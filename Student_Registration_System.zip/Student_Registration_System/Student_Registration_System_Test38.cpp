#include <iostream>
#include <vector>
#include <string>

struct Course {
    std::string courseID;
    std::string courseName;
};

struct Student {
    std::string studentID;
    std::string studentName;
    std::vector<Course> courses;
};

class RegistrationSystem {
private:
    std::vector<Student> students;

    int findStudentIndex(const std::string& studentID) {
        for (int i = 0; i < students.size(); ++i) {
            if (students[i].studentID == studentID) {
                return i;
            }
        }
        return -1;
    }

public:
    void addStudent(const std::string& studentID, const std::string& studentName) {
        if (findStudentIndex(studentID) == -1) {
            students.push_back({studentID, studentName, {}});
        }
    }

    void deleteStudent(const std::string& studentID) {
        int index = findStudentIndex(studentID);
        if (index != -1) {
            students.erase(students.begin() + index);
        }
    }

    void updateStudent(const std::string& studentID, const std::string& studentName) {
        int index = findStudentIndex(studentID);
        if (index != -1) {
            students[index].studentName = studentName;
        }
    }

    void addCourseToStudent(const std::string& studentID, const std::string& courseID, const std::string& courseName) {
        int index = findStudentIndex(studentID);
        if (index != -1) {
            students[index].courses.push_back({courseID, courseName});
        }
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.studentID << ", Name: " << student.studentName << std::endl;
            for (const auto& course : student.courses) {
                std::cout << "  Course ID: " << course.courseID << ", Name: " << course.courseName << std::endl;
            }
        }
    }

    bool searchStudent(const std::string& studentID) {
        int index = findStudentIndex(studentID);
        if (index != -1) {
            std::cout << "Student ID: " << students[index].studentID << ", Name: " << students[index].studentName << std::endl;
            for (const auto& course : students[index].courses) {
                std::cout << "  Course ID: " << course.courseID << ", Name: " << course.courseName << std::endl;
            }
            return true;
        }
        return false;
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent("S001", "John Doe");
    system.addStudent("S002", "Jane Smith");
    system.addCourseToStudent("S001", "C101", "Mathematics");
    system.addCourseToStudent("S001", "C102", "Physics");
    system.addCourseToStudent("S002", "C103", "Chemistry");
    system.displayStudents();
    system.searchStudent("S001");
    system.updateStudent("S002", "Janet Smith");
    system.displayStudents();
    system.deleteStudent("S001");
    system.displayStudents();
    return 0;
}