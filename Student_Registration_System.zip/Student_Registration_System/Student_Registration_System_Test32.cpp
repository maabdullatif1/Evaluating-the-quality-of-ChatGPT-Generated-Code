#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int courseID;
    std::string courseName;

    Course(int id, const std::string& name) : courseID(id), courseName(name) {}
};

class Student {
public:
    int studentID;
    std::string studentName;

    Student(int id, const std::string& name) : studentID(id), studentName(name) {}
};

class RegistrationSystem {
    std::vector<Student> students;
    std::vector<Course> courses;

public:
    void addStudent(int id, const std::string& name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string& name) {
        for (auto& student : students) {
            if (student.studentID == id) {
                student.studentName = name;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.studentID == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.studentID << ", Name: " << student.studentName << std::endl;
        }
    }

    void addCourse(int id, const std::string& name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, const std::string& name) {
        for (auto& course : courses) {
            if (course.courseID == id) {
                course.courseName = name;
                break;
            }
        }
    }

    Course* searchCourse(int id) {
        for (auto& course : courses) {
            if (course.courseID == id) {
                return &course;
            }
        }
        return nullptr;
    }

    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.courseID << ", Name: " << course.courseName << std::endl;
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(101, "Math");
    system.addCourse(102, "Science");

    system.displayStudents();
    system.displayCourses();

    system.updateStudent(1, "Alicia");
    system.updateCourse(101, "Mathematics");

    system.displayStudents();
    system.displayCourses();

    system.deleteStudent(2);
    system.deleteCourse(102);

    system.displayStudents();
    system.displayCourses();

    return 0;
}