#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    std::string courseId;
    std::string courseName;

    Course(std::string id, std::string name) : courseId(id), courseName(name) {}
};

class Student {
public:
    std::string studentId;
    std::string studentName;
    std::vector<Course> courses;

    Student(std::string id, std::string name) : studentId(id), studentName(name) {}
    
    void addCourse(const Course& course) {
        courses.push_back(course);
    }
    
    void removeCourse(const std::string& courseId) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseId == courseId) {
                courses.erase(it);
                break;
            }
        }
    }
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

public:
    void addStudent(const std::string& id, const std::string& name) {
        students.push_back(Student(id, name));
    }
    
    void deleteStudent(const std::string& id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentId == id) {
                students.erase(it);
                break;
            }
        }
    }
    
    void updateStudent(const std::string& id, const std::string& newName) {
        for (auto& student : students) {
            if (student.studentId == id) {
                student.studentName = newName;
                break;
            }
        }
    }
    
    void addCourse(const std::string& id, const std::string& name) {
        courses.push_back(Course(id, name));
    }
    
    void deleteCourse(const std::string& id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseId == id) {
                courses.erase(it);
                break;
            }
        }
    }

    Student* searchStudent(const std::string& id) {
        for (auto& student : students) {
            if (student.studentId == id) {
                return &student;
            }
        }
        return nullptr;
    }

    Course* searchCourse(const std::string& id) {
        for (auto& course : courses) {
            if (course.courseId == id) {
                return &course;
            }
        }
        return nullptr;
    }
    
    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "ID: " << student.studentId << ", Name: " << student.studentName << "\n";
            std::cout << "Courses: ";
            for (const auto& course : student.courses) {
                std::cout << course.courseName << " ";
            }
            std::cout << "\n";
        }
    }

    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "ID: " << course.courseId << ", Name: " << course.courseName << "\n";
        }
    }
};

int main() {
    RegistrationSystem regSystem;
    regSystem.addStudent("S001", "John Doe");
    regSystem.addCourse("C001", "Mathematics");
    regSystem.addCourse("C002", "Physics");

    Student* student = regSystem.searchStudent("S001");
    if (student) {
        Course* course = regSystem.searchCourse("C001");
        if (course) {
            student->addCourse(*course);
        }
    }

    regSystem.displayStudents();
    regSystem.displayCourses();

    return 0;
}