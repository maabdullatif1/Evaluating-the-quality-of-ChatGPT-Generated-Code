#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int id;
    std::string name;
    
    Course(int id, std::string name) : id(id), name(name) {}
};

class Student {
public:
    int id;
    std::string name;
    std::vector<Course> courses;
    
    Student(int id, std::string name) : id(id), name(name) {}

    void addCourse(const Course& course) {
        courses.push_back(course);
    }

    void removeCourse(int courseId) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == courseId) {
                courses.erase(it);
                break;
            }
        }
    }
};

class RegistrationSystem {
    std::vector<Student> students;
    std::vector<Course> courses;

public:
    void addStudent(int id, std::string name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string newName) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = newName;
            }
        }
    }

    void addCourse(int courseId, std::string name) {
        courses.emplace_back(courseId, name);
    }

    void deleteCourse(int courseId) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == courseId) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int courseId, std::string newName) {
        for (auto& course : courses) {
            if (course.id == courseId) {
                course.name = newName;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    Course* searchCourse(int id) {
        for (auto& course : courses) {
            if (course.id == id) {
                return &course;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }

    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.id << ", Name: " << course.name << std::endl;
        }
    }
};

int main() {
    RegistrationSystem system;
    
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    
    system.addCourse(101, "Mathematics");
    system.addCourse(102, "Science");

    system.displayStudents();
    system.displayCourses();
    
    Student* student = system.searchStudent(1);
    if (student) {
        Course* course = system.searchCourse(101);
        if (course) {
            student->addCourse(*course);
        }
    }
    
    system.deleteStudent(2);
    system.updateCourse(101, "Advanced Mathematics");
    system.displayStudents();
    system.displayCourses();

    return 0;
}