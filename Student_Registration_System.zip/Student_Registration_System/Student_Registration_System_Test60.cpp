#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Course {
    string courseID;
    string courseName;
};

struct Student {
    string studentID;
    string name;
    vector<Course> courses;
};

class RegistrationSystem {
    vector<Student> students;
public:
    void addStudent(const string& studentID, const string& name) {
        Student newStudent = {studentID, name, {}};
        students.push_back(newStudent);
    }

    void deleteStudent(const string& studentID) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == studentID) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(const string& studentID, const string& newName) {
        for (auto& student : students) {
            if (student.studentID == studentID) {
                student.name = newName;
                return;
            }
        }
    }

    Student* searchStudent(const string& studentID) {
        for (auto& student : students) {
            if (student.studentID == studentID) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            cout << "ID: " << student.studentID << ", Name: " << student.name << endl;
        }
    }

    void addCourseToStudent(const string& studentID, const string& courseID, const string& courseName) {
        Student* student = searchStudent(studentID);
        if (student != nullptr) {
            student->courses.push_back({courseID, courseName});
        }
    }

    void displayStudentCourses(const string& studentID) {
        Student* student = searchStudent(studentID);
        if (student != nullptr) {
            cout << "Courses for " << student->name << ":" << endl;
            for (const auto& course : student->courses) {
                cout << "Course ID: " << course.courseID << ", Course Name: " << course.courseName << endl;
            }
        }
    }

    void deleteCourseFromStudent(const string& studentID, const string& courseID) {
        Student* student = searchStudent(studentID);
        if (student != nullptr) {
            for (auto it = student->courses.begin(); it != student->courses.end(); ++it) {
                if (it->courseID == courseID) {
                    student->courses.erase(it);
                    return;
                }
            }
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent("S001", "Alice");
    system.addStudent("S002", "Bob");
    system.addCourseToStudent("S001", "C101", "Math");
    system.addCourseToStudent("S001", "C102", "Science");
    system.displayStudents();
    system.displayStudentCourses("S001");
    return 0;
}