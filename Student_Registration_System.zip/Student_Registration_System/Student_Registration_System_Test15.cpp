#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int courseId;
    std::string courseName;

    Course(int id, std::string name) : courseId(id), courseName(name) {}
};

class Student {
public:
    int studentId;
    std::string studentName;
    std::vector<Course> courses;

    Student(int id, std::string name) : studentId(id), studentName(name) {}
    
    void addCourse(Course course) {
        courses.push_back(course);
    }
};

class StudentRegistrationSystem {
private:
    std::vector<Student> students;

public:
    void addStudent(int studentId, std::string studentName) {
        students.push_back(Student(studentId, studentName));
    }

    void deleteStudent(int studentId) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentId == studentId) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int studentId, std::string newStudentName) {
        for (auto& student : students) {
            if (student.studentId == studentId) {
                student.studentName = newStudentName;
                break;
            }
        }
    }

    void addCourseToStudent(int studentId, int courseId, std::string courseName) {
        for (auto& student : students) {
            if (student.studentId == studentId) {
                student.addCourse(Course(courseId, courseName));
                break;
            }
        }
    }

    Student* searchStudent(int studentId) {
        for (auto& student : students) {
            if (student.studentId == studentId) {
                return &student;
            }
        }
        return nullptr;
    }
    
    void displayStudentInfo(int studentId) {
        Student* student = searchStudent(studentId);
        if (student != nullptr) {
            std::cout << "Student ID: " << student->studentId << ", Name: " << student->studentName << "\nCourses:\n";
            for (auto& course : student->courses) {
                std::cout << "  Course ID: " << course.courseId << ", Name: " << course.courseName << "\n";
            }
        } else {
            std::cout << "Student not found.\n";
        }
    }

    void displayAllStudents() {
        for (auto& student : students) {
            std::cout << "Student ID: " << student.studentId << ", Name: " << student.studentName << "\n";
        }
    }
};

int main() {
    StudentRegistrationSystem srs;
    srs.addStudent(1, "Alice");
    srs.addStudent(2, "Bob");
    srs.addCourseToStudent(1, 101, "Mathematics");
    srs.addCourseToStudent(1, 102, "Physics");
    srs.updateStudent(2, "Robert");
    srs.displayStudentInfo(1);
    srs.displayAllStudents();
    srs.deleteStudent(1);
    srs.displayAllStudents();
    return 0;
}