#include <iostream>
#include <vector>
#include <string>

struct Course {
    int courseID;
    std::string courseName;
};

struct Student {
    int studentID;
    std::string studentName;
    std::vector<Course> courses;
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

public:
    void addStudent(int id, const std::string& name) {
        students.push_back({ id, name });
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string& name) {
        for (auto & student : students) {
            if (student.studentID == id) {
                student.studentName = name;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto & student : students) {
            if (student.studentID == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.studentID << ", Name: " << student.studentName << std::endl;
        }
    }

    void addCourse(int id, const std::string& name) {
        courses.push_back({ id, name });
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, const std::string& name) {
        for (auto & course : courses) {
            if (course.courseID == id) {
                course.courseName = name;
                break;
            }
        }
    }

    Course* searchCourse(int id) {
        for (auto & course : courses) {
            if (course.courseID == id) {
                return &course;
            }
        }
        return nullptr;
    }

    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.courseID << ", Name: " << course.courseName << std::endl;
        }
    }

    void registerStudentToCourse(int studentID, int courseID) {
        Student* student = searchStudent(studentID);
        Course* course = searchCourse(courseID);
        if (student && course) {
            student->courses.push_back(*course);
        }
    }

    void displayStudentCourses(int studentID) {
        Student* student = searchStudent(studentID);
        if (student) {
            std::cout << "Student ID: " << student->studentID << ", Name: " << student->studentName << ", Courses: ";
            for (const auto& course : student->courses) {
                std::cout << course.courseName << " ";
            }
            std::cout << std::endl;
        }
    }
};

int main() {
    RegistrationSystem regSys;
    regSys.addStudent(1, "Alice");
    regSys.addStudent(2, "Bob");
    regSys.addCourse(101, "Math");
    regSys.addCourse(102, "Science");
    regSys.registerStudentToCourse(1, 101);
    regSys.registerStudentToCourse(2, 102);
    regSys.displayStudents();
    regSys.displayCourses();
    regSys.displayStudentCourses(1);
    regSys.displayStudentCourses(2);
    return 0;
}