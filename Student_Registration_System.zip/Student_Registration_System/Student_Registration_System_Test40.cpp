#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    std::string courseId;
    std::string courseName;

    Course(const std::string& id, const std::string& name) : courseId(id), courseName(name) {}
};

class Student {
public:
    int studentId;
    std::string studentName;
    std::vector<Course> courses;

    Student(int id, const std::string& name) : studentId(id), studentName(name) {}
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

    Student* findStudentById(int studentId) {
        for (auto& student : students) {
            if (student.studentId == studentId) {
                return &student;
            }
        }
        return nullptr;
    }

    Course* findCourseById(const std::string& courseId) {
        for (auto& course : courses) {
            if (course.courseId == courseId) {
                return &course;
            }
        }
        return nullptr;
    }

public:
    void addStudent(int studentId, const std::string& studentName) {
        students.emplace_back(studentId, studentName);
    }

    void deleteStudent(int studentId) {
        students.erase(std::remove_if(students.begin(), students.end(),
            [studentId](Student& student) { return student.studentId == studentId; }),
            students.end());
    }

    void updateStudent(int studentId, const std::string& newStudentName) {
        Student* student = findStudentById(studentId);
        if (student) {
            student->studentName = newStudentName;
        }
    }

    Student* searchStudent(int studentId) {
        return findStudentById(studentId);
    }

    void addCourse(const std::string& courseId, const std::string& courseName) {
        courses.emplace_back(courseId, courseName);
    }

    void deleteCourse(const std::string& courseId) {
        courses.erase(std::remove_if(courses.begin(), courses.end(),
            [courseId](Course& course) { return course.courseId == courseId; }),
            courses.end());
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.studentId << ", Name: " << student.studentName << "\n";
        }
    }

    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.courseId << ", Name: " << course.courseName << "\n";
        }
    }

    void enrollStudentInCourse(int studentId, const std::string& courseId) {
        Student* student = findStudentById(studentId);
        Course* course = findCourseById(courseId);
        if (student && course) {
            student->courses.push_back(*course);
        }
    }

    void displayStudentCourses(int studentId) {
        Student* student = findStudentById(studentId);
        if (student) {
            std::cout << "Courses for Student ID: " << student->studentId << ", Name: " << student->studentName << "\n";
            for (const auto& course : student->courses) {
                std::cout << "Course ID: " << course.courseId << ", Name: " << course.courseName << "\n";
            }
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse("CSE101", "Computer Science Basics");
    system.addCourse("CSE201", "Data Structures");
    system.enrollStudentInCourse(1, "CSE101");
    system.enrollStudentInCourse(1, "CSE201");
    system.enrollStudentInCourse(2, "CSE101");
    system.displayStudents();
    system.displayCourses();
    system.displayStudentCourses(1);
    system.displayStudentCourses(2);
    return 0;
}