#include <iostream>
#include <string>
using namespace std;

struct Student {
    int id;
    string name;
    string course;
};

struct Course {
    string code;
    string title;
};

const int MAX_STUDENTS = 100;
const int MAX_COURSES = 100;
Student students[MAX_STUDENTS];
Course courses[MAX_COURSES];
int studentCount = 0;
int courseCount = 0;

void addStudent(int id, string name, string course) {
    if (studentCount < MAX_STUDENTS) {
        students[studentCount++] = {id, name, course};
        cout << "Student added successfully.\n";
    } else {
        cout << "Student limit reached.\n";
    }
}

void deleteStudent(int id) {
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].id == id) {
            students[i] = students[--studentCount];
            cout << "Student deleted successfully.\n";
            return;
        }
    }
    cout << "Student not found.\n";
}

void updateStudent(int id, string name, string course) {
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].id == id) {
            students[i].name = name;
            students[i].course = course;
            cout << "Student updated successfully.\n";
            return;
        }
    }
    cout << "Student not found.\n";
}

void searchStudent(int id) {
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].id == id) {
            cout << "Student found: ID=" << students[i].id << ", Name=" << students[i].name << ", Course=" << students[i].course << endl;
            return;
        }
    }
    cout << "Student not found.\n";
}

void displayStudents() {
    for (int i = 0; i < studentCount; ++i) {
        cout << "ID=" << students[i].id << ", Name=" << students[i].name << ", Course=" << students[i].course << endl;
    }
}

void addCourse(string code, string title) {
    if (courseCount < MAX_COURSES) {
        courses[courseCount++] = {code, title};
        cout << "Course added successfully.\n";
    } else {
        cout << "Course limit reached.\n";
    }
}

void deleteCourse(string code) {
    for (int i = 0; i < courseCount; ++i) {
        if (courses[i].code == code) {
            courses[i] = courses[--courseCount];
            cout << "Course deleted successfully.\n";
            return;
        }
    }
    cout << "Course not found.\n";
}

void updateCourse(string code, string title) {
    for (int i = 0; i < courseCount; ++i) {
        if (courses[i].code == code) {
            courses[i].title = title;
            cout << "Course updated successfully.\n";
            return;
        }
    }
    cout << "Course not found.\n";
}

void searchCourse(string code) {
    for (int i = 0; i < courseCount; ++i) {
        if (courses[i].code == code) {
            cout << "Course found: Code=" << courses[i].code << ", Title=" << courses[i].title << endl;
            return;
        }
    }
    cout << "Course not found.\n";
}

void displayCourses() {
    for (int i = 0; i < courseCount; ++i) {
        cout << "Code=" << courses[i].code << ", Title=" << courses[i].title << endl;
    }
}

int main() {
    int option, id;
    string name, courseCode, courseTitle;
    while (true) {
        cout << "1. Add Student\n2. Delete Student\n3. Update Student\n4. Search Student\n5. Display Students\n";
        cout << "6. Add Course\n7. Delete Course\n8. Update Course\n9. Search Course\n10. Display Courses\n11. Exit\n";
        cout << "Choose an option: ";
        cin >> option;
        switch (option) {
            case 1:
                cout << "Enter ID, Name, Course: ";
                cin >> id >> name >> courseCode;
                addStudent(id, name, courseCode);
                break;
            case 2:
                cout << "Enter ID: ";
                cin >> id;
                deleteStudent(id);
                break;
            case 3:
                cout << "Enter ID, New Name, New Course: ";
                cin >> id >> name >> courseCode;
                updateStudent(id, name, courseCode);
                break;
            case 4:
                cout << "Enter ID: ";
                cin >> id;
                searchStudent(id);
                break;
            case 5:
                displayStudents();
                break;
            case 6:
                cout << "Enter Course Code, Title: ";
                cin >> courseCode >> courseTitle;
                addCourse(courseCode, courseTitle);
                break;
            case 7:
                cout << "Enter Course Code: ";
                cin >> courseCode;
                deleteCourse(courseCode);
                break;
            case 8:
                cout << "Enter Course Code, New Title: ";
                cin >> courseCode >> courseTitle;
                updateCourse(courseCode, courseTitle);
                break;
            case 9:
                cout << "Enter Course Code: ";
                cin >> courseCode;
                searchCourse(courseCode);
                break;
            case 10:
                displayCourses();
                break;
            case 11:
                return 0;
            default:
                cout << "Invalid option. Try again.\n";
        }
    }
    return 0;
}