#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Course {
    int courseId;
    string courseName;
};

struct Student {
    int studentId;
    string studentName;
    vector<Course> courses;
};

vector<Student> students;

void addStudent(int id, string name) {
    Student student;
    student.studentId = id;
    student.studentName = name;
    students.push_back(student);
}

void deleteStudent(int id) {
    for (auto it = students.begin(); it != students.end(); ++it) {
        if (it->studentId == id) {
            students.erase(it);
            break;
        }
    }
}

void updateStudent(int id, string newName) {
    for (auto& student : students) {
        if (student.studentId == id) {
            student.studentName = newName;
            break;
        }
    }
}

Student* searchStudent(int id) {
    for (auto& student : students) {
        if (student.studentId == id) {
            return &student;
        }
    }
    return nullptr;
}

void displayStudents() {
    for (const auto& student : students) {
        cout << "ID: " << student.studentId << ", Name: " << student.studentName << "\nCourses: ";
        for (const auto& course : student.courses) {
            cout << course.courseName << " (ID: " << course.courseId << ") ";
        }
        cout << endl;
    }
}

void addCourseToStudent(int studentId, int courseId, string courseName) {
    Student* student = searchStudent(studentId);
    if (student) {
        Course course;
        course.courseId = courseId;
        course.courseName = courseName;
        student->courses.push_back(course);
    }
}

void deleteCourseFromStudent(int studentId, int courseId) {
    Student* student = searchStudent(studentId);
    if (student) {
        auto& courses = student->courses;
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseId == courseId) {
                courses.erase(it);
                break;
            }
        }
    }
}

int main() {
    addStudent(1, "Alice");
    addStudent(2, "Bob");
    addCourseToStudent(1, 100, "Math");
    addCourseToStudent(1, 101, "Physics");
    addCourseToStudent(2, 102, "Chemistry");

    displayStudents();

    updateStudent(1, "Alicia");
    deleteCourseFromStudent(1, 101);
    displayStudents();

    deleteStudent(2);
    displayStudents();

    return 0;
}