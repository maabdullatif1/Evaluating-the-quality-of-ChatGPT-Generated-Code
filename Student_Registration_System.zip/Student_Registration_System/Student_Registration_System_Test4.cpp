#include <iostream>
#include <vector>
#include <string>

struct Course {
    int id;
    std::string name;
};

struct Student {
    int id;
    std::string name;
    std::vector<int> course_ids;
};

class RegistrationSystem {
    std::vector<Student> students;
    std::vector<Course> courses;
public:
    void addStudent(int id, const std::string& name) {
        students.push_back({id, name, {}});
    }
    
    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }
    
    void updateStudent(int id, const std::string& new_name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = new_name;
                break;
            }
        }
    }
    
    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.id == id) return &student;
        }
        return nullptr;
    }
    
    void addCourse(int id, const std::string& name) {
        courses.push_back({id, name});
    }
    
    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == id) {
                courses.erase(it);
                break;
            }
        }
        for (auto& student : students) {
            student.course_ids.erase(
                std::remove(student.course_ids.begin(), student.course_ids.end(), id),
                student.course_ids.end()
            );
        }
    }
    
    Course* searchCourse(int id) {
        for (auto& course : courses) {
            if (course.id == id) return &course;
        }
        return nullptr;
    }
    
    void enrollStudentInCourse(int student_id, int course_id) {
        Student* student = searchStudent(student_id);
        if (student && searchCourse(course_id)) {
            student->course_ids.push_back(course_id);
        }
    }
    
    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << ", Courses: ";
            for (int course_id : student.course_ids) {
                Course* course = searchCourse(course_id);
                if (course) {
                    std::cout << course->name << " ";
                }
            }
            std::cout << std::endl;
        }
    }
    
    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "ID: " << course.id << ", Name: " << course.name << std::endl;
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(101, "Math");
    system.addCourse(102, "Science");
    system.enrollStudentInCourse(1, 101);
    system.enrollStudentInCourse(2, 102);
    system.displayStudents();
    system.displayCourses();
    return 0;
}