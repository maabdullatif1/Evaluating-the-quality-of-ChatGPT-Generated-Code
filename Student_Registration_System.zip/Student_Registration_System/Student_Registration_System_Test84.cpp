#include <iostream>
#include <string>
#include <vector>

class Course {
public:
    int courseId;
    std::string courseName;
    Course(int id, std::string name) : courseId(id), courseName(name) {}
};

class Student {
public:
    int studentId;
    std::string studentName;
    Student(int id, std::string name) : studentId(id), studentName(name) {}
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;
    
public:
    void addStudent(int id, const std::string& name) {
        students.push_back(Student(id, name));
    }
    
    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentId == id) {
                students.erase(it);
                break;
            }
        }
    }
    
    void updateStudent(int id, const std::string& newName) {
        for (auto& student : students) {
            if (student.studentId == id) {
                student.studentName = newName;
                break;
            }
        }
    }
    
    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.studentId == id) {
                std::cout << "Found Student: " << student.studentId << ", " << student.studentName << std::endl;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }
    
    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.studentId << ", Name: " << student.studentName << std::endl;
        }
    }
    
    void addCourse(int id, const std::string& name) {
        courses.push_back(Course(id, name));
    }
    
    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseId == id) {
                courses.erase(it);
                break;
            }
        }
    }
    
    void updateCourse(int id, const std::string& newName) {
        for (auto& course : courses) {
            if (course.courseId == id) {
                course.courseName = newName;
                break;
            }
        }
    }
    
    void searchCourse(int id) {
        for (const auto& course : courses) {
            if (course.courseId == id) {
                std::cout << "Found Course: " << course.courseId << ", " << course.courseName << std::endl;
                return;
            }
        }
        std::cout << "Course not found" << std::endl;
    }
    
    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.courseId << ", Name: " << course.courseName << std::endl;
        }
    }
};

int main() {
    RegistrationSystem system;
    
    system.addStudent(1, "John Doe");
    system.addStudent(2, "Jane Smith");
    system.displayStudents();
    
    system.updateStudent(1, "Johnny Doe");
    system.searchStudent(1);
    
    system.addCourse(101, "Mathematics");
    system.addCourse(102, "Physics");
    system.displayCourses();
    
    system.updateCourse(101, "Advanced Mathematics");
    system.searchCourse(101);
    
    system.deleteStudent(2);
    system.displayStudents();
    
    system.deleteCourse(102);
    system.displayCourses();
    
    return 0;
}