#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int courseId;
    std::string courseName;
    int credits;

    Course(int id, std::string name, int cr) : courseId(id), courseName(name), credits(cr) {}
};

class Student {
public:
    int studentId;
    std::string studentName;
    std::vector<Course> courses;

    Student(int id, std::string name) : studentId(id), studentName(name) {}

    void addCourse(const Course& course) {
        courses.push_back(course);
    }

    void removeCourse(int courseId) {
        for (size_t i = 0; i < courses.size(); ++i) {
            if (courses[i].courseId == courseId) {
                courses.erase(courses.begin() + i);
                return;
            }
        }
    }
};

class RegistrationSystem {
private:
    std::vector<Student> students;

public:
    void addStudent(int id, const std::string& name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(int studentId) {
        for (size_t i = 0; i < students.size(); ++i) {
            if (students[i].studentId == studentId) {
                students.erase(students.begin() + i);
                return;
            }
        }
    }

    void updateStudent(int id, const std::string& newName) {
        for (auto& student : students) {
            if (student.studentId == id) {
                student.studentName = newName;
                return;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.studentId == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.studentId << " Name: " << student.studentName << std::endl;
            for (const auto& course : student.courses) {
                std::cout << "\tCourse ID: " << course.courseId << " Name: " << course.courseName << " Credits: " << course.credits << std::endl;
            }
        }
    }

    void addCourseToStudent(int studentId, int courseId, const std::string& courseName, int credits) {
        Student* student = searchStudent(studentId);
        if (student) {
            student->addCourse(Course(courseId, courseName, credits));
        }
    }

    void removeCourseFromStudent(int studentId, int courseId) {
        Student* student = searchStudent(studentId);
        if (student) {
            student->removeCourse(courseId);
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "John Doe");
    system.addStudent(2, "Jane Smith");
    system.addCourseToStudent(1, 101, "Math", 3);
    system.addCourseToStudent(1, 102, "Science", 4);
    system.displayStudents();
    system.updateStudent(1, "Johnny Doe");
    system.removeCourseFromStudent(1, 101);
    system.displayStudents();
    system.deleteStudent(2);
    system.displayStudents();
    return 0;
}