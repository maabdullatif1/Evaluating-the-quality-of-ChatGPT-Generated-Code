#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    string courseId;
    string courseName;
    Course(string id, string name) : courseId(id), courseName(name) {}
};

class Student {
public:
    string studentId;
    string studentName;
    vector<Course> courses;
    
    Student(string id, string name) : studentId(id), studentName(name) {}
    
    void addCourse(Course course) {
        courses.push_back(course);
    }

    void removeCourse(string courseId) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseId == courseId) {
                courses.erase(it);
                return;
            }
        }
    }

    void updateCourse(string courseId, string newName) {
        for (auto &course : courses) {
            if (course.courseId == courseId) {
                course.courseName = newName;
                return;
            }
        }
    }
};

class StudentRegistrationSystem {
    vector<Student> students;

public:
    void addStudent(string id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(string id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentId == id) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(string id, string newName) {
        for (auto &student : students) {
            if (student.studentId == id) {
                student.studentName = newName;
                return;
            }
        }
    }

    Student* searchStudent(string id) {
        for (auto &student : students) {
            if (student.studentId == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto &student : students) {
            cout << "Student ID: " << student.studentId << ", Name: " << student.studentName << endl;
            for (const auto &course : student.courses) {
                cout << "  Course ID: " << course.courseId << ", Course Name: " << course.courseName << endl;
            }
        }
    }
};

int main() {
    StudentRegistrationSystem system;
    system.addStudent("001", "John Doe");
    system.addStudent("002", "Jane Smith");

    Student* student = system.searchStudent("001");
    if (student) {
        student->addCourse(Course("C101", "Mathematics"));
        student->addCourse(Course("C102", "Science"));
    }

    student = system.searchStudent("002");
    if (student) {
        student->addCourse(Course("C103", "Literature"));
    }

    system.displayStudents();

    system.updateStudent("001", "Johnathan Doe");
    student = system.searchStudent("002");
    if (student) {
        student->removeCourse("C103");
    }

    system.displayStudents();

    system.deleteStudent("002");
    system.displayStudents();

    return 0;
}