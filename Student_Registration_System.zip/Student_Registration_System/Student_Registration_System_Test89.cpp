#include <iostream>
#include <string>

using namespace std;

struct Student {
    string id;
    string name;
    int age;
    string course;
};

struct Course {
    string code;
    string title;
    int credits;
};

const int MAX_STUDENTS = 100;
const int MAX_COURSES = 50;
Student students[MAX_STUDENTS];
Course courses[MAX_COURSES];
int studentCount = 0;
int courseCount = 0;

void addStudent() {
    if (studentCount < MAX_STUDENTS) {
        cout << "Enter ID: ";
        cin >> students[studentCount].id;
        cout << "Enter name: ";
        cin >> students[studentCount].name;
        cout << "Enter age: ";
        cin >> students[studentCount].age;
        cout << "Enter course: ";
        cin >> students[studentCount].course;
        studentCount++;
        cout << "Student added successfully.\n";
    } else {
        cout << "Student limit reached.\n";
    }
}

void deleteStudent() {
    string id;
    cout << "Enter student ID to delete: ";
    cin >> id;
    for (int i = 0; i < studentCount; i++) {
        if (students[i].id == id) {
            for (int j = i; j < studentCount - 1; j++) {
                students[j] = students[j + 1];
            }
            studentCount--;
            cout << "Student deleted successfully.\n";
            return;
        }
    }
    cout << "Student not found.\n";
}

void updateStudent() {
    string id;
    cout << "Enter student ID to update: ";
    cin >> id;
    for (int i = 0; i < studentCount; i++) {
        if (students[i].id == id) {
            cout << "Enter new name: ";
            cin >> students[i].name;
            cout << "Enter new age: ";
            cin >> students[i].age;
            cout << "Enter new course: ";
            cin >> students[i].course;
            cout << "Student updated successfully.\n";
            return;
        }
    }
    cout << "Student not found.\n";
}

void searchStudent() {
    string id;
    cout << "Enter student ID to search: ";
    cin >> id;
    for (int i = 0; i < studentCount; i++) {
        if (students[i].id == id) {
            cout << "ID: " << students[i].id << "\nName: " << students[i].name << "\nAge: " << students[i].age << "\nCourse: " << students[i].course << '\n';
            return;
        }
    }
    cout << "Student not found.\n";
}

void displayStudents() {
    for (int i = 0; i < studentCount; i++) {
        cout << "ID: " << students[i].id << "\nName: " << students[i].name << "\nAge: " << students[i].age << "\nCourse: " << students[i].course << '\n';
    }
}

void addCourse() {
    if (courseCount < MAX_COURSES) {
        cout << "Enter course code: ";
        cin >> courses[courseCount].code;
        cout << "Enter course title: ";
        cin >> courses[courseCount].title;
        cout << "Enter course credits: ";
        cin >> courses[courseCount].credits;
        courseCount++;
        cout << "Course added successfully.\n";
    } else {
        cout << "Course limit reached.\n";
    }
}

void displayCourses() {
    for (int i = 0; i < courseCount; i++) {
        cout << "Code: " << courses[i].code << "\nTitle: " << courses[i].title << "\nCredits: " << courses[i].credits << '\n';
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Student\n2. Delete Student\n3. Update Student\n4. Search Student\n5. Display Students\n6. Add Course\n7. Display Courses\n8. Exit\nEnter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addStudent(); break;
            case 2: deleteStudent(); break;
            case 3: updateStudent(); break;
            case 4: searchStudent(); break;
            case 5: displayStudents(); break;
            case 6: addCourse(); break;
            case 7: displayCourses(); break;
        }
    } while (choice != 8);
    return 0;
}