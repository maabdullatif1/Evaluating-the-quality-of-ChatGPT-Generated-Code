#include <iostream>
#include <vector>
#include <string>

class Student {
public:
    int id;
    std::string name;

    Student(int studentId, const std::string& studentName) : id(studentId), name(studentName) {}
};

class Course {
public:
    int id;
    std::string name;

    Course(int courseId, const std::string& courseName) : id(courseId), name(courseName) {}
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

public:
    void addStudent(int id, const std::string& name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end();) {
            if (it->id == id) {
                it = students.erase(it);
            } else {
                ++it;
            }
        }
    }

    void updateStudent(int id, const std::string& newName) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                std::cout << "Student found: ID=" << student.id << " Name=" << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "ID=" << student.id << " Name=" << student.name << std::endl;
        }
    }

    void addCourse(int id, const std::string& name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end();) {
            if (it->id == id) {
                it = courses.erase(it);
            } else {
                ++it;
            }
        }
    }

    void updateCourse(int id, const std::string& newName) {
        for (auto& course : courses) {
            if (course.id == id) {
                course.name = newName;
                break;
            }
        }
    }

    void searchCourse(int id) {
        for (const auto& course : courses) {
            if (course.id == id) {
                std::cout << "Course found: ID=" << course.id << " Name=" << course.name << std::endl;
                return;
            }
        }
        std::cout << "Course not found" << std::endl;
    }

    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "ID=" << course.id << " Name=" << course.name << std::endl;
        }
    }
};

int main() {
    RegistrationSystem system;

    system.addStudent(1, "John Doe");
    system.addStudent(2, "Jane Smith");
    system.displayStudents();

    system.updateStudent(2, "Jane Johnson");
    system.displayStudents();

    system.searchStudent(1);

    system.addCourse(101, "Mathematics");
    system.addCourse(102, "Physics");
    system.displayCourses();

    system.updateCourse(101, "Advanced Mathematics");
    system.displayCourses();

    system.searchCourse(102);

    return 0;
}