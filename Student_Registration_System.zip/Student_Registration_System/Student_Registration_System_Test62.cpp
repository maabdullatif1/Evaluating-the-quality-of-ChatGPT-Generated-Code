#include <iostream>
#include <string>

using namespace std;

struct Course {
    int courseId;
    string courseName;
};

struct Student {
    int studentId;
    string studentName;
    Course courses[5];
    int courseCount;
};

class RegistrationSystem {
    Student students[100];
    int studentCount;
public:
    RegistrationSystem() : studentCount(0) {}

    void addStudent(int id, string name) {
        students[studentCount].studentId = id;
        students[studentCount].studentName = name;
        students[studentCount].courseCount = 0;
        studentCount++;
    }

    void deleteStudent(int id) {
        for (int i = 0; i < studentCount; i++) {
            if (students[i].studentId == id) {
                for (int j = i; j < studentCount - 1; j++) {
                    students[j] = students[j + 1];
                }
                studentCount--;
                break;
            }
        }
    }

    void updateStudent(int id, string newName) {
        for (int i = 0; i < studentCount; i++) {
            if (students[i].studentId == id) {
                students[i].studentName = newName;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (int i = 0; i < studentCount; i++) {
            if (students[i].studentId == id) {
                return &students[i];
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (int i = 0; i < studentCount; i++) {
            cout << students[i].studentId << ": " << students[i].studentName << endl;
            for (int j = 0; j < students[i].courseCount; j++) {
                cout << "  Course " << j + 1 << ": " << students[i].courses[j].courseId << " " << students[i].courses[j].courseName << endl;
            }
        }
    }

    void addCourseToStudent(int studentId, int courseId, string courseName) {
        Student* student = searchStudent(studentId);
        if (student) {
            student->courses[student->courseCount].courseId = courseId;
            student->courses[student->courseCount].courseName = courseName;
            student->courseCount++;
        }
    }

    void deleteCourseFromStudent(int studentId, int courseId) {
        Student* student = searchStudent(studentId);
        if (student) {
            for (int i = 0; i < student->courseCount; i++) {
                if (student->courses[i].courseId == courseId) {
                    for (int j = i; j < student->courseCount - 1; j++) {
                        student->courses[j] = student->courses[j + 1];
                    }
                    student->courseCount--;
                    break;
                }
            }
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourseToStudent(1, 101, "Math");
    system.addCourseToStudent(1, 102, "English");
    system.addCourseToStudent(2, 101, "Math");
    system.displayStudents();
    system.deleteCourseFromStudent(1, 101);
    system.updateStudent(2, "Bobby");
    system.displayStudents();
    system.deleteStudent(1);
    system.displayStudents();
    return 0;
}