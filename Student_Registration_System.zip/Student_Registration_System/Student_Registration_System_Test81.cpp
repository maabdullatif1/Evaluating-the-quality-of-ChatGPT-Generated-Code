#include<iostream>
#include<string>
using namespace std;

struct Course {
    int courseID;
    string courseName;
};

struct Student {
    int studentID;
    string studentName;
    Course courses[10];
    int courseCount;
};

Student students[100];
int studentCount = 0;

void addStudent() {
    int id;
    string name;
    cout << "Enter student ID: ";
    cin >> id;
    cout << "Enter student name: ";
    cin >> name;
    students[studentCount].studentID = id;
    students[studentCount].studentName = name;
    students[studentCount].courseCount = 0;
    studentCount++;
    cout << "Student added.\n";
}

void deleteStudent() {
    int id;
    cout << "Enter student ID to delete: ";
    cin >> id;
    for (int i = 0; i < studentCount; i++) {
        if (students[i].studentID == id) {
            for (int j = i; j < studentCount - 1; j++) {
                students[j] = students[j + 1];
            }
            studentCount--;
            cout << "Student deleted.\n";
            return;
        }
    }
    cout << "Student not found.\n";
}

void updateStudent() {
    int id;
    cout << "Enter student ID to update: ";
    cin >> id;
    for (int i = 0; i < studentCount; i++) {
        if (students[i].studentID == id) {
            cout << "Enter new student name: ";
            cin >> students[i].studentName;
            cout << "Student updated.\n";
            return;
        }
    }
    cout << "Student not found.\n";
}

void searchStudent() {
    int id;
    cout << "Enter student ID to search: ";
    cin >> id;
    for (int i = 0; i < studentCount; i++) {
        if (students[i].studentID == id) {
            cout << "Student ID: " << students[i].studentID << " Name: " << students[i].studentName << "\n";
            return;
        }
    }
    cout << "Student not found.\n";
}

void displayStudents() {
    for (int i = 0; i < studentCount; i++) {
        cout << "Student ID: " << students[i].studentID << " Name: " << students[i].studentName << "\n";
    }
}

void addCourseToStudent() {
    int studentId, courseId;
    string courseName;
    cout << "Enter student ID for course addition: ";
    cin >> studentId;
    for (int i = 0; i < studentCount; i++) {
        if (students[i].studentID == studentId) {
            cout << "Enter course ID: ";
            cin >> courseId;
            cout << "Enter course name: ";
            cin >> courseName;
            students[i].courses[students[i].courseCount].courseID = courseId;
            students[i].courses[students[i].courseCount].courseName = courseName;
            students[i].courseCount++;
            cout << "Course added to student.\n";
            return;
        }
    }
    cout << "Student not found.\n";
}

void displayStudentCourses() {
    int studentId;
    cout << "Enter student ID to display courses: ";
    cin >> studentId;
    for (int i = 0; i < studentCount; i++) {
        if (students[i].studentID == studentId) {
            for (int j = 0; j < students[i].courseCount; j++) {
                cout << "Course ID: " << students[i].courses[j].courseID << " Name: " << students[i].courses[j].courseName << "\n";
            }
            return;
        }
    }
    cout << "Student not found.\n";
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Student\n2. Delete Student\n3. Update Student\n4. Search Student\n5. Display Students\n6. Add Course to Student\n7. Display Student Courses\n8. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addStudent(); break;
            case 2: deleteStudent(); break;
            case 3: updateStudent(); break;
            case 4: searchStudent(); break;
            case 5: displayStudents(); break;
            case 6: addCourseToStudent(); break;
            case 7: displayStudentCourses(); break;
            case 8: return 0;
            default: cout << "Invalid choice.\n";
        }
    }
}