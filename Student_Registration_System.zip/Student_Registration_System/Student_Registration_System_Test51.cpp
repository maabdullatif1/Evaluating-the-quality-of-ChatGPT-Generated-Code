#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Course {
public:
    int courseID;
    string courseName;

    Course(int id, string name) : courseID(id), courseName(name) {}
};

class Student {
public:
    int studentID;
    string studentName;
    vector<Course> courses;

    Student(int id, string name) : studentID(id), studentName(name) {}
};

class RegistrationSystem {
private:
    vector<Student> students;
    vector<Course> courses;

public:
    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); it++) {
            if (it->studentID == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string name) {
        for (auto &student : students) {
            if (student.studentID == id) {
                student.studentName = name;
                break;
            }
        }
    }
    
    void displayStudents() {
        for (const auto &student : students) {
            cout << "Student ID: " << student.studentID << ", Name: " << student.studentName << endl;
            cout << "Courses enrolled:" << endl;
            for (const auto &course : student.courses) {
                cout << "  Course ID: " << course.courseID << ", Name: " << course.courseName << endl;
            }
        }
    }

    void addCourse(int id, string name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); it++) {
            if (it->courseID == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, string name) {
        for (auto &course : courses) {
            if (course.courseID == id) {
                course.courseName = name;
                break;
            }
        }
    }

    void displayCourses() {
        for (const auto &course : courses) {
            cout << "Course ID: " << course.courseID << ", Name: " << course.courseName << endl;
        }
    }

    void enrollStudentInCourse(int studentID, int courseID) {
        Student *student = nullptr;
        Course *course = nullptr;
        for (auto &s : students) {
            if (s.studentID == studentID) {
                student = &s;
                break;
            }
        }
        for (auto &c : courses) {
            if (c.courseID == courseID) {
                course = &c;
                break;
            }
        }
        if (student && course) {
            student->courses.push_back(*course);
        }
    }

    Student searchStudent(int id) {
        for (const auto &student : students) {
            if (student.studentID == id) {
                return student;
            }
        }
        return Student(-1, "");
    }

    Course searchCourse(int id) {
        for (const auto &course : courses) {
            if (course.courseID == id) {
                return course;
            }
        }
        return Course(-1, "");
    }
};

int main() {
    RegistrationSystem regSys;
    regSys.addStudent(1, "Alice");
    regSys.addStudent(2, "Bob");
    regSys.addCourse(101, "Math");
    regSys.addCourse(102, "Science");
    regSys.enrollStudentInCourse(1, 101);
    regSys.displayStudents();
    regSys.displayCourses();
    return 0;
}