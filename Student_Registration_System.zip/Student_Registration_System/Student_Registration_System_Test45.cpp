#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    int courseID;
    string courseName;
    
    Course(int id, string name) : courseID(id), courseName(name) {}
};

class Student {
public:
    int studentID;
    string studentName;
    vector<Course> courses;
    
    Student(int id, string name) : studentID(id), studentName(name) {}
    
    void addCourse(Course course) {
        courses.push_back(course);
    }
    
    void removeCourse(int courseID) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == courseID) {
                courses.erase(it);
                break;
            }
        }
    }
};

class StudentRegistrationSystem {
    vector<Student> students;
    vector<Course> courses;

public:
    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }
    
    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == id) {
                students.erase(it);
                break;
            }
        }
    }
    
    void updateStudent(int id, string newName) {
        for (auto& student : students) {
            if (student.studentID == id) {
                student.studentName = newName;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.studentID == id) {
                return &student;
            }
        }
        return nullptr;
    }
    
    void displayStudents() {
        for (const auto& student : students) {
            cout << "Student ID: " << student.studentID << ", Name: " << student.studentName << "\n";
        }
    }

    void addCourse(int id, string name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, string newName) {
        for (auto& course : courses) {
            if (course.courseID == id) {
                course.courseName = newName;
                break;
            }
        }
    }

    Course* searchCourse(int id) {
        for (auto& course : courses) {
            if (course.courseID == id) {
                return &course;
            }
        }
        return nullptr;
    }

    void displayCourses() {
        for (const auto& course : courses) {
            cout << "Course ID: " << course.courseID << ", Name: " << course.courseName << "\n";
        }
    }
};

int main() {
    StudentRegistrationSystem sys;
    sys.addStudent(1, "Alice");
    sys.addStudent(2, "Bob");
    sys.addCourse(101, "Math");
    sys.addCourse(102, "Science");
    
    Student* student = sys.searchStudent(1);
    if (student) {
        Course* course = sys.searchCourse(101);
        if (course) {
            student->addCourse(*course);
        }
    }
    
    sys.displayStudents();
    sys.displayCourses();
    
    return 0;
}