#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    int id;
    string name;
    Course(int id, const string& name) : id(id), name(name) {}
};

class Student {
public:
    int id;
    string name;
    vector<int> courseIds;
    Student(int id, const string& name) : id(id), name(name) {}
};

class RegistrationSystem {
private:
    vector<Student> students;
    vector<Course> courses;

public:
    void addStudent(int id, const string& name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const string& newName) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                cout << "Student ID: " << student.id << ", Name: " << student.name << endl;
                return;
            }
        }
        cout << "Student not found." << endl;
    }

    void addCourse(int id, const string& name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, const string& newName) {
        for (auto& course : courses) {
            if (course.id == id) {
                course.name = newName;
                break;
            }
        }
    }

    void searchCourse(int id) {
        for (const auto& course : courses) {
            if (course.id == id) {
                cout << "Course ID: " << course.id << ", Name: " << course.name << endl;
                return;
            }
        }
        cout << "Course not found." << endl;
    }

    void displayStudents() {
        for (const auto& student : students) {
            cout << "Student ID: " << student.id << ", Name: " << student.name << endl;
            cout << "Enrolled Courses: ";
            for (const auto& courseId : student.courseIds) {
                cout << courseId << " ";
            }
            cout << endl;
        }
    }

    void displayCourses() {
        for (const auto& course : courses) {
            cout << "Course ID: " << course.id << ", Name: " << course.name << endl;
        }
    }

    void enrollCourse(int studentId, int courseId) {
        for (auto& student : students) {
            if (student.id == studentId) {
                student.courseIds.push_back(courseId);
                break;
            }
        }
    }
};

int main() {
    RegistrationSystem system;

    system.addStudent(1, "John Doe");
    system.addCourse(101, "Math");
    system.enrollCourse(1, 101);

    system.displayStudents();
    system.displayCourses();

    system.searchStudent(1);
    system.searchCourse(101);

    system.updateStudent(1, "Jane Doe");
    system.updateCourse(101, "Advanced Math");

    system.displayStudents();
    system.displayCourses();

    system.deleteStudent(1);
    system.deleteCourse(101);

    system.displayStudents();
    system.displayCourses();

    return 0;
}