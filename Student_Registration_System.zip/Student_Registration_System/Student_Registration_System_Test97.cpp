#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int courseId;
    std::string courseName;

    Course(int id, std::string name) : courseId(id), courseName(name) {}
};

class Student {
public:
    int studentId;
    std::string studentName;
    std::vector<Course> courses;

    Student(int id, std::string name) : studentId(id), studentName(name) {}
};

class RegistrationSystem {
private:
    std::vector<Student> students;

public:
    void addStudent(int id, const std::string& name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentId == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string& newName) {
        for (auto& student : students) {
            if (student.studentId == id) {
                student.studentName = newName;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.studentId == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() const {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.studentId << ", Name: " << student.studentName << std::endl;
            for (const auto& course : student.courses) {
                std::cout << "  Course ID: " << course.courseId 
                          << ", Name: " << course.courseName << std::endl;
            }
        }
    }

    void addCourseToStudent(int studentId, int courseId, const std::string& courseName) {
        Student* student = searchStudent(studentId);
        if (student != nullptr) {
            student->courses.emplace_back(courseId, courseName);
        }
    }

    void removeCourseFromStudent(int studentId, int courseId) {
        Student* student = searchStudent(studentId);
        if (student != nullptr) {
            for (auto it = student->courses.begin(); it != student->courses.end(); ++it) {
                if (it->courseId == courseId) {
                    student->courses.erase(it);
                    break;
                }
            }
        }
    }
};

int main() {
    RegistrationSystem regSystem;
    regSystem.addStudent(1, "John Doe");
    regSystem.addCourseToStudent(1, 100, "Math");
    regSystem.addCourseToStudent(1, 101, "Science");

    regSystem.addStudent(2, "Jane Smith");
    regSystem.addCourseToStudent(2, 102, "Arts");

    std::cout << "Displaying all students:" << std::endl;
    regSystem.displayStudents();

    regSystem.deleteStudent(1);

    std::cout << "Displaying all students after deletion:" << std::endl;
    regSystem.displayStudents();

    regSystem.updateStudent(2, "Jane Doe");

    std::cout << "Displaying all students after update:" << std::endl;
    regSystem.displayStudents();

    return 0;
}