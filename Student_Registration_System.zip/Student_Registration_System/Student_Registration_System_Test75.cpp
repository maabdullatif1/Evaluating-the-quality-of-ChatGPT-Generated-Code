#include <iostream>
#include <vector>
#include <string>

struct Course {
    int id;
    std::string name;
    int credits;
};

struct Student {
    int id;
    std::string name;
    std::vector<Course> courses;
};

std::vector<Student> students;
std::vector<Course> courses;

void addStudent(int id, const std::string& name) {
    students.push_back({id, name, {}});
}

void deleteStudent(int id) {
    for (auto it = students.begin(); it != students.end(); ++it) {
        if (it->id == id) {
            students.erase(it);
            return;
        }
    }
}

void updateStudent(int id, const std::string& newName) {
    for (auto& student : students) {
        if (student.id == id) {
            student.name = newName;
            return;
        }
    }
}

void searchStudent(int id) {
    for (const auto& student : students) {
        if (student.id == id) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << "\n";
            for (const auto& course : student.courses) {
                std::cout << "  Course ID: " << course.id << ", Name: " << course.name << ", Credits: " << course.credits << "\n";
            }
            return;
        }
    }
    std::cout << "Student not found\n";
}

void displayStudents() {
    for (const auto& student : students) {
        std::cout << "Student ID: " << student.id << ", Name: " << student.name << "\n";
        for (const auto& course : student.courses) {
            std::cout << "  Course ID: " << course.id << ", Name: " << course.name << ", Credits: " << course.credits << "\n";
        }
    }
}

void addCourse(int id, const std::string& name, int credits) {
    courses.push_back({id, name, credits});
}

void deleteCourse(int id) {
    for (auto it = courses.begin(); it != courses.end(); ++it) {
        if (it->id == id) {
            courses.erase(it);
            return;
        }
    }
}

void updateCourse(int id, const std::string& newName, int newCredits) {
    for (auto& course : courses) {
        if (course.id == id) {
            course.name = newName;
            course.credits = newCredits;
            return;
        }
    }
}

void searchCourse(int id) {
    for (const auto& course : courses) {
        if (course.id == id) {
            std::cout << "Course ID: " << course.id << ", Name: " << course.name << ", Credits: " << course.credits << "\n";
            return;
        }
    }
    std::cout << "Course not found\n";
}

void displayCourses() {
    for (const auto& course : courses) {
        std::cout << "Course ID: " << course.id << ", Name: " << course.name << ", Credits: " << course.credits << "\n";
    }
}

void assignCourseToStudent(int studentId, int courseId) {
    for (auto& student : students) {
        if (student.id == studentId) {
            for (const auto& course : courses) {
                if (course.id == courseId) {
                    student.courses.push_back(course);
                    return;
                }
            }
        }
    }
}

int main() {
    addStudent(1, "Alice");
    addStudent(2, "Bob");
    addCourse(101, "Math", 3);
    addCourse(102, "Science", 4);
    assignCourseToStudent(1, 101);
    assignCourseToStudent(2, 102);
    updateStudent(2, "Robert");
    updateCourse(101, "Mathematics", 3);
    
    std::cout << "Students:\n";
    displayStudents();
    std::cout << "\nCourses:\n";
    displayCourses();

    std::cout << "\nSearching for student ID 1:\n";
    searchStudent(1);

    std::cout << "\nSearching for course ID 101:\n";
    searchCourse(101);

    deleteCourse(102);
    deleteStudent(2);

    std::cout << "\nAfter deletion:\n";
    std::cout << "Students:\n";
    displayStudents();
    std::cout << "\nCourses:\n";
    displayCourses();

    return 0;
}