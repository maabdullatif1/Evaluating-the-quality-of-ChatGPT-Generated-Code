#include <iostream>
#include <string>
#define MAX_STUDENTS 100
#define MAX_COURSES 50

struct Course {
    int courseId;
    std::string courseName;
};

struct Student {
    int studentId;
    std::string name;
    Course courses[MAX_COURSES];
    int courseCount;
};

Student students[MAX_STUDENTS];
int studentCount = 0;

void addStudent(int id, const std::string& name) {
    if (studentCount < MAX_STUDENTS) {
        students[studentCount++] = { id, name, {}, 0 };
    }
}

void deleteStudent(int id) {
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].studentId == id) {
            for (int j = i; j < studentCount - 1; ++j) {
                students[j] = students[j + 1];
            }
            --studentCount;
            break;
        }
    }
}

void updateStudent(int id, const std::string& newName) {
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].studentId == id) {
            students[i].name = newName;
            break;
        }
    }
}

Student* searchStudent(int id) {
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].studentId == id) {
            return &students[i];
        }
    }
    return nullptr;
}

void displayStudent(const Student& student) {
    std::cout << "ID: " << student.studentId << " Name: " << student.name << std::endl;
}

void displayAllStudents() {
    for (int i = 0; i < studentCount; ++i) {
        displayStudent(students[i]);
    }
}

void addCourse(int studentId, int courseId, const std::string& courseName) {
    Student* student = searchStudent(studentId);
    if (student && student->courseCount < MAX_COURSES) {
        student->courses[student->courseCount++] = { courseId, courseName };
    }
}

void deleteCourse(int studentId, int courseId) {
    Student* student = searchStudent(studentId);
    if (student) {
        for (int i = 0; i < student->courseCount; ++i) {
            if (student->courses[i].courseId == courseId) {
                for (int j = i; j < student->courseCount - 1; ++j) {
                    student->courses[j] = student->courses[j + 1];
                }
                --student->courseCount;
                break;
            }
        }
    }
}

void displayCourses(const Student& student) {
    for (int i = 0; i < student.courseCount; ++i) {
        std::cout << "Course ID: " << student.courses[i].courseId
                  << " Course Name: " << student.courses[i].courseName << std::endl;
    }
}

int main() {
    addStudent(1, "Alice");
    addStudent(2, "Bob");
    displayAllStudents();

    addCourse(1, 101, "Math");
    addCourse(1, 102, "Science");

    Student* student = searchStudent(1);
    if (student) {
        displayCourses(*student);
    }

    deleteCourse(1, 101);
    if (student) {
        displayCourses(*student);
    }

    updateStudent(2, "Charlie");
    displayAllStudents();
    
    deleteStudent(1);
    displayAllStudents();
    return 0;
}