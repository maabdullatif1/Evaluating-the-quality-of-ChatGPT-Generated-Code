#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int courseId;
    std::string courseName;
    
    Course(int id, std::string name) : courseId(id), courseName(name) {}
};

class Student {
public:
    int studentId;
    std::string studentName;
    std::vector<Course> courses;
    
    Student(int id, std::string name) : studentId(id), studentName(name) {}
    
    void addCourse(Course course) {
        courses.push_back(course);
    }
    
    void removeCourse(int courseId) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseId == courseId) {
                courses.erase(it);
                return;
            }
        }
    }
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

public:
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }
    
    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentId == id) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(int id, std::string newName) {
        for (auto& student : students) {
            if (student.studentId == id) {
                student.studentName = newName;
                return;
            }
        }
    }
    
    void addCourse(int id, std::string name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseId == id) {
                courses.erase(it);
                break;
            }
        }
        for (auto& student : students) {
            student.removeCourse(id);
        }
    }
    
    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.studentId == id) {
                return &student;
            }
        }
        return nullptr;
    }
    
    Course* searchCourse(int id) {
        for (auto& course : courses) {
            if (course.courseId == id) {
                return &course;
            }
        }
        return nullptr;
    }
    
    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.studentId
                      << ", Name: " << student.studentName << std::endl;
            for (const auto& course : student.courses) {
                std::cout << "  Enrolled in Course ID: " << course.courseId
                          << ", Name: " << course.courseName << std::endl;
            }
        }
    }
    
    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.courseId
                      << ", Name: " << course.courseName << std::endl;
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(101, "Math");
    system.addCourse(102, "Science");
    
    Student* alice = system.searchStudent(1);
    if (alice) {
        alice->addCourse(Course(101, "Math"));
        alice->addCourse(Course(102, "Science"));
    }
    
    system.displayStudents();
    system.displayCourses();
    
    system.updateStudent(1, "Alice Smith");
    system.deleteCourse(101);
    
    system.displayStudents();
    
    return 0;
}