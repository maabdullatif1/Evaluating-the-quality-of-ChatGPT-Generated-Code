#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Course {
    int id;
    string name;
};

struct Student {
    int id;
    string name;
    vector<Course> courses;
};

class RegistrationSystem {
private:
    vector<Student> students;
    vector<Course> courses;

public:
    void addStudent(int id, const string& name) {
        students.push_back({id, name, {}});
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const string& name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (auto& student : students) {
            if (student.id == id) {
                cout << "Student ID: " << student.id << ", Name: " << student.name << "\n";
                for (auto& course : student.courses) {
                    cout << "Enrolled in Course ID: " << course.id << ", Name: " << course.name << "\n";
                }
                return;
            }
        }
        cout << "Student not found.\n";
    }

    void displayStudents() {
        for (auto& student : students) {
            cout << "Student ID: " << student.id << ", Name: " << student.name << "\n";
        }
    }

    void addCourse(int id, const string& name) {
        courses.push_back({id, name});
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, const string& name) {
        for (auto& course : courses) {
            if (course.id == id) {
                course.name = name;
                break;
            }
        }
    }

    void searchCourse(int id) {
        for (auto& course : courses) {
            if (course.id == id) {
                cout << "Course ID: " << course.id << ", Name: " << course.name << "\n";
                return;
            }
        }
        cout << "Course not found.\n";
    }

    void displayCourses() {
        for (auto& course : courses) {
            cout << "Course ID: " << course.id << ", Name: " << course.name << "\n";
        }
    }

    void enrollStudentInCourse(int studentId, int courseId) {
        for (auto& student : students) {
            if (student.id == studentId) {
                for (auto& course : courses) {
                    if (course.id == courseId) {
                        student.courses.push_back(course);
                        cout << "Student enrolled in course.\n";
                        return;
                    }
                }
            }
        }
        cout << "Enrollment failed.\n";
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(101, "Math");
    system.addCourse(102, "Science");

    system.enrollStudentInCourse(1, 101);
    system.searchStudent(1);

    system.displayStudents();
    system.displayCourses();

    return 0;
}