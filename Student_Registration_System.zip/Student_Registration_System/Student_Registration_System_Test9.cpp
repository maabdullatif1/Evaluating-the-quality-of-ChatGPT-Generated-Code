#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Course {
    int courseID;
    string courseName;
};

struct Student {
    int studentID;
    string studentName;
    vector<Course> courses;
};

vector<Student> students;
vector<Course> courses;

void addStudent(int id, string name) {
    Student newStudent;
    newStudent.studentID = id;
    newStudent.studentName = name;
    students.push_back(newStudent);
}

void addCourse(int id, string name) {
    Course newCourse;
    newCourse.courseID = id;
    newCourse.courseName = name;
    courses.push_back(newCourse);
}

void deleteStudent(int id) {
    for (auto it = students.begin(); it != students.end(); ++it) {
        if (it->studentID == id) {
            students.erase(it);
            break;
        }
    }
}

void deleteCourse(int id) {
    for (auto it = courses.begin(); it != courses.end(); ++it) {
        if (it->courseID == id) {
            courses.erase(it);
            break;
        }
    }
}

void updateStudent(int id, string newName) {
    for (auto& student : students) {
        if (student.studentID == id) {
            student.studentName = newName;
            break;
        }
    }
}

void updateCourse(int id, string newName) {
    for (auto& course : courses) {
        if (course.courseID == id) {
            course.courseName = newName;
            break;
        }
    }
}

Student* searchStudent(int id) {
    for (auto& student : students) {
        if (student.studentID == id) {
            return &student;
        }
    }
    return nullptr;
}

Course* searchCourse(int id) {
    for (auto& course : courses) {
        if (course.courseID == id) {
            return &course;
        }
    }
    return nullptr;
}

void displayStudents() {
    for (const auto& student : students) {
        cout << "ID: " << student.studentID << ", Name: " << student.studentName << ", Courses: ";
        for (const auto& course : student.courses) {
            cout << course.courseName << " ";
        }
        cout << endl;
    }
}

void displayCourses() {
    for (const auto& course : courses) {
        cout << "ID: " << course.courseID << ", Name: " << course.courseName << endl;
    }
}

int main() {
    addStudent(1, "Alice");
    addStudent(2, "Bob");
    addCourse(101, "Mathematics");
    addCourse(102, "Science");

    Student* student = searchStudent(1);
    if (student) student->courses.push_back(courses[0]);

    displayStudents();
    displayCourses();

    updateStudent(1, "Alicia");
    updateCourse(101, "Advanced Mathematics");

    deleteStudent(2);
    deleteCourse(102);

    displayStudents();
    displayCourses();

    return 0;
}