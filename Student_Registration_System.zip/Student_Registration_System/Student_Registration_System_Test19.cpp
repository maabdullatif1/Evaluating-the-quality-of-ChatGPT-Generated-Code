#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    std::string courseID;
    std::string courseName;
    Course(std::string id, std::string name) : courseID(id), courseName(name) {}
};

class Student {
public:
    int studentID;
    std::string studentName;
    std::vector<Course> courses;
    
    Student(int id, std::string name) : studentID(id), studentName(name) {}
    
    void addCourse(const Course& course) {
        courses.push_back(course);
    }

    void removeCourse(const std::string& courseID) {
        for(auto it = courses.begin(); it != courses.end(); ++it) {
            if(it->courseID == courseID) {
                courses.erase(it);
                return;
            }
        }
    }

    void displayCourses() const {
        for(const auto& course : courses) {
            std::cout << course.courseID << ": " << course.courseName << std::endl;
        }
    }
};

class RegistrationSystem {
    std::vector<Student> students;

public:
    void addStudent(int id, const std::string& name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(int id) {
        students.erase(std::remove_if(students.begin(), students.end(),
                      [id](const Student& s) { return s.studentID == id; }),
                      students.end());
    }

    Student* searchStudent(int id) {
        for(auto& student : students) {
            if(student.studentID == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void updateStudentName(int id, const std::string& newName) {
        Student* student = searchStudent(id);
        if(student) {
            student->studentName = newName;
        }
    }

    void displayStudents() const {
        for(const auto& student : students) {
            std::cout << "ID: " << student.studentID << ", Name: " << student.studentName << std::endl;
            student.displayCourses();
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");

    Course course1("CS101", "Introduction to Programming");
    Course course2("MATH101", "Calculus I");

    Student* student = system.searchStudent(1);
    if(student) {
        student->addCourse(course1);
        student->addCourse(course2);
    }

    student = system.searchStudent(2);
    if(student) {
        student->addCourse(course2);
    }

    system.displayStudents();

    system.updateStudentName(1, "Alicia");
    std::cout << "After update:" << std::endl;
    system.displayStudents();

    system.deleteStudent(2);
    std::cout << "After deletion:" << std::endl;
    system.displayStudents();

    return 0;
}