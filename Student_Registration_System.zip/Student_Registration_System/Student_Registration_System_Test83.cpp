#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Course {
    int id;
    string name;
};

struct Student {
    int id;
    string name;
    vector<Course> courses;
};

class RegistrationSystem {
public:
    void addStudent(int id, string name) {
        Student student;
        student.id = id;
        student.name = name;
        students.push_back(student);
    }

    void deleteStudent(int studentId) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == studentId) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(int studentId, string newName) {
        for (auto &student : students) {
            if (student.id == studentId) {
                student.name = newName;
                return;
            }
        }
    }

    Student* searchStudent(int studentId) {
        for (auto &student : students) {
            if (student.id == studentId) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto &student : students) {
            cout << "Student ID: " << student.id << ", Name: " << student.name << endl;
        }
    }

    void addCourseToStudent(int studentId, int courseId, string courseName) {
        for (auto &student : students) {
            if (student.id == studentId) {
                Course course;
                course.id = courseId;
                course.name = courseName;
                student.courses.push_back(course);
                return;
            }
        }
    }

    void displayStudentCourses(int studentId) {
        for (const auto &student : students) {
            if (student.id == studentId) {
                cout << "Courses for Student ID: " << student.id << endl;
                for (const auto &course : student.courses) {
                    cout << "Course ID: " << course.id << ", Name: " << course.name << endl;
                }
                return;
            }
        }
    }

    void deleteCourseFromStudent(int studentId, int courseId) {
        for (auto &student : students) {
            if (student.id == studentId) {
                for (auto it = student.courses.begin(); it != student.courses.end(); ++it) {
                    if (it->id == courseId) {
                        student.courses.erase(it);
                        return;
                    }
                }
            }
        }
    }

private:
    vector<Student> students;
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "John Doe");
    system.addStudent(2, "Jane Smith");

    system.addCourseToStudent(1, 101, "Mathematics");
    system.addCourseToStudent(1, 102, "Physics");
    system.addCourseToStudent(2, 101, "Mathematics");

    system.displayStudents();
    system.displayStudentCourses(1);

    system.updateStudent(1, "Johnathan Doe");
    system.displayStudents();

    system.deleteCourseFromStudent(1, 101);
    system.displayStudentCourses(1);

    system.deleteStudent(2);
    system.displayStudents();

    return 0;
}