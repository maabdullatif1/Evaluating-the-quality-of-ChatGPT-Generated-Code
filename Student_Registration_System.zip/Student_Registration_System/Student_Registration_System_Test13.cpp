#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    string courseID;
    string courseName;

    Course(string id, string name) : courseID(id), courseName(name) {}
};

class Student {
public:
    string studentID;
    string name;
    vector<Course> courses;

    Student(string id, string name) : studentID(id), name(name) {}
    
    void addCourse(const Course &course) {
        courses.push_back(course);
    }
    
    void removeCourse(string courseID) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == courseID) {
                courses.erase(it);
                return;
            }
        }
    }

    void showCourses() {
        for (Course &course : courses) {
            cout << course.courseID << ": " << course.courseName << endl;
        }
    }
};

class System {
public:
    vector<Student> students;
    vector<Course> courses;

    void addStudent(string id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(string id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == id) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(string id, string newName) {
        for (auto &student : students) {
            if (student.studentID == id) {
                student.name = newName;
            }
        }
    }

    void searchStudent(string id) {
        for (const auto &student : students) {
            if (student.studentID == id) {
                cout << "Student ID: " << student.studentID << ", Name: " << student.name << endl;
                student.showCourses();
                return;
            }
        }
        cout << "Student not found." << endl;
    }

    void displayStudents() {
        for (const auto &student : students) {
            cout << "Student ID: " << student.studentID << ", Name: " << student.name << endl;
            student.showCourses();
        }
    }

    void addCourse(string id, string name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(string id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == id) {
                courses.erase(it);
                return;
            }
        }
    }

    void updateCourse(string id, string newName) {
        for (auto &course : courses) {
            if (course.courseID == id) {
                course.courseName = newName;
            }
        }
    }

    void searchCourse(string id) {
        for (const auto &course : courses) {
            if (course.courseID == id) {
                cout << "Course ID: " << course.courseID << ", Course Name: " << course.courseName << endl;
                return;
            }
        }
        cout << "Course not found." << endl;
    }

    void displayCourses() {
        for (const auto &course : courses) {
            cout << "Course ID: " << course.courseID << ", Course Name: " << course.courseName << endl;
        }
    }

    void enrollStudentInCourse(string studentID, string courseID) {
        Course *course = nullptr;
        for (auto &c : courses) {
            if (c.courseID == courseID) {
                course = &c;
                break;
            }
        }
        if (!course) return;

        for (auto &student : students) {
            if (student.studentID == studentID) {
                student.addCourse(*course);
                return;
            }
        }
    }

    void removeStudentFromCourse(string studentID, string courseID) {
        for (auto &student : students) {
            if (student.studentID == studentID) {
                student.removeCourse(courseID);
                return;
            }
        }
    }
};

int main() {
    System sys;

    sys.addStudent("1", "John Doe");
    sys.addStudent("2", "Jane Smith");

    sys.addCourse("101", "Math");
    sys.addCourse("102", "Science");

    sys.enrollStudentInCourse("1", "101");
    sys.enrollStudentInCourse("2", "102");

    sys.displayStudents();
    sys.displayCourses();

    sys.searchStudent("1");
    sys.searchCourse("101");

    sys.updateStudent("1", "Johnathan Doe");
    sys.updateCourse("101", "Advanced Math");

    sys.removeStudentFromCourse("1", "101");
    sys.deleteStudent("2");
    sys.deleteCourse("102");

    sys.displayStudents();
    sys.displayCourses();

    return 0;
}