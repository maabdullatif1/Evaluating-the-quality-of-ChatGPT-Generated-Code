#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Course {
public:
    int courseId;
    string courseName;

    Course(int id, string name) : courseId(id), courseName(name) {}
};

class Student {
public:
    int studentId;
    string studentName;
    vector<Course> courses;

    Student(int id, string name) : studentId(id), studentName(name) {}
};

vector<Student> students;

void addStudent(int studentId, string name) {
    students.push_back(Student(studentId, name));
}

void deleteStudent(int studentId) {
    for (auto it = students.begin(); it != students.end(); ++it) {
        if (it->studentId == studentId) {
            students.erase(it);
            break;
        }
    }
}

void updateStudent(int studentId, string newName) {
    for (auto &student : students) {
        if (student.studentId == studentId) {
            student.studentName = newName;
            break;
        }
    }
}

void addCourseToStudent(int studentId, int courseId, string courseName) {
    for (auto &student : students) {
        if (student.studentId == studentId) {
            student.courses.push_back(Course(courseId, courseName));
            break;
        }
    }
}

void deleteCourseFromStudent(int studentId, int courseId) {
    for (auto &student : students) {
        if (student.studentId == studentId) {
            auto &courses = student.courses;
            for (auto it = courses.begin(); it != courses.end(); ++it) {
                if (it->courseId == courseId) {
                    courses.erase(it);
                    break;
                }
            }
        }
    }
}

Student* searchStudent(int studentId) {
    for (auto &student : students) {
        if (student.studentId == studentId) {
            return &student;
        }
    }
    return nullptr;
}

void displayStudents() {
    for (const auto &student : students) {
        cout << "ID: " << student.studentId << ", Name: " << student.studentName << "\nCourses:\n";
        for (const auto &course : student.courses) {
            cout << "  Course ID: " << course.courseId << ", Course Name: " << course.courseName << "\n";
        }
        cout << endl;
    }
}

int main() {
    addStudent(1, "Alice");
    addStudent(2, "Bob");

    addCourseToStudent(1, 101, "Math");
    addCourseToStudent(1, 102, "Science");
    addCourseToStudent(2, 101, "Math");

    displayStudents();

    updateStudent(1, "Alice Smith");

    displayStudents();

    deleteCourseFromStudent(1, 101);
    displayStudents();

    deleteStudent(2);
    displayStudents();

    if (Student* s = searchStudent(1)) {
        cout << "Found Student: " << s->studentName << endl;
    }

    return 0;
}