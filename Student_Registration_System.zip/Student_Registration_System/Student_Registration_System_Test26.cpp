#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int id;
    std::string name;

    Course(int id, const std::string& name) : id(id), name(name) {}
};

class Student {
public:
    int id;
    std::string name;
    std::vector<Course> courses;

    Student(int id, const std::string& name) : id(id), name(name) {}

    void addCourse(const Course& course) {
        courses.push_back(course);
    }

    void removeCourse(int courseId) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == courseId) {
                courses.erase(it);
                break;
            }
        }
    }
};

class RegistrationSystem {
private:
    std::vector<Student> students;

    Student* findStudent(int studentId) {
        for (auto& student : students) {
            if (student.id == studentId) {
                return &student;
            }
        }
        return nullptr;
    }

public:
    void addStudent(int studentId, const std::string& studentName) {
        students.emplace_back(studentId, studentName);
    }

    void deleteStudent(int studentId) {
        students.erase(std::remove_if(students.begin(), students.end(), [studentId](Student& student) {
            return student.id == studentId;
        }), students.end());
    }

    void updateStudent(int studentId, const std::string& newName) {
        Student* student = findStudent(studentId);
        if (student) {
            student->name = newName;
        }
    }

    void addCourseToStudent(int studentId, const Course& course) {
        Student* student = findStudent(studentId);
        if (student) {
            student->addCourse(course);
        }
    }

    void removeCourseFromStudent(int studentId, int courseId) {
        Student* student = findStudent(studentId);
        if (student) {
            student->removeCourse(courseId);
        }
    }

    void searchStudent(int studentId) {
        Student* student = findStudent(studentId);
        if (student) {
            std::cout << "Student ID: " << student->id << ", Name: " << student->name << std::endl;
            std::cout << "Courses: ";
            for (const auto& course : student->courses) {
                std::cout << course.name << " ";
            }
            std::cout << std::endl;
        } else {
            std::cout << "Student not found" << std::endl;
        }
    }

    void displayAllStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
            std::cout << "Courses: ";
            for (const auto& course : student.courses) {
                std::cout << course.name << " ";
            }
            std::cout << std::endl;
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");

    Course course1(101, "Math");
    Course course2(102, "Science");

    system.addCourseToStudent(1, course1);
    system.addCourseToStudent(1, course2);
    system.addCourseToStudent(2, course2);

    system.displayAllStudents();

    system.searchStudent(1);

    system.updateStudent(1, "Alicia");
    system.removeCourseFromStudent(1, 101);
    system.displayAllStudents();

    system.deleteStudent(2);
    system.displayAllStudents();

    return 0;
}