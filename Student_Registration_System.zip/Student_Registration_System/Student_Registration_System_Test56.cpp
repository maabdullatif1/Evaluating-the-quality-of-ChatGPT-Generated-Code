#include <iostream>
#include <string>
#include <vector>

class Course {
public:
    int id;
    std::string name;
    Course(int id, const std::string& name) : id(id), name(name) {}
};

class Student {
public:
    int id;
    std::string name;
    std::vector<Course> courses;
    Student(int id, const std::string& name) : id(id), name(name) {}
};

class RegistrationSystem {
public:
    void addStudent(int id, const std::string& name);
    void deleteStudent(int id);
    void updateStudent(int id, const std::string& name);
    void searchStudent(int id);
    void displayStudents();
    void addCourse(int id, const std::string& name);
    void deleteCourse(int id);
    void updateCourse(int id, const std::string& name);
    void displayCourses();

private:
    std::vector<Student> students;
    std::vector<Course> courses;
    Student* findStudentById(int id);
    Course* findCourseById(int id);
};

void RegistrationSystem::addStudent(int id, const std::string& name) {
    students.push_back(Student(id, name));
}

void RegistrationSystem::deleteStudent(int id) {
    students.erase(std::remove_if(students.begin(), students.end(), [&](Student& s) { return s.id == id; }), students.end());
}

void RegistrationSystem::updateStudent(int id, const std::string& name) {
    Student* student = findStudentById(id);
    if (student) {
        student->name = name;
    }
}

void RegistrationSystem::searchStudent(int id) {
    Student* student = findStudentById(id);
    if (student) {
        std::cout << "Student ID: " << student->id << " Name: " << student->name << std::endl;
    }
}

void RegistrationSystem::displayStudents() {
    for (const auto& student : students) {
        std::cout << "Student ID: " << student.id << " Name: " << student.name << std::endl;
    }
}

void RegistrationSystem::addCourse(int id, const std::string& name) {
    courses.push_back(Course(id, name));
}

void RegistrationSystem::deleteCourse(int id) {
    courses.erase(std::remove_if(courses.begin(), courses.end(), [&](Course& c) { return c.id == id; }), courses.end());
}

void RegistrationSystem::updateCourse(int id, const std::string& name) {
    Course* course = findCourseById(id);
    if (course) {
        course->name = name;
    }
}

void RegistrationSystem::displayCourses() {
    for (const auto& course : courses) {
        std::cout << "Course ID: " << course.id << " Name: " << course.name << std::endl;
    }
}

Student* RegistrationSystem::findStudentById(int id) {
    for (auto& student : students) {
        if (student.id == id) {
            return &student;
        }
    }
    return nullptr;
}

Course* RegistrationSystem::findCourseById(int id) {
    for (auto& course : courses) {
        if (course.id == id) {
            return &course;
        }
    }
    return nullptr;
}

int main() {
    RegistrationSystem system;
    system.addStudent(1, "John Doe");
    system.addStudent(2, "Jane Smith");
    system.addCourse(101, "Mathematics");
    system.addCourse(102, "Science");

    std::cout << "Displaying Students:" << std::endl;
    system.displayStudents();
    
    std::cout << "Displaying Courses:" << std::endl;
    system.displayCourses();
    
    system.searchStudent(1);
    system.updateStudent(2, "Jane Doe");
    system.deleteCourse(101);
    
    std::cout << "After Updates:" << std::endl;
    std::cout << "Displaying Students:" << std::endl;
    system.displayStudents();
    
    std::cout << "Displaying Courses:" << std::endl;
    system.displayCourses();

    return 0;
}