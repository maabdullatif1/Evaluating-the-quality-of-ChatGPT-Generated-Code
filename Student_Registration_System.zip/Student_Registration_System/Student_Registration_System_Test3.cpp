#include <iostream>
#include <string>

using namespace std;

const int MAX_STUDENTS = 100;
const int MAX_COURSES = 50;

struct Student {
    int id;
    string name;
};

struct Course {
    int id;
    string title;
};

Student students[MAX_STUDENTS];
Course courses[MAX_COURSES];
int studentCount = 0;
int courseCount = 0;

void addStudent(int id, string name) {
    if (studentCount < MAX_STUDENTS) {
        students[studentCount++] = {id, name};
    } else {
        cout << "Student limit reached." << endl;
    }
}

void deleteStudent(int id) {
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].id == id) {
            for (int j = i; j < studentCount - 1; ++j) {
                students[j] = students[j + 1];
            }
            --studentCount;
            break;
        }
    }
}

void updateStudent(int id, string newName) {
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].id == id) {
            students[i].name = newName;
            break;
        }
    }
}

void searchStudent(int id) {
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].id == id) {
            cout << "ID: " << students[i].id << ", Name: " << students[i].name << endl;
            return;
        }
    }
    cout << "Student not found." << endl;
}

void displayStudents() {
    for (int i = 0; i < studentCount; ++i) {
        cout << "ID: " << students[i].id << ", Name: " << students[i].name << endl;
    }
}

void addCourse(int id, string title) {
    if (courseCount < MAX_COURSES) {
        courses[courseCount++] = {id, title};
    } else {
        cout << "Course limit reached." << endl;
    }
}

void deleteCourse(int id) {
    for (int i = 0; i < courseCount; ++i) {
        if (courses[i].id == id) {
            for (int j = i; j < courseCount - 1; ++j) {
                courses[j] = courses[j + 1];
            }
            --courseCount;
            break;
        }
    }
}

void updateCourse(int id, string newTitle) {
    for (int i = 0; i < courseCount; ++i) {
        if (courses[i].id == id) {
            courses[i].title = newTitle;
            break;
        }
    }
}

void searchCourse(int id) {
    for (int i = 0; i < courseCount; ++i) {
        if (courses[i].id == id) {
            cout << "ID: " << courses[i].id << ", Title: " << courses[i].title << endl;
            return;
        }
    }
    cout << "Course not found." << endl;
}

void displayCourses() {
    for (int i = 0; i < courseCount; ++i) {
        cout << "ID: " << courses[i].id << ", Title: " << courses[i].title << endl;
    }
}

int main() {
    addStudent(1, "John Doe");
    addStudent(2, "Jane Smith");
    displayStudents();

    addCourse(101, "Mathematics");
    addCourse(102, "Computer Science");
    displayCourses();

    updateStudent(1, "Johnathan Doe");
    searchStudent(1);

    deleteStudent(2);
    displayStudents();

    updateCourse(101, "Advanced Mathematics");
    searchCourse(101);

    deleteCourse(102);
    displayCourses();
    
    return 0;
}