#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    int courseId;
    string courseName;

    Course(int id, string name) : courseId(id), courseName(name) {}
};

class Student {
public:
    int studentId;
    string studentName;
    vector<Course> courses;

    Student(int id, string name) : studentId(id), studentName(name) {}

    void enrollCourse(const Course& course) {
        courses.push_back(course);
    }

    void dropCourse(int courseId) {
        for (size_t i = 0; i < courses.size(); ++i) {
            if (courses[i].courseId == courseId) {
                courses.erase(courses.begin() + i);
                break;
            }
        }
    }
};

class RegistrationSystem {
private:
    vector<Student> students;
    vector<Course> courses;
    
public:
    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (size_t i = 0; i < students.size(); ++i) {
            if (students[i].studentId == id) {
                students.erase(students.begin() + i);
                break;
            }
        }
    }

    void updateStudent(int id, string name) {
        for (auto& student : students) {
            if (student.studentId == id) {
                student.studentName = name;
                break;
            }
        }
    }

    void displayStudents() {
        for (const auto& student : students) {
            cout << "ID: " << student.studentId << ", Name: " << student.studentName << ", Courses: ";
            for (const auto& course : student.courses) {
                cout << course.courseName << " ";
            }
            cout << endl;
        }
    }

    void addCourse(int id, string name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (size_t i = 0; i < courses.size(); ++i) {
            if (courses[i].courseId == id) {
                courses.erase(courses.begin() + i);
                break;
            }
        }
    }

    void enrollStudentInCourse(int studentId, int courseId) {
        for (auto& student : students) {
            if (student.studentId == studentId) {
                for (const auto& course : courses) {
                    if (course.courseId == courseId) {
                        student.enrollCourse(course);
                        break;
                    }
                }
            }
        }
    }

    void displayCourses() {
        for (const auto& course : courses) {
            cout << "Course ID: " << course.courseId << ", Course Name: " << course.courseName << endl;
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.studentId == id) {
                return &student;
            }
        }
        return nullptr;
    }

    Course* searchCourse(int id) {
        for (auto& course : courses) {
            if (course.courseId == id) {
                return &course;
            }
        }
        return nullptr;
    }
};

int main() {
    RegistrationSystem system;
    
    system.addStudent(1, "John Doe");
    system.addCourse(101, "Mathematics");
    system.enrollStudentInCourse(1, 101);
    
    system.displayStudents();
    system.displayCourses();
    
    return 0;
}