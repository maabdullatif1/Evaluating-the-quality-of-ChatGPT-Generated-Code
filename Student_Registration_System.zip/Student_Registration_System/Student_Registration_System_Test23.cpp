#include <iostream>
#include <vector>
#include <string>

class Course {
private:
    int courseId;
    std::string courseName;
public:
    Course(int id, std::string name) : courseId(id), courseName(name) {}
    int getCourseId() const { return courseId; }
    std::string getCourseName() const { return courseName; }
};

class Student {
private:
    int studentId;
    std::string studentName;
    std::vector<Course> courses;
public:
    Student(int id, std::string name) : studentId(id), studentName(name) {}
    int getStudentId() const { return studentId; }
    std::string getStudentName() const { return studentName; }
    
    void addCourse(const Course& course) { courses.push_back(course); }
    void removeCourse(int courseId) {
        for (size_t i = 0; i < courses.size(); ++i) {
            if (courses[i].getCourseId() == courseId) {
                courses.erase(courses.begin() + i);
                break;
            }
        }
    }
    
    void displayCourses() const {
        std::cout << "Courses for " << studentName << ": ";
        for (const auto& course : courses) {
            std::cout << course.getCourseName() << " ";
        }
        std::cout << std::endl;
    }
};

class StudentRegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;
public:
    void addStudent(int id, std::string name) {
        students.emplace_back(id, name);
    }
    
    void removeStudent(int id) {
        for (size_t i = 0; i < students.size(); ++i) {
            if (students[i].getStudentId() == id) {
                students.erase(students.begin() + i);
                break;
            }
        }
    }
    
    void updateStudent(int id, std::string newName) {
        for (auto& student : students) {
            if (student.getStudentId() == id) {
                student = Student(id, newName);
                break;
            }
        }
    }
    
    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.getStudentId() == id) {
                return &student;
            }
        }
        return nullptr;
    }
    
    void displayStudents() const {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.getStudentId() 
                      << ", Name: " << student.getStudentName() << std::endl;
        }
    }
    
    void addCourse(int id, std::string name) {
        courses.emplace_back(id, name);
    }
    
    void removeCourse(int id) {
        for (size_t i = 0; i < courses.size(); ++i) {
            if (courses[i].getCourseId() == id) {
                courses.erase(courses.begin() + i);
                break;
            }
        }
    }
    
    void displayCourses() const {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.getCourseId() 
                      << ", Name: " << course.getCourseName() << std::endl;
        }
    }
};

int main() {
    StudentRegistrationSystem system;
    
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    
    system.addCourse(101, "Mathematics");
    system.addCourse(102, "Physics");
    
    system.displayStudents();
    system.displayCourses();
    
    Student* student = system.searchStudent(1);
    if (student) {
        student->addCourse({101, "Mathematics"});
        student->displayCourses();
    }

    return 0;
}