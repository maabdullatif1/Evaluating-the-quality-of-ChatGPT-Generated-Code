#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Course {
    int id;
    string name;
};

struct Student {
    int id;
    string name;
    vector<Course> courses;
};

class RegistrationSystem {
    vector<Student> students;
    vector<Course> courses;

    Student* findStudentById(int studentId) {
        for (auto& student : students) {
            if (student.id == studentId) {
                return &student;
            }
        }
        return nullptr;
    }

    Course* findCourseById(int courseId) {
        for (auto& course : courses) {
            if (course.id == courseId) {
                return &course;
            }
        }
        return nullptr;
    }

public:
    void addStudent(int id, string name) {
        students.push_back({id, name});
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string newName) {
        Student* student = findStudentById(id);
        if (student) {
            student->name = newName;
        }
    }

    void searchStudent(int id) {
        Student* student = findStudentById(id);
        if (student) {
            cout << "Student Found: " << student->id << " " << student->name << endl;
        } else {
            cout << "Student Not Found" << endl;
        }
    }

    void displayStudents() {
        for (const auto& student : students) {
            cout << "ID: " << student.id << " Name: " << student.name << endl;
        }
    }

    void addCourse(int id, string name) {
        courses.push_back({id, name});
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, string newName) {
        Course* course = findCourseById(id);
        if (course) {
            course->name = newName;
        }
    }

    void searchCourse(int id) {
        Course* course = findCourseById(id);
        if (course) {
            cout << "Course Found: " << course->id << " " << course->name << endl;
        } else {
            cout << "Course Not Found" << endl;
        }
    }

    void displayCourses() {
        for (const auto& course : courses) {
            cout << "ID: " << course.id << " Name: " << course.name << endl;
        }
    }

    void enrollStudentInCourse(int studentId, int courseId) {
        Student* student = findStudentById(studentId);
        Course* course = findCourseById(courseId);
        if (student && course) {
            student->courses.push_back(*course);
        }
    }

    void displayStudentCourses(int studentId) {
        Student* student = findStudentById(studentId);
        if (student) {
            cout << "Courses for Student ID: " << student->id << " Name: " << student->name << endl;
            for (const auto& course : student->courses) {
                cout << "Course ID: " << course.id << " Course Name: " << course.name << endl;
            }
        }
    }
};

int main() {
    RegistrationSystem system;

    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.displayStudents();

    system.addCourse(101, "Math");
    system.addCourse(102, "Science");
    system.displayCourses();

    system.enrollStudentInCourse(1, 101);
    system.enrollStudentInCourse(1, 102);
    system.displayStudentCourses(1);

    system.searchStudent(2);
    system.updateStudent(2, "Robert");
    system.displayStudents();

    system.searchCourse(101);
    system.updateCourse(101, "Mathematics");
    system.displayCourses();

    system.deleteStudent(1);
    system.displayStudents();

    system.deleteCourse(102);
    system.displayCourses();

    return 0;
}