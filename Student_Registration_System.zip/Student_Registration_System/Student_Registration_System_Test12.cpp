#include <iostream>
#include <string>
#include <vector>

class Course {
public:
    int courseID;
    std::string courseName;

    Course(int id, std::string name) : courseID(id), courseName(name) {}
};

class Student {
public:
    int studentID;
    std::string studentName;
    std::vector<Course> courses;

    Student(int id, std::string name) : studentID(id), studentName(name) {}

    void addCourse(Course course) {
        courses.push_back(course);
    }

    void removeCourse(int courseID) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == courseID) {
                courses.erase(it);
                break;
            }
        }
    }

    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.courseID << ", Course Name: " << course.courseName << std::endl;
        }
    }
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> availableCourses;

    Student* findStudent(int studentID) {
        for (auto& student : students) {
            if (student.studentID == studentID) {
                return &student;
            }
        }
        return nullptr;
    }

    Course* findCourse(int courseID) {
        for (auto& course : availableCourses) {
            if (course.courseID == courseID) {
                return &course;
            }
        }
        return nullptr;
    }

public:
    void addStudent(int studentID, std::string name) {
        students.emplace_back(studentID, name);
    }

    void deleteStudent(int studentID) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == studentID) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int studentID, std::string name) {
        Student* student = findStudent(studentID);
        if (student != nullptr) {
            student->studentName = name;
        }
    }

    void searchStudent(int studentID) {
        Student* student = findStudent(studentID);
        if (student != nullptr) {
            std::cout << "Student ID: " << student->studentID << ", Name: " << student->studentName << std::endl;
            student->displayCourses();
        } else {
            std::cout << "Student not found" << std::endl;
        }
    }

    void displayAllStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.studentID << ", Name: " << student.studentName << std::endl;
            student.displayCourses();
        }
    }

    void addCourse(int courseID, std::string name) {
        availableCourses.emplace_back(courseID, name);
    }

    void deleteCourse(int courseID) {
        for (auto it = availableCourses.begin(); it != availableCourses.end(); ++it) {
            if (it->courseID == courseID) {
                availableCourses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int courseID, std::string name) {
        Course* course = findCourse(courseID);
        if (course != nullptr) {
            course->courseName = name;
        }
    }

    void searchCourse(int courseID) {
        Course* course = findCourse(courseID);
        if (course != nullptr) {
            std::cout << "Course ID: " << course->courseID << ", Name: " << course->courseName << std::endl;
        } else {
            std::cout << "Course not found" << std::endl;
        }
    }

    void displayAllCourses() {
        for (const auto& course : availableCourses) {
            std::cout << "Course ID: " << course.courseID << ", Name: " << course.courseName << std::endl;
        }
    }

    void addStudentToCourse(int studentID, int courseID) {
        Student* student = findStudent(studentID);
        Course* course = findCourse(courseID);
        if (student != nullptr && course != nullptr) {
            student->addCourse(*course);
        }
    }

    void removeStudentFromCourse(int studentID, int courseID) {
        Student* student = findStudent(studentID);
        if (student != nullptr) {
            student->removeCourse(courseID);
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addCourse(101, "Math");
    system.addCourse(102, "Science");

    system.addStudent(1, "Alice");
    system.addStudentToCourse(1, 101);

    system.addStudent(2, "Bob");
    system.addStudentToCourse(2, 102);

    system.displayAllStudents();
    system.displayAllCourses();

    return 0;
}