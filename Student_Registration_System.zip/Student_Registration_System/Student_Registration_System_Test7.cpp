#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Course {
    int courseId;
    string courseName;
};

struct Student {
    int studentId;
    string studentName;
    vector<Course> courses;
};

vector<Student> students;
vector<Course> courses;

void addStudent() {
    Student student;
    cout << "Enter student ID: ";
    cin >> student.studentId;
    cout << "Enter student name: ";
    cin.ignore();
    getline(cin, student.studentName);
    students.push_back(student);
}

void deleteStudent() {
    int studentId;
    cout << "Enter student ID to delete: ";
    cin >> studentId;
    for (auto it = students.begin(); it != students.end(); ++it) {
        if (it->studentId == studentId) {
            students.erase(it);
            cout << "Student deleted." << endl;
            return;
        }
    }
    cout << "Student not found." << endl;
}

void updateStudent() {
    int studentId;
    cout << "Enter student ID to update: ";
    cin >> studentId;
    for (auto& student : students) {
        if (student.studentId == studentId) {
            cout << "Enter new student name: ";
            cin.ignore();
            getline(cin, student.studentName);
            cout << "Student updated." << endl;
            return;
        }
    }
    cout << "Student not found." << endl;
}

void searchStudent() {
    int studentId;
    cout << "Enter student ID to search: ";
    cin >> studentId;
    for (auto& student : students) {
        if (student.studentId == studentId) {
            cout << "Student ID: " << student.studentId << endl;
            cout << "Student Name: " << student.studentName << endl;
            cout << "Courses Enrolled:" << endl;
            for (auto& course : student.courses) {
                cout << "  Course ID: " << course.courseId << ", Course Name: " << course.courseName << endl;
            }
            return;
        }
    }
    cout << "Student not found." << endl;
}

void displayStudents() {
    for (auto& student : students) {
        cout << "Student ID: " << student.studentId << endl;
        cout << "Student Name: " << student.studentName << endl;
        cout << "Courses Enrolled:" << endl;
        for (auto& course : student.courses) {
            cout << "  Course ID: " << course.courseId << ", Course Name: " << course.courseName << endl;
        }
    }
}

void addCourse() {
    Course course;
    cout << "Enter course ID: ";
    cin >> course.courseId;
    cout << "Enter course name: ";
    cin.ignore();
    getline(cin, course.courseName);
    courses.push_back(course);
}

void deleteCourse() {
    int courseId;
    cout << "Enter course ID to delete: ";
    cin >> courseId;
    for (auto it = courses.begin(); it != courses.end(); ++it) {
        if (it->courseId == courseId) {
            courses.erase(it);
            cout << "Course deleted." << endl;
            return;
        }
    }
    cout << "Course not found." << endl;
}

void updateCourse() {
    int courseId;
    cout << "Enter course ID to update: ";
    cin >> courseId;
    for (auto& course : courses) {
        if (course.courseId == courseId) {
            cout << "Enter new course name: ";
            cin.ignore();
            getline(cin, course.courseName);
            cout << "Course updated." << endl;
            return;
        }
    }
    cout << "Course not found." << endl;
}

void searchCourse() {
    int courseId;
    cout << "Enter course ID to search: ";
    cin >> courseId;
    for (auto& course : courses) {
        if (course.courseId == courseId) {
            cout << "Course ID: " << course.courseId << endl;
            cout << "Course Name: " << course.courseName << endl;
            return;
        }
    }
    cout << "Course not found." << endl;
}

void displayCourses() {
    for (auto& course : courses) {
        cout << "Course ID: " << course.courseId << endl;
        cout << "Course Name: " << course.courseName << endl;
    }
}

void enrollStudentInCourse() {
    int studentId, courseId;
    cout << "Enter student ID: ";
    cin >> studentId;
    cout << "Enter course ID to enroll: ";
    cin >> courseId;
    
    for (auto& student : students) {
        if (student.studentId == studentId) {
            for (auto& course : courses) {
                if (course.courseId == courseId) {
                    student.courses.push_back(course);
                    cout << "Course enrolled successfully." << endl;
                    return;
                }
            }
            cout << "Course not found." << endl;
            return;
        }
    }
    cout << "Student not found." << endl;
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Student" << endl
             << "2. Delete Student" << endl
             << "3. Update Student" << endl
             << "4. Search Student" << endl
             << "5. Display Students" << endl
             << "6. Add Course" << endl
             << "7. Delete Course" << endl
             << "8. Update Course" << endl
             << "9. Search Course" << endl
             << "10. Display Courses" << endl
             << "11. Enroll Student in Course" << endl
             << "12. Exit" << endl
             << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addStudent(); break;
            case 2: deleteStudent(); break;
            case 3: updateStudent(); break;
            case 4: searchStudent(); break;
            case 5: displayStudents(); break;
            case 6: addCourse(); break;
            case 7: deleteCourse(); break;
            case 8: updateCourse(); break;
            case 9: searchCourse(); break;
            case 10: displayCourses(); break;
            case 11: enrollStudentInCourse(); break;
            case 12: return 0;
            default: cout << "Invalid choice." << endl;
        }
    }
}