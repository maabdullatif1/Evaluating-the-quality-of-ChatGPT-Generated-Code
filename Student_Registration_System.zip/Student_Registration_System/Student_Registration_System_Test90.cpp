#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int courseId;
    std::string courseName;

    Course(int id, const std::string &name) : courseId(id), courseName(name) {}
};

class Student {
public:
    int studentId;
    std::string studentName;
    std::vector<Course> courses;

    Student(int id, const std::string &name) : studentId(id), studentName(name) {}
};

class RegistrationSystem {
public:
    void addStudent(int id, const std::string &name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentId == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string &newName) {
        for (auto &student : students) {
            if (student.studentId == id) {
                student.studentName = newName;
                break;
            }
        }
    }

    void addCourseToStudent(int studentId, int courseId, const std::string &courseName) {
        for (auto &student : students) {
            if (student.studentId == studentId) {
                student.courses.push_back(Course(courseId, courseName));
                break;
            }
        }
    }

    void deleteCourseFromStudent(int studentId, int courseId) {
        for (auto &student : students) {
            if (student.studentId == studentId) {
                for (auto it = student.courses.begin(); it != student.courses.end(); ++it) {
                    if (it->courseId == courseId) {
                        student.courses.erase(it);
                        break;
                    }
                }
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto &student : students) {
            if (student.studentId == id) {
                std::cout << "Student found: ID = " << student.studentId << ", Name = " << student.studentName << std::endl;
                return;
            }
        }
        std::cout << "Student not found." << std::endl;
    }

    void displayStudents() {
        for (const auto &student : students) {
            std::cout << "Student ID: " << student.studentId << ", Name: " << student.studentName << std::endl;
            for (const auto &course : student.courses) {
                std::cout << "  Course ID: " << course.courseId << ", Name: " << course.courseName << std::endl;
            }
        }
    }

private:
    std::vector<Student> students;
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourseToStudent(1, 101, "Math");
    system.addCourseToStudent(1, 102, "Science");
    system.displayStudents();
    system.searchStudent(1);
    system.updateStudent(1, "Alice B.");
    system.displayStudents();
    system.deleteCourseFromStudent(1, 101);
    system.displayStudents();
    system.deleteStudent(2);
    system.displayStudents();
    return 0;
}