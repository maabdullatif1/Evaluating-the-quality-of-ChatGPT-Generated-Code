#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Student {
public:
    int id;
    string name;
    Student(int id, string name) : id(id), name(name) {}
};

class Course {
public:
    int id;
    string title;
    Course(int id, string title) : id(id), title(title) {}
};

class RegistrationSystem {
public:
    vector<Student> students;
    vector<Course> courses;

    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string newName) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto &student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (auto &student : students) {
            cout << "Student ID: " << student.id << ", Name: " << student.name << endl;
        }
    }

    void addCourse(int id, string title) {
        courses.push_back(Course(id, title));
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, string newTitle) {
        for (auto &course : courses) {
            if (course.id == id) {
                course.title = newTitle;
                break;
            }
        }
    }

    Course* searchCourse(int id) {
        for (auto &course : courses) {
            if (course.id == id) {
                return &course;
            }
        }
        return nullptr;
    }

    void displayCourses() {
        for (auto &course : courses) {
            cout << "Course ID: " << course.id << ", Title: " << course.title << endl;
        }
    }
};

int main() {
    RegistrationSystem rs;

    rs.addStudent(1, "Alice");
    rs.addStudent(2, "Bob");
    rs.displayStudents();

    rs.addCourse(101, "Mathematics");
    rs.addCourse(102, "Physics");
    rs.displayCourses();

    Student *student = rs.searchStudent(1);
    if (student) {
        cout << "Found Student - ID: " << student->id << ", Name: " << student->name << endl;
    }

    rs.updateStudent(2, "Robert");
    rs.displayStudents();

    rs.deleteStudent(1);
    rs.displayStudents();

    rs.updateCourse(101, "Advanced Mathematics");
    rs.displayCourses();

    rs.deleteCourse(102);
    rs.displayCourses();

    Course *course = rs.searchCourse(101);
    if (course) {
        cout << "Found Course - ID: " << course->id << ", Title: " << course->title << endl;
    }

    return 0;
}