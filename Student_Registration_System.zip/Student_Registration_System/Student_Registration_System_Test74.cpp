#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Course {
    int id;
    string name;
};

struct Student {
    int id;
    string name;
    vector<Course> courses;
};

vector<Student> students;
vector<Course> courses;

void addStudent(int id, string name) {
    students.push_back({id, name, {}});
}

void deleteStudent(int id) {
    for (auto it = students.begin(); it != students.end(); ++it) {
        if (it->id == id) {
            students.erase(it);
            break;
        }
    }
}

void updateStudent(int id, string newName) {
    for (auto &student : students) {
        if (student.id == id) {
            student.name = newName;
            break;
        }
    }
}

Student* searchStudent(int id) {
    for (auto &student : students) {
        if (student.id == id) {
            return &student;
        }
    }
    return nullptr;
}

void displayStudents() {
    for (const auto &student : students) {
        cout << "Student ID: " << student.id << ", Name: " << student.name << ", Courses: ";
        for (const auto &course : student.courses) {
            cout << course.name << " ";
        }
        cout << endl;
    }
}

void addCourse(int id, string name) {
    courses.push_back({id, name});
}

void deleteCourse(int id) {
    for (auto it = courses.begin(); it != courses.end(); ++it) {
        if (it->id == id) {
            courses.erase(it);
            break;
        }
    }
}

void updateCourse(int id, string newName) {
    for (auto &course : courses) {
        if (course.id == id) {
            course.name = newName;
            break;
        }
    }
}

Course* searchCourse(int id) {
    for (auto &course : courses) {
        if (course.id == id) {
            return &course;
        }
    }
    return nullptr;
}

void displayCourses() {
    for (const auto &course : courses) {
        cout << "Course ID: " << course.id << ", Name: " << course.name << endl;
    }
}

void enrollStudentInCourse(int studentId, int courseId) {
    Student* student = searchStudent(studentId);
    Course* course = searchCourse(courseId);
    if (student && course) {
        student->courses.push_back(*course);
    }
}

int main() {
    addStudent(1, "Alice");
    addStudent(2, "Bob");
    addCourse(101, "Mathematics");
    addCourse(102, "Science");
    enrollStudentInCourse(1, 101);
    enrollStudentInCourse(1, 102);
    enrollStudentInCourse(2, 101);
    displayStudents();
    displayCourses();
    return 0;
}