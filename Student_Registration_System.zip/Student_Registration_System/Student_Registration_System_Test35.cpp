#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Course {
    int id;
    string name;
};

struct Student {
    int id;
    string name;
    vector<Course> courses;
};

class RegistrationSystem {
private:
    vector<Student> students;
    vector<Course> courses;

    Student* findStudentById(int id) {
        for (auto &student : students) {
            if (student.id == id) return &student;
        }
        return nullptr;
    }

    Course* findCourseById(int id) {
        for (auto &course : courses) {
            if (course.id == id) return &course;
        }
        return nullptr;
    }

public:
    void addStudent(int id, string name) {
        if (!findStudentById(id)) {
            students.push_back({id, name, {}});
        }
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string newName) {
        Student* student = findStudentById(id);
        if (student) {
            student->name = newName;
        }
    }

    Student* searchStudent(int id) {
        return findStudentById(id);
    }

    void displayStudents() {
        for (const auto &student : students) {
            cout << "Student ID: " << student.id << ", Name: " << student.name << "\n";
        }
    }

    void addCourse(int id, string name) {
        if (!findCourseById(id)) {
            courses.push_back({id, name});
        }
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, string newName) {
        Course* course = findCourseById(id);
        if (course) {
            course->name = newName;
        }
    }

    Course* searchCourse(int id) {
        return findCourseById(id);
    }

    void displayCourses() {
        for (const auto &course : courses) {
            cout << "Course ID: " << course.id << ", Name: " << course.name << "\n";
        }
    }

    void enrollStudentInCourse(int studentId, int courseId) {
        Student* student = findStudentById(studentId);
        Course* course = findCourseById(courseId);
        if (student && course) {
            student->courses.push_back(*course);
        }
    }

    void displayStudentCourses(int studentId) {
        Student* student = findStudentById(studentId);
        if (student) {
            cout << "Courses for Student ID: " << student->id << "\n";
            for (const auto &course : student->courses) {
                cout << "Course ID: " << course.id << ", Name: " << course.name << "\n";
            }
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(101, "Math");
    system.addCourse(102, "Science");
    system.enrollStudentInCourse(1, 101);
    system.enrollStudentInCourse(2, 102);
    system.displayStudents();
    system.displayCourses();
    system.displayStudentCourses(1);
    return 0;
}