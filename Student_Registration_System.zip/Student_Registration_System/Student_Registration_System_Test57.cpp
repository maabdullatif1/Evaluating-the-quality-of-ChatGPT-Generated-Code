#include <iostream>
#include <string>
#include <vector>

class Course {
public:
    int id;
    std::string name;
    Course(int id, std::string name) : id(id), name(name) {}
};

class Student {
public:
    int id;
    std::string name;
    std::vector<int> courseIds;
    Student(int id, std::string name) : id(id), name(name) {}
};

class System {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

    Student* findStudentById(int id) {
        for (auto& student : students) {
            if (student.id == id)
                return &student;
        }
        return nullptr;
    }

    Course* findCourseById(int id) {
        for (auto& course : courses) {
            if (course.id == id)
                return &course;
        }
        return nullptr;
    }

public:
    void addStudent(int id, std::string name) {
        if (findStudentById(id) == nullptr)
            students.emplace_back(id, name);
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string newName) {
        Student* student = findStudentById(id);
        if (student != nullptr)
            student->name = newName;
    }

    Student* searchStudent(int id) {
        return findStudentById(id);
    }

    void addCourse(int id, std::string name) {
        if (findCourseById(id) == nullptr)
            courses.emplace_back(id, name);
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, std::string newName) {
        Course* course = findCourseById(id);
        if (course != nullptr)
            course->name = newName;
    }

    Course* searchCourse(int id) {
        return findCourseById(id);
    }

    void displayStudents() {
        for (auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }

    void displayCourses() {
        for (auto& course : courses) {
            std::cout << "Course ID: " << course.id << ", Name: " << course.name << std::endl;
        }
    }
};

int main() {
    System registrationSystem;

    registrationSystem.addStudent(1, "John Doe");
    registrationSystem.addCourse(100, "Math 101");
    registrationSystem.displayStudents();
    registrationSystem.displayCourses();

    return 0;
}