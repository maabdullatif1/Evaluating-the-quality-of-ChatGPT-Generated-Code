#include <iostream>
#include <string>
using namespace std;

const int MAX_STUDENTS = 100;
const int MAX_COURSES = 50;

struct Student {
    int id;
    string name;
    string course;
};

struct Course {
    int id;
    string courseName;
};

Student students[MAX_STUDENTS];
Course courses[MAX_COURSES];

int studentCount = 0;
int courseCount = 0;

void addStudent(int id, string name, string course) {
    if (studentCount < MAX_STUDENTS) {
        students[studentCount].id = id;
        students[studentCount].name = name;
        students[studentCount].course = course;
        studentCount++;
    }
}

void deleteStudent(int id) {
    for (int i = 0; i < studentCount; i++) {
        if (students[i].id == id) {
            for (int j = i; j < studentCount - 1; j++) {
                students[j] = students[j + 1];
            }
            studentCount--;
            break;
        }
    }
}

void updateStudent(int id, string name, string course) {
    for (int i = 0; i < studentCount; i++) {
        if (students[i].id == id) {
            students[i].name = name;
            students[i].course = course;
            break;
        }
    }
}

Student* searchStudent(int id) {
    for (int i = 0; i < studentCount; i++) {
        if (students[i].id == id) {
            return &students[i];
        }
    }
    return nullptr;
}

void displayStudents() {
    for (int i = 0; i < studentCount; i++) {
        cout << "ID: " << students[i].id << ", Name: " << students[i].name << ", Course: " << students[i].course << endl;
    }
}

void addCourse(int id, string courseName) {
    if (courseCount < MAX_COURSES) {
        courses[courseCount].id = id;
        courses[courseCount].courseName = courseName;
        courseCount++;
    }
}

void deleteCourse(int id) {
    for (int i = 0; i < courseCount; i++) {
        if (courses[i].id == id) {
            for (int j = i; j < courseCount - 1; j++) {
                courses[j] = courses[j + 1];
            }
            courseCount--;
            break;
        }
    }
}

void updateCourse(int id, string courseName) {
    for (int i = 0; i < courseCount; i++) {
        if (courses[i].id == id) {
            courses[i].courseName = courseName;
            break;
        }
    }
}

Course* searchCourse(int id) {
    for (int i = 0; i < courseCount; i++) {
        if (courses[i].id == id) {
            return &courses[i];
        }
    }
    return nullptr;
}

void displayCourses() {
    for (int i = 0; i < courseCount; i++) {
        cout << "ID: " << courses[i].id << ", Course Name: " << courses[i].courseName << endl;
    }
}

int main() {
    addStudent(1, "Jane Doe", "Mathematics");
    addCourse(101, "Mathematics");
    displayStudents();
    displayCourses();
    updateStudent(1, "Jane Smith", "Physics");
    displayStudents();
    deleteStudent(1);
    displayStudents();
    return 0;
}