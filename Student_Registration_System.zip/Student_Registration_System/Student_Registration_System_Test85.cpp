#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    int courseId;
    string courseName;
    Course(int id, string name) : courseId(id), courseName(name) {}
};

class Student {
public:
    int studentId;
    string name;
    vector<Course> courses;
    Student(int id, string name) : studentId(id), name(name) {}
};

class RegistrationSystem {
    vector<Student> students;
    vector<Course> courses;
public:
    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }
    
    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentId == id) {
                students.erase(it);
                break;
            }
        }
    }
    
    void updateStudent(int id, string newName) {
        for (auto &student : students) {
            if (student.studentId == id) {
                student.name = newName;
                break;
            }
        }
    }
    
    void searchStudent(int id) {
        for (const auto &student : students) {
            if (student.studentId == id) {
                cout << "Student ID: " << student.studentId << " Name: " << student.name << endl;
                for (const auto &course : student.courses) {
                    cout << "Enrolled in course: " << course.courseName << " (ID: " << course.courseId << ")" << endl;
                }
                break;
            }
        }
    }
    
    void displayStudents() {
        for (const auto &student : students) {
            cout << "Student ID: " << student.studentId << " Name: " << student.name << endl;
        }
    }
    
    void addCourse(int id, string name) {
        courses.push_back(Course(id, name));
    }
    
    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseId == id) {
                courses.erase(it);
                break;
            }
        }
    }
    
    void updateCourse(int id, string newName) {
        for (auto &course : courses) {
            if (course.courseId == id) {
                course.courseName = newName;
                break;
            }
        }
    }
    
    void searchCourse(int id) {
        for (const auto &course : courses) {
            if (course.courseId == id) {
                cout << "Course ID: " << course.courseId << " Course Name: " << course.courseName << endl;
                break;
            }
        }
    }
    
    void displayCourses() {
        for (const auto &course : courses) {
            cout << "Course ID: " << course.courseId << " Course Name: " << course.courseName << endl;
        }
    }
    
    void enrollStudentInCourse(int studentId, int courseId) {
        Student* studentPtr = nullptr;
        Course* coursePtr = nullptr;
        for (auto &student : students) {
            if (student.studentId == studentId) {
                studentPtr = &student;
                break;
            }
        }
        for (auto &course : courses) {
            if (course.courseId == courseId) {
                coursePtr = &course;
                break;
            }
        }
        if (studentPtr && coursePtr) {
            studentPtr->courses.push_back(*coursePtr);
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(100, "Mathematics");
    system.addCourse(200, "Physics");
    system.enrollStudentInCourse(1, 100);
    system.enrollStudentInCourse(2, 200);
    system.enrollStudentInCourse(1, 200);

    system.displayStudents();
    system.displayCourses();
    system.searchStudent(1);
    system.searchCourse(100);
    
    return 0;
}