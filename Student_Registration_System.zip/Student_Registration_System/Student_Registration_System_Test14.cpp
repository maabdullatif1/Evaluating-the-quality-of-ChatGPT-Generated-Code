#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    int courseID;
    string courseName;

    Course(int id, string name) : courseID(id), courseName(name) {}

    void display() {
        cout << "Course ID: " << courseID << ", Course Name: " << courseName << endl;
    }
};

class Student {
public:
    int studentID;
    string studentName;
    vector<int> enrolledCourses;

    Student(int id, string name) : studentID(id), studentName(name) {}

    void enrollCourse(int courseID) {
        enrolledCourses.push_back(courseID);
    }

    void display() {
        cout << "Student ID: " << studentID << ", Student Name: " << studentName << endl;
        cout << "Enrolled Courses: ";
        for (int courseID : enrolledCourses) {
            cout << courseID << " ";
        }
        cout << endl;
    }
};

vector<Student> students;
vector<Course> courses;

void addStudent(int id, string name) {
    students.push_back(Student(id, name));
}

void deleteStudent(int id) {
    for (auto it = students.begin(); it != students.end(); ++it) {
        if (it->studentID == id) {
            students.erase(it);
            break;
        }
    }
}

void updateStudent(int id, string newName) {
    for (auto &student : students) {
        if (student.studentID == id) {
            student.studentName = newName;
            break;
        }
    }
}

void searchStudent(int id) {
    for (auto &student : students) {
        if (student.studentID == id) {
            student.display();
            return;
        }
    }
    cout << "Student not found" << endl;
}

void displayStudents() {
    for (auto &student : students) {
        student.display();
    }
}

void addCourse(int id, string name) {
    courses.push_back(Course(id, name));
}

void deleteCourse(int id) {
    for (auto it = courses.begin(); it != courses.end(); ++it) {
        if (it->courseID == id) {
            courses.erase(it);
            break;
        }
    }
}

void updateCourse(int id, string newName) {
    for (auto &course : courses) {
        if (course.courseID == id) {
            course.courseName = newName;
            break;
        }
    }
}

void searchCourse(int id) {
    for (auto &course : courses) {
        if (course.courseID == id) {
            course.display();
            return;
        }
    }
    cout << "Course not found" << endl;
}

void displayCourses() {
    for (auto &course : courses) {
        course.display();
    }
}

int main() {
    addStudent(1, "John Doe");
    addStudent(2, "Jane Smith");

    addCourse(101, "Mathematics");
    addCourse(102, "Physics");

    students[0].enrollCourse(101);
    students[1].enrollCourse(102);

    cout << "All Students:" << endl;
    displayStudents();

    cout << "All Courses:" << endl;
    displayCourses();

    return 0;
}