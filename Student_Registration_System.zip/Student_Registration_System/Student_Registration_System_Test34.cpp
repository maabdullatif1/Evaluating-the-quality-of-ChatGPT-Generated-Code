#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    string courseID;
    string courseName;

    Course(string id, string name) : courseID(id), courseName(name) {}
};

class Student {
public:
    string studentID;
    string studentName;
    vector<Course> courses;

    Student(string id, string name) : studentID(id), studentName(name) {}

    void addCourse(const Course& course) {
        courses.push_back(course);
    }

    void deleteCourse(const string& courseID) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == courseID) {
                courses.erase(it);
                break;
            }
        }
    }
};

class StudentRegistrationSystem {
private:
    vector<Student> students;

public:
    void addStudent(const string& id, const string& name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(const string& id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(const string& id, const string& name) {
        for (auto& student : students) {
            if (student.studentID == id) {
                student.studentName = name;
                break;
            }
        }
    }

    Student* searchStudent(const string& id) {
        for (auto& student : students) {
            if (student.studentID == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            cout << "ID: " << student.studentID << ", Name: " << student.studentName << endl;
            for (const auto& course : student.courses) {
                cout << "   Course ID: " << course.courseID << ", Name: " << course.courseName << endl;
            }
        }
    }

    void addCourseToStudent(const string& studentID, const string& courseID, const string& courseName) {
        Student* student = searchStudent(studentID);
        if (student) {
            student->addCourse(Course(courseID, courseName));
        }
    }

    void deleteCourseFromStudent(const string& studentID, const string& courseID) {
        Student* student = searchStudent(studentID);
        if (student) {
            student->deleteCourse(courseID);
        }
    }
};

int main() {
    StudentRegistrationSystem system;
    system.addStudent("001", "John Doe");
    system.addStudent("002", "Jane Smith");
    system.addCourseToStudent("001", "CS101", "Introduction to Computer Science");
    system.addCourseToStudent("001", "MATH101", "Calculus I");
    system.displayStudents();
    system.updateStudent("001", "Johnathan Doe");
    system.deleteCourseFromStudent("001", "MATH101");
    system.displayStudents();
    system.deleteStudent("001");
    system.displayStudents();
    return 0;
}