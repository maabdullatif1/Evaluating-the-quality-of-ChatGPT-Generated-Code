#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    int courseID;
    string courseName;
    Course(int id, string name) : courseID(id), courseName(name) {}
};

class Student {
public:
    int studentID;
    string studentName;
    vector<Course> courses;
    Student(int id, string name) : studentID(id), studentName(name) {}
};

class StudentRegistrationSystem {
private:
    vector<Student> students;
    vector<Course> courses;
public:
    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string name) {
        for (auto &student : students) {
            if (student.studentID == id) {
                student.studentName = name;
                break;
            }
        }
    }

    void addCourse(int id, string name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, string name) {
        for (auto &course : courses) {
            if (course.courseID == id) {
                course.courseName = name;
                break;
            }
        }
    }

    void enrollStudentInCourse(int studentID, int courseID) {
        for (auto &student : students) {
            if (student.studentID == studentID) {
                for (auto &course : courses) {
                    if (course.courseID == courseID) {
                        student.courses.push_back(course);
                        break;
                    }
                }
                break;
            }
        }
    }

    void displayStudents() {
        for (const auto &student : students) {
            cout << "ID: " << student.studentID << ", Name: " << student.studentName << endl;
            for (const auto &course : student.courses) {
                cout << "  Course ID: " << course.courseID << ", Course Name: " << course.courseName << endl;
            }
        }
    }

    void displayCourses() {
        for (const auto &course : courses) {
            cout << "Course ID: " << course.courseID << ", Course Name: " << course.courseName << endl;
        }
    }

    Student* searchStudent(int id) {
        for (auto &student : students) {
            if (student.studentID == id) {
                return &student;
            }
        }
        return nullptr;
    }

    Course* searchCourse(int id) {
        for (auto &course : courses) {
            if (course.courseID == id) {
                return &course;
            }
        }
        return nullptr;
    }
};

int main() {
    StudentRegistrationSystem sys;
    sys.addStudent(1, "John Doe");
    sys.addStudent(2, "Jane Smith");
    sys.addCourse(1, "Math");
    sys.addCourse(2, "Science");
    sys.enrollStudentInCourse(1, 1);
    sys.enrollStudentInCourse(1, 2);
    sys.displayStudents();
    sys.displayCourses();
    sys.updateStudent(1, "Johnathan Doe");
    sys.updateCourse(2, "Biology");
    sys.displayStudents();
    sys.displayCourses();
    sys.deleteStudent(2);
    sys.deleteCourse(1);
    sys.displayStudents();
    sys.displayCourses();
    return 0;
}