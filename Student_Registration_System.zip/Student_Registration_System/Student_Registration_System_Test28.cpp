#include <iostream>
#include <string>
using namespace std;

struct Student {
    int id;
    string name;
};

struct Course {
    int id;
    string title;
};

Student students[100];
Course courses[100];
int studentCount = 0;
int courseCount = 0;

void addStudent(int id, const string& name) {
    students[studentCount++] = {id, name};
}

void deleteStudent(int id) {
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].id == id) {
            for (int j = i; j < studentCount - 1; ++j) {
                students[j] = students[j + 1];
            }
            --studentCount;
            return;
        }
    }
}

void updateStudent(int id, const string& name) {
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].id == id) {
            students[i].name = name;
            return;
        }
    }
}

void searchStudent(int id) {
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].id == id) {
            cout << "Student ID: " << students[i].id << ", Name: " << students[i].name << endl;
            return;
        }
    }
    cout << "Student not found" << endl;
}

void displayStudents() {
    for (int i = 0; i < studentCount; ++i) {
        cout << "Student ID: " << students[i].id << ", Name: " << students[i].name << endl;
    }
}

void addCourse(int id, const string& title) {
    courses[courseCount++] = {id, title};
}

void deleteCourse(int id) {
    for (int i = 0; i < courseCount; ++i) {
        if (courses[i].id == id) {
            for (int j = i; j < courseCount - 1; ++j) {
                courses[j] = courses[j + 1];
            }
            --courseCount;
            return;
        }
    }
}

void updateCourse(int id, const string& title) {
    for (int i = 0; i < courseCount; ++i) {
        if (courses[i].id == id) {
            courses[i].title = title;
            return;
        }
    }
}

void searchCourse(int id) {
    for (int i = 0; i < courseCount; ++i) {
        if (courses[i].id == id) {
            cout << "Course ID: " << courses[i].id << ", Title: " << courses[i].title << endl;
            return;
        }
    }
    cout << "Course not found" << endl;
}

void displayCourses() {
    for (int i = 0; i < courseCount; ++i) {
        cout << "Course ID: " << courses[i].id << ", Title: " << courses[i].title << endl;
    }
}

int main() {
    addStudent(1, "John Doe");
    addStudent(2, "Jane Smith");
    addCourse(101, "Mathematics");
    addCourse(102, "Physics");
    displayStudents();
    displayCourses();
    searchStudent(1);
    searchCourse(101);
    updateStudent(1, "John Michael Doe");
    updateCourse(101, "Advanced Mathematics");
    deleteStudent(2);
    deleteCourse(102);
    displayStudents();
    displayCourses();
    return 0;
}