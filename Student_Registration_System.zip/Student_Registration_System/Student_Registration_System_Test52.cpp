#include <iostream>
#include <string>
#include <vector>

class Course {
public:
    int courseID;
    std::string courseName;

    Course(int id, const std::string& name) : courseID(id), courseName(name) {}
};

class Student {
public:
    int studentID;
    std::string studentName;
    std::vector<Course> courses;

    Student(int id, const std::string& name) : studentID(id), studentName(name) {}

    void addCourse(const Course& course) {
        courses.push_back(course);
    }

    void removeCourse(int courseID) {
        for (size_t i = 0; i < courses.size(); ++i) {
            if (courses[i].courseID == courseID) {
                courses.erase(courses.begin() + i);
                break;
            }
        }
    }

    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.courseID << " Name: " << course.courseName << std::endl;
        }
    }
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

public:
    void addStudent(int id, const std::string& name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (size_t i = 0; i < students.size(); ++i) {
            if (students[i].studentID == id) {
                students.erase(students.begin() + i);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string& newName) {
        for (auto& student : students) {
            if (student.studentID == id) {
                student.studentName = newName;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.studentID == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.studentID << " Name: " << student.studentName << std::endl;
            student.displayCourses();
        }
    }

    void addCourse(int id, const std::string& name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (size_t i = 0; i < courses.size(); ++i) {
            if (courses[i].courseID == id) {
                courses.erase(courses.begin() + i);
                break;
            }
        }
    }

    Course* searchCourse(int id) {
        for (auto& course : courses) {
            if (course.courseID == id) {
                return &course;
            }
        }
        return nullptr;
    }

    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.courseID << " Name: " << course.courseName << std::endl;
        }
    }
};

int main() {
    RegistrationSystem system;
    
    system.addStudent(1, "John Doe");
    system.addStudent(2, "Jane Smith");
    
    system.addCourse(101, "Mathematics");
    system.addCourse(102, "Physics");
    
    Student* student = system.searchStudent(1);
    if(student) {
        student->addCourse(Course(101, "Mathematics"));
    }
    
    system.displayStudents();
    system.displayCourses();
    
    return 0;
}