#include <iostream>
#include <string>
using namespace std;

const int MAX_STUDENTS = 100;
const int MAX_COURSES = 50;

struct Student {
    int id;
    string name;
    string course;
};

struct Course {
    int id;
    string name;
};

Student students[MAX_STUDENTS];
Course courses[MAX_COURSES];
int studentCount = 0;
int courseCount = 0;

void addStudent(int id, string name, string course) {
    if (studentCount >= MAX_STUDENTS) return;
    students[studentCount].id = id;
    students[studentCount].name = name;
    students[studentCount].course = course;
    studentCount++;
}

void deleteStudent(int id) {
    for (int i = 0; i < studentCount; i++) {
        if (students[i].id == id) {
            for (int j = i; j < studentCount - 1; j++) {
                students[j] = students[j + 1];
            }
            studentCount--;
            return;
        }
    }
}

void updateStudent(int id, string name, string course) {
    for (int i = 0; i < studentCount; i++) {
        if (students[i].id == id) {
            students[i].name = name;
            students[i].course = course;
            return;
        }
    }
}

Student* searchStudent(int id) {
    for (int i = 0; i < studentCount; i++) {
        if (students[i].id == id) {
            return &students[i];
        }
    }
    return NULL;
}

void displayStudents() {
    for (int i = 0; i < studentCount; i++) {
        cout << "ID: " << students[i].id << ", Name: " << students[i].name
             << ", Course: " << students[i].course << endl;
    }
}

void addCourse(int id, string name) {
    if (courseCount >= MAX_COURSES) return;
    courses[courseCount].id = id;
    courses[courseCount].name = name;
    courseCount++;
}

void deleteCourse(int id) {
    for (int i = 0; i < courseCount; i++) {
        if (courses[i].id == id) {
            for (int j = i; j < courseCount - 1; j++) {
                courses[j] = courses[j + 1];
            }
            courseCount--;
            return;
        }
    }
}

void updateCourse(int id, string name) {
    for (int i = 0; i < courseCount; i++) {
        if (courses[i].id == id) {
            courses[i].name = name;
            return;
        }
    }
}

Course* searchCourse(int id) {
    for (int i = 0; i < courseCount; i++) {
        if (courses[i].id == id) {
            return &courses[i];
        }
    }
    return NULL;
}

void displayCourses() {
    for (int i = 0; i < courseCount; i++) {
        cout << "ID: " << courses[i].id << ", Name: " << courses[i].name << endl;
    }
}

int main() {
    addStudent(1, "Alice", "Math");
    addStudent(2, "Bob", "Physics");
    displayStudents();
    
    addCourse(101, "Math");
    addCourse(102, "Physics");
    displayCourses();
    
    updateStudent(2, "Bob", "Chemistry");
    displayStudents();
    
    updateCourse(102, "Advanced Physics");
    displayCourses();
    
    deleteStudent(1);
    displayStudents();
    
    deleteCourse(101);
    displayCourses();
    
    Student* student = searchStudent(2);
    if (student) {
        cout << "Found: ID: " << student->id << ", Name: " << student->name
             << ", Course: " << student->course << endl;
    }
    
    Course* course = searchCourse(102);
    if (course) {
        cout << "Found: ID: " << course->id << ", Name: " << course->name << endl;
    }
    
    return 0;
}