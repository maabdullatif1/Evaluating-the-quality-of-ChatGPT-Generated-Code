#include <iostream>
#include <string>

#define MAX_ENTRIES 100

struct Student {
    std::string id;
    std::string name;
};

struct Course {
    std::string code;
    std::string title;
};

struct RegistrationSystem {
    Student students[MAX_ENTRIES];
    Course courses[MAX_ENTRIES];
    int studentCount = 0;
    int courseCount = 0;

    void addStudent(const std::string& id, const std::string& name) {
        if (studentCount < MAX_ENTRIES) {
            students[studentCount++] = {id, name};
        } else {
            std::cout << "Student list full" << std::endl;
        }
    }

    void deleteStudent(const std::string& id) {
        for (int i = 0; i < studentCount; ++i) {
            if (students[i].id == id) {
                students[i] = students[--studentCount];
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }

    void updateStudent(const std::string& id, const std::string& newName) {
        for (int i = 0; i < studentCount; ++i) {
            if (students[i].id == id) {
                students[i].name = newName;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }

    void searchStudent(const std::string& id) {
        for (int i = 0; i < studentCount; ++i) {
            if (students[i].id == id) {
                std::cout << "Student: " << students[i].name << std::endl;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }

    void displayStudents() {
        for (int i = 0; i < studentCount; ++i) {
            std::cout << "ID: " << students[i].id << ", Name: " << students[i].name << std::endl;
        }
    }

    void addCourse(const std::string& code, const std::string& title) {
        if (courseCount < MAX_ENTRIES) {
            courses[courseCount++] = {code, title};
        } else {
            std::cout << "Course list full" << std::endl;
        }
    }

    void deleteCourse(const std::string& code) {
        for (int i = 0; i < courseCount; ++i) {
            if (courses[i].code == code) {
                courses[i] = courses[--courseCount];
                return;
            }
        }
        std::cout << "Course not found" << std::endl;
    }

    void updateCourse(const std::string& code, const std::string& newTitle) {
        for (int i = 0; i < courseCount; ++i) {
            if (courses[i].code == code) {
                courses[i].title = newTitle;
                return;
            }
        }
        std::cout << "Course not found" << std::endl;
    }

    void searchCourse(const std::string& code) {
        for (int i = 0; i < courseCount; ++i) {
            if (courses[i].code == code) {
                std::cout << "Course: " << courses[i].title << std::endl;
                return;
            }
        }
        std::cout << "Course not found" << std::endl;
    }

    void displayCourses() {
        for (int i = 0; i < courseCount; ++i) {
            std::cout << "Code: " << courses[i].code << ", Title: " << courses[i].title << std::endl;
        }
    }
};

int main() {
    RegistrationSystem regSystem;

    regSystem.addStudent("001", "John Doe");
    regSystem.addStudent("002", "Jane Smith");
    
    regSystem.displayStudents();
    
    regSystem.addCourse("CS101", "Introduction to Computer Science");
    regSystem.addCourse("MATH123", "Calculus I");
    
    regSystem.displayCourses();

    regSystem.searchStudent("001");
    regSystem.searchCourse("CS101");

    regSystem.updateStudent("001", "Johnathan Doe");
    regSystem.updateCourse("CS101", "Intro to CS");

    regSystem.displayStudents();
    regSystem.displayCourses();

    regSystem.deleteStudent("002");
    regSystem.deleteCourse("MATH123");

    regSystem.displayStudents();
    regSystem.displayCourses();

    return 0;
}