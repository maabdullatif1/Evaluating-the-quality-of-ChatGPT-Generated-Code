#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int courseID;
    std::string courseName;

    Course(int id, const std::string &name) : courseID(id), courseName(name) {}
};

class Student {
public:
    int studentID;
    std::string studentName;
    std::vector<Course> courses;

    Student(int id, const std::string &name) : studentID(id), studentName(name) {}

    void addCourse(const Course &course) {
        courses.push_back(course);
    }

    void deleteCourse(int courseID) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == courseID) {
                courses.erase(it);
                break;
            }
        }
    }
};

class RegistrationSystem {
    std::vector<Student> students;
    std::vector<Course> courses;

public:
    void addStudent(int id, const std::string &name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string &newName) {
        for (auto &student : students) {
            if (student.studentID == id) {
                student.studentName = newName;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto &student : students) {
            if (student.studentID == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto &student : students) {
            std::cout << "ID: " << student.studentID << ", Name: " << student.studentName << std::endl;
        }
    }

    void addCourse(int id, const std::string &name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, const std::string &newName) {
        for (auto &course : courses) {
            if (course.courseID == id) {
                course.courseName = newName;
                break;
            }
        }
    }

    Course* searchCourse(int id) {
        for (auto &course : courses) {
            if (course.courseID == id) {
                return &course;
            }
        }
        return nullptr;
    }

    void displayCourses() {
        for (const auto &course : courses) {
            std::cout << "ID: " << course.courseID << ", Name: " << course.courseName << std::endl;
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "John Doe");
    system.addStudent(2, "Jane Smith");
    system.displayStudents();
    system.addCourse(101, "Math");
    system.addCourse(102, "Science");
    system.displayCourses();
    Student* s = system.searchStudent(1);
    if (s) {
        Course* c = system.searchCourse(101);
        if (c) {
            s->addCourse(*c);
        }
    }
    return 0;
}