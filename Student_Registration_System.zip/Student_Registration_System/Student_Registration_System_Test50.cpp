#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int courseID;
    std::string courseName;

    Course(int id, std::string name) : courseID(id), courseName(name) {}
};

class Student {
public:
    int studentID;
    std::string studentName;
    std::vector<Course> courses;

    Student(int id, std::string name) : studentID(id), studentName(name) {}

    void addCourse(Course course) {
        courses.push_back(course);
    }
};

class RegistrationSystem {
    std::vector<Student> students;

public:
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string newName) {
        for (auto& student : students) {
            if (student.studentID == id) {
                student.studentName = newName;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.studentID == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.studentID << ", Name: " << student.studentName << "\n";
            for (const auto& course : student.courses) {
                std::cout << "\tCourse ID: " << course.courseID << ", Name: " << course.courseName << "\n";
            }
        }
    }

    void addCourseToStudent(int studentID, int courseID, std::string courseName) {
        Student* student = searchStudent(studentID);
        if (student != nullptr) {
            student->addCourse(Course(courseID, courseName));
        }
    }
};

int main() {
    RegistrationSystem system;

    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");

    system.addCourseToStudent(1, 101, "Mathematics");
    system.addCourseToStudent(1, 102, "Physics");

    system.addCourseToStudent(2, 101, "Mathematics");

    system.displayStudents();

    system.updateStudent(1, "Alicia");
    system.displayStudents();

    system.deleteStudent(2);
    system.displayStudents();

    return 0;
}