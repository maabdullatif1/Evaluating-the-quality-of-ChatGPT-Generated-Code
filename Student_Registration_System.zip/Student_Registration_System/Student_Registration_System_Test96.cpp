#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Course {
    int courseID;
    string courseName;
    int credits;
};

struct Student {
    int studentID;
    string studentName;
    vector<int> courseIDs;
};

class RegistrationSystem {
private:
    vector<Student> students;
    vector<Course> courses;

public:
    void addStudent(int studentID, const string &studentName) {
        Student student = {studentID, studentName, {}};
        students.push_back(student);
    }

    void deleteStudent(int studentID) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == studentID) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int studentID, const string &studentName) {
        for (auto &student : students) {
            if (student.studentID == studentID) {
                student.studentName = studentName;
                break;
            }
        }
    }

    void searchStudent(int studentID) {
        for (const auto &student : students) {
            if (student.studentID == studentID) {
                cout << "Student ID: " << student.studentID << " Name: " << student.studentName << endl;
                cout << "Courses Enrolled: ";
                for (const auto &cid : student.courseIDs) {
                    for (const auto &course : courses) {
                        if (course.courseID == cid) {
                            cout << course.courseName << " ";
                        }
                    }
                }
                cout << endl;
                return;
            }
        }
        cout << "Student not found." << endl;
    }

    void displayStudents() {
        for (const auto &student : students) {
            cout << "Student ID: " << student.studentID << " Name: " << student.studentName << endl;
        }
    }

    void addCourse(int courseID, const string &courseName, int credits) {
        Course course = {courseID, courseName, credits};
        courses.push_back(course);
    }

    void deleteCourse(int courseID) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == courseID) {
                courses.erase(it);
                break;
            }
        }

        for (auto &student : students) {
            for (auto it = student.courseIDs.begin(); it != student.courseIDs.end(); ++it) {
                if (*it == courseID) {
                    student.courseIDs.erase(it);
                    break;
                }
            }
        }
    }

    void updateCourse(int courseID, const string &courseName, int credits) {
        for (auto &course : courses) {
            if (course.courseID == courseID) {
                course.courseName = courseName;
                course.credits = credits;
                break;
            }
        }
    }

    void searchCourse(int courseID) {
        for (const auto &course : courses) {
            if (course.courseID == courseID) {
                cout << "Course ID: " << course.courseID << " Name: " << course.courseName << " Credits: " << course.credits << endl;
                return;
            }
        }
        cout << "Course not found." << endl;
    }

    void displayCourses() {
        for (const auto &course : courses) {
            cout << "Course ID: " << course.courseID << " Name: " << course.courseName << " Credits: " << course.credits << endl;
        }
    }

    void enrollCourse(int studentID, int courseID) {
        for (auto &student : students) {
            if (student.studentID == studentID) {
                student.courseIDs.push_back(courseID);
                break;
            }
        }
    }
};

int main() {
    RegistrationSystem system;
    
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(101, "Math", 3);
    system.addCourse(102, "Science", 4);
    
    system.enrollCourse(1, 101);
    
    system.displayStudents();
    system.displayCourses();
    system.searchStudent(1);
    system.searchCourse(102);
    
    return 0;
}