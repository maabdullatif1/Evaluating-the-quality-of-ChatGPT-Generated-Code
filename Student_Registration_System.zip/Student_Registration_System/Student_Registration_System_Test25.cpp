#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    int courseID;
    string courseName;
    
    Course(int id, const string& name) : courseID(id), courseName(name) {}
};

class Student {
public:
    int studentID;
    string studentName;
    vector<Course> courses;
    
    Student(int id, const string& name) : studentID(id), studentName(name) {}
    
    void addCourse(const Course& course) {
        courses.push_back(course);
    }
    
    void removeCourse(int courseID) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == courseID) {
                courses.erase(it);
                break;
            }
        }
    }
};

class RegistrationSystem {
private:
    vector<Student> students;
    vector<Course> courses;
    
public:
    void addStudent(int studentID, const string& studentName) {
        students.push_back(Student(studentID, studentName));
    }
    
    void deleteStudent(int studentID) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == studentID) {
                students.erase(it);
                break;
            }
        }
    }
    
    void updateStudent(int studentID, const string& newStudentName) {
        for (auto& student : students) {
            if (student.studentID == studentID) {
                student.studentName = newStudentName;
            }
        }
    }
    
    Student* searchStudent(int studentID) {
        for (auto& student : students) {
            if (student.studentID == studentID) {
                return &student;
            }
        }
        return nullptr;
    }
    
    void displayStudents() {
        for (const auto& student : students) {
            cout << "Student ID: " << student.studentID << ", Name: " << student.studentName << endl;
        }
    }
    
    void addCourse(int courseID, const string& courseName) {
        courses.push_back(Course(courseID, courseName));
    }
    
    void deleteCourse(int courseID) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == courseID) {
                courses.erase(it);
                break;
            }
        }
    }
    
    void updateCourse(int courseID, const string& newCourseName) {
        for (auto& course : courses) {
            if (course.courseID == courseID) {
                course.courseName = newCourseName;
            }
        }
    }
    
    Course* searchCourse(int courseID) {
        for (auto& course : courses) {
            if (course.courseID == courseID) {
                return &course;
            }
        }
        return nullptr;
    }
    
    void displayCourses() {
        for (const auto& course : courses) {
            cout << "Course ID: " << course.courseID << ", Name: " << course.courseName << endl;
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(101, "Mathematics");
    system.addCourse(102, "History");
    
    Student* student = system.searchStudent(1);
    if (student) {
        student->addCourse(*system.searchCourse(101));
    }
    
    system.displayStudents();
    system.displayCourses();
}