#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int id;
    std::string name;

    Course(int id, std::string name) : id(id), name(name) {}
};

class Student {
public:
    int id;
    std::string name;
    std::vector<Course> courses;

    Student(int id, std::string name) : id(id), name(name) {}
    
    void addCourse(const Course& course) {
        courses.push_back(course);
    }
    
    void removeCourse(int courseId) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == courseId) {
                courses.erase(it);
                break;
            }
        }
    }
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

    Course* findCourse(int id) {
        for (auto& course : courses) {
            if (course.id == id) {
                return &course;
            }
        }
        return nullptr;
    }

    Student* findStudent(int id) {
        for (auto& student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

public:
    void addStudent(int id, std::string name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string newName) {
        Student* student = findStudent(id);
        if (student) {
            student->name = newName;
        }
    }

    void addCourse(int id, std::string name) {
        courses.emplace_back(id, name);
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, std::string newName) {
        Course* course = findCourse(id);
        if (course) {
            course->name = newName;
        }
    }

    void enrollStudentInCourse(int studentId, int courseId) {
        Student* student = findStudent(studentId);
        Course* course = findCourse(courseId);
        if (student && course) {
            student->addCourse(*course);
        }
    }

    void unenrollStudentFromCourse(int studentId, int courseId) {
        Student* student = findStudent(studentId);
        if (student) {
            student->removeCourse(courseId);
        }
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << "\n";
            for (const auto& course : student.courses) {
                std::cout << "  Enrolled in Course ID: " << course.id << ", Name: " << course.name << "\n";
            }
        }
    }

    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.id << ", Name: " << course.name << "\n";
        }
    }

    void searchStudent(int id) {
        Student* student = findStudent(id);
        if (student) {
            std::cout << "Found Student ID: " << student->id << ", Name: " << student->name << "\n";
        } else {
            std::cout << "Student not found\n";
        }
    }

    void searchCourse(int id) {
        Course* course = findCourse(id);
        if (course) {
            std::cout << "Found Course ID: " << course->id << ", Name: " << course->name << "\n";
        } else {
            std::cout << "Course not found\n";
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(101, "Math");
    system.addCourse(102, "Science");
    system.enrollStudentInCourse(1, 101);
    system.enrollStudentInCourse(1, 102);
    system.enrollStudentInCourse(2, 102);
    system.displayStudents();
    system.displayCourses();
    system.searchStudent(1);
    system.searchCourse(101);
    system.deleteStudent(2);
    system.deleteCourse(101);
    system.displayStudents();
    system.displayCourses();
    return 0;
}