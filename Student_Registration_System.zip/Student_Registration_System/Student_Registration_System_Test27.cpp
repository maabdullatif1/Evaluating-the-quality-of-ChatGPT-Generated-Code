#include <iostream>
#include <string>
#include <vector>

class Course {
public:
    int id;
    std::string name;

    Course(int _id, const std::string &_name) : id(_id), name(_name) {}
};

class Student {
public:
    int id;
    std::string name;
    std::vector<Course> courses;

    Student(int _id, const std::string &_name) : id(_id), name(_name) {}
};

class RegistrationSystem {
private:
    std::vector<Student> students;

    Student* findStudent(int studentId) {
        for (auto &student : students) {
            if (student.id == studentId) {
                return &student;
            }
        }
        return nullptr;
    }

    Course* findCourse(Student &student, int courseId) {
        for (auto &course : student.courses) {
            if (course.id == courseId) return &course;
        }
        return nullptr;
    }

public:
    void addStudent(int id, const std::string &name) {
        if (!findStudent(id)) {
            students.emplace_back(id, name);
        }
    }

    void deleteStudent(int id) {
        students.erase(std::remove_if(students.begin(), students.end(),
                                      [id](Student &s) { return s.id == id; }),
                       students.end());
    }

    void updateStudent(int id, const std::string &newName) {
        Student *student = findStudent(id);
        if (student) {
            student->name = newName;
        }
    }

    void addCourse(int studentId, int courseId, const std::string &courseName) {
        Student *student = findStudent(studentId);
        if (student && !findCourse(*student, courseId)) {
            student->courses.emplace_back(courseId, courseName);
        }
    }

    void updateCourse(int studentId, int courseId, const std::string &newName) {
        Student *student = findStudent(studentId);
        if (student) {
            Course *course = findCourse(*student, courseId);
            if (course) course->name = newName;
        }
    }

    void deleteCourse(int studentId, int courseId) {
        Student *student = findStudent(studentId);
        if (student) {
            student->courses.erase(
                std::remove_if(student->courses.begin(), student->courses.end(),
                               [courseId](Course &c) { return c.id == courseId; }),
                student->courses.end());
        }
    }

    void displayStudent(int id) {
        Student *student = findStudent(id);
        if (student) {
            std::cout << "Student ID: " << student->id << ", Name: " << student->name << '\n';
            std::cout << "Courses:\n";
            for (const auto &course : student->courses) {
                std::cout << "  Course ID: " << course.id << ", Name: " << course.name << '\n';
            }
        } else {
            std::cout << "Student not found\n";
        }
    }

    void displayAllStudents() {
        for (const auto &student : students) {
            displayStudent(student.id);
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(1, 101, "Math");
    system.addCourse(1, 102, "Science");
    system.addCourse(2, 101, "Math");
    system.displayAllStudents();
    system.updateStudent(1, "Alicia");
    system.updateCourse(1, 101, "Advanced Math");
    system.displayStudent(1);
    system.deleteCourse(1, 102);
    system.displayStudent(1);
    system.deleteStudent(2);
    system.displayAllStudents();
    return 0;
}