#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int courseId;
    std::string courseName;

    Course(int id, std::string name) : courseId(id), courseName(name) {}
};

class Student {
public:
    int studentId;
    std::string studentName;
    std::vector<Course> courses;

    Student(int id, std::string name) : studentId(id), studentName(name) {}
    
    void addCourse(Course course) {
        courses.push_back(course);
    }
    
    void removeCourse(int courseId) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseId == courseId) {
                courses.erase(it);
                break;
            }
        }
    }
};

class RegistrationSystem {
    std::vector<Student> students;
    std::vector<Course> courses;

public:
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentId == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string name) {
        for (auto& student : students) {
            if (student.studentId == id) {
                student.studentName = name;
                return;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.studentId == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.studentId << ", Name: " << student.studentName << "\n";
        }
    }

    void addCourse(int id, std::string name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseId == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, std::string name) {
        for (auto& course : courses) {
            if (course.courseId == id) {
                course.courseName = name;
                return;
            }
        }
    }

    Course* searchCourse(int id) {
        for (auto& course : courses) {
            if (course.courseId == id) {
                return &course;
            }
        }
        return nullptr;
    }

    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.courseId << ", Name: " << course.courseName << "\n";
        }
    }

    void enrollStudentInCourse(int studentId, int courseId) {
        Student* student = searchStudent(studentId);
        Course* course = searchCourse(courseId);
        if (student && course) {
            student->addCourse(*course);
        }
    }

    void displayStudentCourses(int studentId) {
        Student* student = searchStudent(studentId);
        if (student) {
            for (const auto& course : student->courses) {
                std::cout << "Course ID: " << course.courseId << ", Name: " << course.courseName << "\n";
            }
        }
    }
};

int main() {
    RegistrationSystem system;
    
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    
    system.addCourse(101, "Mathematics");
    system.addCourse(102, "Physics");
    
    system.enrollStudentInCourse(1, 101);
    system.enrollStudentInCourse(2, 102);
    
    system.displayStudents();
    system.displayCourses();
    system.displayStudentCourses(1);

    return 0;
}