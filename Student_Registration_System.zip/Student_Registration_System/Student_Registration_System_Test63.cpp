#include <iostream>
#include <vector>
#include <string>

struct Course {
    int courseID;
    std::string courseName;
};

struct Student {
    int studentID;
    std::string studentName;
    std::vector<Course> courses;
};

class StudentRegistrationSystem {
private:
    std::vector<Student> students;

public:
    void addStudent(int id, const std::string& name) {
        students.push_back({id, name, {}});
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string& newName) {
        for (auto& student : students) {
            if (student.studentID == id) {
                student.studentName = newName;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.studentID == id) {
                std::cout << "Student ID: " << student.studentID << ", Name: " << student.studentName << "\n";
                for (const auto& course : student.courses) {
                    std::cout << "  Course ID: " << course.courseID << ", Name: " << course.courseName << "\n";
                }
                return;
            }
        }
        std::cout << "Student not found.\n";
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.studentID << ", Name: " << student.studentName << "\n";
            for (const auto& course : student.courses) {
                std::cout << "  Course ID: " << course.courseID << ", Name: " << course.courseName << "\n";
            }
        }
    }

    void addCourseToStudent(int studentID, int courseID, const std::string& courseName) {
        for (auto& student : students) {
            if (student.studentID == studentID) {
                student.courses.push_back({courseID, courseName});
                return;
            }
        }
        std::cout << "Student not found.\n";
    }

    void deleteCourseFromStudent(int studentID, int courseID) {
        for (auto& student : students) {
            if (student.studentID == studentID) {
                for (auto it = student.courses.begin(); it != student.courses.end(); ++it) {
                    if (it->courseID == courseID) {
                        student.courses.erase(it);
                        return;
                    }
                }
            }
        }
    }
};

int main() {
    StudentRegistrationSystem sys;
    sys.addStudent(1, "Alice");
    sys.addStudent(2, "Bob");
    sys.addCourseToStudent(1, 101, "Math");
    sys.addCourseToStudent(1, 102, "Physics");
    sys.addCourseToStudent(2, 101, "Math");
    sys.displayStudents();
    sys.searchStudent(1);
    sys.updateStudent(1, "Alice Smith");
    sys.deleteCourseFromStudent(1, 101);
    sys.deleteStudent(2);
    sys.displayStudents();
    return 0;
}