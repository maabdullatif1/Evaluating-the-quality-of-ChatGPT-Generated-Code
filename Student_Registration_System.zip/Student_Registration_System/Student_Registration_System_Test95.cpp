```cpp
#include <iostream>
#include <string>
using namespace std;

const int MAX_STUDENTS = 100;
const int MAX_COURSES = 50;

struct Student {
    int id;
    string name;
};

struct Course {
    int id;
    string name;
};

Student students[MAX_STUDENTS];
int studentCount = 0;

Course courses[MAX_COURSES];
int courseCount = 0;

void addStudent() {
    if (studentCount < MAX_STUDENTS) {
        cout << "Enter student id: ";
        cin >> students[studentCount].id;
        cout << "Enter student name: ";
        cin >> students[studentCount].name;
        studentCount++;
    } else {
        cout << "Student list is full." << endl;
    }
}

void deleteStudent() {
    int id;
    cout << "Enter student id to delete: ";
    cin >> id;
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].id == id) {
            for (int j = i; j < studentCount - 1; ++j) {
                students[j] = students[j + 1];
            }
            studentCount--;
            cout << "Student deleted." << endl;
            return;
        }
    }
    cout << "Student not found." << endl;
}

void updateStudent() {
    int id;
    cout << "Enter student id to update: ";
    cin >> id;
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].id == id) {
            cout << "Enter new student name: ";
            cin >> students[i].name;