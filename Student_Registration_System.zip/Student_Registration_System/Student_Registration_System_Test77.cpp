#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    int courseId;
    string courseName;

    Course(int id, string name) : courseId(id), courseName(name) {}

    void display() {
        cout << "Course ID: " << courseId << ", Course Name: " << courseName << endl;
    }
};

class Student {
public:
    int studentId;
    string studentName;
    vector<Course> courses;

    Student(int id, string name) : studentId(id), studentName(name) {}

    void addCourse(Course course) {
        courses.push_back(course);
    }

    void removeCourse(int courseId) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseId == courseId) {
                courses.erase(it);
                break;
            }
        }
    }

    void display() {
        cout << "Student ID: " << studentId << ", Student Name: " << studentName << endl;
        for (auto& course : courses) {
            course.display();
        }
    }
};

class RegistrationSystem {
public:
    vector<Student> students;
    vector<Course> courses;

    void addStudent(Student student) {
        students.push_back(student);
    }

    void deleteStudent(int studentId) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentId == studentId) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int studentId, string newName) {
        for (auto& student : students) {
            if (student.studentId == studentId) {
                student.studentName = newName;
                break;
            }
        }
    }

    void addCourse(Course course) {
        courses.push_back(course);
    }

    void deleteCourse(int courseId) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseId == courseId) {
                courses.erase(it);
                break;
            }
        }
    }

    Student* searchStudent(int studentId) {
        for (auto& student : students) {
            if (student.studentId == studentId) {
                return &student;
            }
        }
        return nullptr;
    }

    Course* searchCourse(int courseId) {
        for (auto& course : courses) {
            if (course.courseId == courseId) {
                return &course;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (auto& student : students) {
            student.display();
        }
    }

    void displayCourses() {
        for (auto& course : courses) {
            course.display();
        }
    }
};

int main() {
    RegistrationSystem system;

    system.addCourse(Course(101, "Math"));
    system.addCourse(Course(102, "Science"));

    Student s1(1, "Alice");
    s1.addCourse(*system.searchCourse(101));
    system.addStudent(s1);

    Student s2(2, "Bob");
    s2.addCourse(*system.searchCourse(102));
    system.addStudent(s2);

    system.displayStudents();
    system.displayCourses();

    system.updateStudent(1, "Alicia");
    system.deleteCourse(102);
    system.displayStudents();
    system.displayCourses();

    return 0;
}