#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int courseId;
    std::string courseName;

    Course(int id, std::string name) : courseId(id), courseName(name) {}
};

class Student {
public:
    int studentId;
    std::string studentName;
    std::vector<Course> courses;

    Student(int id, std::string name) : studentId(id), studentName(name) {}

    void addCourse(Course course) {
        courses.push_back(course);
    }
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

public:
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (size_t i = 0; i < students.size(); ++i) {
            if (students[i].studentId == id) {
                students.erase(students.begin() + i);
                break;
            }
        }
    }

    void updateStudent(int id, std::string newName) {
        for (auto &student : students) {
            if (student.studentId == id) {
                student.studentName = newName;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto &student : students) {
            if (student.studentId == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto &student : students) {
            std::cout << "Student ID: " << student.studentId << ", Name: " << student.studentName << "\n";
        }
    }

    void addCourse(int id, std::string name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (size_t i = 0; i < courses.size(); ++i) {
            if (courses[i].courseId == id) {
                courses.erase(courses.begin() + i);
                break;
            }
        }
    }

    void updateCourse(int id, std::string newName) {
        for (auto &course : courses) {
            if (course.courseId == id) {
                course.courseName = newName;
                break;
            }
        }
    }

    Course* searchCourse(int id) {
        for (auto &course : courses) {
            if (course.courseId == id) {
                return &course;
            }
        }
        return nullptr;
    }

    void displayCourses() {
        for (const auto &course : courses) {
            std::cout << "Course ID: " << course.courseId << ", Name: " << course.courseName << "\n";
        }
    }
};

int main() {
    RegistrationSystem system;

    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.displayStudents();
    system.updateStudent(1, "Alicia");
    system.displayStudents();
    system.deleteStudent(2);
    system.displayStudents();

    system.addCourse(101, "Mathematics");
    system.addCourse(102, "Physics");
    system.displayCourses();
    system.updateCourse(101, "Advanced Mathematics");
    system.displayCourses();
    system.deleteCourse(102);
    system.displayCourses();

    return 0;
}