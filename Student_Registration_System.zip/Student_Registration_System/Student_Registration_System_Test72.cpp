#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    string courseName;
    string courseCode;

    Course(string name, string code) : courseName(name), courseCode(code) {}
};

class Student {
public:
    string studentName;
    string studentID;
    vector<Course> courses;

    Student(string name, string id) : studentName(name), studentID(id) {}

    void addCourse(const Course& course) {
        courses.push_back(course);
    }
};

vector<Student> students;

void addStudent() {
    string name, id;
    cout << "Enter student name: ";
    cin >> name;
    cout << "Enter student ID: ";
    cin >> id;
    students.push_back(Student(name, id));
}

void deleteStudent() {
    string id;
    cout << "Enter student ID to delete: ";
    cin >> id;
    for (auto it = students.begin(); it != students.end(); ++it) {
        if (it->studentID == id) {
            students.erase(it);
            cout << "Student deleted.\n";
            return;
        }
    }
    cout << "Student not found.\n";
}

void updateStudent() {
    string id;
    cout << "Enter student ID to update: ";
    cin >> id;
    for (auto& student : students) {
        if (student.studentID == id) {
            cout << "Enter new name: ";
            cin >> student.studentName;
            cout << "Student updated.\n";
            return;
        }
    }
    cout << "Student not found.\n";
}

void searchStudent() {
    string id;
    cout << "Enter student ID to search: ";
    cin >> id;
    for (const auto& student : students) {
        if (student.studentID == id) {
            cout << "Student Name: " << student.studentName << "\n";
            cout << "Student ID: " << student.studentID << "\n";
            cout << "Courses Enrolled:\n";
            for (const auto& course : student.courses) {
                cout << course.courseName << " (" << course.courseCode << ")\n";
            }
            return;
        }
    }
    cout << "Student not found.\n";
}

void displayStudents() {
    for (const auto& student : students) {
        cout << "Student Name: " << student.studentName << ", ID: " << student.studentID << "\n";
        cout << "Courses:\n";
        for (const auto& course : student.courses) {
            cout << course.courseName << " (" << course.courseCode << ")\n";
        }
    }
}

void addCourseToStudent() {
    string id, courseName, courseCode;
    cout << "Enter student ID to add course: ";
    cin >> id;
    for (auto& student : students) {
        if (student.studentID == id) {
            cout << "Enter course name: ";
            cin >> courseName;
            cout << "Enter course code: ";
            cin >> courseCode;
            student.addCourse(Course(courseName, courseCode));
            cout << "Course added.\n";
            return;
        }
    }
    cout << "Student not found.\n";
}

int main() {
    int choice;
    do {
        cout << "1. Add Student\n";
        cout << "2. Delete Student\n";
        cout << "3. Update Student\n";
        cout << "4. Search Student\n";
        cout << "5. Display All Students\n";
        cout << "6. Add Course to Student\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addStudent(); break;
            case 2: deleteStudent(); break;
            case 3: updateStudent(); break;
            case 4: searchStudent(); break;
            case 5: displayStudents(); break;
            case 6: addCourseToStudent(); break;
        }
    } while (choice != 0);
    return 0;
}