#include <iostream>
#include <string>

class Course {
public:
    int courseID;
    std::string courseName;

    Course() : courseID(0), courseName("") {}
    Course(int id, std::string name) : courseID(id), courseName(name) {}
};

class Student {
public:
    int studentID;
    std::string name;

    Student() : studentID(0), name("") {}
    Student(int id, std::string n) : studentID(id), name(n) {}
};

class RegistrationSystem {
    Course courses[100];
    Student students[100];
    int totalCourses;
    int totalStudents;

public:
    RegistrationSystem() : totalCourses(0), totalStudents(0) {}

    void addCourse(int id, std::string name) {
        courses[totalCourses++] = Course(id, name);
    }

    void deleteCourse(int id) {
        for (int i = 0; i < totalCourses; i++) {
            if (courses[i].courseID == id) {
                for (int j = i; j < totalCourses - 1; j++)
                    courses[j] = courses[j + 1];
                totalCourses--;
                break;
            }
        }
    }

    void updateCourse(int id, std::string name) {
        for (int i = 0; i < totalCourses; i++) {
            if (courses[i].courseID == id) {
                courses[i].courseName = name;
                break;
            }
        }
    }

    void displayCourses() {
        for (int i = 0; i < totalCourses; i++) {
            std::cout << "Course ID: " << courses[i].courseID
                      << ", Course Name: " << courses[i].courseName << std::endl;
        }
    }

    void searchCourse(int id) {
        for (int i = 0; i < totalCourses; i++) {
            if (courses[i].courseID == id) {
                std::cout << "Course ID: " << courses[i].courseID
                          << ", Course Name: " << courses[i].courseName << std::endl;
                return;
            }
        }
        std::cout << "Course not found." << std::endl;
    }

    void addStudent(int id, std::string name) {
        students[totalStudents++] = Student(id, name);
    }

    void deleteStudent(int id) {
        for (int i = 0; i < totalStudents; i++) {
            if (students[i].studentID == id) {
                for (int j = i; j < totalStudents - 1; j++)
                    students[j] = students[j + 1];
                totalStudents--;
                break;
            }
        }
    }

    void updateStudent(int id, std::string name) {
        for (int i = 0; i < totalStudents; i++) {
            if (students[i].studentID == id) {
                students[i].name = name;
                break;
            }
        }
    }

    void displayStudents() {
        for (int i = 0; i < totalStudents; i++) {
            std::cout << "Student ID: " << students[i].studentID
                      << ", Name: " << students[i].name << std::endl;
        }
    }

    void searchStudent(int id) {
        for (int i = 0; i < totalStudents; i++) {
            if (students[i].studentID == id) {
                std::cout << "Student ID: " << students[i].studentID
                          << ", Name: " << students[i].name << std::endl;
                return;
            }
        }
        std::cout << "Student not found." << std::endl;
    }
};

int main() {
    RegistrationSystem system;

    system.addCourse(101, "Mathematics");
    system.addCourse(102, "Physics");
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");

    std::cout << "All Courses:" << std::endl;
    system.displayCourses();

    std::cout << "\nAll Students:" << std::endl;
    system.displayStudents();

    system.searchCourse(101);
    system.updateStudent(1, "Alice Smith");
    system.searchStudent(1);
    system.deleteCourse(102);
    system.deleteStudent(2);

    std::cout << "\nUpdated Courses:" << std::endl;
    system.displayCourses();

    std::cout << "\nUpdated Students:" << std::endl;
    system.displayStudents();

    return 0;
}