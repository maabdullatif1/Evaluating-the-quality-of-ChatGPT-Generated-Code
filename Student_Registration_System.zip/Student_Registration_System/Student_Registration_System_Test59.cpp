#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Student {
    int id;
    string name;
};

struct Course {
    int id;
    string title;
};

vector<Student> students;
vector<Course> courses;

void addStudent(int id, string name) {
    students.push_back({id, name});
}

void deleteStudent(int id) {
    for (auto it = students.begin(); it != students.end(); ++it) {
        if (it->id == id) {
            students.erase(it);
            return;
        }
    }
}

void updateStudent(int id, string name) {
    for (auto& student : students) {
        if (student.id == id) {
            student.name = name;
            return;
        }
    }
}

void displayStudents() {
    for (const auto& student : students) {
        cout << "ID: " << student.id << ", Name: " << student.name << endl;
    }
}

Student* searchStudent(int id) {
    for (auto& student : students) {
        if (student.id == id) {
            return &student;
        }
    }
    return nullptr;
}

void addCourse(int id, string title) {
    courses.push_back({id, title});
}

void deleteCourse(int id) {
    for (auto it = courses.begin(); it != courses.end(); ++it) {
        if (it->id == id) {
            courses.erase(it);
            return;
        }
    }
}

void updateCourse(int id, string title) {
    for (auto& course : courses) {
        if (course.id == id) {
            course.title = title;
            return;
        }
    }
}

void displayCourses() {
    for (const auto& course : courses) {
        cout << "ID: " << course.id << ", Title: " << course.title << endl;
    }
}

Course* searchCourse(int id) {
    for (auto& course : courses) {
        if (course.id == id) {
            return &course;
        }
    }
    return nullptr;
}

int main() {
    addStudent(1, "Alice");
    addStudent(2, "Bob");
    displayStudents();
    updateStudent(1, "Alicia");
    displayStudents();
    deleteStudent(2);
    displayStudents();
    
    addCourse(101, "Math");
    addCourse(102, "Science");
    displayCourses();
    updateCourse(101, "Advanced Math");
    displayCourses();
    deleteCourse(102);
    displayCourses();

    if (Student* s = searchStudent(1)) {
        cout << "Found student: " << s->name << endl;
    }

    if (Course* c = searchCourse(101)) {
        cout << "Found course: " << c->title << endl;
    }

    return 0;
}