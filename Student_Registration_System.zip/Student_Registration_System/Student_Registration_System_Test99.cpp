#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int id;
    std::string name;
    Course(int id, std::string name) : id(id), name(name) {}
};

class Student {
public:
    int id;
    std::string name;
    std::vector<Course> courses;
    Student(int id, std::string name) : id(id), name(name) {}
    void addCourse(const Course& course) {
        courses.push_back(course);
    }
    void removeCourse(int courseId) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == courseId) {
                courses.erase(it);
                break;
            }
        }
    }
    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.id << ", Course Name: " << course.name << std::endl;
        }
    }
};

class StudentRegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;
public:
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }
    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }
    void updateStudentName(int id, std::string newName) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }
    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
                student.displayCourses();
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }
    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
    void addCourse(int id, std::string name) {
        courses.push_back(Course(id, name));
    }
    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == id) {
                courses.erase(it);
                break;
            }
        }
        for (auto& student : students) {
            student.removeCourse(id);
        }
    }
    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.id << ", Name: " << course.name << std::endl;
        }
    }
    void enrollStudentInCourse(int studentId, int courseId) {
        auto itCourse = std::find_if(courses.begin(), courses.end(), [&](const Course& c) { return c.id == courseId; });
        if (itCourse == courses.end()) return;
        for (auto& student : students) {
            if (student.id == studentId) {
                student.addCourse(*itCourse);
                break;
            }
        }
    }
    void unenrollStudentFromCourse(int studentId, int courseId) {
        for (auto& student : students) {
            if (student.id == studentId) {
                student.removeCourse(courseId);
                break;
            }
        }
    }
};

int main() {
    StudentRegistrationSystem system;
    system.addStudent(1, "John Doe");
    system.addStudent(2, "Jane Smith");
    system.addCourse(101, "Mathematics");
    system.addCourse(102, "Physics");
    system.enrollStudentInCourse(1, 101);
    system.enrollStudentInCourse(2, 102);
    system.searchStudent(1);
    system.displayStudents();
    system.displayCourses();
    return 0;
}