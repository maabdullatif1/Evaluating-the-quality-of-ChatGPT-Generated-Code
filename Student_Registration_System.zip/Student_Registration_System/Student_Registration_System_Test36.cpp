#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int id;
    std::string name;
    
    Course(int id, std::string name) : id(id), name(name) {}
};

class Student {
public:
    int id;
    std::string name;
    std::vector<Course> courses;
    
    Student(int id, std::string name) : id(id), name(name) {}
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

    int findStudentIndex(int id) {
        for (int i = 0; i < students.size(); ++i)
            if (students[i].id == id)
                return i;
        return -1;
    }

    int findCourseIndex(int id) {
        for (int i = 0; i < courses.size(); ++i)
            if (courses[i].id == id)
                return i;
        return -1;
    }

public:
    void addStudent(int id, std::string name) {
        if (findStudentIndex(id) == -1)
            students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        int index = findStudentIndex(id);
        if (index != -1)
            students.erase(students.begin() + index);
    }

    void updateStudent(int id, std::string newName) {
        int index = findStudentIndex(id);
        if (index != -1)
            students[index].name = newName;
    }

    void searchStudent(int id) {
        int index = findStudentIndex(id);
        if (index != -1)
            std::cout << "Student ID: " << students[index].id << ", Name: " << students[index].name << "\n";
        else
            std::cout << "Student not found.\n";
    }

    void displayStudents() {
        for (Student &student : students)
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << "\n";
    }

    void addCourse(int id, std::string name) {
        if (findCourseIndex(id) == -1)
            courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        int index = findCourseIndex(id);
        if (index != -1)
            courses.erase(courses.begin() + index);
    }

    void updateCourse(int id, std::string newName) {
        int index = findCourseIndex(id);
        if (index != -1)
            courses[index].name = newName;
    }

    void searchCourse(int id) {
        int index = findCourseIndex(id);
        if (index != -1)
            std::cout << "Course ID: " << courses[index].id << ", Name: " << courses[index].name << "\n";
        else
            std::cout << "Course not found.\n";
    }

    void displayCourses() {
        for (Course &course : courses)
            std::cout << "Course ID: " << course.id << ", Name: " << course.name << "\n";
    }

    void enrollStudentInCourse(int studentId, int courseId) {
        int studentIndex = findStudentIndex(studentId);
        int courseIndex = findCourseIndex(courseId);
        if (studentIndex != -1 && courseIndex != -1)
            students[studentIndex].courses.push_back(courses[courseIndex]);
    }
};

int main() {
    RegistrationSystem rs;
    rs.addStudent(1, "Alice");
    rs.addStudent(2, "Bob");
    rs.displayStudents();
    rs.addCourse(101, "Math");
    rs.addCourse(102, "Science");
    rs.displayCourses();
    rs.enrollStudentInCourse(1, 101);
    rs.searchStudent(1);
    return 0;
}