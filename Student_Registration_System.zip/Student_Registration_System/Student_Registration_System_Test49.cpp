#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Course {
public:
    int courseID;
    string courseName;

    Course(int id, string name) : courseID(id), courseName(name) {}
};

class Student {
public:
    int studentID;
    string studentName;
    vector<Course> courses;

    Student(int id, string name) : studentID(id), studentName(name) {}

    void addCourse(Course course) {
        courses.push_back(course);
    }

    void removeCourse(int courseID) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == courseID) {
                courses.erase(it);
                break;
            }
        }
    }
};

class RegistrationSystem {
private:
    vector<Student> students;
    vector<Course> courses;

public:
    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string name) {
        for (auto& s : students) {
            if (s.studentID == id) {
                s.studentName = name;
                break;
            }
        }
    }

    void addCourse(int id, string name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, string name) {
        for (auto& c : courses) {
            if (c.courseID == id) {
                c.courseName = name;
                break;
            }
        }
    }

    void enrollStudentInCourse(int studentID, int courseID) {
        Student* student = searchStudent(studentID);
        Course* course = searchCourse(courseID);
        if (student && course) {
            student->addCourse(*course);
        }
    }

    Student* searchStudent(int id) {
        for (auto& s : students) {
            if (s.studentID == id) {
                return &s;
            }
        }
        return nullptr;
    }

    Course* searchCourse(int id) {
        for (auto& c : courses) {
            if (c.courseID == id) {
                return &c;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto &s : students) {
            cout << "Student ID: " << s.studentID << ", Name: " << s.studentName << ", Courses: ";
            for (const auto &c : s.courses) {
                cout << c.courseName << " ";
            }
            cout << endl;
        }
    }

    void displayCourses() {
        for (const auto &c : courses) {
            cout << "Course ID: " << c.courseID << ", Name: " << c.courseName << endl;
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addCourse(101, "Math");
    system.enrollStudentInCourse(1, 101);
    system.displayStudents();
    system.displayCourses();
    return 0;
}