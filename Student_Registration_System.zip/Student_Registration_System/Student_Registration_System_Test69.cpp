#include <iostream>
#include <string>

struct Course {
    int courseID;
    std::string courseName;
};

struct Student {
    int studentID;
    std::string studentName;
    Course courses[5];
    int courseCount;
};

class RegistrationSystem {
    Student students[100];
    int studentCount;

public:
    RegistrationSystem() : studentCount(0) {}

    void addStudent(int id, const std::string& name) {
        students[studentCount].studentID = id;
        students[studentCount].studentName = name;
        students[studentCount].courseCount = 0;
        studentCount++;
    }

    void deleteStudent(int id) {
        for(int i = 0; i < studentCount; i++) {
            if(students[i].studentID == id) {
                for(int j = i; j < studentCount - 1; j++) {
                    students[j] = students[j + 1];
                }
                studentCount--;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for(int i = 0; i < studentCount; i++) {
            if(students[i].studentID == id) {
                displayStudent(students[i]);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string& name) {
        for(int i = 0; i < studentCount; i++) {
            if(students[i].studentID == id) {
                students[i].studentName = name;
                break;
            }
        }
    }

    void displayStudents() {
        for(int i = 0; i < studentCount; i++) {
            displayStudent(students[i]);
        }
    }
    
    void addCourseToStudent(int studentID, int courseID, const std::string& courseName) {
        for(int i = 0; i < studentCount; i++) {
            if(students[i].studentID == studentID) {
                if (students[i].courseCount < 5) {
                    students[i].courses[students[i].courseCount].courseID = courseID;
                    students[i].courses[students[i].courseCount].courseName = courseName;
                    students[i].courseCount++;
                }
                break;
            }
        }
    }
    
    void displayCourses(int studentID) {
        for(int i = 0; i < studentCount; i++) {
            if(students[i].studentID == studentID) {
                for(int j = 0; j < students[i].courseCount; j++) {
                    std::cout << "Course ID: " << students[i].courses[j].courseID << "\nCourse Name: " 
                              << students[i].courses[j].courseName << std::endl;
                }
                break;
            }
        }
    }

private:
    void displayStudent(const Student& student) {
        std::cout << "Student ID: " << student.studentID << "\nStudent Name: " << student.studentName 
                  << "\nCourses Enrolled: ";
        for(int i = 0; i < student.courseCount; i++) {
            std::cout << student.courses[i].courseName << " ";
        }
        std::cout << std::endl;
    }
};

int main() {
    RegistrationSystem rs;
    rs.addStudent(1, "John Doe");
    rs.addCourseToStudent(1, 101, "Math");
    rs.addCourseToStudent(1, 102, "Science");
    rs.displayCourses(1);
    rs.displayStudents();
    rs.updateStudent(1, "John Smith");
    rs.displayStudents();
    rs.deleteStudent(1);
    rs.displayStudents();
    return 0;
}