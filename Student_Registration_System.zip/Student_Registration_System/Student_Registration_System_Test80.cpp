#include <iostream>
#include <vector>
#include <string>

struct Course {
    int courseId;
    std::string courseName;
};

struct Student {
    int studentId;
    std::string name;
    std::vector<Course> courses;
};

class RegistrationSystem {
    std::vector<Student> students;

    Student* findStudent(int studentId) {
        for (auto &student : students) {
            if (student.studentId == studentId) {
                return &student;
            }
        }
        return nullptr;
    }

public:
    void addStudent(int studentId, std::string name) {
        students.push_back({studentId, name, {}});
    }

    void deleteStudent(int studentId) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentId == studentId) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(int studentId, std::string name) {
        Student* student = findStudent(studentId);
        if (student) {
            student->name = name;
        }
    }

    Student* searchStudent(int studentId) {
        return findStudent(studentId);
    }

    void displayStudents() {
        for (const auto &student : students) {
            std::cout << "Student ID: " << student.studentId 
                      << ", Name: " << student.name << std::endl;
        }
    }

    void addCourseToStudent(int studentId, int courseId, std::string courseName) {
        Student* student = findStudent(studentId);
        if (student) {
            student->courses.push_back({courseId, courseName});
        }
    }

    void displayCourses(int studentId) {
        Student* student = findStudent(studentId);
        if (student) {
            for (const auto &course : student->courses) {
                std::cout << "Course ID: " << course.courseId 
                          << ", Course Name: " << course.courseName << std::endl;
            }
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    
    system.addCourseToStudent(1, 101, "Math");
    system.addCourseToStudent(1, 102, "Science");
    system.addCourseToStudent(2, 103, "History");
    
    system.displayStudents();
    std::cout << "Courses for student ID 1:" << std::endl;
    system.displayCourses(1);

    system.updateStudent(2, "Robert");
    system.displayStudents();

    system.deleteStudent(1);
    system.displayStudents();

    return 0;
}