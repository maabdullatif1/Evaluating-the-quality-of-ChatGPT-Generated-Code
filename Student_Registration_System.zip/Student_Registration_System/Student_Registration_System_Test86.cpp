#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int courseID;
    std::string courseName;
    Course(int id, std::string name) : courseID(id), courseName(name) {}
};

class Student {
public:
    int studentID;
    std::string studentName;
    std::vector<Course> enrolledCourses;
    Student(int id, std::string name) : studentID(id), studentName(name) {}
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

public:
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for(auto it = students.begin(); it != students.end(); ++it) {
            if(it->studentID == id) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(int id, std::string newName) {
        for(auto& student : students) {
            if(student.studentID == id) {
                student.studentName = newName;
                return;
            }
        }
    }

    void searchStudent(int id) {
        for(const auto& student : students) {
            if(student.studentID == id) {
                std::cout << "Student ID: " << student.studentID << "\nName: " << student.studentName << std::endl;
                return;
            }
        }
        std::cout << "Student not found." << std::endl;
    }

    void displayStudents() {
        for(const auto& student : students) {
            std::cout << "ID: " << student.studentID << " Name: " << student.studentName << std::endl;
        }
    }

    void addCourse(int id, std::string name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for(auto it = courses.begin(); it != courses.end(); ++it) {
            if(it->courseID == id) {
                courses.erase(it);
                return;
            }
        }
    }

    void updateCourse(int id, std::string newName) {
        for(auto& course : courses) {
            if(course.courseID == id) {
                course.courseName = newName;
                return;
            }
        }
    }

    void searchCourse(int id) {
        for(const auto& course : courses) {
            if(course.courseID == id) {
                std::cout << "Course ID: " << course.courseID << "\nName: " << course.courseName << std::endl;
                return;
            }
        }
        std::cout << "Course not found." << std::endl;
    }

    void displayCourses() {
        for(const auto& course : courses) {
            std::cout << "ID: " << course.courseID << " Name: " << course.courseName << std::endl;
        }
    }

    void enrollStudentInCourse(int studentID, int courseID) {
        for(auto& student : students) {
            if(student.studentID == studentID) {
                for(const auto& course : courses) {
                    if(course.courseID == courseID) {
                        student.enrolledCourses.push_back(course);
                        return;
                    }
                }
            }
        }
    }

    void displayStudentCourses(int studentID) {
        for(const auto& student : students) {
            if(student.studentID == studentID) {
                std::cout << "Courses for " << student.studentName << ":" << std::endl;
                for(const auto& course : student.enrolledCourses) {
                    std::cout << course.courseID << " - " << course.courseName << std::endl;
                }
                return;
            }
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(101, "Math");
    system.addCourse(102, "Science");
    
    system.enrollStudentInCourse(1, 101);
    system.enrollStudentInCourse(1, 102);
    system.displayStudents();
    system.displayCourses();
    system.displayStudentCourses(1);
    
    system.updateStudent(1, "Alice Smith");
    system.updateCourse(101, "Advanced Math");
    
    system.searchStudent(1);
    system.searchCourse(101);
    
    system.deleteStudent(2);
    system.deleteCourse(102);
    
    system.displayStudents();
    system.displayCourses();
    
    return 0;
}