#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    std::string code;
    std::string name;
    Course(const std::string& c, const std::string& n) : code(c), name(n) {}
};

class Student {
public:
    std::string id;
    std::string name;
    std::vector<Course> courses;

    Student(const std::string& i, const std::string& n) : id(i), name(n) {}

    void addCourse(const Course& course) {
        courses.push_back(course);
    }

    void deleteCourse(const std::string& courseCode) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->code == courseCode) {
                courses.erase(it);
                return;
            }
        }
    }
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

    int findStudentIndex(const std::string& id) {
        for (int i = 0; i < students.size(); ++i) {
            if (students[i].id == id) return i;
        }
        return -1;
    }

    int findCourseIndex(const std::string& code) {
        for (int i = 0; i < courses.size(); ++i) {
            if (courses[i].code == code) return i;
        }
        return -1;
    }

public:
    void addStudent(const std::string& id, const std::string& name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(const std::string& id) {
        int index = findStudentIndex(id);
        if (index != -1) {
            students.erase(students.begin() + index);
        }
    }

    void updateStudent(const std::string& id, const std::string& name) {
        int index = findStudentIndex(id);
        if (index != -1) {
            students[index].name = name;
        }
    }

    Student* searchStudent(const std::string& id) {
        int index = findStudentIndex(id);
        return (index != -1) ? &students[index] : nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }

    void addCourse(const std::string& code, const std::string& name) {
        courses.emplace_back(code, name);
    }

    void deleteCourse(const std::string& code) {
        int index = findCourseIndex(code);
        if (index != -1) {
            courses.erase(courses.begin() + index);
        }
    }

    void updateCourse(const std::string& code, const std::string& name) {
        int index = findCourseIndex(code);
        if (index != -1) {
            courses[index].name = name;
        }
    }

    Course* searchCourse(const std::string& code) {
        int index = findCourseIndex(code);
        return (index != -1) ? &courses[index] : nullptr;
    }

    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Code: " << course.code << ", Name: " << course.name << std::endl;
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent("S001", "Alice");
    system.addStudent("S002", "Bob");
    system.addCourse("C001", "Math");
    system.addCourse("C002", "Science");

    system.displayStudents();
    system.displayCourses();

    system.updateStudent("S001", "Alice Smith");
    system.updateCourse("C001", "Advanced Math");

    system.displayStudents();
    system.displayCourses();

    system.deleteStudent("S002");
    system.deleteCourse("C002");

    system.displayStudents();
    system.displayCourses();

    return 0;
}