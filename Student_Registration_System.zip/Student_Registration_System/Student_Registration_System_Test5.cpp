#include <iostream>
#include <string>
#include <vector>

struct Course {
    int id;
    std::string name;
};

struct Student {
    int id;
    std::string name;
    std::vector<Course> courses;
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

public:
    void addStudent(int studentId, const std::string& studentName) {
        Student student = {studentId, studentName, {}};
        students.push_back(student);
    }
    
    void deleteStudent(int studentId) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == studentId) {
                students.erase(it);
                break;
            }
        }
    }
    
    void updateStudent(int studentId, const std::string& newName) {
        for (auto& student : students) {
            if (student.id == studentId) {
                student.name = newName;
                break;
            }
        }
    }
    
    Student* searchStudent(int studentId) {
        for (auto& student : students) {
            if (student.id == studentId) {
                return &student;
            }
        }
        return nullptr;
    }
    
    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << "\n";
            for (const auto& course : student.courses) {
                std::cout << "  Course ID: " << course.id << ", Name: " << course.name << "\n";
            }
        }
    }
    
    void addCourse(int courseId, const std::string& courseName) {
        Course course = {courseId, courseName};
        courses.push_back(course);
    }
    
    void deleteCourse(int courseId) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == courseId) {
                courses.erase(it);
                break;
            }
        }
    }
    
    void updateCourse(int courseId, const std::string& newName) {
        for (auto& course : courses) {
            if (course.id == courseId) {
                course.name = newName;
                break;
            }
        }
    }
    
    Course* searchCourse(int courseId) {
        for (auto& course : courses) {
            if (course.id == courseId) {
                return &course;
            }
        }
        return nullptr;
    }
    
    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.id << ", Name: " << course.name << "\n";
        }
    }
    
    void enrollStudentInCourse(int studentId, int courseId) {
        Student* student = searchStudent(studentId);
        Course* course = searchCourse(courseId);
        if (student && course) {
            student->courses.push_back(*course);
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(101, "Math");
    system.addCourse(102, "Science");
    system.enrollStudentInCourse(1, 101);
    system.enrollStudentInCourse(2, 101);
    system.enrollStudentInCourse(2, 102);
    system.displayStudents();
    system.displayCourses();
    return 0;
}