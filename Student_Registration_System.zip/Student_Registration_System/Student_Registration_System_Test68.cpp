#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int id;
    std::string name;
    Course(int i, std::string n) : id(i), name(n) {}
};

class Student {
public:
    int id;
    std::string name;
    std::vector<int> enrolledCourses;
    Student(int i, std::string n) : id(i), name(n) {}
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

    int findStudent(int id) {
        for (size_t i = 0; i < students.size(); ++i) {
            if (students[i].id == id) return i;
        }
        return -1;
    }

    int findCourse(int id) {
        for (size_t i = 0; i < courses.size(); ++i) {
            if (courses[i].id == id) return i;
        }
        return -1;
    }

public:
    void addStudent(int id, std::string name) {
        if (findStudent(id) == -1)
            students.emplace_back(id, name);
    }

    void deleteStudent(int id) {
        int index = findStudent(id);
        if (index != -1)
            students.erase(students.begin() + index);
    }

    void updateStudent(int id, std::string name) {
        int index = findStudent(id);
        if (index != -1)
            students[index].name = name;
    }

    void searchStudent(int id) {
        int index = findStudent(id);
        if (index != -1)
            std::cout << "Student ID: " << students[index].id << ", Name: " << students[index].name << std::endl;
        else
            std::cout << "Student not found." << std::endl;
    }

    void displayStudents() {
        for (const auto &student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
            for (int courseId : student.enrolledCourses) {
                int courseIndex = findCourse(courseId);
                if (courseIndex != -1)
                    std::cout << "  Enrolled in: " << courses[courseIndex].name << std::endl;
            }
        }
    }

    void addCourse(int id, std::string name) {
        if (findCourse(id) == -1)
            courses.emplace_back(id, name);
    }

    void deleteCourse(int id) {
        int index = findCourse(id);
        if (index != -1)
            courses.erase(courses.begin() + index);
    }

    void updateCourse(int id, std::string name) {
        int index = findCourse(id);
        if (index != -1)
            courses[index].name = name;
    }

    void searchCourse(int id) {
        int index = findCourse(id);
        if (index != -1)
            std::cout << "Course ID: " << courses[index].id << ", Name: " << courses[index].name << std::endl;
        else
            std::cout << "Course not found." << std::endl;
    }

    void displayCourses() {
        for (const auto &course : courses) {
            std::cout << "Course ID: " << course.id << ", Name: " << course.name << std::endl;
        }
    }

    void enrollStudent(int studentId, int courseId) {
        int studentIndex = findStudent(studentId);
        int courseIndex = findCourse(courseId);
        if (studentIndex != -1 && courseIndex != -1) {
            students[studentIndex].enrolledCourses.push_back(courseId);
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(101, "Math");
    system.addCourse(102, "Science");
    system.enrollStudent(1, 101);
    system.enrollStudent(2, 102);
    system.displayStudents();
    system.searchStudent(1);
    system.searchCourse(101);
    system.updateStudent(1, "Alice Johnson");
    system.updateCourse(101, "Mathematics");
    system.displayStudents();
    system.displayCourses();
    system.deleteStudent(2);
    system.deleteCourse(102);
    system.displayStudents();
    system.displayCourses();
    return 0;
}