#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Course {
public:
    string courseID;
    string courseName;

    Course(string id, string name) : courseID(id), courseName(name) {}
    void displayCourse() { cout << "Course ID: " << courseID << ", Course Name: " << courseName << endl; }
};

class Student {
public:
    string studentID;
    string studentName;
    vector<Course> courses;

    Student(string id, string name) : studentID(id), studentName(name) {}

    void addCourse(Course course) { courses.push_back(course); }
    void removeCourse(string courseID) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == courseID) {
                courses.erase(it);
                break;
            }
        }
    }

    void displayStudent() {
        cout << "Student ID: " << studentID << ", Student Name: " << studentName << endl;
        for (auto &course : courses) {
            cout << "  ";
            course.displayCourse();
        }
    }
};

class RegistrationSystem {
private:
    vector<Student> students;
    vector<Course> courses;

public:
    void addStudent(string id, string name) { students.emplace_back(id, name); }

    void deleteStudent(string id) {
        students.erase(
            remove_if(students.begin(), students.end(), [&id](Student &s) { return s.studentID == id; }),
            students.end());
    }

    void updateStudent(string id, string newName) {
        for (auto &student : students) {
            if (student.studentID == id) {
                student.studentName = newName;
                break;
            }
        }
    }

    void addCourse(string id, string name) { courses.emplace_back(id, name); }

    void deleteCourse(string id) {
        courses.erase(
            remove_if(courses.begin(), courses.end(), [&id](Course &c) { return c.courseID == id; }),
            courses.end());
    }

    void assignCourseToStudent(string studentID, string courseID) {
        Course *course = nullptr;
        for (auto &c : courses) {
            if (c.courseID == courseID) {
                course = &c;
                break;
            }
        }
        if (!course) return;
        for (auto &s : students) {
            if (s.studentID == studentID) {
                s.addCourse(*course);
                break;
            }
        }
    }

    void removeCourseFromStudent(string studentID, string courseID) {
        for (auto &s : students) {
            if (s.studentID == studentID) {
                s.removeCourse(courseID);
                break;
            }
        }
    }

    void searchStudent(string id) {
        for (auto &student : students) {
            if (student.studentID == id) {
                student.displayStudent();
                return;
            }
        }
        cout << "Student not found" << endl;
    }

    void searchCourse(string id) {
        for (auto &course : courses) {
            if (course.courseID == id) {
                course.displayCourse();
                return;
            }
        }
        cout << "Course not found" << endl;
    }

    void displayAllStudents() {
        for (auto &student : students) {
            student.displayStudent();
        }
    }

    void displayAllCourses() {
        for (auto &course : courses) {
            course.displayCourse();
        }
    }
};

int main() {
    RegistrationSystem regSys;
    regSys.addStudent("S1001", "Alice");
    regSys.addStudent("S1002", "Bob");
    regSys.addCourse("C101", "Mathematics");
    regSys.addCourse("C102", "Physics");
    regSys.assignCourseToStudent("S1001", "C101");
    regSys.assignCourseToStudent("S1001", "C102");
    regSys.assignCourseToStudent("S1002", "C102");
    regSys.displayAllStudents();
    regSys.removeCourseFromStudent("S1001", "C102");
    regSys.searchStudent("S1001");
    regSys.deleteStudent("S1002");
    regSys.displayAllStudents();
    regSys.displayAllCourses();
    return 0;
}