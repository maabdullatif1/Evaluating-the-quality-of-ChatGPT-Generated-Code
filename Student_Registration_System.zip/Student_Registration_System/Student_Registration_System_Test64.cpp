#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int id;
    std::string name;
  
    Course(int id, std::string name) : id(id), name(name) {}
};

class Student {
public:
    int id;
    std::string name;
    std::vector<Course> courses;
  
    Student(int id, std::string name) : id(id), name(name) {}
    
    void addCourse(Course course) {
        courses.push_back(course);
    }

    void deleteCourse(int courseId) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == courseId) {
                courses.erase(it);
                break;
            }
        }
    }

    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.id << ", Course Name: " << course.name << std::endl;
        }
    }
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

public:
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }
    
    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string name) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto &student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Student Name: " << student.name << std::endl;
            student.displayCourses();
        }
    }

    void addCourse(int id, std::string name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, std::string name) {
        for (auto &course : courses) {
            if (course.id == id) {
                course.name = name;
                break;
            }
        }
    }

    Course* searchCourse(int id) {
        for (auto &course : courses) {
            if (course.id == id) {
                return &course;
            }
        }
        return nullptr;
    }

    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "Course ID: " << course.id << ", Course Name: " << course.name << std::endl;
        }
    }
};

int main() {
    RegistrationSystem system;

    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(101, "Math");
    system.addCourse(102, "Science");

    Student* student = system.searchStudent(1);
    if (student) {
        student->addCourse(Course(101, "Math"));
    }

    system.displayStudents();
    system.displayCourses();

    return 0;
}