#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Course {
public:
    int courseID;
    string courseName;

    Course(int id, string name) : courseID(id), courseName(name) {}
};

class Student {
public:
    int studentID;
    string studentName;
    vector<Course> enrolledCourses;

    Student(int id, string name) : studentID(id), studentName(name) {}

    void enrollCourse(Course course) {
        enrolledCourses.push_back(course);
    }

    void dropCourse(int courseID) {
        for (auto it = enrolledCourses.begin(); it != enrolledCourses.end(); ++it) {
            if (it->courseID == courseID) {
                enrolledCourses.erase(it);
                break;
            }
        }
    }

    void displayCourses() {
        for (const auto& course : enrolledCourses) {
            cout << "Course ID: " << course.courseID << ", Course Name: " << course.courseName << endl;
        }
    }
};

class RegistrationSystem {
private:
    vector<Student> students;
    vector<Course> courses;

public:
    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string newName) {
        for (auto& student : students) {
            if (student.studentID == id) {
                student.studentName = newName;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.studentID == id) {
                cout << "Student ID: " << student.studentID << ", Student Name: " << student.studentName << endl;
                student.displayCourses();
                return;
            }
        }
        cout << "Student not found" << endl;
    }

    void displayAllStudents() {
        for (const auto& student : students) {
            cout << "Student ID: " << student.studentID << ", Student Name: " << student.studentName << endl;
        }
    }

    void addCourse(int id, string name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(int id, string newName) {
        for (auto& course : courses) {
            if (course.courseID == id) {
                course.courseName = newName;
                break;
            }
        }
    }

    void searchCourse(int id) {
        for (const auto& course : courses) {
            if (course.courseID == id) {
                cout << "Course ID: " << course.courseID << ", Course Name: " << course.courseName << endl;
                return;
            }
        }
        cout << "Course not found" << endl;
    }

    void displayAllCourses() {
        for (const auto& course : courses) {
            cout << "Course ID: " << course.courseID << ", Course Name: " << course.courseName << endl;
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(101, "Math");
    system.addCourse(102, "Science");
    system.searchStudent(1);
    system.enrollCourseToStudent(1, 101);
    system.searchStudent(1);
    system.displayAllStudents();
    system.displayAllCourses();

    return 0;
}