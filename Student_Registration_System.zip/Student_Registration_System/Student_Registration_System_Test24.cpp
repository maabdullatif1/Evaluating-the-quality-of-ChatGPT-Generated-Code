#include <iostream>
#include <string>
using namespace std;

const int MAX_STUDENTS = 100;
const int MAX_COURSES = 50;

struct Course {
    int id;
    string name;
};

struct Student {
    int id;
    string name;
    int courseIds[MAX_COURSES];
    int courseCount;
};

class RegistrationSystem {
    Student students[MAX_STUDENTS];
    Course courses[MAX_COURSES];
    int studentCount;
    int courseCount;
public:
    RegistrationSystem() : studentCount(0), courseCount(0) {}

    void addStudent(int id, const string& name) {
        if (studentCount < MAX_STUDENTS) {
            students[studentCount++] = {id, name, {}, 0};
        }
    }

    void deleteStudent(int id) {
        for (int i = 0; i < studentCount; ++i) {
            if (students[i].id == id) {
                for (int j = i; j < studentCount - 1; ++j) {
                    students[j] = students[j + 1];
                }
                --studentCount;
                break;
            }
        }
    }

    void updateStudent(int id, const string& name) {
        for (int i = 0; i < studentCount; ++i) {
            if (students[i].id == id) {
                students[i].name = name;
                break;
            }
        }
    }
    
    void addCourse(int id, const string& name) {
        if (courseCount < MAX_COURSES) {
            courses[courseCount++] = {id, name};
        }
    }

    void deleteCourse(int id) {
        for (int i = 0; i < courseCount; ++i) {
            if (courses[i].id == id) {
                for (int j = i; j < courseCount - 1; ++j) {
                    courses[j] = courses[j + 1];
                }
                --courseCount;
                break;
            }
        }
    }

    void updateCourse(int id, const string& name) {
        for (int i = 0; i < courseCount; ++i) {
            if (courses[i].id == id) {
                courses[i].name = name;
                break;
            }
        }
    }

    void enrollCourse(int studentId, int courseId) {
        for (int i = 0; i < studentCount; ++i) {
            if (students[i].id == studentId) {
                if (students[i].courseCount < MAX_COURSES) {
                    students[i].courseIds[students[i].courseCount++] = courseId;
                }
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (int i = 0; i < studentCount; ++i) {
            if (students[i].id == id) {
                cout << "Student Found: " << students[i].name << endl;
                return;
            }
        }
        cout << "Student Not Found" << endl;
    }

    void searchCourse(int id) {
        for (int i = 0; i < courseCount; ++i) {
            if (courses[i].id == id) {
                cout << "Course Found: " << courses[i].name << endl;
                return;
            }
        }
        cout << "Course Not Found" << endl;
    }

    void displayStudents() {
        for (int i = 0; i < studentCount; ++i) {
            cout << "ID: " << students[i].id << ", Name: " << students[i].name << ", Courses: ";
            for (int j = 0; j < students[i].courseCount; ++j) {
                cout << students[i].courseIds[j] << " ";
            }
            cout << endl;
        }
    }

    void displayCourses() {
        for (int i = 0; i < courseCount; ++i) {
            cout << "ID: " << courses[i].id << ", Name: " << courses[i].name << endl;
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(101, "Math");
    system.addCourse(102, "Science");
    system.enrollCourse(1, 101);
    system.enrollCourse(2, 102);
    system.displayStudents();
    system.displayCourses();
    system.searchStudent(1);
    system.searchCourse(101);
    system.updateStudent(1, "Alicia");
    system.updateCourse(101, "Advanced Math");
    system.displayStudents();
    system.displayCourses();
    system.deleteStudent(2);
    system.deleteCourse(102);
    system.displayStudents();
    system.displayCourses();
    return 0;
}