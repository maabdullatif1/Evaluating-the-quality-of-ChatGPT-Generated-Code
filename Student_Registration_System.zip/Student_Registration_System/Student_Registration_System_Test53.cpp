#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    string courseCode;
    string courseName;

    Course(string code, string name) : courseCode(code), courseName(name) {}
};

class Student {
public:
    string studentId;
    string studentName;
    vector<Course> courses;

    Student(string id, string name) : studentId(id), studentName(name) {}

    void addCourse(const Course& course) {
        courses.push_back(course);
    }

    void removeCourse(const string& courseCode) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseCode == courseCode) {
                courses.erase(it);
                return;
            }
        }
    }
};

class RegistrationSystem {
private:
    vector<Student> students;
    vector<Course> courses;

    Student* findStudentById(const string& id) {
        for (auto& student : students) {
            if (student.studentId == id) {
                return &student;
            }
        }
        return nullptr;
    }

    Course* findCourseByCode(const string& code) {
        for (auto& course : courses) {
            if (course.courseCode == code) {
                return &course;
            }
        }
        return nullptr;
    }

public:
    void addStudent(const string& id, const string& name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(const string& id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentId == id) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(const string& id, const string& newName) {
        Student* student = findStudentById(id);
        if (student) {
            student->studentName = newName;
        }
    }

    void searchStudent(const string& id) {
        Student* student = findStudentById(id);
        if (student) {
            cout << "Student ID: " << student->studentId << ", Name: " << student->studentName << endl;
            for (const auto& course : student->courses) {
                cout << "Enrolled in: " << course.courseCode << " - " << course.courseName << endl;
            }
        } else {
            cout << "Student not found." << endl;
        }
    }

    void displayAllStudents() {
        for (const auto& student : students) {
            cout << "Student ID: " << student.studentId << ", Name: " << student.studentName << endl;
        }
    }

    void addCourse(const string& code, const string& name) {
        courses.emplace_back(code, name);
    }

    void deleteCourse(const string& code) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseCode == code) {
                courses.erase(it);
                return;
            }
        }
    }

    void updateCourse(const string& code, const string& newName) {
        Course* course = findCourseByCode(code);
        if (course) {
            course->courseName = newName;
        }
    }

    void searchCourse(const string& code) {
        Course* course = findCourseByCode(code);
        if (course) {
            cout << "Course Code: " << course->courseCode << ", Name: " << course->courseName << endl;
        } else {
            cout << "Course not found." << endl;
        }
    }

    void displayAllCourses() {
        for (const auto& course : courses) {
            cout << "Course Code: " << course.courseCode << ", Name: " << course.courseName << endl;
        }
    }

    void enrollStudentInCourse(const string& studentId, const string& courseCode) {
        Student* student = findStudentById(studentId);
        Course* course = findCourseByCode(courseCode);
        if (student && course) {
            student->addCourse(*course);
        }
    }

    void removeStudentFromCourse(const string& studentId, const string& courseCode) {
        Student* student = findStudentById(studentId);
        if (student) {
            student->removeCourse(courseCode);
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent("S001", "Alice");
    system.addStudent("S002", "Bob");
    system.addCourse("C101", "Math");
    system.addCourse("C102", "Science");
    system.enrollStudentInCourse("S001", "C101");
    system.searchStudent("S001");
    system.displayAllStudents();
    system.displayAllCourses();
    return 0;
}