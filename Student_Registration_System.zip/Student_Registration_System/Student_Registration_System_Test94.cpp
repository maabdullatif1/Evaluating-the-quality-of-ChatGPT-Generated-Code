#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Course {
public:
    string courseCode;
    string courseName;

    Course(string cCode, string cName) : courseCode(cCode), courseName(cName) {}

    void displayCourse() {
        cout << "Course Code: " << courseCode << ", Course Name: " << courseName << endl;
    }
};

class Student {
public:
    int id;
    string name;
    vector<Course> courses;

    Student(int id, string name) : id(id), name(name) {}

    void displayStudent() {
        cout << "ID: " << id << ", Name: " << name << endl;
        cout << "Courses Enrolled: " << endl;
        for (auto &course : courses) {
            course.displayCourse();
        }
    }

    void addCourse(Course course) {
        courses.push_back(course);
    }

    void removeCourse(string courseCode) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseCode == courseCode) {
                courses.erase(it);
                return;
            }
        }
    }
};

class RegistrationSystem {
    vector<Student> students;
    vector<Course> courses;

    Student* findStudent(int id) {
        for (auto &student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    Course* findCourse(string courseCode) {
        for (auto &course : courses) {
            if (course.courseCode == courseCode) {
                return &course;
            }
        }
        return nullptr;
    }

public:
    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void removeStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(int id, string newName) {
        Student* student = findStudent(id);
        if (student) {
            student->name = newName;
        }
    }

    void searchStudent(int id) {
        Student* student = findStudent(id);
        if (student) {
            student->displayStudent();
        } else {
            cout << "Student not found" << endl;
        }
    }

    void displayAllStudents() {
        for (auto &student : students) {
            student.displayStudent();
        }
    }

    void addCourse(string courseCode, string courseName) {
        courses.push_back(Course(courseCode, courseName));
    }

    void removeCourse(string courseCode) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseCode == courseCode) {
                courses.erase(it);
                return;
            }
        }
    }

    void updateCourse(string courseCode, string newCourseName) {
        Course* course = findCourse(courseCode);
        if (course) {
            course->courseName = newCourseName;
        }
    }

    void searchCourse(string courseCode) {
        Course* course = findCourse(courseCode);
        if (course) {
            course->displayCourse();
        } else {
            cout << "Course not found" << endl;
        }
    }

    void displayAllCourses() {
        for (auto &course : courses) {
            course.displayCourse();
        }
    }

    void enrollStudentInCourse(int studentId, string courseCode) {
        Student* student = findStudent(studentId);
        Course* course = findCourse(courseCode);
        if (student && course) {
            student->addCourse(*course);
        } else {
            cout << "Student or Course not found" << endl;
        }
    }

    void removeStudentFromCourse(int studentId, string courseCode) {
        Student* student = findStudent(studentId);
        if (student) {
            student->removeCourse(courseCode);
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "John Doe");
    system.addStudent(2, "Jane Smith");
    system.addCourse("CS101", "Introduction to Computer Science");
    system.addCourse("MA101", "Calculus");

    system.enrollStudentInCourse(1, "CS101");
    system.enrollStudentInCourse(1, "MA101");
    system.enrollStudentInCourse(2, "CS101");

    cout << "Displaying All Students:" << endl;
    system.displayAllStudents();

    cout << "Displaying All Courses:" << endl;
    system.displayAllCourses();

    return 0;
}