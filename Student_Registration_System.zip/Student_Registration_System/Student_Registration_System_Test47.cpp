#include <iostream>
#include <string>

using namespace std;

const int MAX_STUDENTS = 100;
const int MAX_COURSES = 50;

struct Student {
    int id;
    string name;
    int age;
    int courseId;
};

struct Course {
    int id;
    string title;
};

Student students[MAX_STUDENTS];
Course courses[MAX_COURSES];

int studentCount = 0;
int courseCount = 0;

void addStudent() {
    if (studentCount < MAX_STUDENTS) {
        Student s;
        cout << "Enter Student ID: ";
        cin >> s.id;
        cout << "Enter Student Name: ";
        cin.ignore();
        getline(cin, s.name);
        cout << "Enter Student Age: ";
        cin >> s.age;
        cout << "Enter Course ID: ";
        cin >> s.courseId;
        students[studentCount++] = s;
    } else {
        cout << "Maximum student limit reached." << endl;
    }
}

void deleteStudent() {
    int id;
    cout << "Enter Student ID to delete: ";
    cin >> id;
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].id == id) {
            students[i] = students[studentCount - 1];
            studentCount--;
            cout << "Student deleted." << endl;
            return;
        }
    }
    cout << "Student not found." << endl;
}

void updateStudent() {
    int id;
    cout << "Enter Student ID to update: ";
    cin >> id;
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].id == id) {
            cout << "Enter new Name: ";
            cin.ignore();
            getline(cin, students[i].name);
            cout << "Enter new Age: ";
            cin >> students[i].age;
            cout << "Enter new Course ID: ";
            cin >> students[i].courseId;
            cout << "Student updated." << endl;
            return;
        }
    }
    cout << "Student not found." << endl;
}

void searchStudent() {
    int id;
    cout << "Enter Student ID to search: ";
    cin >> id;
    for (int i = 0; i < studentCount; ++i) {
        if (students[i].id == id) {
            cout << "Student ID: " << students[i].id << ", Name: " << students[i].name << ", Age: " << students[i].age << ", Course ID: " << students[i].courseId << endl;
            return;
        }
    }
    cout << "Student not found." << endl;
}

void displayStudents() {
    if(studentCount == 0) {
        cout << "No students available." << endl;
        return;
    }
    for (int i = 0; i < studentCount; ++i) {
        cout << "Student ID: " << students[i].id << ", Name: " << students[i].name << ", Age: " << students[i].age << ", Course ID: " << students[i].courseId << endl;
    }
}

void addCourse() {
    if (courseCount < MAX_COURSES) {
        Course c;
        cout << "Enter Course ID: ";
        cin >> c.id;
        cout << "Enter Course Title: ";
        cin.ignore();
        getline(cin, c.title);
        courses[courseCount++] = c;
    } else {
        cout << "Maximum course limit reached." << endl;
    }
}

void deleteCourse() {
    int id;
    cout << "Enter Course ID to delete: ";
    cin >> id;
    for (int i = 0; i < courseCount; ++i) {
        if (courses[i].id == id) {
            courses[i] = courses[courseCount - 1];
            courseCount--;
            cout << "Course deleted." << endl;
            return;
        }
    }
    cout << "Course not found." << endl;
}

void updateCourse() {
    int id;
    cout << "Enter Course ID to update: ";
    cin >> id;
    for (int i = 0; i < courseCount; ++i) {
        if (courses[i].id == id) {
            cout << "Enter new Title: ";
            cin.ignore();
            getline(cin, courses[i].title);
            cout << "Course updated." << endl;
            return;
        }
    }
    cout << "Course not found." << endl;
}

void searchCourse() {
    int id;
    cout << "Enter Course ID to search: ";
    cin >> id;
    for (int i = 0; i < courseCount; ++i) {
        if (courses[i].id == id) {
            cout << "Course ID: " << courses[i].id << ", Title: " << courses[i].title << endl;
            return;
        }
    }
    cout << "Course not found." << endl;
}

void displayCourses() {
    if(courseCount == 0) {
        cout << "No courses available." << endl;
        return;
    }
    for (int i = 0; i < courseCount; ++i) {
        cout << "Course ID: " << courses[i].id << ", Title: " << courses[i].title << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "\n1. Add Student\n2. Delete Student\n3. Update Student\n4. Search Student\n5. Display Students\n";
        cout << "6. Add Course\n7. Delete Course\n8. Update Course\n9. Search Course\n10. Display Courses\n0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        
        switch (choice) {
            case 1: addStudent(); break;
            case 2: deleteStudent(); break;
            case 3: updateStudent(); break;
            case 4: searchStudent(); break;
            case 5: displayStudents(); break;
            case 6: addCourse(); break;
            case 7: deleteCourse(); break;
            case 8: updateCourse(); break;
            case 9: searchCourse(); break;
            case 10: displayCourses(); break;
        }
    } while (choice != 0);
    
    return 0;
}