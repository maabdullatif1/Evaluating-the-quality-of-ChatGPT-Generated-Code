#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    string courseID;
    string courseName;

    Course(string id, string name) : courseID(id), courseName(name) {}
};

class Student {
public:
    string studentID;
    string studentName;
    vector<Course> courses;

    Student(string id, string name) : studentID(id), studentName(name) {}

    void addCourse(Course course) {
        courses.push_back(course);
    }

    void removeCourse(string courseID) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == courseID) {
                courses.erase(it);
                return;
            }
        }
    }
};

class RegistrationSystem {
private:
    vector<Student> students;

public:
    void addStudent(string id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(string id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == id) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(string id, string newName) {
        for (auto& student : students) {
            if (student.studentID == id) {
                student.studentName = newName;
                return;
            }
        }
    }

    Student* searchStudent(string id) {
        for (auto& student : students) {
            if (student.studentID == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            cout << "Student ID: " << student.studentID << ", Name: " << student.studentName << endl;
            for (const auto& course : student.courses) {
                cout << "  Course ID: " << course.courseID << ", Name: " << course.courseName << endl;
            }
        }
    }

    void addCourseToStudent(string studentID, string courseID, string courseName) {
        Student* student = searchStudent(studentID);
        if (student) {
            student->addCourse(Course(courseID, courseName));
        }
    }

    void removeCourseFromStudent(string studentID, string courseID) {
        Student* student = searchStudent(studentID);
        if (student) {
            student->removeCourse(courseID);
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent("S001", "Alice");
    system.addStudent("S002", "Bob");
    system.addCourseToStudent("S001", "C001", "Mathematics");
    system.addCourseToStudent("S001", "C002", "Physics");
    system.addCourseToStudent("S002", "C001", "Mathematics");
    system.displayStudents();
    system.updateStudent("S002", "Robert");
    system.removeCourseFromStudent("S001", "C002");
    system.displayStudents();
    system.deleteStudent("S001");
    system.displayStudents();
    return 0;
}