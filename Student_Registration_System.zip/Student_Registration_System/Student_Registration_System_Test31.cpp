#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int id;
    std::string name;

    Course(int courseId, std::string courseName)
        : id(courseId), name(courseName) {}
};

class Student {
public:
    int id;
    std::string name;
    std::vector<Course> courses;

    Student(int studentId, std::string studentName)
        : id(studentId), name(studentName) {}

    void addCourse(const Course &course) {
        courses.push_back(course);
    }
    
    void removeCourse(int courseId) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == courseId) {
                courses.erase(it);
                break;
            }
        }
    }
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

public:
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string newName) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto &student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto &student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << "\nCourses: ";
            for (const auto &course : student.courses) {
                std::cout << course.name << " ";
            }
            std::cout << "\n";
        }
    }

    void addCourse(int id, std::string name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == id) {
                courses.erase(it);
                break;
            }
        }
    }

    Course* searchCourse(int id) {
        for (auto &course : courses) {
            if (course.id == id) {
                return &course;
            }
        }
        return nullptr;
    }

    void displayCourses() {
        for (const auto &course : courses) {
            std::cout << "Course ID: " << course.id << ", Name: " << course.name << "\n";
        }
    }

    void assignCourseToStudent(int studentId, int courseId) {
        Student* student = searchStudent(studentId);
        Course* course = searchCourse(courseId);
        if (student && course) {
            student->addCourse(*course);
        }
    }

    void removeCourseFromStudent(int studentId, int courseId) {
        Student* student = searchStudent(studentId);
        if (student) {
            student->removeCourse(courseId);
        }
    }
};

int main() {
    RegistrationSystem system;

    system.addCourse(1, "Math");
    system.addCourse(2, "Science");

    system.addStudent(101, "John Doe");
    system.addStudent(102, "Jane Smith");

    system.assignCourseToStudent(101, 1);
    system.assignCourseToStudent(102, 2);

    system.displayStudents();

    system.updateStudent(101, "Johnathan Doe");
    system.displayStudents();

    system.removeCourseFromStudent(102, 2);
    system.displayStudents();
    
    system.deleteStudent(102);
    system.displayStudents();

    return 0;
}