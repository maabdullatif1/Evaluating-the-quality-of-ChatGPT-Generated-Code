#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    int id;
    std::string name;

    Course(int id, const std::string& name) : id(id), name(name) {}
};

class Student {
public:
    int id;
    std::string name;
    std::vector<Course> courses;

    Student(int id, const std::string& name) : id(id), name(name) {}
};

class RegistrationSystem {
private:
    std::vector<Student> students;

public:
    void addStudent(int id, const std::string& name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string& newName) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
            for (const auto& course : student.courses) {
                std::cout << "    Enrolled Course ID: " << course.id << ", Name: " << course.name << std::endl;
            }
        }
    }

    void addCourseToStudent(int studentId, int courseId, const std::string& courseName) {
        for (auto& student : students) {
            if (student.id == studentId) {
                student.courses.emplace_back(courseId, courseName);
                break;
            }
        }
    }

    void removeCourseFromStudent(int studentId, int courseId) {
        for (auto& student : students) {
            if (student.id == studentId) {
                for (auto it = student.courses.begin(); it != student.courses.end(); ++it) {
                    if (it->id == courseId) {
                        student.courses.erase(it);
                        break;
                    }
                }
                break;
            }
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");

    system.addCourseToStudent(1, 101, "Math");
    system.addCourseToStudent(1, 102, "Science");

    system.addCourseToStudent(2, 103, "English");

    system.displayStudents();

    Student* student = system.searchStudent(1);
    if (student) {
        std::cout << "Found Student: " << student->name << std::endl;
    }

    system.updateStudent(1, "Alice Smith");

    system.removeCourseFromStudent(1, 101);

    system.displayStudents();

    system.deleteStudent(2);

    system.displayStudents();

    return 0;
}