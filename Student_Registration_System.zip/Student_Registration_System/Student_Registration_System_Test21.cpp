#include <iostream>
#include <string>
using namespace std;

struct Course {
    string courseId;
    string courseName;
};

struct Student {
    string studentId;
    string studentName;
    Course course;
};

struct University {
    Student students[100];
    int studentCount;

    void addStudent(const string &studentId, const string &studentName, const string &courseId, const string &courseName) {
        if (studentCount >= 100) return;
        students[studentCount].studentId = studentId;
        students[studentCount].studentName = studentName;
        students[studentCount].course.courseId = courseId;
        students[studentCount].course.courseName = courseName;
        studentCount++;
    }

    void deleteStudent(const string &studentId) {
        for (int i = 0; i < studentCount; ++i) {
            if (students[i].studentId == studentId) {
                for (int j = i; j < studentCount - 1; ++j)
                    students[j] = students[j + 1];
                studentCount--;
                break;
            }
        }
    }

    void updateStudent(const string &studentId, const string &newName, const string &newCourseId, const string &newCourseName) {
        for (int i = 0; i < studentCount; ++i) {
            if (students[i].studentId == studentId) {
                students[i].studentName = newName;
                students[i].course.courseId = newCourseId;
                students[i].course.courseName = newCourseName;
            }
        }
    }

    void searchStudent(const string &studentId) {
        for (int i = 0; i < studentCount; ++i) {
            if (students[i].studentId == studentId) {
                cout << "Student ID: " << students[i].studentId << endl;
                cout << "Student Name: " << students[i].studentName << endl;
                cout << "Course ID: " << students[i].course.courseId << endl;
                cout << "Course Name: " << students[i].course.courseName << endl;
            }
        }
    }

    void displayStudents() {
        for (int i = 0; i < studentCount; ++i) {
            cout << "Student ID: " << students[i].studentId << ", ";
            cout << "Student Name: " << students[i].studentName << ", ";
            cout << "Course ID: " << students[i].course.courseId << ", ";
            cout << "Course Name: " << students[i].course.courseName << endl;
        }
    }
};

int main() {
    University university;
    university.studentCount = 0;

    university.addStudent("S01", "John Doe", "C101", "Mathematics");
    university.addStudent("S02", "Jane Smith", "C102", "Physics");

    university.displayStudents();

    university.updateStudent("S02", "Jane Johnson", "C103", "Chemistry");
    
    university.searchStudent("S02");

    university.deleteStudent("S01");

    university.displayStudents();

    return 0;
}