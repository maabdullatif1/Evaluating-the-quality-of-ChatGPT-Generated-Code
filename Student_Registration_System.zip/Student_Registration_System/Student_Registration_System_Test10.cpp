#include <iostream>
#include <string>
using namespace std;

struct Course {
    int id;
    string name;
    int credits;
};

struct Student {
    int id;
    string name;
    int age;
    Course courses[10];
    int course_count;
};

Student students[100];
int student_count = 0;

void addStudent(int id, string name, int age) {
    students[student_count].id = id;
    students[student_count].name = name;
    students[student_count].age = age;
    students[student_count].course_count = 0;
    student_count++;
}

void deleteStudent(int id) {
    for (int i = 0; i < student_count; i++) {
        if (students[i].id == id) {
            for (int j = i; j < student_count - 1; j++) {
                students[j] = students[j + 1];
            }
            student_count--;
            break;
        }
    }
}

void updateStudent(int id, string name, int age) {
    for (int i = 0; i < student_count; i++) {
        if (students[i].id == id) {
            students[i].name = name;
            students[i].age = age;
            break;
        }
    }
}

Student* searchStudent(int id) {
    for (int i = 0; i < student_count; i++) {
        if (students[i].id == id) {
            return &students[i];
        }
    }
    return nullptr;
}

void displayStudents() {
    for (int i = 0; i < student_count; i++) {
        cout << "ID: " << students[i].id << ", Name: " << students[i].name << ", Age: " << students[i].age << endl;
    }
}

void addCourseToStudent(int student_id, int course_id, string course_name, int credits) {
    Student* student = searchStudent(student_id);
    if (student != nullptr && student->course_count < 10) {
        student->courses[student->course_count].id = course_id;
        student->courses[student->course_count].name = course_name;
        student->courses[student->course_count].credits = credits;
        student->course_count++;
    }
}

void displayStudentCourses(int student_id) {
    Student* student = searchStudent(student_id);
    if (student != nullptr) {
        for (int i = 0; i < student->course_count; i++) {
            cout << "Course ID: " << student->courses[i].id << ", Name: " << student->courses[i].name << ", Credits: " << student->courses[i].credits << endl;
        }
    }
}

int main() {
    addStudent(1, "Alice", 20);
    addStudent(2, "Bob", 22);

    addCourseToStudent(1, 101, "Math", 3);
    addCourseToStudent(1, 102, "Science", 4);

    displayStudents();
    displayStudentCourses(1);

    updateStudent(1, "Alice Smith", 21);
    deleteStudent(2);

    displayStudents();

    return 0;
}