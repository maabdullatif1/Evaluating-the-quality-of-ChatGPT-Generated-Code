#include <iostream>
#include <vector>
#include <string>

class Student {
public:
    int id;
    std::string name;
    
    Student(int id, const std::string& name) : id(id), name(name) {}
};

class Course {
public:
    int id;
    std::string title;
    
    Course(int id, const std::string& title) : id(id), title(title) {}
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;

public:
    void addStudent(int id, const std::string& name) {
        students.push_back(Student(id, name));
    }
    
    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }
    
    void updateStudent(int id, const std::string& name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }
    
    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }
    
    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }

    void addCourse(int id, const std::string& title) {
        courses.push_back(Course(id, title));
    }
    
    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->id == id) {
                courses.erase(it);
                break;
            }
        }
    }
    
    void updateCourse(int id, const std::string& title) {
        for (auto& course : courses) {
            if (course.id == id) {
                course.title = title;
                break;
            }
        }
    }
    
    void searchCourse(int id) {
        for (const auto& course : courses) {
            if (course.id == id) {
                std::cout << "Course ID: " << course.id << ", Title: " << course.title << std::endl;
                return;
            }
        }
        std::cout << "Course not found" << std::endl;
    }
    
    void displayCourses() {
        for (const auto& course : courses) {
            std::cout << "ID: " << course.id << ", Title: " << course.title << std::endl;
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourse(101, "Math");
    system.addCourse(102, "Science");
    
    std::cout << "All Students:" << std::endl;
    system.displayStudents();
    
    std::cout << "All Courses:" << std::endl;
    system.displayCourses();

    std::cout << "Search Student ID 1:" << std::endl;
    system.searchStudent(1);

    std::cout << "Search Course ID 102:" << std::endl;
    system.searchCourse(102);

    std::cout << "Update Student ID 1:" << std::endl;
    system.updateStudent(1, "Alice Smith");
    
    std::cout << "Update Course ID 102:" << std::endl;
    system.updateCourse(102, "Physical Science");
    
    std::cout << "All Students after update:" << std::endl;
    system.displayStudents();
    
    std::cout << "All Courses after update:" << std::endl;
    system.displayCourses();

    system.deleteStudent(2);
    system.deleteCourse(101);

    std::cout << "All Students after deletion:" << std::endl;
    system.displayStudents();
    
    std::cout << "All Courses after deletion:" << std::endl;
    system.displayCourses();

    return 0;
}