#include <iostream>
#include <vector>
#include <string>

class Course {
public:
    std::string courseName;
    std::string courseCode;

    Course(std::string name, std::string code) : courseName(name), courseCode(code) {}
};

class Student {
public:
    int studentId;
    std::string name;
    std::vector<Course> courses;

    Student(int id, std::string name) : studentId(id), name(name) {}
};

class StudentRegistrationSystem {
private:
    std::vector<Student> students;

public:
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void addCourseToStudent(int studentId, std::string courseName, std::string courseCode) {
        for (auto &student : students) {
            if (student.studentId == studentId) {
                student.courses.push_back(Course(courseName, courseCode));
                return;
            }
        }
    }

    void deleteStudent(int studentId) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentId == studentId) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudentName(int studentId, std::string newName) {
        for (auto &student : students) {
            if (student.studentId == studentId) {
                student.name = newName;
                return;
            }
        }
    }

    void updateCourseForStudent(int studentId, std::string oldCourseCode, std::string newCourseName, std::string newCourseCode) {
        for (auto &student : students) {
            if (student.studentId == studentId) {
                for (auto &course : student.courses) {
                    if (course.courseCode == oldCourseCode) {
                        course.courseName = newCourseName;
                        course.courseCode = newCourseCode;
                        return;
                    }
                }
            }
        }
    }

    void searchStudent(int studentId) {
        for (const auto &student : students) {
            if (student.studentId == studentId) {
                std::cout << "Student ID: " << student.studentId << std::endl;
                std::cout << "Name: " << student.name << std::endl;
                for (const auto &course : student.courses) {
                    std::cout << "Course Name: " << course.courseName << ", Course Code: " << course.courseCode << std::endl;
                }
                return;
            }
        }
        std::cout << "Student not found." << std::endl;
    }

    void displayAllStudents() {
        for (const auto &student : students) {
            std::cout << "Student ID: " << student.studentId << ", Name: " << student.name << std::endl;
            for (const auto &course : student.courses) {
                std::cout << "\tCourse Name: " << course.courseName << ", Course Code: " << course.courseCode << std::endl;
            }
        }
    }
};

int main() {
    StudentRegistrationSystem srs;
    srs.addStudent(1, "John Doe");
    srs.addCourseToStudent(1, "Mathematics", "MATH101");
    srs.addCourseToStudent(1, "Physics", "PHY101");

    srs.addStudent(2, "Jane Smith");
    srs.addCourseToStudent(2, "Chemistry", "CHEM101");

    srs.displayAllStudents();
    srs.searchStudent(1);
    srs.updateStudentName(1, "John D.");
    srs.updateCourseForStudent(1, "MATH101", "Advanced Mathematics", "MATH201");
    srs.deleteStudent(2);
    srs.displayAllStudents();
    return 0;
}