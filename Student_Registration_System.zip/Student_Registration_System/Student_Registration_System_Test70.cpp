#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    int courseId;
    string courseName;

    Course(int id, string name) : courseId(id), courseName(name) {}
};

class Student {
public:
    int studentId;
    string studentName;
    vector<Course> courses;

    Student(int id, string name) : studentId(id), studentName(name) {}

    void addCourse(Course course) {
        courses.push_back(course);
    }

    void removeCourse(int courseId) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseId == courseId) {
                courses.erase(it);
                break;
            }
        }
    }
};

class RegistrationSystem {
    vector<Student> students;
    vector<Course> courses;

public:
    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentId == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string newName) {
        for (auto &student : students) {
            if (student.studentId == id) {
                student.studentName = newName;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto &student : students) {
            if (student.studentId == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void addCourse(int id, string name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(int id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseId == id) {
                for (auto &student : students) {
                    student.removeCourse(id);
                }
                courses.erase(it);
                break;
            }
        }
    }

    void displayStudents() {
        for (const auto &student : students) {
            cout << "Student ID: " << student.studentId << ", Name: " << student.studentName << endl;
        }
    }

    void displayCourses() {
        for (const auto &course : courses) {
            cout << "Course ID: " << course.courseId << ", Name: " << course.courseName << endl;
        }
    }

    void displayStudentCourses(int studentId) {
        Student* student = searchStudent(studentId);
        if (student) {
            cout << "Courses for " << student->studentName << ":" << endl;
            for (const auto &course : student->courses) {
                cout << "Course ID: " << course.courseId << ", Name: " << course.courseName << endl;
            }
        } else {
            cout << "Student not found." << endl;
        }
    }

    void enrollStudentInCourse(int studentId, int courseId) {
        Student* student = searchStudent(studentId);
        if (student) {
            for (const auto &course : courses) {
                if (course.courseId == courseId) {
                    student->addCourse(course);
                    break;
                }
            }
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "John Doe");
    system.addCourse(101, "Math");
    system.enrollStudentInCourse(1, 101);
    system.displayStudents();
    system.displayCourses();
    system.displayStudentCourses(1);
    return 0;
}