#include <iostream>
#include <vector>
#include <string>

class Student {
public:
    int id;
    std::string name;
    std::vector<std::string> courses;
    
    Student(int id, std::string name) : id(id), name(name) {}
};

class Course {
public:
    std::string code;
    std::string title;
    
    Course(std::string code, std::string title) : code(code), title(title) {}
};

class RegistrationSystem {
private:
    std::vector<Student> students;
    std::vector<Course> courses;
    
public:
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string newName) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto &student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << " Name: " << student.name << "\nCourses: ";
                for (const auto &course : student.courses)
                    std::cout << course << " ";
                std::cout << std::endl;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }

    void displayStudents() {
        for (const auto &student : students) {
            std::cout << "Student ID: " << student.id << " Name: " << student.name << "\nCourses: ";
            for (const auto &course : student.courses)
                std::cout << course << " ";
            std::cout << std::endl;
        }
    }

    void addCourse(std::string code, std::string title) {
        courses.push_back(Course(code, title));
    }

    void deleteCourse(std::string code) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->code == code) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(std::string code, std::string newTitle) {
        for (auto &course : courses) {
            if (course.code == code) {
                course.title = newTitle;
                break;
            }
        }
    }

    void searchCourse(std::string code) {
        for (const auto &course : courses) {
            if (course.code == code) {
                std::cout << "Course Code: " << course.code << " Title: " << course.title << std::endl;
                return;
            }
        }
        std::cout << "Course not found" << std::endl;
    }

    void displayCourses() {
        for (const auto &course : courses) {
            std::cout << "Course Code: " << course.code << " Title: " << course.title << std::endl;
        }
    }

    void registerStudentToCourse(int studentId, std::string courseCode) {
        for (auto &student : students) {
            if (student.id == studentId) {
                student.courses.push_back(courseCode);
                break;
            }
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "John Doe");
    system.addStudent(2, "Jane Smith");

    system.addCourse("CS101", "Intro to Programming");
    system.addCourse("MATH123", "Calculus I");

    system.registerStudentToCourse(1, "CS101");

    system.displayStudents();
    system.displayCourses();

    return 0;
}