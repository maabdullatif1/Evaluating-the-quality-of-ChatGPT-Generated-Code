#include <iostream>
#include <vector>
#include <string>

struct Course {
    int courseId;
    std::string courseName;
};

struct Student {
    int studentId;
    std::string studentName;
    std::vector<Course> courses;
};

class RegistrationSystem {
public:
    void addStudent(int studentId, const std::string& studentName) {
        students.push_back({studentId, studentName, {}});
    }

    void deleteStudent(int studentId) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentId == studentId) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(int studentId, const std::string& newName) {
        for (auto& student : students) {
            if (student.studentId == studentId) {
                student.studentName = newName;
                return;
            }
        }
    }

    Student* searchStudent(int studentId) {
        for (auto& student : students) {
            if (student.studentId == studentId) return &student;
        }
        return nullptr;
    }

    void addCourseToStudent(int studentId, int courseId, const std::string& courseName) {
        Student* student = searchStudent(studentId);
        if (student) {
            student->courses.push_back({courseId, courseName});
        }
    }

    void deleteCourseFromStudent(int studentId, int courseId) {
        Student* student = searchStudent(studentId);
        if (student) {
            for (auto it = student->courses.begin(); it != student->courses.end(); ++it) {
                if (it->courseId == courseId) {
                    student->courses.erase(it);
                    return;
                }
            }
        }
    }

    void updateCourseOfStudent(int studentId, int courseId, const std::string& newCourseName) {
        Student* student = searchStudent(studentId);
        if (student) {
            for (auto& course : student->courses) {
                if (course.courseId == courseId) {
                    course.courseName = newCourseName;
                    return;
                }
            }
        }
    }

    void displayStudent(int studentId) {
        Student* student = searchStudent(studentId);
        if (student) {
            std::cout << "Student ID: " << student->studentId 
                      << ", Name: " << student->studentName << "\nCourses:\n";
            for (const auto& course : student->courses) {
                std::cout << "- Course ID: " << course.courseId 
                          << ", Course Name: " << course.courseName << "\n";
            }
        }
    }

    void displayAllStudents() {
        for (const auto& student : students) {
            displayStudent(student.studentId);
        }
    }

private:
    std::vector<Student> students;
};

int main() {
    RegistrationSystem system;
    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.addCourseToStudent(1, 101, "Math");
    system.addCourseToStudent(1, 102, "English");
    system.displayAllStudents();
    system.updateStudent(1, "Alicia");
    system.updateCourseOfStudent(1, 101, "Advanced Math");
    system.displayStudent(1);
    system.deleteCourseFromStudent(1, 101);
    system.displayStudent(1);
    system.deleteStudent(2);
    system.displayAllStudents();
    return 0;
}