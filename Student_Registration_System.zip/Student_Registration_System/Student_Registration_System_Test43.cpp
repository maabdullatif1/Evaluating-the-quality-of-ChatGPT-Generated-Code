#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    int courseID;
    string courseName;

    Course(int id, string name) : courseID(id), courseName(name) {}
};

class Student {
public:
    int studentID;
    string studentName;
    vector<Course> courses;

    Student(int id, string name) : studentID(id), studentName(name) {}
};

vector<Student> students;
vector<Course> courses;

void addStudent() {
    int id;
    string name;
    cout << "Enter student ID: ";
    cin >> id;
    cout << "Enter student name: ";
    cin >> name;
    students.push_back(Student(id, name));
}

void deleteStudent() {
    int id;
    cout << "Enter student ID to delete: ";
    cin >> id;
    for (auto it = students.begin(); it != students.end(); ++it) {
        if (it->studentID == id) {
            students.erase(it);
            break;
        }
    }
}

void updateStudent() {
    int id;
    cout << "Enter student ID to update: ";
    cin >> id;
    for (auto& student : students) {
        if (student.studentID == id) {
            string name;
            cout << "Enter new student name: ";
            cin >> name;
            student.studentName = name;
            break;
        }
    }
}

void searchStudent() {
    int id;
    cout << "Enter student ID to search: ";
    cin >> id;
    for (const auto& student : students) {
        if (student.studentID == id) {
            cout << "Student ID: " << student.studentID << ", Name: " << student.studentName << "\n";
            break;
        }
    }
}

void displayStudents() {
    for (const auto& student : students) {
        cout << "Student ID: " << student.studentID << ", Name: " << student.studentName << "\n";
    }
}

void addCourse() {
    int id;
    string name;
    cout << "Enter course ID: ";
    cin >> id;
    cout << "Enter course name: ";
    cin >> name;
    courses.push_back(Course(id, name));
}

void deleteCourse() {
    int id;
    cout << "Enter course ID to delete: ";
    cin >> id;
    for (auto it = courses.begin(); it != courses.end(); ++it) {
        if (it->courseID == id) {
            courses.erase(it);
            break;
        }
    }
}

void updateCourse() {
    int id;
    cout << "Enter course ID to update: ";
    cin >> id;
    for (auto& course : courses) {
        if (course.courseID == id) {
            string name;
            cout << "Enter new course name: ";
            cin >> name;
            course.courseName = name;
            break;
        }
    }
}

void searchCourse() {
    int id;
    cout << "Enter course ID to search: ";
    cin >> id;
    for (const auto& course : courses) {
        if (course.courseID == id) {
            cout << "Course ID: " << course.courseID << ", Name: " << course.courseName << "\n";
            break;
        }
    }
}

void displayCourses() {
    for (const auto& course : courses) {
        cout << "Course ID: " << course.courseID << ", Name: " << course.courseName << "\n";
    }
}

int main() {
    while (true) {
        int choice;
        cout << "1. Add Student\n2. Delete Student\n3. Update Student\n4. Search Student\n";
        cout << "5. Display Students\n6. Add Course\n7. Delete Course\n8. Update Course\n";
        cout << "9. Search Course\n10. Display Courses\n11. Exit\nSelect an option: ";
        cin >> choice;

        switch (choice) {
        case 1: addStudent(); break;
        case 2: deleteStudent(); break;
        case 3: updateStudent(); break;
        case 4: searchStudent(); break;
        case 5: displayStudents(); break;
        case 6: addCourse(); break;
        case 7: deleteCourse(); break;
        case 8: updateCourse(); break;
        case 9: searchCourse(); break;
        case 10: displayCourses(); break;
        case 11: return 0;
        default: cout << "Invalid option\n"; break;
        }
    }
    return 0;
}