#include <iostream>
#include <string>

#define MAX_STUDENTS 100
#define MAX_COURSES 50

struct Student {
    int id;
    std::string name;
};

struct Course {
    int code;
    std::string title;
};

Student students[MAX_STUDENTS];
Course courses[MAX_COURSES];
int studentCount = 0;
int courseCount = 0;

void addStudent(int id, std::string name) {
    if (studentCount < MAX_STUDENTS) {
        students[studentCount++] = {id, name};
    }
}

void deleteStudent(int id) {
    for (int i = 0; i < studentCount; i++) {
        if (students[i].id == id) {
            for (int j = i; j < studentCount - 1; j++) {
                students[j] = students[j + 1];
            }
            studentCount--;
            break;
        }
    }
}

void updateStudent(int id, std::string newName) {
    for (int i = 0; i < studentCount; i++) {
        if (students[i].id == id) {
            students[i].name = newName;
            break;
        }
    }
}

void searchStudent(int id) {
    for (int i = 0; i < studentCount; i++) {
        if (students[i].id == id) {
            std::cout << "Student ID: " << students[i].id << ", Name: " << students[i].name << std::endl;
            return;
        }
    }
    std::cout << "Student not found.\n";
}

void displayStudents() {
    for (int i = 0; i < studentCount; i++) {
        std::cout << "Student ID: " << students[i].id << ", Name: " << students[i].name << std::endl;
    }
}

void addCourse(int code, std::string title) {
    if (courseCount < MAX_COURSES) {
        courses[courseCount++] = {code, title};
    }
}

void deleteCourse(int code) {
    for (int i = 0; i < courseCount; i++) {
        if (courses[i].code == code) {
            for (int j = i; j < courseCount - 1; j++) {
                courses[j] = courses[j + 1];
            }
            courseCount--;
            break;
        }
    }
}

void updateCourse(int code, std::string newTitle) {
    for (int i = 0; i < courseCount; i++) {
        if (courses[i].code == code) {
            courses[i].title = newTitle;
            break;
        }
    }
}

void searchCourse(int code) {
    for (int i = 0; i < courseCount; i++) {
        if (courses[i].code == code) {
            std::cout << "Course Code: " << courses[i].code << ", Title: " << courses[i].title << std::endl;
            return;
        }
    }
    std::cout << "Course not found.\n";
}

void displayCourses() {
    for (int i = 0; i < courseCount; i++) {
        std::cout << "Course Code: " << courses[i].code << ", Title: " << courses[i].title << std::endl;
    }
}

int main() {
    addStudent(1, "Alice");
    addStudent(2, "Bob");
    displayStudents();
    updateStudent(1, "Alice Smith");
    searchStudent(1);
    deleteStudent(2);
    displayStudents();

    addCourse(101, "Mathematics");
    addCourse(102, "Physics");
    displayCourses();
    updateCourse(101, "Advanced Mathematics");
    searchCourse(101);
    deleteCourse(102);
    displayCourses();

    return 0;
}