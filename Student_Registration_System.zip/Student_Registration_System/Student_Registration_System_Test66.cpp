#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Course {
public:
    string courseID;
    string courseName;

    Course(string id, string name) : courseID(id), courseName(name) {}

    void display() {
        cout << "Course ID: " << courseID << ", Course Name: " << courseName << endl;
    }
};

class Student {
public:
    string studentID;
    string studentName;
    vector<Course> enrolledCourses;

    Student(string id, string name) : studentID(id), studentName(name) {}

    void display() {
        cout << "Student ID: " << studentID << ", Student Name: " << studentName << endl;
    }

    void displayCourses() {
        for (Course &course : enrolledCourses) {
            course.display();
        }
    }

    void addCourse(Course &course) {
        enrolledCourses.push_back(course);
    }

    void removeCourse(const string &courseID) {
        for (auto it = enrolledCourses.begin(); it != enrolledCourses.end(); ++it) {
            if (it->courseID == courseID) {
                enrolledCourses.erase(it);
                break;
            }
        }
    }
};

class RegistrationSystem {
private:
    vector<Student> students;
    vector<Course> courses;

public:
    void addStudent(const string &id, const string &name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(const string &id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(const string &id, const string &newName) {
        for (auto &student : students) {
            if (student.studentID == id) {
                student.studentName = newName;
                break;
            }
        }
    }

    void searchStudent(const string &id) {
        for (const auto &student : students) {
            if (student.studentID == id) {
                student.display();
                student.displayCourses();
                break;
            }
        }
    }

    void displayStudents() {
        for (const auto &student : students) {
            student.display();
        }
    }

    void addCourse(const string &id, const string &name) {
        courses.push_back(Course(id, name));
    }

    void deleteCourse(const string &id) {
        for (auto it = courses.begin(); it != courses.end(); ++it) {
            if (it->courseID == id) {
                courses.erase(it);
                break;
            }
        }
    }

    void updateCourse(const string &id, const string &newName) {
        for (auto &course : courses) {
            if (course.courseID == id) {
                course.courseName = newName;
                break;
            }
        }
    }

    void searchCourse(const string &id) {
        for (const auto &course : courses) {
            if (course.courseID == id) {
                course.display();
                break;
            }
        }
    }

    void displayCourses() {
        for (const auto &course : courses) {
            course.display();
        }
    }

    void enrollStudentInCourse(const string &studentID, const string &courseID) {
        Student *studentPtr = nullptr;
        Course *coursePtr = nullptr;

        for (auto &student : students) {
            if (student.studentID == studentID) {
                studentPtr = &student;
                break;
            }
        }

        for (auto &course : courses) {
            if (course.courseID == courseID) {
                coursePtr = &course;
                break;
            }
        }

        if (studentPtr && coursePtr) {
            studentPtr->addCourse(*coursePtr);
        }
    }

    void unenrollStudentFromCourse(const string &studentID, const string &courseID) {
        for (auto &student : students) {
            if (student.studentID == studentID) {
                student.removeCourse(courseID);
                break;
            }
        }
    }
};

int main() {
    RegistrationSystem system;
    system.addStudent("S001", "John Doe");
    system.addCourse("C001", "Mathematics");
    system.enrollStudentInCourse("S001", "C001");
    system.displayStudents();
    system.displayCourses();
    system.searchStudent("S001");
    system.searchCourse("C001");
    system.updateStudent("S001", "John Smith");
    system.updateCourse("C001", "Advanced Mathematics");
    system.unenrollStudentFromCourse("S001", "C001");
    system.deleteStudent("S001");
    system.deleteCourse("C001");
    return 0;
}