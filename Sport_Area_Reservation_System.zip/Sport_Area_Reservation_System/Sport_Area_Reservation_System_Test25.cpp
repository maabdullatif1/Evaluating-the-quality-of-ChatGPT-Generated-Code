#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string contact;
    
    Customer(int id, const string &name, const string &contact) 
        : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    string name;
    string type;
    int capacity;
    
    SportArea(int id, const string &name, const string &type, int capacity) 
        : id(id), name(name), type(type), capacity(capacity) {}
};

class ReservationSystem {
public:
    vector<Customer> customers;
    vector<SportArea> sportAreas;
    
    void addCustomer(int id, const string &name, const string &contact) {
        customers.push_back(Customer(id, name, contact));
    }
    
    void deleteCustomer(int id) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) {
                customers.erase(customers.begin() + i);
                break;
            }
        }
    }
    
    void updateCustomer(int id, const string &name, const string &contact) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) {
                customers[i].name = name;
                customers[i].contact = contact;
                break;
            }
        }
    }
    
    Customer* searchCustomer(int id) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) {
                return &customers[i];
            }
        }
        return nullptr;
    }
    
    void displayCustomers() {
        for (size_t i = 0; i < customers.size(); ++i) {
            cout << "ID: " << customers[i].id << ", Name: " << customers[i].name 
                 << ", Contact: " << customers[i].contact << endl;
        }
    }
    
    void addSportArea(int id, const string &name, const string &type, int capacity) {
        sportAreas.push_back(SportArea(id, name, type, capacity));
    }
    
    void deleteSportArea(int id) {
        for (size_t i = 0; i < sportAreas.size(); ++i) {
            if (sportAreas[i].id == id) {
                sportAreas.erase(sportAreas.begin() + i);
                break;
            }
        }
    }
    
    void updateSportArea(int id, const string &name, const string &type, int capacity) {
        for (size_t i = 0; i < sportAreas.size(); ++i) {
            if (sportAreas[i].id == id) {
                sportAreas[i].name = name;
                sportAreas[i].type = type;
                sportAreas[i].capacity = capacity;
                break;
            }
        }
    }
    
    SportArea* searchSportArea(int id) {
        for (size_t i = 0; i < sportAreas.size(); ++i) {
            if (sportAreas[i].id == id) {
                return &sportAreas[i];
            }
        }
        return nullptr;
    }
    
    void displaySportAreas() {
        for (size_t i = 0; i < sportAreas.size(); ++i) {
            cout << "ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name 
                 << ", Type: " << sportAreas[i].type << ", Capacity: " << sportAreas[i].capacity << endl;
        }
    }
};

int main() {
    ReservationSystem rs;
    
    rs.addCustomer(1, "Alice", "alice@example.com");
    rs.addCustomer(2, "Bob", "bob@example.com");
    
    rs.addSportArea(1, "Court 1", "Tennis", 4);
    rs.addSportArea(2, "Pool", "Swimming", 20);
    
    rs.displayCustomers();
    rs.displaySportAreas();
    
    rs.updateCustomer(1, "Alice Wonderland", "alicew@example.com");
    rs.updateSportArea(1, "Court 1", "Squash", 4);
    
    rs.displayCustomers();
    rs.displaySportAreas();
    
    rs.deleteCustomer(2);
    rs.deleteSportArea(2);
    
    rs.displayCustomers();
    rs.displaySportAreas();
    
    return 0;
}