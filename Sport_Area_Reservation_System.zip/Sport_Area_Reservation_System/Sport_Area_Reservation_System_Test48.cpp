#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string contact;

    Customer(int id, string name, string contact) : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    string name;
    bool isBooked;

    SportArea(int id, string name) : id(id), name(name), isBooked(false) {}
};

class ReservationSystem {
    vector<Customer> customers;
    vector<SportArea> sportAreas;

public:
    void addCustomer(int id, string name, string contact) {
        customers.emplace_back(id, name, contact);
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void updateCustomer(int id, string newName, string newContact) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = newName;
                customer.contact = newContact;
                return;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
        }
    }

    void addSportArea(int id, string name) {
        sportAreas.emplace_back(id, name);
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                return;
            }
        }
    }

    void updateSportArea(int id, string newName) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                area.name = newName;
                return;
            }
        }
    }

    SportArea* searchSportArea(int id) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                return &area;
            }
        }
        return nullptr;
    }

    void displaySportAreas() {
        for (const auto& area : sportAreas) {
            cout << "ID: " << area.id << ", Name: " << area.name << ", Booked: " << (area.isBooked ? "Yes" : "No") << endl;
        }
    }

    void bookSportArea(int sportAreaId) {
        for (auto& area : sportAreas) {
            if (area.id == sportAreaId) {
                if (!area.isBooked) {
                    area.isBooked = true;
                    return;
                } else {
                    cout << "Sport area already booked." << endl;
                    return;
                }
            }
        }
    }

    void unbookSportArea(int sportAreaId) {
        for (auto& area : sportAreas) {
            if (area.id == sportAreaId) {
                if (area.isBooked) {
                    area.isBooked = false;
                    return;
                } else {
                    cout << "Sport area is not booked." << endl;
                    return;
                }
            }
        }
    }
};

int main() {
    ReservationSystem system;

    system.addCustomer(1, "John Doe", "john@example.com");
    system.addCustomer(2, "Jane Smith", "jane@example.com");

    system.addSportArea(1, "Tennis Court");
    system.addSportArea(2, "Football Field");

    system.displayCustomers();
    system.displaySportAreas();

    system.bookSportArea(1);
    system.displaySportAreas();

    system.unbookSportArea(1);
    system.displaySportAreas();

    return 0;
}