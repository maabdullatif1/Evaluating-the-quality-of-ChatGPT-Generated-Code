#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string phone;
    Customer(int c_id, std::string c_name, std::string c_phone)
        : id(c_id), name(c_name), phone(c_phone) {}
};

class SportArea {
public:
    int id;
    std::string name;
    std::string type;
    SportArea(int sa_id, std::string sa_name, std::string sa_type)
        : id(sa_id), name(sa_name), type(sa_type) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
    
public:
    void addCustomer(int id, std::string name, std::string phone) {
        customers.push_back(Customer(id, name, phone));
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, std::string name, std::string phone) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phone = phone;
                break;
            }
        }
    }
    
    void searchCustomer(int id) {
        for (const auto &customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer: " << customer.id << ", " << customer.name << ", " << customer.phone << std::endl;
                return;
            }
        }
        std::cout << "Customer not found." << std::endl;
    }
    
    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "Customer: " << customer.id << ", " << customer.name << ", " << customer.phone << std::endl;
        }
    }
    
    void addSportArea(int id, std::string name, std::string type) {
        sportAreas.push_back(SportArea(id, name, type));
    }
    
    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }
    
    void updateSportArea(int id, std::string name, std::string type) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.type = type;
                break;
            }
        }
    }
    
    void searchSportArea(int id) {
        for (const auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                std::cout << "Sport Area: " << sportArea.id << ", " << sportArea.name << ", " << sportArea.type << std::endl;
                return;
            }
        }
        std::cout << "Sport Area not found." << std::endl;
    }
    
    void displaySportAreas() {
        for (const auto &sportArea : sportAreas) {
            std::cout << "Sport Area: " << sportArea.id << ", " << sportArea.name << ", " << sportArea.type << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    
    system.addCustomer(1, "John Doe", "123-456-7890");
    system.addCustomer(2, "Jane Smith", "987-654-3210");
    system.addSportArea(1, "Basketball Court", "Indoor");
    system.addSportArea(2, "Tennis Court", "Outdoor");

    std::cout << "Customers:" << std::endl;
    system.displayCustomers();
    std::cout << "\nSport Areas:" << std::endl;
    system.displaySportAreas();
    
    std::cout << "\nSearching for Customer ID 1:" << std::endl;
    system.searchCustomer(1);

    std::cout << "\nSearching for Sport Area ID 2:" << std::endl;
    system.searchSportArea(2);

    system.updateCustomer(1, "John Doe Updated", "321-654-0987");
    system.updateSportArea(1, "Basketball Court Updated", "Outdoor");

    std::cout << "\nUpdated Customers:" << std::endl;
    system.displayCustomers();
    std::cout << "\nUpdated Sport Areas:" << std::endl;
    system.displaySportAreas();
    
    system.deleteCustomer(2);
    system.deleteSportArea(2);

    std::cout << "\nFinal Customers:" << std::endl;
    system.displayCustomers();
    std::cout << "\nFinal Sport Areas:" << std::endl;
    system.displaySportAreas();

    return 0;
}