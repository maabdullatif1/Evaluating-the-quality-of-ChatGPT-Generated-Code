#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct SportArea {
    int id;
    string name;
    bool isAvailable;
};

vector<Customer> customers;
vector<SportArea> sportAreas;

void addCustomer(int id, string name, string phone) {
    customers.push_back({id, name, phone});
}

void deleteCustomer(int id) {
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            break;
        }
    }
}

void updateCustomer(int id, string name, string phone) {
    for (auto &customer : customers) {
        if (customer.id == id) {
            customer.name = name;
            customer.phone = phone;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (auto &customer : customers) {
        if (customer.id == id) {
            return &customer;
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (const auto &customer : customers) {
        cout << "ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << endl;
    }
}

void addSportArea(int id, string name, bool isAvailable) {
    sportAreas.push_back({id, name, isAvailable});
}

void deleteSportArea(int id) {
    for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
        if (it->id == id) {
            sportAreas.erase(it);
            break;
        }
    }
}

void updateSportArea(int id, string name, bool isAvailable) {
    for (auto &area : sportAreas) {
        if (area.id == id) {
            area.name = name;
            area.isAvailable = isAvailable;
            break;
        }
    }
}

SportArea* searchSportArea(int id) {
    for (auto &area : sportAreas) {
        if (area.id == id) {
            return &area;
        }
    }
    return nullptr;
}

void displaySportAreas() {
    for (const auto &area : sportAreas) {
        cout << "ID: " << area.id << ", Name: " << area.name << ", Available: " << (area.isAvailable ? "Yes" : "No") << endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "123-456-7890");
    addCustomer(2, "Jane Smith", "098-765-4321");
    addSportArea(1, "Basketball Court", true);
    addSportArea(2, "Swimming Pool", false);

    displayCustomers();
    displaySportAreas();

    Customer* customer = searchCustomer(1);
    if (customer != nullptr) {
        cout << "Found customer: " << customer->name << endl;
    }

    SportArea* area = searchSportArea(2);
    if (area != nullptr) {
        cout << "Found sport area: " << area->name << ", Available: " << (area->isAvailable ? "Yes" : "No") << endl;
    }

    updateCustomer(1, "John Doe Jr.", "111-222-3333");
    updateSportArea(1, "Basketball Court", false);
    displayCustomers();
    displaySportAreas();

    deleteCustomer(2);
    deleteSportArea(2);
    displayCustomers();
    displaySportAreas();

    return 0;
}