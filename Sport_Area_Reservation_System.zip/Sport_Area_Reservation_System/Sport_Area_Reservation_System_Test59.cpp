#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string contact;
    
    Customer(int id, string name, string contact) : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    string name;
    bool isReserved;
    
    SportArea(int id, string name) : id(id), name(name), isReserved(false) {}
};

class ReservationSystem {
    vector<Customer> customers;
    vector<SportArea> sportAreas;
    int customerCounter;
    int sportAreaCounter;
    
public:
    ReservationSystem() : customerCounter(1), sportAreaCounter(1) {}
    
    void addCustomer(string name, string contact) {
        customers.push_back(Customer(customerCounter++, name, contact));
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, string name, string contact) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }
    
    void searchCustomer(int id) {
        for (const auto &customer : customers) {
            if (customer.id == id) {
                cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
                return;
            }
        }
        cout << "Customer not found" << endl;
    }
    
    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
        }
    }
    
    void addSportArea(string name) {
        sportAreas.push_back(SportArea(sportAreaCounter++, name));
    }
    
    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }
    
    void updateSportArea(int id, string name) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                break;
            }
        }
    }
    
    void searchSportArea(int id) {
        for (const auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                cout << "Sport Area ID: " << sportArea.id << ", Name: " << sportArea.name << ", Reserved: " << (sportArea.isReserved ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Sport area not found" << endl;
    }
    
    void displaySportAreas() {
        for (const auto &sportArea : sportAreas) {
            cout << "Sport Area ID: " << sportArea.id << ", Name: " << sportArea.name << ", Reserved: " << (sportArea.isReserved ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    
    system.addCustomer("John Doe", "123-456-7890");
    system.addCustomer("Jane Smith", "098-765-4321");
    system.displayCustomers();
    
    system.addSportArea("Basketball Court");
    system.addSportArea("Tennis Court");
    system.displaySportAreas();
    
    system.searchCustomer(1);
    system.searchSportArea(2);
    
    system.updateCustomer(1, "Johnathan Doe", "321-654-0987");
    system.updateSportArea(1, "Football Field");
    
    system.displayCustomers();
    system.displaySportAreas();
    
    system.deleteCustomer(2);
    system.deleteSportArea(1);
    
    system.displayCustomers();
    system.displaySportAreas();
    
    return 0;
}