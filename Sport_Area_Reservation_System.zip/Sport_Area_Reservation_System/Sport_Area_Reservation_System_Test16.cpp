#include <iostream>
#include <string>
using namespace std;

const int MAX = 100;

struct Customer {
    int id;
    string name;
    string phone;
};

struct SportArea {
    int id;
    string name;
    string type;
};

Customer customers[MAX];
SportArea sportAreas[MAX];

int customerCount = 0;
int sportAreaCount = 0;

void addCustomer(int id, string name, string phone) {
    if (customerCount < MAX) {
        customers[customerCount++] = {id, name, phone};
    }
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; j++) {
                customers[j] = customers[j + 1];
            }
            customerCount--;
            break;
        }
    }
}

void updateCustomer(int id, string name, string phone) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            customers[i].name = name;
            customers[i].phone = phone;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; i++) {
        cout << "ID: " << customers[i].id << ", Name: " << customers[i].name << ", Phone: " << customers[i].phone << endl;
    }
}

void addSportArea(int id, string name, string type) {
    if (sportAreaCount < MAX) {
        sportAreas[sportAreaCount++] = {id, name, type};
    }
}

void deleteSportArea(int id) {
    for (int i = 0; i < sportAreaCount; i++) {
        if (sportAreas[i].id == id) {
            for (int j = i; j < sportAreaCount - 1; j++) {
                sportAreas[j] = sportAreas[j + 1];
            }
            sportAreaCount--;
            break;
        }
    }
}

void updateSportArea(int id, string name, string type) {
    for (int i = 0; i < sportAreaCount; i++) {
        if (sportAreas[i].id == id) {
            sportAreas[i].name = name;
            sportAreas[i].type = type;
            break;
        }
    }
}

SportArea* searchSportArea(int id) {
    for (int i = 0; i < sportAreaCount; i++) {
        if (sportAreas[i].id == id) {
            return &sportAreas[i];
        }
    }
    return nullptr;
}

void displaySportAreas() {
    for (int i = 0; i < sportAreaCount; i++) {
        cout << "ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name << ", Type: " << sportAreas[i].type << endl;
    }
}

int main() {
    addCustomer(1, "Alice", "123456789");
    addCustomer(2, "Bob", "987654321");
    displayCustomers();
    addSportArea(1, "Gym", "Fitness");
    addSportArea(2, "Pool", "Swimming");
    displaySportAreas();
    updateCustomer(1, "Alice Smith", "123456000");
    displayCustomers();
    deleteCustomer(2);
    displayCustomers();
    updateSportArea(1, "Fitness Center", "Fitness");
    displaySportAreas();
    deleteSportArea(2);
    displaySportAreas();
    return 0;
}