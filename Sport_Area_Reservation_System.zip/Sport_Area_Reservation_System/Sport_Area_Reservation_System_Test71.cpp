#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;

    Customer(int i, std::string n, std::string c) : id(i), name(n), contact(c) {}
};

class SportArea {
public:
    int id;
    std::string name;
    std::string location;

    SportArea(int i, std::string n, std::string l) : id(i), name(n), location(l) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;

    Customer* findCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    SportArea* findSportArea(int id) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                return &area;
            }
        }
        return nullptr;
    }

public:
    void addCustomer(int id, std::string name, std::string contact) {
        customers.emplace_back(id, name, contact);
    }

    void deleteCustomer(int id) {
        customers.erase(std::remove_if(customers.begin(), customers.end(),
            [&](Customer& c) { return c.id == id; }), customers.end());
    }

    void updateCustomer(int id, std::string name, std::string contact) {
        Customer* customer = findCustomer(id);
        if (customer) {
            customer->name = name;
            customer->contact = contact;
        }
    }

    void searchCustomer(int id) {
        Customer* customer = findCustomer(id);
        if (customer) {
            std::cout << "Customer ID: " << customer->id << ", Name: " << customer->name << ", Contact: " << customer->contact << "\n";
        } else {
            std::cout << "Customer not found\n";
        }
    }

    void displayAllCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << "\n";
        }
    }

    void addSportArea(int id, std::string name, std::string location) {
        sportAreas.emplace_back(id, name, location);
    }

    void deleteSportArea(int id) {
        sportAreas.erase(std::remove_if(sportAreas.begin(), sportAreas.end(),
            [&](SportArea& a) { return a.id == id; }), sportAreas.end());
    }

    void updateSportArea(int id, std::string name, std::string location) {
        SportArea* area = findSportArea(id);
        if (area) {
            area->name = name;
            area->location = location;
        }
    }

    void searchSportArea(int id) {
        SportArea* area = findSportArea(id);
        if (area) {
            std::cout << "SportArea ID: " << area->id << ", Name: " << area->name << ", Location: " << area->location << "\n";
        } else {
            std::cout << "SportArea not found\n";
        }
    }

    void displayAllSportAreas() {
        for (const auto& area : sportAreas) {
            std::cout << "SportArea ID: " << area.id << ", Name: " << area.name << ", Location: " << area.location << "\n";
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "Alice", "123-456-7890");
    system.addSportArea(1, "Tennis Court", "North Wing");
    system.displayAllCustomers();
    system.displayAllSportAreas();
    system.searchCustomer(1);
    system.searchSportArea(1);
    system.updateCustomer(1, "Alice", "098-765-4321");
    system.updateSportArea(1, "Basketball Court", "South Wing");
    system.displayAllCustomers();
    system.displayAllSportAreas();
    system.deleteCustomer(1);
    system.deleteSportArea(1);
    system.displayAllCustomers();
    system.displayAllSportAreas();
    return 0;
}