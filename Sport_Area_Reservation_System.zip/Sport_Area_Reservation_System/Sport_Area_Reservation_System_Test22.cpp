#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct SportArea {
    int id;
    string name;
    bool isReserved;
    int reservedByCustomerId;
};

Customer customers[100];
SportArea sportAreas[100];
int customerCount = 0;
int sportAreaCount = 0;

void addCustomer(int id, string name, string phone) {
    customers[customerCount++] = {id, name, phone};
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; ++j) {
                customers[j] = customers[j + 1];
            }
            --customerCount;
            break;
        }
    }
}

void updateCustomer(int id, string name, string phone) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            customers[i].name = name;
            customers[i].phone = phone;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; ++i) {
        cout << "ID: " << customers[i].id << ", Name: " << customers[i].name << ", Phone: " << customers[i].phone << endl;
    }
}

void addSportArea(int id, string name) {
    sportAreas[sportAreaCount++] = {id, name, false, -1};
}

void deleteSportArea(int id) {
    for (int i = 0; i < sportAreaCount; ++i) {
        if (sportAreas[i].id == id) {
            for (int j = i; j < sportAreaCount - 1; ++j) {
                sportAreas[j] = sportAreas[j + 1];
            }
            --sportAreaCount;
            break;
        }
    }
}

void updateSportArea(int id, string name) {
    for (int i = 0; i < sportAreaCount; ++i) {
        if (sportAreas[i].id == id) {
            sportAreas[i].name = name;
            break;
        }
    }
}

SportArea* searchSportArea(int id) {
    for (int i = 0; i < sportAreaCount; ++i) {
        if (sportAreas[i].id == id) {
            return &sportAreas[i];
        }
    }
    return nullptr;
}

void displaySportAreas() {
    for (int i = 0; i < sportAreaCount; ++i) {
        cout << "ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name;
        cout << ", Reserved: " << (sportAreas[i].isReserved ? "Yes" : "No");
        if (sportAreas[i].isReserved) {
            cout << ", Reserved by Customer ID: " << sportAreas[i].reservedByCustomerId;
        }
        cout << endl;
    }
}

void reserveSportArea(int sportAreaId, int customerId) {
    SportArea* area = searchSportArea(sportAreaId);
    if (area && !area->isReserved) {
        area->isReserved = true;
        area->reservedByCustomerId = customerId;
    }
}

void cancelReservation(int sportAreaId) {
    SportArea* area = searchSportArea(sportAreaId);
    if (area && area->isReserved) {
        area->isReserved = false;
        area->reservedByCustomerId = -1;
    }
}

int main() {
    addCustomer(1, "John Doe", "555-5555");
    addCustomer(2, "Jane Smith", "555-1234");
    addSportArea(1, "Tennis Court");
    addSportArea(2, "Basketball Court");
    reserveSportArea(1, 1);
    displayCustomers();
    displaySportAreas();
    return 0;
}