#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;

    Customer(int id, std::string name, std::string contact) : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    std::string name;
    bool isReserved;

    SportArea(int id, std::string name, bool isReserved) : id(id), name(name), isReserved(isReserved) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;

public:
    void addCustomer(int id, std::string name, std::string contact) {
        customers.push_back(Customer(id, name, contact));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string contact) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name 
                          << ", Contact: " << customer.contact << std::endl;
                return;
            }
        }
        std::cout << "Customer not found" << std::endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name 
                      << ", Contact: " << customer.contact << std::endl;
        }
    }

    void addSportArea(int id, std::string name, bool isReserved) {
        sportAreas.push_back(SportArea(id, name, isReserved));
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, std::string name, bool isReserved) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                area.name = name;
                area.isReserved = isReserved;
                break;
            }
        }
    }

    void searchSportArea(int id) {
        for (const auto& area : sportAreas) {
            if (area.id == id) {
                std::cout << "Sport Area ID: " << area.id << ", Name: " << area.name 
                          << ", Reserved: " << (area.isReserved ? "Yes" : "No") << std::endl;
                return;
            }
        }
        std::cout << "Sport area not found" << std::endl;
    }

    void displaySportAreas() {
        for (const auto& area : sportAreas) {
            std::cout << "Sport Area ID: " << area.id << ", Name: " << area.name 
                      << ", Reserved: " << (area.isReserved ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "Alice", "123-456-7890");
    system.addCustomer(2, "Bob", "098-765-4321");
    system.displayCustomers();
    system.addSportArea(1, "Soccer Field", false);
    system.addSportArea(2, "Basketball Court", true);
    system.displaySportAreas();
    system.updateCustomer(1, "Alice Smith", "123-000-4567");
    system.searchCustomer(1);
    system.updateSportArea(1, "Soccer Field", true);
    system.searchSportArea(1);
    system.deleteCustomer(2);
    system.displayCustomers();
    system.deleteSportArea(2);
    system.displaySportAreas();
    return 0;
}