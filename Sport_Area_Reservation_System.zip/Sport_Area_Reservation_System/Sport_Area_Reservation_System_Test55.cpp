#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
};

struct SportArea {
    int id;
    string name;
};

vector<Customer> customers;
vector<SportArea> sportAreas;

void addCustomer(int id, string name) {
    customers.push_back({id, name});
}

void deleteCustomer(int id) {
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            break;
        }
    }
}

void updateCustomer(int id, string name) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            customer.name = name;
        }
    }
}

Customer* searchCustomer(int id) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            return &customer;
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (const auto& customer : customers) {
        cout << "Customer ID: " << customer.id << ", Name: " << customer.name << endl;
    }
}

void addSportArea(int id, string name) {
    sportAreas.push_back({id, name});
}

void deleteSportArea(int id) {
    for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
        if (it->id == id) {
            sportAreas.erase(it);
            break;
        }
    }
}

void updateSportArea(int id, string name) {
    for (auto& sportArea : sportAreas) {
        if (sportArea.id == id) {
            sportArea.name = name;
        }
    }
}

SportArea* searchSportArea(int id) {
    for (auto& sportArea : sportAreas) {
        if (sportArea.id == id) {
            return &sportArea;
        }
    }
    return nullptr;
}

void displaySportAreas() {
    for (const auto& sportArea : sportAreas) {
        cout << "Sport Area ID: " << sportArea.id << ", Name: " << sportArea.name << endl;
    }
}

int main() {
    addCustomer(1, "John Doe");
    addCustomer(2, "Jane Smith");
    displayCustomers();

    updateCustomer(1, "John Updated");
    displayCustomers();

    deleteCustomer(2);
    displayCustomers();

    addSportArea(1, "Tennis Court");
    addSportArea(2, "Swimming Pool");
    displaySportAreas();

    updateSportArea(2, "Olympic Pool");
    displaySportAreas();

    deleteSportArea(1);
    displaySportAreas();

    return 0;
}