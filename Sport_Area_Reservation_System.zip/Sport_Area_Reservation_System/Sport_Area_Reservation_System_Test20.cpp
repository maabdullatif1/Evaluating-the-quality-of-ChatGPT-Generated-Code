#include <iostream>
#include <vector>

struct Customer {
    int id;
    std::string name;
    std::string email;
};

struct SportArea {
    int id;
    std::string name;
    std::string location;
};

class System {
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
    int customerID = 0;
    int sportAreaID = 0;

public:
    void addCustomer(const std::string& name, const std::string& email) {
        customers.push_back({++customerID, name, email});
    }

    void addSportArea(const std::string& name, const std::string& location) {
        sportAreas.push_back({++sportAreaID, name, location});
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& email) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.email = email;
                break;
            }
        }
    }

    void updateSportArea(int id, const std::string& name, const std::string& location) {
        for (auto& sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.location = location;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    SportArea* searchSportArea(int id) {
        for (auto& sportArea : sportAreas) {
            if (sportArea.id == id) {
                return &sportArea;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Email: " << customer.email << std::endl;
        }
    }

    void displaySportAreas() {
        for (const auto& sportArea : sportAreas) {
            std::cout << "ID: " << sportArea.id << ", Name: " << sportArea.name << ", Location: " << sportArea.location << std::endl;
        }
    }
};

int main() {
    System system;

    system.addCustomer("Alice", "alice@example.com");
    system.addCustomer("Bob", "bob@example.com");
    system.addSportArea("Tennis Court", "Downtown");
    system.addSportArea("Swimming Pool", "Uptown");

    system.displayCustomers();
    system.displaySportAreas();

    return 0;
}