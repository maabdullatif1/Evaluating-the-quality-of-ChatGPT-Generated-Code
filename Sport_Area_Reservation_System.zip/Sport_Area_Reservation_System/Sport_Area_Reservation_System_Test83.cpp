#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;

    Customer(int i, std::string n, std::string c) : id(i), name(n), contact(c) {}
};

class SportArea {
public:
    int id;
    std::string name;
    std::string type;

    SportArea(int i, std::string n, std::string t) : id(i), name(n), type(t) {}
};

std::vector<Customer> customers;
std::vector<SportArea> sportAreas;

void addCustomer(int id, std::string name, std::string contact) {
    customers.push_back(Customer(id, name, contact));
}

void deleteCustomer(int id) {
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            break;
        }
    }
}

void updateCustomer(int id, std::string name, std::string contact) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            customer.name = name;
            customer.contact = contact;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            return &customer;
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (const auto& customer : customers) {
        std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << std::endl;
    }
}

void addSportArea(int id, std::string name, std::string type) {
    sportAreas.push_back(SportArea(id, name, type));
}

void deleteSportArea(int id) {
    for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
        if (it->id == id) {
            sportAreas.erase(it);
            break;
        }
    }
}

void updateSportArea(int id, std::string name, std::string type) {
    for (auto& sportArea : sportAreas) {
        if (sportArea.id == id) {
            sportArea.name = name;
            sportArea.type = type;
            break;
        }
    }
}

SportArea* searchSportArea(int id) {
    for (auto& sportArea : sportAreas) {
        if (sportArea.id == id) {
            return &sportArea;
        }
    }
    return nullptr;
}

void displaySportAreas() {
    for (const auto& sportArea : sportAreas) {
        std::cout << "ID: " << sportArea.id << ", Name: " << sportArea.name << ", Type: " << sportArea.type << std::endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "123-4567");
    addCustomer(2, "Jane Smith", "987-6543");
    displayCustomers();

    addSportArea(1, "Basketball Court", "Indoor");
    addSportArea(2, "Football Field", "Outdoor");
    displaySportAreas();

    return 0;
}