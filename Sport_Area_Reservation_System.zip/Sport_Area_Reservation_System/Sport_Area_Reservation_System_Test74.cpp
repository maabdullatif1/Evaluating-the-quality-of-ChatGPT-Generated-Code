#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;

    Customer(int id, const std::string& name, const std::string& contact)
        : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    std::string name;
    std::string type;

    SportArea(int id, const std::string& name, const std::string& type)
        : id(id), name(name), type(type) {}
};

class ReservationSystem {
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;

public:
    void addCustomer(int id, const std::string& name, const std::string& contact) {
        customers.push_back(Customer(id, name, contact));
    }

    void updateCustomer(int id, const std::string& name, const std::string& contact) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                return;
            }
        }
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << "\n";
                return;
            }
        }
        std::cout << "Customer not found\n";
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << "\n";
        }
    }

    void addSportArea(int id, const std::string& name, const std::string& type) {
        sportAreas.push_back(SportArea(id, name, type));
    }

    void updateSportArea(int id, const std::string& name, const std::string& type) {
        for (auto& sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.type = type;
                return;
            }
        }
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                return;
            }
        }
    }

    void searchSportArea(int id) {
        for (const auto& sportArea : sportAreas) {
            if (sportArea.id == id) {
                std::cout << "Sport Area ID: " << sportArea.id << ", Name: " << sportArea.name << ", Type: " << sportArea.type << "\n";
                return;
            }
        }
        std::cout << "Sport area not found\n";
    }

    void displaySportAreas() {
        for (const auto& sportArea : sportAreas) {
            std::cout << "Sport Area ID: " << sportArea.id << ", Name: " << sportArea.name << ", Type: " << sportArea.type << "\n";
        }
    }
};

int main() {
    ReservationSystem rs;
    rs.addCustomer(1, "Alice", "123-456-7890");
    rs.addCustomer(2, "Bob", "098-765-4321");
    rs.addSportArea(1, "Tennis Court", "Outdoor");
    rs.addSportArea(2, "Swimming Pool", "Indoor");
    rs.displayCustomers();
    rs.displaySportAreas();
    rs.updateCustomer(2, "Bobby", "111-222-3333");
    rs.searchCustomer(2);
    rs.deleteCustomer(1);
    rs.displayCustomers();
    rs.updateSportArea(1, "Tennis Court", "Indoor");
    rs.searchSportArea(1);
    rs.deleteSportArea(2);
    rs.displaySportAreas();
    return 0;
}