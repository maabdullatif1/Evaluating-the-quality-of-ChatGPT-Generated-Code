#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;

    Customer(int id, const std::string& name) : id(id), name(name) {}
};

class SportArea {
public:
    int id;
    std::string name;

    SportArea(int id, const std::string& name) : id(id), name(name) {}
};

class ReservationSystem {
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
    
public:
    void addCustomer(int id, const std::string& name) {
        customers.push_back(Customer(id, name));
    }

    void deleteCustomer(int id) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) {
                customers.erase(customers.begin() + i);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& newName) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = newName;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << std::endl;
        }
    }

    void addSportArea(int id, const std::string& name) {
        sportAreas.push_back(SportArea(id, name));
    }

    void deleteSportArea(int id) {
        for (size_t i = 0; i < sportAreas.size(); ++i) {
            if (sportAreas[i].id == id) {
                sportAreas.erase(sportAreas.begin() + i);
                break;
            }
        }
    }

    void updateSportArea(int id, const std::string& newName) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                area.name = newName;
                break;
            }
        }
    }

    SportArea* searchSportArea(int id) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                return &area;
            }
        }
        return nullptr;
    }

    void displaySportAreas() {
        for (const auto& area : sportAreas) {
            std::cout << "ID: " << area.id << ", Name: " << area.name << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "John Doe");
    system.addCustomer(2, "Jane Smith");
    system.addSportArea(1, "Tennis Court");
    system.addSportArea(2, "Football Field");

    std::cout << "Customers:" << std::endl;
    system.displayCustomers();

    std::cout << "\nSport Areas:" << std::endl;
    system.displaySportAreas();

    system.updateCustomer(1, "Johnny Doe");
    system.updateSportArea(2, "Soccer Field");

    std::cout << "\nUpdated Customers:" << std::endl;
    system.displayCustomers();

    std::cout << "\nUpdated Sport Areas:" << std::endl;
    system.displaySportAreas();

    return 0;
}