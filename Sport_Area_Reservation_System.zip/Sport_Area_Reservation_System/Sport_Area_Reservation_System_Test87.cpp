#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string phone;
    Customer(int id, const std::string &name, const std::string &phone) : id(id), name(name), phone(phone) {}
};

class SportArea {
public:
    int id;
    std::string name;
    bool isAvailable;
    SportArea(int id, const std::string &name, bool isAvailable) : id(id), name(name), isAvailable(isAvailable) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;

public:
    void addCustomer(int id, const std::string &name, const std::string &phone) {
        customers.push_back(Customer{id, name, phone});
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string &name, const std::string &phone) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phone = phone;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto &customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << std::endl;
                return;
            }
        }
        std::cout << "Customer not found" << std::endl;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << std::endl;
        }
    }

    void addSportArea(int id, const std::string &name, bool isAvailable) {
        sportAreas.push_back(SportArea{id, name, isAvailable});
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, const std::string &name, bool isAvailable) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.isAvailable = isAvailable;
                break;
            }
        }
    }

    void searchSportArea(int id) {
        for (const auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                std::cout << "Sport Area ID: " << sportArea.id << ", Name: " << sportArea.name << ", Available: " << (sportArea.isAvailable ? "Yes" : "No") << std::endl;
                return;
            }
        }
        std::cout << "Sport Area not found" << std::endl;
    }

    void displaySportAreas() {
        for (const auto &sportArea : sportAreas) {
            std::cout << "Sport Area ID: " << sportArea.id << ", Name: " << sportArea.name << ", Available: " << (sportArea.isAvailable ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "Alice", "123456789");
    system.addCustomer(2, "Bob", "987654321");
    system.addSportArea(1, "Tennis Court", true);
    system.addSportArea(2, "Swimming Pool", false);

    std::cout << "Customers:" << std::endl;
    system.displayCustomers();

    std::cout << "\nSport Areas:" << std::endl;
    system.displaySportAreas();

    return 0;
}