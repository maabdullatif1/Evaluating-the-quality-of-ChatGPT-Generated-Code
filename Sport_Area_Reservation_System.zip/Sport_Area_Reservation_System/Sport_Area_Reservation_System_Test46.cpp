#include <iostream>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string contact;
};

struct SportArea {
    int id;
    string name;
    string location;
};

Customer customers[100];
SportArea sportAreas[100];

int customerCount = 0;
int sportAreaCount = 0;

void addCustomer() {
    if (customerCount < 100) {
        int id;
        string name, contact;
        cout << "Enter Customer ID: ";
        cin >> id;
        cout << "Enter Customer Name: ";
        cin >> name;
        cout << "Enter Contact Information: ";
        cin >> contact;
        customers[customerCount++] = {id, name, contact};
    } else {
        cout << "Customer limit reached.\n";
    }
}

void deleteCustomer() {
    int id;
    cout << "Enter Customer ID to delete: ";
    cin >> id;
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; ++j) {
                customers[j] = customers[j + 1];
            }
            --customerCount;
            cout << "Customer deleted.\n";
            return;
        }
    }
    cout << "Customer not found.\n";
}

void updateCustomer() {
    int id;
    cout << "Enter Customer ID to update: ";
    cin >> id;
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            string name, contact;
            cout << "Enter new Customer Name: ";
            cin >> name;
            cout << "Enter new Contact Information: ";
            cin >> contact;
            customers[i] = {id, name, contact};
            cout << "Customer updated.\n";
            return;
        }
    }
    cout << "Customer not found.\n";
}

void searchCustomer() {
    int id;
    cout << "Enter Customer ID to search: ";
    cin >> id;
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << ", Contact: " << customers[i].contact << endl;
            return;
        }
    }
    cout << "Customer not found.\n";
}

void displayCustomers() {
    for (int i = 0; i < customerCount; ++i) {
        cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << ", Contact: " << customers[i].contact << endl;
    }
}

void addSportArea() {
    if (sportAreaCount < 100) {
        int id;
        string name, location;
        cout << "Enter Sport Area ID: ";
        cin >> id;
        cout << "Enter Sport Area Name: ";
        cin >> name;
        cout << "Enter Sport Area Location: ";
        cin >> location;
        sportAreas[sportAreaCount++] = {id, name, location};
    } else {
        cout << "Sport area limit reached.\n";
    }
}

void deleteSportArea() {
    int id;
    cout << "Enter Sport Area ID to delete: ";
    cin >> id;
    for (int i = 0; i < sportAreaCount; ++i) {
        if (sportAreas[i].id == id) {
            for (int j = i; j < sportAreaCount - 1; ++j) {
                sportAreas[j] = sportAreas[j + 1];
            }
            --sportAreaCount;
            cout << "Sport area deleted.\n";
            return;
        }
    }
    cout << "Sport area not found.\n";
}

void updateSportArea() {
    int id;
    cout << "Enter Sport Area ID to update: ";
    cin >> id;
    for (int i = 0; i < sportAreaCount; ++i) {
        if (sportAreas[i].id == id) {
            string name, location;
            cout << "Enter new Sport Area Name: ";
            cin >> name;
            cout << "Enter new Sport Area Location: ";
            cin >> location;
            sportAreas[i] = {id, name, location};
            cout << "Sport area updated.\n";
            return;
        }
    }
    cout << "Sport area not found.\n";
}

void searchSportArea() {
    int id;
    cout << "Enter Sport Area ID to search: ";
    cin >> id;
    for (int i = 0; i < sportAreaCount; ++i) {
        if (sportAreas[i].id == id) {
            cout << "Sport Area ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name << ", Location: " << sportAreas[i].location << endl;
            return;
        }
    }
    cout << "Sport area not found.\n";
}

void displaySportAreas() {
    for (int i = 0; i < sportAreaCount; ++i) {
        cout << "Sport Area ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name << ", Location: " << sportAreas[i].location << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Customer\n2. Delete Customer\n3. Update Customer\n4. Search Customer\n5. Display Customers\n";
        cout << "6. Add Sport Area\n7. Delete Sport Area\n8. Update Sport Area\n9. Search Sport Area\n10. Display Sport Areas\n0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addCustomer(); break;
            case 2: deleteCustomer(); break;
            case 3: updateCustomer(); break;
            case 4: searchCustomer(); break;
            case 5: displayCustomers(); break;
            case 6: addSportArea(); break;
            case 7: deleteSportArea(); break;
            case 8: updateSportArea(); break;
            case 9: searchSportArea(); break;
            case 10: displaySportAreas(); break;
            case 0: break;
            default: cout << "Invalid choice.\n"; break;
        }
    } while (choice != 0);
    return 0;
}