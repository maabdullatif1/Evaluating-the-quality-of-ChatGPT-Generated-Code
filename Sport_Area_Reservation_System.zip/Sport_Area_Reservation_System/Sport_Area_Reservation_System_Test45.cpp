#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string phone;
};

struct SportArea {
    int id;
    std::string name;
    bool reserved;
};

class ReservationSystem {
public:
    void addCustomer(int id, const std::string& name, const std::string& phone) {
        customers.push_back({id, name, phone});
    }

    void deleteCustomer(int id) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) {
                customers.erase(customers.begin() + i);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& phone) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phone = phone;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer ID: " << customer.id 
                          << ", Name: " << customer.name 
                          << ", Phone: " << customer.phone << "\n";
                return;
            }
        }
        std::cout << "Customer not found.\n";
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id 
                      << ", Name: " << customer.name 
                      << ", Phone: " << customer.phone << "\n";
        }
    }

    void addSportArea(int id, const std::string& name) {
        sportAreas.push_back({id, name, false});
    }

    void deleteSportArea(int id) {
        for (size_t i = 0; i < sportAreas.size(); ++i) {
            if (sportAreas[i].id == id) {
                sportAreas.erase(sportAreas.begin() + i);
                break;
            }
        }
    }

    void updateSportArea(int id, const std::string& name, bool reserved) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                area.name = name;
                area.reserved = reserved;
                break;
            }
        }
    }

    void searchSportArea(int id) {
        for (const auto& area : sportAreas) {
            if (area.id == id) {
                std::cout << "Sport Area ID: " << area.id 
                          << ", Name: " << area.name 
                          << ", Reserved: " << (area.reserved ? "Yes" : "No") << "\n";
                return;
            }
        }
        std::cout << "Sport area not found.\n";
    }

    void displaySportAreas() {
        for (const auto& area : sportAreas) {
            std::cout << "Sport Area ID: " << area.id 
                      << ", Name: " << area.name 
                      << ", Reserved: " << (area.reserved ? "Yes" : "No") << "\n";
        }
    }

private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
};

int main() {
    ReservationSystem system;
    
    system.addCustomer(1, "John Doe", "123-456-7890");
    system.addCustomer(2, "Jane Smith", "098-765-4321");
    
    system.displayCustomers();
    
    system.addSportArea(1, "Football Field");
    system.addSportArea(2, "Tennis Court");
    
    system.displaySportAreas();
    
    system.updateSportArea(1, "Football Field", true);
    
    system.searchSportArea(1);
    
    system.deleteCustomer(2);
    
    system.displayCustomers();

    return 0;
}