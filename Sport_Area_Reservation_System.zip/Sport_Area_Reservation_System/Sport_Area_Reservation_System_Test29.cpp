#include <iostream>
#include <string>
#include <vector>

class Customer {
public:
    int id;
    std::string name;
    std::string phone;
    
    Customer(int id, const std::string& name, const std::string& phone)
        : id(id), name(name), phone(phone) {}
};

class SportArea {
public:
    int id;
    std::string name;
    bool isReserved;
    
    SportArea(int id, const std::string& name)
        : id(id), name(name), isReserved(false) {}
};

class ReservationSystem {
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;

    Customer* findCustomerById(int id) {
        for (auto &customer : customers)
            if (customer.id == id)
                return &customer;
        return nullptr;
    }
    
    SportArea* findSportAreaById(int id) {
        for (auto &area : sportAreas)
            if (area.id == id)
                return &area;
        return nullptr;
    }
    
public:
    void addCustomer(int id, const std::string& name, const std::string& phone) {
        customers.push_back(Customer(id, name, phone));
    }
    
    void deleteCustomer(int id) {
        customers.erase(
            std::remove_if(customers.begin(), customers.end(), 
                           [id](Customer& c) { return c.id == id; }),
            customers.end());
    }
    
    void updateCustomer(int id, const std::string& name, const std::string& phone) {
        Customer* customer = findCustomerById(id);
        if (customer) {
            customer->name = name;
            customer->phone = phone;
        }
    }
    
    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name 
                      << ", Phone: " << customer.phone << std::endl;
        }
    }
    
    void addSportArea(int id, const std::string& name) {
        sportAreas.push_back(SportArea(id, name));
    }
    
    void deleteSportArea(int id) {
        sportAreas.erase(
            std::remove_if(sportAreas.begin(), sportAreas.end(), 
                           [id](SportArea& area) { return area.id == id; }),
            sportAreas.end());
    }
    
    void updateSportArea(int id, const std::string& name) {
        SportArea* area = findSportAreaById(id);
        if (area) {
            area->name = name;
        }
    }
    
    void displaySportAreas() {
        for (const auto &area : sportAreas) {
            std::cout << "ID: " << area.id << ", Name: " << area.name 
                      << ", Reserved: " << (area.isReserved ? "Yes" : "No") << std::endl;
        }
    }
    
    bool reserveArea(int areaId) {
        SportArea* area = findSportAreaById(areaId);
        if (area && !area->isReserved) {
            area->isReserved = true;
            return true;
        }
        return false;
    }
    
    bool cancelReservation(int areaId) {
        SportArea* area = findSportAreaById(areaId);
        if (area && area->isReserved) {
            area->isReserved = false;
            return true;
        }
        return false;
    }
    
    void searchCustomer(int id) {
        Customer* customer = findCustomerById(id);
        if (customer) {
            std::cout << "Customer Found: ID: " << customer->id 
                      << ", Name: " << customer->name 
                      << ", Phone: " << customer->phone << std::endl;
        } else {
            std::cout << "Customer not found." << std::endl;
        }
    }
    
    void searchSportArea(int id) {
        SportArea* area = findSportAreaById(id);
        if (area) {
            std::cout << "Sport Area Found: ID: " << area->id 
                      << ", Name: " << area->name 
                      << ", Reserved: " << (area->isReserved ? "Yes" : "No") << std::endl;
        } else {
            std::cout << "Sport area not found." << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "John Doe", "123456789");
    system.addSportArea(1, "Tennis Court");
    system.displayCustomers();
    system.displaySportAreas();
    system.reserveArea(1);
    system.displaySportAreas();
    system.cancelReservation(1);
    system.displaySportAreas();
    return 0;
}