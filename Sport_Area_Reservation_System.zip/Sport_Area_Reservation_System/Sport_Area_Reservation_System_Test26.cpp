#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string phoneNumber;

    Customer(int id, const std::string& name, const std::string& phoneNumber)
        : id(id), name(name), phoneNumber(phoneNumber) {}
};

class SportArea {
public:
    int id;
    std::string name;
    bool isReserved;

    SportArea(int id, const std::string& name, bool isReserved = false)
        : id(id), name(name), isReserved(isReserved) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
    int customerCount;
    int sportAreaCount;

public:
    ReservationSystem() : customerCount(0), sportAreaCount(0) {}

    void addCustomer(const std::string& name, const std::string& phoneNumber) {
        customers.push_back(Customer(++customerCount, name, phoneNumber));
    }

    void addSportArea(const std::string& name) {
        sportAreas.push_back(SportArea(++sportAreaCount, name));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    Customer* updateCustomer(int id, const std::string& name, const std::string& phoneNumber) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phoneNumber = phoneNumber;
                return &customer;
            }
        }
        return nullptr;
    }

    SportArea* updateSportArea(int id, const std::string& name, bool isReserved) {
        for (auto& sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.isReserved = isReserved;
                return &sportArea;
            }
        }
        return nullptr;
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    SportArea* searchSportArea(int id) {
        for (auto& sportArea : sportAreas) {
            if (sportArea.id == id) {
                return &sportArea;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id
                      << ", Name: " << customer.name
                      << ", Phone Number: " << customer.phoneNumber << std::endl;
        }
    }

    void displaySportAreas() {
        for (const auto& sportArea : sportAreas) {
            std::cout << "Sport Area ID: " << sportArea.id
                      << ", Name: " << sportArea.name
                      << ", Reserved: " << (sportArea.isReserved ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer("John Doe", "123456789");
    system.addSportArea("Tennis Court");
    system.displayCustomers();
    system.displaySportAreas();
    return 0;
}