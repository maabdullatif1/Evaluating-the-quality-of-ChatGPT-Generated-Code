#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string contact;
};

struct SportArea {
    int id;
    string name;
    string type;
    bool isAvailable;
};

vector<Customer> customers;
vector<SportArea> sportAreas;

void addCustomer(int id, string name, string contact) {
    customers.push_back({id, name, contact});
}

void deleteCustomer(int id) {
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            break;
        }
    }
}

void updateCustomer(int id, string name, string contact) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            customer.name = name;
            customer.contact = contact;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            return &customer;
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (const auto& customer : customers) {
        cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
    }
}

void addSportArea(int id, string name, string type, bool isAvailable) {
    sportAreas.push_back({id, name, type, isAvailable});
}

void deleteSportArea(int id) {
    for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
        if (it->id == id) {
            sportAreas.erase(it);
            break;
        }
    }
}

void updateSportArea(int id, string name, string type, bool isAvailable) {
    for (auto& area : sportAreas) {
        if (area.id == id) {
            area.name = name;
            area.type = type;
            area.isAvailable = isAvailable;
            break;
        }
    }
}

SportArea* searchSportArea(int id) {
    for (auto& area : sportAreas) {
        if (area.id == id) {
            return &area;
        }
    }
    return nullptr;
}

void displaySportAreas() {
    for (const auto& area : sportAreas) {
        cout << "ID: " << area.id << ", Name: " << area.name << ", Type: " << area.type 
             << ", Available: " << (area.isAvailable ? "Yes" : "No") << endl;
    }
}

int main() {
    addCustomer(1, "Alice Smith", "123-456-7890");
    addCustomer(2, "Bob Johnson", "234-567-8901");
    
    addSportArea(1, "Main Court", "Basketball", true);
    addSportArea(2, "Swimming Pool", "Swimming", false);

    displayCustomers();
    displaySportAreas();
    
    Customer* customer = searchCustomer(1);
    if (customer) {
        cout << "Found Customer: " << customer->name << endl;
    }

    SportArea* area = searchSportArea(1);
    if (area) {
        cout << "Found Sport Area: " << area->name << endl;
    }

    updateCustomer(1, "Alice Johnson", "987-654-3210");
    updateSportArea(1, "Main Court", "Basketball", false);

    displayCustomers();
    displaySportAreas();

    deleteCustomer(2);
    deleteSportArea(2);

    displayCustomers();
    displaySportAreas();

    return 0;
}