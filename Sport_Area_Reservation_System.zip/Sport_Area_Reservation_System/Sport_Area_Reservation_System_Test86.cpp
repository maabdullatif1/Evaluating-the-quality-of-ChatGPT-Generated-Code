#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string contact;
};

struct SportArea {
    int id;
    string name;
    string type;
};

Customer customers[100];
SportArea sportAreas[100];
int customerCount = 0;
int sportAreaCount = 0;

void addCustomer(int id, string name, string contact) {
    customers[customerCount].id = id;
    customers[customerCount].name = name;
    customers[customerCount].contact = contact;
    customerCount++;
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; j++) {
                customers[j] = customers[j + 1];
            }
            customerCount--;
            break;
        }
    }
}

void updateCustomer(int id, string name, string contact) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            customers[i].name = name;
            customers[i].contact = contact;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; i++) {
        cout << "ID: " << customers[i].id << ", Name: " << customers[i].name << ", Contact: " << customers[i].contact << endl;
    }
}

void addSportArea(int id, string name, string type) {
    sportAreas[sportAreaCount].id = id;
    sportAreas[sportAreaCount].name = name;
    sportAreas[sportAreaCount].type = type;
    sportAreaCount++;
}

void deleteSportArea(int id) {
    for (int i = 0; i < sportAreaCount; i++) {
        if (sportAreas[i].id == id) {
            for (int j = i; j < sportAreaCount - 1; j++) {
                sportAreas[j] = sportAreas[j + 1];
            }
            sportAreaCount--;
            break;
        }
    }
}

void updateSportArea(int id, string name, string type) {
    for (int i = 0; i < sportAreaCount; i++) {
        if (sportAreas[i].id == id) {
            sportAreas[i].name = name;
            sportAreas[i].type = type;
            break;
        }
    }
}

SportArea* searchSportArea(int id) {
    for (int i = 0; i < sportAreaCount; i++) {
        if (sportAreas[i].id == id) {
            return &sportAreas[i];
        }
    }
    return nullptr;
}

void displaySportAreas() {
    for (int i = 0; i < sportAreaCount; i++) {
        cout << "ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name << ", Type: " << sportAreas[i].type << endl;
    }
}

int main() {
    // Example usage of the system
    addCustomer(1, "John Doe", "123-456-7890");
    addCustomer(2, "Jane Smith", "098-765-4321");
    addSportArea(1, "Tennis Court", "Tennis");
    addSportArea(2, "Football Field", "Football");

    cout << "Customers:" << endl;
    displayCustomers();

    cout << "Sport Areas:" << endl;
    displaySportAreas();

    updateCustomer(1, "John Doe", "111-222-3333");
    updateSportArea(1, "Tennis Court A", "Tennis");

    cout << "Updated Customers:" << endl;
    displayCustomers();

    cout << "Updated Sport Areas:" << endl;
    displaySportAreas();

    deleteCustomer(2);
    deleteSportArea(2);

    cout << "After Deletion, Customers:" << endl;
    displayCustomers();

    cout << "After Deletion, Sport Areas:" << endl;
    displaySportAreas();

    return 0;
}