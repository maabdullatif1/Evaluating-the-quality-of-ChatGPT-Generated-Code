#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string phone;
};

struct SportArea {
    int id;
    std::string name;
    bool available;
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;

public:
    void addCustomer(int id, const std::string& name, const std::string& phone) {
        customers.push_back({id, name, phone});
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, const std::string& name, const std::string& phone) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phone = phone;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << "\n";
        }
    }

    void addSportArea(int id, const std::string& name, bool available) {
        sportAreas.push_back({id, name, available});
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, const std::string& name, bool available) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                area.name = name;
                area.available = available;
                break;
            }
        }
    }

    SportArea* searchSportArea(int id) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                return &area;
            }
        }
        return nullptr;
    }

    void displaySportAreas() {
        for (const auto& area : sportAreas) {
            std::cout << "ID: " << area.id << ", Name: " << area.name << ", Available: " << (area.available ? "Yes" : "No") << "\n";
        }
    }
};

int main() {
    ReservationSystem system;

    system.addCustomer(1, "John Doe", "123-456-7890");
    system.addCustomer(2, "Jane Smith", "987-654-3210");
    system.displayCustomers();
    
    system.addSportArea(1, "Tennis Court", true);
    system.addSportArea(2, "Swimming Pool", false);
    system.displaySportAreas();
    
    return 0;
}