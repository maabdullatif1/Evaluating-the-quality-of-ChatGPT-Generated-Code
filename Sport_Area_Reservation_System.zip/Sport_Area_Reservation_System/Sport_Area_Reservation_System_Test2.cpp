#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string phone;
};

struct SportArea {
    int id;
    std::string name;
    bool isReserved;
    int customerId;
};

std::vector<Customer> customers;
std::vector<SportArea> sportAreas;

int getCustomerIndexById(int id) {
    for (size_t i = 0; i < customers.size(); ++i) {
        if (customers[i].id == id) return i;
    }
    return -1;
}

int getSportAreaIndexById(int id) {
    for (size_t i = 0; i < sportAreas.size(); ++i) {
        if (sportAreas[i].id == id) return i;
    }
    return -1;
}

void addCustomer(int id, const std::string& name, const std::string& phone) {
    if (getCustomerIndexById(id) == -1) {
        customers.push_back({id, name, phone});
    }
}

void addSportArea(int id, const std::string& name) {
    if (getSportAreaIndexById(id) == -1) {
        sportAreas.push_back({id, name, false, -1});
    }
}

void deleteCustomer(int id) {
    int index = getCustomerIndexById(id);
    if (index != -1) {
        customers.erase(customers.begin() + index);
    }
}

void deleteSportArea(int id) {
    int index = getSportAreaIndexById(id);
    if (index != -1) {
        sportAreas.erase(sportAreas.begin() + index);
    }
}

void updateCustomer(int id, const std::string& name, const std::string& phone) {
    int index = getCustomerIndexById(id);
    if (index != -1) {
        customers[index].name = name;
        customers[index].phone = phone;
    }
}

void updateReservation(int sportAreaId, int customerId, bool reserve) {
    int sportAreaIndex = getSportAreaIndexById(sportAreaId);
    if (sportAreaIndex != -1) {
        if (reserve && !sportAreas[sportAreaIndex].isReserved) {
            sportAreas[sportAreaIndex].isReserved = true;
            sportAreas[sportAreaIndex].customerId = customerId;
        } else if (!reserve && sportAreas[sportAreaIndex].isReserved) {
            sportAreas[sportAreaIndex].isReserved = false;
            sportAreas[sportAreaIndex].customerId = -1;
        }
    }
}

Customer* searchCustomer(int id) {
    int index = getCustomerIndexById(id);
    if (index != -1) {
        return &customers[index];
    }
    return nullptr;
}

SportArea* searchSportArea(int id) {
    int index = getSportAreaIndexById(id);
    if (index != -1) {
        return &sportAreas[index];
    }
    return nullptr;
}

void displayCustomers() {
    for (const auto& customer : customers) {
        std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << std::endl;
    }
}

void displaySportAreas() {
    for (const auto& area : sportAreas) {
        std::cout << "ID: " << area.id << ", Name: " << area.name << ", Reserved: " << (area.isReserved ? "Yes" : "No");
        if (area.isReserved) {
            std::cout << ", Reserved by Customer ID: " << area.customerId;
        }
        std::cout << std::endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "123456789");
    addCustomer(2, "Jane Smith", "987654321");
    addSportArea(101, "Tennis Court");
    addSportArea(102, "Basketball Court");

    updateReservation(101, 1, true);

    displayCustomers();
    displaySportAreas();

    updateReservation(101, 1, false);

    deleteCustomer(1);
    deleteSportArea(102);

    displayCustomers();
    displaySportAreas();

    return 0;
}