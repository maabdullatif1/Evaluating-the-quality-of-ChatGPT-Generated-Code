#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string contact;
    
    Customer(int id, string name, string contact) : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    string name;
    string location;
    
    SportArea(int id, string name, string location) : id(id), name(name), location(location) {}
};

class ReservationSystem {
private:
    vector<Customer> customers;
    vector<SportArea> sportAreas;

public:
    void addCustomer(int id, string name, string contact) {
        customers.push_back(Customer(id, name, contact));
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }
    
    void updateCustomer(int id, string name, string contact) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
            }
        }
    }
    
    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                cout << "Customer ID: " << customer.id 
                     << ", Name: " << customer.name 
                     << ", Contact: " << customer.contact << endl;
                return;
            }
        }
        cout << "Customer not found" << endl;
    }
    
    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Customer ID: " << customer.id 
                 << ", Name: " << customer.name 
                 << ", Contact: " << customer.contact << endl;
        }
    }

    void addSportArea(int id, string name, string location) {
        sportAreas.push_back(SportArea(id, name, location));
    }
    
    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                return;
            }
        }
    }
    
    void updateSportArea(int id, string name, string location) {
        for (auto& sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.location = location;
            }
        }
    }
    
    void searchSportArea(int id) {
        for (const auto& sportArea : sportAreas) {
            if (sportArea.id == id) {
                cout << "Sport Area ID: " << sportArea.id 
                     << ", Name: " << sportArea.name 
                     << ", Location: " << sportArea.location << endl;
                return;
            }
        }
        cout << "Sport area not found" << endl;
    }
    
    void displaySportAreas() {
        for (const auto& sportArea : sportAreas) {
            cout << "Sport Area ID: " << sportArea.id 
                 << ", Name: " << sportArea.name 
                 << ", Location: " << sportArea.location << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "John Doe", "1234567890");
    system.addCustomer(2, "Jane Smith", "0987654321");
    system.displayCustomers();
    system.searchCustomer(2);
    system.updateCustomer(2, "Jane Doe", "1122334455");
    system.searchCustomer(2);
    system.deleteCustomer(1);
    system.displayCustomers();

    system.addSportArea(1, "Soccer Field", "Downtown");
    system.addSportArea(2, "Basketball Court", "Uptown");
    system.displaySportAreas();
    system.searchSportArea(1);
    system.updateSportArea(1, "Football Field", "Suburbs");
    system.searchSportArea(1);
    system.deleteSportArea(2);
    system.displaySportAreas();

    return 0;
}