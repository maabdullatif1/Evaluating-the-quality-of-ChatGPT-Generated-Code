#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;
    Customer(int i, std::string n, std::string c) : id(i), name(n), contact(c) {}
};

class SportArea {
public:
    int id;
    std::string name;
    bool reserved;
    SportArea(int i, std::string n) : id(i), name(n), reserved(false) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
public:
    void addCustomer(int id, std::string name, std::string contact) {
        customers.push_back(Customer(id, name, contact));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string contact) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto &customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer found: " << customer.name << ", " << customer.contact << std::endl;
                return;
            }
        }
        std::cout << "Customer not found." << std::endl;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << std::endl;
        }
    }

    void addSportArea(int id, std::string name) {
        sportAreas.push_back(SportArea(id, name));
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, std::string name, bool reserved) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.reserved = reserved;
                break;
            }
        }
    }

    void searchSportArea(int id) {
        for (const auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                std::cout << "Sport Area found: " << sportArea.name << ", Reserved: " << (sportArea.reserved ? "Yes" : "No") << std::endl;
                return;
            }
        }
        std::cout << "Sport Area not found." << std::endl;
    }

    void displaySportAreas() {
        for (const auto &sportArea : sportAreas) {
            std::cout << "ID: " << sportArea.id << ", Name: " << sportArea.name << ", Reserved: " << (sportArea.reserved ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "John Doe", "123456789");
    system.addCustomer(2, "Jane Smith", "987654321");
    system.addSportArea(1, "Tennis Court");
    system.addSportArea(2, "Swimming Pool");

    std::cout << "Customers:" << std::endl;
    system.displayCustomers();
    
    std::cout << "Sport Areas:" << std::endl;
    system.displaySportAreas();

    system.updateCustomer(1, "Johnathon Doe", "111222333");
    system.updateSportArea(2, "Olympic Pool", true);

    std::cout << "\nUpdated Customers:" << std::endl;
    system.displayCustomers();

    std::cout << "Updated Sport Areas:" << std::endl;
    system.displaySportAreas();

    system.searchCustomer(1);
    system.searchSportArea(2);

    return 0;
}