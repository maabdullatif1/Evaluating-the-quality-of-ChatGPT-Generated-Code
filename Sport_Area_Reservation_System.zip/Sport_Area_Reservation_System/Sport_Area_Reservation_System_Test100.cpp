#include <iostream>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct SportArea {
    int id;
    string name;
    bool reserved;
};

class ReservationSystem {
    Customer customers[100];
    SportArea sportAreas[100];
    int customerCount;
    int sportAreaCount;

public:
    ReservationSystem() : customerCount(0), sportAreaCount(0) {}

    void addCustomer(int id, string name, string phone) {
        customers[customerCount++] = {id, name, phone};
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i] = customers[--customerCount];
                return;
            }
        }
    }

    void updateCustomer(int id, string name, string phone) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i].name = name;
                customers[i].phone = phone;
                return;
            }
        }
    }

    void searchCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                cout << "Customer ID: " << customers[i].id << ", Name: " 
                     << customers[i].name << ", Phone: " << customers[i].phone << endl;
                return;
            }
        }
        cout << "Customer not found." << endl;
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; ++i) {
            cout << "Customer ID: " << customers[i].id 
                 << ", Name: " << customers[i].name 
                 << ", Phone: " << customers[i].phone << endl;
        }
    }

    void addSportArea(int id, string name) {
        sportAreas[sportAreaCount++] = {id, name, false};
    }

    void deleteSportArea(int id) {
        for (int i = 0; i < sportAreaCount; ++i) {
            if (sportAreas[i].id == id) {
                sportAreas[i] = sportAreas[--sportAreaCount];
                return;
            }
        }
    }

    void updateSportArea(int id, string name, bool reserved) {
        for (int i = 0; i < sportAreaCount; ++i) {
            if (sportAreas[i].id == id) {
                sportAreas[i].name = name;
                sportAreas[i].reserved = reserved;
                return;
            }
        }
    }

    void searchSportArea(int id) {
        for (int i = 0; i < sportAreaCount; ++i) {
            if (sportAreas[i].id == id) {
                cout << "Sport Area ID: " << sportAreas[i].id 
                     << ", Name: " << sportAreas[i].name 
                     << ", Reserved: " << (sportAreas[i].reserved ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Sport Area not found." << endl;
    }

    void displaySportAreas() {
        for (int i = 0; i < sportAreaCount; ++i) {
            cout << "Sport Area ID: " << sportAreas[i].id 
                 << ", Name: " << sportAreas[i].name 
                 << ", Reserved: " << (sportAreas[i].reserved ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    ReservationSystem rs;
    rs.addCustomer(1, "John Doe", "123-456-7890");
    rs.addSportArea(1, "Tennis Court");
    rs.displayCustomers();
    rs.displaySportAreas();
    rs.updateSportArea(1, "Tennis Court", true);
    rs.displaySportAreas();
    rs.searchCustomer(1);
    rs.deleteCustomer(1);
    rs.displayCustomers();
    return 0;
}