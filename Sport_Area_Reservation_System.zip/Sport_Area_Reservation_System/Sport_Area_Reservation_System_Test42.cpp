#include <iostream>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct SportArea {
    int id;
    string name;
    string type;
    bool available;
};

const int MAX_CUSTOMERS = 100;
const int MAX_SPORT_AREAS = 50;

Customer customers[MAX_CUSTOMERS];
SportArea sportAreas[MAX_SPORT_AREAS];
int customerCount = 0;
int sportAreaCount = 0;

void addCustomer() {
    if (customerCount >= MAX_CUSTOMERS) return;
    Customer c;
    cout << "Enter customer ID: ";
    cin >> c.id;
    cout << "Enter customer name: ";
    cin >> c.name;
    cout << "Enter customer phone: ";
    cin >> c.phone;
    customers[customerCount++] = c;
}

void deleteCustomer() {
    int id;
    cout << "Enter customer ID to delete: ";
    cin >> id;
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; ++j) {
                customers[j] = customers[j + 1];
            }
            customerCount--;
            return;
        }
    }
}

void updateCustomer() {
    int id;
    cout << "Enter customer ID to update: ";
    cin >> id;
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            cout << "Enter new name: ";
            cin >> customers[i].name;
            cout << "Enter new phone: ";
            cin >> customers[i].phone;
            return;
        }
    }
}

void searchCustomer() {
    int id;
    cout << "Enter customer ID to search: ";
    cin >> id;
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            cout << "Customer ID: " << customers[i].id << endl;
            cout << "Customer Name: " << customers[i].name << endl;
            cout << "Customer Phone: " << customers[i].phone << endl;
            return;
        }
    }
}

void displayCustomers() {
    for (int i = 0; i < customerCount; i++) {
        cout << customers[i].id << " " << customers[i].name << " " << customers[i].phone << endl;
    }
}

void addSportArea() {
    if (sportAreaCount >= MAX_SPORT_AREAS) return;
    SportArea s;
    cout << "Enter sport area ID: ";
    cin >> s.id;
    cout << "Enter sport area name: ";
    cin >> s.name;
    cout << "Enter sport area type: ";
    cin >> s.type;
    s.available = true;
    sportAreas[sportAreaCount++] = s;
}

void deleteSportArea() {
    int id;
    cout << "Enter sport area ID to delete: ";
    cin >> id;
    for (int i = 0; i < sportAreaCount; ++i) {
        if (sportAreas[i].id == id) {
            for (int j = i; j < sportAreaCount - 1; ++j) {
                sportAreas[j] = sportAreas[j + 1];
            }
            sportAreaCount--;
            return;
        }
    }
}

void updateSportArea() {
    int id;
    cout << "Enter sport area ID to update: ";
    cin >> id;
    for (int i = 0; i < sportAreaCount; ++i) {
        if (sportAreas[i].id == id) {
            cout << "Enter new name: ";
            cin >> sportAreas[i].name;
            cout << "Enter new type: ";
            cin >> sportAreas[i].type;
            cout << "Enter availability (1 for available, 0 for not available): ";
            int avail;
            cin >> avail;
            sportAreas[i].available = (avail == 1);
            return;
        }
    }
}

void searchSportArea() {
    int id;
    cout << "Enter sport area ID to search: ";
    cin >> id;
    for (int i = 0; i < sportAreaCount; ++i) {
        if (sportAreas[i].id == id) {
            cout << "Sport Area ID: " << sportAreas[i].id << endl;
            cout << "Sport Area Name: " << sportAreas[i].name << endl;
            cout << "Sport Area Type: " << sportAreas[i].type << endl;
            cout << "Available: " << (sportAreas[i].available ? "Yes" : "No") << endl;
            return;
        }
    }
}

void displaySportAreas() {
    for (int i = 0; i < sportAreaCount; i++) {
        cout << sportAreas[i].id << " " << sportAreas[i].name << " " << sportAreas[i].type 
             << " " << (sportAreas[i].available ? "Available" : "Not Available") << endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Customer" << endl;
        cout << "2. Delete Customer" << endl;
        cout << "3. Update Customer" << endl;
        cout << "4. Search Customer" << endl;
        cout << "5. Display Customers" << endl;
        cout << "6. Add Sport Area" << endl;
        cout << "7. Delete Sport Area" << endl;
        cout << "8. Update Sport Area" << endl;
        cout << "9. Search Sport Area" << endl;
        cout << "10. Display Sport Areas" << endl;
        cout << "0. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addCustomer(); break;
            case 2: deleteCustomer(); break;
            case 3: updateCustomer(); break;
            case 4: searchCustomer(); break;
            case 5: displayCustomers(); break;
            case 6: addSportArea(); break;
            case 7: deleteSportArea(); break;
            case 8: updateSportArea(); break;
            case 9: searchSportArea(); break;
            case 10: displaySportAreas(); break;
            case 0: return 0;
            default: cout << "Invalid choice." << endl;
        }
    }
}