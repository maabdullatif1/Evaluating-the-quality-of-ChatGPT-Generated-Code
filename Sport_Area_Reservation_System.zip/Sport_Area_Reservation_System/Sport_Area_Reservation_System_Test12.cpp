#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string contact;
    
    Customer(int _id, string _name, string _contact) : id(_id), name(_name), contact(_contact) {}
};

class SportArea {
public:
    int id;
    string name;
    string location;
    
    SportArea(int _id, string _name, string _location) : id(_id), name(_name), location(_location) {}
};

class ReservationSystem {
private:
    vector<Customer> customers;
    vector<SportArea> sportAreas;
    int customerIdCounter;
    int sportAreaIdCounter;

    Customer* findCustomerById(int id) {
        for(auto &customer : customers) {
            if(customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    SportArea* findSportAreaById(int id) {
        for(auto &sportArea : sportAreas) {
            if(sportArea.id == id) {
                return &sportArea;
            }
        }
        return nullptr;
    }

public:
    ReservationSystem() : customerIdCounter(0), sportAreaIdCounter(0) {}

    void addCustomer(string name, string contact) {
        customers.emplace_back(++customerIdCounter, name, contact);
    }

    void deleteCustomer(int id) {
        customers.erase(remove_if(customers.begin(), customers.end(),
                                  [id](Customer &customer) { return customer.id == id; }),
                        customers.end());
    }

    void updateCustomer(int id, string name, string contact) {
        Customer* customer = findCustomerById(id);
        if(customer) {
            customer->name = name;
            customer->contact = contact;
        }
    }

    Customer* searchCustomer(int id) {
        return findCustomerById(id);
    }

    void displayCustomers() {
        for(const auto &customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name 
                 << ", Contact: " << customer.contact << endl;
        }
    }

    void addSportArea(string name, string location) {
        sportAreas.emplace_back(++sportAreaIdCounter, name, location);
    }

    void deleteSportArea(int id) {
        sportAreas.erase(remove_if(sportAreas.begin(), sportAreas.end(),
                                   [id](SportArea &sportArea) { return sportArea.id == id; }),
                         sportAreas.end());
    }

    void updateSportArea(int id, string name, string location) {
        SportArea* sportArea = findSportAreaById(id);
        if(sportArea) {
            sportArea->name = name;
            sportArea->location = location;
        }
    }

    SportArea* searchSportArea(int id) {
        return findSportAreaById(id);
    }

    void displaySportAreas() {
        for(const auto &sportArea : sportAreas) {
            cout << "SportArea ID: " << sportArea.id << ", Name: " << sportArea.name 
                 << ", Location: " << sportArea.location << endl;
        }
    }
};

int main() {
    ReservationSystem system;

    system.addCustomer("Alice", "123-456-7890");
    system.addCustomer("Bob", "987-654-3210");
    system.displayCustomers();

    system.updateCustomer(1, "Alice Smith", "123-456-7899");
    system.displayCustomers();

    system.deleteCustomer(2);
    system.displayCustomers();

    system.addSportArea("Tennis Court", "North Wing");
    system.addSportArea("Football Field", "East End");
    system.displaySportAreas();

    system.updateSportArea(1, "Indoor Tennis Court", "North Wing");
    system.displaySportAreas();

    system.deleteSportArea(2);
    system.displaySportAreas();

    Customer* customer = system.searchCustomer(1);
    if(customer) {
        cout << "Found Customer: " << customer->name << endl;
    }

    SportArea* sportArea = system.searchSportArea(1);
    if(sportArea) {
        cout << "Found SportArea: " << sportArea->name << endl;
    }

    return 0;
}