#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string contact;
    
    Customer(int id, string name, string contact) : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    string name;
    string location;
    
    SportArea(int id, string name, string location) : id(id), name(name), location(location) {}
};

vector<Customer> customers;
vector<SportArea> sportAreas;

void addCustomer(int id, string name, string contact) {
    customers.push_back(Customer(id, name, contact));
}

void deleteCustomer(int id) {
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            break;
        }
    }
}

void updateCustomer(int id, string name, string contact) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            customer.name = name;
            customer.contact = contact;
        }
    }
}

void displayCustomers() {
    for (const auto& customer : customers) {
        cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
    }
}

Customer* searchCustomer(int id) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            return &customer;
        }
    }
    return nullptr;
}

void addSportArea(int id, string name, string location) {
    sportAreas.push_back(SportArea(id, name, location));
}

void deleteSportArea(int id) {
    for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
        if (it->id == id) {
            sportAreas.erase(it);
            break;
        }
    }
}

void updateSportArea(int id, string name, string location) {
    for (auto& sportArea : sportAreas) {
        if (sportArea.id == id) {
            sportArea.name = name;
            sportArea.location = location;
        }
    }
}

void displaySportAreas() {
    for (const auto& sportArea : sportAreas) {
        cout << "ID: " << sportArea.id << ", Name: " << sportArea.name << ", Location: " << sportArea.location << endl;
    }
}

SportArea* searchSportArea(int id) {
    for (auto& sportArea : sportAreas) {
        if (sportArea.id == id) {
            return &sportArea;
        }
    }
    return nullptr;
}

int main() {
    addCustomer(1, "John Doe", "123456789");
    addCustomer(2, "Jane Smith", "987654321");
    addSportArea(1, "Tennis Court", "First Street");
    addSportArea(2, "Swimming Pool", "Second Avenue");

    displayCustomers();
    displaySportAreas();

    updateCustomer(1, "John Doe", "111111111");
    updateSportArea(2, "Olympic Pool", "Second Avenue");

    displayCustomers();
    displaySportAreas();

    Customer* customer = searchCustomer(1);
    if (customer) {
        cout << "Found Customer - ID: " << customer->id << ", Name: " << customer->name << endl;
    }

    SportArea* sportArea = searchSportArea(1);
    if (sportArea) {
        cout << "Found Sport Area - ID: " << sportArea->id << ", Name: " << sportArea->name << endl;
    }

    deleteCustomer(2);
    deleteSportArea(1);

    displayCustomers();
    displaySportAreas();

    return 0;
}