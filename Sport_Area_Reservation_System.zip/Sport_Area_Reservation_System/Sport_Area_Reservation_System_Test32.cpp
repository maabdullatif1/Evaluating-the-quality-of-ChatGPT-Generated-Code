#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    string name;
    string contact;
    int id;

    Customer(int id, string name, string contact) : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    string name;
    int id;

    SportArea(int id, string name) : id(id), name(name) {}
};

class ReservationSystem {
    vector<Customer> customers;
    vector<SportArea> sportAreas;

    int getCustomerIndexById(int id) {
        for (int i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) return i;
        }
        return -1;
    }

    int getSportAreaIndexById(int id) {
        for (int i = 0; i < sportAreas.size(); ++i) {
            if (sportAreas[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCustomer(int id, string name, string contact) {
        customers.push_back(Customer(id, name, contact));
    }

    void deleteCustomer(int id) {
        int index = getCustomerIndexById(id);
        if (index != -1) {
            customers.erase(customers.begin() + index);
        }
    }

    void updateCustomer(int id, string name, string contact) {
        int index = getCustomerIndexById(id);
        if (index != -1) {
            customers[index].name = name;
            customers[index].contact = contact;
        }
    }

    Customer* searchCustomer(int id) {
        int index = getCustomerIndexById(id);
        return index != -1 ? &customers[index] : nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
        }
    }

    void addSportArea(int id, string name) {
        sportAreas.push_back(SportArea(id, name));
    }

    void deleteSportArea(int id) {
        int index = getSportAreaIndexById(id);
        if (index != -1) {
            sportAreas.erase(sportAreas.begin() + index);
        }
    }

    void updateSportArea(int id, string name) {
        int index = getSportAreaIndexById(id);
        if (index != -1) {
            sportAreas[index].name = name;
        }
    }

    SportArea* searchSportArea(int id) {
        int index = getSportAreaIndexById(id);
        return index != -1 ? &sportAreas[index] : nullptr;
    }

    void displaySportAreas() {
        for (const auto& sportArea : sportAreas) {
            cout << "ID: " << sportArea.id << ", Name: " << sportArea.name << endl;
        }
    }
};

int main() {
    ReservationSystem system;

    system.addCustomer(1, "John Doe", "123-456-7890");
    system.addCustomer(2, "Jane Smith", "987-654-3210");
    
    system.addSportArea(1, "Tennis Court");
    system.addSportArea(2, "Swimming Pool");

    system.displayCustomers();
    system.displaySportAreas();

    system.deleteCustomer(1);
    system.updateSportArea(2, "Indoor Swimming Pool");

    system.displayCustomers();
    system.displaySportAreas();

    if (Customer* customer = system.searchCustomer(2)) {
        cout << "Found customer: " << customer->name << endl;
    }

    return 0;
}