#include <iostream>
#include <string>

struct Customer {
    int id;
    std::string name;
};

struct SportArea {
    int id;
    std::string type;
};

const int MAX_CUSTOMERS = 100;
const int MAX_AREAS = 50;

Customer customers[MAX_CUSTOMERS];
SportArea sportAreas[MAX_AREAS];

int customerCount = 0;
int areaCount = 0;

void addCustomer(int id, const std::string& name) {
    if (customerCount < MAX_CUSTOMERS) {
        customers[customerCount++] = {id, name};
    }
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; ++j) {
                customers[j] = customers[j + 1];
            }
            --customerCount;
            break;
        }
    }
}

void updateCustomer(int id, const std::string& newName) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            customers[i].name = newName;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; ++i) {
        std::cout << "ID: " << customers[i].id << ", Name: " << customers[i].name << std::endl;
    }
}

void addSportArea(int id, const std::string& type) {
    if (areaCount < MAX_AREAS) {
        sportAreas[areaCount++] = {id, type};
    }
}

void deleteSportArea(int id) {
    for (int i = 0; i < areaCount; ++i) {
        if (sportAreas[i].id == id) {
            for (int j = i; j < areaCount - 1; ++j) {
                sportAreas[j] = sportAreas[j + 1];
            }
            --areaCount;
            break;
        }
    }
}

void updateSportArea(int id, const std::string& newType) {
    for (int i = 0; i < areaCount; ++i) {
        if (sportAreas[i].id == id) {
            sportAreas[i].type = newType;
            break;
        }
    }
}

SportArea* searchSportArea(int id) {
    for (int i = 0; i < areaCount; ++i) {
        if (sportAreas[i].id == id) {
            return &sportAreas[i];
        }
    }
    return nullptr;
}

void displaySportAreas() {
    for (int i = 0; i < areaCount; ++i) {
        std::cout << "ID: " << sportAreas[i].id << ", Type: " << sportAreas[i].type << std::endl;
    }
}

int main() {
    addCustomer(1, "John Doe");
    addCustomer(2, "Jane Smith");
    updateCustomer(2, "Jane Doe");
    displayCustomers();
    deleteCustomer(1);
    displayCustomers();
    
    addSportArea(1, "Tennis Court");
    addSportArea(2, "Swimming Pool");
    updateSportArea(2, "Olympic Pool");
    displaySportAreas();
    deleteSportArea(1);
    displaySportAreas();
    
    return 0;
}