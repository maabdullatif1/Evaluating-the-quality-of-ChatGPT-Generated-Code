#include <iostream>
#include <string>
#include <vector>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;
    Customer(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    std::string name;
    std::string type;
    bool isAvailable;
    SportArea(int id, std::string name, std::string type, bool isAvailable)
        : id(id), name(name), type(type), isAvailable(isAvailable) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
    
    int findCustomerById(int id) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) return i;
        }
        return -1;
    }

    int findSportAreaById(int id) {
        for (size_t i = 0; i < sportAreas.size(); ++i) {
            if (sportAreas[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCustomer(int id, std::string name, std::string contact) {
        if (findCustomerById(id) == -1) {
            customers.push_back(Customer(id, name, contact));
        }
    }

    void deleteCustomer(int id) {
        int index = findCustomerById(id);
        if (index != -1) {
            customers.erase(customers.begin() + index);
        }
    }

    void updateCustomer(int id, std::string name, std::string contact) {
        int index = findCustomerById(id);
        if (index != -1) {
            customers[index].name = name;
            customers[index].contact = contact;
        }
    }

    Customer* searchCustomer(int id) {
        int index = findCustomerById(id);
        if (index != -1) {
            return &customers[index];
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id 
                      << ", Name: " << customer.name 
                      << ", Contact: " << customer.contact << std::endl;
        }
    }

    void addSportArea(int id, std::string name, std::string type, bool isAvailable) {
        if (findSportAreaById(id) == -1) {
            sportAreas.push_back(SportArea(id, name, type, isAvailable));
        }
    }

    void deleteSportArea(int id) {
        int index = findSportAreaById(id);
        if (index != -1) {
            sportAreas.erase(sportAreas.begin() + index);
        }
    }

    void updateSportArea(int id, std::string name, std::string type, bool isAvailable) {
        int index = findSportAreaById(id);
        if (index != -1) {
            sportAreas[index].name = name;
            sportAreas[index].type = type;
            sportAreas[index].isAvailable = isAvailable;
        }
    }

    SportArea* searchSportArea(int id) {
        int index = findSportAreaById(id);
        if (index != -1) {
            return &sportAreas[index];
        }
        return nullptr;
    }

    void displaySportAreas() {
        for (const auto& sportArea : sportAreas) {
            std::cout << "ID: " << sportArea.id 
                      << ", Name: " << sportArea.name 
                      << ", Type: " << sportArea.type
                      << ", Available: " << (sportArea.isAvailable ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    
    system.addCustomer(1, "Alice", "123-456-7890");
    system.addCustomer(2, "Bob", "987-654-3210");
    
    system.addSportArea(1, "Court 1", "Tennis", true);
    system.addSportArea(2, "Field 1", "Soccer", false);
    
    std::cout << "Customers:" << std::endl;
    system.displayCustomers();
    
    std::cout << "\nSport Areas:" << std::endl;
    system.displaySportAreas();
    
    return 0;
}