#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string contactInfo;

    Customer(int id, string name, string contactInfo)
        : id(id), name(name), contactInfo(contactInfo) {}
};

class SportArea {
public:
    int id;
    string name;
    string status;

    SportArea(int id, string name, string status)
        : id(id), name(name), status(status) {}
};

class ReservationSystem {
private:
    vector<Customer> customers;
    vector<SportArea> sportAreas;
    int customerCounter = 1;
    int sportsAreaCounter = 1;

public:
    void addCustomer(string name, string contactInfo) {
        customers.push_back(Customer(customerCounter++, name, contactInfo));
    }

    void addSportArea(string name, string status) {
        sportAreas.push_back(SportArea(sportsAreaCounter++, name, status));
    }

    bool deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return true;
            }
        }
        return false;
    }

    bool deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateCustomer(int id, string name, string contactInfo) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contactInfo = contactInfo;
                return true;
            }
        }
        return false;
    }

    bool updateSportArea(int id, string name, string status) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                area.name = name;
                area.status = status;
                return true;
            }
        }
        return false;
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    SportArea* searchSportArea(int id) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                return &area;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "ID: " << customer.id << ", Name: " << customer.name
                 << ", Contact Info: " << customer.contactInfo << endl;
        }
    }

    void displaySportAreas() {
        for (const auto& area : sportAreas) {
            cout << "ID: " << area.id << ", Name: " << area.name
                 << ", Status: " << area.status << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer("Alice", "alice@example.com");
    system.addCustomer("Bob", "bob@example.com");
    system.addSportArea("Tennis Court", "Available");
    system.addSportArea("Football Field", "Occupied");

    system.displayCustomers();
    system.displaySportAreas();

    system.updateCustomer(1, "Alice Smith", "alice.smith@example.com");
    system.deleteSportArea(2);

    Customer* customer = system.searchCustomer(1);
    if (customer) {
        cout << "Found Customer - ID: " << customer->id << ", Name: " << customer->name << endl;
    }

    system.displayCustomers();
    system.displaySportAreas();

    return 0;
}