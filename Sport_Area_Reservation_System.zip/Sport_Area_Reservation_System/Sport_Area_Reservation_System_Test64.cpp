#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;

    Customer(int id, const std::string &name, const std::string &contact)
        : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    std::string name;
    bool available;

    SportArea(int id, const std::string &name, bool available)
        : id(id), name(name), available(available) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;

public:
    bool addCustomer(int id, const std::string &name, const std::string &contact) {
        for (const auto &customer : customers) {
            if (customer.id == id) return false;
        }
        customers.emplace_back(id, name, contact);
        return true;
    }

    bool deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateCustomer(int id, const std::string &name, const std::string &contact) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                return true;
            }
        }
        return false;
    }

    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) return &customer;
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << std::endl;
        }
    }

    bool addSportArea(int id, const std::string &name, bool available) {
        for (const auto &area : sportAreas) {
            if (area.id == id) return false;
        }
        sportAreas.emplace_back(id, name, available);
        return true;
    }

    bool deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateSportArea(int id, const std::string &name, bool available) {
        for (auto &area : sportAreas) {
            if (area.id == id) {
                area.name = name;
                area.available = available;
                return true;
            }
        }
        return false;
    }

    SportArea* searchSportArea(int id) {
        for (auto &area : sportAreas) {
            if (area.id == id) return &area;
        }
        return nullptr;
    }

    void displaySportAreas() {
        for (const auto &area : sportAreas) {
            std::cout << "ID: " << area.id << ", Name: " << area.name << ", Available: " << (area.available ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "Alice", "123456789");
    system.addCustomer(2, "Bob", "987654321");
    system.addSportArea(1, "Court A", true);
    system.addSportArea(2, "Court B", false);

    std::cout << "Customers:" << std::endl;
    system.displayCustomers();

    std::cout << "\nSport Areas:" << std::endl;
    system.displaySportAreas();

    return 0;
}