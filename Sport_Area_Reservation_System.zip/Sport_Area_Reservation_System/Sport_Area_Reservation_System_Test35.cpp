#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct SportArea {
    int areaId;
    string name;
    string type;
};

vector<Customer> customers;
vector<SportArea> sportAreas;

void addCustomer() {
    Customer customer;
    cout << "Enter customer ID: ";
    cin >> customer.id;
    cout << "Enter customer name: ";
    cin >> customer.name;
    cout << "Enter customer phone: ";
    cin >> customer.phone;
    customers.push_back(customer);
}

void deleteCustomer() {
    int id;
    cout << "Enter customer ID to delete: ";
    cin >> id;
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            return;
        }
    }
}

void updateCustomer() {
    int id;
    cout << "Enter customer ID to update: ";
    cin >> id;
    for (auto& customer : customers) {
        if (customer.id == id) {
            cout << "Enter new customer name: ";
            cin >> customer.name;
            cout << "Enter new customer phone: ";
            cin >> customer.phone;
            return;
        }
    }
}

void searchCustomer() {
    int id;
    cout << "Enter customer ID to search: ";
    cin >> id;
    for (const auto& customer : customers) {
        if (customer.id == id) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << endl;
            return;
        }
    }
    cout << "Customer not found." << endl;
}

void displayCustomers() {
    for (const auto& customer : customers) {
        cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << endl;
    }
}

void addSportArea() {
    SportArea area;
    cout << "Enter sport area ID: ";
    cin >> area.areaId;
    cout << "Enter sport area name: ";
    cin >> area.name;
    cout << "Enter sport area type: ";
    cin >> area.type;
    sportAreas.push_back(area);
}

void deleteSportArea() {
    int id;
    cout << "Enter sport area ID to delete: ";
    cin >> id;
    for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
        if (it->areaId == id) {
            sportAreas.erase(it);
            return;
        }
    }
}

void updateSportArea() {
    int id;
    cout << "Enter sport area ID to update: ";
    cin >> id;
    for (auto& area : sportAreas) {
        if (area.areaId == id) {
            cout << "Enter new sport area name: ";
            cin >> area.name;
            cout << "Enter new sport area type: ";
            cin >> area.type;
            return;
        }
    }
}

void searchSportArea() {
    int id;
    cout << "Enter sport area ID to search: ";
    cin >> id;
    for (const auto& area : sportAreas) {
        if (area.areaId == id) {
            cout << "Sport Area ID: " << area.areaId << ", Name: " << area.name << ", Type: " << area.type << endl;
            return;
        }
    }
    cout << "Sport area not found." << endl;
}

void displaySportAreas() {
    for (const auto& area : sportAreas) {
        cout << "Sport Area ID: " << area.areaId << ", Name: " << area.name << ", Type: " << area.type << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "Menu:\n";
        cout << "1. Add Customer\n2. Delete Customer\n3. Update Customer\n4. Search Customer\n5. Display Customers\n";
        cout << "6. Add Sport Area\n7. Delete Sport Area\n8. Update Sport Area\n9. Search Sport Area\n10. Display Sport Areas\n11. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addCustomer(); break;
            case 2: deleteCustomer(); break;
            case 3: updateCustomer(); break;
            case 4: searchCustomer(); break;
            case 5: displayCustomers(); break;
            case 6: addSportArea(); break;
            case 7: deleteSportArea(); break;
            case 8: updateSportArea(); break;
            case 9: searchSportArea(); break;
            case 10: displaySportAreas(); break;
            case 11: break;
            default: cout << "Invalid choice." << endl;
        }
    } while (choice != 11);
    return 0;
}