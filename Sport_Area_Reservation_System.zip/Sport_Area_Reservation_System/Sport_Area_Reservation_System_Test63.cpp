#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string phone;
    
    Customer(int id, string name, string phone) : id(id), name(name), phone(phone) {}
};

class SportArea {
public:
    int id;
    string name;
    bool isReserved;
    
    SportArea(int id, string name) : id(id), name(name), isReserved(false) {}
};

class ReservationSystem {
    vector<Customer> customers;
    vector<SportArea> sportAreas;
    int customerIDCounter = 1;
    int sportAreaIDCounter = 1;
    
public:
    void addCustomer(string name, string phone) {
        customers.push_back(Customer(customerIDCounter++, name, phone));
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, string name, string phone) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phone = phone;
                break;
            }
        }
    }
    
    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }
    
    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << endl;
        }
    }
    
    void addSportArea(string name) {
        sportAreas.push_back(SportArea(sportAreaIDCounter++, name));
    }
    
    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }
    
    void updateSportArea(int id, string name, bool isReserved) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.isReserved = isReserved;
                break;
            }
        }
    }
    
    SportArea* searchSportArea(int id) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                return &sportArea;
            }
        }
        return nullptr;
    }
    
    void displaySportAreas() {
        for (const auto &sportArea : sportAreas) {
            cout << "ID: " << sportArea.id << ", Name: " << sportArea.name << ", Reserved: " << (sportArea.isReserved ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    
    system.addCustomer("John Doe", "123456789");
    system.addCustomer("Jane Smith", "987654321");
    
    system.addSportArea("Tennis Court");
    system.addSportArea("Football Field");
    
    cout << "Customers:" << endl;
    system.displayCustomers();
    
    cout << "Sport Areas:" << endl;
    system.displaySportAreas();
    
    system.updateCustomer(1, "Johnathan Doe", "555555555");
    system.updateSportArea(1, "Tennis Court", true);
    
    cout << "Updated Customers:" << endl;
    system.displayCustomers();
    
    cout << "Updated Sport Areas:" << endl;
    system.displaySportAreas();
    
    system.deleteCustomer(2);
    system.deleteSportArea(2);
    
    cout << "After Deletion Customers:" << endl;
    system.displayCustomers();
    
    cout << "After Deletion Sport Areas:" << endl;
    system.displaySportAreas();

    return 0;
}