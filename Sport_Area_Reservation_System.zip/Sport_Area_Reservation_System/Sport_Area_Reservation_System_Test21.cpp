#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Customer {
    int id;
    string name;
    string contact;
};

struct SportArea {
    int id;
    string name;
    string type;
    bool reserved;
};

class ReservationSystem {
private:
    vector<Customer> customers;
    vector<SportArea> sportAreas;
    int customerCounter;
    int sportAreaCounter;

public:
    ReservationSystem() : customerCounter(0), sportAreaCounter(0) {}

    void addCustomer(string name, string contact) {
        customers.push_back({++customerCounter, name, contact});
    }

    void addSportArea(string name, string type) {
        sportAreas.push_back({++sportAreaCounter, name, type, false});
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                return;
            }
        }
    }

    void updateCustomer(int id, string name, string contact) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                return;
            }
        }
    }

    void updateSportArea(int id, string name, string type, bool reserved) {
        for (auto &area : sportAreas) {
            if (area.id == id) {
                area.name = name;
                area.type = type;
                area.reserved = reserved;
                return;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    SportArea* searchSportArea(int id) {
        for (auto &area : sportAreas) {
            if (area.id == id) {
                return &area;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "Customer ID: " << customer.id 
                 << ", Name: " << customer.name 
                 << ", Contact: " << customer.contact << endl;
        }
    }

    void displaySportAreas() {
        for (const auto &area : sportAreas) {
            cout << "Sport Area ID: " << area.id 
                 << ", Name: " << area.name 
                 << ", Type: " << area.type 
                 << ", Reserved: " << (area.reserved ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    
    system.addCustomer("John Doe", "123456789");
    system.addCustomer("Jane Smith", "987654321");
    system.displayCustomers();

    system.addSportArea("Tennis Court", "Outdoor");
    system.addSportArea("Swimming Pool", "Indoor");
    system.displaySportAreas();

    system.updateCustomer(1, "John Doe", "111111111");
    system.updateSportArea(1, "Tennis Court", "Outdoor", true);

    Customer* customer = system.searchCustomer(1);
    if (customer) {
        cout << "Found Customer: " << customer->name << endl;
    }

    SportArea* sportArea = system.searchSportArea(1);
    if (sportArea) {
        cout << "Found Sport Area: " << sportArea->name << endl;
    }

    system.deleteCustomer(2);
    system.deleteSportArea(2);

    system.displayCustomers();
    system.displaySportAreas();

    return 0;
}