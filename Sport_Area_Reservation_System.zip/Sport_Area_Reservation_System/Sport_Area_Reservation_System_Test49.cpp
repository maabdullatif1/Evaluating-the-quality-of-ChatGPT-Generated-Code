#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string phone;
    
    Customer(int id, const string& name, const string& phone) : id(id), name(name), phone(phone) {}
};

class SportArea {
public:
    int id;
    string name;
    string type;
    
    SportArea(int id, const string& name, const string& type) : id(id), name(name), type(type) {}
};

class ReservationSystem {
private:
    vector<Customer> customers;
    vector<SportArea> areas;

    Customer* findCustomerById(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) return &customer;
        }
        return nullptr;
    }

    SportArea* findAreaById(int id) {
        for (auto& area : areas) {
            if (area.id == id) return &area;
        }
        return nullptr;
    }

public:
    void addCustomer(int id, const string& name, const string& phone) {
        customers.push_back(Customer(id, name, phone));
    }

    void deleteCustomer(int id) {
        auto it = remove_if(customers.begin(), customers.end(), [id](Customer& c) { return c.id == id; });
        if (it != customers.end()) customers.erase(it, customers.end());
    }

    void updateCustomer(int id, const string& name, const string& phone) {
        Customer* customer = findCustomerById(id);
        if (customer) {
            customer->name = name;
            customer->phone = phone;
        }
    }

    void searchCustomer(int id) {
        Customer* customer = findCustomerById(id);
        if (customer) {
            cout << "Customer ID: " << customer->id << ", Name: " << customer->name << ", Phone: " << customer->phone << endl;
        }
    }

    void displayCustomers() {
        for (const auto& c : customers) {
            cout << "Customer ID: " << c.id << ", Name: " << c.name << ", Phone: " << c.phone << endl;
        }
    }

    void addArea(int id, const string& name, const string& type) {
        areas.push_back(SportArea(id, name, type));
    }

    void deleteArea(int id) {
        auto it = remove_if(areas.begin(), areas.end(), [id](SportArea& a) { return a.id == id; });
        if (it != areas.end()) areas.erase(it, areas.end());
    }

    void updateArea(int id, const string& name, const string& type) {
        SportArea* area = findAreaById(id);
        if (area) {
            area->name = name;
            area->type = type;
        }
    }

    void searchArea(int id) {
        SportArea* area = findAreaById(id);
        if (area) {
            cout << "Area ID: " << area->id << ", Name: " << area->name << ", Type: " << area->type << endl;
        }
    }

    void displayAreas() {
        for (const auto& a : areas) {
            cout << "Area ID: " << a.id << ", Name: " << a.name << ", Type: " << a.type << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    
    system.addCustomer(1, "John Doe", "123-456-7890");
    system.addCustomer(2, "Jane Smith", "098-765-4321");
    
    system.addArea(1, "Basketball Court", "Indoor");
    system.addArea(2, "Tennis Court", "Outdoor");

    system.displayCustomers();
    system.displayAreas();

    return 0;
}