#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string phone;
    Customer(int i, std::string n, std::string p) : id(i), name(n), phone(p) {}
};

class SportArea {
public:
    int id;
    std::string name;
    std::string type;
    SportArea(int i, std::string n, std::string t) : id(i), name(n), type(t) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
    int customerCounter;
    int sportAreaCounter;

public:
    ReservationSystem() : customerCounter(0), sportAreaCounter(0) {}

    void addCustomer(std::string name, std::string phone) {
        customers.push_back(Customer(++customerCounter, name, phone));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string phone) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phone = phone;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << std::endl;
        }
    }

    void addSportArea(std::string name, std::string type) {
        sportAreas.push_back(SportArea(++sportAreaCounter, name, type));
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, std::string name, std::string type) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                area.name = name;
                area.type = type;
                break;
            }
        }
    }

    SportArea* searchSportArea(int id) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                return &area;
            }
        }
        return nullptr;
    }

    void displaySportAreas() {
        for (auto& area : sportAreas) {
            std::cout << "Sport Area ID: " << area.id << ", Name: " << area.name << ", Type: " << area.type << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer("John Doe", "123456789");
    system.addCustomer("Jane Smith", "987654321");
    system.displayCustomers();

    system.addSportArea("Soccer Field", "Outdoor");
    system.addSportArea("Basketball Court", "Indoor");
    system.displaySportAreas();

    system.updateCustomer(1, "Johnny Doe", "111111111");
    Customer* customer = system.searchCustomer(1);
    if (customer) {
        std::cout << "Found Customer - ID: " << customer->id << ", Name: " << customer->name << ", Phone: " << customer->phone << std::endl;
    }

    system.updateSportArea(1, "Football Field", "Outdoor");
    SportArea* area = system.searchSportArea(1);
    if (area) {
        std::cout << "Found Sport Area - ID: " << area->id << ", Name: " << area->name << ", Type: " << area->type << std::endl;
    }

    system.deleteCustomer(2);
    system.displayCustomers();

    system.deleteSportArea(2);
    system.displaySportAreas();

    return 0;
}