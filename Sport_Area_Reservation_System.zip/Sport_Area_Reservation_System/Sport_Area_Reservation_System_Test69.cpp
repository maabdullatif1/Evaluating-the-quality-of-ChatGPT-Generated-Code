#include <iostream>
#include <string>
#include <vector>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;

    Customer(int i, std::string n, std::string c) : id(i), name(n), contact(c) {}
};

class SportArea {
public:
    int id;
    std::string name;
    std::string type;

    SportArea(int i, std::string n, std::string t) : id(i), name(n), type(t) {}
};

class ReservationSystem {
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;

public:
    void addCustomer(int id, std::string name, std::string contact) {
        customers.push_back(Customer(id, name, contact));
    }

    void deleteCustomer(int id) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) {
                customers.erase(customers.begin() + i);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string contact) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << std::endl;
        }
    }

    void addSportArea(int id, std::string name, std::string type) {
        sportAreas.push_back(SportArea(id, name, type));
    }

    void deleteSportArea(int id) {
        for (size_t i = 0; i < sportAreas.size(); ++i) {
            if (sportAreas[i].id == id) {
                sportAreas.erase(sportAreas.begin() + i);
                break;
            }
        }
    }

    void updateSportArea(int id, std::string name, std::string type) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.type = type;
                break;
            }
        }
    }

    SportArea* searchSportArea(int id) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                return &sportArea;
            }
        }
        return nullptr;
    }

    void displaySportAreas() {
        for (const auto &sportArea : sportAreas) {
            std::cout << "ID: " << sportArea.id << ", Name: " << sportArea.name << ", Type: " << sportArea.type << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "John Doe", "123456789");
    system.addCustomer(2, "Jane Smith", "987654321");
    system.addSportArea(1, "Basketball Court", "Indoor");
    system.addSportArea(2, "Tennis Court", "Outdoor");
    system.displayCustomers();
    system.displaySportAreas();
    system.updateCustomer(1, "John Doe", "111111111");
    system.updateSportArea(2, "Tennis Court", "Indoor");
    Customer* c = system.searchCustomer(1);
    if (c) std::cout << "Found customer: " << c->name << std::endl;
    SportArea* s = system.searchSportArea(1);
    if (s) std::cout << "Found sport area: " << s->name << std::endl;
    system.deleteCustomer(2);
    system.deleteSportArea(2);
    system.displayCustomers();
    system.displaySportAreas();
    return 0;
}