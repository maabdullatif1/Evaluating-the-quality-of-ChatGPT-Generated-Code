#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct SportArea {
    int id;
    string name;
    string type;
    int capacity;
};

vector<Customer> customers;
vector<SportArea> sportAreas;

int getCustomerById(int id) {
    for (int i = 0; i < customers.size(); i++) {
        if (customers[i].id == id) {
            return i;
        }
    }
    return -1;
}

int getSportAreaById(int id) {
    for (int i = 0; i < sportAreas.size(); i++) {
        if (sportAreas[i].id == id) {
            return i;
        }
    }
    return -1;
}

void addCustomer(int id, string name, string phone) {
    Customer newCustomer = {id, name, phone};
    customers.push_back(newCustomer);
}

void deleteCustomer(int id) {
    int index = getCustomerById(id);
    if (index != -1) {
        customers.erase(customers.begin() + index);
    }
}

void updateCustomer(int id, string name, string phone) {
    int index = getCustomerById(id);
    if (index != -1) {
        customers[index].name = name;
        customers[index].phone = phone;
    }
}

void searchCustomer(int id) {
    int index = getCustomerById(id);
    if (index != -1) {
        cout << "ID: " << customers[index].id << " Name: " << customers[index].name << " Phone: " << customers[index].phone << endl;
    } else {
        cout << "Customer not found" << endl;
    }
}

void displayCustomers() {
    for (int i = 0; i < customers.size(); i++) {
        cout << "ID: " << customers[i].id << " Name: " << customers[i].name << " Phone: " << customers[i].phone << endl;
    }
}

void addSportArea(int id, string name, string type, int capacity) {
    SportArea newArea = {id, name, type, capacity};
    sportAreas.push_back(newArea);
}

void deleteSportArea(int id) {
    int index = getSportAreaById(id);
    if (index != -1) {
        sportAreas.erase(sportAreas.begin() + index);
    }
}

void updateSportArea(int id, string name, string type, int capacity) {
    int index = getSportAreaById(id);
    if (index != -1) {
        sportAreas[index].name = name;
        sportAreas[index].type = type;
        sportAreas[index].capacity = capacity;
    }
}

void searchSportArea(int id) {
    int index = getSportAreaById(id);
    if (index != -1) {
        cout << "ID: " << sportAreas[index].id << " Name: " << sportAreas[index].name << " Type: " << sportAreas[index].type << " Capacity: " << sportAreas[index].capacity << endl;
    } else {
        cout << "Sport area not found" << endl;
    }
}

void displaySportAreas() {
    for (int i = 0; i < sportAreas.size(); i++) {
        cout << "ID: " << sportAreas[i].id << " Name: " << sportAreas[i].name << " Type: " << sportAreas[i].type << " Capacity: " << sportAreas[i].capacity << endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "1234567890");
    addCustomer(2, "Jane Smith", "0987654321");
    displayCustomers();
    updateCustomer(1, "John Williams", "1122334455");
    searchCustomer(1);
    deleteCustomer(2);
    displayCustomers();

    addSportArea(1, "Football Field", "Outdoor", 30);
    addSportArea(2, "Basketball Court", "Indoor", 15);
    displaySportAreas();
    updateSportArea(1, "Soccer Field", "Outdoor", 25);
    searchSportArea(1);
    deleteSportArea(2);
    displaySportAreas();

    return 0;
}