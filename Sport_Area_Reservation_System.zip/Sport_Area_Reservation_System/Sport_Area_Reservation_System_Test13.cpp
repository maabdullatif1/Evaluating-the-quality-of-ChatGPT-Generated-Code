#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string contact;

    Customer(int id, string name, string contact)
        : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    string name;
    int capacity;

    SportArea(int id, string name, int capacity)
        : id(id), name(name), capacity(capacity) {}
};

class ReservationSystem {
    vector<Customer> customers;
    vector<SportArea> sportAreas;

public:
    void addCustomer(int id, const string& name, const string& contact) {
        customers.push_back(Customer(id, name, contact));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const string& newName, const string& newContact) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = newName;
                customer.contact = newContact;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
                return;
            }
        }
        cout << "Customer not found." << endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
        }
    }

    void addSportArea(int id, const string& name, int capacity) {
        sportAreas.push_back(SportArea(id, name, capacity));
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, const string& newName, int newCapacity) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                area.name = newName;
                area.capacity = newCapacity;
                break;
            }
        }
    }

    void searchSportArea(int id) {
        for (const auto& area : sportAreas) {
            if (area.id == id) {
                cout << "Sport Area ID: " << area.id << ", Name: " << area.name << ", Capacity: " << area.capacity << endl;
                return;
            }
        }
        cout << "Sport area not found." << endl;
    }

    void displaySportAreas() {
        for (const auto& area : sportAreas) {
            cout << "Sport Area ID: " << area.id << ", Name: " << area.name << ", Capacity: " << area.capacity << endl;
        }
    }
};

int main() {
    ReservationSystem system;

    system.addCustomer(1, "John Doe", "123-456-789");
    system.addCustomer(2, "Jane Smith", "987-654-321");
    
    system.addSportArea(1, "Football Field", 22);
    system.addSportArea(2, "Basketball Court", 10);

    system.displayCustomers();
    system.displaySportAreas();

    system.updateCustomer(1, "Johnathan Doe", "111-222-333");
    system.updateSportArea(2, "Indoor Basketball Court", 12);

    system.displayCustomers();
    system.displaySportAreas();

    system.searchCustomer(1);
    system.searchSportArea(2);

    system.deleteCustomer(2);
    system.deleteSportArea(1);

    system.displayCustomers();
    system.displaySportAreas();

    return 0;
}