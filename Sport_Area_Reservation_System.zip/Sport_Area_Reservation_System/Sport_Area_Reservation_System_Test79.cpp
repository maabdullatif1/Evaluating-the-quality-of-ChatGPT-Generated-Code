#include <iostream>
#include <string>
#include <vector>

struct Customer {
    int id;
    std::string name;
};

struct SportArea {
    int id;
    std::string name;
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;

    Customer* findCustomerById(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) return &customer;
        }
        return nullptr;
    }

    SportArea* findSportAreaById(int id) {
        for (auto& area : sportAreas) {
            if (area.id == id) return &area;
        }
        return nullptr;
    }

public:
    void addCustomer(int id, const std::string& name) {
        if (!findCustomerById(id)) {
            customers.push_back({ id, name });
        }
    }

    void deleteCustomer(int id) {
        customers.erase(std::remove_if(customers.begin(), customers.end(),
                      [id](Customer& c) { return c.id == id; }), customers.end());
    }

    void updateCustomer(int id, const std::string& name) {
        Customer* customer = findCustomerById(id);
        if (customer) {
            customer->name = name;
        }
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << std::endl;
        }
    }

    void addSportArea(int id, const std::string& name) {
        if (!findSportAreaById(id)) {
            sportAreas.push_back({ id, name });
        }
    }

    void deleteSportArea(int id) {
        sportAreas.erase(std::remove_if(sportAreas.begin(), sportAreas.end(),
                       [id](SportArea& s) { return s.id == id; }), sportAreas.end());
    }

    void updateSportArea(int id, const std::string& name) {
        SportArea* area = findSportAreaById(id);
        if (area) {
            area->name = name;
        }
    }

    void displaySportAreas() {
        for (const auto& area : sportAreas) {
            std::cout << "Sport Area ID: " << area.id << ", Name: " << area.name << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "John Doe");
    system.addCustomer(2, "Jane Smith");
    system.addSportArea(1, "Tennis Court");
    system.addSportArea(2, "Swimming Pool");

    std::cout << "Customers:" << std::endl;
    system.displayCustomers();
    std::cout << std::endl;

    std::cout << "Sport Areas:" << std::endl;
    system.displaySportAreas();
    std::cout << std::endl;

    system.updateCustomer(1, "John Updated");
    system.updateSportArea(2, "Updated Pool");

    std::cout << "Updated Information:" << std::endl;
    system.displayCustomers();
    system.displaySportAreas();
    
    return 0;
}