#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string contact;

    Customer(int i, string n, string c) : id(i), name(n), contact(c) {}
};

class SportArea {
public:
    int id;
    string name;
    double price_per_hour;

    SportArea(int i, string n, double p) : id(i), name(n), price_per_hour(p) {}
};

class ReservationSystem {
private:
    vector<Customer> customers;
    vector<SportArea> sportAreas;

public:
    void addCustomer(int id, string name, string contact) {
        customers.push_back(Customer(id, name, contact));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string contact) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto &customer : customers) {
            if (customer.id == id) {
                cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
                break;
            }
        }
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
        }
    }

    void addSportArea(int id, string name, double price) {
        sportAreas.push_back(SportArea(id, name, price));
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, string name, double price) {
        for (auto &area : sportAreas) {
            if (area.id == id) {
                area.name = name;
                area.price_per_hour = price;
                break;
            }
        }
    }

    void searchSportArea(int id) {
        for (const auto &area : sportAreas) {
            if (area.id == id) {
                cout << "Sport Area ID: " << area.id << ", Name: " << area.name << ", Price per hour: " << area.price_per_hour << endl;
                break;
            }
        }
    }

    void displaySportAreas() {
        for (const auto &area : sportAreas) {
            cout << "Sport Area ID: " << area.id << ", Name: " << area.name << ", Price per hour: " << area.price_per_hour << endl;
        }
    }
};

int main() {
    ReservationSystem system;

    system.addCustomer(1, "John Doe", "123456789");
    system.addCustomer(2, "Jane Smith", "987654321");
    system.addSportArea(1, "Tennis Court", 20.0);
    system.addSportArea(2, "Basketball Court", 15.0);

    cout << "Customers:" << endl;
    system.displayCustomers();
    cout << "\nSport Areas:" << endl;
    system.displaySportAreas();

    return 0;
}