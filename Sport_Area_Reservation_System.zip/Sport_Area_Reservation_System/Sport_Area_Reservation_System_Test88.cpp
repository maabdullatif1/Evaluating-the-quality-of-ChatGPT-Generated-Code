#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string phoneNumber;

    Customer(int id, string name, string phoneNumber)
        : id(id), name(name), phoneNumber(phoneNumber) {}
};

class SportArea {
public:
    int id;
    string name;
    bool isAvailable;

    SportArea(int id, string name, bool isAvailable = true)
        : id(id), name(name), isAvailable(isAvailable) {}
};

class ReservationSystem {
    vector<Customer> customers;
    vector<SportArea> sportAreas;

public:
    void addCustomer(int id, string name, string phoneNumber) {
        customers.push_back(Customer(id, name, phoneNumber));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string phoneNumber) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phoneNumber = phoneNumber;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phoneNumber << endl;
                return;
            }
        }
        cout << "Customer not found." << endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phoneNumber << endl;
        }
    }

    void addSportArea(int id, string name) {
        sportAreas.push_back(SportArea(id, name));
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, string name, bool isAvailable) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                area.name = name;
                area.isAvailable = isAvailable;
                break;
            }
        }
    }

    void searchSportArea(int id) {
        for (const auto& area : sportAreas) {
            if (area.id == id) {
                cout << "Sport Area ID: " << area.id << ", Name: " << area.name << ", Availability: " 
                     << (area.isAvailable ? "Available" : "Unavailable") << endl;
                return;
            }
        }
        cout << "Sport Area not found." << endl;
    }

    void displaySportAreas() {
        for (const auto& area : sportAreas) {
            cout << "Sport Area ID: " << area.id << ", Name: " << area.name << ", Availability: " 
                 << (area.isAvailable ? "Available" : "Unavailable") << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "Alice", "123456789");
    system.addCustomer(2, "Bob", "987654321");
    
    system.addSportArea(101, "Tennis Court");
    system.addSportArea(102, "Football Field");

    system.displayCustomers();
    system.displaySportAreas();

    system.updateCustomer(1, "Alice Smith", "123450987");
    system.updateSportArea(101, "Tennis Court", false);

    system.searchCustomer(1);
    system.searchSportArea(101);

    system.deleteCustomer(2);
    system.deleteSportArea(102);

    system.displayCustomers();
    system.displaySportAreas();

    return 0;
}