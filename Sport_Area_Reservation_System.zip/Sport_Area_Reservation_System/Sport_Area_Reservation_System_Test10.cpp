#include <iostream>
#include <string>
#include <vector>

struct Customer {
    int id;
    std::string name;
    std::string phone;
};

struct SportArea {
    int areaId;
    std::string name;
    bool isAvailable;
};

std::vector<Customer> customers;
std::vector<SportArea> sportAreas;

void addCustomer(int id, const std::string& name, const std::string& phone) {
    customers.push_back({id, name, phone});
}

void deleteCustomer(int id) {
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            break;
        }
    }
}

void updateCustomer(int id, const std::string& name, const std::string& phone) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            customer.name = name;
            customer.phone = phone;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            return &customer;
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (const auto& customer : customers) {
        std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << std::endl;
    }
}

void addSportArea(int areaId, const std::string& name) {
    sportAreas.push_back({areaId, name, true});
}

void deleteSportArea(int areaId) {
    for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
        if (it->areaId == areaId) {
            sportAreas.erase(it);
            break;
        }
    }
}

void updateSportArea(int areaId, const std::string& name, bool isAvailable) {
    for (auto& area : sportAreas) {
        if (area.areaId == areaId) {
            area.name = name;
            area.isAvailable = isAvailable;
            break;
        }
    }
}

SportArea* searchSportArea(int areaId) {
    for (auto& area : sportAreas) {
        if (area.areaId == areaId) {
            return &area;
        }
    }
    return nullptr;
}

void displaySportAreas() {
    for (const auto& area : sportAreas) {
        std::cout << "Area ID: " << area.areaId << ", Name: " << area.name << ", Available: " << (area.isAvailable ? "Yes" : "No") << std::endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "123-456-7890");
    addCustomer(2, "Jane Smith", "098-765-4321");

    addSportArea(101, "Tennis Court");
    addSportArea(102, "Swimming Pool");

    displayCustomers();
    displaySportAreas();

    updateCustomer(1, "John Michael", "321-654-0987");
    updateSportArea(101, "Tennis Court", false);

    Customer* customer = searchCustomer(1);
    if (customer) {
        std::cout << "Found Customer - ID: " << customer->id << ", Name: " << customer->name << std::endl;
    }

    SportArea* area = searchSportArea(101);
    if (area) {
        std::cout << "Found Sport Area - Area ID: " << area->areaId << ", Name: " << area->name << std::endl;
    }

    deleteCustomer(2);
    deleteSportArea(102);

    displayCustomers();
    displaySportAreas();

    return 0;
}