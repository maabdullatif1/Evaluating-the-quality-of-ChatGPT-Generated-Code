#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Customer {
    int id;
    string name;
    string contact;
};

struct SportArea {
    int id;
    string name;
    bool isAvailable;
};

vector<Customer> customers;
vector<SportArea> sportAreas;

void addCustomer() {
    Customer customer;
    cout << "Enter customer ID: ";
    cin >> customer.id;
    cout << "Enter customer name: ";
    cin.ignore();
    getline(cin, customer.name);
    cout << "Enter customer contact: ";
    getline(cin, customer.contact);
    customers.push_back(customer);
}

void deleteCustomer() {
    int id;
    cout << "Enter customer ID to delete: ";
    cin >> id;
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            return;
        }
    }
    cout << "Customer not found." << endl;
}

void updateCustomer() {
    int id;
    cout << "Enter customer ID to update: ";
    cin >> id;
    for (auto& customer : customers) {
        if (customer.id == id) {
            cout << "Enter new customer name: ";
            cin.ignore();
            getline(cin, customer.name);
            cout << "Enter new customer contact: ";
            getline(cin, customer.contact);
            return;
        }
    }
    cout << "Customer not found." << endl;
}

void searchCustomer() {
    int id;
    cout << "Enter customer ID to search: ";
    cin >> id;
    for (const auto& customer : customers) {
        if (customer.id == id) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
            return;
        }
    }
    cout << "Customer not found." << endl;
}

void displayCustomers() {
    if (customers.empty()) {
        cout << "No customers available." << endl;
        return;
    }
    for (const auto& customer : customers) {
        cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
    }
}

void addSportArea() {
    SportArea area;
    cout << "Enter sport area ID: ";
    cin >> area.id;
    cout << "Enter sport area name: ";
    cin.ignore();
    getline(cin, area.name);
    area.isAvailable = true;
    sportAreas.push_back(area);
}

void deleteSportArea() {
    int id;
    cout << "Enter sport area ID to delete: ";
    cin >> id;
    for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
        if (it->id == id) {
            sportAreas.erase(it);
            return;
        }
    }
    cout << "Sport area not found." << endl;
}

void updateSportArea() {
    int id;
    cout << "Enter sport area ID to update: ";
    cin >> id;
    for (auto& area : sportAreas) {
        if (area.id == id) {
            cout << "Enter new sport area name: ";
            cin.ignore();
            getline(cin, area.name);
            cout << "Is area available? (1 for Yes, 0 for No): ";
            cin >> area.isAvailable;
            return;
        }
    }
    cout << "Sport area not found." << endl;
}

void searchSportArea() {
    int id;
    cout << "Enter sport area ID to search: ";
    cin >> id;
    for (const auto& area : sportAreas) {
        if (area.id == id) {
            cout << "Sport Area ID: " << area.id << ", Name: " << area.name << ", Available: " << (area.isAvailable ? "Yes" : "No") << endl;
            return;
        }
    }
    cout << "Sport area not found." << endl;
}

void displaySportAreas() {
    if (sportAreas.empty()) {
        cout << "No sport areas available." << endl;
        return;
    }
    for (const auto& area : sportAreas) {
        cout << "Sport Area ID: " << area.id << ", Name: " << area.name << ", Available: " << (area.isAvailable ? "Yes" : "No") << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Customer\n2. Delete Customer\n3. Update Customer\n4. Search Customer\n5. Display Customers\n";
        cout << "6. Add Sport Area\n7. Delete Sport Area\n8. Update Sport Area\n9. Search Sport Area\n10. Display Sport Areas\n11. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addCustomer(); break;
            case 2: deleteCustomer(); break;
            case 3: updateCustomer(); break;
            case 4: searchCustomer(); break;
            case 5: displayCustomers(); break;
            case 6: addSportArea(); break;
            case 7: deleteSportArea(); break;
            case 8: updateSportArea(); break;
            case 9: searchSportArea(); break;
            case 10: displaySportAreas(); break;
            case 11: break;
            default: cout << "Invalid choice." << endl; break;
        }
    } while (choice != 11);
    return 0;
}