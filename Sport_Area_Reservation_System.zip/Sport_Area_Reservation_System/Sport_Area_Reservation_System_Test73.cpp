#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
};

struct SportArea {
    int id;
    string name;
    bool isReserved;
};

Customer customers[100];
SportArea sportAreas[100];
int customerCount = 0;
int sportAreaCount = 0;

void addCustomer(int id, const string &name) {
    customers[customerCount++] = {id, name};
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; ++j) {
                customers[j] = customers[j + 1];
            }
            --customerCount;
            break;
        }
    }
}

void updateCustomer(int id, const string &name) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            customers[i].name = name;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; ++i) {
        cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << endl;
    }
}

void addSportArea(int id, const string &name) {
    sportAreas[sportAreaCount++] = {id, name, false};
}

void deleteSportArea(int id) {
    for (int i = 0; i < sportAreaCount; ++i) {
        if (sportAreas[i].id == id) {
            for (int j = i; j < sportAreaCount - 1; ++j) {
                sportAreas[j] = sportAreas[j + 1];
            }
            --sportAreaCount;
            break;
        }
    }
}

void updateSportArea(int id, const string &name, bool isReserved) {
    for (int i = 0; i < sportAreaCount; ++i) {
        if (sportAreas[i].id == id) {
            sportAreas[i].name = name;
            sportAreas[i].isReserved = isReserved;
            break;
        }
    }
}

SportArea* searchSportArea(int id) {
    for (int i = 0; i < sportAreaCount; ++i) {
        if (sportAreas[i].id == id) {
            return &sportAreas[i];
        }
    }
    return nullptr;
}

void displaySportAreas() {
    for (int i = 0; i < sportAreaCount; ++i) {
        cout << "Sport Area ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name
             << ", Reserved: " << (sportAreas[i].isReserved ? "Yes" : "No") << endl;
    }
}

int main() {
    addCustomer(1, "John Doe");
    addCustomer(2, "Jane Smith");
    addSportArea(1, "Tennis Court");
    addSportArea(2, "Soccer Field");

    displayCustomers();
    displaySportAreas();

    updateCustomer(1, "John Wick");
    updateSportArea(1, "Tennis Court", true);

    Customer* c = searchCustomer(1);
    if (c) {
        cout << "Found Customer: " << c->name << endl;
    }

    SportArea* s = searchSportArea(1);
    if (s) {
        cout << "Found Sport Area: " << s->name << " Reserved: " << (s->isReserved ? "Yes" : "No") << endl;
    }

    deleteCustomer(2);
    deleteSportArea(2);

    displayCustomers();
    displaySportAreas();

    return 0;
}