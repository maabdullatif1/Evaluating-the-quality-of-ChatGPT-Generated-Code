#include <iostream>
#include <string>
#include <vector>

class Customer {
public:
    int id;
    std::string name;

    Customer(int id, const std::string& name) : id(id), name(name) {}
};

class SportArea {
public:
    int id;
    std::string name;

    SportArea(int id, const std::string& name) : id(id), name(name) {}
};

class ReservationSystem {
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;

public:
    void addCustomer(int id, const std::string& name) {
        customers.push_back(Customer(id, name));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                break;
            }
        }
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << std::endl;
        }
    }

    void addSportArea(int id, const std::string& name) {
        sportAreas.push_back(SportArea(id, name));
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, const std::string& name) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                area.name = name;
                break;
            }
        }
    }

    void displaySportAreas() {
        for (const auto& area : sportAreas) {
            std::cout << "Sport Area ID: " << area.id << ", Name: " << area.name << std::endl;
        }
    }

    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                std::cout << "Found Customer ID: " << customer.id << ", Name: " << customer.name << std::endl;
                return;
            }
        }
        std::cout << "Customer not found." << std::endl;
    }

    void searchSportArea(int id) {
        for (const auto& area : sportAreas) {
            if (area.id == id) {
                std::cout << "Found Sport Area ID: " << area.id << ", Name: " << area.name << std::endl;
                return;
            }
        }
        std::cout << "Sport Area not found." << std::endl;
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "John Doe");
    system.addCustomer(2, "Jane Smith");
    system.displayCustomers();
    system.updateCustomer(1, "Johnathan Doe");
    system.displayCustomers();
    system.deleteCustomer(2);
    system.displayCustomers();

    system.addSportArea(101, "Tennis Court");
    system.addSportArea(102, "Swimming Pool");
    system.displaySportAreas();
    system.updateSportArea(101, "Main Tennis Court");
    system.displaySportAreas();
    system.deleteSportArea(102);
    system.displaySportAreas();

    system.searchCustomer(1);
    system.searchSportArea(101);
    return 0;
}