#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string contact;
};

struct SportArea {
    int id;
    string name;
    string type;
    bool isAvailable;
};

class ReservationSystem {
private:
    vector<Customer> customers;
    vector<SportArea> sportAreas;
    int customerCounter;
    int sportAreaCounter;

public:
    ReservationSystem() : customerCounter(0), sportAreaCounter(0) {}

    void addCustomer(const string& name, const string& contact) {
        Customer customer = {++customerCounter, name, contact};
        customers.push_back(customer);
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const string& name, const string& contact) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
                return;
            }
        }
        cout << "Customer not found." << endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
        }
    }

    void addSportArea(const string& name, const string& type) {
        SportArea area = {++sportAreaCounter, name, type, true};
        sportAreas.push_back(area);
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, const string& name, const string& type, bool availability) {
        for (auto& area : sportAreas) {
            if (area.id == id) {
                area.name = name;
                area.type = type;
                area.isAvailable = availability;
                break;
            }
        }
    }

    void searchSportArea(int id) {
        for (const auto& area : sportAreas) {
            if (area.id == id) {
                cout << "Sport Area ID: " << area.id << ", Name: " << area.name << ", Type: " << area.type << ", Available: " << (area.isAvailable ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Sport Area not found." << endl;
    }

    void displaySportAreas() {
        for (const auto& area : sportAreas) {
            cout << "Sport Area ID: " << area.id << ", Name: " << area.name << ", Type: " << area.type << ", Available: " << (area.isAvailable ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer("John Doe", "123-456-7890");
    system.addSportArea("Main Court", "Basketball");
    system.displayCustomers();
    system.displaySportAreas();
    system.searchCustomer(1);
    system.searchSportArea(1);
    system.updateCustomer(1, "Jane Doe", "098-765-4321");
    system.updateSportArea(1, "Main Court", "Basketball", false);
    system.displayCustomers();
    system.displaySportAreas();
    system.deleteCustomer(1);
    system.deleteSportArea(1);
    system.displayCustomers();
    system.displaySportAreas();
    return 0;
}