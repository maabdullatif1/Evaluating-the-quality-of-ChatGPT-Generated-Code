#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string phoneNumber;
};

class SportArea {
public:
    int id;
    string name;
    string type;
};

class ReservationSystem {
private:
    vector<Customer> customers;
    vector<SportArea> sportAreas;
    int nextCustomerId;
    int nextSportAreaId;

public:
    ReservationSystem() : nextCustomerId(1), nextSportAreaId(1) {}

    void addCustomer(string name, string phoneNumber) {
        Customer customer;
        customer.id = nextCustomerId++;
        customer.name = name;
        customer.phoneNumber = phoneNumber;
        customers.push_back(customer);
    }

    void addSportArea(string name, string type) {
        SportArea sportArea;
        sportArea.id = nextSportAreaId++;
        sportArea.name = name;
        sportArea.type = type;
        sportAreas.push_back(sportArea);
    }

    void deleteCustomer(int id) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) {
                customers.erase(customers.begin() + i);
                break;
            }
        }
    }

    void deleteSportArea(int id) {
        for (size_t i = 0; i < sportAreas.size(); ++i) {
            if (sportAreas[i].id == id) {
                sportAreas.erase(sportAreas.begin() + i);
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string phoneNumber) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phoneNumber = phoneNumber;
                break;
            }
        }
    }

    void updateSportArea(int id, string name, string type) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.type = type;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto &customer : customers) {
            if (customer.id == id) {
                cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Phone Number: " << customer.phoneNumber << endl;
                return;
            }
        }
        cout << "Customer not found" << endl;
    }

    void searchSportArea(int id) {
        for (const auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                cout << "Sport Area ID: " << sportArea.id << ", Name: " << sportArea.name << ", Type: " << sportArea.type << endl;
                return;
            }
        }
        cout << "Sport Area not found" << endl;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Phone Number: " << customer.phoneNumber << endl;
        }
    }

    void displaySportAreas() {
        for (const auto &sportArea : sportAreas) {
            cout << "Sport Area ID: " << sportArea.id << ", Name: " << sportArea.name << ", Type: " << sportArea.type << endl;
        }
    }
};

int main() {
    ReservationSystem system;

    system.addCustomer("Alice", "1234567890");
    system.addCustomer("Bob", "0987654321");
    system.addSportArea("Tennis Court", "Tennis");
    system.addSportArea("Football Field", "Football");

    system.displayCustomers();
    system.displaySportAreas();

    system.updateCustomer(1, "Alicia", "1112223333");
    system.searchCustomer(1);

    system.deleteCustomer(2);
    system.displayCustomers();

    system.updateSportArea(1, "Tennis Arena", "Tennis");
    system.searchSportArea(1);

    system.deleteSportArea(2);
    system.displaySportAreas();

    return 0;
}