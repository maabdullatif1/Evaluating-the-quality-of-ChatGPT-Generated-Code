#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;

    Customer(int id, std::string name, std::string contact) : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    std::string name;
    bool isAvailable;

    SportArea(int id, std::string name, bool isAvailable=true) : id(id), name(name), isAvailable(isAvailable) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;

public:
    void addCustomer(int id, std::string name, std::string contact) {
        customers.push_back(Customer(id, name, contact));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string contact) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << std::endl;
        }
    }

    void addSportArea(int id, std::string name, bool isAvailable=true) {
        sportAreas.push_back(SportArea(id, name, isAvailable));
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, std::string name, bool isAvailable) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.isAvailable = isAvailable;
                break;
            }
        }
    }

    SportArea* searchSportArea(int id) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                return &sportArea;
            }
        }
        return nullptr;
    }

    void displaySportAreas() {
        for (const auto &sportArea : sportAreas) {
            std::cout << "ID: " << sportArea.id << ", Name: " << sportArea.name << ", Available: " << (sportArea.isAvailable ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "John Doe", "123-456-7890");
    system.addCustomer(2, "Jane Smith", "098-765-4321");
    system.addSportArea(1, "Tennis Court");
    system.addSportArea(2, "Football Field", false);
    std::cout << "Customers:\n";
    system.displayCustomers();
    std::cout << "Sport Areas:\n";
    system.displaySportAreas();
    return 0;
}