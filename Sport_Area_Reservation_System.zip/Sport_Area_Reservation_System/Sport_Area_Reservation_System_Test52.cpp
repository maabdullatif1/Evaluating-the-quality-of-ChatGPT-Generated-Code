#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
};

struct SportArea {
    int id;
    string name;
    bool available;
};

struct ReservationSystem {
    Customer customers[100];
    SportArea sportAreas[100];
    int customerCount;
    int areaCount;

    ReservationSystem() : customerCount(0), areaCount(0) {}

    void addCustomer(int id, const string& name) {
        customers[customerCount++] = {id, name};
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                for (int j = i; j < customerCount - 1; ++j) {
                    customers[j] = customers[j + 1];
                }
                --customerCount;
                break;
            }
        }
    }

    void updateCustomer(int id, const string& name) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i].name = name;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << endl;
                return;
            }
        }
        cout << "Customer not found" << endl;
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; ++i) {
            cout << "ID: " << customers[i].id << ", Name: " << customers[i].name << endl;
        }
    }

    void addSportArea(int id, const string& name, bool available) {
        sportAreas[areaCount++] = {id, name, available};
    }

    void deleteSportArea(int id) {
        for (int i = 0; i < areaCount; ++i) {
            if (sportAreas[i].id == id) {
                for (int j = i; j < areaCount - 1; ++j) {
                    sportAreas[j] = sportAreas[j + 1];
                }
                --areaCount;
                break;
            }
        }
    }

    void updateSportArea(int id, const string& name, bool available) {
        for (int i = 0; i < areaCount; ++i) {
            if (sportAreas[i].id == id) {
                sportAreas[i].name = name;
                sportAreas[i].available = available;
                break;
            }
        }
    }

    void searchSportArea(int id) {
        for (int i = 0; i < areaCount; ++i) {
            if (sportAreas[i].id == id) {
                cout << "Sport Area ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name 
                     << ", Available: " << (sportAreas[i].available ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Sport Area not found" << endl;
    }

    void displaySportAreas() {
        for (int i = 0; i < areaCount; ++i) {
            cout << "ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name 
                 << ", Available: " << (sportAreas[i].available ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "John Doe");
    system.addSportArea(101, "Tennis Court", true);
    system.displayCustomers();
    system.displaySportAreas();
    system.searchCustomer(1);
    system.searchSportArea(101);
    system.updateCustomer(1, "John Smith");
    system.updateSportArea(101, "Tennis Court", false);
    system.displayCustomers();
    system.displaySportAreas();
    system.deleteCustomer(1);
    system.deleteSportArea(101);
    system.displayCustomers();
    system.displaySportAreas();
    return 0;
}