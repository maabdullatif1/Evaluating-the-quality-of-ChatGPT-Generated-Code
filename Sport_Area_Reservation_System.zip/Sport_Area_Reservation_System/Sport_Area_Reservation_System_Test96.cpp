#include <iostream>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string phone;
};

struct SportArea {
    int id;
    std::string name;
    double pricePerHour;
};

struct Reservation {
    int customerId;
    int areaId;
    int hours;
};

Customer customers[100];
SportArea areas[100];
Reservation reservations[100];
int customerCount = 0;
int areaCount = 0;
int reservationCount = 0;

int findCustomerIndexById(int id) {
    for (int i = 0; i < customerCount; ++i)
        if (customers[i].id == id)
            return i;
    return -1;
}

int findAreaIndexById(int id) {
    for (int i = 0; i < areaCount; ++i)
        if (areas[i].id == id)
            return i;
    return -1;
}

void addCustomer(int id, const std::string& name, const std::string& phone) {
    if (findCustomerIndexById(id) == -1) {
        customers[customerCount++] = {id, name, phone};
    }
}

void deleteCustomer(int id) {
    int index = findCustomerIndexById(id);
    if (index != -1) {
        for (int i = index; i < customerCount - 1; ++i)
            customers[i] = customers[i + 1];
        --customerCount;
    }
}

void updateCustomer(int id, const std::string& name, const std::string& phone) {
    int index = findCustomerIndexById(id);
    if (index != -1) {
        customers[index].name = name;
        customers[index].phone = phone;
    }
}

void searchCustomer(int id) {
    int index = findCustomerIndexById(id);
    if (index != -1) {
        std::cout << "Customer ID: " << customers[index].id << ", Name: " << customers[index].name << ", Phone: " << customers[index].phone << "\n";
    }
}

void addSportArea(int id, const std::string& name, double pricePerHour) {
    if (findAreaIndexById(id) == -1) {
        areas[areaCount++] = {id, name, pricePerHour};
    }
}

void deleteSportArea(int id) {
    int index = findAreaIndexById(id);
    if (index != -1) {
        for (int i = index; i < areaCount - 1; ++i)
            areas[i] = areas[i + 1];
        --areaCount;
    }
}

void updateSportArea(int id, const std::string& name, double pricePerHour) {
    int index = findAreaIndexById(id);
    if (index != -1) {
        areas[index].name = name;
        areas[index].pricePerHour = pricePerHour;
    }
}

void searchSportArea(int id) {
    int index = findAreaIndexById(id);
    if (index != -1) {
        std::cout << "Sport Area ID: " << areas[index].id << ", Name: " << areas[index].name << ", Price/Hour: " << areas[index].pricePerHour << "\n";
    }
}

void displayCustomers() {
    for (int i = 0; i < customerCount; ++i) {
        std::cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << ", Phone: " << customers[i].phone << "\n";
    }
}

void displaySportAreas() {
    for (int i = 0; i < areaCount; ++i) {
        std::cout << "Sport Area ID: " << areas[i].id << ", Name: " << areas[i].name << ", Price/Hour: " << areas[i].pricePerHour << "\n";
    }
}

int main() {
    addCustomer(1, "Alice", "123123123");
    addCustomer(2, "Bob", "321321321");
    addSportArea(1, "Tennis Court", 30.0);
    addSportArea(2, "Swimming Pool", 15.0);
    displayCustomers();
    displaySportAreas();
}