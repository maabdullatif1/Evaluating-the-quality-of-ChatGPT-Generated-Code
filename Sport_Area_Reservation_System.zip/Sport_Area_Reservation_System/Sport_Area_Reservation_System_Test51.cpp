#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
};

struct SportArea {
    int id;
    string name;
};

class ReservationSystem {
    Customer customers[100];
    SportArea sportAreas[100];
    int customerCount, sportAreaCount;

public:
    ReservationSystem() : customerCount(0), sportAreaCount(0) {}

    void addCustomer(int id, string name) {
        customers[customerCount++] = { id, name };
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i] = customers[--customerCount];
                break;
            }
        }
    }

    void updateCustomer(int id, string newName) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i].name = newName;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) return &customers[i];
        }
        return nullptr;
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; ++i) {
            cout << "ID: " << customers[i].id << ", Name: " << customers[i].name << endl;
        }
    }

    void addSportArea(int id, string name) {
        sportAreas[sportAreaCount++] = { id, name };
    }

    void deleteSportArea(int id) {
        for (int i = 0; i < sportAreaCount; ++i) {
            if (sportAreas[i].id == id) {
                sportAreas[i] = sportAreas[--sportAreaCount];
                break;
            }
        }
    }

    void updateSportArea(int id, string newName) {
        for (int i = 0; i < sportAreaCount; ++i) {
            if (sportAreas[i].id == id) {
                sportAreas[i].name = newName;
                break;
            }
        }
    }

    SportArea* searchSportArea(int id) {
        for (int i = 0; i < sportAreaCount; ++i) {
            if (sportAreas[i].id == id) return &sportAreas[i];
        }
        return nullptr;
    }

    void displaySportAreas() {
        for (int i = 0; i < sportAreaCount; ++i) {
            cout << "ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "Alice");
    system.addCustomer(2, "Bob");
    system.displayCustomers();
    
    system.addSportArea(1, "Tennis Court");
    system.addSportArea(2, "Swimming Pool");
    system.displaySportAreas();
    
    system.updateCustomer(1, "Alicia");
    Customer* customer = system.searchCustomer(2);
    if (customer) cout << "Found Customer - ID: " << customer->id << ", Name: " << customer->name << endl;
    
    system.updateSportArea(2, "Olympic Pool");
    SportArea* sportArea = system.searchSportArea(1);
    if (sportArea) cout << "Found Sport Area - ID: " << sportArea->id << ", Name: " << sportArea->name << endl;
    
    system.deleteCustomer(2);
    system.displayCustomers();
    system.deleteSportArea(1);
    system.displaySportAreas();
    
    return 0;
}