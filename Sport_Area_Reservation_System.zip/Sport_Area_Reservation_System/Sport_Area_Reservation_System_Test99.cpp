#include <iostream>
#include <string>
#define MAX_CUSTOMERS 100
#define MAX_AREAS 50

using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct SportArea {
    int id;
    string name;
    string type;
};

Customer customers[MAX_CUSTOMERS];
SportArea sportAreas[MAX_AREAS];
int customerCount = 0, areaCount = 0;

void addCustomer() {
    if (customerCount >= MAX_CUSTOMERS) return;
    Customer c;
    c.id = customerCount + 1;
    cout << "Enter customer name: ";
    cin >> c.name;
    cout << "Enter phone number: ";
    cin >> c.phone;
    customers[customerCount++] = c;
}

void deleteCustomer() {
    if (customerCount == 0) return;
    int id;
    cout << "Enter customer ID to delete: ";
    cin >> id;
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; ++j) {
                customers[j] = customers[j + 1];
            }
            --customerCount;
            return;
        }
    }
}

void updateCustomer() {
    int id;
    cout << "Enter customer ID to update: ";
    cin >> id;
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            cout << "Enter new name: ";
            cin >> customers[i].name;
            cout << "Enter new phone: ";
            cin >> customers[i].phone;
            return;
        }
    }
}

void searchCustomer() {
    int id;
    cout << "Enter customer ID to search: ";
    cin >> id;
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            cout << "Customer ID: " << customers[i].id
                 << ", Name: " << customers[i].name
                 << ", Phone: " << customers[i].phone << endl;
            return;
        }
    }
}

void displayCustomers() {
    for (int i = 0; i < customerCount; ++i) {
        cout << "Customer ID: " << customers[i].id
             << ", Name: " << customers[i].name
             << ", Phone: " << customers[i].phone << endl;
    }
}

void addSportArea() {
    if (areaCount >= MAX_AREAS) return;
    SportArea sa;
    sa.id = areaCount + 1;
    cout << "Enter sport area name: ";
    cin >> sa.name;
    cout << "Enter sport area type: ";
    cin >> sa.type;
    sportAreas[areaCount++] = sa;
}

void deleteSportArea() {
    if (areaCount == 0) return;
    int id;
    cout << "Enter sport area ID to delete: ";
    cin >> id;
    for (int i = 0; i < areaCount; ++i) {
        if (sportAreas[i].id == id) {
            for (int j = i; j < areaCount - 1; ++j) {
                sportAreas[j] = sportAreas[j + 1];
            }
            --areaCount;
            return;
        }
    }
}

void updateSportArea() {
    int id;
    cout << "Enter sport area ID to update: ";
    cin >> id;
    for (int i = 0; i < areaCount; ++i) {
        if (sportAreas[i].id == id) {
            cout << "Enter new name: ";
            cin >> sportAreas[i].name;
            cout << "Enter new type: ";
            cin >> sportAreas[i].type;
            return;
        }
    }
}

void searchSportArea() {
    int id;
    cout << "Enter sport area ID to search: ";
    cin >> id;
    for (int i = 0; i < areaCount; ++i) {
        if (sportAreas[i].id == id) {
            cout << "Sport Area ID: " << sportAreas[i].id
                 << ", Name: " << sportAreas[i].name
                 << ", Type: " << sportAreas[i].type << endl;
            return;
        }
    }
}

void displaySportAreas() {
    for (int i = 0; i < areaCount; ++i) {
        cout << "Sport Area ID: " << sportAreas[i].id
             << ", Name: " << sportAreas[i].name
             << ", Type: " << sportAreas[i].type << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "\n1. Add Customer\n2. Delete Customer\n3. Update Customer\n4. Search Customer\n5. Display Customers\n";
        cout << "6. Add Sport Area\n7. Delete Sport Area\n8. Update Sport Area\n9. Search Sport Area\n10. Display Sport Areas\n0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addCustomer(); break;
            case 2: deleteCustomer(); break;
            case 3: updateCustomer(); break;
            case 4: searchCustomer(); break;
            case 5: displayCustomers(); break;
            case 6: addSportArea(); break;
            case 7: deleteSportArea(); break;
            case 8: updateSportArea(); break;
            case 9: searchSportArea(); break;
            case 10: displaySportAreas(); break;
        }
    } while (choice != 0);

    return 0;
}