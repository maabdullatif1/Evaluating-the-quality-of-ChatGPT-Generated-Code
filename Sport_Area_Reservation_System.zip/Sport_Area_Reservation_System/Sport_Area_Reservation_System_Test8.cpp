#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    string name;
    int id;
    string contact;
    Customer(int i, string n, string c) : id(i), name(n), contact(c) {}
};

class SportArea {
public:
    string name;
    int id;
    bool isAvailable;
    SportArea(int i, string n, bool a) : id(i), name(n), isAvailable(a) {}
};

class ReservationSystem {
private:
    vector<Customer> customers;
    vector<SportArea> sportAreas;

public:
    void addCustomer(int id, string name, string contact) {
        customers.push_back(Customer(id, name, contact));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string contact) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
        }
    }

    void addSportArea(int id, string name, bool isAvailable) {
        sportAreas.push_back(SportArea(id, name, isAvailable));
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, string name, bool isAvailable) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.isAvailable = isAvailable;
                break;
            }
        }
    }

    SportArea* searchSportArea(int id) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                return &sportArea;
            }
        }
        return nullptr;
    }

    void displaySportAreas() {
        for (const auto &sportArea : sportAreas) {
            cout << "ID: " << sportArea.id << ", Name: " << sportArea.name 
                 << ", Available: " << (sportArea.isAvailable ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "John Doe", "123-456-7890");
    system.addCustomer(2, "Jane Smith", "987-654-3210");

    system.addSportArea(1, "Tennis Court", true);
    system.addSportArea(2, "Football Field", false);

    cout << "Customers:" << endl;
    system.displayCustomers();
    
    cout << "Sport Areas:" << endl;
    system.displaySportAreas();

    return 0;
}