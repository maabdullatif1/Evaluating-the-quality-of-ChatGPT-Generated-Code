#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string contact;

    Customer(int i, string n, string c) : id(i), name(n), contact(c) {}
};

class SportArea {
public:
    int id;
    string name;
    bool isReserved;

    SportArea(int i, string n) : id(i), name(n), isReserved(false) {}
};

class ReservationSystem {
private:
    vector<Customer> customers;
    vector<SportArea> sportAreas;
    
    int generateCustomerId() {
        return customers.size() + 1;
    }

    int generateSportAreaId() {
        return sportAreas.size() + 1;
    }

public:
    void addCustomer(string name, string contact) {
        int id = generateCustomerId();
        customers.push_back(Customer(id, name, contact));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void updateCustomer(int id, string name, string contact) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto &customer : customers) {
            if (customer.id == id) {
                cout << "Customer ID: " << customer.id << " Name: " << customer.name << " Contact: " << customer.contact << endl;
            }
        }
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "Customer ID: " << customer.id << " Name: " << customer.name << " Contact: " << customer.contact << endl;
        }
    }

    void addSportArea(string name) {
        int id = generateSportAreaId();
        sportAreas.push_back(SportArea(id, name));
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                return;
            }
        }
    }

    void updateSportArea(int id, string name) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
            }
        }
    }

    void searchSportArea(int id) {
        for (const auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                cout << "SportArea ID: " << sportArea.id << " Name: " << sportArea.name << " Reserved: " << (sportArea.isReserved ? "Yes" : "No") << endl;
            }
        }
    }

    void displaySportAreas() {
        for (const auto &sportArea : sportAreas) {
            cout << "SportArea ID: " << sportArea.id << " Name: " << sportArea.name << " Reserved: " << (sportArea.isReserved ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    ReservationSystem system;

    system.addCustomer("John Doe", "123-456-7890");
    system.addCustomer("Jane Smith", "987-654-3210");

    system.displayCustomers();

    system.addSportArea("Tennis Court");
    system.addSportArea("Football Field");

    system.displaySportAreas();

    system.updateCustomer(1, "John Doe", "111-222-3333");
    system.searchCustomer(1);

    system.updateSportArea(1, "Updated Tennis Court");
    system.searchSportArea(1);

    system.deleteCustomer(2);
    system.displayCustomers();

    system.deleteSportArea(2);
    system.displaySportAreas();

    return 0;
}