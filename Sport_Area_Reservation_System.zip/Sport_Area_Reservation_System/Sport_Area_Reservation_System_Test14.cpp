#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;

    Customer(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    std::string name;
    double hourlyRate;

    SportArea(int id, std::string name, double hourlyRate)
        : id(id), name(name), hourlyRate(hourlyRate) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
    int nextCustomerId;
    int nextSportAreaId;

    int findCustomerIndexById(int id) {
        for (int i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) return i;
        }
        return -1;
    }

    int findSportAreaIndexById(int id) {
        for (int i = 0; i < sportAreas.size(); ++i) {
            if (sportAreas[i].id == id) return i;
        }
        return -1;
    }

public:
    ReservationSystem() : nextCustomerId(1), nextSportAreaId(1) {}

    void addCustomer(std::string name, std::string contact) {
        customers.push_back(Customer(nextCustomerId++, name, contact));
    }

    void deleteCustomer(int id) {
        int index = findCustomerIndexById(id);
        if (index != -1) {
            customers.erase(customers.begin() + index);
        }
    }

    void updateCustomer(int id, std::string name, std::string contact) {
        int index = findCustomerIndexById(id);
        if (index != -1) {
            customers[index].name = name;
            customers[index].contact = contact;
        }
    }

    void displayCustomer(int id) {
        int index = findCustomerIndexById(id);
        if (index != -1) {
            std::cout << "Customer ID: " << customers[index].id
                      << " Name: " << customers[index].name
                      << " Contact: " << customers[index].contact << "\n";
        }
    }

    void displayAllCustomers() {
        for (const auto &customer : customers) {
            std::cout << "Customer ID: " << customer.id
                      << " Name: " << customer.name
                      << " Contact: " << customer.contact << "\n";
        }
    }

    void addSportArea(std::string name, double hourlyRate) {
        sportAreas.push_back(SportArea(nextSportAreaId++, name, hourlyRate));
    }

    void deleteSportArea(int id) {
        int index = findSportAreaIndexById(id);
        if (index != -1) {
            sportAreas.erase(sportAreas.begin() + index);
        }
    }

    void updateSportArea(int id, std::string name, double hourlyRate) {
        int index = findSportAreaIndexById(id);
        if (index != -1) {
            sportAreas[index].name = name;
            sportAreas[index].hourlyRate = hourlyRate;
        }
    }

    void displaySportArea(int id) {
        int index = findSportAreaIndexById(id);
        if (index != -1) {
            std::cout << "Sport Area ID: " << sportAreas[index].id
                      << " Name: " << sportAreas[index].name
                      << " Hourly Rate: $" << sportAreas[index].hourlyRate << "\n";
        }
    }

    void displayAllSportAreas() {
        for (const auto &sportArea : sportAreas) {
            std::cout << "Sport Area ID: " << sportArea.id
                      << " Name: " << sportArea.name
                      << " Hourly Rate: $" << sportArea.hourlyRate << "\n";
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer("John Doe", "123-456-7890");
    system.addCustomer("Jane Smith", "987-654-3210");
    system.displayAllCustomers();
    system.addSportArea("Tennis Court", 50.0);
    system.addSportArea("Football Field", 100.0);
    system.displayAllSportAreas();
    system.updateCustomer(1, "Johnathan Doe", "111-222-3333");
    system.displayCustomer(1);
    system.updateSportArea(1, "Tennis Court A", 55.0);
    system.displaySportArea(1);
    system.deleteCustomer(2);
    system.displayAllCustomers();
    system.deleteSportArea(2);
    system.displayAllSportAreas();
    return 0;
}