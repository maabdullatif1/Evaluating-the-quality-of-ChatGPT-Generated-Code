#include <iostream>
#include <string>
#include <vector>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;

    Customer(int id, std::string name, std::string contact) : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    std::string name;
    bool available;

    SportArea(int id, std::string name, bool available) : id(id), name(name), available(available) {}
};

std::vector<Customer> customers;
std::vector<SportArea> sportAreas;

void addCustomer(int id, std::string name, std::string contact) {
    customers.emplace_back(id, name, contact);
}

void deleteCustomer(int id) {
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            break;
        }
    }
}

void updateCustomer(int id, std::string name, std::string contact) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            customer.name = name;
            customer.contact = contact;
            break;
        }
    }
}

void searchCustomer(int id) {
    for (const auto& customer : customers) {
        if (customer.id == id) {
            std::cout << "Customer Found: " << customer.name << ", " << customer.contact << std::endl;
            return;
        }
    }
    std::cout << "Customer not found.\n";
}

void displayCustomers() {
    for (const auto& customer : customers) {
        std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << std::endl;
    }
}

void addSportArea(int id, std::string name, bool available) {
    sportAreas.emplace_back(id, name, available);
}

void deleteSportArea(int id) {
    for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
        if (it->id == id) {
            sportAreas.erase(it);
            break;
        }
    }
}

void updateSportArea(int id, std::string name, bool available) {
    for (auto& area : sportAreas) {
        if (area.id == id) {
            area.name = name;
            area.available = available;
            break;
        }
    }
}

void searchSportArea(int id) {
    for (const auto& area : sportAreas) {
        if (area.id == id) {
            std::cout << "Sport Area Found: " << area.name << ", Available: " << (area.available ? "Yes" : "No") << std::endl;
            return;
        }
    }
    std::cout << "Sport area not found.\n";
}

void displaySportAreas() {
    for (const auto& area : sportAreas) {
        std::cout << "ID: " << area.id << ", Name: " << area.name << ", Available: " << (area.available ? "Yes" : "No") << std::endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "123456789");
    addCustomer(2, "Jane Doe", "987654321");

    addSportArea(1, "Basketball Court", true);
    addSportArea(2, "Tennis Court", false);

    std::cout << "Initial Customers:\n";
    displayCustomers();

    std::cout << "Initial Sport Areas:\n";
    displaySportAreas();

    updateCustomer(1, "John Smith", "111222333");
    updateSportArea(2, "Tennis Court", true);

    std::cout << "Updated Customers:\n";
    displayCustomers();

    std::cout << "Updated Sport Areas:\n";
    displaySportAreas();

    searchCustomer(1);
    searchSportArea(2);

    deleteCustomer(2);
    deleteSportArea(1);

    std::cout << "Final Customers:\n";
    displayCustomers();

    std::cout << "Final Sport Areas:\n";
    displaySportAreas();

    return 0;
}