#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Customer {
    int id;
    string name;
    string contact;
};

struct SportArea {
    int id;
    string name;
    string type;
};

vector<Customer> customers;
vector<SportArea> sportAreas;

void addCustomer() {
    Customer customer;
    cout << "Enter customer ID: ";
    cin >> customer.id;
    cout << "Enter customer name: ";
    cin.ignore();
    getline(cin, customer.name);
    cout << "Enter customer contact: ";
    getline(cin, customer.contact);
    customers.push_back(customer);
}

void addSportArea() {
    SportArea area;
    cout << "Enter sport area ID: ";
    cin >> area.id;
    cout << "Enter sport area name: ";
    cin.ignore();
    getline(cin, area.name);
    cout << "Enter sport area type: ";
    getline(cin, area.type);
    sportAreas.push_back(area);
}

void deleteCustomer() {
    int id;
    cout << "Enter customer ID to delete: ";
    cin >> id;
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            cout << "Customer deleted." << endl;
            return;
        }
    }
    cout << "Customer not found." << endl;
}

void deleteSportArea() {
    int id;
    cout << "Enter sport area ID to delete: ";
    cin >> id;
    for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
        if (it->id == id) {
            sportAreas.erase(it);
            cout << "Sport area deleted." << endl;
            return;
        }
    }
    cout << "Sport area not found." << endl;
}

void updateCustomer() {
    int id;
    cout << "Enter customer ID to update: ";
    cin >> id;
    for (auto& customer : customers) {
        if (customer.id == id) {
            cout << "Enter new customer name: ";
            cin.ignore();
            getline(cin, customer.name);
            cout << "Enter new customer contact: ";
            getline(cin, customer.contact);
            cout << "Customer updated." << endl;
            return;
        }
    }
    cout << "Customer not found." << endl;
}

void updateSportArea() {
    int id;
    cout << "Enter sport area ID to update: ";
    cin >> id;
    for (auto& area : sportAreas) {
        if (area.id == id) {
            cout << "Enter new sport area name: ";
            cin.ignore();
            getline(cin, area.name);
            cout << "Enter new sport area type: ";
            getline(cin, area.type);
            cout << "Sport area updated." << endl;
            return;
        }
    }
    cout << "Sport area not found." << endl;
}

void searchCustomer() {
    int id;
    cout << "Enter customer ID to search: ";
    cin >> id;
    for (const auto& customer : customers) {
        if (customer.id == id) {
            cout << "Customer ID: " << customer.id 
                 << ", Name: " << customer.name 
                 << ", Contact: " << customer.contact << endl;
            return;
        }
    }
    cout << "Customer not found." << endl;
}

void searchSportArea() {
    int id;
    cout << "Enter sport area ID to search: ";
    cin >> id;
    for (const auto& area : sportAreas) {
        if (area.id == id) {
            cout << "Sport Area ID: " << area.id 
                 << ", Name: " << area.name 
                 << ", Type: " << area.type << endl;
            return;
        }
    }
    cout << "Sport area not found." << endl;
}

void displayCustomers() {
    if (customers.empty()) {
        cout << "No customers to display." << endl;
        return;
    }
    for (const auto& customer : customers) {
        cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
    }
}

void displaySportAreas() {
    if (sportAreas.empty()) {
        cout << "No sport areas to display." << endl;
        return;
    }
    for (const auto& area : sportAreas) {
        cout << "ID: " << area.id << ", Name: " << area.name << ", Type: " << area.type << endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Customer\n2. Add Sport Area\n3. Delete Customer\n4. Delete Sport Area\n5. Update Customer\n6. Update Sport Area\n7. Search Customer\n8. Search Sport Area\n9. Display Customers\n10. Display Sport Areas\n11. Exit\nEnter choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addCustomer(); break;
            case 2: addSportArea(); break;
            case 3: deleteCustomer(); break;
            case 4: deleteSportArea(); break;
            case 5: updateCustomer(); break;
            case 6: updateSportArea(); break;
            case 7: searchCustomer(); break;
            case 8: searchSportArea(); break;
            case 9: displayCustomers(); break;
            case 10: displaySportAreas(); break;
            case 11: return 0;
            default: cout << "Invalid choice." << endl; break;
        }
    }
}