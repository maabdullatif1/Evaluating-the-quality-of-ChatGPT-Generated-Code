#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string phone;
    
    Customer(int id, string name, string phone) : id(id), name(name), phone(phone) {}
};

class SportArea {
public:
    int id;
    string name;
    string type;
    
    SportArea(int id, string name, string type) : id(id), name(name), type(type) {}
};

class ReservationSystem {
private:
    vector<Customer> customers;
    vector<SportArea> sportAreas;

    int findCustomerIndex(int id) {
        for (int i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) return i;
        }
        return -1;
    }

    int findSportAreaIndex(int id) {
        for (int i = 0; i < sportAreas.size(); ++i) {
            if (sportAreas[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCustomer(int id, string name, string phone) {
        customers.push_back(Customer(id, name, phone));
    }
    
    void updateCustomer(int id, string name, string phone) {
        int index = findCustomerIndex(id);
        if (index != -1) {
            customers[index].name = name;
            customers[index].phone = phone;
        }
    }
    
    void deleteCustomer(int id) {
        int index = findCustomerIndex(id);
        if (index != -1) {
            customers.erase(customers.begin() + index);
        }
    }
    
    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Customer ID: " << customer.id 
                 << ", Name: " << customer.name 
                 << ", Phone: " << customer.phone << endl;
        }
    }
    
    void addSportArea(int id, string name, string type) {
        sportAreas.push_back(SportArea(id, name, type));
    }
    
    void updateSportArea(int id, string name, string type) {
        int index = findSportAreaIndex(id);
        if (index != -1) {
            sportAreas[index].name = name;
            sportAreas[index].type = type;
        }
    }
    
    void deleteSportArea(int id) {
        int index = findSportAreaIndex(id);
        if (index != -1) {
            sportAreas.erase(sportAreas.begin() + index);
        }
    }
    
    void displaySportAreas() {
        for (const auto& area : sportAreas) {
            cout << "Sport Area ID: " << area.id 
                 << ", Name: " << area.name 
                 << ", Type: " << area.type << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    
    system.addCustomer(1, "Alice", "12345");
    system.addCustomer(2, "Bob", "67890");
    
    system.addSportArea(1, "Court A", "Tennis");
    system.addSportArea(2, "Field B", "Soccer");
    
    cout << "Customers:" << endl;
    system.displayCustomers();
    
    cout << "Sport Areas:" << endl;
    system.displaySportAreas();
    
    system.updateCustomer(1, "Alice Smith", "54321");
    system.updateSportArea(1, "Court A1", "Badminton");
    
    cout << "Updated Customers:" << endl;
    system.displayCustomers();
    
    cout << "Updated Sport Areas:" << endl;
    system.displaySportAreas();
    
    system.deleteCustomer(2);
    system.deleteSportArea(2);
    
    cout << "Final Customers:" << endl;
    system.displayCustomers();
    
    cout << "Final Sport Areas:" << endl;
    system.displaySportAreas();
    
    return 0;
}