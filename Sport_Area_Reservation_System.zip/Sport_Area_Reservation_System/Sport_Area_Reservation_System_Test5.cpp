#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string phone;

    Customer(int id, string name, string phone) : id(id), name(name), phone(phone) {}
};

class SportArea {
public:
    int id;
    string name;
    string type;

    SportArea(int id, string name, string type) : id(id), name(name), type(type) {}
};

vector<Customer> customers;
vector<SportArea> sportAreas;

void addCustomer(int id, string name, string phone) {
    customers.push_back(Customer(id, name, phone));
}

void addSportArea(int id, string name, string type) {
    sportAreas.push_back(SportArea(id, name, type));
}

void deleteCustomer(int id) {
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            break;
        }
    }
}

void deleteSportArea(int id) {
    for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
        if (it->id == id) {
            sportAreas.erase(it);
            break;
        }
    }
}

void updateCustomer(int id, string name, string phone) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            customer.name = name;
            customer.phone = phone;
        }
    }
}

void updateSportArea(int id, string name, string type) {
    for (auto& sportArea : sportAreas) {
        if (sportArea.id == id) {
            sportArea.name = name;
            sportArea.type = type;
        }
    }
}

Customer* searchCustomer(int id) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            return &customer;
        }
    }
    return nullptr;
}

SportArea* searchSportArea(int id) {
    for (auto& sportArea : sportAreas) {
        if (sportArea.id == id) {
            return &sportArea;
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (const auto& customer : customers) {
        cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << endl;
    }
}

void displaySportAreas() {
    for (const auto& sportArea : sportAreas) {
        cout << "Sport Area ID: " << sportArea.id << ", Name: " << sportArea.name << ", Type: " << sportArea.type << endl;
    }
}

int main() {
    addCustomer(1, "Alice", "1234567890");
    addCustomer(2, "Bob", "0987654321");
    addSportArea(1, "Tennis Court", "Tennis");
    addSportArea(2, "Swimming Pool", "Swimming");
    
    displayCustomers();
    displaySportAreas();

    updateCustomer(1, "Alice Johnson", "1111111111");
    updateSportArea(2, "Indoor Pool", "Swimming");

    displayCustomers();
    displaySportAreas();

    deleteCustomer(2);
    deleteSportArea(1);

    displayCustomers();
    displaySportAreas();

    return 0;
}