#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct SportArea {
    int id;
    string name;
    string type;
};

vector<Customer> customers;
vector<SportArea> sportAreas;

void addCustomer(int id, string name, string phone) {
    customers.push_back({id, name, phone});
}

void deleteCustomer(int id) {
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            break;
        }
    }
}

void updateCustomer(int id, string name, string phone) {
    for (auto &customer : customers) {
        if (customer.id == id) {
            customer.name = name;
            customer.phone = phone;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (auto &customer : customers) {
        if (customer.id == id) {
            return &customer;
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (const auto &customer : customers) {
        cout << "ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << endl;
    }
}

void addSportArea(int id, string name, string type) {
    sportAreas.push_back({id, name, type});
}

void deleteSportArea(int id) {
    for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
        if (it->id == id) {
            sportAreas.erase(it);
            break;
        }
    }
}

void updateSportArea(int id, string name, string type) {
    for (auto &area : sportAreas) {
        if (area.id == id) {
            area.name = name;
            area.type = type;
            break;
        }
    }
}

SportArea* searchSportArea(int id) {
    for (auto &area : sportAreas) {
        if (area.id == id) {
            return &area;
        }
    }
    return nullptr;
}

void displaySportAreas() {
    for (const auto &area : sportAreas) {
        cout << "ID: " << area.id << ", Name: " << area.name << ", Type: " << area.type << endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "123456789");
    addCustomer(2, "Jane Smith", "987654321");
    displayCustomers();

    updateCustomer(1, "John Doe Jr.", "123456780");
    displayCustomers();

    deleteCustomer(2);
    displayCustomers();

    addSportArea(1, "Football Field", "Outdoor");
    addSportArea(2, "Basketball Court", "Indoor");
    displaySportAreas();

    updateSportArea(1, "Soccer Field", "Outdoor");
    displaySportAreas();

    deleteSportArea(2);
    displaySportAreas();

    return 0;
}