#include <iostream>
#include <string>
using namespace std;

const int MAX_CUSTOMERS = 100;
const int MAX_AREAS = 100;

struct Customer {
    int id;
    string name;
    string contact;
};

struct SportArea {
    int id;
    string name;
    string type;
};

Customer customers[MAX_CUSTOMERS];
SportArea sportAreas[MAX_AREAS];
int customerCount = 0;
int areaCount = 0;

void addCustomer() {
    if (customerCount < MAX_CUSTOMERS) {
        Customer c;
        c.id = customerCount + 1;
        cout << "Enter Customer Name: ";
        cin >> c.name;
        cout << "Enter Customer Contact: ";
        cin >> c.contact;
        customers[customerCount++] = c;
    }
}

void addSportArea() {
    if (areaCount < MAX_AREAS) {
        SportArea a;
        a.id = areaCount + 1;
        cout << "Enter Sport Area Name: ";
        cin >> a.name;
        cout << "Enter Sport Area Type: ";
        cin >> a.type;
        sportAreas[areaCount++] = a;
    }
}

void deleteCustomer() {
    int id;
    cout << "Enter Customer ID to delete: ";
    cin >> id;
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; j++) {
                customers[j] = customers[j + 1];
            }
            customerCount--;
            break;
        }
    }
}

void deleteSportArea() {
    int id;
    cout << "Enter Sport Area ID to delete: ";
    cin >> id;
    for (int i = 0; i < areaCount; i++) {
        if (sportAreas[i].id == id) {
            for (int j = i; j < areaCount - 1; j++) {
                sportAreas[j] = sportAreas[j + 1];
            }
            areaCount--;
            break;
        }
    }
}

void updateCustomer() {
    int id;
    cout << "Enter Customer ID to update: ";
    cin >> id;
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            cout << "Enter new Customer Name: ";
            cin >> customers[i].name;
            cout << "Enter new Customer Contact: ";
            cin >> customers[i].contact;
            break;
        }
    }
}

void updateSportArea() {
    int id;
    cout << "Enter Sport Area ID to update: ";
    cin >> id;
    for (int i = 0; i < areaCount; i++) {
        if (sportAreas[i].id == id) {
            cout << "Enter new Sport Area Name: ";
            cin >> sportAreas[i].name;
            cout << "Enter new Sport Area Type: ";
            cin >> sportAreas[i].type;
            break;
        }
    }
}

void searchCustomer() {
    string name;
    cout << "Enter Customer Name to search: ";
    cin >> name;
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].name == name) {
            cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << ", Contact: " << customers[i].contact << endl;
            break;
        }
    }
}

void searchSportArea() {
    string name;
    cout << "Enter Sport Area Name to search: ";
    cin >> name;
    for (int i = 0; i < areaCount; i++) {
        if (sportAreas[i].name == name) {
            cout << "Sport Area ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name << ", Type: " << sportAreas[i].type << endl;
            break;
        }
    }
}

void displayCustomers() {
    for (int i = 0; i < customerCount; i++) {
        cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << ", Contact: " << customers[i].contact << endl;
    }
}

void displaySportAreas() {
    for (int i = 0; i < areaCount; i++) {
        cout << "Sport Area ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name << ", Type: " << sportAreas[i].type << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Customer\n2. Delete Customer\n3. Update Customer\n4. Search Customer\n5. Display Customers\n";
        cout << "6. Add Sport Area\n7. Delete Sport Area\n8. Update Sport Area\n9. Search Sport Area\n10. Display Sport Areas\n11. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        
        switch (choice) {
            case 1:
                addCustomer();
                break;
            case 2:
                deleteCustomer();
                break;
            case 3:
                updateCustomer();
                break;
            case 4:
                searchCustomer();
                break;
            case 5:
                displayCustomers();
                break;
            case 6:
                addSportArea();
                break;
            case 7:
                deleteSportArea();
                break;
            case 8:
                updateSportArea();
                break;
            case 9:
                searchSportArea();
                break;
            case 10:
                displaySportAreas();
                break;
            case 11:
                exit(0);
        }
    } while (true);
}