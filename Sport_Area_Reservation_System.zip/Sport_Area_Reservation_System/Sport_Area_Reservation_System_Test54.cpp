#include <iostream>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string contact;
    Customer* next;
};

struct SportArea {
    int id;
    string name;
    string location;
    SportArea* next;
};

Customer* customerHead = nullptr;
SportArea* sportAreaHead = nullptr;

Customer* createCustomer(int id, string name, string contact) {
    Customer* newCustomer = new Customer();
    newCustomer->id = id;
    newCustomer->name = name;
    newCustomer->contact = contact;
    newCustomer->next = nullptr;
    return newCustomer;
}

SportArea* createSportArea(int id, string name, string location) {
    SportArea* newSportArea = new SportArea();
    newSportArea->id = id;
    newSportArea->name = name;
    newSportArea->location = location;
    newSportArea->next = nullptr;
    return newSportArea;
}

void addCustomer(int id, string name, string contact) {
    Customer* newCustomer = createCustomer(id, name, contact);
    if (!customerHead) {
        customerHead = newCustomer;
    } else {
        Customer* temp = customerHead;
        while (temp->next) {
            temp = temp->next;
        }
        temp->next = newCustomer;
    }
}

void addSportArea(int id, string name, string location) {
    SportArea* newSportArea = createSportArea(id, name, location);
    if (!sportAreaHead) {
        sportAreaHead = newSportArea;
    } else {
        SportArea* temp = sportAreaHead;
        while (temp->next) {
            temp = temp->next;
        }
        temp->next = newSportArea;
    }
}

bool deleteCustomer(int id) {
    if (!customerHead) return false;
    if (customerHead->id == id) {
        Customer* temp = customerHead;
        customerHead = customerHead->next;
        delete temp;
        return true;
    }
    Customer* temp = customerHead;
    while (temp->next && temp->next->id != id) {
        temp = temp->next;
    }
    if (temp->next) {
        Customer* toDelete = temp->next;
        temp->next = temp->next->next;
        delete toDelete;
        return true;
    }
    return false;
}

bool deleteSportArea(int id) {
    if (!sportAreaHead) return false;
    if (sportAreaHead->id == id) {
        SportArea* temp = sportAreaHead;
        sportAreaHead = sportAreaHead->next;
        delete temp;
        return true;
    }
    SportArea* temp = sportAreaHead;
    while (temp->next && temp->next->id != id) {
        temp = temp->next;
    }
    if (temp->next) {
        SportArea* toDelete = temp->next;
        temp->next = temp->next->next;
        delete toDelete;
        return true;
    }
    return false;
}

bool updateCustomer(int id, string name, string contact) {
    Customer* temp = customerHead;
    while (temp) {
        if (temp->id == id) {
            temp->name = name;
            temp->contact = contact;
            return true;
        }
        temp = temp->next;
    }
    return false;
}

bool updateSportArea(int id, string name, string location) {
    SportArea* temp = sportAreaHead;
    while (temp) {
        if (temp->id == id) {
            temp->name = name;
            temp->location = location;
            return true;
        }
        temp = temp->next;
    }
    return false;
}

Customer* searchCustomer(int id) {
    Customer* temp = customerHead;
    while (temp) {
        if (temp->id == id) {
            return temp;
        }
        temp = temp->next;
    }
    return nullptr;
}

SportArea* searchSportArea(int id) {
    SportArea* temp = sportAreaHead;
    while (temp) {
        if (temp->id == id) {
            return temp;
        }
        temp = temp->next;
    }
    return nullptr;
}

void displayCustomers() {
    Customer* temp = customerHead;
    while (temp) {
        cout << "ID: " << temp->id << ", Name: " << temp->name << ", Contact: " << temp->contact << endl;
        temp = temp->next;
    }
}

void displaySportAreas() {
    SportArea* temp = sportAreaHead;
    while (temp) {
        cout << "ID: " << temp->id << ", Name: " << temp->name << ", Location: " << temp->location << endl;
        temp = temp->next;
    }
}

int main() {
    addCustomer(1, "John Doe", "john.doe@example.com");
    addCustomer(2, "Jane Smith", "jane.smith@example.com");
    addSportArea(1, "Tennis Court", "Downtown");
    addSportArea(2, "Swimming Pool", "Westside");
    displayCustomers();
    displaySportAreas();
    updateCustomer(1, "Johnathan Doe", "johnathandoe@example.com");
    updateSportArea(1, "Tennis Court", "Uptown");
    displayCustomers();
    displaySportAreas();
    deleteCustomer(2);
    deleteSportArea(1);
    displayCustomers();
    displaySportAreas();
    return 0;
}