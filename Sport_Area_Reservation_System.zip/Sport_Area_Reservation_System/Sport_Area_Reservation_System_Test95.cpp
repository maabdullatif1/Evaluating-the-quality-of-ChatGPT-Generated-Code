#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;

    Customer(int i, std::string n, std::string c) : id(i), name(n), contact(c) {}
};

class SportArea {
public:
    int id;
    std::string name;
    std::string location;

    SportArea(int i, std::string n, std::string l) : id(i), name(n), location(l) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
    int customer_id_counter;
    int sportArea_id_counter;

public:
    ReservationSystem() : customer_id_counter(1), sportArea_id_counter(1) {}

    void addCustomer(std::string name, std::string contact) {
        customers.push_back(Customer(customer_id_counter++, name, contact));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string contact) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (auto &customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name
                      << ", Contact: " << customer.contact << std::endl;
        }
    }

    void addSportArea(std::string name, std::string location) {
        sportAreas.push_back(SportArea(sportArea_id_counter++, name, location));
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, std::string name, std::string location) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.location = location;
                break;
            }
        }
    }

    SportArea* searchSportArea(int id) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                return &sportArea;
            }
        }
        return nullptr;
    }

    void displaySportAreas() {
        for (auto &sportArea : sportAreas) {
            std::cout << "SportArea ID: " << sportArea.id << ", Name: " << sportArea.name
                      << ", Location: " << sportArea.location << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;

    system.addCustomer("John Doe", "123-456-7890");
    system.addCustomer("Alice Smith", "234-567-8901");

    system.addSportArea("Football Field", "Downtown");
    system.addSportArea("Basketball Court", "Uptown");

    system.displayCustomers();
    system.displaySportAreas();

    system.updateCustomer(1, "Johnathan Doe", "123-456-7899");
    system.updateSportArea(2, "Basketball Arena", "Eastside");

    system.displayCustomers();
    system.displaySportAreas();

    system.deleteCustomer(2);
    system.deleteSportArea(1);

    system.displayCustomers();
    system.displaySportAreas();

    return 0;
}