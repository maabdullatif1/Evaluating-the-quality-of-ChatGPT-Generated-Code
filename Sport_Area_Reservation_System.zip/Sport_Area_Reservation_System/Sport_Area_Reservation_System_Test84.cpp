#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string email;

    Customer(int id, const std::string& name, const std::string& email)
        : id(id), name(name), email(email) {}
};

class SportArea {
public:
    int id;
    std::string name;
    std::string location;

    SportArea(int id, const std::string& name, const std::string& location)
        : id(id), name(name), location(location) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
    int customerCounter = 0;
    int sportAreaCounter = 0;

public:
    void addCustomer(const std::string& name, const std::string& email) {
        customers.emplace_back(++customerCounter, name, email);
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& email) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.email = email;
                break;
            }
        }
    }

    void displayCustomers() const {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Email: " << customer.email << '\n';
        }
    }

    void addSportArea(const std::string& name, const std::string& location) {
        sportAreas.emplace_back(++sportAreaCounter, name, location);
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, const std::string& name, const std::string& location) {
        for (auto& sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.location = location;
                break;
            }
        }
    }

    void displaySportAreas() const {
        for (const auto& sportArea : sportAreas) {
            std::cout << "ID: " << sportArea.id << ", Name: " << sportArea.name << ", Location: " << sportArea.location << '\n';
        }
    }
};

int main() {
    ReservationSystem rs;
    rs.addCustomer("John Doe", "john@example.com");
    rs.addCustomer("Jane Smith", "jane@example.com");
    rs.displayCustomers();
    rs.updateCustomer(1, "Johnny Doe", "johnny@example.com");
    rs.displayCustomers();
    rs.deleteCustomer(2);
    rs.displayCustomers();

    rs.addSportArea("Tennis Court", "Park A");
    rs.addSportArea("Swimming Pool", "Complex B");
    rs.displaySportAreas();
    rs.updateSportArea(1, "Tennis Court", "Updated Park A");
    rs.displaySportAreas();
    rs.deleteSportArea(2);
    rs.displaySportAreas();

    return 0;
}