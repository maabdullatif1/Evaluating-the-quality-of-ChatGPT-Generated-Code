#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string contact;

    Customer(int id, string name, string contact) : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    string name;
    string type;
    bool isReserved;

    SportArea(int id, string name, string type, bool isReserved = false)
        : id(id), name(name), type(type), isReserved(isReserved) {}
};

class ReservationSystem {
private:
    vector<Customer> customers;
    vector<SportArea> sportAreas;
    int customerIdCounter = 1;
    int sportAreaIdCounter = 1;

public:
    void addCustomer(string name, string contact) {
        customers.push_back(Customer(customerIdCounter++, name, contact));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string contact) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void addSportArea(string name, string type) {
        sportAreas.push_back(SportArea(sportAreaIdCounter++, name, type));
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, string name, string type, bool isReserved) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.type = type;
                sportArea.isReserved = isReserved;
                break;
            }
        }
    }

    SportArea* searchSportArea(int id) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                return &sportArea;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "ID: " << customer.id << ", Name: " << customer.name 
                 << ", Contact: " << customer.contact << endl;
        }
    }

    void displaySportAreas() {
        for (const auto &sportArea : sportAreas) {
            cout << "ID: " << sportArea.id << ", Name: " << sportArea.name 
                 << ", Type: " << sportArea.type << ", Reserved: " 
                 << (sportArea.isReserved ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer("John Doe", "123-456-7890");
    system.addCustomer("Jane Smith", "098-765-4321");
    system.displayCustomers();
    
    system.addSportArea("Tennis Court", "Outdoor");
    system.addSportArea("Basketball Court", "Indoor");
    system.displaySportAreas();
    
    system.updateSportArea(1, "Tennis Court", "Outdoor", true);
    
    system.displaySportAreas();
    
    system.deleteCustomer(1);
    system.displayCustomers();
    
    return 0;
}