#include <iostream>
#include <string>
#include <vector>

class Customer {
public:
    int id;
    std::string name;
    
    Customer(int id, const std::string &name) : id(id), name(name) {}
};

class SportArea {
public:
    int id;
    std::string name;
    
    SportArea(int id, const std::string &name) : id(id), name(name) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;

public:
    void addCustomer(int id, const std::string &name) {
        customers.push_back(Customer(id, name));
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, const std::string &newName) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = newName;
                break;
            }
        }
    }
    
    void addSportArea(int id, const std::string &name) {
        sportAreas.push_back(SportArea(id, name));
    }
    
    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }
    
    void updateSportArea(int id, const std::string &newName) {
        for (auto &area : sportAreas) {
            if (area.id == id) {
                area.name = newName;
                break;
            }
        }
    }
    
    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }
    
    SportArea* searchSportArea(int id) {
        for (auto &area : sportAreas) {
            if (area.id == id) {
                return &area;
            }
        }
        return nullptr;
    }
    
    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << std::endl;
        }
    }
    
    void displaySportAreas() {
        for (const auto &area : sportAreas) {
            std::cout << "Sport Area ID: " << area.id << ", Name: " << area.name << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "Alice");
    system.addCustomer(2, "Bob");
    system.addSportArea(1, "Basketball Court");
    system.addSportArea(2, "Tennis Court");

    system.displayCustomers();
    system.displaySportAreas();

    system.updateCustomer(1, "Alice Smith");
    system.updateSportArea(2, "Clay Tennis Court");
    
    Customer* customer = system.searchCustomer(1);
    if (customer) {
        std::cout << "Found Customer: ID=" << customer->id << ", Name=" << customer->name << std::endl;
    }
    
    SportArea* area = system.searchSportArea(1);
    if (area) {
        std::cout << "Found Sport Area: ID=" << area->id << ", Name=" << area->name << std::endl;
    }

    system.deleteCustomer(2);
    system.deleteSportArea(1);

    system.displayCustomers();
    system.displaySportAreas();

    return 0;
}