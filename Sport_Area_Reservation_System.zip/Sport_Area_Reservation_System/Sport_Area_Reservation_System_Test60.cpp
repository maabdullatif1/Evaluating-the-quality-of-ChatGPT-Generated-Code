#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string phone;
};

struct SportArea {
    int id;
    std::string name;
    double rate;
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;

    int findCustomerIndexById(int id) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) return i;
        }
        return -1;
    }
    
    int findSportAreaIndexById(int id) {
        for (size_t i = 0; i < sportAreas.size(); ++i) {
            if (sportAreas[i].id == id) return i;
        }
        return -1;
    }
    
public:
    void addCustomer(int id, const std::string& name, const std::string& phone) {
        Customer newCustomer = {id, name, phone};
        customers.push_back(newCustomer);
    }
    
    void deleteCustomer(int id) {
        int index = findCustomerIndexById(id);
        if (index != -1) {
            customers.erase(customers.begin() + index);
        }
    }
    
    void updateCustomer(int id, const std::string& name, const std::string& phone) {
        int index = findCustomerIndexById(id);
        if (index != -1) {
            customers[index].name = name;
            customers[index].phone = phone;
        }
    }
    
    Customer searchCustomerById(int id) {
        int index = findCustomerIndexById(id);
        if (index != -1) {
            return customers[index];
        }
        return {-1, "", ""};
    }
    
    void displayAllCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name 
                      << ", Phone: " << customer.phone << std::endl;
        }
    }
    
    void addSportArea(int id, const std::string& name, double rate) {
        SportArea newSportArea = {id, name, rate};
        sportAreas.push_back(newSportArea);
    }
    
    void deleteSportArea(int id) {
        int index = findSportAreaIndexById(id);
        if (index != -1) {
            sportAreas.erase(sportAreas.begin() + index);
        }
    }
    
    void updateSportArea(int id, const std::string& name, double rate) {
        int index = findSportAreaIndexById(id);
        if (index != -1) {
            sportAreas[index].name = name;
            sportAreas[index].rate = rate;
        }
    }
    
    SportArea searchSportAreaById(int id) {
        int index = findSportAreaIndexById(id);
        if (index != -1) {
            return sportAreas[index];
        }
        return {-1, "", 0.0};
    }
    
    void displayAllSportAreas() {
        for (const auto& sportArea : sportAreas) {
            std::cout << "ID: " << sportArea.id << ", Name: " << sportArea.name 
                      << ", Rate: " << sportArea.rate << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    
    system.addCustomer(1, "John Doe", "1234567890");
    system.addCustomer(2, "Jane Smith", "0987654321");
    system.updateCustomer(1, "John Updated", "1111111111");
    system.displayAllCustomers();
    system.deleteCustomer(1);
    system.displayAllCustomers();

    system.addSportArea(1, "Tennis Court", 50.0);
    system.addSportArea(2, "Soccer Field", 75.0);
    system.updateSportArea(2, "Updated Soccer Field", 80.0);
    system.displayAllSportAreas();
    system.deleteSportArea(1);
    system.displayAllSportAreas();

    return 0;
}