#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;
    Customer(int i, const std::string &n, const std::string &c) : id(i), name(n), contact(c) {}
};

class SportArea {
public:
    int id;
    std::string name;
    bool isAvailable;
    SportArea(int i, const std::string &n) : id(i), name(n), isAvailable(true) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;

    int findCustomerIndex(int id) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id)
                return i;
        }
        return -1;
    }

    int findSportAreaIndex(int id) {
        for (size_t i = 0; i < sportAreas.size(); ++i) {
            if (sportAreas[i].id == id)
                return i;
        }
        return -1;
    }

public:
    void addCustomer(int id, const std::string &name, const std::string &contact) {
        if (findCustomerIndex(id) == -1) {
            customers.emplace_back(id, name, contact);
        }
    }

    void deleteCustomer(int id) {
        int index = findCustomerIndex(id);
        if (index != -1) {
            customers.erase(customers.begin() + index);
        }
    }

    void updateCustomer(int id, const std::string &name, const std::string &contact) {
        int index = findCustomerIndex(id);
        if (index != -1) {
            customers[index].name = name;
            customers[index].contact = contact;
        }
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << std::endl;
        }
    }

    void addSportArea(int id, const std::string &name) {
        if (findSportAreaIndex(id) == -1) {
            sportAreas.emplace_back(id, name);
        }
    }

    void deleteSportArea(int id) {
        int index = findSportAreaIndex(id);
        if (index != -1) {
            sportAreas.erase(sportAreas.begin() + index);
        }
    }

    void updateSportArea(int id, const std::string &name, bool isAvailable) {
        int index = findSportAreaIndex(id);
        if (index != -1) {
            sportAreas[index].name = name;
            sportAreas[index].isAvailable = isAvailable;
        }
    }

    void displaySportAreas() {
        for (const auto &sportArea : sportAreas) {
            std::cout << "ID: " << sportArea.id << ", Name: " << sportArea.name << ", Available: " << (sportArea.isAvailable ? "Yes" : "No") << std::endl;
        }
    }

    bool searchCustomer(int id) {
        return findCustomerIndex(id) != -1;
    }

    bool searchSportArea(int id) {
        return findSportAreaIndex(id) != -1;
    }
};

int main() {
    ReservationSystem rs;
    rs.addCustomer(1, "John Doe", "123-456-7890");
    rs.addSportArea(1, "Basketball Court");
    rs.displayCustomers();
    rs.displaySportAreas();
    rs.updateCustomer(1, "John Smith", "098-765-4321");
    rs.updateSportArea(1, "Basketball Court", false);
    rs.displayCustomers();
    rs.displaySportAreas();

    return 0;
}