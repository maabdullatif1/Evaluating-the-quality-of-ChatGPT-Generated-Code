#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Customer {
public:
    int id;
    string name;
    string contact;

    Customer(int id, string name, string contact)
        : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    string name;
    bool isAvailable;

    SportArea(int id, string name, bool isAvailable)
        : id(id), name(name), isAvailable(isAvailable) {}
};

class ReservationSystem {
    vector<Customer> customers;
    vector<SportArea> sportAreas;
    int customerIdCounter;
    int sportAreaIdCounter;

public:
    ReservationSystem() : customerIdCounter(1), sportAreaIdCounter(1) {}

    void addCustomer(string name, string contact) {
        customers.emplace_back(customerIdCounter++, name, contact);
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string contact) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
                return;
            }
        }
        cout << "Customer not found" << endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
        }
    }

    void addSportArea(string name, bool isAvailable) {
        sportAreas.emplace_back(sportAreaIdCounter++, name, isAvailable);
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, string name, bool isAvailable) {
        for (auto& sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.isAvailable = isAvailable;
                break;
            }
        }
    }

    void searchSportArea(int id) {
        for (const auto& sportArea : sportAreas) {
            if (sportArea.id == id) {
                cout << "Sport Area ID: " << sportArea.id << ", Name: " << sportArea.name << ", Available: " << (sportArea.isAvailable ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Sport Area not found" << endl;
    }

    void displaySportAreas() {
        for (const auto& sportArea : sportAreas) {
            cout << "Sport Area ID: " << sportArea.id << ", Name: " << sportArea.name << ", Available: " << (sportArea.isAvailable ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer("John Doe", "123-456-7890");
    system.addCustomer("Jane Smith", "234-567-8901");
    system.addSportArea("Tennis Court", true);
    system.addSportArea("Swimming Pool", false);

    cout << "Customers:" << endl;
    system.displayCustomers();

    cout << "\nSport Areas:" << endl;
    system.displaySportAreas();

    return 0;
}