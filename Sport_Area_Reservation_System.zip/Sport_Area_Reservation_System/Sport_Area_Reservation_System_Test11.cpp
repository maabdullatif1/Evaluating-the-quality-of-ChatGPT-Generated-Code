#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;

    Customer(int id, const std::string &name, const std::string &contact) 
        : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    std::string name;
    bool available;

    SportArea(int id, const std::string &name, bool available) 
        : id(id), name(name), available(available) {}
};

class ReservationSystem {
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;

public:
    void addCustomer(int id, const std::string &name, const std::string &contact) {
        customers.emplace_back(id, name, contact);
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string &name, const std::string &contact) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }

    void addSportArea(int id, const std::string &name, bool available) {
        sportAreas.emplace_back(id, name, available);
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, const std::string &name, bool available) {
        for (auto &area : sportAreas) {
            if (area.id == id) {
                area.name = name;
                area.available = available;
                break;
            }
        }
    }

    Customer *searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    SportArea *searchSportArea(int id) {
        for (auto &area : sportAreas) {
            if (area.id == id) {
                return &area;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "ID: " << customer.id 
                      << ", Name: " << customer.name 
                      << ", Contact: " << customer.contact << std::endl;
        }
    }

    void displaySportAreas() {
        for (const auto &area : sportAreas) {
            std::cout << "ID: " << area.id 
                      << ", Name: " << area.name 
                      << ", Available: " << (area.available ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "Alice", "123456789");
    system.addCustomer(2, "Bob", "987654321");
    system.displayCustomers();

    system.addSportArea(1, "Tennis Court", true);
    system.addSportArea(2, "Basketball Court", false);
    system.displaySportAreas();

    Customer *customer = system.searchCustomer(1);
    if (customer) {
        std::cout << "Found customer: " << customer->name << std::endl;
    }

    SportArea *area = system.searchSportArea(1);
    if (area) {
        std::cout << "Found sport area: " << area->name << std::endl;
    }

    system.updateCustomer(1, "Alice Johnson", "111222333");
    system.updateSportArea(2, "Indoor Basketball Court", true);
    system.displayCustomers();
    system.displaySportAreas();

    system.deleteCustomer(2);
    system.deleteSportArea(2);
    system.displayCustomers();
    system.displaySportAreas();

    return 0;
}