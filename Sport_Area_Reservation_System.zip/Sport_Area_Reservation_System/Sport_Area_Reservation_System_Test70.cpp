#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string contact;
};

struct SportArea {
    int id;
    string name;
    string location;
};

vector<Customer> customers;
vector<SportArea> sportAreas;

int findCustomerIndexById(int id) {
    for (int i = 0; i < customers.size(); ++i) {
        if (customers[i].id == id) return i;
    }
    return -1;
}

int findSportAreaIndexById(int id) {
    for (int i = 0; i < sportAreas.size(); ++i) {
        if (sportAreas[i].id == id) return i;
    }
    return -1;
}

void addCustomer() {
    Customer customer;
    cout << "Enter customer id: ";
    cin >> customer.id;
    cout << "Enter customer name: ";
    cin >> customer.name;
    cout << "Enter customer contact: ";
    cin >> customer.contact;
    customers.push_back(customer);
}

void deleteCustomer() {
    int id;
    cout << "Enter customer id to delete: ";
    cin >> id;
    int index = findCustomerIndexById(id);
    if (index != -1) customers.erase(customers.begin() + index);
    else cout << "Customer not found.\n";
}

void updateCustomer() {
    int id;
    cout << "Enter customer id to update: ";
    cin >> id;
    int index = findCustomerIndexById(id);
    if (index != -1) {
        cout << "Enter new customer name: ";
        cin >> customers[index].name;
        cout << "Enter new customer contact: ";
        cin >> customers[index].contact;
    } else {
        cout << "Customer not found.\n";
    }
}

void displayCustomers() {
    for (auto &customer : customers) {
        cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
    }
}

void addSportArea() {
    SportArea area;
    cout << "Enter sport area id: ";
    cin >> area.id;
    cout << "Enter sport area name: ";
    cin >> area.name;
    cout << "Enter sport area location: ";
    cin >> area.location;
    sportAreas.push_back(area);
}

void deleteSportArea() {
    int id;
    cout << "Enter sport area id to delete: ";
    cin >> id;
    int index = findSportAreaIndexById(id);
    if (index != -1) sportAreas.erase(sportAreas.begin() + index);
    else cout << "Sport area not found.\n";
}

void updateSportArea() {
    int id;
    cout << "Enter sport area id to update: ";
    cin >> id;
    int index = findSportAreaIndexById(id);
    if (index != -1) {
        cout << "Enter new sport area name: ";
        cin >> sportAreas[index].name;
        cout << "Enter new sport area location: ";
        cin >> sportAreas[index].location;
    } else {
        cout << "Sport area not found.\n";
    }
}

void displaySportAreas() {
    for (auto &area : sportAreas) {
        cout << "ID: " << area.id << ", Name: " << area.name << ", Location: " << area.location << endl;
    }
}

void searchCustomer() {
    int id;
    cout << "Enter customer id to search: ";
    cin >> id;
    int index = findCustomerIndexById(id);
    if (index != -1) {
        cout << "ID: " << customers[index].id << ", Name: " << customers[index].name 
             << ", Contact: " << customers[index].contact << endl;
    } else {
        cout << "Customer not found.\n";
    }
}

void searchSportArea() {
    int id;
    cout << "Enter sport area id to search: ";
    cin >> id;
    int index = findSportAreaIndexById(id);
    if (index != -1) {
        cout << "ID: " << sportAreas[index].id << ", Name: " << sportAreas[index].name 
             << ", Location: " << sportAreas[index].location << endl;
    } else {
        cout << "Sport area not found.\n";
    }
}

int main() {
    char choice;
    while (true) {
        cout << "1. Add Customer\n2. Delete Customer\n3. Update Customer\n4. Display Customers\n";
        cout << "5. Add Sport Area\n6. Delete Sport Area\n7. Update Sport Area\n8. Display Sport Areas\n";
        cout << "9. Search Customer\n10. Search Sport Area\n11. Exit\n";
        cin >> choice;
        switch (choice) {
            case '1':
                addCustomer();
                break;
            case '2':
                deleteCustomer();
                break;
            case '3':
                updateCustomer();
                break;
            case '4':
                displayCustomers();
                break;
            case '5':
                addSportArea();
                break;
            case '6':
                deleteSportArea();
                break;
            case '7':
                updateSportArea();
                break;
            case '8':
                displaySportAreas();
                break;
            case '9':
                searchCustomer();
                break;
            case '10':
                searchSportArea();
                break;
            case '11':
                return 0;
            default:
                cout << "Invalid choice.\n";
                break;
        }
    }
}