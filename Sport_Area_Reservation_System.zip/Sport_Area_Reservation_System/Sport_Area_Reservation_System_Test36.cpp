#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;
    Customer(int id, std::string name, std::string contact) 
        : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    std::string name;
    std::string type;
    SportArea(int id, std::string name, std::string type) 
        : id(id), name(name), type(type) {}
};

class ReservationSystem {
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
    
public:
    void addCustomer(int id, const std::string& name, const std::string& contact) {
        customers.emplace_back(id, name, contact);
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& contact) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name 
                      << ", Contact: " << customer.contact << std::endl;
        }
    }

    void addSportArea(int id, const std::string& name, const std::string& type) {
        sportAreas.emplace_back(id, name, type);
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, const std::string& name, const std::string& type) {
        for (auto& sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.type = type;
                break;
            }
        }
    }

    SportArea* searchSportArea(int id) {
        for (auto& sportArea : sportAreas) {
            if (sportArea.id == id) {
                return &sportArea;
            }
        }
        return nullptr;
    }

    void displaySportAreas() {
        for (const auto& sportArea : sportAreas) {
            std::cout << "ID: " << sportArea.id << ", Name: " << sportArea.name 
                      << ", Type: " << sportArea.type << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;

    system.addCustomer(1, "John Doe", "123456789");
    system.addCustomer(2, "Jane Smith", "987654321");

    system.addSportArea(1, "Tennis Court", "Tennis");
    system.addSportArea(2, "Swimming Pool", "Swimming");

    std::cout << "Customers:\n";
    system.displayCustomers();

    std::cout << "\nSport Areas:\n";
    system.displaySportAreas();

    system.updateCustomer(1, "John Doe Jr.", "1122334455");
    system.updateSportArea(2, "Olympic Pool", "Swimming");

    std::cout << "\nUpdated Customers:\n";
    system.displayCustomers();

    std::cout << "\nUpdated Sport Areas:\n";
    system.displaySportAreas();

    system.deleteCustomer(2);
    system.deleteSportArea(1);

    std::cout << "\nAfter Deletion - Customers:\n";
    system.displayCustomers();

    std::cout << "\nAfter Deletion - Sport Areas:\n";
    system.displaySportAreas();

    return 0;
}