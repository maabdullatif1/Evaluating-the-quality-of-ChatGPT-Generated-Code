#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    std::string name;
    std::string contact;
    
    Customer(std::string n, std::string c) : name(n), contact(c) {}
};

class SportArea {
public:
    std::string areaName;
    bool isReserved;
    
    SportArea(std::string an) : areaName(an), isReserved(false) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
    
public:
    void addCustomer(std::string name, std::string contact) {
        customers.push_back(Customer(name, contact));
    }

    void deleteCustomer(std::string name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(std::string oldName, std::string newName, std::string newContact) {
        for (auto& c : customers) {
            if (c.name == oldName) {
                c.name = newName;
                c.contact = newContact;
                break;
            }
        }
    }

    bool searchCustomer(std::string name) {
        for (const auto& c : customers) {
            if (c.name == name) return true;
        }
        return false;
    }

    void displayCustomers() {
        for (const auto& c : customers) {
            std::cout << "Name: " << c.name << ", Contact: " << c.contact << "\n";
        }
    }

    void addSportArea(std::string areaName) {
        sportAreas.push_back(SportArea(areaName));
    }

    void deleteSportArea(std::string areaName) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->areaName == areaName) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(std::string oldAreaName, std::string newAreaName) {
        for (auto& a : sportAreas) {
            if (a.areaName == oldAreaName) {
                a.areaName = newAreaName;
                break;
            }
        }
    }

    bool searchSportArea(std::string areaName) {
        for (const auto& a : sportAreas) {
            if (a.areaName == areaName) return true;
        }
        return false;
    }

    void displaySportAreas() {
        for (const auto& a : sportAreas) {
            std::cout << "Area Name: " << a.areaName << ", Reserved: " << (a.isReserved ? "Yes" : "No") << "\n";
        }
    }

    void reserveArea(std::string areaName) {
        for (auto& a : sportAreas) {
            if (a.areaName == areaName && !a.isReserved) {
                a.isReserved = true;
                break;
            }
        }
    }

    void releaseArea(std::string areaName) {
        for (auto& a : sportAreas) {
            if (a.areaName == areaName && a.isReserved) {
                a.isReserved = false;
                break;
            }
        }
    }
};

int main() {
    ReservationSystem system;
    
    system.addCustomer("John Doe", "123-456-7890");
    system.addSportArea("Tennis Court");
    
    system.displayCustomers();
    system.displaySportAreas();
    
    system.reserveArea("Tennis Court");
    system.displaySportAreas();
    
    return 0;
}