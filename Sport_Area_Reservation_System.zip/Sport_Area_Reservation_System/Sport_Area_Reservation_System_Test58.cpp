#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct SportArea {
    int id;
    string name;
    string type;
    double pricePerHour;
};

Customer customers[100];
SportArea sportAreas[100];
int customerCount = 0;
int sportAreaCount = 0;

void addCustomer() {
    Customer c;
    cout << "Enter Customer ID, Name, Phone: ";
    cin >> c.id >> ws;
    getline(cin, c.name);
    getline(cin, c.phone);
    customers[customerCount++] = c;
    cout << "Customer Added.\n";
}

void deleteCustomer() {
    int id;
    cout << "Enter Customer ID to delete: ";
    cin >> id;
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            customers[i] = customers[--customerCount];
            cout << "Customer Deleted.\n";
            return;
        }
    }
    cout << "Customer not found.\n";
}

void updateCustomer() {
    int id;
    cout << "Enter Customer ID to update: ";
    cin >> id;
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            cout << "Enter New Name, Phone: ";
            cin >> ws;
            getline(cin, customers[i].name);
            getline(cin, customers[i].phone);
            cout << "Customer Updated.\n";
            return;
        }
    }
    cout << "Customer not found.\n";
}

void searchCustomer() {
    int id;
    cout << "Enter Customer ID to search: ";
    cin >> id;
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            cout << "Customer Found: " << customers[i].name << ", " << customers[i].phone << "\n";
            return;
        }
    }
    cout << "Customer not found.\n";
}

void displayCustomers() {
    for (int i = 0; i < customerCount; i++) {
        cout << "ID: " << customers[i].id << ", Name: " << customers[i].name << ", Phone: " << customers[i].phone << "\n";
    }
}

void addSportArea() {
    SportArea sa;
    cout << "Enter Sport Area ID, Name, Type, Price Per Hour: ";
    cin >> sa.id >> ws;
    getline(cin, sa.name);
    getline(cin, sa.type);
    cin >> sa.pricePerHour;
    sportAreas[sportAreaCount++] = sa;
    cout << "Sport Area Added.\n";
}

void deleteSportArea() {
    int id;
    cout << "Enter Sport Area ID to delete: ";
    cin >> id;
    for (int i = 0; i < sportAreaCount; i++) {
        if (sportAreas[i].id == id) {
            sportAreas[i] = sportAreas[--sportAreaCount];
            cout << "Sport Area Deleted.\n";
            return;
        }
    }
    cout << "Sport Area not found.\n";
}

void updateSportArea() {
    int id;
    cout << "Enter Sport Area ID to update: ";
    cin >> id;
    for (int i = 0; i < sportAreaCount; i++) {
        if (sportAreas[i].id == id) {
            cout << "Enter New Name, Type, Price Per Hour: ";
            cin >> ws;
            getline(cin, sportAreas[i].name);
            getline(cin, sportAreas[i].type);
            cin >> sportAreas[i].pricePerHour;
            cout << "Sport Area Updated.\n";
            return;
        }
    }
    cout << "Sport Area not found.\n";
}

void searchSportArea() {
    int id;
    cout << "Enter Sport Area ID to search: ";
    cin >> id;
    for (int i = 0; i < sportAreaCount; i++) {
        if (sportAreas[i].id == id) {
            cout << "Sport Area Found: " << sportAreas[i].name << ", " << sportAreas[i].type << ", $" << sportAreas[i].pricePerHour << "/hr\n";
            return;
        }
    }
    cout << "Sport Area not found.\n";
}

void displaySportAreas() {
    for (int i = 0; i < sportAreaCount; i++) {
        cout << "ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name << ", Type: " << sportAreas[i].type << ", Price Per Hour: $" << sportAreas[i].pricePerHour << "\n";
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Customer\n2. Delete Customer\n3. Update Customer\n4. Search Customer\n5. Display Customers\n6. Add Sport Area\n7. Delete Sport Area\n8. Update Sport Area\n9. Search Sport Area\n10. Display Sport Areas\n0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addCustomer(); break;
            case 2: deleteCustomer(); break;
            case 3: updateCustomer(); break;
            case 4: searchCustomer(); break;
            case 5: displayCustomers(); break;
            case 6: addSportArea(); break;
            case 7: deleteSportArea(); break;
            case 8: updateSportArea(); break;
            case 9: searchSportArea(); break;
            case 10: displaySportAreas(); break;
            case 0: return 0;
            default: cout << "Invalid choice.\n";
        }
    }
}