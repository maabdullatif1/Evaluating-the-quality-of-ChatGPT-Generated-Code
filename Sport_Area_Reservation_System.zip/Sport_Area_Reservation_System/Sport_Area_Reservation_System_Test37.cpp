#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string contact;
};

struct SportArea {
    int id;
    std::string name;
    std::string location;
    bool isAvailable;
};

class ReservationSystem {
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
    int customerIDCounter;
    int sportAreaIDCounter;

public:
    ReservationSystem() : customerIDCounter(0), sportAreaIDCounter(0) {}

    void addCustomer(const std::string& name, const std::string& contact) {
        customers.push_back({++customerIDCounter, name, contact});
    }

    void addSportArea(const std::string& name, const std::string& location, bool isAvailable) {
        sportAreas.push_back({++sportAreaIDCounter, name, location, isAvailable});
    }

    void deleteCustomer(int id) {
        customers.erase(std::remove_if(customers.begin(), customers.end(),
                        [id](const Customer& c) { return c.id == id; }), customers.end());
    }

    void deleteSportArea(int id) {
        sportAreas.erase(std::remove_if(sportAreas.begin(), sportAreas.end(),
                        [id](const SportArea& s) { return s.id == id; }), sportAreas.end());
    }

    void updateCustomer(int id, const std::string& name, const std::string& contact) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }

    void updateSportArea(int id, const std::string& name, const std::string& location, bool isAvailable) {
        for (auto& sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.location = location;
                sportArea.isAvailable = isAvailable;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    SportArea* searchSportArea(int id) {
        for (auto& sportArea : sportAreas) {
            if (sportArea.id == id) {
                return &sportArea;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << std::endl;
        }
    }

    void displaySportAreas() {
        for (const auto& sportArea : sportAreas) {
            std::cout << "ID: " << sportArea.id << ", Name: " << sportArea.name
                      << ", Location: " << sportArea.location
                      << ", Available: " << (sportArea.isAvailable ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer("John Doe", "123456789");
    system.addCustomer("Jane Doe", "987654321");
    system.addSportArea("Tennis Court", "North Wing", true);
    system.addSportArea("Basketball Court", "South Wing", false);
    system.displayCustomers();
    system.displaySportAreas();
    Customer* customer = system.searchCustomer(1);
    SportArea* sportArea = system.searchSportArea(1);
    if (customer) {
        std::cout << "Found customer: " << customer->name << std::endl;
    }
    if (sportArea) {
        std::cout << "Found sport area: " << sportArea->name << std::endl;
    }
    system.updateCustomer(1, "John Smith", "123456780");
    system.updateSportArea(1, "Tennis Court A", "East Wing", true);
    system.displayCustomers();
    system.displaySportAreas();
    system.deleteCustomer(2);
    system.deleteSportArea(2);
    system.displayCustomers();
    system.displaySportAreas();
    return 0;
}