#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct SportArea {
    int id;
    string name;
    string location;
};

struct ReservationSystem {
    Customer customers[100];
    SportArea sportAreas[100];
    int customerCount;
    int sportAreaCount;

    ReservationSystem() : customerCount(0), sportAreaCount(0) {}

    void addCustomer(int id, string name, string phone) {
        customers[customerCount++] = {id, name, phone};
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                for (int j = i; j < customerCount - 1; ++j) {
                    customers[j] = customers[j + 1];
                }
                --customerCount;
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string phone) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i] = {id, name, phone};
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << ", Phone: " << customers[i].phone << endl;
                break;
            }
        }
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; ++i) {
            cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << ", Phone: " << customers[i].phone << endl;
        }
    }

    void addSportArea(int id, string name, string location) {
        sportAreas[sportAreaCount++] = {id, name, location};
    }

    void deleteSportArea(int id) {
        for (int i = 0; i < sportAreaCount; ++i) {
            if (sportAreas[i].id == id) {
                for (int j = i; j < sportAreaCount - 1; ++j) {
                    sportAreas[j] = sportAreas[j + 1];
                }
                --sportAreaCount;
                break;
            }
        }
    }

    void updateSportArea(int id, string name, string location) {
        for (int i = 0; i < sportAreaCount; ++i) {
            if (sportAreas[i].id == id) {
                sportAreas[i] = {id, name, location};
                break;
            }
        }
    }

    void searchSportArea(int id) {
        for (int i = 0; i < sportAreaCount; ++i) {
            if (sportAreas[i].id == id) {
                cout << "SportArea ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name << ", Location: " << sportAreas[i].location << endl;
                break;
            }
        }
    }

    void displaySportAreas() {
        for (int i = 0; i < sportAreaCount; ++i) {
            cout << "SportArea ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name << ", Location: " << sportAreas[i].location << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "John Doe", "123456789");
    system.addCustomer(2, "Jane Smith", "987654321");
    system.addSportArea(1, "Basketball Court", "Building A");
    system.addSportArea(2, "Tennis Court", "Building B");
    
    system.displayCustomers();
    system.displaySportAreas();
    
    system.updateCustomer(1, "John A. Doe", "111222333");
    system.updateSportArea(1, "Main Basketball Court", "Building C");
    
    system.searchCustomer(1);
    system.searchSportArea(1);

    system.deleteCustomer(2);
    system.deleteSportArea(2);

    system.displayCustomers();
    system.displaySportAreas();

    return 0;
}