#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
};

struct SportArea {
    int id;
    string name;
    bool isReserved;
};

Customer customers[100];
SportArea sportAreas[100];
int customerCount = 0;
int sportAreaCount = 0;

void addCustomer(int id, string name) {
    customers[customerCount++] = {id, name};
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; ++j) {
                customers[j] = customers[j + 1];
            }
            customerCount--;
            break;
        }
    }
}

void updateCustomer(int id, string name) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            customers[i].name = name;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; ++i) {
        cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << endl;
    }
}

void addSportArea(int id, string name) {
    sportAreas[sportAreaCount++] = {id, name, false};
}

void deleteSportArea(int id) {
    for (int i = 0; i < sportAreaCount; ++i) {
        if (sportAreas[i].id == id) {
            for (int j = i; j < sportAreaCount - 1; ++j) {
                sportAreas[j] = sportAreas[j + 1];
            }
            sportAreaCount--;
            break;
        }
    }
}

void updateSportArea(int id, string name) {
    for (int i = 0; i < sportAreaCount; ++i) {
        if (sportAreas[i].id == id) {
            sportAreas[i].name = name;
            break;
        }
    }
}

SportArea* searchSportArea(int id) {
    for (int i = 0; i < sportAreaCount; ++i) {
        if (sportAreas[i].id == id) {
            return &sportAreas[i];
        }
    }
    return nullptr;
}

void displaySportAreas() {
    for (int i = 0; i < sportAreaCount; ++i) {
        cout << "Sport Area ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name 
             << ", Reserved: " << (sportAreas[i].isReserved ? "Yes" : "No") << endl;
    }
}

int main() {
    addCustomer(1, "John Doe");
    addCustomer(2, "Jane Smith");
    addSportArea(1, "Tennis Court");
    addSportArea(2, "Football Field");

    updateCustomer(1, "John A. Doe");
    updateSportArea(2, "Soccer Field");

    displayCustomers();
    displaySportAreas();

    Customer* customer = searchCustomer(1);
    if (customer != nullptr) {
        cout << "Found Customer: " << customer->name << endl;
    }

    SportArea* sportArea = searchSportArea(2);
    if (sportArea != nullptr) {
        cout << "Found Sport Area: " << sportArea->name << endl;
    }

    deleteCustomer(2);
    deleteSportArea(1);

    displayCustomers();
    displaySportAreas();

    return 0;
}