#include <iostream>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
};

struct SportArea {
    int id;
    string name;
    bool reserved;
};

Customer customers[100];
SportArea sportAreas[100];
int customerCount = 0;
int sportAreaCount = 0;

void addCustomer(int id, const string& name) {
    customers[customerCount++] = {id, name};
}

void addSportArea(int id, const string& name) {
    sportAreas[sportAreaCount++] = {id, name, false};
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; j++) {
                customers[j] = customers[j + 1];
            }
            customerCount--;
            break;
        }
    }
}

void deleteSportArea(int id) {
    for (int i = 0; i < sportAreaCount; i++) {
        if (sportAreas[i].id == id) {
            for (int j = i; j < sportAreaCount - 1; j++) {
                sportAreas[j] = sportAreas[j + 1];
            }
            sportAreaCount--;
            break;
        }
    }
}

void updateCustomer(int id, const string& newName) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            customers[i].name = newName;
            break;
        }
    }
}

void updateSportArea(int id, const string& newName) {
    for (int i = 0; i < sportAreaCount; i++) {
        if (sportAreas[i].id == id) {
            sportAreas[i].name = newName;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

SportArea* searchSportArea(int id) {
    for (int i = 0; i < sportAreaCount; i++) {
        if (sportAreas[i].id == id) {
            return &sportAreas[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; i++) {
        cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << endl;
    }
}

void displaySportAreas() {
    for (int i = 0; i < sportAreaCount; i++) {
        cout << "Sport Area ID: " << sportAreas[i].id << ", Name: " << sportAreas[i].name
             << ", Reserved: " << (sportAreas[i].reserved ? "Yes" : "No") << endl;
    }
}

int main() {
    addCustomer(1, "Alice");
    addCustomer(2, "Bob");
    addSportArea(1, "Tennis Court");
    addSportArea(2, "Basketball Court");

    displayCustomers();
    displaySportAreas();

    updateCustomer(1, "Alicia");
    updateSportArea(1, "Main Tennis Court");
    deleteCustomer(2);
    deleteSportArea(2);

    displayCustomers();
    displaySportAreas();

    return 0;
}