#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;
    Customer(int i, std::string n, std::string c) : id(i), name(n), contact(c) {}
};

class SportArea {
public:
    int id;
    std::string name;
    bool isAvailable;
    SportArea(int i, std::string n, bool a) : id(i), name(n), isAvailable(a) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
public:
    void addCustomer(int id, std::string name, std::string contact) {
        customers.push_back(Customer(id, name, contact));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string contact) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << std::endl;
        }
    }

    void addSportArea(int id, std::string name, bool isAvailable) {
        sportAreas.push_back(SportArea(id, name, isAvailable));
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, std::string name, bool isAvailable) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.isAvailable = isAvailable;
            }
        }
    }

    SportArea* searchSportArea(int id) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                return &sportArea;
            }
        }
        return nullptr;
    }

    void displaySportAreas() {
        for (const auto &sportArea : sportAreas) {
            std::cout << "ID: " << sportArea.id << ", Name: " << sportArea.name << ", Available: " << (sportArea.isAvailable ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "Alice", "555-1234");
    system.addCustomer(2, "Bob", "555-5678");
    system.addSportArea(1, "Tennis Court", true);
    system.addSportArea(2, "Swimming Pool", false);
    system.displayCustomers();
    system.displaySportAreas();
    Customer* customer = system.searchCustomer(1);
    if (customer != nullptr) {
        std::cout << "Found Customer: " << customer->name << "\n";
    }
    SportArea* area = system.searchSportArea(1);
    if (area != nullptr) {
        std::cout << "Found Sport Area: " << area->name << "\n";
    }
    system.updateCustomer(1, "Alice B.", "555-9876");
    system.updateSportArea(1, "Tennis Court", false);
    system.displayCustomers();
    system.displaySportAreas();
    system.deleteCustomer(2);
    system.deleteSportArea(2);
    system.displayCustomers();
    system.displaySportAreas();
    return 0;
}