#include <iostream>
#include <string>
#include <vector>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;
    
    Customer(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    std::string name;
    std::string type;
    
    SportArea(int id, std::string name, std::string type)
        : id(id), name(name), type(type) {}
};

class ReservationSystem {
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
public:
    void addCustomer(int id, std::string name, std::string contact) {
        customers.push_back(Customer(id, name, contact));
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, std::string name, std::string contact) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }
    
    Customer searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return customer;
            }
        }
        return Customer(-1, "", "");
    }
    
    void displayCustomers() {
        for (auto &customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << std::endl;
        }
    }
    
    void addSportArea(int id, std::string name, std::string type) {
        sportAreas.push_back(SportArea(id, name, type));
    }
    
    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }
    
    void updateSportArea(int id, std::string name, std::string type) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = name;
                sportArea.type = type;
                break;
            }
        }
    }
    
    SportArea searchSportArea(int id) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                return sportArea;
            }
        }
        return SportArea(-1, "", "");
    }
    
    void displaySportAreas() {
        for (auto &sportArea : sportAreas) {
            std::cout << "ID: " << sportArea.id << ", Name: " << sportArea.name << ", Type: " << sportArea.type << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "John Doe", "123-456-7890");
    system.addCustomer(2, "Jane Smith", "098-765-4321");
    system.displayCustomers();

    system.addSportArea(1, "Tennis Court", "Tennis");
    system.addSportArea(2, "Soccer Field", "Soccer");
    system.displaySportAreas();

    Customer foundCustomer = system.searchCustomer(1);
    std::cout << "Found Customer: " << foundCustomer.name << std::endl;

    SportArea foundArea = system.searchSportArea(2);
    std::cout << "Found Sport Area: " << foundArea.name << std::endl;

    system.updateCustomer(1, "John Doe Updated", "111-222-3333");
    system.displayCustomers();

    system.updateSportArea(1, "Updated Tennis Court", "Updated Tennis");
    system.displaySportAreas();

    system.deleteCustomer(2);
    system.displayCustomers();

    system.deleteSportArea(2);
    system.displaySportAreas();

    return 0;
}