#include <iostream>
#include <string>
#define MAX_CUSTOMERS 100
#define MAX_AREAS 100

class Customer {
public:
    int id;
    std::string name;
    std::string contact;
};

class SportArea {
public:
    int id;
    std::string name;
    bool isReserved;
};

class ReservationSystem {
private:
    Customer customers[MAX_CUSTOMERS];
    SportArea areas[MAX_AREAS];
    int customerCount;
    int areaCount;

public:
    ReservationSystem() : customerCount(0), areaCount(0) {}

    void addCustomer(int id, std::string name, std::string contact) {
        if(customerCount < MAX_CUSTOMERS) {
            customers[customerCount].id = id;
            customers[customerCount].name = name;
            customers[customerCount].contact = contact;
            customerCount++;
        }
    }

    void deleteCustomer(int id) {
        for(int i = 0; i < customerCount; i++) {
            if(customers[i].id == id) {
                for(int j = i; j < customerCount - 1; j++) {
                    customers[j] = customers[j+1];
                }
                customerCount--;
                break;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string contact) {
        for(int i = 0; i < customerCount; i++) {
            if(customers[i].id == id) {
                customers[i].name = name;
                customers[i].contact = contact;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for(int i = 0; i < customerCount; i++) {
            if(customers[i].id == id) {
                return &customers[i];
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for(int i = 0; i < customerCount; i++) {
            std::cout << "ID: " << customers[i].id << ", Name: " << customers[i].name
                      << ", Contact: " << customers[i].contact << std::endl;
        }
    }

    void addSportArea(int id, std::string name) {
        if(areaCount < MAX_AREAS) {
            areas[areaCount].id = id;
            areas[areaCount].name = name;
            areas[areaCount].isReserved = false;
            areaCount++;
        }
    }

    void deleteSportArea(int id) {
        for(int i = 0; i < areaCount; i++) {
            if(areas[i].id == id) {
                for(int j = i; j < areaCount - 1; j++) {
                    areas[j] = areas[j+1];
                }
                areaCount--;
                break;
            }
        }
    }

    void updateSportArea(int id, std::string name, bool isReserved) {
        for(int i = 0; i < areaCount; i++) {
            if(areas[i].id == id) {
                areas[i].name = name;
                areas[i].isReserved = isReserved;
                break;
            }
        }
    }

    SportArea* searchSportArea(int id) {
        for(int i = 0; i < areaCount; i++) {
            if(areas[i].id == id) {
                return &areas[i];
            }
        }
        return nullptr;
    }

    void displaySportAreas() {
        for(int i = 0; i < areaCount; i++) {
            std::cout << "ID: " << areas[i].id << ", Name: " << areas[i].name
                      << ", Reserved: " << (areas[i].isReserved ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;

    system.addCustomer(1, "John Doe", "123-456-7890");
    system.addCustomer(2, "Jane Smith", "098-765-4321");

    system.displayCustomers();

    system.addSportArea(1, "Tennis Court");
    system.addSportArea(2, "Soccer Field");

    system.displaySportAreas();

    return 0;
}