#include <iostream>
#include <string>
using namespace std;

const int MAX_CUSTOMERS = 100;
const int MAX_SPORT_AREAS = 100;

struct Customer {
    int id;
    string name;
    string contact;
};

struct SportArea {
    int id;
    string name;
    string type;
};

Customer customers[MAX_CUSTOMERS];
SportArea sport_areas[MAX_SPORT_AREAS];
int customer_count = 0;
int sport_area_count = 0;

void addCustomer() {
    if (customer_count >= MAX_CUSTOMERS) return;
    customers[customer_count].id = customer_count + 1;
    cout << "Enter customer name: ";
    cin >> customers[customer_count].name;
    cout << "Enter customer contact: ";
    cin >> customers[customer_count].contact;
    customer_count++;
}

void deleteCustomer() {
    int id;
    cout << "Enter customer ID to delete: ";
    cin >> id;
    for (int i = 0; i < customer_count; i++) {
        if (customers[i].id == id) {
            for (int j = i; j < customer_count - 1; j++) {
                customers[j] = customers[j + 1];
            }
            customer_count--;
            break;
        }
    }
}

void updateCustomer() {
    int id;
    cout << "Enter customer ID to update: ";
    cin >> id;
    for (int i = 0; i < customer_count; i++) {
        if (customers[i].id == id) {
            cout << "Enter new customer name: ";
            cin >> customers[i].name;
            cout << "Enter new customer contact: ";
            cin >> customers[i].contact;
            break;
        }
    }
}

void searchCustomer() {
    int id;
    cout << "Enter customer ID to search: ";
    cin >> id;
    for (int i = 0; i < customer_count; i++) {
        if (customers[i].id == id) {
            cout << "Customer ID: " << customers[i].id << endl;
            cout << "Name: " << customers[i].name << endl;
            cout << "Contact: " << customers[i].contact << endl;
            break;
        }
    }
}

void displayCustomers() {
    for (int i = 0; i < customer_count; i++) {
        cout << "ID: " << customers[i].id << " Name: " << customers[i].name << " Contact: " << customers[i].contact << endl;
    }
}

void addSportArea() {
    if (sport_area_count >= MAX_SPORT_AREAS) return;
    sport_areas[sport_area_count].id = sport_area_count + 1;
    cout << "Enter sport area name: ";
    cin >> sport_areas[sport_area_count].name;
    cout << "Enter sport area type: ";
    cin >> sport_areas[sport_area_count].type;
    sport_area_count++;
}

void deleteSportArea() {
    int id;
    cout << "Enter sport area ID to delete: ";
    cin >> id;
    for (int i = 0; i < sport_area_count; i++) {
        if (sport_areas[i].id == id) {
            for (int j = i; j < sport_area_count - 1; j++) {
                sport_areas[j] = sport_areas[j + 1];
            }
            sport_area_count--;
            break;
        }
    }
}

void updateSportArea() {
    int id;
    cout << "Enter sport area ID to update: ";
    cin >> id;
    for (int i = 0; i < sport_area_count; i++) {
        if (sport_areas[i].id == id) {
            cout << "Enter new sport area name: ";
            cin >> sport_areas[i].name;
            cout << "Enter new sport area type: ";
            cin >> sport_areas[i].type;
            break;
        }
    }
}

void searchSportArea() {
    int id;
    cout << "Enter sport area ID to search: ";
    cin >> id;
    for (int i = 0; i < sport_area_count; i++) {
        if (sport_areas[i].id == id) {
            cout << "Sport Area ID: " << sport_areas[i].id << endl;
            cout << "Name: " << sport_areas[i].name << endl;
            cout << "Type: " << sport_areas[i].type << endl;
            break;
        }
    }
}

void displaySportAreas() {
    for (int i = 0; i < sport_area_count; i++) {
        cout << "ID: " << sport_areas[i].id << " Name: " << sport_areas[i].name << " Type: " << sport_areas[i].type << endl;
    }
}

int main() {
    int option;
    do {
        cout << "1. Add Customer\n2. Delete Customer\n3. Update Customer\n4. Search Customer\n5. Display Customers\n";
        cout << "6. Add Sport Area\n7. Delete Sport Area\n8. Update Sport Area\n9. Search Sport Area\n10. Display Sport Areas\n11. Exit\n";
        cout << "Choose an option: ";
        cin >> option;
        switch(option) {
            case 1: addCustomer(); break;
            case 2: deleteCustomer(); break;
            case 3: updateCustomer(); break;
            case 4: searchCustomer(); break;
            case 5: displayCustomers(); break;
            case 6: addSportArea(); break;
            case 7: deleteSportArea(); break;
            case 8: updateSportArea(); break;
            case 9: searchSportArea(); break;
            case 10: displaySportAreas(); break;
        }
    } while(option != 11);
    return 0;
}