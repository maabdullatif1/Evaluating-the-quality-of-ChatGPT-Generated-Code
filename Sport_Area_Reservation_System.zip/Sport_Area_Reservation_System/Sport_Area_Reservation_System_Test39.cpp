#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string contact;
};

struct SportArea {
    int id;
    std::string name;
    std::string location;
    bool isAvailable;
};

class ReservationSystem {
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
    int customerIdCounter = 1;
    int sportAreaIdCounter = 1;

public:
    void addCustomer(const std::string &name, const std::string &contact) {
        customers.push_back({customerIdCounter++, name, contact});
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string &name, const std::string &contact) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }

    Customer *searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name
                      << ", Contact: " << customer.contact << std::endl;
        }
    }

    void addSportArea(const std::string &name, const std::string &location, bool isAvailable) {
        sportAreas.push_back({sportAreaIdCounter++, name, location, isAvailable});
    }

    void deleteSportArea(int id) {
        for (auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if (it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, const std::string &name, const std::string &location, bool isAvailable) {
        for (auto &area : sportAreas) {
            if (area.id == id) {
                area.name = name;
                area.location = location;
                area.isAvailable = isAvailable;
                break;
            }
        }
    }

    SportArea *searchSportArea(int id) {
        for (auto &area : sportAreas) {
            if (area.id == id) {
                return &area;
            }
        }
        return nullptr;
    }

    void displaySportAreas() {
        for (const auto &area : sportAreas) {
            std::cout << "ID: " << area.id << ", Name: " << area.name
                      << ", Location: " << area.location
                      << ", Available: " << (area.isAvailable ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer("Alice", "1234567890");
    system.addCustomer("Bob", "0987654321");
    system.displayCustomers();
    system.addSportArea("Tennis Court", "North Wing", true);
    system.addSportArea("Basketball Court", "South Wing", false);
    system.displaySportAreas();
    return 0;
}