#include <iostream>
#include <string>
#include <vector>

class Customer {
public:
    std::string name;
    std::string phone;
    Customer(std::string n, std::string p) : name(n), phone(p) {}
};

class SportArea {
public:
    std::string name;
    bool reserved;
    SportArea(std::string n) : name(n), reserved(false) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;

    int findCustomerIndex(const std::string& name) {
        for (size_t i = 0; i < customers.size(); ++i)
            if (customers[i].name == name)
                return i;
        return -1;
    }

    int findSportAreaIndex(const std::string& name) {
        for (size_t i = 0; i < sportAreas.size(); ++i)
            if (sportAreas[i].name == name)
                return i;
        return -1;
    }

public:
    void addCustomer(const std::string& name, const std::string& phone) {
        if (findCustomerIndex(name) == -1)
            customers.push_back(Customer(name, phone));
    }

    void deleteCustomer(const std::string& name) {
        int index = findCustomerIndex(name);
        if (index != -1)
            customers.erase(customers.begin() + index);
    }

    void updateCustomer(const std::string& name, const std::string& phone) {
        int index = findCustomerIndex(name);
        if (index != -1)
            customers[index].phone = phone;
    }

    void searchCustomer(const std::string& name) {
        int index = findCustomerIndex(name);
        if (index != -1)
            std::cout << "Customer found: " << customers[index].name << ", " << customers[index].phone << "\n";
        else
            std::cout << "Customer not found\n";
    }

    void displayCustomers() {
        for (const auto& customer : customers)
            std::cout << "Customer: " << customer.name << ", " << customer.phone << "\n";
    }

    void addSportArea(const std::string& name) {
        if (findSportAreaIndex(name) == -1)
            sportAreas.push_back(SportArea(name));
    }

    void deleteSportArea(const std::string& name) {
        int index = findSportAreaIndex(name);
        if (index != -1)
            sportAreas.erase(sportAreas.begin() + index);
    }

    void updateSportAreaReservation(const std::string& name, bool reserved) {
        int index = findSportAreaIndex(name);
        if (index != -1)
            sportAreas[index].reserved = reserved;
    }

    void searchSportArea(const std::string& name) {
        int index = findSportAreaIndex(name);
        if (index != -1)
            std::cout << "Sport Area found: " << sportAreas[index].name << ", Reserved: " << (sportAreas[index].reserved ? "Yes" : "No") << "\n";
        else
            std::cout << "Sport Area not found\n";
    }

    void displaySportAreas() {
        for (const auto& area : sportAreas)
            std::cout << "Sport Area: " << area.name << ", Reserved: " << (area.reserved ? "Yes" : "No") << "\n";
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer("Alice", "123456");
    system.addCustomer("Bob", "654321");
    system.addSportArea("Tennis Court");
    system.addSportArea("Swimming Pool");
    system.updateSportAreaReservation("Tennis Court", true);
    system.displayCustomers();
    system.displaySportAreas();
    return 0;
}