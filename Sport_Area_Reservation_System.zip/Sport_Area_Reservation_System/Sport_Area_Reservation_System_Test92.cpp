#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string contact;
};

struct SportArea {
    int id;
    string name;
    string location;
};

Customer customers[100];
SportArea sportAreas[100];
int customerCount = 0;
int sportAreaCount = 0;

void addCustomer() {
    cout << "Enter Customer ID: ";
    cin >> customers[customerCount].id;
    cout << "Enter Customer Name: ";
    cin >> customers[customerCount].name;
    cout << "Enter Customer Contact: ";
    cin >> customers[customerCount].contact;
    customerCount++;
}

void deleteCustomer() {
    int id;
    cout << "Enter Customer ID to delete: ";
    cin >> id;
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; j++) {
                customers[j] = customers[j + 1];
            }
            customerCount--;
            break;
        }
    }
}

void updateCustomer() {
    int id;
    cout << "Enter Customer ID to update: ";
    cin >> id;
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            cout << "Enter new name: ";
            cin >> customers[i].name;
            cout << "Enter new contact: ";
            cin >> customers[i].contact;
            break;
        }
    }
}

void searchCustomer() {
    int id;
    cout << "Enter Customer ID to search: ";
    cin >> id;
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            cout << "Customer ID: " << customers[i].id << endl;
            cout << "Name: " << customers[i].name << endl;
            cout << "Contact: " << customers[i].contact << endl;
            break;
        }
    }
}

void displayCustomers() {
    for (int i = 0; i < customerCount; i++) {
        cout << "Customer ID: " << customers[i].id << endl;
        cout << "Name: " << customers[i].name << endl;
        cout << "Contact: " << customers[i].contact << endl;
    }
}

void addSportArea() {
    cout << "Enter Sport Area ID: ";
    cin >> sportAreas[sportAreaCount].id;
    cout << "Enter Sport Area Name: ";
    cin >> sportAreas[sportAreaCount].name;
    cout << "Enter Sport Area Location: ";
    cin >> sportAreas[sportAreaCount].location;
    sportAreaCount++;
}

void deleteSportArea() {
    int id;
    cout << "Enter Sport Area ID to delete: ";
    cin >> id;
    for (int i = 0; i < sportAreaCount; i++) {
        if (sportAreas[i].id == id) {
            for (int j = i; j < sportAreaCount - 1; j++) {
                sportAreas[j] = sportAreas[j + 1];
            }
            sportAreaCount--;
            break;
        }
    }
}

void updateSportArea() {
    int id;
    cout << "Enter Sport Area ID to update: ";
    cin >> id;
    for (int i = 0; i < sportAreaCount; i++) {
        if (sportAreas[i].id == id) {
            cout << "Enter new name: ";
            cin >> sportAreas[i].name;
            cout << "Enter new location: ";
            cin >> sportAreas[i].location;
            break;
        }
    }
}

void searchSportArea() {
    int id;
    cout << "Enter Sport Area ID to search: ";
    cin >> id;
    for (int i = 0; i < sportAreaCount; i++) {
        if (sportAreas[i].id == id) {
            cout << "Sport Area ID: " << sportAreas[i].id << endl;
            cout << "Name: " << sportAreas[i].name << endl;
            cout << "Location: " << sportAreas[i].location << endl;
            break;
        }
    }
}

void displaySportAreas() {
    for (int i = 0; i < sportAreaCount; i++) {
        cout << "Sport Area ID: " << sportAreas[i].id << endl;
        cout << "Name: " << sportAreas[i].name << endl;
        cout << "Location: " << sportAreas[i].location << endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Customer\n2. Delete Customer\n3. Update Customer\n4. Search Customer\n5. Display Customers\n";
        cout << "6. Add Sport Area\n7. Delete Sport Area\n8. Update Sport Area\n9. Search Sport Area\n10. Display Sport Areas\n11. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addCustomer(); break;
            case 2: deleteCustomer(); break;
            case 3: updateCustomer(); break;
            case 4: searchCustomer(); break;
            case 5: displayCustomers(); break;
            case 6: addSportArea(); break;
            case 7: deleteSportArea(); break;
            case 8: updateSportArea(); break;
            case 9: searchSportArea(); break;
            case 10: displaySportAreas(); break;
            case 11: return 0;
            default: cout << "Invalid choice\n"; break;
        }
    }
}