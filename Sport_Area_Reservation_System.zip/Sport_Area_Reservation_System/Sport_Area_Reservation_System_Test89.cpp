#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string phone;

    Customer(int i, std::string n, std::string p) : id(i), name(n), phone(p) {}
};

class SportArea {
public:
    int id;
    std::string name;
    std::string type;
    bool reserved;

    SportArea(int i, std::string n, std::string t) : id(i), name(n), type(t), reserved(false) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
    int customerIdCounter;
    int sportAreaIdCounter;

public:
    ReservationSystem() : customerIdCounter(1), sportAreaIdCounter(1) {}

    void addCustomer(std::string name, std::string phone) {
        customers.push_back(Customer(customerIdCounter++, name, phone));
    }

    void addSportArea(std::string name, std::string type) {
        sportAreas.push_back(SportArea(sportAreaIdCounter++, name, type));
    }

    void updateCustomer(int id, std::string newName, std::string newPhone) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = newName;
                customer.phone = newPhone;
                return;
            }
        }
    }

    void updateSportArea(int id, std::string newName, std::string newType) {
        for (auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                sportArea.name = newName;
                sportArea.type = newType;
                return;
            }
        }
    }

    void deleteCustomer(int id) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) {
                customers.erase(customers.begin() + i);
                return;
            }
        }
    }

    void deleteSportArea(int id) {
        for (size_t i = 0; i < sportAreas.size(); ++i) {
            if (sportAreas[i].id == id) {
                sportAreas.erase(sportAreas.begin() + i);
                return;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto &customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << "\n";
                return;
            }
        }
        std::cout << "Customer not found.\n";
    }

    void searchSportArea(int id) {
        for (const auto &sportArea : sportAreas) {
            if (sportArea.id == id) {
                std::cout << "SportArea ID: " << sportArea.id << ", Name: " << sportArea.name << ", Type: " << sportArea.type << ", Reserved: " << (sportArea.reserved ? "Yes" : "No") << "\n";
                return;
            }
        }
        std::cout << "SportArea not found.\n";
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << "\n";
        }
    }

    void displaySportAreas() {
        for (const auto &sportArea : sportAreas) {
            std::cout << "SportArea ID: " << sportArea.id << ", Name: " << sportArea.name << ", Type: " << sportArea.type << ", Reserved: " << (sportArea.reserved ? "Yes" : "No") << "\n";
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer("John Doe", "1234567890");
    system.addCustomer("Jane Smith", "0987654321");

    system.addSportArea("Tennis Court", "Tennis");
    system.addSportArea("Basketball Court", "Basketball");

    system.displayCustomers();
    system.displaySportAreas();

    return 0;
}