#include <iostream>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
};

struct SportArea {
    int id;
    string name;
};

struct ReservationSystem {
    Customer customers[100];
    SportArea areas[100];
    int customerCount;
    int areaCount;

    ReservationSystem() : customerCount(0), areaCount(0) {}

    void addCustomer(int id, string name) {
        customers[customerCount++] = {id, name};
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; i++) {
            if (customers[i].id == id) {
                customers[i] = customers[--customerCount];
                break;
            }
        }
    }

    void updateCustomer(int id, string name) {
        for (int i = 0; i < customerCount; i++) {
            if (customers[i].id == id) {
                customers[i].name = name;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (int i = 0; i < customerCount; i++) {
            if (customers[i].id == id) {
                return &customers[i];
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; i++) {
            cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << endl;
        }
    }

    void addSportArea(int id, string name) {
        areas[areaCount++] = {id, name};
    }

    void deleteSportArea(int id) {
        for (int i = 0; i < areaCount; i++) {
            if (areas[i].id == id) {
                areas[i] = areas[--areaCount];
                break;
            }
        }
    }

    void updateSportArea(int id, string name) {
        for (int i = 0; i < areaCount; i++) {
            if (areas[i].id == id) {
                areas[i].name = name;
                break;
            }
        }
    }

    SportArea* searchSportArea(int id) {
        for (int i = 0; i < areaCount; i++) {
            if (areas[i].id == id) {
                return &areas[i];
            }
        }
        return nullptr;
    }

    void displaySportAreas() {
        for (int i = 0; i < areaCount; i++) {
            cout << "Sport Area ID: " << areas[i].id << ", Name: " << areas[i].name << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "Alice");
    system.addCustomer(2, "Bob");
    system.displayCustomers();
    system.addSportArea(101, "Tennis Court");
    system.addSportArea(102, "Football Field");
    system.displaySportAreas();
    return 0;
}