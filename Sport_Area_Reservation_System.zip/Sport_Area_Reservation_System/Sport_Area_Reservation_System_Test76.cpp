#include <iostream>
#include <string>
#include <vector>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;
    
    Customer(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class SportArea {
public:
    int id;
    std::string name;
    std::string type;
    bool isAvailable;

    SportArea(int id, std::string name, std::string type, bool isAvailable = true)
        : id(id), name(name), type(type), isAvailable(isAvailable) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<SportArea> sportAreas;
    
    Customer* searchCustomer(int id) {
        for(auto& customer : customers)
            if(customer.id == id)
                return &customer;
        return nullptr;
    }

    SportArea* searchSportArea(int id) {
        for(auto& area : sportAreas)
            if(area.id == id)
                return &area;
        return nullptr;
    }

public:
    void addCustomer(int id, std::string name, std::string contact) {
        customers.push_back(Customer(id, name, contact));
    }
    
    void deleteCustomer(int id) {
        for(auto it = customers.begin(); it != customers.end(); ++it) {
            if(it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string contact) {
        Customer* customer = searchCustomer(id);
        if(customer) {
            customer->name = name;
            customer->contact = contact;
        }
    }

    void displayCustomer(int id) {
        Customer* customer = searchCustomer(id);
        if(customer) {
            std::cout << "Customer ID: " << customer->id 
                      << ", Name: " << customer->name 
                      << ", Contact: " << customer->contact << "\n";
        }
    }

    void addSportArea(int id, std::string name, std::string type) {
        sportAreas.push_back(SportArea(id, name, type));
    }

    void deleteSportArea(int id) {
        for(auto it = sportAreas.begin(); it != sportAreas.end(); ++it) {
            if(it->id == id) {
                sportAreas.erase(it);
                break;
            }
        }
    }

    void updateSportArea(int id, std::string name, std::string type, bool isAvailable) {
        SportArea* area = searchSportArea(id);
        if(area) {
            area->name = name;
            area->type = type;
            area->isAvailable = isAvailable;
        }
    }

    void displaySportArea(int id) {
        SportArea* area = searchSportArea(id);
        if(area) {
            std::cout << "Area ID: " << area->id 
                      << ", Name: " << area->name 
                      << ", Type: " << area->type 
                      << ", Available: " << (area->isAvailable ? "Yes" : "No") << "\n";
        }
    }

    void displayAllCustomers() {
        for(const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id 
                      << ", Name: " << customer.name 
                      << ", Contact: " << customer.contact << "\n";
        }
    }

    void displayAllSportAreas() {
        for(const auto& area : sportAreas) {
            std::cout << "Area ID: " << area.id 
                      << ", Name: " << area.name 
                      << ", Type: " << area.type 
                      << ", Available: " << (area.isAvailable ? "Yes" : "No") << "\n";
        }
    }
};

int main() {
    ReservationSystem system;

    system.addCustomer(1, "John Doe", "123456789");
    system.addCustomer(2, "Jane Smith", "987654321");

    system.addSportArea(1, "Court A", "Tennis");
    system.addSportArea(2, "Field B", "Soccer");

    system.displayAllCustomers();
    system.displayAllSportAreas();

    system.updateCustomer(1, "John Doe", "111111111");
    system.updateSportArea(2, "Field B", "Soccer", false);

    system.displayCustomer(1);
    system.displaySportArea(2);

    system.deleteCustomer(2);
    system.deleteSportArea(1);

    system.displayAllCustomers();
    system.displayAllSportAreas();

    return 0;
}