#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Patient {
public:
    int id;
    string name;
    int age;

    Patient(int id, string name, int age): id(id), name(name), age(age) {}
};

class Appointment {
public:
    int id;
    int patientId;
    string date;

    Appointment(int id, int patientId, string date): id(id), patientId(patientId), date(date) {}
};

class HealthcareSystem {
private:
    vector<Patient> patients;
    vector<Appointment> appointments;

    Patient* findPatientById(int id) {
        for (auto &patient : patients) {
            if (patient.id == id) return &patient;
        }
        return nullptr;
    }

    Appointment* findAppointmentById(int id) {
        for (auto &appointment : appointments) {
            if (appointment.id == id) return &appointment;
        }
        return nullptr;
    }

public:
    void addPatient(int id, string name, int age) {
        patients.emplace_back(id, name, age);
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, string name, int age) {
        Patient* patient = findPatientById(id);
        if (patient != nullptr) {
            patient->name = name;
            patient->age = age;
        }
    }

    void displayPatients() {
        for (const auto &patient : patients) {
            cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << endl;
        }
    }

    void addAppointment(int id, int patientId, string date) {
        appointments.emplace_back(id, patientId, date);
    }

    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->id == id) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int id, int patientId, string date) {
        Appointment* appointment = findAppointmentById(id);
        if (appointment != nullptr) {
            appointment->patientId = patientId;
            appointment->date = date;
        }
    }

    void displayAppointments() {
        for (const auto &appointment : appointments) {
            cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId << ", Date: " << appointment.date << endl;
        }
    }

    void searchPatient(int id) {
        Patient* patient = findPatientById(id);
        if (patient != nullptr) {
            cout << "Found Patient - ID: " << patient->id << ", Name: " << patient->name << ", Age: " << patient->age << endl;
        } else {
            cout << "Patient not found" << endl;
        }
    }

    void searchAppointment(int id) {
        Appointment* appointment = findAppointmentById(id);
        if (appointment != nullptr) {
            cout << "Found Appointment - ID: " << appointment->id << ", Patient ID: " << appointment->patientId << ", Date: " << appointment->date << endl;
        } else {
            cout << "Appointment not found" << endl;
        }
    }
};

int main() {
    HealthcareSystem system;
    system.addPatient(1, "John Doe", 30);
    system.addPatient(2, "Jane Smith", 25);
    system.displayPatients();
    
    system.addAppointment(1, 1, "2023-10-10");
    system.addAppointment(2, 2, "2023-10-11");
    system.displayAppointments();

    system.searchPatient(1);
    system.searchAppointment(1);

    system.updatePatient(1, "Johnathon Doe", 31);
    system.displayPatients();
    
    system.deleteAppointment(1);
    system.displayAppointments();

    return 0;
}