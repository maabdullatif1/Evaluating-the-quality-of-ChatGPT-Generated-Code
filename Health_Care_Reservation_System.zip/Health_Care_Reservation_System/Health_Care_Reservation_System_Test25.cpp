#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

struct Patient {
    int id;
    std::string name;
    int age;
};

struct Appointment {
    int id;
    int patientId;
    std::string date;
    std::string time;
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;
    int patientIdCounter;
    int appointmentIdCounter;

public:
    HealthCareSystem() : patientIdCounter(1), appointmentIdCounter(1) {}

    void addPatient(const std::string& name, int age) {
        Patient p = {patientIdCounter++, name, age};
        patients.push_back(p);
    }

    void deletePatient(int patientId) {
        patients.erase(std::remove_if(patients.begin(), patients.end(),
            [&](Patient& p) { return p.id == patientId; }), patients.end());
        appointments.erase(std::remove_if(appointments.begin(), appointments.end(),
            [&](Appointment& a) { return a.patientId == patientId; }), appointments.end());
    }

    void updatePatient(int patientId, const std::string& name, int age) {
        for (auto& p : patients) {
            if (p.id == patientId) {
                p.name = name;
                p.age = age;
            }
        }
    }

    void searchPatient(int patientId) {
        for (const auto& p : patients) {
            if (p.id == patientId) {
                std::cout << "Patient ID: " << p.id << ", Name: " << p.name << ", Age: " << p.age << std::endl;
                return;
            }
        }
        std::cout << "Patient not found." << std::endl;
    }

    void displayPatients() {
        for (const auto& p : patients) {
            std::cout << "Patient ID: " << p.id << ", Name: " << p.name << ", Age: " << p.age << std::endl;
        }
    }

    void addAppointment(int patientId, const std::string& date, const std::string& time) {
        Appointment a = {appointmentIdCounter++, patientId, date, time};
        appointments.push_back(a);
    }

    void deleteAppointment(int appointmentId) {
        appointments.erase(std::remove_if(appointments.begin(), appointments.end(),
            [&](Appointment& a) { return a.id == appointmentId; }), appointments.end());
    }

    void updateAppointment(int appointmentId, const std::string& date, const std::string& time) {
        for (auto& a : appointments) {
            if (a.id == appointmentId) {
                a.date = date;
                a.time = time;
            }
        }
    }

    void searchAppointment(int appointmentId) {
        for (const auto& a : appointments) {
            if (a.id == appointmentId) {
                std::cout << "Appointment ID: " << a.id << ", Patient ID: " << a.patientId
                          << ", Date: " << a.date << ", Time: " << a.time << std::endl;
                return;
            }
        }
        std::cout << "Appointment not found." << std::endl;
    }

    void displayAppointments() {
        for (const auto& a : appointments) {
            std::cout << "Appointment ID: " << a.id << ", Patient ID: " << a.patientId
                      << ", Date: " << a.date << ", Time: " << a.time << std::endl;
        }
    }
};

int main() {
    HealthCareSystem system;

    system.addPatient("Alice", 30);
    system.addPatient("Bob", 25);

    system.addAppointment(1, "2023-10-21", "14:00");
    system.addAppointment(2, "2023-10-22", "10:00");

    system.displayPatients();
    system.displayAppointments();

    system.updatePatient(1, "Alice Smith", 31);
    system.updateAppointment(1, "2023-10-23", "15:00");

    system.displayPatients();
    system.displayAppointments();

    system.searchPatient(2);
    system.searchAppointment(2);

    system.deletePatient(1);
    system.displayPatients();
    system.displayAppointments();

    return 0;
}