#include <iostream>
#include <string>

using namespace std;

const int MAX_PATIENTS = 100;
const int MAX_APPOINTMENTS = 100;

struct Patient {
    int id;
    string name;
    int age;
};

struct Appointment {
    int id;
    int patientId;
    string date;
    string time;
};

Patient patients[MAX_PATIENTS];
Appointment appointments[MAX_APPOINTMENTS];
int patientCount = 0;
int appointmentCount = 0;

void addPatient(){
    if(patientCount < MAX_PATIENTS){
        cout << "Enter Patient ID: ";
        cin >> patients[patientCount].id;
        cout << "Enter Patient Name: ";
        cin.ignore();
        getline(cin, patients[patientCount].name);
        cout << "Enter Patient Age: ";
        cin >> patients[patientCount].age;
        patientCount++;
    } else {
        cout << "Patient limit reached." << endl;
    }
}

void deletePatient() {
    int id;
    cout << "Enter Patient ID to delete: ";
    cin >> id;
    for (int i = 0; i < patientCount; ++i) {
        if (patients[i].id == id) {
            for (int j = i; j < patientCount - 1; ++j) {
                patients[j] = patients[j + 1];
            }
            patientCount--;
            cout << "Patient deleted." << endl;
            return;
        }
    }
    cout << "Patient not found." << endl;
}

void updatePatient() {
    int id;
    cout << "Enter Patient ID to update: ";
    cin >> id;
    for (int i = 0; i < patientCount; ++i) {
        if (patients[i].id == id) {
            cout << "Enter new Patient Name: ";
            cin.ignore();
            getline(cin, patients[i].name);
            cout << "Enter new Patient Age: ";
            cin >> patients[i].age;
            cout << "Patient updated." << endl;
            return;
        }
    }
    cout << "Patient not found." << endl;
}

void searchPatient() {
    int id;
    cout << "Enter Patient ID to search: ";
    cin >> id;
    for (int i = 0; i < patientCount; ++i) {
        if (patients[i].id == id) {
            cout << "Patient ID: " << patients[i].id << ", Name: " << patients[i].name << ", Age: " << patients[i].age << endl;
            return;
        }
    }
    cout << "Patient not found." << endl;
}

void displayPatients() {
    for (int i = 0; i < patientCount; ++i) {
        cout << "Patient ID: " << patients[i].id << ", Name: " << patients[i].name << ", Age: " << patients[i].age << endl;
    }
}

void addAppointment() {
    if(appointmentCount < MAX_APPOINTMENTS) {
        cout << "Enter Appointment ID: ";
        cin >> appointments[appointmentCount].id;
        cout << "Enter Patient ID: ";
        cin >> appointments[appointmentCount].patientId;
        cout << "Enter Date (YYYY-MM-DD): ";
        cin.ignore();
        getline(cin, appointments[appointmentCount].date);
        cout << "Enter Time (HH:MM): ";
        getline(cin, appointments[appointmentCount].time);
        appointmentCount++;
    } else {
        cout << "Appointment limit reached." << endl;
    }
}

void deleteAppointment() {
    int id;
    cout << "Enter Appointment ID to delete: ";
    cin >> id;
    for (int i = 0; i < appointmentCount; ++i) {
        if (appointments[i].id == id) {
            for (int j = i; j < appointmentCount - 1; ++j) {
                appointments[j] = appointments[j + 1];
            }
            appointmentCount--;
            cout << "Appointment deleted." << endl;
            return;
        }
    }
    cout << "Appointment not found." << endl;
}

void updateAppointment() {
    int id;
    cout << "Enter Appointment ID to update: ";
    cin >> id;
    for (int i = 0; i < appointmentCount; ++i) {
        if (appointments[i].id == id) {
            cout << "Enter new Patient ID: ";
            cin >> appointments[i].patientId;
            cout << "Enter new Date (YYYY-MM-DD): ";
            cin.ignore();
            getline(cin, appointments[i].date);
            cout << "Enter new Time (HH:MM): ";
            getline(cin, appointments[i].time);
            cout << "Appointment updated." << endl;
            return;
        }
    }
    cout << "Appointment not found." << endl;
}

void searchAppointment() {
    int id;
    cout << "Enter Appointment ID to search: ";
    cin >> id;
    for (int i = 0; i < appointmentCount; ++i) {
        if (appointments[i].id == id) {
            cout << "Appointment ID: " << appointments[i].id << ", Patient ID: " << appointments[i].patientId << ", Date: " << appointments[i].date << ", Time: " << appointments[i].time << endl;
            return;
        }
    }
    cout << "Appointment not found." << endl;
}

void displayAppointments() {
    for (int i = 0; i < appointmentCount; ++i) {
        cout << "Appointment ID: " << appointments[i].id << ", Patient ID: " << appointments[i].patientId << ", Date: " << appointments[i].date << ", Time: " << appointments[i].time << endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Patient\n2. Delete Patient\n3. Update Patient\n4. Search Patient\n5. Display All Patients\n";
        cout << "6. Add Appointment\n7. Delete Appointment\n8. Update Appointment\n9. Search Appointment\n10. Display All Appointments\n0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addPatient(); break;
            case 2: deletePatient(); break;
            case 3: updatePatient(); break;
            case 4: searchPatient(); break;
            case 5: displayPatients(); break;
            case 6: addAppointment(); break;
            case 7: deleteAppointment(); break;
            case 8: updateAppointment(); break;
            case 9: searchAppointment(); break;
            case 10: displayAppointments(); break;
            case 0: return 0;
            default: cout << "Invalid choice." << endl;
        }
    }
}