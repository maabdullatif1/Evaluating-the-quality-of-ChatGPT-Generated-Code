#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Appointment {
    int appointmentID;
    string date;
    string time;
    int patientID;
};

struct Patient {
    int patientID;
    string name;
    int age;
    string gender;
};

vector<Patient> patients;
vector<Appointment> appointments;

void addPatient(int id, string name, int age, string gender) {
    Patient newPatient = { id, name, age, gender };
    patients.push_back(newPatient);
}

void deletePatient(int id) {
    for (auto it = patients.begin(); it != patients.end(); ++it) {
        if (it->patientID == id) {
            patients.erase(it);
            break;
        }
    }
}

void updatePatient(int id, string name, int age, string gender) {
    for (auto &patient : patients) {
        if (patient.patientID == id) {
            patient.name = name;
            patient.age = age;
            patient.gender = gender;
            break;
        }
    }
}

Patient* searchPatient(int id) {
    for (auto &patient : patients) {
        if (patient.patientID == id) {
            return &patient;
        }
    }
    return nullptr;
}

void displayPatients() {
    for (const auto &patient : patients) {
        cout << "ID: " << patient.patientID << ", Name: " << patient.name
             << ", Age: " << patient.age << ", Gender: " << patient.gender << endl;
    }
}

void addAppointment(int appointmentID, string date, string time, int patientID) {
    Appointment newAppointment = { appointmentID, date, time, patientID };
    appointments.push_back(newAppointment);
}

void deleteAppointment(int appointmentID) {
    for (auto it = appointments.begin(); it != appointments.end(); ++it) {
        if (it->appointmentID == appointmentID) {
            appointments.erase(it);
            break;
        }
    }
}

void updateAppointment(int appointmentID, string date, string time, int patientID) {
    for (auto &appointment : appointments) {
        if (appointment.appointmentID == appointmentID) {
            appointment.date = date;
            appointment.time = time;
            appointment.patientID = patientID;
            break;
        }
    }
}

Appointment* searchAppointment(int appointmentID) {
    for (auto &appointment : appointments) {
        if (appointment.appointmentID == appointmentID) {
            return &appointment;
        }
    }
    return nullptr;
}

void displayAppointments() {
    for (const auto &appointment : appointments) {
        cout << "Appointment ID: " << appointment.appointmentID << ", Date: " << appointment.date
             << ", Time: " << appointment.time << ", Patient ID: " << appointment.patientID << endl;
    }
}

int main() {
    addPatient(1, "John Doe", 30, "Male");
    addPatient(2, "Jane Smith", 25, "Female");
    
    addAppointment(1, "2023-11-01", "09:00", 1);
    addAppointment(2, "2023-11-01", "10:00", 2);

    displayPatients();
    displayAppointments();

    updatePatient(1, "John Doe", 31, "Male");
    updateAppointment(1, "2023-11-02", "09:30", 1);

    displayPatients();
    displayAppointments();

    deletePatient(2);
    deleteAppointment(2);

    displayPatients();
    displayAppointments();

    return 0;
}