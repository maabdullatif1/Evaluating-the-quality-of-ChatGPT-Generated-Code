#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Appointment {
    int id;
    string date;
    string time;
    string doctor;
};

struct Patient {
    int id;
    string name;
    int age;
    vector<Appointment> appointments;
};

class HealthCareReservationSystem {
private:
    vector<Patient> patients;
    int patientCount = 0;
    int appointmentCount = 0;

    Patient* findPatientById(int id) {
        for (auto &patient : patients) {
            if (patient.id == id) return &patient;
        }
        return nullptr;
    }

    Appointment* findAppointmentById(Patient &patient, int id) {
        for (auto &appointment : patient.appointments) {
            if (appointment.id == id) return &appointment;
        }
        return nullptr;
    }

public:
    void addPatient(const string &name, int age) {
        Patient newPatient = {++patientCount, name, age, {}};
        patients.push_back(newPatient);
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                return;
            }
        }
    }

    void updatePatient(int id, const string &name, int age) {
        Patient* patient = findPatientById(id);
        if (patient) {
            patient->name = name;
            patient->age = age;
        }
    }

    Patient* searchPatient(int id) {
        return findPatientById(id);
    }

    void displayPatients() {
        for (const auto &patient : patients) {
            cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << endl;
            for (const auto &app : patient.appointments) {
                cout << "  Appointment ID: " << app.id << ", Date: " << app.date << ", Time: " << app.time << ", Doctor: " << app.doctor << endl;
            }
        }
    }

    void addAppointment(int patientId, const string &date, const string &time, const string &doctor) {
        Patient* patient = findPatientById(patientId);
        if (patient) {
            Appointment newAppointment = {++appointmentCount, date, time, doctor};
            patient->appointments.push_back(newAppointment);
        }
    }

    void deleteAppointment(int patientId, int appointmentId) {
        Patient* patient = findPatientById(patientId);
        if (patient) {
            for (auto it = patient->appointments.begin(); it != patient->appointments.end(); ++it) {
                if (it->id == appointmentId) {
                    patient->appointments.erase(it);
                    return;
                }
            }
        }
    }

    void updateAppointment(int patientId, int appointmentId, const string &date, const string &time, const string &doctor) {
        Patient* patient = findPatientById(patientId);
        if (patient) {
            Appointment* appointment = findAppointmentById(*patient, appointmentId);
            if (appointment) {
                appointment->date = date;
                appointment->time = time;
                appointment->doctor = doctor;
            }
        }
    }
};

int main() {
    HealthCareReservationSystem system;
    system.addPatient("John Doe", 30);
    system.addAppointment(1, "2023-11-20", "10:00", "Dr. Smith");
    system.displayPatients();
    return 0;
}