#include <iostream>
#include <vector>
#include <string>

class Patient {
public:
    int id;
    std::string name;
    int age;
};

class Appointment {
public:
    int id;
    int patientId;
    std::string date;
    std::string time;
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;
    int patientIdCounter = 1;
    int appointmentIdCounter = 1;

public:
    void addPatient(const std::string& name, int age) {
        patients.push_back({patientIdCounter++, name, age});
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, const std::string& name, int age) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (auto& patient : patients) {
            if (patient.id == id) return &patient;
        }
        return nullptr;
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            std::cout << "ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << "\n";
        }
    }

    void addAppointment(int patientId, const std::string& date, const std::string& time) {
        appointments.push_back({appointmentIdCounter++, patientId, date, time});
    }

    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->id == id) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int id, int patientId, const std::string& date, const std::string& time) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) {
                appointment.patientId = patientId;
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }

    Appointment* searchAppointment(int id) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) return &appointment;
        }
        return nullptr;
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            std::cout << "ID: " << appointment.id << ", Patient ID: " << appointment.patientId << ", Date: " << appointment.date << ", Time: " << appointment.time << "\n";
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("John Doe", 30);
    system.addPatient("Jane Smith", 40);
    
    system.displayPatients();
    
    system.addAppointment(1, "2023-12-01", "09:00");
    system.addAppointment(2, "2023-12-02", "10:00");
    
    system.displayAppointments();
    
    system.updatePatient(1, "Johnathan Doe", 31);
    system.updateAppointment(1, 1, "2023-12-01", "09:30");
    
    system.displayPatients();
    system.displayAppointments();
    
    system.deletePatient(2);
    system.deleteAppointment(2);
    
    system.displayPatients();
    system.displayAppointments();
    
    return 0;
}