#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Patient {
    int id;
    string name;
    int age;
    string ailment;
};

struct Appointment {
    int id;
    int patientId;
    string date;
    string time;
};

class HealthcareSystem {
public:
    void addPatient(int id, const string& name, int age, const string& ailment) {
        patients.push_back({id, name, age, ailment});
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, const string& name, int age, const string& ailment) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                patient.ailment = ailment;
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (auto& patient : patients) {
            if (patient.id == id) return &patient;
        }
        return nullptr;
    }

    void displayPatients() const {
        for (const auto& patient : patients) {
            cout << "ID: " << patient.id << ", Name: " << patient.name 
                 << ", Age: " << patient.age << ", Ailment: " << patient.ailment << endl;
        }
    }

    void addAppointment(int id, int patientId, const string& date, const string& time) {
        appointments.push_back({id, patientId, date, time});
    }

    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->id == id) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int id, const string& date, const string& time) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) {
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }

    Appointment* searchAppointment(int id) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) return &appointment;
        }
        return nullptr;
    }

    void displayAppointments() const {
        for (const auto& appointment : appointments) {
            cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId 
                 << ", Date: " << appointment.date << ", Time: " << appointment.time << endl;
        }
    }

private:
    vector<Patient> patients;
    vector<Appointment> appointments;
};

int main() {
    HealthcareSystem system;
    system.addPatient(1, "John Doe", 30, "Flu");
    system.addPatient(2, "Jane Smith", 25, "Cough");
    system.displayPatients();

    system.addAppointment(1, 1, "2023-10-12", "10:30");
    system.addAppointment(2, 2, "2023-10-12", "11:00");
    system.displayAppointments();

    system.updatePatient(1, "Johnny Doe", 31, "Severe Flu");
    system.displayPatients();
    
    system.deleteAppointment(1);
    system.displayAppointments();
    
    return 0;
}