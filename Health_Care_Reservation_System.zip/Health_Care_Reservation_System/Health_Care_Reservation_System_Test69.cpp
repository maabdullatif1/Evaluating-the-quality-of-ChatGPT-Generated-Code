#include <iostream>
#include <string>
using namespace std;

const int MAX_PATIENTS = 100;

struct Appointment {
    int appointmentId;
    int patientId;
    string date;
    string time;
};

struct Patient {
    int patientId;
    string name;
    int age;
    string contact;
    Appointment appointments[MAX_PATIENTS];
    int appointmentCount;
};

class HealthCareReservationSystem {
    Patient patients[MAX_PATIENTS];
    int patientCount;
    int nextAppointmentId;

public:
    HealthCareReservationSystem() : patientCount(0), nextAppointmentId(1) {}

    void addPatient(const string& name, int age, const string& contact) {
        if (patientCount < MAX_PATIENTS) {
            Patient& patient = patients[patientCount++];
            patient.patientId = patientCount;
            patient.name = name;
            patient.age = age;
            patient.contact = contact;
            patient.appointmentCount = 0;
        }
    }

    void deletePatient(int patientId) {
        for (int i = 0; i < patientCount; ++i) {
            if (patients[i].patientId == patientId) {
                for (int j = i; j < patientCount - 1; ++j) {
                    patients[j] = patients[j + 1];
                }
                --patientCount;
                break;
            }
        }
    }

    void updatePatient(int patientId, const string& name, int age, const string& contact) {
        for (int i = 0; i < patientCount; ++i) {
            if (patients[i].patientId == patientId) {
                patients[i].name = name;
                patients[i].age = age;
                patients[i].contact = contact;
                break;
            }
        }
    }

    Patient* searchPatient(int patientId) {
        for (int i = 0; i < patientCount; ++i) {
            if (patients[i].patientId == patientId) {
                return &patients[i];
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (int i = 0; i < patientCount; ++i) {
            cout << "Patient ID: " << patients[i].patientId << endl;
            cout << "Name: " << patients[i].name << endl;
            cout << "Age: " << patients[i].age << endl;
            cout << "Contact: " << patients[i].contact << endl;
            cout << "===========================" << endl;
        }
    }

    void addAppointment(int patientId, const string& date, const string& time) {
        Patient* patient = searchPatient(patientId);
        if (patient && patient->appointmentCount < MAX_PATIENTS) {
            Appointment& appointment = patient->appointments[patient->appointmentCount++];
            appointment.appointmentId = nextAppointmentId++;
            appointment.patientId = patientId;
            appointment.date = date;
            appointment.time = time;
        }
    }

    void deleteAppointment(int patientId, int appointmentId) {
        Patient* patient = searchPatient(patientId);
        if (patient) {
            for (int i = 0; i < patient->appointmentCount; ++i) {
                if (patient->appointments[i].appointmentId == appointmentId) {
                    for (int j = i; j < patient->appointmentCount - 1; ++j) {
                        patient->appointments[j] = patient->appointments[j + 1];
                    }
                    --patient->appointmentCount;
                    break;
                }
            }
        }
    }

    void updateAppointment(int patientId, int appointmentId, const string& date, const string& time) {
        Patient* patient = searchPatient(patientId);
        if (patient) {
            for (int i = 0; i < patient->appointmentCount; ++i) {
                if (patient->appointments[i].appointmentId == appointmentId) {
                    patient->appointments[i].date = date;
                    patient->appointments[i].time = time;
                    break;
                }
            }
        }
    }

    void displayAppointments(int patientId) {
        Patient* patient = searchPatient(patientId);
        if (patient) {
            for (int i = 0; i < patient->appointmentCount; ++i) {
                cout << "Appointment ID: " << patient->appointments[i].appointmentId << endl;
                cout << "Date: " << patient->appointments[i].date << endl;
                cout << "Time: " << patient->appointments[i].time << endl;
                cout << "===========================" << endl;
            }
        }
    }
};

int main() {
    HealthCareReservationSystem system;
    system.addPatient("John Doe", 30, "123-456-789");
    system.addPatient("Jane Smith", 25, "987-654-321");
    system.displayPatients();
    system.addAppointment(1, "2023-09-01", "10:00");
    system.displayAppointments(1);
    return 0;
}