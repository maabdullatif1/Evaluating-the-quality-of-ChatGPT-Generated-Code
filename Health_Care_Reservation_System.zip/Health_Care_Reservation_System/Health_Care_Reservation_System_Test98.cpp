#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Appointment {
    int id;
    string date;
    string time;
    string doctor;
};

struct Patient {
    int id;
    string name;
    string address;
    int age;
    vector<Appointment> appointments;
};

vector<Patient> patients;

int generatePatientId() {
    static int patientIdCounter = 1;
    return patientIdCounter++;
}

int generateAppointmentId() {
    static int appointmentIdCounter = 1;
    return appointmentIdCounter++;
}

Patient* findPatient(int id) {
    for (auto &patient : patients) {
        if (patient.id == id) return &patient;
    }
    return nullptr;
}

Appointment* findAppointment(Patient &patient, int id) {
    for (auto &appointment : patient.appointments) {
        if (appointment.id == id) return &appointment;
    }
    return nullptr;
}

void addPatient() {
    Patient patient;
    patient.id = generatePatientId();
    cout << "Enter Patient Name: ";
    cin >> patient.name;
    cout << "Enter Patient Address: ";
    cin >> patient.address;
    cout << "Enter Patient Age: ";
    cin >> patient.age;
    patients.push_back(patient);
}

void deletePatient() {
    int id;
    cout << "Enter Patient ID to delete: ";
    cin >> id;
    for (auto it = patients.begin(); it != patients.end(); ++it) {
        if (it->id == id) {
            patients.erase(it);
            cout << "Patient deleted." << endl;
            return;
        }
    }
    cout << "Patient not found." << endl;
}

void updatePatient() {
    int id;
    cout << "Enter Patient ID to update: ";
    cin >> id;
    Patient* patient = findPatient(id);
    if (patient) {
        cout << "Enter new name: ";
        cin >> patient->name;
        cout << "Enter new address: ";
        cin >> patient->address;
        cout << "Enter new age: ";
        cin >> patient->age;
    } else {
        cout << "Patient not found." << endl;
    }
}

void searchPatient() {
    int id;
    cout << "Enter Patient ID to search: ";
    cin >> id;
    Patient* patient = findPatient(id);
    if (patient) {
        cout << "Patient ID: " << patient->id << endl;
        cout << "Name: " << patient->name << endl;
        cout << "Address: " << patient->address << endl;
        cout << "Age: " << patient->age << endl;
    } else {
        cout << "Patient not found." << endl;
    }
}

void displayPatients() {
    for (const auto &patient : patients) {
        cout << "Patient ID: " << patient.id << endl;
        cout << "Name: " << patient.name << endl;
        cout << "Address: " << patient.address << endl;
        cout << "Age: " << patient.age << endl;
    }
}

void addAppointment() {
    int patientId;
    cout << "Enter Patient ID to add appointment for: ";
    cin >> patientId;
    Patient* patient = findPatient(patientId);
    if (patient) {
        Appointment appointment;
        appointment.id = generateAppointmentId();
        cout << "Enter Appointment Date: ";
        cin >> appointment.date;
        cout << "Enter Appointment Time: ";
        cin >> appointment.time;
        cout << "Enter Doctor Name: ";
        cin >> appointment.doctor;
        patient->appointments.push_back(appointment);
    } else {
        cout << "Patient not found." << endl;
    }
}

void deleteAppointment() {
    int patientId, appointmentId;
    cout << "Enter Patient ID to delete appointment for: ";
    cin >> patientId;
    Patient* patient = findPatient(patientId);
    if (patient) {
        cout << "Enter Appointment ID to delete: ";
        cin >> appointmentId;
        for (auto it = patient->appointments.begin(); it != patient->appointments.end(); ++it) {
            if (it->id == appointmentId) {
                patient->appointments.erase(it);
                cout << "Appointment deleted." << endl;
                return;
            }
        }
        cout << "Appointment not found." << endl;
    } else {
        cout << "Patient not found." << endl;
    }
}

void updateAppointment() {
    int patientId, appointmentId;
    cout << "Enter Patient ID for updating appointment: ";
    cin >> patientId;
    Patient* patient = findPatient(patientId);
    if (patient) {
        cout << "Enter Appointment ID to update: ";
        cin >> appointmentId;
        Appointment* appointment = findAppointment(*patient, appointmentId);
        if (appointment) {
            cout << "Enter new date: ";
            cin >> appointment->date;
            cout << "Enter new time: ";
            cin >> appointment->time;
            cout << "Enter new doctor: ";
            cin >> appointment->doctor;
        } else {
            cout << "Appointment not found." << endl;
        }
    } else {
        cout << "Patient not found." << endl;
    }
}

void searchAppointment() {
    int patientId, appointmentId;
    cout << "Enter Patient ID to search appointment: ";
    cin >> patientId;
    Patient* patient = findPatient(patientId);
    if (patient) {
        cout << "Enter Appointment ID to search: ";
        cin >> appointmentId;
        Appointment* appointment = findAppointment(*patient, appointmentId);
        if (appointment) {
            cout << "Appointment ID: " << appointment->id << endl;
            cout << "Date: " << appointment->date << endl;
            cout << "Time: " << appointment->time << endl;
            cout << "Doctor: " << appointment->doctor << endl;
        } else {
            cout << "Appointment not found." << endl;
        }
    } else {
        cout << "Patient not found." << endl;
    }
}

void displayAppointments() {
    int patientId;
    cout << "Enter Patient ID to display appointments: ";
    cin >> patientId;
    Patient* patient = findPatient(patientId);
    if (patient) {
        for (const auto &appointment : patient->appointments) {
            cout << "Appointment ID: " << appointment.id << endl;
            cout << "Date: " << appointment.date << endl;
            cout << "Time: " << appointment.time << endl;
            cout << "Doctor: " << appointment.doctor << endl;
        }
    } else {
        cout << "Patient not found." << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Patient" << endl;
        cout << "2. Delete Patient" << endl;
        cout << "3. Update Patient" << endl;
        cout << "4. Search Patient" << endl;
        cout << "5. Display Patients" << endl;
        cout << "6. Add Appointment" << endl;
        cout << "7. Delete Appointment" << endl;
        cout << "8. Update Appointment" << endl;
        cout << "9. Search Appointment" << endl;
        cout << "10. Display Appointments" << endl;
        cout << "11. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addPatient(); break;
            case 2: deletePatient(); break;
            case 3: updatePatient(); break;
            case 4: searchPatient(); break;
            case 5: displayPatients(); break;
            case 6: addAppointment(); break;
            case 7: deleteAppointment(); break;
            case 8: updateAppointment(); break;
            case 9: searchAppointment(); break;
            case 10: displayAppointments(); break;
            case 11: break;
            default: cout << "Invalid choice" << endl;
        }
    } while (choice != 11);
    return 0;
}