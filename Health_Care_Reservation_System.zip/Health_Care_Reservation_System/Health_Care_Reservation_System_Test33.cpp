#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Patient {
public:
    int id;
    string name;
    int age;
    string gender;

    Patient(int id, string name, int age, string gender)
        : id(id), name(name), age(age), gender(gender) {}
};

class Appointment {
public:
    int id;
    int patientId;
    string date;
    string time;
    
    Appointment(int id, int patientId, string date, string time)
        : id(id), patientId(patientId), date(date), time(time) {}
};

class HealthCareReservationSystem {
    vector<Patient> patients;
    vector<Appointment> appointments;
    int patientCounter = 0;
    int appointmentCounter = 0;
    
public:
    void addPatient(string name, int age, string gender) {
        patients.push_back(Patient(++patientCounter, name, age, gender));
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, string name, int age, string gender) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                patient.gender = gender;
            }
        }
    }

    void searchPatient(int id) {
        for (const auto& patient : patients) {
            if (patient.id == id) {
                cout << "Patient Found: ID-" << patient.id << ", Name-" << patient.name 
                     << ", Age-" << patient.age << ", Gender-" << patient.gender << endl;
                return;
            }
        }
        cout << "Patient not found." << endl;
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            cout << "ID: " << patient.id << ", Name: " << patient.name 
                 << ", Age: " << patient.age << ", Gender: " << patient.gender << endl;
        }
    }

    void addAppointment(int patientId, string date, string time) {
        appointments.push_back(Appointment(++appointmentCounter, patientId, date, time));
    }

    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->id == id) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int id, int patientId, string date, string time) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) {
                appointment.patientId = patientId;
                appointment.date = date;
                appointment.time = time;
            }
        }
    }

    void searchAppointment(int id) {
        for (const auto& appointment : appointments) {
            if (appointment.id == id) {
                cout << "Appointment Found: ID-" << appointment.id << ", PatientID-" << appointment.patientId 
                     << ", Date-" << appointment.date << ", Time-" << appointment.time << endl;
                return;
            }
        }
        cout << "Appointment not found." << endl;
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            cout << "ID: " << appointment.id << ", PatientID: " << appointment.patientId 
                 << ", Date: " << appointment.date << ", Time: " << appointment.time << endl;
        }
    }
};

int main() {
    HealthCareReservationSystem system;

    system.addPatient("John Doe", 30, "Male");
    system.addPatient("Jane Smith", 25, "Female");
    system.displayPatients();
    
    system.addAppointment(1, "2023-12-01", "10:00");
    system.addAppointment(2, "2023-12-02", "11:00");
    system.displayAppointments();
    
    return 0;
}