#include <iostream>
#include <vector>
#include <string>

struct Patient {
    int id;
    std::string name;
    std::string contact;
};

struct Appointment {
    int id;
    int patientId;
    std::string date;
    std::string time;
};

class HealthCareSystem {
public:
    void addPatient(int id, const std::string& name, const std::string& contact);
    void deletePatient(int id);
    void updatePatient(int id, const std::string& name, const std::string& contact);
    void searchPatient(int id);
    void displayPatients();

    void addAppointment(int id, int patientId, const std::string& date, const std::string& time);
    void deleteAppointment(int id);
    void updateAppointment(int id, int patientId, const std::string& date, const std::string& time);
    void searchAppointment(int id);
    void displayAppointments();

private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;

    auto findPatientById(int id);
    auto findAppointmentById(int id);
};

void HealthCareSystem::addPatient(int id, const std::string& name, const std::string& contact) {
    patients.push_back(Patient{id, name, contact});
}

void HealthCareSystem::deletePatient(int id) {
    auto it = findPatientById(id);
    if (it != patients.end()) {
        patients.erase(it);
    }
}

void HealthCareSystem::updatePatient(int id, const std::string& name, const std::string& contact) {
    auto it = findPatientById(id);
    if (it != patients.end()) {
        it->name = name;
        it->contact = contact;
    }
}

void HealthCareSystem::searchPatient(int id) {
    auto it = findPatientById(id);
    if (it != patients.end()) {
        std::cout << "Patient ID: " << it->id << ", Name: " << it->name << ", Contact: " << it->contact << "\n";
    } else {
        std::cout << "Patient not found.\n";
    }
}

void HealthCareSystem::displayPatients() {
    for (const auto& patient : patients) {
        std::cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Contact: " << patient.contact << "\n";
    }
}

void HealthCareSystem::addAppointment(int id, int patientId, const std::string& date, const std::string& time) {
    appointments.push_back(Appointment{id, patientId, date, time});
}

void HealthCareSystem::deleteAppointment(int id) {
    auto it = findAppointmentById(id);
    if (it != appointments.end()) {
        appointments.erase(it);
    }
}

void HealthCareSystem::updateAppointment(int id, int patientId, const std::string& date, const std::string& time) {
    auto it = findAppointmentById(id);
    if (it != appointments.end()) {
        it->patientId = patientId;
        it->date = date;
        it->time = time;
    }
}

void HealthCareSystem::searchAppointment(int id) {
    auto it = findAppointmentById(id);
    if (it != appointments.end()) {
        std::cout << "Appointment ID: " << it->id << ", Patient ID: " << it->patientId << ", Date: " << it->date << ", Time: " << it->time << "\n";
    } else {
        std::cout << "Appointment not found.\n";
    }
}

void HealthCareSystem::displayAppointments() {
    for (const auto& appointment : appointments) {
        std::cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId << ", Date: " << appointment.date << ", Time: " << appointment.time << "\n";
    }
}

auto HealthCareSystem::findPatientById(int id) {
    return std::find_if(patients.begin(), patients.end(), [id](const Patient& p) { return p.id == id; });
}

auto HealthCareSystem::findAppointmentById(int id) {
    return std::find_if(appointments.begin(), appointments.end(), [id](const Appointment& a) { return a.id == id; });
}

int main() {
    HealthCareSystem system;

    system.addPatient(1, "John Doe", "123456789");
    system.addPatient(2, "Jane Smith", "987654321");
    system.displayPatients();

    system.addAppointment(1, 1, "2023-01-01", "09:00");
    system.addAppointment(2, 2, "2023-01-02", "10:00");
    system.displayAppointments();

    system.updatePatient(1, "John Updated", "111222333");
    system.searchPatient(1);

    system.updateAppointment(1, 1, "2023-01-01", "11:00");
    system.searchAppointment(1);

    system.deletePatient(2);
    system.displayPatients();

    system.deleteAppointment(2);
    system.displayAppointments();

    return 0;
}