#include <iostream>
#include <string>
using namespace std;

struct Patient {
    int id;
    string name;
    int age;
    string ailment;
};

struct Appointment {
    int id;
    int patientId;
    string date;
    string time;
};

const int MAX_PATIENTS = 100;
const int MAX_APPOINTMENTS = 100;

Patient patients[MAX_PATIENTS];
int patientCount = 0;

Appointment appointments[MAX_APPOINTMENTS];
int appointmentCount = 0;

void addPatient() {
    if (patientCount < MAX_PATIENTS) {
        Patient p;
        cout << "Enter Patient ID: ";
        cin >> p.id;
        cout << "Enter Patient Name: ";
        cin >> p.name;
        cout << "Enter Patient Age: ";
        cin >> p.age;
        cout << "Enter Patient Ailment: ";
        cin >> p.ailment;
        patients[patientCount++] = p;
    } else {
        cout << "Patient list is full.\n";
    }
}

void deletePatient() {
    int id;
    cout << "Enter Patient ID to Delete: ";
    cin >> id;
    for (int i = 0; i < patientCount; i++) {
        if (patients[i].id == id) {
            for (int j = i; j < patientCount - 1; j++) {
                patients[j] = patients[j + 1];
            }
            patientCount--;
            cout << "Patient deleted.\n";
            return;
        }
    }
    cout << "Patient not found.\n";
}

void updatePatient() {
    int id;
    cout << "Enter Patient ID to Update: ";
    cin >> id;
    for (int i = 0; i < patientCount; i++) {
        if (patients[i].id == id) {
            cout << "Enter New Patient Name: ";
            cin >> patients[i].name;
            cout << "Enter New Patient Age: ";
            cin >> patients[i].age;
            cout << "Enter New Patient Ailment: ";
            cin >> patients[i].ailment;
            cout << "Patient updated.\n";
            return;
        }
    }
    cout << "Patient not found.\n";
}

void searchPatient() {
    int id;
    cout << "Enter Patient ID to Search: ";
    cin >> id;
    for (int i = 0; i < patientCount; i++) {
        if (patients[i].id == id) {
            cout << "Patient ID: " << patients[i].id << "\n";
            cout << "Name: " << patients[i].name << "\n";
            cout << "Age: " << patients[i].age << "\n";
            cout << "Ailment: " << patients[i].ailment << "\n";
            return;
        }
    }
    cout << "Patient not found.\n";
}

void displayPatients() {
    for (int i = 0; i < patientCount; i++) {
        cout << "Patient ID: " << patients[i].id << "\n";
        cout << "Name: " << patients[i].name << "\n";
        cout << "Age: " << patients[i].age << "\n";
        cout << "Ailment: " << patients[i].ailment << "\n";
        cout << "-------------------------\n";
    }
}

void addAppointment() {
    if (appointmentCount < MAX_APPOINTMENTS) {
        Appointment a;
        cout << "Enter Appointment ID: ";
        cin >> a.id;
        cout << "Enter Patient ID: ";
        cin >> a.patientId;
        cout << "Enter Appointment Date (YYYY-MM-DD): ";
        cin >> a.date;
        cout << "Enter Appointment Time (HH:MM): ";
        cin >> a.time;
        appointments[appointmentCount++] = a;
    } else {
        cout << "Appointment list is full.\n";
    }
}

void deleteAppointment() {
    int id;
    cout << "Enter Appointment ID to Delete: ";
    cin >> id;
    for (int i = 0; i < appointmentCount; i++) {
        if (appointments[i].id == id) {
            for (int j = i; j < appointmentCount - 1; j++) {
                appointments[j] = appointments[j + 1];
            }
            appointmentCount--;
            cout << "Appointment deleted.\n";
            return;
        }
    }
    cout << "Appointment not found.\n";
}

void updateAppointment() {
    int id;
    cout << "Enter Appointment ID to Update: ";
    cin >> id;
    for (int i = 0; i < appointmentCount; i++) {
        if (appointments[i].id == id) {
            cout << "Enter New Patient ID: ";
            cin >> appointments[i].patientId;
            cout << "Enter New Appointment Date (YYYY-MM-DD): ";
            cin >> appointments[i].date;
            cout << "Enter New Appointment Time (HH:MM): ";
            cin >> appointments[i].time;
            cout << "Appointment updated.\n";
            return;
        }
    }
    cout << "Appointment not found.\n";
}

void searchAppointment() {
    int id;
    cout << "Enter Appointment ID to Search: ";
    cin >> id;
    for (int i = 0; i < appointmentCount; i++) {
        if (appointments[i].id == id) {
            cout << "Appointment ID: " << appointments[i].id << "\n";
            cout << "Patient ID: " << appointments[i].patientId << "\n";
            cout << "Date: " << appointments[i].date << "\n";
            cout << "Time: " << appointments[i].time << "\n";
            return;
        }
    }
    cout << "Appointment not found.\n";
}

void displayAppointments() {
    for (int i = 0; i < appointmentCount; i++) {
        cout << "Appointment ID: " << appointments[i].id << "\n";
        cout << "Patient ID: " << appointments[i].patientId << "\n";
        cout << "Date: " << appointments[i].date << "\n";
        cout << "Time: " << appointments[i].time << "\n";
        cout << "-------------------------\n";
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Patient\n2. Delete Patient\n3. Update Patient\n4. Search Patient\n5. Display Patients\n";
        cout << "6. Add Appointment\n7. Delete Appointment\n8. Update Appointment\n9. Search Appointment\n10. Display Appointments\n0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addPatient(); break;
            case 2: deletePatient(); break;
            case 3: updatePatient(); break;
            case 4: searchPatient(); break;
            case 5: displayPatients(); break;
            case 6: addAppointment(); break;
            case 7: deleteAppointment(); break;
            case 8: updateAppointment(); break;
            case 9: searchAppointment(); break;
            case 10: displayAppointments(); break;
        }
    } while (choice != 0);
    return 0;
}