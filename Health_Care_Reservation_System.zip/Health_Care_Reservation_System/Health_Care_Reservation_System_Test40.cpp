#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Patient {
    int patientId;
    string name;
    int age;
    string gender;
};

struct Appointment {
    int appointmentId;
    int patientId;
    string date;
    string time;
    string doctor;
};

vector<Patient> patients;
vector<Appointment> appointments;

int findPatientIndexById(int patientId) {
    for (int i = 0; i < patients.size(); ++i) {
        if (patients[i].patientId == patientId) {
            return i;
        }
    }
    return -1;
}

int findAppointmentIndexById(int appointmentId) {
    for (int i = 0; i < appointments.size(); ++i) {
        if (appointments[i].appointmentId == appointmentId) {
            return i;
        }
    }
    return -1;
}

void addPatient(int patientId, string name, int age, string gender) {
    patients.push_back({patientId, name, age, gender});
}

void deletePatient(int patientId) {
    int index = findPatientIndexById(patientId);
    if (index != -1) {
        patients.erase(patients.begin() + index);
    }
}

void updatePatient(int patientId, string name, int age, string gender) {
    int index = findPatientIndexById(patientId);
    if (index != -1) {
        patients[index] = {patientId, name, age, gender};
    }
}

Patient* searchPatient(int patientId) {
    int index = findPatientIndexById(patientId);
    if (index != -1) {
        return &patients[index];
    }
    return nullptr;
}

void displayPatients() {
    for (const auto& patient : patients) {
        cout << "ID: " << patient.patientId 
             << ", Name: " << patient.name 
             << ", Age: " << patient.age 
             << ", Gender: " << patient.gender << endl;
    }
}

void addAppointment(int appointmentId, int patientId, string date, string time, string doctor) {
    appointments.push_back({appointmentId, patientId, date, time, doctor});
}

void deleteAppointment(int appointmentId) {
    int index = findAppointmentIndexById(appointmentId);
    if (index != -1) {
        appointments.erase(appointments.begin() + index);
    }
}

void updateAppointment(int appointmentId, int patientId, string date, string time, string doctor) {
    int index = findAppointmentIndexById(appointmentId);
    if (index != -1) {
        appointments[index] = {appointmentId, patientId, date, time, doctor};
    }
}

Appointment* searchAppointment(int appointmentId) {
    int index = findAppointmentIndexById(appointmentId);
    if (index != -1) {
        return &appointments[index];
    }
    return nullptr;
}

void displayAppointments() {
    for (const auto& appointment : appointments) {
        cout << "Appointment ID: " << appointment.appointmentId 
             << ", Patient ID: " << appointment.patientId 
             << ", Date: " << appointment.date 
             << ", Time: " << appointment.time 
             << ", Doctor: " << appointment.doctor << endl;
    }
}

int main() {
    addPatient(1, "Alice", 30, "Female");
    addPatient(2, "Bob", 25, "Male");
    
    addAppointment(1, 1, "2023-11-01", "10:00", "Dr. Smith");
    addAppointment(2, 2, "2023-11-02", "11:00", "Dr. Jones");
    
    displayPatients();
    displayAppointments();
    
    updatePatient(1, "Alice Wonderland", 31, "Female");

    cout << "After update:" << endl;
    displayPatients();
    
    deleteAppointment(2);
    
    cout << "After deleting appointment:" << endl;
    displayAppointments();
    
    return 0;
}