#include <iostream>
#include <vector>
#include <string>

struct Patient {
    int id;
    std::string name;
    int age;
};

struct Appointment {
    int id;
    int patient_id;
    std::string date;
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;

    int findPatientIndex(int id) {
        for (int i = 0; i < patients.size(); ++i) {
            if (patients[i].id == id) return i;
        }
        return -1;
    }

    int findAppointmentIndex(int id) {
        for (int i = 0; i < appointments.size(); ++i) {
            if (appointments[i].id == id) return i;
        }
        return -1;
    }

public:
    void addPatient(int id, const std::string &name, int age) {
        if (findPatientIndex(id) == -1) {
            patients.push_back({id, name, age});
        }
    }

    void deletePatient(int id) {
        int index = findPatientIndex(id);
        if (index != -1) {
            patients.erase(patients.begin() + index);
        }
    }

    void updatePatient(int id, const std::string &name, int age) {
        int index = findPatientIndex(id);
        if (index != -1) {
            patients[index] = {id, name, age};
        }
    }

    void searchPatient(int id) {
        int index = findPatientIndex(id);
        if (index != -1) {
            std::cout << "Patient found: " << patients[index].name << ", Age: " << patients[index].age << std::endl;
        } else {
            std::cout << "Patient not found." << std::endl;
        }
    }

    void displayPatients() {
        for (const auto &patient : patients) {
            std::cout << "ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << std::endl;
        }
    }

    void addAppointment(int id, int patient_id, const std::string &date) {
        if (findAppointmentIndex(id) == -1) {
            appointments.push_back({id, patient_id, date});
        }
    }

    void deleteAppointment(int id) {
        int index = findAppointmentIndex(id);
        if (index != -1) {
            appointments.erase(appointments.begin() + index);
        }
    }

    void updateAppointment(int id, int patient_id, const std::string &date) {
        int index = findAppointmentIndex(id);
        if (index != -1) {
            appointments[index] = {id, patient_id, date};
        }
    }

    void searchAppointment(int id) {
        int index = findAppointmentIndex(id);
        if (index != -1) {
            std::cout << "Appointment found for patient ID: " << appointments[index].patient_id << " on date " << appointments[index].date << std::endl;
        } else {
            std::cout << "Appointment not found." << std::endl;
        }
    }

    void displayAppointments() {
        for (const auto &appointment : appointments) {
            std::cout << "ID: " << appointment.id << ", Patient ID: " << appointment.patient_id << ", Date: " << appointment.date << std::endl;
        }
    }
};

int main() {
    HealthCareSystem system;

    system.addPatient(1, "John Doe", 30);
    system.addPatient(2, "Jane Smith", 25);

    system.displayPatients();

    system.addAppointment(1, 1, "2023-12-01");
    system.addAppointment(2, 2, "2023-12-02");

    system.displayAppointments();

    system.searchPatient(1);
    system.searchAppointment(1);

    system.updatePatient(1, "John Doe", 31);
    system.updateAppointment(1, 1, "2023-12-03");

    system.displayPatients();
    system.displayAppointments();

    system.deletePatient(2);
    system.deleteAppointment(2);

    system.displayPatients();
    system.displayAppointments();

    return 0;
}