#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Patient {
    int id;
    string name;
    int age;
};

struct Appointment {
    int id;
    int patient_id;
    string date;
};

class HealthCareSystem {
private:
    vector<Patient> patients;
    vector<Appointment> appointments;
    int patient_id_counter;
    int appointment_id_counter;

    Patient* findPatient(int id) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }

    Appointment* findAppointment(int id) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) {
                return &appointment;
            }
        }
        return nullptr;
    }

public:
    HealthCareSystem() : patient_id_counter(1), appointment_id_counter(1) {}

    void addPatient(string name, int age) {
        Patient patient = {patient_id_counter++, name, age};
        patients.push_back(patient);
    }

    void deletePatient(int id) {
        for (size_t i = 0; i < patients.size(); ++i) {
            if (patients[i].id == id) {
                patients.erase(patients.begin() + i);
                break;
            }
        }
    }

    void updatePatient(int id, string name, int age) {
        Patient* patient = findPatient(id);
        if (patient) {
            patient->name = name;
            patient->age = age;
        }
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            cout << "ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << endl;
        }
    }

    void addAppointment(int patient_id, string date) {
        if (findPatient(patient_id)) {
            Appointment appointment = {appointment_id_counter++, patient_id, date};
            appointments.push_back(appointment);
        }
    }

    void deleteAppointment(int id) {
        for (size_t i = 0; i < appointments.size(); ++i) {
            if (appointments[i].id == id) {
                appointments.erase(appointments.begin() + i);
                break;
            }
        }
    }

    void updateAppointment(int id, int patient_id, string date) {
        Appointment* appointment = findAppointment(id);
        if (appointment && findPatient(patient_id)) {
            appointment->patient_id = patient_id;
            appointment->date = date;
        }
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            cout << "Appointment ID: " << appointment.id
                 << ", Patient ID: " << appointment.patient_id
                 << ", Date: " << appointment.date << endl;
        }
    }

    void searchPatient(int id) {
        Patient* patient = findPatient(id);
        if (patient) {
            cout << "Patient found: ID: " << patient->id << ", Name: " << patient->name << ", Age: " << patient->age << endl;
        } else {
            cout << "Patient not found" << endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("Alice", 30);
    system.addPatient("Bob", 25);
    system.addAppointment(1, "2023-11-01");
    system.addAppointment(2, "2023-11-05");

    cout << "Patients:" << endl;
    system.displayPatients();
    cout << "\nAppointments:" << endl;
    system.displayAppointments();

    system.updatePatient(1, "Alice Johnson", 31);
    system.updateAppointment(1, 1, "2023-11-10");

    cout << "\nUpdated Patients:" << endl;
    system.displayPatients();
    cout << "\nUpdated Appointments:" << endl;
    system.displayAppointments();

    system.searchPatient(1);
    system.deleteAppointment(1);
    system.deletePatient(1);

    cout << "\nAfter Deletion:" << endl;
    system.displayPatients();
    system.displayAppointments();

    return 0;
}