#include <iostream>
#include <string>

struct Appointment {
    int id;
    std::string patient_name;
    std::string date;
    std::string time;
    Appointment* next;
};

struct Patient {
    int id;
    std::string name;
    int age;
    std::string gender;
    Patient* next;
    Appointment* appointments;
};

class HealthCareSystem {
private:
    Patient* patients;
    int patientCount;
    int appointmentCount;

    Patient* findPatient(int id) {
        Patient* current = patients;
        while (current != nullptr) {
            if (current->id == id) return current;
            current = current->next;
        }
        return nullptr;
    }

    Appointment* findAppointment(Patient* patient, int id) {
        if (!patient) return nullptr;
        Appointment* current = patient->appointments;
        while (current != nullptr) {
            if (current->id == id) return current;
            current = current->next;
        }
        return nullptr;
    }

public:
    HealthCareSystem() : patients(nullptr), patientCount(0), appointmentCount(0) {}

    void addPatient(const std::string& name, int age, const std::string& gender) {
        Patient* newPatient = new Patient{patientCount++, name, age, gender, patients, nullptr};
        patients = newPatient;
    }

    void deletePatient(int id) {
        Patient* current = patients;
        Patient* prev = nullptr;
        while (current != nullptr && current->id != id) {
            prev = current;
            current = current->next;
        }
        if (current == nullptr) return;
        if (prev != nullptr) prev->next = current->next;
        else patients = current->next;
        delete current;
    }

    void updatePatient(int id, const std::string& name, int age, const std::string& gender) {
        Patient* patient = findPatient(id);
        if (!patient) return;
        patient->name = name;
        patient->age = age;
        patient->gender = gender;
    }

    Patient* searchPatient(int id) {
        return findPatient(id);
    }

    void addAppointment(int patientId, const std::string& date, const std::string& time) {
        Patient* patient = findPatient(patientId);
        if (!patient) return;
        Appointment* newAppointment = new Appointment{appointmentCount++, patient->name, date, time, patient->appointments};
        patient->appointments = newAppointment;
    }

    void deleteAppointment(int patientId, int appointmentId) {
        Patient* patient = findPatient(patientId);
        if (!patient) return;
        Appointment* current = patient->appointments;
        Appointment* prev = nullptr;
        while (current != nullptr && current->id != appointmentId) {
            prev = current;
            current = current->next;
        }
        if (current == nullptr) return;
        if (prev != nullptr) prev->next = current->next;
        else patient->appointments = current->next;
        delete current;
    }

    Appointment* searchAppointment(int patientId, int appointmentId) {
        Patient* patient = findPatient(patientId);
        return findAppointment(patient, appointmentId);
    }

    void displayPatients() {
        Patient* current = patients;
        while (current != nullptr) {
            std::cout << "ID: " << current->id << ", Name: " << current->name 
                      << ", Age: " << current->age << ", Gender: " << current->gender << "\n";
            current = current->next;
        }
    }

    void displayAppointments(int patientId) {
        Patient* patient = findPatient(patientId);
        if (!patient) return;
        Appointment* current = patient->appointments;
        while (current != nullptr) {
            std::cout << "Appointment ID: " << current->id << ", Date: " << current->date 
                      << ", Time: " << current->time << "\n";
            current = current->next;
        }
    }
};

int main() {
    HealthCareSystem hcs;
    hcs.addPatient("John Doe", 30, "Male");
    hcs.addPatient("Jane Smith", 25, "Female");
    hcs.addAppointment(0, "2023-10-15", "10:00");
    hcs.addAppointment(0, "2023-10-16", "11:00");
    hcs.displayPatients();
    hcs.displayAppointments(0);
    hcs.updatePatient(0, "John Doe", 31, "Male");
    hcs.displayPatients();
    hcs.deleteAppointment(0, 0);
    hcs.displayAppointments(0);
    hcs.deletePatient(1);
    hcs.displayPatients();
    return 0;
}