#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Patient {
    int id;
    string name;
    int age;
    string gender;
};

struct Appointment {
    int id;
    int patientId;
    string date;
    string time;
    string doctor;
};

class HealthCareSystem {
private:
    vector<Patient> patients;
    vector<Appointment> appointments;
    int patientIdCounter = 1;
    int appointmentIdCounter = 1;

public:
    void addPatient(string name, int age, string gender) {
        Patient newPatient = {patientIdCounter++, name, age, gender};
        patients.push_back(newPatient);
    }

    void deletePatient(int id) {
        for (size_t i = 0; i < patients.size(); ++i) {
            if (patients[i].id == id) {
                patients.erase(patients.begin() + i);
                break;
            }
        }
    }

    void updatePatient(int id, string name, int age, string gender) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                patient.gender = gender;
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (const auto &patient : patients) {
            cout << "ID: " << patient.id << ", Name: " << patient.name
                 << ", Age: " << patient.age << ", Gender: " << patient.gender << endl;
        }
    }

    void addAppointment(int patientId, string date, string time, string doctor) {
        Appointment newAppointment = {appointmentIdCounter++, patientId, date, time, doctor};
        appointments.push_back(newAppointment);
    }

    void deleteAppointment(int id) {
        for (size_t i = 0; i < appointments.size(); ++i) {
            if (appointments[i].id == id) {
                appointments.erase(appointments.begin() + i);
                break;
            }
        }
    }

    void updateAppointment(int id, int patientId, string date, string time, string doctor) {
        for (auto &appointment : appointments) {
            if (appointment.id == id) {
                appointment.patientId = patientId;
                appointment.date = date;
                appointment.time = time;
                appointment.doctor = doctor;
                break;
            }
        }
    }

    Appointment* searchAppointment(int id) {
        for (auto &appointment : appointments) {
            if (appointment.id == id) {
                return &appointment;
            }
        }
        return nullptr;
    }

    void displayAppointments() {
        for (const auto &appointment : appointments) {
            cout << "ID: " << appointment.id << ", Patient ID: " << appointment.patientId
                 << ", Date: " << appointment.date << ", Time: " << appointment.time
                 << ", Doctor: " << appointment.doctor << endl;
        }
    }
};

int main() {
    HealthCareSystem hcs;
    hcs.addPatient("John Doe", 30, "Male");
    hcs.addPatient("Jane Smith", 25, "Female");
    hcs.addAppointment(1, "2023-04-01", "10:00", "Dr. Brown");
    hcs.addAppointment(2, "2023-04-01", "11:00", "Dr. White");
    hcs.displayPatients();
    hcs.displayAppointments();

    return 0;
}