#include <iostream>
#include <vector>
#include <string>

struct Patient {
    int id;
    std::string name;
    int age;
    std::string gender;
};

struct Appointment {
    int id;
    int patientId;
    std::string date;
    std::string time;
};

std::vector<Patient> patients;
std::vector<Appointment> appointments;

int generatePatientId() {
    return patients.empty() ? 1 : patients.back().id + 1;
}

int generateAppointmentId() {
    return appointments.empty() ? 1 : appointments.back().id + 1;
}

void addPatient() {
    Patient p;
    p.id = generatePatientId();
    std::cout << "Enter name: ";
    std::cin >> p.name;
    std::cout << "Enter age: ";
    std::cin >> p.age;
    std::cout << "Enter gender: ";
    std::cin >> p.gender;
    patients.push_back(p);
    std::cout << "Patient added.\n";
}

void deletePatient() {
    int id;
    std::cout << "Enter patient ID to delete: ";
    std::cin >> id;
    for (auto it = patients.begin(); it != patients.end(); ++it) {
        if (it->id == id) {
            patients.erase(it);
            std::cout << "Patient deleted.\n";
            return;
        }
    }
    std::cout << "Patient not found.\n";
}

void updatePatient() {
    int id;
    std::cout << "Enter patient ID to update: ";
    std::cin >> id;
    for (auto& patient : patients) {
        if (patient.id == id) {
            std::cout << "Enter new name: ";
            std::cin >> patient.name;
            std::cout << "Enter new age: ";
            std::cin >> patient.age;
            std::cout << "Enter new gender: ";
            std::cin >> patient.gender;
            std::cout << "Patient updated.\n";
            return;
        }
    }
    std::cout << "Patient not found.\n";
}

void searchPatient() {
    int id;
    std::cout << "Enter patient ID to search: ";
    std::cin >> id;
    for (const auto& patient : patients) {
        if (patient.id == id) {
            std::cout << "Patient Found: " << patient.id << ", " << patient.name << ", " << patient.age << ", " << patient.gender << "\n";
            return;
        }
    }
    std::cout << "Patient not found.\n";
}

void displayPatients() {
    if (patients.empty()) {
        std::cout << "No patients available.\n";
    }
    for (const auto& patient : patients) {
        std::cout << patient.id << ", " << patient.name << ", " << patient.age << ", " << patient.gender << "\n";
    }
}

void addAppointment() {
    Appointment a;
    a.id = generateAppointmentId();
    std::cout << "Enter patient ID: ";
    std::cin >> a.patientId;
    std::cout << "Enter date (YYYY-MM-DD): ";
    std::cin >> a.date;
    std::cout << "Enter time (HH:MM): ";
    std::cin >> a.time;
    appointments.push_back(a);
    std::cout << "Appointment added.\n";
}

void deleteAppointment() {
    int id;
    std::cout << "Enter appointment ID to delete: ";
    std::cin >> id;
    for (auto it = appointments.begin(); it != appointments.end(); ++it) {
        if (it->id == id) {
            appointments.erase(it);
            std::cout << "Appointment deleted.\n";
            return;
        }
    }
    std::cout << "Appointment not found.\n";
}

void updateAppointment() {
    int id;
    std::cout << "Enter appointment ID to update: ";
    std::cin >> id;
    for (auto& appointment : appointments) {
        if (appointment.id == id) {
            std::cout << "Enter new patient ID: ";
            std::cin >> appointment.patientId;
            std::cout << "Enter new date (YYYY-MM-DD): ";
            std::cin >> appointment.date;
            std::cout << "Enter new time (HH:MM): ";
            std::cin >> appointment.time;
            std::cout << "Appointment updated.\n";
            return;
        }
    }
    std::cout << "Appointment not found.\n";
}

void searchAppointment() {
    int id;
    std::cout << "Enter appointment ID to search: ";
    std::cin >> id;
    for (const auto& appointment : appointments) {
        if (appointment.id == id) {
            std::cout << "Appointment Found: " << appointment.id << ", Patient ID: " << appointment.patientId << ", " << appointment.date << ", " << appointment.time << "\n";
            return;
        }
    }
    std::cout << "Appointment not found.\n";
}

void displayAppointments() {
    if (appointments.empty()) {
        std::cout << "No appointments available.\n";
    }
    for (const auto& appointment : appointments) {
        std::cout << "ID: " << appointment.id << ", Patient ID: " << appointment.patientId << ", " << appointment.date << ", " << appointment.time << "\n";
    }
}

int main() {
    int choice;
    while (true) {
        std::cout << "1. Add Patient\n2. Delete Patient\n3. Update Patient\n4. Search Patient\n5. Display Patients\n"
                  << "6. Add Appointment\n7. Delete Appointment\n8. Update Appointment\n9. Search Appointment\n10. Display Appointments\n0. Exit\n";
        std::cin >> choice;
        switch (choice) {
            case 1: addPatient(); break;
            case 2: deletePatient(); break;
            case 3: updatePatient(); break;
            case 4: searchPatient(); break;
            case 5: displayPatients(); break;
            case 6: addAppointment(); break;
            case 7: deleteAppointment(); break;
            case 8: updateAppointment(); break;
            case 9: searchAppointment(); break;
            case 10: displayAppointments(); break;
            case 0: return 0;
            default: std::cout << "Invalid choice.\n"; break;
        }
    }
}