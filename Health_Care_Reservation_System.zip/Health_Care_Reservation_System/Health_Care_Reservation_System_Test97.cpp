#include <iostream>
#include <string>

using namespace std;

struct Patient {
    int id;
    string name;
    int age;
    string ailment;
};

struct Appointment {
    int id;
    int patientId;
    string date;
    string time;
};

Patient patients[100];
Appointment appointments[100];
int patientCount = 0;
int appointmentCount = 0;

void addPatient() {
    cout << "Enter patient ID: ";
    cin >> patients[patientCount].id;
    cout << "Enter patient name: ";
    cin >> patients[patientCount].name;
    cout << "Enter patient age: ";
    cin >> patients[patientCount].age;
    cout << "Enter patient ailment: ";
    cin >> patients[patientCount].ailment;
    patientCount++;
}

void deletePatient() {
    int id;
    cout << "Enter patient ID to delete: ";
    cin >> id;
    for (int i = 0; i < patientCount; i++) {
        if (patients[i].id == id) {
            for (int j = i; j < patientCount - 1; j++) {
                patients[j] = patients[j + 1];
            }
            patientCount--;
            break;
        }
    }
}

void updatePatient() {
    int id;
    cout << "Enter patient ID to update: ";
    cin >> id;
    for (int i = 0; i < patientCount; i++) {
        if (patients[i].id == id) {
            cout << "Enter new patient name: ";
            cin >> patients[i].name;
            cout << "Enter new patient age: ";
            cin >> patients[i].age;
            cout << "Enter new patient ailment: ";
            cin >> patients[i].ailment;
            break;
        }
    }
}

void searchPatient() {
    int id;
    cout << "Enter patient ID to search: ";
    cin >> id;
    for (int i = 0; i < patientCount; i++) {
        if (patients[i].id == id) {
            cout << "ID: " << patients[i].id << "\nName: " << patients[i].name << "\nAge: " << patients[i].age << "\nAilment: " << patients[i].ailment << endl;
            break;
        }
    }
}

void displayPatients() {
    for (int i = 0; i < patientCount; i++) {
        cout << "ID: " << patients[i].id << "\nName: " << patients[i].name << "\nAge: " << patients[i].age << "\nAilment: " << patients[i].ailment << endl;
    }
}

void addAppointment() {
    cout << "Enter appointment ID: ";
    cin >> appointments[appointmentCount].id;
    cout << "Enter patient ID: ";
    cin >> appointments[appointmentCount].patientId;
    cout << "Enter appointment date: ";
    cin >> appointments[appointmentCount].date;
    cout << "Enter appointment time: ";
    cin >> appointments[appointmentCount].time;
    appointmentCount++;
}

void deleteAppointment() {
    int id;
    cout << "Enter appointment ID to delete: ";
    cin >> id;
    for (int i = 0; i < appointmentCount; i++) {
        if (appointments[i].id == id) {
            for (int j = i; j < appointmentCount - 1; j++) {
                appointments[j] = appointments[j + 1];
            }
            appointmentCount--;
            break;
        }
    }
}

void updateAppointment() {
    int id;
    cout << "Enter appointment ID to update: ";
    cin >> id;
    for (int i = 0; i < appointmentCount; i++) {
        if (appointments[i].id == id) {
            cout << "Enter new patient ID: ";
            cin >> appointments[i].patientId;
            cout << "Enter new appointment date: ";
            cin >> appointments[i].date;
            cout << "Enter new appointment time: ";
            cin >> appointments[i].time;
            break;
        }
    }
}

void searchAppointment() {
    int id;
    cout << "Enter appointment ID to search: ";
    cin >> id;
    for (int i = 0; i < appointmentCount; i++) {
        if (appointments[i].id == id) {
            cout << "Appointment ID: " << appointments[i].id << "\nPatient ID: " << appointments[i].patientId << "\nDate: " << appointments[i].date << "\nTime: " << appointments[i].time << endl;
            break;
        }
    }
}

void displayAppointments() {
    for (int i = 0; i < appointmentCount; i++) {
        cout << "Appointment ID: " << appointments[i].id << "\nPatient ID: " << appointments[i].patientId << "\nDate: " << appointments[i].date << "\nTime: " << appointments[i].time << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Patient\n2. Delete Patient\n3. Update Patient\n4. Search Patient\n5. Display Patients\n6. Add Appointment\n7. Delete Appointment\n8. Update Appointment\n9. Search Appointment\n10. Display Appointments\n0. Exit\nEnter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addPatient(); break;
            case 2: deletePatient(); break;
            case 3: updatePatient(); break;
            case 4: searchPatient(); break;
            case 5: displayPatients(); break;
            case 6: addAppointment(); break;
            case 7: deleteAppointment(); break;
            case 8: updateAppointment(); break;
            case 9: searchAppointment(); break;
            case 10: displayAppointments(); break;
        }
    } while (choice != 0);
    return 0;
}