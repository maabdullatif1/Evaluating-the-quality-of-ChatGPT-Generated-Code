#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Appointment {
public:
    string time;
    string doctor;
    Appointment(string t, string d) : time(t), doctor(d) {}
};

class Patient {
public:
    string name;
    int age;
    vector<Appointment> appointments;

    Patient(string n, int a) : name(n), age(a) {}

    void addAppointment(string time, string doctor) {
        appointments.push_back(Appointment(time, doctor));
    }

    void updateAppointment(int index, string time, string doctor) {
        if (index >= 0 && index < appointments.size()) {
            appointments[index].time = time;
            appointments[index].doctor = doctor;
        }
    }

    void deleteAppointment(int index) {
        if (index >= 0 && index < appointments.size()) {
            appointments.erase(appointments.begin() + index);
        }
    }

    void displayAppointments() {
        for (int i = 0; i < appointments.size(); ++i) {
            cout << "Appointment " << i + 1 << ": Time - " << appointments[i].time << ", Doctor - " << appointments[i].doctor << endl;
        }
    }
};

class HealthCareSystem {
public:
    vector<Patient> patients;

    void addPatient(string name, int age) {
        patients.push_back(Patient(name, age));
    }

    void deletePatient(string name) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->name == name) {
                patients.erase(it);
                break;
            }
        }
    }

    Patient* searchPatient(string name) {
        for (auto& patient : patients) {
            if (patient.name == name) {
                return &patient;
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            cout << "Patient: " << patient.name << ", Age: " << patient.age << endl;
            patient.displayAppointments();
        }
    }
};

int main() {
    HealthCareSystem system;

    system.addPatient("John Doe", 30);
    system.addPatient("Jane Smith", 25);

    Patient* patient = system.searchPatient("John Doe");
    if (patient) {
        patient->addAppointment("10:00 AM", "Dr. Brown");
        patient->addAppointment("12:00 PM", "Dr. White");
    }

    system.displayPatients();

    if (patient) {
        patient->updateAppointment(0, "11:00 AM", "Dr. Brown");
    }

    system.displayPatients();

    if (patient) {
        patient->deleteAppointment(1);
    }

    system.displayPatients();

    system.deletePatient("Jane Smith");

    system.displayPatients();

    return 0;
}