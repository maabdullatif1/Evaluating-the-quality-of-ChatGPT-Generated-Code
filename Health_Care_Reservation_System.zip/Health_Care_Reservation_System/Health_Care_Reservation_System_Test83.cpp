#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Patient {
    int id;
    string name;
    int age;
    string condition;
};

struct Appointment {
    int id;
    int patientId;
    string date;
    string time;
};

class HealthCareSystem {
private:
    vector<Patient> patients;
    vector<Appointment> appointments;
    int patientCounter = 0;
    int appointmentCounter = 0;

public:
    void addPatient(const string& name, int age, const string& condition) {
        Patient newPatient = {++patientCounter, name, age, condition};
        patients.push_back(newPatient);
        cout << "Patient added with ID: " << newPatient.id << endl;
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                cout << "Patient with ID: " << id << " deleted" << endl;
                return;
            }
        }
        cout << "Patient not found" << endl;
    }

    void updatePatient(int id, const string& name, int age, const string& condition) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                patient.condition = condition;
                cout << "Patient with ID: " << id << " updated" << endl;
                return;
            }
        }
        cout << "Patient not found" << endl;
    }

    void searchPatient(int id) {
        for (const auto& patient : patients) {
            if (patient.id == id) {
                cout << "Patient ID: " << patient.id
                     << ", Name: " << patient.name
                     << ", Age: " << patient.age
                     << ", Condition: " << patient.condition << endl;
                return;
            }
        }
        cout << "Patient not found" << endl;
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            cout << "ID: " << patient.id
                 << ", Name: " << patient.name
                 << ", Age: " << patient.age
                 << ", Condition: " << patient.condition << endl;
        }
    }

    void addAppointment(int patientId, const string& date, const string& time) {
        Appointment newAppointment = {++appointmentCounter, patientId, date, time};
        appointments.push_back(newAppointment);
        cout << "Appointment added with ID: " << newAppointment.id << endl;
    }

    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->id == id) {
                appointments.erase(it);
                cout << "Appointment with ID: " << id << " deleted" << endl;
                return;
            }
        }
        cout << "Appointment not found" << endl;
    }

    void updateAppointment(int id, int patientId, const string& date, const string& time) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) {
                appointment.patientId = patientId;
                appointment.date = date;
                appointment.time = time;
                cout << "Appointment with ID: " << id << " updated" << endl;
                return;
            }
        }
        cout << "Appointment not found" << endl;
    }

    void searchAppointment(int id) {
        for (const auto& appointment : appointments) {
            if (appointment.id == id) {
                cout << "Appointment ID: " << appointment.id
                     << ", Patient ID: " << appointment.patientId
                     << ", Date: " << appointment.date
                     << ", Time: " << appointment.time << endl;
                return;
            }
        }
        cout << "Appointment not found" << endl;
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            cout << "ID: " << appointment.id
                 << ", Patient ID: " << appointment.patientId
                 << ", Date: " << appointment.date
                 << ", Time: " << appointment.time << endl;
        }
    }
};

int main() {
    HealthCareSystem hcs;
    hcs.addPatient("John Doe", 30, "Flu");
    hcs.addPatient("Jane Smith", 25, "Cold");
    hcs.displayPatients();
    hcs.addAppointment(1, "2023-05-20", "14:00");
    hcs.addAppointment(2, "2023-05-21", "10:00");
    hcs.displayAppointments();
    hcs.searchPatient(1);
    hcs.updatePatient(1, "John Doe", 31, "Recovered");
    hcs.displayPatients();
    hcs.deletePatient(1);
    hcs.displayPatients();
    hcs.searchAppointment(1);
    hcs.updateAppointment(2, 2, "2023-05-22", "11:00");
    hcs.displayAppointments();
    hcs.deleteAppointment(2);
    hcs.displayAppointments();
    return 0;
}