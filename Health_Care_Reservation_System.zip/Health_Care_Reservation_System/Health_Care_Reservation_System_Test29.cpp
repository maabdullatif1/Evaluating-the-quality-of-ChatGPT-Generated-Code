#include <iostream>
#include <string>
using namespace std;

struct Patient {
    int id;
    string name;
    int age;
};

struct Appointment {
    int id;
    int patientId;
    string date;
    string time;
};

class HealthCareSystem {
    Patient patients[100];
    Appointment appointments[100];
    int patientCount;
    int appointmentCount;

public:
    HealthCareSystem() : patientCount(0), appointmentCount(0) {}

    void addPatient(int id, string name, int age) {
        patients[patientCount].id = id;
        patients[patientCount].name = name;
        patients[patientCount].age = age;
        patientCount++;
    }

    void deletePatient(int id) {
        for (int i = 0; i < patientCount; ++i) {
            if (patients[i].id == id) {
                for (int j = i; j < patientCount - 1; ++j) {
                    patients[j] = patients[j + 1];
                }
                patientCount--;
                break;
            }
        }
    }

    void updatePatient(int id, string name, int age) {
        for (int i = 0; i < patientCount; ++i) {
            if (patients[i].id == id) {
                patients[i].name = name;
                patients[i].age = age;
                break;
            }
        }
    }

    void searchPatient(int id) {
        for (int i = 0; i < patientCount; ++i) {
            if (patients[i].id == id) {
                cout << "Patient ID: " << patients[i].id << ", Name: " << patients[i].name << ", Age: " << patients[i].age << endl;
                return;
            }
        }
        cout << "Patient not found!" << endl;
    }

    void displayPatients() {
        for (int i = 0; i < patientCount; ++i) {
            cout << "Patient ID: " << patients[i].id << ", Name: " << patients[i].name << ", Age: " << patients[i].age << endl;
        }
    }

    void addAppointment(int id, int patientId, string date, string time) {
        appointments[appointmentCount].id = id;
        appointments[appointmentCount].patientId = patientId;
        appointments[appointmentCount].date = date;
        appointments[appointmentCount].time = time;
        appointmentCount++;
    }

    void deleteAppointment(int id) {
        for (int i = 0; i < appointmentCount; ++i) {
            if (appointments[i].id == id) {
                for (int j = i; j < appointmentCount - 1; ++j) {
                    appointments[j] = appointments[j + 1];
                }
                appointmentCount--;
                break;
            }
        }
    }

    void updateAppointment(int id, string date, string time) {
        for (int i = 0; i < appointmentCount; ++i) {
            if (appointments[i].id == id) {
                appointments[i].date = date;
                appointments[i].time = time;
                break;
            }
        }
    }

    void searchAppointment(int id) {
        for (int i = 0; i < appointmentCount; ++i) {
            if (appointments[i].id == id) {
                cout << "Appointment ID: " << appointments[i].id << ", Patient ID: " << appointments[i].patientId 
                     << ", Date: " << appointments[i].date << ", Time: " << appointments[i].time << endl;
                return;
            }
        }
        cout << "Appointment not found!" << endl;
    }

    void displayAppointments() {
        for (int i = 0; i < appointmentCount; ++i) {
            cout << "Appointment ID: " << appointments[i].id << ", Patient ID: " << appointments[i].patientId 
                 << ", Date: " << appointments[i].date << ", Time: " << appointments[i].time << endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient(1, "John Doe", 30);
    system.addPatient(2, "Jane Smith", 25);
    system.displayPatients();
    system.addAppointment(1, 1, "2023-10-10", "10:00");
    system.addAppointment(2, 2, "2023-10-11", "11:00");
    system.displayAppointments();
    return 0;
}