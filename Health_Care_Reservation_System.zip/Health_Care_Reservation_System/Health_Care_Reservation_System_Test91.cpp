#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Patient {
public:
    int id;
    string name;
    int age;
    string address;
    
    Patient(int id, string name, int age, string address)
        : id(id), name(name), age(age), address(address) {}
};

class Appointment {
public:
    int patientId;
    string date;
    string time;
    
    Appointment(int patientId, string date, string time)
        : patientId(patientId), date(date), time(time) {}
};

vector<Patient> patients;
vector<Appointment> appointments;

void addPatient(int id, string name, int age, string address) {
    patients.push_back(Patient(id, name, age, address));
}

void deletePatient(int id) {
    for(auto it = patients.begin(); it != patients.end(); ++it) {
        if(it->id == id) {
            patients.erase(it);
            break;
        }
    }
}

void updatePatient(int id, string name, int age, string address) {
    for(auto &patient : patients) {
        if(patient.id == id) {
            patient.name = name;
            patient.age = age;
            patient.address = address;
            break;
        }
    }
}

Patient* searchPatient(int id) {
    for(auto &patient : patients) {
        if(patient.id == id) {
            return &patient;
        }
    }
    return nullptr;
}

void displayPatients() {
    for(const auto &patient : patients) {
        cout << "ID: " << patient.id 
             << ", Name: " << patient.name 
             << ", Age: " << patient.age 
             << ", Address: " << patient.address << endl;
    }
}

void addAppointment(int patientId, string date, string time) {
    appointments.push_back(Appointment(patientId, date, time));
}

void deleteAppointment(int patientId) {
    for(auto it = appointments.begin(); it != appointments.end(); ++it) {
        if(it->patientId == patientId) {
            appointments.erase(it);
            break;
        }
    }
}

Appointment* searchAppointment(int patientId) {
    for(auto &appointment : appointments) {
        if(appointment.patientId == patientId) return &appointment;
    }
    return nullptr;
}

void displayAppointments() {
    for(const auto &appointment : appointments) {
        cout << "Patient ID: " << appointment.patientId 
             << ", Date: " << appointment.date 
             << ", Time: " << appointment.time << endl;
    }
}

int main() {
    addPatient(1, "John Doe", 30, "123 Elm Street");
    addAppointment(1, "2023-10-01", "14:00");

    displayPatients();
    displayAppointments();

    return 0;
}