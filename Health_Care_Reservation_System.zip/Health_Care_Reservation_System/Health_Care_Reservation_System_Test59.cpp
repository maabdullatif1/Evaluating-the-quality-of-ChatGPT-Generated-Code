#include <iostream>
#include <string>
using namespace std;

const int MAX_RECORDS = 100;

struct Patient {
    int id;
    string name;
    int age;
    string ailment;
};

struct Appointment {
    int appointmentId;
    int patientId;
    string date;
    string time;
    string doctor;
};

Patient patients[MAX_RECORDS];
Appointment appointments[MAX_RECORDS];
int patientCount = 0;
int appointmentCount = 0;

void addPatient(int id, string name, int age, string ailment) {
    if (patientCount < MAX_RECORDS) {
        patients[patientCount].id = id;
        patients[patientCount].name = name;
        patients[patientCount].age = age;
        patients[patientCount].ailment = ailment;
        patientCount++;
    }
}

void deletePatient(int id) {
    for (int i = 0; i < patientCount; ++i) {
        if (patients[i].id == id) {
            patients[i] = patients[patientCount - 1];
            patientCount--;
            break;
        }
    }
}

void updatePatient(int id, string name, int age, string ailment) {
    for (int i = 0; i < patientCount; ++i) {
        if (patients[i].id == id) {
            patients[i].name = name;
            patients[i].age = age;
            patients[i].ailment = ailment;
            break;
        }
    }
}

Patient* searchPatient(int id) {
    for (int i = 0; i < patientCount; ++i) {
        if (patients[i].id == id) {
            return &patients[i];
        }
    }
    return nullptr;
}

void displayPatients() {
    for (int i = 0; i < patientCount; ++i) {
        cout << "ID: " << patients[i].id << ", Name: " << patients[i].name
             << ", Age: " << patients[i].age << ", Ailment: " << patients[i].ailment << endl;
    }
}

void addAppointment(int appointmentId, int patientId, string date, string time, string doctor) {
    if (appointmentCount < MAX_RECORDS) {
        appointments[appointmentCount].appointmentId = appointmentId;
        appointments[appointmentCount].patientId = patientId;
        appointments[appointmentCount].date = date;
        appointments[appointmentCount].time = time;
        appointments[appointmentCount].doctor = doctor;
        appointmentCount++;
    }
}

void deleteAppointment(int appointmentId) {
    for (int i = 0; i < appointmentCount; ++i) {
        if (appointments[i].appointmentId == appointmentId) {
            appointments[i] = appointments[appointmentCount - 1];
            appointmentCount--;
            break;
        }
    }
}

void updateAppointment(int appointmentId, int patientId, string date, string time, string doctor) {
    for (int i = 0; i < appointmentCount; ++i) {
        if (appointments[i].appointmentId == appointmentId) {
            appointments[i].patientId = patientId;
            appointments[i].date = date;
            appointments[i].time = time;
            appointments[i].doctor = doctor;
            break;
        }
    }
}

Appointment* searchAppointment(int appointmentId) {
    for (int i = 0; i < appointmentCount; ++i) {
        if (appointments[i].appointmentId == appointmentId) {
            return &appointments[i];
        }
    }
    return nullptr;
}

void displayAppointments() {
    for (int i = 0; i < appointmentCount; ++i) {
        cout << "Appointment ID: " << appointments[i].appointmentId
             << ", Patient ID: " << appointments[i].patientId
             << ", Date: " << appointments[i].date
             << ", Time: " << appointments[i].time
             << ", Doctor: " << appointments[i].doctor << endl;
    }
}

int main() {
    addPatient(1, "John Doe", 30, "Flu");
    addPatient(2, "Jane Smith", 25, "Cough");
    addAppointment(1, 1, "2023-12-01", "10:00", "Dr. Brown");
    displayPatients();
    displayAppointments();
    return 0;
}