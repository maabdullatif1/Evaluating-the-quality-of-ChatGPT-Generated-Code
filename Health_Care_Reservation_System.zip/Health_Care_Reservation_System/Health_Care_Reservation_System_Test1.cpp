#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

struct Patient {
    int id;
    string name;
    int age;
    string contact;
};

struct Appointment {
    int id;
    int patientId;
    string date;
    string time;
};

vector<Patient> patients;
vector<Appointment> appointments;

int generatePatientId() {
    return patients.empty() ? 1 : patients.back().id + 1;
}

int generateAppointmentId() {
    return appointments.empty() ? 1 : appointments.back().id + 1;
}

void addPatient() {
    Patient patient;
    patient.id = generatePatientId();
    cout << "Enter patient name: ";
    cin >> patient.name;
    cout << "Enter patient age: ";
    cin >> patient.age;
    cout << "Enter patient contact: ";
    cin >> patient.contact;
    patients.push_back(patient);
}

void deletePatient() {
    int id;
    cout << "Enter patient ID to delete: ";
    cin >> id;
    patients.erase(remove_if(patients.begin(), patients.end(), [id](Patient &p) { return p.id == id; }), patients.end());
}

void updatePatient() {
    int id;
    cout << "Enter patient ID to update: ";
    cin >> id;
    for (auto &p : patients) {
        if (p.id == id) {
            cout << "Enter new name: ";
            cin >> p.name;
            cout << "Enter new age: ";
            cin >> p.age;
            cout << "Enter new contact: ";
            cin >> p.contact;
            break;
        }
    }
}

void searchPatient() {
    int id;
    cout << "Enter patient ID to search: ";
    cin >> id;
    for (const auto &p : patients) {
        if (p.id == id) {
            cout << "ID: " << p.id << " Name: " << p.name << " Age: " << p.age << " Contact: " << p.contact << endl;
            return;
        }
    }
    cout << "Patient not found." << endl;
}

void displayPatients() {
    for (const auto &p : patients) {
        cout << "ID: " << p.id << " Name: " << p.name << " Age: " << p.age << " Contact: " << p.contact << endl;
    }
}

void addAppointment() {
    Appointment appointment;
    appointment.id = generateAppointmentId();
    cout << "Enter patient ID for appointment: ";
    cin >> appointment.patientId;
    cout << "Enter appointment date (YYYY-MM-DD): ";
    cin >> appointment.date;
    cout << "Enter appointment time (HH:MM): ";
    cin >> appointment.time;
    appointments.push_back(appointment);
}

void deleteAppointment() {
    int id;
    cout << "Enter appointment ID to delete: ";
    cin >> id;
    appointments.erase(remove_if(appointments.begin(), appointments.end(), [id](Appointment &a) { return a.id == id; }), appointments.end());
}

void updateAppointment() {
    int id;
    cout << "Enter appointment ID to update: ";
    cin >> id;
    for (auto &a : appointments) {
        if (a.id == id) {
            cout << "Enter new patient ID: ";
            cin >> a.patientId;
            cout << "Enter new date (YYYY-MM-DD): ";
            cin >> a.date;
            cout << "Enter new time (HH:MM): ";
            cin >> a.time;
            break;
        }
    }
}

void searchAppointment() {
    int id;
    cout << "Enter appointment ID to search: ";
    cin >> id;
    for (const auto &a : appointments) {
        if (a.id == id) {
            cout << "Appointment ID: " << a.id << " Patient ID: " << a.patientId << " Date: " << a.date << " Time: " << a.time << endl;
            return;
        }
    }
    cout << "Appointment not found." << endl;
}

void displayAppointments() {
    for (const auto &a : appointments) {
        cout << "Appointment ID: " << a.id << " Patient ID: " << a.patientId << " Date: " << a.date << " Time: " << a.time << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Patient" << endl;
        cout << "2. Delete Patient" << endl;
        cout << "3. Update Patient" << endl;
        cout << "4. Search Patient" << endl;
        cout << "5. Display Patients" << endl;
        cout << "6. Add Appointment" << endl;
        cout << "7. Delete Appointment" << endl;
        cout << "8. Update Appointment" << endl;
        cout << "9. Search Appointment" << endl;
        cout << "10. Display Appointments" << endl;
        cout << "11. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addPatient(); break;
            case 2: deletePatient(); break;
            case 3: updatePatient(); break;
            case 4: searchPatient(); break;
            case 5: displayPatients(); break;
            case 6: addAppointment(); break;
            case 7: deleteAppointment(); break;
            case 8: updateAppointment(); break;
            case 9: searchAppointment(); break;
            case 10: displayAppointments(); break;
            case 11: cout << "Exiting..." << endl; break;
            default: cout << "Invalid choice" << endl;
        }
    } while (choice != 11);
    return 0;
}