#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Patient {
public:
    int id;
    string name;
    int age;

    Patient(int id, string name, int age) : id(id), name(name), age(age) {}
};

class Appointment {
public:
    int patientId;
    string date;
    string time;
    string doctorName;

    Appointment(int patientId, string date, string time, string doctorName) 
        : patientId(patientId), date(date), time(time), doctorName(doctorName) {}
};

class HealthcareSystem {
    vector<Patient> patients;
    vector<Appointment> appointments;

public:
    void addPatient(int id, string name, int age) {
        patients.push_back(Patient(id, name, age));
    }
    
    void deletePatient(int id) {
        for(auto it = patients.begin(); it != patients.end(); ++it) {
            if(it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }
    
    void updatePatient(int id, string name, int age) {
        for(auto &patient : patients) {
            if(patient.id == id) {
                patient.name = name;
                patient.age = age;
            }
        }
    }
    
    void searchPatient(int id) {
        for(const auto &patient : patients) {
            if(patient.id == id) {
                cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << endl;
                return;
            }
        }
        cout << "Patient not found" << endl;
    }
    
    void displayPatients() {
        for(const auto &patient : patients) {
            cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << endl;
        }
    }
    
    void addAppointment(int patientId, string date, string time, string doctorName) {
        appointments.push_back(Appointment(patientId, date, time, doctorName));
    }
    
    void deleteAppointment(int patientId, string date) {
        for(auto it = appointments.begin(); it != appointments.end(); ++it) {
            if(it->patientId == patientId && it->date == date) {
                appointments.erase(it);
                break;
            }
        }
    }
    
    void updateAppointment(int patientId, string date, string time, string doctorName) {
        for(auto &appointment : appointments) {
            if(appointment.patientId == patientId && appointment.date == date) {
                appointment.time = time;
                appointment.doctorName = doctorName;
            }
        }
    }
    
    void searchAppointment(int patientId) {
        for(const auto &appointment : appointments) {
            if(appointment.patientId == patientId) {
                cout << "Patient ID: " << appointment.patientId << ", Date: " << appointment.date 
                     << ", Time: " << appointment.time << ", Doctor: " << appointment.doctorName << endl;
                return;
            }
        }
        cout << "Appointment not found" << endl;
    }
    
    void displayAppointments() {
        for(const auto &appointment : appointments) {
            cout << "Patient ID: " << appointment.patientId << ", Date: " << appointment.date 
                 << ", Time: " << appointment.time << ", Doctor: " << appointment.doctorName << endl;
        }
    }
};

int main() {
    HealthcareSystem system;
    system.addPatient(1, "John Doe", 30);
    system.addPatient(2, "Jane Smith", 25);
    system.addAppointment(1, "2023-10-22", "10:00", "Dr. Brown");

    system.displayPatients();
    system.displayAppointments();

    system.updatePatient(1, "Johnathan Doe", 31);
    system.updateAppointment(1, "2023-10-22", "11:00", "Dr. Green");
    
    system.searchPatient(1);
    system.searchAppointment(1);

    system.deletePatient(2);
    system.deleteAppointment(1, "2023-10-22");

    system.displayPatients();
    system.displayAppointments();
    
    return 0;
}