#include <iostream>
#include <vector>
#include <string>

class Appointment {
public:
    std::string patientName;
    std::string date;
    std::string time;
    
    Appointment(std::string pname, std::string date, std::string time)
        : patientName(pname), date(date), time(time) {}
};

class Patient {
public:
    std::string name;
    int age;
    std::string id;
    std::vector<Appointment> appointments;
    
    Patient(std::string name, int age, std::string id)
        : name(name), age(age), id(id) {}
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;

public:
    void addPatient(std::string name, int age, std::string id) {
        patients.push_back(Patient(name, age, id));
    }

    void deletePatient(std::string id) {
        for (size_t i = 0; i < patients.size(); ++i) {
            if (patients[i].id == id) {
                patients.erase(patients.begin() + i);
                break;
            }
        }
    }

    void updatePatient(std::string id, std::string newName, int newAge) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                patient.name = newName;
                patient.age = newAge;
                break;
            }
        }
    }

    Patient* searchPatient(std::string id) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            std::cout << "ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << std::endl;
            for (const auto& appointment : patient.appointments) {
                std::cout << "    Appointment: " << appointment.date << " at " << appointment.time << std::endl;
            }
        }
    }

    void addAppointment(std::string patientId, std::string date, std::string time) {
        Patient* patient = searchPatient(patientId);
        if (patient) {
            patient->appointments.push_back(Appointment(patient->name, date, time));
        }
    }

    void deleteAppointment(std::string patientId, std::string date, std::string time) {
        Patient* patient = searchPatient(patientId);
        if (patient) {
            for (size_t i = 0; i < patient->appointments.size(); ++i) {
                if (patient->appointments[i].date == date && patient->appointments[i].time == time) {
                    patient->appointments.erase(patient->appointments.begin() + i);
                    break;
                }
            }
        }
    }
};

int main() {
    HealthCareSystem system;

    system.addPatient("Alice Johnson", 30, "P001");
    system.addPatient("Bob Smith", 45, "P002");

    system.addAppointment("P001", "2023-10-15", "09:00");
    system.addAppointment("P002", "2023-10-16", "10:30");

    system.displayPatients();

    system.updatePatient("P001", "Alice Brown", 31);
    system.deleteAppointment("P002", "2023-10-16", "10:30");
    system.deletePatient("P002");

    system.displayPatients();

    return 0;
}