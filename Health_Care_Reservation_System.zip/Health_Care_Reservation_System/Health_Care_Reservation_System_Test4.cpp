#include <iostream>
#include <vector>
#include <string>

struct Patient {
    int id;
    std::string name;
    int age;
    std::string contact;
};

struct Appointment {
    int id;
    int patientId;
    std::string date;
    std::string time;
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;
    int patientIdCounter;
    int appointmentIdCounter;
    
public:
    HealthCareSystem() : patientIdCounter(1), appointmentIdCounter(1) {}

    void addPatient(const std::string& name, int age, const std::string& contact) {
        patients.push_back({patientIdCounter++, name, age, contact});
    }

    void deletePatient(int id) {
        for(auto it = patients.begin(); it != patients.end(); ++it) {
            if(it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, const std::string& name, int age, const std::string& contact) {
        for(auto &patient : patients) {
            if(patient.id == id) {
                patient.name = name;
                patient.age = age;
                patient.contact = contact;
                break;
            }
        }
    }

    void searchPatient(int id) {
        for(const auto &patient : patients) {
            if(patient.id == id) {
                std::cout << "Patient ID: " << patient.id << ", Name: " << patient.name 
                          << ", Age: " << patient.age << ", Contact: " << patient.contact << std::endl;
                          return;
            }
        }
        std::cout << "Patient not found." << std::endl;
    }

    void displayPatients() {
        for(const auto &patient : patients) {
            std::cout << "Patient ID: " << patient.id << ", Name: " << patient.name 
                      << ", Age: " << patient.age << ", Contact: " << patient.contact << std::endl;
        }
    }

    void addAppointment(int patientId, const std::string& date, const std::string& time) {
        appointments.push_back({appointmentIdCounter++, patientId, date, time});
    }

    void deleteAppointment(int id) {
        for(auto it = appointments.begin(); it != appointments.end(); ++it) {
            if(it->id == id) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int id, int patientId, const std::string& date, const std::string& time) {
        for(auto &appointment : appointments) {
            if(appointment.id == id) {
                appointment.patientId = patientId;
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }

    void searchAppointment(int id) {
        for(const auto &appointment : appointments) {
            if(appointment.id == id) {
                std::cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId 
                          << ", Date: " << appointment.date << ", Time: " << appointment.time << std::endl;
                          return;
            }
        }
        std::cout << "Appointment not found." << std::endl;
    }

    void displayAppointments() {
        for(const auto &appointment : appointments) {
            std::cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId 
                      << ", Date: " << appointment.date << ", Time: " << appointment.time << std::endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("John Doe", 30, "123-456-7890");
    system.addPatient("Jane Smith", 25, "098-765-4321");
    system.displayPatients();
    system.addAppointment(1, "2023-10-12", "10:00 AM");
    system.displayAppointments();
    system.searchPatient(1);
    system.searchAppointment(1);
    system.updatePatient(1, "John Doe", 31, "123-456-7899");
    system.updateAppointment(1, 1, "2023-10-15", "11:00 AM");
    system.displayPatients();
    system.displayAppointments();
    system.deletePatient(2);
    system.deleteAppointment(1);
    system.displayPatients();
    system.displayAppointments();
    return 0;
}