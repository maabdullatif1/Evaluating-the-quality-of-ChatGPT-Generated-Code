#include <iostream>
#include <string>
using namespace std;

struct Appointment {
    int id;
    string time;
    string doctorName;
};

struct Patient {
    int id;
    string name;
    int age;
    Appointment appointment;
};

class HealthCareReservationSystem {
private:
    Patient patients[100];
    int patientCount;

public:
    HealthCareReservationSystem() : patientCount(0) {}

    void addPatient(int id, const string& name, int age, int appId, const string& time, const string& doctor) {
        if (patientCount < 100) {
            patients[patientCount].id = id;
            patients[patientCount].name = name;
            patients[patientCount].age = age;
            patients[patientCount].appointment = {appId, time, doctor};
            patientCount++;
        }
    }

    void deletePatient(int id) {
        for (int i = 0; i < patientCount; ++i) {
            if (patients[i].id == id) {
                for (int j = i; j < patientCount - 1; ++j) {
                    patients[j] = patients[j + 1];
                }
                patientCount--;
                break;
            }
        }
    }

    void updatePatient(int id, const string& name, int age, int appId, const string& time, const string& doctor) {
        for (int i = 0; i < patientCount; ++i) {
            if (patients[i].id == id) {
                patients[i].name = name;
                patients[i].age = age;
                patients[i].appointment = {appId, time, doctor};
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (int i = 0; i < patientCount; ++i) {
            if (patients[i].id == id) {
                return &patients[i];
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (int i = 0; i < patientCount; ++i) {
            cout << "Patient ID: " << patients[i].id << endl;
            cout << "Name: " << patients[i].name << endl;
            cout << "Age: " << patients[i].age << endl;
            cout << "Appointment ID: " << patients[i].appointment.id << endl;
            cout << "Appointment Time: " << patients[i].appointment.time << endl;
            cout << "Doctor: " << patients[i].appointment.doctorName << endl << endl;
        }
    }
};

int main() {
    HealthCareReservationSystem system;
    
    system.addPatient(1, "John Doe", 30, 101, "10:00 AM", "Dr. Smith");
    system.addPatient(2, "Jane Doe", 25, 102, "11:00 AM", "Dr. Brown");

    system.displayPatients();

    system.updatePatient(1, "John Smith", 31, 101, "10:30 AM", "Dr. Clark");
    system.displayPatients();

    system.deletePatient(1);
    system.displayPatients();

    return 0;
}