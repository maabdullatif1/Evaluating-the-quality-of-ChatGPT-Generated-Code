#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Patient {
    int id;
    string name;
    int age;
    string gender;
};

struct Appointment {
    int id;
    int patientId;
    string doctorName;
    string date;
    string time;
};

class HealthCareSystem {
    vector<Patient> patients;
    vector<Appointment> appointments;
    int patientIdCounter;
    int appointmentIdCounter;
    
public:
    HealthCareSystem() : patientIdCounter(1), appointmentIdCounter(1) {}

    void addPatient(string name, int age, string gender) {
        patients.push_back({patientIdCounter++, name, age, gender});
    }

    void deletePatient(int patientId) {
        for(auto it = patients.begin(); it != patients.end(); ++it) {
            if(it->id == patientId) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int patientId, string name, int age, string gender) {
        for(auto& patient : patients) {
            if(patient.id == patientId) {
                patient.name = name;
                patient.age = age;
                patient.gender = gender;
                break;
            }
        }
    }

    Patient* searchPatient(int patientId) {
        for(auto& patient : patients) {
            if(patient.id == patientId) {
                return &patient;
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for(auto& patient : patients) {
            cout << "ID: " << patient.id << ", Name: " << patient.name 
                 << ", Age: " << patient.age << ", Gender: " << patient.gender << endl;
        }
    }

    void addAppointment(int patientId, string doctorName, string date, string time) {
        appointments.push_back({appointmentIdCounter++, patientId, doctorName, date, time});
    }

    void deleteAppointment(int appointmentId) {
        for(auto it = appointments.begin(); it != appointments.end(); ++it) {
            if(it->id == appointmentId) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int appointmentId, int patientId, string doctorName, string date, string time) {
        for(auto& appointment : appointments) {
            if(appointment.id == appointmentId) {
                appointment.patientId = patientId;
                appointment.doctorName = doctorName;
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }

    Appointment* searchAppointment(int appointmentId) {
        for(auto& appointment : appointments) {
            if(appointment.id == appointmentId) {
                return &appointment;
            }
        }
        return nullptr;
    }

    void displayAppointments() {
        for(auto& appointment : appointments) {
            cout << "ID: " << appointment.id << ", Patient ID: " << appointment.patientId 
                 << ", Doctor: " << appointment.doctorName << ", Date: " << appointment.date 
                 << ", Time: " << appointment.time << endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("John Doe", 30, "Male");
    system.addPatient("Jane Smith", 25, "Female");
    system.displayPatients();

    system.addAppointment(1, "Dr. Brown", "2023-11-15", "10:30 AM");
    system.addAppointment(2, "Dr. Green", "2023-11-16", "11:00 AM");
    system.displayAppointments();

    system.updatePatient(1, "Johnny Doe", 31, "Male");
    system.displayPatients();

    Patient* patient = system.searchPatient(1);
    if(patient != nullptr) {
        cout << "Found patient: " << patient->name << endl;
    }

    Appointment* appointment = system.searchAppointment(1);
    if(appointment != nullptr) {
        cout << "Found appointment with Doctor: " << appointment->doctorName << endl;
    }

    system.deletePatient(2);
    system.displayPatients();

    system.deleteAppointment(1);
    system.displayAppointments();

    return 0;
}