#include <iostream>
#include <vector>
#include <string>

class Patient {
public:
    int id;
    std::string name;
    int age;

    Patient(int pid, std::string pname, int page) : id(pid), name(pname), age(page) {}
};

class Appointment {
public:
    int id;
    int patientId;
    std::string date;
    std::string time;

    Appointment(int aid, int pid, std::string adate, std::string atime) 
    : id(aid), patientId(pid), date(adate), time(atime) {}
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;

    Patient* findPatientById(int id) {
        for (auto &patient : patients) {
            if (patient.id == id) return &patient;
        }
        return nullptr;
    }

    Appointment* findAppointmentById(int id) {
        for (auto &appointment : appointments) {
            if (appointment.id == id) return &appointment;
        }
        return nullptr;
    }
    
public:
    void addPatient(int id, std::string name, int age) {
        patients.push_back(Patient(id, name, age));
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, std::string name, int age) {
        Patient* patient = findPatientById(id);
        if (patient) {
            patient->name = name;
            patient->age = age;
        }
    }

    void searchPatient(int id) {
        Patient* patient = findPatientById(id);
        if (patient) {
            std::cout << "Patient Found: " << patient->id << ", " << patient->name << ", " << patient->age << "\n";
        } else {
            std::cout << "Patient not found\n";
        }
    }

    void displayPatients() {
        for (const auto &patient : patients) {
            std::cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << "\n";
        }
    }

    void addAppointment(int id, int patientId, std::string date, std::string time) {
        appointments.push_back(Appointment(id, patientId, date, time));
    }

    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->id == id) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int id, int patientId, std::string date, std::string time) {
        Appointment* appointment = findAppointmentById(id);
        if (appointment) {
            appointment->patientId = patientId;
            appointment->date = date;
            appointment->time = time;
        }
    }

    void searchAppointment(int id) {
        Appointment* appointment = findAppointmentById(id);
        if (appointment) {
            std::cout << "Appointment Found: " << appointment->id << ", Patient ID: " << appointment->patientId 
                      << ", Date: " << appointment->date << ", Time: " << appointment->time << "\n";
        } else {
            std::cout << "Appointment not found\n";
        }
    }

    void displayAppointments() {
        for (const auto &appointment : appointments) {
            std::cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId 
                      << ", Date: " << appointment.date << ", Time: " << appointment.time << "\n";
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient(1, "John Doe", 30);
    system.addPatient(2, "Jane Smith", 25);

    system.addAppointment(1, 1, "2023-10-01", "10:00");
    system.addAppointment(2, 2, "2023-10-02", "11:00");

    system.displayPatients();
    system.displayAppointments();

    system.searchPatient(1);
    system.searchAppointment(2);

    system.updatePatient(1, "John Wick", 35);
    system.updateAppointment(1, 1, "2023-10-03", "09:00");

    system.displayPatients();
    system.displayAppointments();

    system.deletePatient(2);
    system.deleteAppointment(2);

    system.displayPatients();
    system.displayAppointments();

    return 0;
}