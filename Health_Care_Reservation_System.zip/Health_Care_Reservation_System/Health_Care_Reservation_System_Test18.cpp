#include <iostream>
#include <vector>
#include <string>

struct Patient {
    int id;
    std::string name;
    int age;
    std::string condition;
};

struct Appointment {
    int appointmentId;
    int patientId;
    std::string date;
    std::string time;
};

class HealthCareReservationSystem {
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;
    
public:
    void addPatient(int id, const std::string& name, int age, const std::string& condition) {
        patients.push_back({id, name, age, condition});
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, const std::string& name, int age, const std::string& condition) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                patient.condition = condition;
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            std::cout << "ID: " << patient.id << ", Name: " << patient.name 
                      << ", Age: " << patient.age << ", Condition: " << patient.condition << "\n";
        }
    }

    void addAppointment(int appointmentId, int patientId, const std::string& date, const std::string& time) {
        appointments.push_back({appointmentId, patientId, date, time});
    }

    void deleteAppointment(int appointmentId) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->appointmentId == appointmentId) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int appointmentId, int patientId, const std::string& date, const std::string& time) {
        for (auto& appointment : appointments) {
            if (appointment.appointmentId == appointmentId) {
                appointment.patientId = patientId;
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }

    Appointment* searchAppointment(int appointmentId) {
        for (auto& appointment : appointments) {
            if (appointment.appointmentId == appointmentId) {
                return &appointment;
            }
        }
        return nullptr;
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            std::cout << "Appointment ID: " << appointment.appointmentId << ", Patient ID: " << appointment.patientId 
                      << ", Date: " << appointment.date << ", Time: " << appointment.time << "\n";
        }
    }
};

int main() {
    HealthCareReservationSystem system;
    system.addPatient(1, "John Doe", 30, "Flu");
    system.addPatient(2, "Jane Smith", 25, "Cough");
    system.displayPatients();
    
    system.addAppointment(101, 1, "2023-11-01", "10:00");
    system.addAppointment(102, 2, "2023-11-02", "11:00");
    system.displayAppointments();

    system.updatePatient(1, "John Doe", 31, "Chronic Flu");
    system.updateAppointment(101, 1, "2023-11-03", "09:00");
    system.displayPatients();
    system.displayAppointments();

    system.deletePatient(2);
    system.deleteAppointment(102);
    system.displayPatients();
    system.displayAppointments();

    return 0;
}