#include <iostream>
#include <string>

using namespace std;

struct Patient {
    int id;
    string name;
    int age;
    string ailment;
};

struct Appointment {
    int id;
    int patientId;
    string doctorName;
    string date;
    string time;
};

Patient patients[100];
Appointment appointments[100];
int patientCount = 0;
int appointmentCount = 0;

void addPatient() {
    Patient p;
    cout << "Enter Patient ID, Name, Age, Ailment: ";
    cin >> p.id >> p.name >> p.age >> p.ailment;
    patients[patientCount++] = p;
}

void deletePatient() {
    int id;
    cout << "Enter Patient ID to delete: ";
    cin >> id;
    for (int i = 0; i < patientCount; i++) {
        if (patients[i].id == id) {
            for (int j = i; j < patientCount - 1; j++)
                patients[j] = patients[j + 1];
            patientCount--;
            break;
        }
    }
}

void updatePatient() {
    int id;
    cout << "Enter Patient ID to update: ";
    cin >> id;
    for (int i = 0; i < patientCount; i++) {
        if (patients[i].id == id) {
            cout << "Enter new Name, Age, Ailment: ";
            cin >> patients[i].name >> patients[i].age >> patients[i].ailment;
            break;
        }
    }
}

void searchPatient() {
    int id;
    cout << "Enter Patient ID to search: ";
    cin >> id;
    for (int i = 0; i < patientCount; i++) {
        if (patients[i].id == id) {
            cout << "Patient ID: " << patients[i].id << ", Name: " << patients[i].name << ", Age: " << patients[i].age << ", Ailment: " << patients[i].ailment << endl;
            return;
        }
    }
    cout << "Patient not found" << endl;
}

void displayPatients() {
    for (int i = 0; i < patientCount; i++) {
        cout << "Patient ID: " << patients[i].id << ", Name: " << patients[i].name << ", Age: " << patients[i].age << ", Ailment: " << patients[i].ailment << endl;
    }
}

void addAppointment() {
    Appointment a;
    cout << "Enter Appointment ID, Patient ID, Doctor Name, Date, Time: ";
    cin >> a.id >> a.patientId >> a.doctorName >> a.date >> a.time;
    appointments[appointmentCount++] = a;
}

void deleteAppointment() {
    int id;
    cout << "Enter Appointment ID to delete: ";
    cin >> id;
    for (int i = 0; i < appointmentCount; i++) {
        if (appointments[i].id == id) {
            for (int j = i; j < appointmentCount - 1; j++)
                appointments[j] = appointments[j + 1];
            appointmentCount--;
            break;
        }
    }
}

void updateAppointment() {
    int id;
    cout << "Enter Appointment ID to update: ";
    cin >> id;
    for (int i = 0; i < appointmentCount; i++) {
        if (appointments[i].id == id) {
            cout << "Enter new Patient ID, Doctor Name, Date, Time: ";
            cin >> appointments[i].patientId >> appointments[i].doctorName >> appointments[i].date >> appointments[i].time;
            break;
        }
    }
}

void searchAppointment() {
    int id;
    cout << "Enter Appointment ID to search: ";
    cin >> id;
    for (int i = 0; i < appointmentCount; i++) {
        if (appointments[i].id == id) {
            cout << "Appointment ID: " << appointments[i].id << ", Patient ID: " << appointments[i].patientId << ", Doctor: " << appointments[i].doctorName << ", Date: " << appointments[i].date << ", Time: " << appointments[i].time << endl;
            return;
        }
    }
    cout << "Appointment not found" << endl;
}

void displayAppointments() {
    for (int i = 0; i < appointmentCount; i++) {
        cout << "Appointment ID: " << appointments[i].id << ", Patient ID: " << appointments[i].patientId << ", Doctor: " << appointments[i].doctorName << ", Date: " << appointments[i].date << ", Time: " << appointments[i].time << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Patient\n2. Delete Patient\n3. Update Patient\n4. Search Patient\n5. Display Patients\n";
        cout << "6. Add Appointment\n7. Delete Appointment\n8. Update Appointment\n9. Search Appointment\n10. Display Appointments\n0. Exit\n";
        cin >> choice;
        switch (choice) {
        case 1: addPatient(); break;
        case 2: deletePatient(); break;
        case 3: updatePatient(); break;
        case 4: searchPatient(); break;
        case 5: displayPatients(); break;
        case 6: addAppointment(); break;
        case 7: deleteAppointment(); break;
        case 8: updateAppointment(); break;
        case 9: searchAppointment(); break;
        case 10: displayAppointments(); break;
        }
    } while (choice != 0);
    return 0;
}