#include <iostream>
#include <string>

struct Patient {
    int id;
    std::string name;
    std::string condition;
};

struct Appointment {
    int id;
    int patientId;
    std::string date;
    std::string time;
};

class HealthCareReservationSystem {
    Patient patients[100];
    Appointment appointments[100];
    int patientCount;
    int appointmentCount;

public:
    HealthCareReservationSystem() : patientCount(0), appointmentCount(0) {}

    void addPatient(int id, const std::string& name, const std::string& condition) {
        if (patientCount < 100) {
            patients[patientCount++] = { id, name, condition };
        }
    }

    void deletePatient(int id) {
        for (int i = 0; i < patientCount; ++i) {
            if (patients[i].id == id) {
                for (int j = i; j < patientCount - 1; ++j) {
                    patients[j] = patients[j + 1];
                }
                --patientCount;
                break;
            }
        }
    }

    void updatePatient(int id, const std::string& name, const std::string& condition) {
        for (int i = 0; i < patientCount; ++i) {
            if (patients[i].id == id) {
                patients[i].name = name;
                patients[i].condition = condition;
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (int i = 0; i < patientCount; ++i) {
            if (patients[i].id == id) {
                return &patients[i];
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (int i = 0; i < patientCount; ++i) {
            std::cout << "ID: " << patients[i].id << ", Name: " << patients[i].name
                      << ", Condition: " << patients[i].condition << std::endl;
        }
    }

    void addAppointment(int id, int patientId, const std::string& date, const std::string& time) {
        if (appointmentCount < 100) {
            appointments[appointmentCount++] = { id, patientId, date, time };
        }
    }

    void deleteAppointment(int id) {
        for (int i = 0; i < appointmentCount; ++i) {
            if (appointments[i].id == id) {
                for (int j = i; j < appointmentCount - 1; ++j) {
                    appointments[j] = appointments[j + 1];
                }
                --appointmentCount;
                break;
            }
        }
    }

    void updateAppointment(int id, const std::string& date, const std::string& time) {
        for (int i = 0; i < appointmentCount; ++i) {
            if (appointments[i].id == id) {
                appointments[i].date = date;
                appointments[i].time = time;
                break;
            }
        }
    }

    Appointment* searchAppointment(int id) {
        for (int i = 0; i < appointmentCount; ++i) {
            if (appointments[i].id == id) {
                return &appointments[i];
            }
        }
        return nullptr;
    }

    void displayAppointments() {
        for (int i = 0; i < appointmentCount; ++i) {
            std::cout << "ID: " << appointments[i].id << ", Patient ID: " << appointments[i].patientId
                      << ", Date: " << appointments[i].date << ", Time: " << appointments[i].time << std::endl;
        }
    }
};

int main() {
    HealthCareReservationSystem system;
    system.addPatient(1, "John Doe", "Flu");
    system.addPatient(2, "Jane Smith", "Cold");
    system.addAppointment(1, 1, "2023-10-15", "14:00");
    system.addAppointment(2, 2, "2023-10-16", "10:00");
    system.displayPatients();
    system.displayAppointments();
    return 0;
}