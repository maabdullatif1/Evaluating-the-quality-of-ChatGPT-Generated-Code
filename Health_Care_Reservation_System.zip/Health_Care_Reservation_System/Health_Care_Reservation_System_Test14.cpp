#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Patient {
public:
    int id;
    string name;
    int age;

    Patient(int patientId, string patientName, int patientAge) {
        id = patientId;
        name = patientName;
        age = patientAge;
    }
};

class Appointment {
public:
    int id;
    int patientId;
    string date;
    string time;

    Appointment(int appointmentId, int pId, string appointmentDate, string appointmentTime) {
        id = appointmentId;
        patientId = pId;
        date = appointmentDate;
        time = appointmentTime;
    }
};

class HealthcareSystem {
    vector<Patient> patients;
    vector<Appointment> appointments;
    int patientCounter;
    int appointmentCounter;
    
public:
    HealthcareSystem() : patientCounter(0), appointmentCounter(0) {}

    void addPatient(string name, int age) {
        patients.push_back(Patient(++patientCounter, name, age));
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, string name, int age) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << endl;
        }
    }

    void addAppointment(int patientId, string date, string time) {
        appointments.push_back(Appointment(++appointmentCounter, patientId, date, time));
    }

    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->id == id) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int id, string date, string time) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) {
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }

    Appointment* searchAppointment(int id) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) {
                return &appointment;
            }
        }
        return nullptr;
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            cout << "Appointment ID: " << appointment.id 
                 << ", Patient ID: " << appointment.patientId 
                 << ", Date: " << appointment.date 
                 << ", Time: " << appointment.time << endl;
        }
    }
};

int main() {
    HealthcareSystem system;
    system.addPatient("Alice", 30);
    system.addPatient("Bob", 25);
    system.displayPatients();

    system.addAppointment(1, "2023-10-12", "10:00 AM");
    system.addAppointment(2, "2023-10-13", "11:00 AM");
    system.displayAppointments();

    return 0;
}