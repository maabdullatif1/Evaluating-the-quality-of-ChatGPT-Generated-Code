#include <iostream>
#include <string>
#include <vector>

class Patient {
public:
    int id;
    std::string name;
    int age;
    std::string gender;

    Patient(int id, const std::string& name, int age, const std::string& gender)
        : id(id), name(name), age(age), gender(gender) {}
};

class Appointment {
public:
    int id;
    int patientId;
    std::string date;
    std::string time;
    std::string description;

    Appointment(int id, int patientId, const std::string& date, const std::string& time, const std::string& description)
        : id(id), patientId(patientId), date(date), time(time), description(description) {}
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;

    Patient* findPatientById(int id) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }

    Appointment* findAppointmentById(int id) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) {
                return &appointment;
            }
        }
        return nullptr;
    }

public:
    void addPatient(int id, const std::string& name, int age, const std::string& gender) {
        patients.emplace_back(id, name, age, gender);
    }

    void deletePatient(int id) {
        patients.erase(std::remove_if(patients.begin(), patients.end(), [id](Patient& patient) {
            return patient.id == id;
        }), patients.end());
    }

    void updatePatient(int id, const std::string& name, int age, const std::string& gender) {
        Patient* patient = findPatientById(id);
        if (patient) {
            patient->name = name;
            patient->age = age;
            patient->gender = gender;
        }
    }

    Patient* searchPatient(int id) {
        return findPatientById(id);
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            std::cout << "ID: " << patient.id << ", Name: " << patient.name 
                      << ", Age: " << patient.age << ", Gender: " << patient.gender << std::endl;
        }
    }

    void addAppointment(int id, int patientId, const std::string& date, const std::string& time, const std::string& description) {
        appointments.emplace_back(id, patientId, date, time, description);
    }

    void deleteAppointment(int id) {
        appointments.erase(std::remove_if(appointments.begin(), appointments.end(), [id](Appointment& appointment) {
            return appointment.id == id;
        }), appointments.end());
    }

    void updateAppointment(int id, int patientId, const std::string& date, const std::string& time, const std::string& description) {
        Appointment* appointment = findAppointmentById(id);
        if (appointment) {
            appointment->patientId = patientId;
            appointment->date = date;
            appointment->time = time;
            appointment->description = description;
        }
    }

    Appointment* searchAppointment(int id) {
        return findAppointmentById(id);
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            std::cout << "ID: " << appointment.id << ", Patient ID: " << appointment.patientId 
                      << ", Date: " << appointment.date << ", Time: " << appointment.time 
                      << ", Description: " << appointment.description << std::endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient(1, "John Doe", 30, "Male");
    system.addPatient(2, "Jane Smith", 25, "Female");
    system.addAppointment(1, 1, "2023-11-01", "10:00", "General Checkup");
    system.addAppointment(2, 2, "2023-11-02", "11:00", "Dental Cleaning");

    std::cout << "Patients:\n";
    system.displayPatients();

    std::cout << "\nAppointments:\n";
    system.displayAppointments();

    return 0;
}