#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Patient {
public:
    int patientID;
    string name;
    int age;

    Patient(int id, string n, int a) : patientID(id), name(n), age(a) {}
};

class Appointment {
public:
    int appointmentID;
    int patientID;
    string date;
    string time;

    Appointment(int appId, int patId, string d, string t) 
        : appointmentID(appId), patientID(patId), date(d), time(t) {}
};

vector<Patient> patients;
vector<Appointment> appointments;

void addPatient(int id, string name, int age) {
    patients.push_back(Patient(id, name, age));
}

void deletePatient(int id) {
    for (auto it = patients.begin(); it != patients.end(); ++it) {
        if (it->patientID == id) {
            patients.erase(it);
            break;
        }
    }
}

void updatePatient(int id, string name, int age) {
    for (auto& patient : patients) {
        if (patient.patientID == id) {
            patient.name = name;
            patient.age = age;
            break;
        }
    }
}

Patient* searchPatient(int id) {
    for (auto& patient : patients) {
        if (patient.patientID == id) {
            return &patient;
        }
    }
    return nullptr;
}

void displayPatients() {
    for (const auto& patient : patients) {
        cout << "ID: " << patient.patientID << ", Name: " << patient.name << ", Age: " << patient.age << endl;
    }
}

void addAppointment(int appId, int patId, string date, string time) {
    appointments.push_back(Appointment(appId, patId, date, time));
}

void deleteAppointment(int appId) {
    for (auto it = appointments.begin(); it != appointments.end(); ++it) {
        if (it->appointmentID == appId) {
            appointments.erase(it);
            break;
        }
    }
}

void updateAppointment(int appId, string date, string time) {
    for (auto& appointment : appointments) {
        if (appointment.appointmentID == appId) {
            appointment.date = date;
            appointment.time = time;
            break;
        }
    }
}

Appointment* searchAppointment(int appId) {
    for (auto& appointment : appointments) {
        if (appointment.appointmentID == appId) {
            return &appointment;
        }
    }
    return nullptr;
}

void displayAppointments() {
    for (const auto& appointment : appointments) {
        cout << "Appointment ID: " << appointment.appointmentID << ", Patient ID: " << appointment.patientID 
             << ", Date: " << appointment.date << ", Time: " << appointment.time << endl;
    }
}

int main() {
    addPatient(1, "John Doe", 30);
    addPatient(2, "Jane Smith", 25);

    addAppointment(100, 1, "2023-10-01", "10:00AM");
    addAppointment(101, 2, "2023-10-02", "11:00AM");

    displayPatients();
    displayAppointments();

    updatePatient(1, "Johnny Doe", 31);
    updateAppointment(100, "2023-10-05", "09:00AM");

    displayPatients();
    displayAppointments();

    deletePatient(2);
    deleteAppointment(101);

    displayPatients();
    displayAppointments();

    Patient* p = searchPatient(1);
    if (p) {
        cout << "Found patient: " << p->name << endl;
    }

    Appointment* a = searchAppointment(100);
    if (a) {
        cout << "Found appointment on: " << a->date << " at " << a->time << endl;
    }

    return 0;
}