#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Appointment {
    string date;
    string time;
    string patientName;
    string doctorName;
};

struct Patient {
    string name;
    int age;
    string gender;
    string contactNumber;
};

class HealthCareSystem {
private:
    vector<Patient> patients;
    vector<Appointment> appointments;

    int findPatient(const string& name) {
        for (size_t i = 0; i < patients.size(); ++i) {
            if (patients[i].name == name) return i;
        }
        return -1;
    }

    int findAppointment(const string& name) {
        for (size_t i = 0; i < appointments.size(); ++i) {
            if (appointments[i].patientName == name) return i;
        }
        return -1;
    }

public:
    void addPatient(const string& name, int age, const string& gender, const string& contactNumber) {
        if (findPatient(name) == -1) {
            patients.push_back({name, age, gender, contactNumber});
            cout << "Patient added successfully.\n";
        } else {
            cout << "Patient already exists.\n";
        }
    }

    void deletePatient(const string& name) {
        int index = findPatient(name);
        if (index != -1) {
            patients.erase(patients.begin() + index);
            cout << "Patient deleted successfully.\n";
        } else {
            cout << "Patient not found.\n";
        }
    }

    void updatePatient(const string& name, const string& newName, int age, const string& gender, const string& contactNumber) {
        int index = findPatient(name);
        if (index != -1) {
            patients[index] = {newName, age, gender, contactNumber};
            cout << "Patient updated successfully.\n";
        } else {
            cout << "Patient not found.\n";
        }
    }

    void searchPatient(const string& name) {
        int index = findPatient(name);
        if (index != -1) {
            cout << "Name: " << patients[index].name << ", Age: " << patients[index].age
                 << ", Gender: " << patients[index].gender
                 << ", Contact Number: " << patients[index].contactNumber << endl;
        } else {
            cout << "Patient not found.\n";
        }
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            cout << "Name: " << patient.name << ", Age: " << patient.age
                 << ", Gender: " << patient.gender
                 << ", Contact Number: " << patient.contactNumber << endl;
        }
    }

    void addAppointment(const string& date, const string& time, const string& patientName, const string& doctorName) {
        if (findAppointment(patientName) == -1) {
            appointments.push_back({date, time, patientName, doctorName});
            cout << "Appointment added successfully.\n";
        } else {
            cout << "Appointment already exists for this patient.\n";
        }
    }

    void deleteAppointment(const string& patientName) {
        int index = findAppointment(patientName);
        if (index != -1) {
            appointments.erase(appointments.begin() + index);
            cout << "Appointment deleted successfully.\n";
        } else {
            cout << "Appointment not found.\n";
        }
    }

    void updateAppointment(const string& patientName, const string& date, const string& time, const string& doctorName) {
        int index = findAppointment(patientName);
        if (index != -1) {
            appointments[index] = {date, time, patientName, doctorName};
            cout << "Appointment updated successfully.\n";
        } else {
            cout << "Appointment not found.\n";
        }
    }

    void searchAppointment(const string& patientName) {
        int index = findAppointment(patientName);
        if (index != -1) {
            cout << "Date: " << appointments[index].date << ", Time: " << appointments[index].time
                 << ", Patient: " << appointments[index].patientName
                 << ", Doctor: " << appointments[index].doctorName << endl;
        } else {
            cout << "Appointment not found.\n";
        }
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            cout << "Date: " << appointment.date << ", Time: " << appointment.time
                 << ", Patient: " << appointment.patientName
                 << ", Doctor: " << appointment.doctorName << endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("John Doe", 30, "Male", "1234567890");
    system.searchPatient("John Doe");
    system.addAppointment("2023-09-15", "10:00", "John Doe", "Dr. Smith");
    system.displayAppointments();
    return 0;
}