#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Patient {
    int id;
    string name;
    int age;
};

struct Appointment {
    int patientId;
    string date;
    string time;
    string doctorName;
};

vector<Patient> patients;
vector<Appointment> appointments;

int getPatientIndexById(int id) {
    for (size_t i = 0; i < patients.size(); ++i) {
        if (patients[i].id == id) return i;
    }
    return -1;
}

int getAppointmentIndexByPatientId(int patientId) {
    for (size_t i = 0; i < appointments.size(); ++i) {
        if (appointments[i].patientId == patientId) return i;
    }
    return -1;
}

void addPatient(int id, string name, int age) {
    patients.push_back({id, name, age});
}

void deletePatient(int id) {
    int index = getPatientIndexById(id);
    if (index != -1) {
        patients.erase(patients.begin() + index);
        int appIndex = getAppointmentIndexByPatientId(id);
        if (appIndex != -1) {
            appointments.erase(appointments.begin() + appIndex);
        }
    }
}

void updatePatient(int id, string name, int age) {
    int index = getPatientIndexById(id);
    if (index != -1) {
        patients[index].name = name;
        patients[index].age = age;
    }
}

void searchPatient(int id) {
    int index = getPatientIndexById(id);
    if (index != -1) {
        cout << "Patient ID: " << patients[index].id << "\nName: " << patients[index].name << "\nAge: " << patients[index].age << endl;
    } else {
        cout << "Patient not found." << endl;
    }
}

void displayPatients() {
    for (const auto& patient : patients) {
        cout << "Patient ID: " << patient.id << "\nName: " << patient.name << "\nAge: " << patient.age << "\n" << endl;
    }
}

void addAppointment(int patientId, string date, string time, string doctorName) {
    if (getPatientIndexById(patientId) != -1) {
        appointments.push_back({patientId, date, time, doctorName});
    }
}

void deleteAppointment(int patientId) {
    int index = getAppointmentIndexByPatientId(patientId);
    if (index != -1) {
        appointments.erase(appointments.begin() + index);
    }
}

void updateAppointment(int patientId, string date, string time, string doctorName) {
    int index = getAppointmentIndexByPatientId(patientId);
    if (index != -1) {
        appointments[index].date = date;
        appointments[index].time = time;
        appointments[index].doctorName = doctorName;
    }
}

void searchAppointment(int patientId) {
    int index = getAppointmentIndexByPatientId(patientId);
    if (index != -1) {
        cout << "Appointment for Patient ID: " << appointments[index].patientId << "\nDate: " << appointments[index].date 
             << "\nTime: " << appointments[index].time << "\nDoctor: " << appointments[index].doctorName << endl;
    } else {
        cout << "Appointment not found." << endl;
    }
}

void displayAppointments() {
    for (const auto& appointment : appointments) {
        cout << "Appointment for Patient ID: " << appointment.patientId << "\nDate: " << appointment.date 
             << "\nTime: " << appointment.time << "\nDoctor: " << appointment.doctorName << "\n" << endl;
    }
}

int main() {
    addPatient(1, "John Doe", 30);
    addPatient(2, "Jane Smith", 25);

    addAppointment(1, "2023-10-15", "10:00 AM", "Dr. Brown");
    addAppointment(2, "2023-10-16", "11:00 AM", "Dr. Green");

    cout << "Patients:" << endl;
    displayPatients();
    
    cout << "Appointments:" << endl;
    displayAppointments();

    updatePatient(1, "John Doe", 31);
    updateAppointment(1, "2023-10-15", "11:00 AM", "Dr. Brown");

    cout << "Updated Patient:" << endl;
    searchPatient(1);

    cout << "Updated Appointment:" << endl;
    searchAppointment(1);

    deletePatient(2);

    cout << "Patients after deletion:" << endl;
    displayPatients();
    
    cout << "Appointments after deletion:" << endl;
    displayAppointments();

    return 0;
}