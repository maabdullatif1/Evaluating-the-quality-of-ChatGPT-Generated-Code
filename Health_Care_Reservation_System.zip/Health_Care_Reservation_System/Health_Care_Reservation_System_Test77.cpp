#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Patient {
public:
    int id;
    string name;
    int age;

    Patient(int id, string name, int age) : id(id), name(name), age(age) {}
};

class Appointment {
public:
    int id;
    int patientId;
    string date;
    string time;

    Appointment(int id, int patientId, string date, string time)
        : id(id), patientId(patientId), date(date), time(time) {}
};

class HealthCareReservationSystem {
    vector<Patient> patients;
    vector<Appointment> appointments;
    int nextPatientId = 1;
    int nextAppointmentId = 1;

public:
    void addPatient(const string& name, int age) {
        patients.emplace_back(nextPatientId++, name, age);
    }

    void deletePatient(int id) {
        patients.erase(remove_if(patients.begin(), patients.end(),
            [&id](Patient& p) { return p.id == id; }), patients.end());
    }

    void updatePatient(int id, const string& name, int age) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (auto& patient : patients) {
            if (patient.id == id)
                return &patient;
        }
        return nullptr;
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            cout << "Patient ID: " << patient.id
                 << ", Name: " << patient.name
                 << ", Age: " << patient.age << endl;
        }
    }

    void addAppointment(int patientId, const string& date, const string& time) {
        appointments.emplace_back(nextAppointmentId++, patientId, date, time);
    }

    void deleteAppointment(int id) {
        appointments.erase(remove_if(appointments.begin(), appointments.end(),
            [&id](Appointment& a) { return a.id == id; }), appointments.end());
    }

    void updateAppointment(int id, const string& date, const string& time) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) {
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }

    Appointment* searchAppointment(int id) {
        for (auto& appointment : appointments) {
            if (appointment.id == id)
                return &appointment;
        }
        return nullptr;
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            cout << "Appointment ID: " << appointment.id
                 << ", Patient ID: " << appointment.patientId
                 << ", Date: " << appointment.date
                 << ", Time: " << appointment.time << endl;
        }
    }
};

int main() {
    HealthCareReservationSystem system;

    system.addPatient("John Doe", 30);
    system.addPatient("Jane Smith", 25);

    system.addAppointment(1, "2023-11-01", "10:00");
    system.addAppointment(2, "2023-11-02", "14:00");

    cout << "Patients List:" << endl;
    system.displayPatients();

    cout << endl << "Appointments List:" << endl;
    system.displayAppointments();

    return 0;
}