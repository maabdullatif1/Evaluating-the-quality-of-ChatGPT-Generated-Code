#include <iostream>
#include <string>
using namespace std;

struct Appointment {
    int id;
    string date;
    string time;
    string doctorName;
};

struct Patient {
    int id;
    string name;
    int age;
    string gender;
    Appointment appointment;
};

class HealthCareSystem {
private:
    Patient patients[100];
    int patientCount;

public:
    HealthCareSystem() : patientCount(0) {}

    void addPatient(int id, string name, int age, string gender, int appId, string date, string time, string doctor) {
        if (patientCount < 100) {
            patients[patientCount].id = id;
            patients[patientCount].name = name;
            patients[patientCount].age = age;
            patients[patientCount].gender = gender;
            patients[patientCount].appointment = {appId, date, time, doctor};
            patientCount++;
        }
    }

    void deletePatient(int id) {
        for (int i = 0; i < patientCount; i++) {
            if (patients[i].id == id) {
                for (int j = i; j < patientCount - 1; j++) {
                    patients[j] = patients[j + 1];
                }
                patientCount--;
                break;
            }
        }
    }

    void updatePatient(int id, string name, int age, string gender, int appId, string date, string time, string doctor) {
        for (int i = 0; i < patientCount; i++) {
            if (patients[i].id == id) {
                patients[i].name = name;
                patients[i].age = age;
                patients[i].gender = gender;
                patients[i].appointment = {appId, date, time, doctor};
                break;
            }
        }
    }

    void searchPatient(int id) {
        for (int i = 0; i < patientCount; i++) {
            if (patients[i].id == id) {
                cout << "Patient ID: " << patients[i].id << endl;
                cout << "Name: " << patients[i].name << endl;
                cout << "Age: " << patients[i].age << endl;
                cout << "Gender: " << patients[i].gender << endl;
                cout << "Appointment ID: " << patients[i].appointment.id << endl;
                cout << "Date: " << patients[i].appointment.date << endl;
                cout << "Time: " << patients[i].appointment.time << endl;
                cout << "Doctor Name: " << patients[i].appointment.doctorName << endl;
                return;
            }
        }
        cout << "Patient not found" << endl;
    }

    void displayAllPatients() {
        for (int i = 0; i < patientCount; i++) {
            cout << "Patient ID: " << patients[i].id << endl;
            cout << "Name: " << patients[i].name << endl;
            cout << "Age: " << patients[i].age << endl;
            cout << "Gender: " << patients[i].gender << endl;
            cout << "Appointment ID: " << patients[i].appointment.id << endl;
            cout << "Date: " << patients[i].appointment.date << endl;
            cout << "Time: " << patients[i].appointment.time << endl;
            cout << "Doctor Name: " << patients[i].appointment.doctorName << endl;
            cout << "-------------------------" << endl;
        }
    }
};

int main() {
    HealthCareSystem hcs;
    hcs.addPatient(1, "John Doe", 30, "Male", 101, "2023-10-20", "10:00 AM", "Dr. Smith");
    hcs.addPatient(2, "Jane Doe", 28, "Female", 102, "2023-10-21", "11:00 AM", "Dr. Adams");
    hcs.displayAllPatients();
    hcs.searchPatient(1);
    hcs.updatePatient(1, "John Doe", 31, "Male", 101, "2023-10-22", "10:30 AM", "Dr. Smith");
    hcs.searchPatient(1);
    hcs.deletePatient(2);
    hcs.displayAllPatients();
    return 0;
}