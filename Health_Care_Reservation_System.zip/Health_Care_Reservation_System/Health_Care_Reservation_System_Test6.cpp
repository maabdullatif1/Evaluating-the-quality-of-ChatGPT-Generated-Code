#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Patient {
public:
    int id;
    string name;
    int age;

    Patient(int id, string name, int age) : id(id), name(name), age(age) {}
};

class Appointment {
public:
    int id;
    int patientId;
    string date;
    string time;

    Appointment(int id, int patientId, string date, string time) 
        : id(id), patientId(patientId), date(date), time(time) {}
};

class HealthCareSystem {
    vector<Patient> patients;
    vector<Appointment> appointments;
    int nextPatientId;
    int nextAppointmentId;

public:
    HealthCareSystem() : nextPatientId(1), nextAppointmentId(1) {}

    void addPatient(string name, int age) {
        patients.push_back(Patient(nextPatientId++, name, age));
        cout << "Patient added successfully.\n";
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                cout << "Patient deleted successfully.\n";
                return;
            }
        }
        cout << "Patient not found.\n";
    }

    void updatePatient(int id, string name, int age) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                cout << "Patient updated successfully.\n";
                return;
            }
        }
        cout << "Patient not found.\n";
    }

    void searchPatient(int id) {
        for (const auto& patient : patients) {
            if (patient.id == id) {
                cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << endl;
                return;
            }
        }
        cout << "Patient not found.\n";
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            cout << "ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << endl;
        }
    }

    void addAppointment(int patientId, string date, string time) {
        appointments.push_back(Appointment(nextAppointmentId++, patientId, date, time));
        cout << "Appointment added successfully.\n";
    }

    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->id == id) {
                appointments.erase(it);
                cout << "Appointment deleted successfully.\n";
                return;
            }
        }
        cout << "Appointment not found.\n";
    }

    void updateAppointment(int id, string date, string time) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) {
                appointment.date = date;
                appointment.time = time;
                cout << "Appointment updated successfully.\n";
                return;
            }
        }
        cout << "Appointment not found.\n";
    }

    void searchAppointment(int id) {
        for (const auto& appointment : appointments) {
            if (appointment.id == id) {
                cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId 
                     << ", Date: " << appointment.date << ", Time: " << appointment.time << endl;
                return;
            }
        }
        cout << "Appointment not found.\n";
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            cout << "ID: " << appointment.id << ", Patient ID: " << appointment.patientId 
                 << ", Date: " << appointment.date << ", Time: " << appointment.time << endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("John Doe", 30);
    system.addPatient("Jane Smith", 25);
    system.displayPatients();

    system.addAppointment(1, "2023-11-01", "10:30");
    system.addAppointment(2, "2023-11-02", "11:00");
    system.displayAppointments();

    system.searchPatient(1);
    system.searchAppointment(1);

    system.updatePatient(1, "Johnathan Doe", 31);
    system.updateAppointment(1, "2023-11-01", "11:30");

    system.deletePatient(2);
    system.deleteAppointment(2);

    system.displayPatients();
    system.displayAppointments();

    return 0;
}