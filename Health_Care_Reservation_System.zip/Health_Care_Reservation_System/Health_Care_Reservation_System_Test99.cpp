#include <iostream>
#include <string>
#include <vector>

class Patient {
public:
    int id;
    std::string name;
    int age;
    std::string gender;

    Patient(int i, const std::string& n, int a, const std::string& g) : id(i), name(n), age(a), gender(g) {}
};

class Appointment {
public:
    int appointmentId;
    int patientId;
    std::string date;
    std::string time;

    Appointment(int aid, int pid, const std::string& d, const std::string& t) : appointmentId(aid), patientId(pid), date(d), time(t) {}
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;
    int nextPatientId = 1;
    int nextAppointmentId = 1;

public:
    void addPatient(const std::string& name, int age, const std::string& gender) {
        patients.push_back(Patient(nextPatientId++, name, age, gender));
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, const std::string& name, int age, const std::string& gender) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                patient.gender = gender;
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            std::cout << "ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << ", Gender: " << patient.gender << std::endl;
        }
    }

    void addAppointment(int patientId, const std::string& date, const std::string& time) {
        appointments.push_back(Appointment(nextAppointmentId++, patientId, date, time));
    }

    void deleteAppointment(int appointmentId) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->appointmentId == appointmentId) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int appointmentId, int patientId, const std::string& date, const std::string& time) {
        for (auto& appointment : appointments) {
            if (appointment.appointmentId == appointmentId) {
                appointment.patientId = patientId;
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }

    Appointment* searchAppointment(int appointmentId) {
        for (auto& appointment : appointments) {
            if (appointment.appointmentId == appointmentId) {
                return &appointment;
            }
        }
        return nullptr;
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            std::cout << "Appointment ID: " << appointment.appointmentId << ", Patient ID: " << appointment.patientId 
                      << ", Date: " << appointment.date << ", Time: " << appointment.time << std::endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("John Doe", 30, "Male");
    system.addPatient("Jane Smith", 40, "Female");
    system.displayPatients();

    system.addAppointment(1, "2023-10-15", "10:00");
    system.addAppointment(2, "2023-10-16", "11:00");
    system.displayAppointments();
    
    return 0;
}