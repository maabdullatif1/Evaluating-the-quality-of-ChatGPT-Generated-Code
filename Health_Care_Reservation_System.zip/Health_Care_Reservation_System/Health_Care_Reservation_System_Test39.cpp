#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Patient {
    int id;
    string name;
    int age;
    string contact;
};

struct Appointment {
    int id;
    int patientId;
    string date;
    string time;
};

class HealthCareSystem {
    vector<Patient> patients;
    vector<Appointment> appointments;
    int patientIdCounter;
    int appointmentIdCounter;

    Patient* findPatientById(int id) {
        for (auto& patient : patients) {
            if (patient.id == id) return &patient;
        }
        return nullptr;
    }

public:
    HealthCareSystem() : patientIdCounter(1), appointmentIdCounter(1) {}

    void addPatient(string name, int age, string contact) {
        patients.push_back({patientIdCounter++, name, age, contact});
    }

    void deletePatient(int id) {
        for (size_t i = 0; i < patients.size(); ++i) {
            if (patients[i].id == id) {
                patients.erase(patients.begin() + i);
                return;
            }
        }
    }

    void updatePatient(int id, string name, int age, string contact) {
        Patient* patient = findPatientById(id);
        if (patient) {
            patient->name = name;
            patient->age = age;
            patient->contact = contact;
        }
    }

    Patient* searchPatient(int id) {
        return findPatientById(id);
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            cout << "ID: " << patient.id 
                 << ", Name: " << patient.name 
                 << ", Age: " << patient.age 
                 << ", Contact: " << patient.contact << endl;
        }
    }

    void addAppointment(int patientId, string date, string time) {
        if (findPatientById(patientId)) {
            appointments.push_back({appointmentIdCounter++, patientId, date, time});
        }
    }

    void deleteAppointment(int id) {
        for (size_t i = 0; i < appointments.size(); ++i) {
            if (appointments[i].id == id) {
                appointments.erase(appointments.begin() + i);
                return;
            }
        }
    }

    void updateAppointment(int id, string date, string time) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) {
                appointment.date = date;
                appointment.time = time;
                return;
            }
        }
    }

    Appointment* searchAppointment(int id) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) return &appointment;
        }
        return nullptr;
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            cout << "Appointment ID: " << appointment.id 
                 << ", Patient ID: " << appointment.patientId 
                 << ", Date: " << appointment.date 
                 << ", Time: " << appointment.time << endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("John Doe", 30, "1234567890");
    system.addPatient("Jane Smith", 25, "0987654321");
    system.displayPatients();

    system.addAppointment(1, "2023-10-01", "10:00");
    system.addAppointment(2, "2023-10-02", "11:00");
    system.displayAppointments();

    system.updatePatient(1, "John Doe Jr.", 31, "1234509876");
    system.updateAppointment(1, "2023-10-03", "09:00");
    system.displayPatients();
    system.displayAppointments();

    system.deletePatient(2);
    system.deleteAppointment(2);
    system.displayPatients();
    system.displayAppointments();

    return 0;
}