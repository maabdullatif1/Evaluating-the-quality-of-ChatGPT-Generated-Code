#include <iostream>
#include <string>
using namespace std;

struct Patient {
    int id;
    string name;
    int age;
    string address;
};

struct Appointment {
    int id;
    int patientId;
    string date;
    string time;
};

Patient patients[100];
Appointment appointments[100];
int patientCount = 0;
int appointmentCount = 0;

void addPatient() {
    Patient p;
    cout << "Enter Patient ID: ";
    cin >> p.id;
    cout << "Enter Patient Name: ";
    cin >> p.name;
    cout << "Enter Patient Age: ";
    cin >> p.age;
    cout << "Enter Patient Address: ";
    cin >> p.address;
    patients[patientCount++] = p;
}

void deletePatient() {
    int id;
    cout << "Enter Patient ID to delete: ";
    cin >> id;
    for (int i = 0; i < patientCount; ++i) {
        if (patients[i].id == id) {
            for (int j = i; j < patientCount - 1; ++j) {
                patients[j] = patients[j + 1];
            }
            patientCount--;
            cout << "Patient deleted successfully." << endl;
            return;
        }
    }
    cout << "Patient not found." << endl;
}

void updatePatient() {
    int id;
    cout << "Enter Patient ID to update: ";
    cin >> id;
    for (int i = 0; i < patientCount; ++i) {
        if (patients[i].id == id) {
            cout << "Enter new Patient Name: ";
            cin >> patients[i].name;
            cout << "Enter new Patient Age: ";
            cin >> patients[i].age;
            cout << "Enter new Patient Address: ";
            cin >> patients[i].address;
            cout << "Patient updated successfully." << endl;
            return;
        }
    }
    cout << "Patient not found." << endl;
}

void searchPatient() {
    int id;
    cout << "Enter Patient ID to search: ";
    cin >> id;
    for (int i = 0; i < patientCount; ++i) {
        if (patients[i].id == id) {
            cout << "Patient ID: " << patients[i].id << endl;
            cout << "Patient Name: " << patients[i].name << endl;
            cout << "Patient Age: " << patients[i].age << endl;
            cout << "Patient Address: " << patients[i].address << endl;
            return;
        }
    }
    cout << "Patient not found." << endl;
}

void displayPatients() {
    if (patientCount == 0) {
        cout << "No patients to display." << endl;
        return;
    }
    for (int i = 0; i < patientCount; ++i) {
        cout << "Patient ID: " << patients[i].id << ", Name: " << patients[i].name 
             << ", Age: " << patients[i].age << ", Address: " << patients[i].address << endl;
    }
}

void addAppointment() {
    Appointment a;
    cout << "Enter Appointment ID: ";
    cin >> a.id;
    cout << "Enter Patient ID for Appointment: ";
    cin >> a.patientId;
    cout << "Enter Appointment Date (yyyy-mm-dd): ";
    cin >> a.date;
    cout << "Enter Appointment Time (hh:mm): ";
    cin >> a.time;
    appointments[appointmentCount++] = a;
}

void deleteAppointment() {
    int id;
    cout << "Enter Appointment ID to delete: ";
    cin >> id;
    for (int i = 0; i < appointmentCount; ++i) {
        if (appointments[i].id == id) {
            for (int j = i; j < appointmentCount - 1; ++j) {
                appointments[j] = appointments[j + 1];
            }
            appointmentCount--;
            cout << "Appointment deleted successfully." << endl;
            return;
        }
    }
    cout << "Appointment not found." << endl;
}

void updateAppointment() {
    int id;
    cout << "Enter Appointment ID to update: ";
    cin >> id;
    for (int i = 0; i < appointmentCount; ++i) {
        if (appointments[i].id == id) {
            cout << "Enter new Patient ID for Appointment: ";
            cin >> appointments[i].patientId;
            cout << "Enter new Appointment Date (yyyy-mm-dd): ";
            cin >> appointments[i].date;
            cout << "Enter new Appointment Time (hh:mm): ";
            cin >> appointments[i].time;
            cout << "Appointment updated successfully." << endl;
            return;
        }
    }
    cout << "Appointment not found." << endl;
}

void searchAppointment() {
    int id;
    cout << "Enter Appointment ID to search: ";
    cin >> id;
    for (int i = 0; i < appointmentCount; ++i) {
        if (appointments[i].id == id) {
            cout << "Appointment ID: " << appointments[i].id << endl;
            cout << "Patient ID: " << appointments[i].patientId << endl;
            cout << "Appointment Date: " << appointments[i].date << endl;
            cout << "Appointment Time: " << appointments[i].time << endl;
            return;
        }
    }
    cout << "Appointment not found." << endl;
}

void displayAppointments() {
    if (appointmentCount == 0) {
        cout << "No appointments to display." << endl;
        return;
    }
    for (int i = 0; i < appointmentCount; ++i) {
        cout << "Appointment ID: " << appointments[i].id << ", Patient ID: " << appointments[i].patientId 
             << ", Date: " << appointments[i].date << ", Time: " << appointments[i].time << endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Patient" << endl
             << "2. Delete Patient" << endl
             << "3. Update Patient" << endl
             << "4. Search Patient" << endl
             << "5. Display Patients" << endl
             << "6. Add Appointment" << endl
             << "7. Delete Appointment" << endl
             << "8. Update Appointment" << endl
             << "9. Search Appointment" << endl
             << "10. Display Appointments" << endl
             << "11. Exit" << endl
             << "Enter choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addPatient(); break;
            case 2: deletePatient(); break;
            case 3: updatePatient(); break;
            case 4: searchPatient(); break;
            case 5: displayPatients(); break;
            case 6: addAppointment(); break;
            case 7: deleteAppointment(); break;
            case 8: updateAppointment(); break;
            case 9: searchAppointment(); break;
            case 10: displayAppointments(); break;
            case 11: return 0;
            default: cout << "Invalid choice." << endl;
        }
    }
}