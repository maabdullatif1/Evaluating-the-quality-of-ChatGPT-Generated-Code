#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Patient {
    int id;
    string name;
    int age;
};

struct Appointment {
    int id;
    int patientId;
    string date;
    string time;
};

class HealthcareSystem {
private:
    vector<Patient> patients;
    vector<Appointment> appointments;
    int patientCounter = 1;
    int appointmentCounter = 1;

    int findPatientIndex(int id) {
        for (size_t i = 0; i < patients.size(); ++i) {
            if (patients[i].id == id) return i;
        }
        return -1;
    }

    int findAppointmentIndex(int id) {
        for (size_t i = 0; i < appointments.size(); ++i) {
            if (appointments[i].id == id) return i;
        }
        return -1;
    }

public:
    void addPatient(const string& name, int age) {
        patients.push_back({patientCounter++, name, age});
    }

    void deletePatient(int id) {
        int index = findPatientIndex(id);
        if (index != -1) patients.erase(patients.begin() + index);
    }

    void updatePatient(int id, const string& name, int age) {
        int index = findPatientIndex(id);
        if (index != -1) {
            patients[index].name = name;
            patients[index].age = age;
        }
    }

    int searchPatient(const string& name) {
        for (size_t i = 0; i < patients.size(); ++i) {
            if (patients[i].name == name) return patients[i].id;
        }
        return -1;
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            cout << "ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << endl;
        }
    }

    void addAppointment(int patientId, const string& date, const string& time) {
        int patientIndex = findPatientIndex(patientId);
        if (patientIndex != -1) {
            appointments.push_back({appointmentCounter++, patientId, date, time});
        }
    }

    void deleteAppointment(int id) {
        int index = findAppointmentIndex(id);
        if (index != -1) appointments.erase(appointments.begin() + index);
    }

    void updateAppointment(int id, const string& date, const string& time) {
        int index = findAppointmentIndex(id);
        if (index != -1) {
            appointments[index].date = date;
            appointments[index].time = time;
        }
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            cout << "Appointment ID: " << appointment.id 
                 << ", Patient ID: " << appointment.patientId 
                 << ", Date: " << appointment.date 
                 << ", Time: " << appointment.time << endl;
        }
    }
};

int main() {
    HealthcareSystem system;
    system.addPatient("John Doe", 30);
    system.addPatient("Jane Smith", 25);
    system.displayPatients();

    system.addAppointment(1, "2023-11-10", "10:00 AM");
    system.displayAppointments();

    system.updatePatient(1, "John Doe Updated", 31);
    system.displayPatients();

    system.updateAppointment(1, "2023-11-11", "11:00 AM");
    system.displayAppointments();

    system.deletePatient(2);
    system.displayPatients();

    system.deleteAppointment(1);
    system.displayAppointments();

    return 0;
}