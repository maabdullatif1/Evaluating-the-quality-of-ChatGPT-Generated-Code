#include <iostream>
#include <vector>
#include <string>

struct Patient {
    int id;
    std::string name;
    int age;
};

struct Appointment {
    int id;
    int patientId;
    std::string date;
    std::string time;
};

std::vector<Patient> patients;
std::vector<Appointment> appointments;

void addPatient(int id, std::string name, int age) {
    patients.push_back({id, name, age});
}

void deletePatient(int id) {
    for (auto it = patients.begin(); it != patients.end(); ++it) {
        if (it->id == id) {
            patients.erase(it);
            break;
        }
    }
}

void updatePatient(int id, std::string name, int age) {
    for (auto &patient : patients) {
        if (patient.id == id) {
            patient.name = name;
            patient.age = age;
        }
    }
}

Patient* searchPatient(int id) {
    for (auto &patient : patients) {
        if (patient.id == id) return &patient;
    }
    return nullptr;
}

void displayPatients() {
    for (auto &patient : patients) {
        std::cout << "ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << std::endl;
    }
}

void addAppointment(int id, int patientId, std::string date, std::string time) {
    appointments.push_back({id, patientId, date, time});
}

void deleteAppointment(int id) {
    for (auto it = appointments.begin(); it != appointments.end(); ++it) {
        if (it->id == id) {
            appointments.erase(it);
            break;
        }
    }
}

void updateAppointment(int id, std::string date, std::string time) {
    for (auto &appointment : appointments) {
        if (appointment.id == id) {
            appointment.date = date;
            appointment.time = time;
        }
    }
}

Appointment* searchAppointment(int id) {
    for (auto &appointment : appointments) {
        if (appointment.id == id) return &appointment;
    }
    return nullptr;
}

void displayAppointments() {
    for (auto &appointment : appointments) {
        std::cout << "Appointment ID: " << appointment.id
                  << ", Patient ID: " << appointment.patientId
                  << ", Date: " << appointment.date
                  << ", Time: " << appointment.time << std::endl;
    }
}

int main() {
    addPatient(1, "Alice Smith", 30);
    addPatient(2, "Bob Johnson", 40);
    addAppointment(1, 1, "2023-12-01", "09:00");
    addAppointment(2, 2, "2023-12-02", "10:00");

    std::cout << "Patients:" << std::endl;
    displayPatients();

    std::cout << "Appointments:" << std::endl;
    displayAppointments();

    updatePatient(2, "Bob Johnson", 41);
    updateAppointment(1, "2023-12-01", "10:00");

    std::cout << "Updated Patients:" << std::endl;
    displayPatients();

    std::cout << "Updated Appointments:" << std::endl;
    displayAppointments();

    deletePatient(1);
    deleteAppointment(2);

    std::cout << "Final Patients:" << std::endl;
    displayPatients();

    std::cout << "Final Appointments:" << std::endl;
    displayAppointments();

    return 0;
}