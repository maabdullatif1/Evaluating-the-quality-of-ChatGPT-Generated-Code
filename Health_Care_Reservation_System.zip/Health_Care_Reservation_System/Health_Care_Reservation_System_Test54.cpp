#include <iostream>
#include <vector>
#include <string>

struct Patient {
    int id;
    std::string name;
    int age;
    std::string address;
};

struct Appointment {
    int id;
    int patientId;
    std::string date;
    std::string time;
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;
    int nextPatientId = 1;
    int nextAppointmentId = 1;

public:
    void addPatient(const std::string &name, int age, const std::string &address) {
        patients.push_back({nextPatientId++, name, age, address});
    }

    void deletePatient(int patientId) {
        patients.erase(std::remove_if(patients.begin(), patients.end(),
                      [patientId](Patient &p){ return p.id == patientId; }),
                       patients.end());
    }

    void updatePatient(int patientId, const std::string &name, int age, const std::string &address) {
        for (auto &patient : patients) {
            if (patient.id == patientId) {
                patient.name = name;
                patient.age = age;
                patient.address = address;
                break;
            }
        }
    }

    void searchPatient(int patientId) {
        for (const auto &patient : patients) {
            if (patient.id == patientId) {
                std::cout << "Patient ID: " << patient.id << "\nName: " << patient.name
                          << "\nAge: " << patient.age << "\nAddress: " << patient.address << "\n";
                return;
            }
        }
        std::cout << "Patient not found.\n";
    }

    void displayPatients() {
        for (const auto &patient : patients) {
            std::cout << "Patient ID: " << patient.id << "\nName: " << patient.name
                      << "\nAge: " << patient.age << "\nAddress: " << patient.address << "\n";
        }
    }

    void addAppointment(int patientId, const std::string &date, const std::string &time) {
        appointments.push_back({nextAppointmentId++, patientId, date, time});
    }

    void deleteAppointment(int appointmentId) {
        appointments.erase(std::remove_if(appointments.begin(), appointments.end(),
                          [appointmentId](Appointment &a){ return a.id == appointmentId; }),
                           appointments.end());
    }

    void updateAppointment(int appointmentId, const std::string &date, const std::string &time) {
        for (auto &appointment : appointments) {
            if (appointment.id == appointmentId) {
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }

    void searchAppointment(int appointmentId) {
        for (const auto &appointment : appointments) {
            if (appointment.id == appointmentId) {
                std::cout << "Appointment ID: " << appointment.id
                          << "\nPatient ID: " << appointment.patientId
                          << "\nDate: " << appointment.date
                          << "\nTime: " << appointment.time << "\n";
                return;
            }
        }
        std::cout << "Appointment not found.\n";
    }

    void displayAppointments() {
        for (const auto &appointment : appointments) {
            std::cout << "Appointment ID: " << appointment.id
                      << "\nPatient ID: " << appointment.patientId
                      << "\nDate: " << appointment.date
                      << "\nTime: " << appointment.time << "\n";
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("John Doe", 30, "123 Elm St");
    system.addPatient("Jane Doe", 28, "456 Oak St");
    system.displayPatients();
    system.addAppointment(1, "2023-05-01", "10:00 AM");
    system.addAppointment(2, "2023-05-02", "11:00 AM");
    system.displayAppointments();
    system.updatePatient(1, "John Smith", 31, "789 Pine St");
    system.updateAppointment(1, "2023-05-03", "2:00 PM");
    system.searchPatient(1);
    system.searchAppointment(1);
    system.deletePatient(2);
    system.deleteAppointment(2);
    system.displayPatients();
    system.displayAppointments();
    return 0;
}