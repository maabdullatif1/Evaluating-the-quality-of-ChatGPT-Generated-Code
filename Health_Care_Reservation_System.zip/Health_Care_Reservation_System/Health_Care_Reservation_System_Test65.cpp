#include <iostream>
#include <vector>
#include <string>

class Patient {
public:
    std::string name;
    int age;
    std::string id;

    Patient(const std::string& name, int age, const std::string& id)
        : name(name), age(age), id(id) {}
};

class Appointment {
public:
    std::string patientId;
    std::string date;
    std::string time;
    std::string doctor;
    
    Appointment(const std::string& patientId, const std::string& date, const std::string& time, const std::string& doctor)
        : patientId(patientId), date(date), time(time), doctor(doctor) {}
};

class HealthCareSystem {
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;

public:
    void addPatient(const std::string& name, int age, const std::string& id) {
        patients.emplace_back(name, age, id);
    }
    
    void deletePatient(const std::string& id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }
    
    void updatePatient(const std::string& id, const std::string& name, int age) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                break;
            }
        }
    }
    
    Patient* searchPatient(const std::string& id) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }
    
    void displayPatients() {
        for (const auto& patient : patients) {
            std::cout << "ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << std::endl;
        }
    }
    
    void addAppointment(const std::string& patientId, const std::string& date, const std::string& time, const std::string& doctor) {
        appointments.emplace_back(patientId, date, time, doctor);
    }
    
    void deleteAppointment(const std::string& patientId, const std::string& date) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->patientId == patientId && it->date == date) {
                appointments.erase(it);
                break;
            }
        }
    }
    
    void updateAppointment(const std::string& patientId, const std::string& date, const std::string& time, const std::string& doctor) {
        for (auto& appointment : appointments) {
            if (appointment.patientId == patientId && appointment.date == date) {
                appointment.time = time;
                appointment.doctor = doctor;
                break;
            }
        }
    }
    
    Appointment* searchAppointment(const std::string& patientId, const std::string& date) {
        for (auto& appointment : appointments) {
            if (appointment.patientId == patientId && appointment.date == date) {
                return &appointment;
            }
        }
        return nullptr;
    }
    
    void displayAppointments() {
        for (const auto& appointment : appointments) {
            std::cout << "Patient ID: " << appointment.patientId << ", Date: " << appointment.date << ", Time: " << appointment.time << ", Doctor: " << appointment.doctor << std::endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("John Doe", 30, "P123");
    system.addPatient("Jane Smith", 25, "P124");
    system.displayPatients();
    system.addAppointment("P123", "2023-11-01", "10:00 AM", "Dr. Brown");
    system.addAppointment("P124", "2023-11-02", "11:00 AM", "Dr. White");
    system.displayAppointments();
    return 0;
}