#include <iostream>
#include <string>
using namespace std;

struct Appointment {
    int day, month, year, hour, minute;
    string reason;
};

struct Patient {
    int id;
    string name;
    int age;
    Appointment appointment;
};

Patient patients[100];
int patientCount = 0;

void addPatient() {
    if (patientCount < 100) {
        Patient p;
        cout << "Enter Patient ID: ";
        cin >> p.id;
        cout << "Enter Patient Name: ";
        cin.ignore();
        getline(cin, p.name);
        cout << "Enter Patient Age: ";
        cin >> p.age;
        cout << "Enter Appointment Date (DD MM YYYY): ";
        cin >> p.appointment.day >> p.appointment.month >> p.appointment.year;
        cout << "Enter Appointment Time (HH MM): ";
        cin >> p.appointment.hour >> p.appointment.minute;
        cout << "Enter Appointment Reason: ";
        cin.ignore();
        getline(cin, p.appointment.reason);
        patients[patientCount++] = p;
        cout << "Patient added successfully.\n";
    } else {
        cout << "Patient list is full!\n";
    }
}

void deletePatient() {
    int id;
    cout << "Enter Patient ID to delete: ";
    cin >> id;
    for (int i = 0; i < patientCount; ++i) {
        if (patients[i].id == id) {
            for (int j = i; j < patientCount - 1; ++j) {
                patients[j] = patients[j + 1];
            }
            patientCount--;
            cout << "Patient deleted successfully.\n";
            return;
        }
    }
    cout << "Patient not found.\n";
}

void updateAppointment() {
    int id;
    cout << "Enter Patient ID to update: ";
    cin >> id;
    for (int i = 0; i < patientCount; ++i) {
        if (patients[i].id == id) {
            cout << "Enter new Appointment Date (DD MM YYYY): ";
            cin >> patients[i].appointment.day >> patients[i].appointment.month >> patients[i].appointment.year;
            cout << "Enter new Appointment Time (HH MM): ";
            cin >> patients[i].appointment.hour >> patients[i].appointment.minute;
            cout << "Enter new Appointment Reason: ";
            cin.ignore();
            getline(cin, patients[i].appointment.reason);
            cout << "Appointment updated successfully.\n";
            return;
        }
    }
    cout << "Patient not found.\n";
}

void searchPatient() {
    int id;
    cout << "Enter Patient ID to search: ";
    cin >> id;
    for (int i = 0; i < patientCount; ++i) {
        if (patients[i].id == id) {
            cout << "Patient ID: " << patients[i].id << endl;
            cout << "Name: " << patients[i].name << endl;
            cout << "Age: " << patients[i].age << endl;
            cout << "Appointment Date: " << patients[i].appointment.day << "/" << patients[i].appointment.month << "/" << patients[i].appointment.year << endl;
            cout << "Appointment Time: " << patients[i].appointment.hour << ":" << patients[i].appointment.minute << endl;
            cout << "Reason: " << patients[i].appointment.reason << endl;
            return;
        }
    }
    cout << "Patient not found.\n";
}

void displayPatients() {
    if (patientCount == 0) {
        cout << "No patients found.\n";
    } else {
        for (int i = 0; i < patientCount; ++i) {
            cout << "Patient ID: " << patients[i].id << endl;
            cout << "Name: " << patients[i].name << endl;
            cout << "Age: " << patients[i].age << endl;
            cout << "Appointment Date: " << patients[i].appointment.day << "/" << patients[i].appointment.month << "/" << patients[i].appointment.year << endl;
            cout << "Appointment Time: " << patients[i].appointment.hour << ":" << patients[i].appointment.minute << endl;
            cout << "Reason: " << patients[i].appointment.reason << endl << endl;
        }
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Patient\n";
        cout << "2. Delete Patient\n";
        cout << "3. Update Appointment\n";
        cout << "4. Search Patient\n";
        cout << "5. Display All Patients\n";
        cout << "6. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addPatient(); break;
            case 2: deletePatient(); break;
            case 3: updateAppointment(); break;
            case 4: searchPatient(); break;
            case 5: displayPatients(); break;
            case 6: return 0;
            default: cout << "Invalid choice. Try again.\n";
        }
    }
}