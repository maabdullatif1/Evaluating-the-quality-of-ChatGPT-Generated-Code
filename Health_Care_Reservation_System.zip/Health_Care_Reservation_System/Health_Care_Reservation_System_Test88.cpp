#include <iostream>
#include <string>
#include <vector>

struct Patient {
    int id;
    std::string name;
    int age;
};

struct Appointment {
    int id;
    int patientId;
    std::string date;
    std::string time;
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;
    int patientIdCounter = 1;
    int appointmentIdCounter = 1;

    Patient* findPatientById(int id) {
        for (auto& patient : patients) {
            if (patient.id == id) return &patient;
        }
        return nullptr;
    }
    
    Appointment* findAppointmentById(int id) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) return &appointment;
        }
        return nullptr;
    }

public:
    void addPatient(const std::string& name, int age) {
        patients.push_back({patientIdCounter++, name, age});
    }

    void deletePatient(int id) {
        patients.erase(std::remove_if(patients.begin(), patients.end(),
                                      [id](const Patient& p) { return p.id == id; }), patients.end());
        appointments.erase(std::remove_if(appointments.begin(), appointments.end(),
                                          [id](const Appointment& a) { return a.patientId == id; }), appointments.end());
    }

    void updatePatient(int id, const std::string& name, int age) {
        Patient* patient = findPatientById(id);
        if (patient) {
            patient->name = name;
            patient->age = age;
        }
    }

    void displayPatients() const {
        for (const auto& patient : patients) {
            std::cout << "Patient ID: " << patient.id 
                      << ", Name: " << patient.name 
                      << ", Age: " << patient.age << std::endl;
        }
    }

    void addAppointment(int patientId, const std::string& date, const std::string& time) {
        if (findPatientById(patientId)) {
            appointments.push_back({appointmentIdCounter++, patientId, date, time});
        }
    }

    void deleteAppointment(int id) {
        appointments.erase(std::remove_if(appointments.begin(), appointments.end(),
                                          [id](const Appointment& a) { return a.id == id; }), appointments.end());
    }

    void updateAppointment(int id, const std::string& date, const std::string& time) {
        Appointment* appointment = findAppointmentById(id);
        if (appointment) {
            appointment->date = date;
            appointment->time = time;
        }
    }

    void displayAppointments() const {
        for (const auto& appointment : appointments) {
            std::cout << "Appointment ID: " << appointment.id 
                      << ", Patient ID: " << appointment.patientId 
                      << ", Date: " << appointment.date 
                      << ", Time: " << appointment.time << std::endl;
        }
    }

    void searchPatientByName(const std::string& name) const {
        for (const auto& patient : patients) {
            if (patient.name == name) {
                std::cout << "Found Patient - ID: " << patient.id 
                          << ", Name: " << patient.name 
                          << ", Age: " << patient.age << std::endl;
            }
        }
    }
};

int main() {
    HealthCareSystem hcs;
    hcs.addPatient("Alice", 30);
    hcs.addPatient("Bob", 25);
    hcs.addAppointment(1, "2023-10-01", "10:00");
    hcs.addAppointment(2, "2023-10-02", "11:00");
    hcs.displayPatients();
    hcs.displayAppointments();
    hcs.searchPatientByName("Alice");
    hcs.updatePatient(1, "Alice Johnson", 31);
    hcs.updateAppointment(1, "2023-10-05", "10:30");
    hcs.displayPatients();
    hcs.displayAppointments();
    hcs.deleteAppointment(1);
    hcs.deletePatient(2);
    hcs.displayPatients();
    hcs.displayAppointments();
    return 0;
}