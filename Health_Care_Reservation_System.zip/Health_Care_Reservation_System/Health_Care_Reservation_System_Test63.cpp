#include <iostream>
#include <string>
using namespace std;

struct Patient {
    int id;
    string name;
    int age;
};

struct Appointment {
    int id;
    int patientId;
    string date;
    string time;
};

class HealthCareSystem {
private:
    Patient patients[100];
    Appointment appointments[100];
    int patientCount;
    int appointmentCount;

public:
    HealthCareSystem() : patientCount(0), appointmentCount(0) {}

    void addPatient(int id, string name, int age) {
        patients[patientCount++] = {id, name, age};
    }

    void deletePatient(int id) {
        for (int i = 0; i < patientCount; i++) {
            if (patients[i].id == id) {
                for (int j = i; j < patientCount - 1; j++) {
                    patients[j] = patients[j + 1];
                }
                patientCount--;
                break;
            }
        }
    }

    void updatePatient(int id, string name, int age) {
        for (int i = 0; i < patientCount; i++) {
            if (patients[i].id == id) {
                patients[i] = {id, name, age};
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (int i = 0; i < patientCount; i++) {
            if (patients[i].id == id) {
                return &patients[i];
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (int i = 0; i < patientCount; i++) {
            cout << "ID: " << patients[i].id << ", Name: " << patients[i].name << ", Age: " << patients[i].age << endl;
        }
    }

    void addAppointment(int id, int patientId, string date, string time) {
        appointments[appointmentCount++] = {id, patientId, date, time};
    }

    void deleteAppointment(int id) {
        for (int i = 0; i < appointmentCount; i++) {
            if (appointments[i].id == id) {
                for (int j = i; j < appointmentCount - 1; j++) {
                    appointments[j] = appointments[j + 1];
                }
                appointmentCount--;
                break;
            }
        }
    }

    void updateAppointment(int id, int patientId, string date, string time) {
        for (int i = 0; i < appointmentCount; i++) {
            if (appointments[i].id == id) {
                appointments[i] = {id, patientId, date, time};
                break;
            }
        }
    }

    Appointment* searchAppointment(int id) {
        for (int i = 0; i < appointmentCount; i++) {
            if (appointments[i].id == id) {
                return &appointments[i];
            }
        }
        return nullptr;
    }

    void displayAppointments() {
        for (int i = 0; i < appointmentCount; i++) {
            cout << "ID: " << appointments[i].id << ", Patient ID: " << appointments[i].patientId 
                 << ", Date: " << appointments[i].date << ", Time: " << appointments[i].time << endl;
        }
    }
};

int main() {
    HealthCareSystem system;

    system.addPatient(1, "John Doe", 30);
    system.addPatient(2, "Jane Smith", 40);

    system.displayPatients();

    system.addAppointment(1, 1, "2023-11-01", "10:00");
    system.addAppointment(2, 2, "2023-11-01", "11:00");

    system.displayAppointments();

    return 0;
}