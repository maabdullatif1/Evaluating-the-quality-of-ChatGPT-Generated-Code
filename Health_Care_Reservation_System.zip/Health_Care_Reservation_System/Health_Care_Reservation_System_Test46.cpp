#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Patient {
public:
    string id;
    string name;
    int age;
    string gender;

    Patient(string id, string name, int age, string gender)
        : id(id), name(name), age(age), gender(gender) {}
};

class Appointment {
public:
    string id;
    string patientId;
    string date;
    string time;
    string doctor;

    Appointment(string id, string patientId, string date, string time, string doctor)
        : id(id), patientId(patientId), date(date), time(time), doctor(doctor) {}
};

class HealthcareReservationSystem {
private:
    vector<Patient> patients;
    vector<Appointment> appointments;

    int findPatientIndexById(const string& id) {
        for (int i = 0; i < patients.size(); ++i) {
            if (patients[i].id == id) return i;
        }
        return -1;
    }

    int findAppointmentIndexById(const string& id) {
        for (int i = 0; i < appointments.size(); ++i) {
            if (appointments[i].id == id) return i;
        }
        return -1;
    }

public:
    void addPatient(const string& id, const string& name, int age, const string& gender) {
        patients.push_back(Patient(id, name, age, gender));
    }

    void deletePatient(const string& id) {
        int index = findPatientIndexById(id);
        if (index != -1) patients.erase(patients.begin() + index);
    }

    void updatePatient(const string& id, const string& name, int age, const string& gender) {
        int index = findPatientIndexById(id);
        if (index != -1) patients[index] = Patient(id, name, age, gender);
    }

    Patient* searchPatient(const string& id) {
        int index = findPatientIndexById(id);
        if (index != -1) return &patients[index];
        return nullptr;
    }

    void addAppointment(const string& id, const string& patientId, const string& date, const string& time, const string& doctor) {
        appointments.push_back(Appointment(id, patientId, date, time, doctor));
    }

    void deleteAppointment(const string& id) {
        int index = findAppointmentIndexById(id);
        if (index != -1) appointments.erase(appointments.begin() + index);
    }

    void updateAppointment(const string& id, const string& patientId, const string& date, const string& time, const string& doctor) {
        int index = findAppointmentIndexById(id);
        if (index != -1) appointments[index] = Appointment(id, patientId, date, time, doctor);
    }

    Appointment* searchAppointment(const string& id) {
        int index = findAppointmentIndexById(id);
        if (index != -1) return &appointments[index];
        return nullptr;
    }

    void displayPatients() {
        for (auto& patient : patients) {
            cout << "ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << ", Gender: " << patient.gender << endl;
        }
    }

    void displayAppointments() {
        for (auto& appointment : appointments) {
            cout << "ID: " << appointment.id << ", Patient ID: " << appointment.patientId << ", Date: " << appointment.date << ", Time: " << appointment.time << ", Doctor: " << appointment.doctor << endl;
        }
    }
};

int main() {
    HealthcareReservationSystem system;
    system.addPatient("P001", "John Doe", 30, "Male");
    system.addPatient("P002", "Jane Smith", 28, "Female");
    system.addAppointment("A001", "P001", "2023-11-01", "10:00", "Dr. Brown");
    system.addAppointment("A002", "P002", "2023-11-02", "11:00", "Dr. Green");

    Patient* patient = system.searchPatient("P001");
    if (patient) cout << "Found Patient: " << patient->name << endl;

    Appointment* appointment = system.searchAppointment("A002");
    if (appointment) cout << "Found Appointment on: " << appointment->date << endl;

    system.displayPatients();
    system.displayAppointments();

    return 0;
}