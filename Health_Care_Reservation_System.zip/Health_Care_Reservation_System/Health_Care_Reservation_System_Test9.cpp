#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Appointment {
public:
    int id;
    string patientName;
    string doctorName;
    string date;
    string time;
    
    Appointment(int id, string patientName, string doctorName, string date, string time)
    : id(id), patientName(patientName), doctorName(doctorName), date(date), time(time) {}
};

class Patient {
public:
    int id;
    string name;
    int age;
    string gender;

    Patient(int id, string name, int age, string gender)
    : id(id), name(name), age(age), gender(gender) {}
};

class HealthcareSystem {
private:
    vector<Patient> patients;
    vector<Appointment> appointments;
    int patientIdCounter = 1;
    int appointmentIdCounter = 1;

public:
    void addPatient(string name, int age, string gender) {
        patients.push_back(Patient(patientIdCounter++, name, age, gender));
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); it++) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, string name, int age, string gender) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                patient.gender = gender;
                break;
            }
        }
    }

    void searchPatient(int id) {
        for (const auto &patient : patients) {
            if (patient.id == id) {
                cout << "Patient Found: " << patient.name << ", " << patient.age << ", " << patient.gender << endl;
                return;
            }
        }
        cout << "Patient not found." << endl;
    }

    void displayPatients() {
        for (const auto &patient : patients) {
            cout << "ID: " << patient.id << ", Name: " << patient.name 
                 << ", Age: " << patient.age << ", Gender: " << patient.gender << endl;
        }
    }

    void addAppointment(int patientId, string doctorName, string date, string time) {
        for (const auto &patient : patients) {
            if (patient.id == patientId) {
                appointments.push_back(Appointment(appointmentIdCounter++, patient.name, doctorName, date, time));
                return;
            }
        }
        cout << "Patient ID not found. Appointment not added." << endl;
    }

    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); it++) {
            if (it->id == id) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int id, int patientId, string doctorName, string date, string time) {
        for (auto &appointment : appointments) {
            if (appointment.id == id) {
                for (const auto &patient : patients) {
                    if (patient.id == patientId) {
                        appointment.patientName = patient.name;
                        appointment.doctorName = doctorName;
                        appointment.date = date;
                        appointment.time = time;
                        return;
                    }
                }
                cout << "Patient ID not found. Appointment not updated." << endl;
                return;
            }
        }
        cout << "Appointment ID not found." << endl;
    }

    void searchAppointment(int id) {
        for (const auto &appointment : appointments) {
            if (appointment.id == id) {
                cout << "Appointment Found: " << appointment.patientName << " with " 
                     << appointment.doctorName << " on " << appointment.date 
                     << " at " << appointment.time << endl;
                return;
            }
        }
        cout << "Appointment not found." << endl;
    }

    void displayAppointments() {
        for (const auto &appointment : appointments) {
            cout << "ID: " << appointment.id << ", Patient: " << appointment.patientName 
                 << ", Doctor: " << appointment.doctorName << ", Date: " << appointment.date 
                 << ", Time: " << appointment.time << endl;
        }
    }
};

int main() {
    HealthcareSystem system;
    
    system.addPatient("John Doe", 30, "Male");
    system.addPatient("Jane Smith", 25, "Female");
    
    system.addAppointment(1, "Dr. Brown", "2023-10-22", "10:00 AM");
    system.addAppointment(2, "Dr. White", "2023-10-23", "11:00 AM");
    
    cout << "Patients List:" << endl;
    system.displayPatients();
    
    cout << "\nAppointments List:" << endl;
    system.displayAppointments();
    
    return 0;
}