#include <iostream>
#include <vector>
#include <string>

struct Patient {
    int id;
    std::string name;
    int age;
    std::string ailment;
};

struct Appointment {
    int id;
    int patientId;
    std::string date;
    std::string time;
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;
    int patientIdCounter = 1;
    int appointmentIdCounter = 1;

public:
    void addPatient(const std::string& name, int age, const std::string& ailment) {
        Patient patient = { patientIdCounter++, name, age, ailment };
        patients.push_back(patient);
    }
    
    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }
    
    void updatePatient(int id, const std::string& name, int age, const std::string& ailment) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                patient.ailment = ailment;
                break;
            }
        }
    }
    
    void addAppointment(int patientId, const std::string& date, const std::string& time) {
        Appointment appointment = { appointmentIdCounter++, patientId, date, time };
        appointments.push_back(appointment);
    }
    
    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->id == id) {
                appointments.erase(it);
                break;
            }
        }
    }
    
    void updateAppointment(int id, const std::string& date, const std::string& time) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) {
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }
    
    Patient* searchPatient(int id) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }
    
    void displayPatients() {
        for (const auto& patient : patients) {
            std::cout << "ID: " << patient.id << " Name: " << patient.name << " Age: " << patient.age << " Ailment: " << patient.ailment << std::endl;
        }
    }
    
    void displayAppointments() {
        for (const auto& appointment : appointments) {
            std::cout << "ID: " << appointment.id << " Patient ID: " << appointment.patientId << " Date: " << appointment.date << " Time: " << appointment.time << std::endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("Alice", 30, "Flu");
    system.addPatient("Bob", 40, "Headache");
    system.displayPatients();
    system.addAppointment(1, "2023-01-01", "10:00");
    system.addAppointment(2, "2023-01-02", "11:00");
    system.displayAppointments();
    return 0;
}