#include <iostream>
#include <vector>
#include <string>

class Patient {
public:
    int id;
    std::string name;
    std::string disease;
    Patient(int id, std::string name, std::string disease) 
        : id(id), name(name), disease(disease) {}
};

class Appointment {
public:
    int patientId;
    std::string date;
    std::string time;
    Appointment(int patientId, std::string date, std::string time) 
        : patientId(patientId), date(date), time(time) {}
};

class HealthCareSystem {
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;
    
    int findPatientIndex(int id) {
        for (size_t i = 0; i < patients.size(); ++i) {
            if (patients[i].id == id) return i;
        }
        return -1;
    }

    int findAppointmentIndex(int patientId) {
        for (size_t i = 0; i < appointments.size(); ++i) {
            if (appointments[i].patientId == patientId) return i;
        }
        return -1;
    }

public:
    void addPatient(int id, std::string name, std::string disease) {
        if (findPatientIndex(id) == -1) {
            patients.emplace_back(id, name, disease);
        } else {
            std::cout << "Patient with ID " << id << " already exists.\n";
        }
    }
    
    void updatePatient(int id, std::string name, std::string disease) {
        int idx = findPatientIndex(id);
        if (idx != -1) {
            patients[idx].name = name;
            patients[idx].disease = disease;
        } else {
            std::cout << "Patient with ID " << id << " not found.\n";
        }
    }
    
    void deletePatient(int id) {
        int idx = findPatientIndex(id);
        if (idx != -1) {
            patients.erase(patients.begin() + idx);
            
            int appointmentIndex = findAppointmentIndex(id);
            if (appointmentIndex != -1) {
                appointments.erase(appointments.begin() + appointmentIndex);
            }
        } else {
            std::cout << "Patient with ID " << id << " not found.\n";
        }
    }
    
    void searchPatient(int id) {
        int idx = findPatientIndex(id);
        if (idx != -1) {
            std::cout << "Patient ID: " << patients[idx].id 
                      << ", Name: " << patients[idx].name 
                      << ", Disease: " << patients[idx].disease << "\n";
        } else {
            std::cout << "Patient with ID " << id << " not found.\n";
        }
    }
    
    void displayPatients() {
        for (const auto& patient : patients) {
            std::cout << "Patient ID: " << patient.id 
                      << ", Name: " << patient.name 
                      << ", Disease: " << patient.disease << "\n";
        }
    }

    void addAppointment(int patientId, std::string date, std::string time) {
        if (findPatientIndex(patientId) != -1 && findAppointmentIndex(patientId) == -1) {
            appointments.emplace_back(patientId, date, time);
        } else {
            std::cout << "Cannot add appointment for patient ID " << patientId << ".\n";
        }
    }

    void updateAppointment(int patientId, std::string date, std::string time) {
        int idx = findAppointmentIndex(patientId);
        if (idx != -1) {
            appointments[idx].date = date;
            appointments[idx].time = time;
        } else {
            std::cout << "Appointment for patient ID " << patientId << " not found.\n";
        }
    }

    void deleteAppointment(int patientId) {
        int idx = findAppointmentIndex(patientId);
        if (idx != -1) {
            appointments.erase(appointments.begin() + idx);
        } else {
            std::cout << "Appointment for patient ID " << patientId << " not found.\n";
        }
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            std::cout << "Appointment for Patient ID: " << appointment.patientId 
                      << ", Date: " << appointment.date 
                      << ", Time: " << appointment.time << "\n";
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient(1, "John Doe", "Flu");
    system.addPatient(2, "Jane Smith", "Cold");
    system.addAppointment(1, "2023-10-15", "10:00 AM");
    system.updatePatient(2, "Jane Doe", "Allergy");
    system.displayPatients();
    system.displayAppointments();
    system.searchPatient(2);
    system.deleteAppointment(1);
    system.deletePatient(1);
    system.displayPatients();
    system.displayAppointments();
    return 0;
}