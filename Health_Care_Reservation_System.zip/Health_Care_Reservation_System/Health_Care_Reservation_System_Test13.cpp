#include <iostream>
#include <string>
#include <vector>

class Patient {
public:
    int id;
    std::string name;
    std::string dateOfBirth;
    std::string phoneNumber;

    Patient(int pid, std::string pname, std::string dob, std::string phone)
        : id(pid), name(pname), dateOfBirth(dob), phoneNumber(phone) {}
};

class Appointment {
public:
    int patientId;
    std::string date;
    std::string time;

    Appointment(int pid, std::string adate, std::string atime)
        : patientId(pid), date(adate), time(atime) {}
};

class HealthcareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;

public:
    void addPatient(int id, std::string name, std::string dob, std::string phone) {
        patients.push_back(Patient(id, name, dob, phone));
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, std::string name, std::string dob, std::string phone) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.dateOfBirth = dob;
                patient.phoneNumber = phone;
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (const auto &patient : patients) {
            std::cout << "ID: " << patient.id
                      << ", Name: " << patient.name
                      << ", DOB: " << patient.dateOfBirth
                      << ", Phone: " << patient.phoneNumber << std::endl;
        }
    }

    void addAppointment(int pid, std::string date, std::string time) {
        appointments.push_back(Appointment(pid, date, time));
    }

    void deleteAppointment(int pid, std::string date, std::string time) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->patientId == pid && it->date == date && it->time == time) {
                appointments.erase(it);
                break;
            }
        }
    }

    Appointment* searchAppointment(int pid, std::string date) {
        for (auto &appointment : appointments) {
            if (appointment.patientId == pid && appointment.date == date) {
                return &appointment;
            }
        }
        return nullptr;
    }

    void displayAppointments() {
        for (const auto &appointment : appointments) {
            std::cout << "Patient ID: " << appointment.patientId
                      << ", Date: " << appointment.date
                      << ", Time: " << appointment.time << std::endl;
        }
    }
};

int main() {
    HealthcareSystem system;
    system.addPatient(1, "John Doe", "1990-01-01", "555-1234");
    system.addAppointment(1, "2023-10-20", "10:00 AM");

    system.displayPatients();
    system.displayAppointments();

    return 0;
}