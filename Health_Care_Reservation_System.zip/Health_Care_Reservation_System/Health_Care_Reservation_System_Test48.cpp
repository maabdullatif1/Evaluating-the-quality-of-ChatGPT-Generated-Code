#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Patient {
public:
    int patientID;
    string name;
    int age;
    string condition;

    Patient(int id, string n, int a, string c) : patientID(id), name(n), age(a), condition(c) {}
};

class Appointment {
public:
    int appointmentID;
    int patientID;
    string date;
    string time;
    string doctorName;

    Appointment(int aID, int pID, string d, string t, string doc)
        : appointmentID(aID), patientID(pID), date(d), time(t), doctorName(doc) {}
};

class HealthCareReservationSystem {
    vector<Patient> patients;
    vector<Appointment> appointments;

public:
    void addPatient(int id, string name, int age, string condition) {
        patients.push_back(Patient(id, name, age, condition));
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->patientID == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, string name, int age, string condition) {
        for (auto &patient : patients) {
            if (patient.patientID == id) {
                patient.name = name;
                patient.age = age;
                patient.condition = condition;
                break;
            }
        }
    }

    Patient *searchPatient(int id) {
        for (auto &patient : patients) {
            if (patient.patientID == id) {
                return &patient;
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (const auto &patient : patients) {
            cout << "ID: " << patient.patientID << ", Name: " << patient.name << ", Age: " << patient.age
                 << ", Condition: " << patient.condition << endl;
        }
    }

    void addAppointment(int aID, int pID, string date, string time, string doctor) {
        appointments.push_back(Appointment(aID, pID, date, time, doctor));
    }

    void deleteAppointment(int aID) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->appointmentID == aID) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int aID, string date, string time, string doctor) {
        for (auto &appointment : appointments) {
            if (appointment.appointmentID == aID) {
                appointment.date = date;
                appointment.time = time;
                appointment.doctorName = doctor;
                break;
            }
        }
    }

    Appointment *searchAppointment(int aID) {
        for (auto &appointment : appointments) {
            if (appointment.appointmentID == aID) {
                return &appointment;
            }
        }
        return nullptr;
    }

    void displayAppointments() {
        for (const auto &appointment : appointments) {
            cout << "Appointment ID: " << appointment.appointmentID << ", Patient ID: " << appointment.patientID
                 << ", Date: " << appointment.date << ", Time: " << appointment.time
                 << ", Doctor: " << appointment.doctorName << endl;
        }
    }
};

int main() {
    HealthCareReservationSystem system;
    system.addPatient(1, "John Doe", 30, "Flu");
    system.addPatient(2, "Jane Smith", 40, "Cold");
    system.displayPatients();

    system.addAppointment(1, 1, "2023-11-01", "10:00", "Dr. Brown");
    system.addAppointment(2, 2, "2023-11-02", "11:00", "Dr. Green");
    system.displayAppointments();

    return 0;
}