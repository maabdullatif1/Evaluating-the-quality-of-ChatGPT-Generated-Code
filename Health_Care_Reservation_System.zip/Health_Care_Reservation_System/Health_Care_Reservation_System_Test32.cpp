#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Patient {
    string id;
    string name;
    int age;
    string gender;

public:
    Patient(string id, string name, int age, string gender)
        : id(id), name(name), age(age), gender(gender) {}

    string getId() const { return id; }
    string getName() const { return name; }
    int getAge() const { return age; }
    string getGender() const { return gender; }

    void setName(string newName) { name = newName; }
    void setAge(int newAge) { age = newAge; }
    void setGender(string newGender) { gender = newGender; }

    void display() const {
        cout << "ID: " << id << ", Name: " << name << ", Age: " << age << ", Gender: " << gender << endl;
    }
};

class Appointment {
    string id;
    string patientId;
    string date;
    string time;

public:
    Appointment(string id, string patientId, string date, string time)
        : id(id), patientId(patientId), date(date), time(time) {}

    string getId() const { return id; }
    string getPatientId() const { return patientId; }
    string getDate() const { return date; }
    string getTime() const { return time; }

    void setDate(string newDate) { date = newDate; }
    void setTime(string newTime) { time = newTime; }

    void display() const {
        cout << "ID: " << id << ", Patient ID: " << patientId << ", Date: " << date << ", Time: " << time << endl;
    }
};

class HealthCareSystem {
    vector<Patient> patients;
    vector<Appointment> appointments;

public:
    void addPatient(const Patient& patient) {
        patients.push_back(patient);
    }

    void deletePatient(const string& patientId) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->getId() == patientId) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(const string& patientId, const string& name, int age, const string& gender) {
        for (auto& p : patients) {
            if (p.getId() == patientId) {
                p.setName(name);
                p.setAge(age);
                p.setGender(gender);
                break;
            }
        }
    }

    Patient* searchPatient(const string& patientId) {
        for (auto& p : patients) {
            if (p.getId() == patientId) {
                return &p;
            }
        }
        return nullptr;
    }

    void addAppointment(const Appointment& appointment) {
        appointments.push_back(appointment);
    }

    void deleteAppointment(const string& appointmentId) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->getId() == appointmentId) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(const string& appointmentId, const string& date, const string& time) {
        for (auto& a : appointments) {
            if (a.getId() == appointmentId) {
                a.setDate(date);
                a.setTime(time);
                break;
            }
        }
    }

    Appointment* searchAppointment(const string& appointmentId) {
        for (auto& a : appointments) {
            if (a.getId() == appointmentId) {
                return &a;
            }
        }
        return nullptr;
    }

    void displayPatients() const {
        for (const auto& p : patients) {
            p.display();
        }
    }

    void displayAppointments() const {
        for (const auto& a : appointments) {
            a.display();
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient(Patient("P1", "John Doe", 30, "Male"));
    system.addPatient(Patient("P2", "Jane Doe", 28, "Female"));
    system.addAppointment(Appointment("A1", "P1", "2023-10-10", "09:00"));
    system.addAppointment(Appointment("A2", "P2", "2023-10-11", "10:00"));

    cout << "Patients:" << endl;
    system.displayPatients();
    cout << "\nAppointments:" << endl;
    system.displayAppointments();

    Patient* patient = system.searchPatient("P1");
    if (patient) {
        patient->setName("John Smith");
    }

    Appointment* appointment = system.searchAppointment("A1");
    if (appointment) {
        appointment->setDate("2023-10-15");
    }

    cout << "\nUpdated Patients:" << endl;
    system.displayPatients();
    cout << "\nUpdated Appointments:" << endl;
    system.displayAppointments();

    return 0;
}