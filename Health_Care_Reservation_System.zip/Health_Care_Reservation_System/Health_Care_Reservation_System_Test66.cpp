#include <iostream>
#include <string>

using namespace std;

struct Appointment {
    string date;
    string time;
    string doctor;
};

struct Patient {
    string name;
    int age;
    string gender;
    string phone;
    Appointment appointment;
};

Patient patients[100];
int patientCount = 0;

void addPatient() {
    if (patientCount >= 100) {
        cout << "Patient list is full." << endl;
        return;
    }
    cout << "Enter patient name: ";
    cin >> patients[patientCount].name;
    cout << "Enter age: ";
    cin >> patients[patientCount].age;
    cout << "Enter gender: ";
    cin >> patients[patientCount].gender;
    cout << "Enter phone: ";
    cin >> patients[patientCount].phone;
    cout << "Enter appointment date (YYYY-MM-DD): ";
    cin >> patients[patientCount].appointment.date;
    cout << "Enter appointment time (HH:MM): ";
    cin >> patients[patientCount].appointment.time;
    cout << "Enter doctor's name: ";
    cin >> patients[patientCount].appointment.doctor;
    patientCount++;
    cout << "Patient added successfully." << endl;
}

void deletePatient() {
    string name;
    cout << "Enter patient name to delete: ";
    cin >> name;
    for (int i = 0; i < patientCount; ++i) {
        if (patients[i].name == name) {
            for (int j = i; j < patientCount - 1; ++j) {
                patients[j] = patients[j + 1];
            }
            patientCount--;
            cout << "Patient deleted successfully." << endl;
            return;
        }
    }
    cout << "Patient not found." << endl;
}

void updatePatient() {
    string name;
    cout << "Enter patient name to update: ";
    cin >> name;
    for (int i = 0; i < patientCount; ++i) {
        if (patients[i].name == name) {
            cout << "Enter new age: ";
            cin >> patients[i].age;
            cout << "Enter new gender: ";
            cin >> patients[i].gender;
            cout << "Enter new phone: ";
            cin >> patients[i].phone;
            cout << "Enter new appointment date (YYYY-MM-DD): ";
            cin >> patients[i].appointment.date;
            cout << "Enter new appointment time (HH:MM): ";
            cin >> patients[i].appointment.time;
            cout << "Enter new doctor's name: ";
            cin >> patients[i].appointment.doctor;
            cout << "Patient updated successfully." << endl;
            return;
        }
    }
    cout << "Patient not found." << endl;
}

void searchPatient() {
    string name;
    cout << "Enter patient name to search: ";
    cin >> name;
    for (int i = 0; i < patientCount; ++i) {
        if (patients[i].name == name) {
            cout << "Name: " << patients[i].name << endl;
            cout << "Age: " << patients[i].age << endl;
            cout << "Gender: " << patients[i].gender << endl;
            cout << "Phone: " << patients[i].phone << endl;
            cout << "Appointment Date: " << patients[i].appointment.date << endl;
            cout << "Appointment Time: " << patients[i].appointment.time << endl;
            cout << "Doctor: " << patients[i].appointment.doctor << endl;
            return;
        }
    }
    cout << "Patient not found." << endl;
}

void displayPatients() {
    for (int i = 0; i < patientCount; ++i) {
        cout << "Patient " << i + 1 << endl;
        cout << "Name: " << patients[i].name << endl;
        cout << "Age: " << patients[i].age << endl;
        cout << "Gender: " << patients[i].gender << endl;
        cout << "Phone: " << patients[i].phone << endl;
        cout << "Appointment Date: " << patients[i].appointment.date << endl;
        cout << "Appointment Time: " << patients[i].appointment.time << endl;
        cout << "Doctor: " << patients[i].appointment.doctor << endl;
        cout << "-------------------------" << endl;
    }
    if (patientCount == 0) {
        cout << "No patients available." << endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Patient" << endl;
        cout << "2. Delete Patient" << endl;
        cout << "3. Update Patient" << endl;
        cout << "4. Search Patient" << endl;
        cout << "5. Display All Patients" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addPatient(); break;
            case 2: deletePatient(); break;
            case 3: updatePatient(); break;
            case 4: searchPatient(); break;
            case 5: displayPatients(); break;
            case 6: return 0;
            default: cout << "Invalid choice." << endl;
        }
    }
}