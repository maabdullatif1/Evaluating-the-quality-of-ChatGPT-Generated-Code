#include <iostream>
#include <string>

struct Patient {
    int id;
    std::string name;
    int age;
    std::string condition;
};

struct Appointment {
    int id;
    int patient_id;
    std::string date;
    std::string time;
};

class HealthcareSystem {
private:
    Patient patients[100];
    Appointment appointments[100];
    int patientCount = 0;
    int appointmentCount = 0;
    
public:
    void addPatient(int id, std::string name, int age, std::string condition) {
        patients[patientCount++] = {id, name, age, condition};
    }

    void deletePatient(int id) {
        for (int i = 0; i < patientCount; ++i) {
            if (patients[i].id == id) {
                patients[i] = patients[--patientCount];
                break;
            }
        }
    }

    void updatePatient(int id, std::string name, int age, std::string condition) {
        for (int i = 0; i < patientCount; ++i) {
            if (patients[i].id == id) {
                patients[i] = {id, name, age, condition};
                break;
            }
        }
    }

    void searchPatient(int id) {
        for (int i = 0; i < patientCount; ++i) {
            if (patients[i].id == id) {
                std::cout << "ID: " << patients[i].id << ", Name: " << patients[i].name
                          << ", Age: " << patients[i].age << ", Condition: " << patients[i].condition << std::endl;
                return;
            }
        }
        std::cout << "Patient not found." << std::endl;
    }

    void displayPatients() {
        for (int i = 0; i < patientCount; ++i) {
            std::cout << "ID: " << patients[i].id << ", Name: " << patients[i].name
                      << ", Age: " << patients[i].age << ", Condition: " << patients[i].condition << std::endl;
        }
    }

    void addAppointment(int id, int patient_id, std::string date, std::string time) {
        appointments[appointmentCount++] = {id, patient_id, date, time};
    }

    void deleteAppointment(int id) {
        for (int i = 0; i < appointmentCount; ++i) {
            if (appointments[i].id == id) {
                appointments[i] = appointments[--appointmentCount];
                break;
            }
        }
    }

    void updateAppointment(int id, int patient_id, std::string date, std::string time) {
        for (int i = 0; i < appointmentCount; ++i) {
            if (appointments[i].id == id) {
                appointments[i] = {id, patient_id, date, time};
                break;
            }
        }
    }

    void searchAppointment(int id) {
        for (int i = 0; i < appointmentCount; ++i) {
            if (appointments[i].id == id) {
                std::cout << "ID: " << appointments[i].id << ", Patient ID: " << appointments[i].patient_id
                          << ", Date: " << appointments[i].date << ", Time: " << appointments[i].time << std::endl;
                return;
            }
        }
        std::cout << "Appointment not found." << std::endl;
    }

    void displayAppointments() {
        for (int i = 0; i < appointmentCount; ++i) {
            std::cout << "ID: " << appointments[i].id << ", Patient ID: " << appointments[i].patient_id
                      << ", Date: " << appointments[i].date << ", Time: " << appointments[i].time << std::endl;
        }
    }
};

int main() {
    HealthcareSystem hc;
    hc.addPatient(1, "John Doe", 30, "Flu");
    hc.addPatient(2, "Jane Smith", 25, "Cold");
    hc.displayPatients();

    hc.addAppointment(1, 1, "2023-10-15", "10:00");
    hc.addAppointment(2, 2, "2023-10-16", "11:00");
    hc.displayAppointments();

    hc.searchPatient(1);
    hc.searchAppointment(1);

    hc.updatePatient(1, "John Doe", 31, "Recovered");
    hc.updateAppointment(1, 1, "2023-10-17", "09:00");

    hc.displayPatients();
    hc.displayAppointments();

    hc.deletePatient(2);
    hc.deleteAppointment(2);

    hc.displayPatients();
    hc.displayAppointments();

    return 0;
}