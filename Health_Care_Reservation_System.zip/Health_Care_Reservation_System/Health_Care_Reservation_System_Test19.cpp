#include <iostream>
#include <string>
#include <vector>

class Patient {
public:
    std::string name;
    int age;
    std::string id;

    Patient(std::string n, int a, std::string i) : name(n), age(a), id(i) {}
};

class Appointment {
public:
    std::string patientId;
    std::string date;
    std::string time;

    Appointment(std::string pid, std::string d, std::string t) : patientId(pid), date(d), time(t) {}
};

class HealthCareSystem {
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;
    
public:
    void addPatient(std::string name, int age, std::string id) {
        patients.push_back(Patient(name, age, id));
    }

    void deletePatient(std::string id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(std::string id, std::string name, int age) {
        for (auto &p : patients) {
            if (p.id == id) {
                p.name = name;
                p.age = age;
                break;
            }
        }
    }

    Patient* searchPatient(std::string id) {
        for (auto &p : patients) {
            if (p.id == id) {
                return &p;
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (const auto &p : patients) {
            std::cout << "Name: " << p.name << ", Age: " << p.age << ", ID: " << p.id << std::endl;
        }
    }
    
    void addAppointment(std::string patientId, std::string date, std::string time) {
        appointments.push_back(Appointment(patientId, date, time));
    }
    
    void deleteAppointment(std::string patientId, std::string date) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->patientId == patientId && it->date == date) {
                appointments.erase(it);
                break;
            }
        }
    }
    
    Appointment* searchAppointment(std::string patientId, std::string date) {
        for (auto &a : appointments) {
            if (a.patientId == patientId && a.date == date) {
                return &a;
            }
        }
        return nullptr;
    }
    
    void displayAppointments() {
        for (const auto &a : appointments) {
            std::cout << "Patient ID: " << a.patientId << ", Date: " << a.date << ", Time: " << a.time << std::endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("John Doe", 30, "P001");
    system.addPatient("Jane Smith", 25, "P002");
    system.displayPatients();

    system.updatePatient("P001", "Johnathan Doe", 31);
    system.displayPatients();

    system.addAppointment("P001", "2024-05-01", "10:00");
    system.addAppointment("P002", "2024-05-01", "11:00");
    system.displayAppointments();

    system.deletePatient("P002");
    system.displayPatients();

    system.deleteAppointment("P001", "2024-05-01");
    system.displayAppointments();

    return 0;
}