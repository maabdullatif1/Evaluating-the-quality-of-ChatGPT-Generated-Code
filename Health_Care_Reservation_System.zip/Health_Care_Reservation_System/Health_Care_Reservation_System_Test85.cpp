#include <iostream>
#include <vector>
#include <string>

struct Patient {
    int id;
    std::string name;
    int age;
};

struct Appointment {
    int patientId;
    std::string date;
    std::string time;
};

class HealthCareSystem {
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;
    int patientCount = 0;

public:
    void addPatient(const std::string& name, int age) {
        patients.push_back({++patientCount, name, age});
    }

    void deletePatient(int patientId) {
        patients.erase(std::remove_if(patients.begin(), patients.end(),
            [&](const Patient& p) { return p.id == patientId; }), patients.end());
        appointments.erase(std::remove_if(appointments.begin(), appointments.end(),
            [&](const Appointment& a) { return a.patientId == patientId; }), appointments.end());
    }

    void updatePatient(int patientId, const std::string& name, int age) {
        for (auto& patient : patients) {
            if (patient.id == patientId) {
                patient.name = name;
                patient.age = age;
                break;
            }
        }
    }

    Patient* searchPatient(int patientId) {
        for (auto& patient : patients) {
            if (patient.id == patientId) {
                return &patient;
            }
        }
        return nullptr;
    }

    void addAppointment(int patientId, const std::string& date, const std::string& time) {
        appointments.push_back({patientId, date, time});
    }

    void deleteAppointment(int patientId, const std::string& date, const std::string& time) {
        appointments.erase(std::remove_if(appointments.begin(), appointments.end(),
            [&](const Appointment& a) { return a.patientId == patientId && a.date == date && a.time == time; }),
            appointments.end());
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            std::cout << "Patient ID: " << patient.id << ", Name: " << patient.name 
                      << ", Age: " << patient.age << std::endl;
        }
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            Patient* patient = searchPatient(appointment.patientId);
            if (patient) {
                std::cout << "Patient ID: " << appointment.patientId << ", Name: " << patient->name 
                          << ", Date: " << appointment.date << ", Time: " << appointment.time << std::endl;
            }
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("Alice", 30);
    system.addPatient("Bob", 25);
    system.addAppointment(1, "2023-10-01", "10:00");
    system.addAppointment(2, "2023-10-02", "11:00");
    system.displayPatients();
    system.displayAppointments();
    system.updatePatient(2, "Robert", 26);
    system.displayPatients();
    system.deleteAppointment(1, "2023-10-01", "10:00");
    system.displayAppointments();
    system.deletePatient(1);
    system.displayPatients();
}