#include <iostream>
#include <string>

struct Appointment {
    int id;
    std::string date;
    std::string time;
    std::string doctor;
};

struct Patient {
    int id;
    std::string name;
    int age;
    std::string gender;
    Appointment appointment;
};

class HealthCareSystem {
private:
    static const int maxPatients = 100;
    Patient patients[maxPatients];
    int patientCount;

public:
    HealthCareSystem() : patientCount(0) {}

    void addPatient(int id, std::string name, int age, std::string gender, int appId, std::string appDate, std::string appTime, std::string doc) {
        if (patientCount < maxPatients) {
            patients[patientCount].id = id;
            patients[patientCount].name = name;
            patients[patientCount].age = age;
            patients[patientCount].gender = gender;
            patients[patientCount].appointment.id = appId;
            patients[patientCount].appointment.date = appDate;
            patients[patientCount].appointment.time = appTime;
            patients[patientCount].appointment.doctor = doc;
            patientCount++;
        }
    }

    void deletePatient(int id) {
        for (int i = 0; i < patientCount; i++) {
            if (patients[i].id == id) {
                for (int j = i; j < patientCount - 1; j++) {
                    patients[j] = patients[j + 1];
                }
                patientCount--;
                break;
            }
        }
    }

    void updatePatient(int id, std::string name, int age, std::string gender, int appId, std::string appDate, std::string appTime, std::string doc) {
        for (int i = 0; i < patientCount; i++) {
            if (patients[i].id == id) {
                patients[i].name = name;
                patients[i].age = age;
                patients[i].gender = gender;
                patients[i].appointment.id = appId;
                patients[i].appointment.date = appDate;
                patients[i].appointment.time = appTime;
                patients[i].appointment.doctor = doc;
                break;
            }
        }
    }

    void searchPatient(int id) {
        for (int i = 0; i < patientCount; i++) {
            if (patients[i].id == id) {
                std::cout << "Patient found: " << patients[i].name << ", Age: " << patients[i].age << ", Gender: " << patients[i].gender << "\n";
                break;
            }
        }
    }

    void displayPatients() {
        for (int i = 0; i < patientCount; i++) {
            std::cout << "Patient ID: " << patients[i].id << ", Name: " << patients[i].name << ", Age: " << patients[i].age << ", Gender: " << patients[i].gender << "\n";
            std::cout << "Appointment ID: " << patients[i].appointment.id << ", Date: " << patients[i].appointment.date << ", Time: " << patients[i].appointment.time << ", Doctor: " << patients[i].appointment.doctor << "\n";
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient(1, "John Doe", 30, "Male", 101, "2023-11-01", "10:00", "Dr. Smith");
    system.addPatient(2, "Jane Smith", 25, "Female", 102, "2023-11-02", "11:00", "Dr. Adams");
    system.displayPatients();
    system.searchPatient(1);
    system.updatePatient(1, "John Doe", 31, "Male", 101, "2023-11-03", "12:00", "Dr. Brown");
    system.searchPatient(1);
    system.deletePatient(2);
    system.displayPatients();
    return 0;
}