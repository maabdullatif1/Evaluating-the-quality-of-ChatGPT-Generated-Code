#include <iostream>
#include <string>
#include <vector>

class Patient {
public:
    int id;
    std::string name;
    int age;
    
    Patient(int p_id, std::string p_name, int p_age) : id(p_id), name(p_name), age(p_age) {}
};

class Appointment {
public:
    int id;
    int patient_id;
    std::string date;
    std::string time;
    
    Appointment(int a_id, int p_id, std::string a_date, std::string a_time) 
    : id(a_id), patient_id(p_id), date(a_date), time(a_time) {}
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;
    int next_patient_id;
    int next_appointment_id;

public:
    HealthCareSystem() : next_patient_id(1), next_appointment_id(1) {}

    void addPatient(std::string name, int age) {
        patients.push_back(Patient(next_patient_id++, name, age));
    }

    void deletePatient(int patient_id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == patient_id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int patient_id, std::string name, int age) {
        for (auto& patient : patients) {
            if (patient.id == patient_id) {
                patient.name = name;
                patient.age = age;
                break;
            }
        }
    }

    Patient* searchPatient(int patient_id) {
        for (auto& patient : patients) {
            if (patient.id == patient_id) {
                return &patient;
            }
        }
        return nullptr;
    }

    void addAppointment(int patient_id, std::string date, std::string time) {
        appointments.push_back(Appointment(next_appointment_id++, patient_id, date, time));
    }

    void deleteAppointment(int appointment_id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->id == appointment_id) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int appointment_id, std::string date, std::string time) {
        for (auto& appointment : appointments) {
            if (appointment.id == appointment_id) {
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }

    Appointment* searchAppointment(int appointment_id) {
        for (auto& appointment : appointments) {
            if (appointment.id == appointment_id) {
                return &appointment;
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            std::cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << std::endl;
        }
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            std::cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patient_id
                      << ", Date: " << appointment.date << ", Time: " << appointment.time << std::endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    
    system.addPatient("John Doe", 30);
    system.addPatient("Jane Smith", 25);
    
    system.addAppointment(1, "2023-11-10", "10:00 AM");
    system.addAppointment(2, "2023-11-11", "11:30 AM");
    
    system.displayPatients();
    system.displayAppointments();
    
    system.updatePatient(1, "John D.", 31);
    system.updateAppointment(1, "2023-11-10", "11:00 AM");
    
    system.displayPatients();
    system.displayAppointments();
    
    system.deletePatient(2);
    system.deleteAppointment(2);
    
    system.displayPatients();
    system.displayAppointments();

    return 0;
}