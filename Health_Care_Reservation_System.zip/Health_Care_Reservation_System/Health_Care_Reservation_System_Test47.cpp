#include <iostream>
#include <vector>
#include <string>

class Patient {
public:
    int id;
    std::string name;
    int age;

    Patient(int pid, std::string pname, int page) : id(pid), name(pname), age(page) {}
};

class Appointment {
public:
    int id;
    int patientId;
    std::string date;
    std::string doctor;

    Appointment(int aid, int pid, std::string adate, std::string adoctor) : id(aid), patientId(pid), date(adate), doctor(adoctor) {}
};

class HealthcareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;

public:
    void addPatient(int id, std::string name, int age) {
        patients.push_back(Patient(id, name, age));
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, std::string name, int age) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                break;
            }
        }
    }

    void searchPatient(int id) {
        for (const auto &patient : patients) {
            if (patient.id == id) {
                std::cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << std::endl;
                return;
            }
        }
        std::cout << "Patient not found." << std::endl;
    }

    void displayPatients() {
        for (const auto &patient : patients) {
            std::cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << std::endl;
        }
    }

    void addAppointment(int id, int patientId, std::string date, std::string doctor) {
        appointments.push_back(Appointment(id, patientId, date, doctor));
    }

    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->id == id) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int id, std::string date, std::string doctor) {
        for (auto &appointment : appointments) {
            if (appointment.id == id) {
                appointment.date = date;
                appointment.doctor = doctor;
                break;
            }
        }
    }

    void searchAppointment(int id) {
        for (const auto &appointment : appointments) {
            if (appointment.id == id) {
                std::cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId
                          << ", Date: " << appointment.date << ", Doctor: " << appointment.doctor << std::endl;
                return;
            }
        }
        std::cout << "Appointment not found." << std::endl;
    }

    void displayAppointments() {
        for (const auto &appointment : appointments) {
            std::cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId
                      << ", Date: " << appointment.date << ", Doctor: " << appointment.doctor << std::endl;
        }
    }
};

int main() {
    HealthcareSystem hcs;
    hcs.addPatient(1, "John Doe", 30);
    hcs.addPatient(2, "Jane Smith", 25);
    hcs.displayPatients();
    hcs.addAppointment(1, 1, "2023-11-01", "Dr. Brown");
    hcs.addAppointment(2, 2, "2023-11-02", "Dr. Smith");
    hcs.displayAppointments();
    hcs.searchPatient(1);
    hcs.searchAppointment(2);
    hcs.updatePatient(1, "John Doe Jr.", 31);
    hcs.updateAppointment(1, "2023-11-03", "Dr. Adams");
    hcs.displayPatients();
    hcs.displayAppointments();
    hcs.deletePatient(2);
    hcs.deleteAppointment(2);
    hcs.displayPatients();
    hcs.displayAppointments();
    return 0;
}