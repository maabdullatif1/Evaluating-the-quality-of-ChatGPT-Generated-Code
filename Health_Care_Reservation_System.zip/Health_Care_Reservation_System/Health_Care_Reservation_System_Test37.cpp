#include <iostream>
#include <vector>
#include <string>

struct Patient {
    int id;
    std::string name;
    int age;
};

struct Appointment {
    int id;
    int patientId;
    std::string date;
    std::string time;
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;
    int patientIdCounter = 1;
    int appointmentIdCounter = 1;

public:
    void addPatient(const std::string& name, int age) {
        patients.push_back({ patientIdCounter++, name, age });
    }

    void deletePatient(int id) {
        for(auto it = patients.begin(); it != patients.end(); ++it) {
            if(it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, const std::string& name, int age) {
        for(auto& patient : patients) {
            if(patient.id == id) {
                patient.name = name;
                patient.age = age;
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for(auto& patient : patients) {
            if(patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for(const auto& patient : patients) {
            std::cout << "ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << "\n";
        }
    }

    void addAppointment(int patientId, const std::string& date, const std::string& time) {
        appointments.push_back({ appointmentIdCounter++, patientId, date, time });
    }

    void deleteAppointment(int id) {
        for(auto it = appointments.begin(); it != appointments.end(); ++it) {
            if(it->id == id) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int id, int patientId, const std::string& date, const std::string& time) {
        for(auto& appointment : appointments) {
            if(appointment.id == id) {
                appointment.patientId = patientId;
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }

    Appointment* searchAppointment(int id) {
        for(auto& appointment : appointments) {
            if(appointment.id == id) {
                return &appointment;
            }
        }
        return nullptr;
    }

    void displayAppointments() {
        for(const auto& appointment : appointments) {
            std::cout << "Appointment ID: " << appointment.id << ", Patient ID: "
                      << appointment.patientId << ", Date: " << appointment.date
                      << ", Time: " << appointment.time << "\n";
        }
    }
};

int main() {
    HealthCareSystem system;

    system.addPatient("John Doe", 30);
    system.addPatient("Jane Smith", 25);

    system.displayPatients();

    system.addAppointment(1, "2023-11-01", "10:00 AM");
    system.addAppointment(2, "2023-11-02", "02:00 PM");

    system.displayAppointments();

    Patient* patient = system.searchPatient(1);
    if(patient) {
        std::cout << "Found patient: " << patient->name << "\n";
    }

    Appointment* appointment = system.searchAppointment(1);
    if(appointment) {
        std::cout << "Found appointment on: " << appointment->date << "\n";
    }

    return 0;
}