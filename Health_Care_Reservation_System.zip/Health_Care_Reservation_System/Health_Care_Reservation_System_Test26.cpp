#include <iostream>
#include <string>
#include <vector>

struct Patient {
    int id;
    std::string name;
    std::string phone;
};

struct Appointment {
    int id;
    int patientId;
    std::string date;
    std::string time;
};

std::vector<Patient> patients;
std::vector<Appointment> appointments;

void addPatient(int id, const std::string& name, const std::string& phone) {
    patients.push_back({id, name, phone});
}

void deletePatient(int id) {
    for (auto it = patients.begin(); it != patients.end(); ++it) {
        if (it->id == id) {
            patients.erase(it);
            break;
        }
    }
}

void updatePatient(int id, const std::string& name, const std::string& phone) {
    for (auto& patient : patients) {
        if (patient.id == id) {
            patient.name = name;
            patient.phone = phone;
            break;
        }
    }
}

Patient* searchPatient(int id) {
    for (auto& patient : patients) {
        if (patient.id == id) {
            return &patient;
        }
    }
    return nullptr;
}

void displayPatients() {
    for (const auto& patient : patients) {
        std::cout << "ID: " << patient.id << ", Name: " << patient.name << ", Phone: " << patient.phone << std::endl;
    }
}

void addAppointment(int id, int patientId, const std::string& date, const std::string& time) {
    appointments.push_back({id, patientId, date, time});
}

void deleteAppointment(int id) {
    for (auto it = appointments.begin(); it != appointments.end(); ++it) {
        if (it->id == id) {
            appointments.erase(it);
            break;
        }
    }
}

void updateAppointment(int id, const std::string& date, const std::string& time) {
    for (auto& app : appointments) {
        if (app.id == id) {
            app.date = date;
            app.time = time;
            break;
        }
    }
}

Appointment* searchAppointment(int id) {
    for (auto& app : appointments) {
        if (app.id == id) {
            return &app;
        }
    }
    return nullptr;
}

void displayAppointments() {
    for (const auto& app : appointments) {
        std::cout << "Appointment ID: " << app.id << ", Patient ID: " << app.patientId
                  << ", Date: " << app.date << ", Time: " << app.time << std::endl;
    }
}

int main() {
    addPatient(1, "John Doe", "123-456-7890");
    addPatient(2, "Jane Smith", "098-765-4321");

    addAppointment(1, 1, "2023-10-01", "10:00 AM");
    addAppointment(2, 2, "2023-10-02", "11:00 AM");

    displayPatients();
    displayAppointments();

    updatePatient(1, "John Doe", "111-222-3333");
    updateAppointment(2, "2023-10-03", "01:00 PM");

    Patient* patient = searchPatient(1);
    if (patient) {
        std::cout << "Found patient: " << patient->name << std::endl;
    }

    Appointment* appointment = searchAppointment(2);
    if (appointment) {
        std::cout << "Found appointment for patient ID: " << appointment->patientId << std::endl;
    }

    deletePatient(2);
    deleteAppointment(1);

    displayPatients();
    displayAppointments();

    return 0;
}