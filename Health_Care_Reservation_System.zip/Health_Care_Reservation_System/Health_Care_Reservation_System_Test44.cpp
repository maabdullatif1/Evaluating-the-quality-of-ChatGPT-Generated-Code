#include <iostream>
#include <string>
#include <vector>

class Patient {
public:
    int id;
    std::string name;
    int age;

    Patient(int id, std::string name, int age) : id(id), name(name), age(age) {}
};

class Appointment {
public:
    int id;
    int patientId;
    std::string date;

    Appointment(int id, int patientId, std::string date) : id(id), patientId(patientId), date(date) {}
};

std::vector<Patient> patients;
std::vector<Appointment> appointments;

void addPatient() {
    int id, age;
    std::string name;
    std::cout << "Enter Patient ID: ";
    std::cin >> id;
    std::cout << "Enter Patient Name: ";
    std::cin >> name;
    std::cout << "Enter Patient Age: ";
    std::cin >> age;
    patients.push_back(Patient(id, name, age));
}

void deletePatient() {
    int id;
    std::cout << "Enter Patient ID to delete: ";
    std::cin >> id;
    for (auto it = patients.begin(); it != patients.end(); ++it) {
        if (it->id == id) {
            patients.erase(it);
            break;
        }
    }
}

void updatePatient() {
    int id, age;
    std::string name;
    std::cout << "Enter Patient ID to update: ";
    std::cin >> id;
    for (auto &patient : patients) {
        if (patient.id == id) {
            std::cout << "Enter new Patient Name: ";
            std::cin >> name;
            std::cout << "Enter new Patient Age: ";
            std::cin >> age;
            patient.name = name;
            patient.age = age;
            break;
        }
    }
}

void searchPatient() {
    int id;
    std::cout << "Enter Patient ID to search: ";
    std::cin >> id;
    for (const auto &patient : patients) {
        if (patient.id == id) {
            std::cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << std::endl;
            return;
        }
    }
    std::cout << "Patient not found." << std::endl;
}

void displayPatients() {
    for (const auto &patient : patients) {
        std::cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << std::endl;
    }
}

void addAppointment() {
    int id, patientId;
    std::string date;
    std::cout << "Enter Appointment ID: ";
    std::cin >> id;
    std::cout << "Enter Patient ID for the Appointment: ";
    std::cin >> patientId;
    std::cout << "Enter Appointment Date: ";
    std::cin >> date;
    appointments.push_back(Appointment(id, patientId, date));
}

void deleteAppointment() {
    int id;
    std::cout << "Enter Appointment ID to delete: ";
    std::cin >> id;
    for (auto it = appointments.begin(); it != appointments.end(); ++it) {
        if (it->id == id) {
            appointments.erase(it);
            break;
        }
    }
}

void updateAppointment() {
    int id, patientId;
    std::string date;
    std::cout << "Enter Appointment ID to update: ";
    std::cin >> id;
    for (auto &appointment : appointments) {
        if (appointment.id == id) {
            std::cout << "Enter new Patient ID: ";
            std::cin >> patientId;
            std::cout << "Enter new Appointment Date: ";
            std::cin >> date;
            appointment.patientId = patientId;
            appointment.date = date;
            break;
        }
    }
}

void searchAppointment() {
    int id;
    std::cout << "Enter Appointment ID to search: ";
    std::cin >> id;
    for (const auto &appointment : appointments) {
        if (appointment.id == id) {
            std::cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId << ", Date: " << appointment.date << std::endl;
            return;
        }
    }
    std::cout << "Appointment not found." << std::endl;
}

void displayAppointments() {
    for (const auto &appointment : appointments) {
        std::cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId << ", Date: " << appointment.date << std::endl;
    }
}

int main() {
    int choice;
    while (true) {
        std::cout << "\nHealthcare Reservation System\n";
        std::cout << "1. Add Patient\n2. Delete Patient\n3. Update Patient\n4. Search Patient\n5. Display Patients\n";
        std::cout << "6. Add Appointment\n7. Delete Appointment\n8. Update Appointment\n9. Search Appointment\n10. Display Appointments\n11. Exit\n";
        std::cout << "Choose an option: ";
        std::cin >> choice;

        switch (choice) {
            case 1: addPatient(); break;
            case 2: deletePatient(); break;
            case 3: updatePatient(); break;
            case 4: searchPatient(); break;
            case 5: displayPatients(); break;
            case 6: addAppointment(); break;
            case 7: deleteAppointment(); break;
            case 8: updateAppointment(); break;
            case 9: searchAppointment(); break;
            case 10: displayAppointments(); break;
            case 11: return 0;
            default: std::cout << "Invalid choice, try again."; break;
        }
    }
}