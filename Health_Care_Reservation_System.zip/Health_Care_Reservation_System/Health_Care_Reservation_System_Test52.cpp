#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Appointment {
    string patientName;
    string time;
    string date;
};

struct Patient {
    string name;
    int age;
    vector<Appointment> appointments;
};

class HealthCareReservationSystem {
    vector<Patient> patients;

    Patient* findPatientByName(const string& name) {
        for (auto& patient : patients) {
            if (patient.name == name) {
                return &patient;
            }
        }
        return nullptr;
    }
    
public:
    void addPatient(const string& name, int age) {
        if (findPatientByName(name) != nullptr) return;
        Patient newPatient{ name, age };
        patients.push_back(newPatient);
    }
    
    void deletePatient(const string& name) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->name == name) {
                patients.erase(it);
                return;
            }
        }
    }
    
    void updatePatient(const string& name, int newAge) {
        Patient* patient = findPatientByName(name);
        if (patient != nullptr) {
            patient->age = newAge;
        }
    }
    
    void addAppointment(const string& name, const string& time, const string& date) {
        Patient* patient = findPatientByName(name);
        if (patient != nullptr) {
            Appointment newAppt{ name, time, date };
            patient->appointments.push_back(newAppt);
        }
    }
    
    void deleteAppointment(const string& name, const string& date) {
        Patient* patient = findPatientByName(name);
        if (patient != nullptr) {
            for (auto it = patient->appointments.begin(); it != patient->appointments.end(); ++it) {
                if (it->date == date) {
                    patient->appointments.erase(it);
                    return;
                }
            }
        }
    }
    
    void displayPatientInfo(const string& name) {
        Patient* patient = findPatientByName(name);
        if (patient != nullptr) {
            cout << "Patient Name: " << patient->name << ", Age: " << patient->age << "\n";
            for (const auto& appt : patient->appointments) {
                cout << "Appointment - Date: " << appt.date << ", Time: " << appt.time << "\n";
            }
        }
    }
    
    void displayAllPatients() {
        for (const auto& patient : patients) {
            displayPatientInfo(patient.name);
        }
    }
};

int main() {
    HealthCareReservationSystem system;
    system.addPatient("Alice", 30);
    system.addPatient("Bob", 25);
    system.addAppointment("Alice", "10:00 AM", "2023-10-05");
    system.addAppointment("Bob", "11:00 AM", "2023-10-06");
    system.displayAllPatients();
    system.updatePatient("Alice", 31);
    system.deleteAppointment("Bob", "2023-10-06");
    system.deletePatient("Alice");
    system.displayAllPatients();
    return 0;
}