#include <iostream>
#include <vector>
#include <string>

class Patient {
public:
    int id;
    std::string name;
    int age;
    std::string ailment;
    
    Patient(int id, const std::string &name, int age, const std::string &ailment)
        : id(id), name(name), age(age), ailment(ailment) {}
};

class Appointment {
public:
    int id;
    int patientId;
    std::string date;
    std::string time;
    
    Appointment(int id, int patientId, const std::string &date, const std::string &time)
        : id(id), patientId(patientId), date(date), time(time) {}
};

class HealthCareSystem {
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;

    public:

    void addPatient(int id, const std::string &name, int age, const std::string &ailment) {
        patients.push_back(Patient(id, name, age, ailment));
    }
    
    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }
    
    void updatePatient(int id, const std::string &name, int age, const std::string &ailment) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                patient.ailment = ailment;
                break;
            }
        }
    }
    
    void searchPatient(int id) {
        for (const auto &patient : patients) {
            if (patient.id == id) {
                std::cout << "Patient ID: " << patient.id << "\nName: " << patient.name << "\nAge: " << patient.age << "\nAilment: " << patient.ailment << std::endl;
                return;
            }
        }
        std::cout << "Patient not found." << std::endl;
    }
    
    void displayPatients() {
        for (const auto &patient : patients) {
            std::cout << "Patient ID: " << patient.id << "\nName: " << patient.name << "\nAge: " << patient.age << "\nAilment: " << patient.ailment << "\n" << std::endl;
        }
    }
    
    void addAppointment(int id, int patientId, const std::string &date, const std::string &time) {
        appointments.push_back(Appointment(id, patientId, date, time));
    }
    
    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->id == id) {
                appointments.erase(it);
                break;
            }
        }
    }
    
    void updateAppointment(int id, int patientId, const std::string &date, const std::string &time) {
        for (auto &appointment : appointments) {
            if (appointment.id == id) {
                appointment.patientId = patientId;
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }
    
    void searchAppointment(int id) {
        for (const auto &appointment : appointments) {
            if (appointment.id == id) {
                std::cout << "Appointment ID: " << appointment.id << "\nPatient ID: " << appointment.patientId << "\nDate: " << appointment.date << "\nTime: " << appointment.time << std::endl;
                return;
            }
        }
        std::cout << "Appointment not found." << std::endl;
    }
    
    void displayAppointments() {
        for (const auto &appointment : appointments) {
            std::cout << "Appointment ID: " << appointment.id << "\nPatient ID: " << appointment.patientId << "\nDate: " << appointment.date << "\nTime: " << appointment.time << "\n" << std::endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient(1, "John Doe", 30, "Flu");
    system.addPatient(2, "Jane Smith", 40, "Cold");
    system.displayPatients();
    system.addAppointment(1, 1, "2023-10-01", "10:00 AM");
    system.addAppointment(2, 2, "2023-10-02", "11:00 AM");
    system.displayAppointments();
    return 0;
}