#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Appointment {
    int id;
    string date;
    string time;
};

struct Patient {
    int id;
    string name;
    int age;
    string gender;
    vector<Appointment> appointments;
};

class HealthCareSystem {
    vector<Patient> patients;
    int patient_id_counter = 0;
    int appointment_id_counter = 0;

    public:
    void addPatient(string name, int age, string gender) {
        Patient patient;
        patient.id = patient_id_counter++;
        patient.name = name;
        patient.age = age;
        patient.gender = gender;
        patients.push_back(patient);
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, string name, int age, string gender) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                patient.gender = gender;
            }
        }
    }

    void searchPatient(int id) {
        for (const auto& patient : patients) {
            if (patient.id == id) {
                displayPatient(patient);
            }
        }
    }

    void addAppointment(int patient_id, string date, string time) {
        for (auto& patient : patients) {
            if (patient.id == patient_id) {
                Appointment appointment;
                appointment.id = appointment_id_counter++;
                appointment.date = date;
                appointment.time = time;
                patient.appointments.push_back(appointment);
            }
        }
    }

    void deleteAppointment(int patient_id, int appointment_id) {
        for (auto& patient : patients) {
            if (patient.id == patient_id) {
                for (auto it = patient.appointments.begin(); it != patient.appointments.end(); ++it) {
                    if (it->id == appointment_id) {
                        patient.appointments.erase(it);
                        break;
                    }
                }
            }
        }
    }

    void displayPatient(const Patient& patient) {
        cout << "Patient ID: " << patient.id << ", Name: " << patient.name
             << ", Age: " << patient.age << ", Gender: " << patient.gender << endl;
        for (const auto& app : patient.appointments) {
            cout << "  Appointment ID: " << app.id << ", Date: " << app.date
                 << ", Time: " << app.time << endl;
        }
    }

    void displayAllPatients() {
        for (const auto& patient : patients) {
            displayPatient(patient);
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("Alice", 30, "Female");
    system.addPatient("Bob", 25, "Male");
    system.addAppointment(0, "2023-12-01", "10:00");
    system.addAppointment(1, "2023-12-02", "14:00");
    system.displayAllPatients();
    system.updatePatient(0, "Alice Johnson", 31, "Female");
    system.addAppointment(0, "2023-12-03", "16:00");
    system.displayAllPatients();
    system.deleteAppointment(0, 0);
    system.deletePatient(1);
    system.displayAllPatients();
    return 0;
}