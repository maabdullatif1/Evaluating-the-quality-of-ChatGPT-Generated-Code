#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Patient {
public:
    int id;
    string name;
    int age;
    string gender;
    
    Patient(int _id, string _name, int _age, string _gender)
        : id(_id), name(_name), age(_age), gender(_gender) {}
};

class Appointment {
public:
    int id;
    int patientId;
    string date;
    string time;
    
    Appointment(int _id, int _patientId, string _date, string _time)
        : id(_id), patientId(_patientId), date(_date), time(_time) {}
};

class HealthcareSystem {
private:
    vector<Patient> patients;
    vector<Appointment> appointments;

    Patient* findPatientById(int id) {
        for (auto& patient : patients) {
            if (patient.id == id) return &patient;
        }
        return nullptr;
    }
    
    Appointment* findAppointmentById(int id) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) return &appointment;
        }
        return nullptr;
    }
    
public:
    void addPatient(int id, string name, int age, string gender) {
        if (findPatientById(id) == nullptr) {
            patients.emplace_back(id, name, age, gender);
        } else {
            cout << "Patient with ID " << id << " already exists." << endl;
        }
    }
    
    void addAppointment(int id, int patientId, string date, string time) {
        if (findAppointmentById(id) == nullptr) {
            appointments.emplace_back(id, patientId, date, time);
        } else {
            cout << "Appointment with ID " << id << " already exists." << endl;
        }
    }
    
    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }
    
    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->id == id) {
                appointments.erase(it);
                break;
            }
        }
    }
    
    void updatePatient(int id, string name, int age, string gender) {
        Patient* patient = findPatientById(id);
        if (patient) {
            patient->name = name;
            patient->age = age;
            patient->gender = gender;
        } else {
            cout << "Patient with ID " << id << " not found." << endl;
        }
    }
    
    void updateAppointment(int id, int patientId, string date, string time) {
        Appointment* appointment = findAppointmentById(id);
        if (appointment) {
            appointment->patientId = patientId;
            appointment->date = date;
            appointment->time = time;
        } else {
            cout << "Appointment with ID " << id << " not found." << endl;
        }
    }
    
    Patient* searchPatient(int id) {
        return findPatientById(id);
    }
    
    Appointment* searchAppointment(int id) {
        return findAppointmentById(id);
    }
    
    void displayPatients() {
        for (const auto& patient : patients) {
            cout << "ID: " << patient.id << ", Name: " << patient.name
                 << ", Age: " << patient.age << ", Gender: " << patient.gender << endl;
        }
    }
    
    void displayAppointments() {
        for (const auto& appointment : appointments) {
            cout << "ID: " << appointment.id << ", Patient ID: " << appointment.patientId
                 << ", Date: " << appointment.date << ", Time: " << appointment.time << endl;
        }
    }
};

int main() {
    HealthcareSystem system;
    
    system.addPatient(1, "John Doe", 30, "Male");
    system.addPatient(2, "Jane Smith", 25, "Female");
    
    system.addAppointment(1, 1, "2023-10-10", "10:00 AM");
    system.addAppointment(2, 2, "2023-10-11", "11:00 AM");
    
    system.displayPatients();
    cout << endl;
    system.displayAppointments();
    
    system.updatePatient(1, "John Doe", 31, "Male");
    system.updateAppointment(1, 1, "2023-10-12", "10:30 AM");
    
    cout << endl;
    system.displayPatients();
    cout << endl;
    system.displayAppointments();
    
    system.deletePatient(2);
    system.deleteAppointment(2);
    
    cout << endl;
    system.displayPatients();
    cout << endl;
    system.displayAppointments();
    
    return 0;
}