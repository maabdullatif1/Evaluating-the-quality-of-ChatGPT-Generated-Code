#include <iostream>
#include <vector>
#include <string>

struct Appointment {
    int patientId;
    std::string date;
    std::string time;
};

struct Patient {
    int id;
    std::string name;
    int age;
    std::vector<Appointment> appointments;
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    int generatePatientId() {
        return patients.size() + 1;
    }

public:
    void addPatient(const std::string &name, int age) {
        Patient newPatient;
        newPatient.id = generatePatientId();
        newPatient.name = name;
        newPatient.age = age;
        patients.push_back(newPatient);
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, const std::string &name, int age) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }

    void addAppointment(int patientId, const std::string &date, const std::string &time) {
        Patient* patient = searchPatient(patientId);
        if (patient != nullptr) {
            Appointment newAppointment;
            newAppointment.patientId = patientId;
            newAppointment.date = date;
            newAppointment.time = time;
            patient->appointments.push_back(newAppointment);
        }
    }

    void displayPatients() {
        for (const auto &patient : patients) {
            std::cout << "Patient ID: " << patient.id << ", Name: " << patient.name
                      << ", Age: " << patient.age << "\n";
            std::cout << "Appointments:\n";
            for (const auto &appointment : patient.appointments) {
                std::cout << "  Date: " << appointment.date << ", Time: " << appointment.time << "\n";
            }
        }
    }
};

int main() {
    HealthCareSystem system;

    system.addPatient("John Doe", 30);
    system.addPatient("Jane Smith", 25);

    system.addAppointment(1, "2023-10-30", "10:00");
    system.addAppointment(1, "2023-11-01", "14:00");
    system.addAppointment(2, "2023-10-31", "09:30");

    system.displayPatients();

    return 0;
}