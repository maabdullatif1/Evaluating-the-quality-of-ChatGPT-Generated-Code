#include <iostream>
#include <string>
#include <vector>

class Patient {
public:
    int id;
    std::string name;
    int age;

    Patient(int id, const std::string& name, int age) : id(id), name(name), age(age) {}
};

class Appointment {
public:
    int patientId;
    std::string date;
    std::string time;

    Appointment(int patientId, const std::string& date, const std::string& time) : patientId(patientId), date(date), time(time) {}
};

class HealthcareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;

    int findPatientIndexById(int id) {
        for (int i = 0; i < patients.size(); ++i) {
            if (patients[i].id == id) return i;
        }
        return -1;
    }

public:
    void addPatient(int id, const std::string& name, int age) {
        if (findPatientIndexById(id) == -1) {
            patients.push_back(Patient(id, name, age));
        } else {
            std::cout << "Patient with ID " << id << " already exists.\n";
        }
    }

    void deletePatient(int id) {
        int index = findPatientIndexById(id);
        if (index != -1) {
            patients.erase(patients.begin() + index);
            appointments.erase(
                remove_if(appointments.begin(), appointments.end(),
                          [id](Appointment& a) { return a.patientId == id; }),
                appointments.end());
        } else {
            std::cout << "Patient with ID " << id << " not found.\n";
        }
    }

    void updatePatient(int id, const std::string& name, int age) {
        int index = findPatientIndexById(id);
        if (index != -1) {
            patients[index].name = name;
            patients[index].age = age;
        } else {
            std::cout << "Patient with ID " << id << " not found.\n";
        }
    }

    void searchPatient(int id) {
        int index = findPatientIndexById(id);
        if (index != -1) {
            std::cout << "Patient Found: ID: " << patients[index].id << ", Name: " << patients[index].name << ", Age: " << patients[index].age << "\n";
        } else {
            std::cout << "Patient with ID " << id << " not found.\n";
        }
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            std::cout << "ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << "\n";
        }
    }

    void addAppointment(int patientId, const std::string& date, const std::string& time) {
        if (findPatientIndexById(patientId) != -1) {
            appointments.push_back(Appointment(patientId, date, time));
        } else {
            std::cout << "Patient with ID " << patientId << " not found.\n";
        }
    }

    void deleteAppointment(int patientId, const std::string& date, const std::string& time) {
        auto it = remove_if(appointments.begin(), appointments.end(),
                            [patientId, date, time](Appointment& a) {
                                return a.patientId == patientId && a.date == date && a.time == time;
                            });
        if (it != appointments.end()) {
            appointments.erase(it, appointments.end());
        } else {
            std::cout << "Appointment not found.\n";
        }
    }

    void searchAppointmentsForPatient(int patientId) {
        for (const auto& appointment : appointments) {
            if (appointment.patientId == patientId) {
                std::cout << "Appointment: Date: " << appointment.date << ", Time: " << appointment.time << "\n";
            }
        }
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            std::cout << "Patient ID: " << appointment.patientId << ", Date: " << appointment.date << ", Time: " << appointment.time << "\n";
        }
    }
};

int main() {
    HealthcareSystem system;
    system.addPatient(1, "John Doe", 30);
    system.addPatient(2, "Jane Smith", 25);
    system.addAppointment(1, "2023-12-01", "10:00");
    system.addAppointment(2, "2023-12-02", "11:00");

    system.displayPatients();
    system.displayAppointments();

    system.searchPatient(1);
    system.updatePatient(1, "Johnny Doe", 31);

    system.displayPatients();

    system.deletePatient(1);

    system.displayPatients();
    system.displayAppointments();

    return 0;
}