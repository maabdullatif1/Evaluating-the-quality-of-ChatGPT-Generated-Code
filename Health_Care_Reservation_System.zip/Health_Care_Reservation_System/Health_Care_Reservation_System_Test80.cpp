#include <iostream>
#include <vector>
#include <string>

class Patient {
public:
    int id;
    std::string name;
    int age;
    
    Patient(int pid, const std::string &pname, int page)
    : id(pid), name(pname), age(page) {}
};

class Appointment {
public:
    int id;
    int patientId;
    std::string date;
    std::string time;

    Appointment(int aid, int pid, const std::string &adate, const std::string &atime)
    : id(aid), patientId(pid), date(adate), time(atime) {}
};

class HealthCareSystem {
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;
    int patientIdCounter = 1;
    int appointmentIdCounter = 1;

public:
    void addPatient(const std::string &name, int age) {
        patients.emplace_back(patientIdCounter++, name, age);
    }
    
    void deletePatient(int id) {
        auto it = std::remove_if(patients.begin(), patients.end(), [id](const Patient& p) { return p.id == id; });
        patients.erase(it, patients.end());
    }
    
    void updatePatient(int id, const std::string &name, int age) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                break;
            }
        }
    }
    
    Patient* searchPatient(int id) {
        for (auto &patient : patients) {
            if (patient.id == id) return &patient;
        }
        return nullptr;
    }
    
    void displayPatients() const {
        for (const auto &patient : patients) {
            std::cout << "ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << std::endl;
        }
    }
    
    void addAppointment(int patientId, const std::string &date, const std::string &time) {
        appointments.emplace_back(appointmentIdCounter++, patientId, date, time);
    }
    
    void deleteAppointment(int id) {
        auto it = std::remove_if(appointments.begin(), appointments.end(), [id](const Appointment& a) { return a.id == id; });
        appointments.erase(it, appointments.end());
    }
    
    void updateAppointment(int id, int patientId, const std::string &date, const std::string &time) {
        for (auto &appointment : appointments) {
            if (appointment.id == id) {
                appointment.patientId = patientId;
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }
    
    Appointment* searchAppointment(int id) {
        for (auto &appointment : appointments) {
            if (appointment.id == id) return &appointment;
        }
        return nullptr;
    }
    
    void displayAppointments() const {
        for (const auto &appointment : appointments) {
            std::cout << "ID: " << appointment.id << ", Patient ID: " << appointment.patientId
                      << ", Date: " << appointment.date << ", Time: " << appointment.time << std::endl;
        }
    }
};

int main() {
    HealthCareSystem hcs;
    hcs.addPatient("John Doe", 29);
    hcs.addPatient("Alice Smith", 32);
    hcs.displayPatients();
    hcs.addAppointment(1, "2023-11-01", "10:00");
    hcs.displayAppointments();
    return 0;
}