#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Patient {
public:
    int id;
    string name;
    string contact;

    Patient(int id, string name, string contact) : id(id), name(name), contact(contact) {}
};

class Appointment {
public:
    int id;
    int patientId;
    string date;
    string time;

    Appointment(int id, int patientId, string date, string time)
        : id(id), patientId(patientId), date(date), time(time) {}
};

class HealthCareSystem {
private:
    vector<Patient> patients;
    vector<Appointment> appointments;

    int findPatientIndex(int id) {
        for (size_t i = 0; i < patients.size(); ++i) {
            if (patients[i].id == id) return i;
        }
        return -1;
    }

    int findAppointmentIndex(int id) {
        for (size_t i = 0; i < appointments.size(); ++i) {
            if (appointments[i].id == id) return i;
        }
        return -1;
    }

public:
    void addPatient(int id, string name, string contact) {
        if (findPatientIndex(id) == -1) patients.emplace_back(id, name, contact);
    }

    void deletePatient(int id) {
        int index = findPatientIndex(id);
        if (index != -1) {
            patients.erase(patients.begin() + index);
            appointments.erase(remove_if(appointments.begin(), appointments.end(), 
                [id](Appointment &ap) { return ap.patientId == id; }), appointments.end());
        }
    }

    void updatePatient(int id, string name, string contact) {
        int index = findPatientIndex(id);
        if (index != -1) {
            patients[index].name = name;
            patients[index].contact = contact;
        }
    }

    Patient* searchPatient(int id) {
        int index = findPatientIndex(id);
        if (index != -1) return &patients[index];
        return nullptr;
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            cout << "Patient ID: " << patient.id << ", Name: " << patient.name
                 << ", Contact: " << patient.contact << endl;
        }
    }

    void addAppointment(int id, int patientId, string date, string time) {
        if (findAppointmentIndex(id) == -1 && findPatientIndex(patientId) != -1) {
            appointments.emplace_back(id, patientId, date, time);
        }
    }

    void deleteAppointment(int id) {
        int index = findAppointmentIndex(id);
        if (index != -1) {
            appointments.erase(appointments.begin() + index);
        }
    }

    void updateAppointment(int id, string date, string time) {
        int index = findAppointmentIndex(id);
        if (index != -1) {
            appointments[index].date = date;
            appointments[index].time = time;
        }
    }

    Appointment* searchAppointment(int id) {
        int index = findAppointmentIndex(id);
        if (index != -1) return &appointments[index];
        return nullptr;
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId
                 << ", Date: " << appointment.date << ", Time: " << appointment.time << endl;
        }
    }
};

int main() {
    HealthCareSystem system;

    system.addPatient(1, "John Doe", "123-456-7890");
    system.addPatient(2, "Jane Smith", "987-654-3210");

    system.addAppointment(1, 1, "2023-10-01", "10:00 AM");
    system.addAppointment(2, 2, "2023-10-02", "11:00 AM");

    cout << "Patients: " << endl;
    system.displayPatients();

    cout << "\nAppointments: " << endl;
    system.displayAppointments();

    return 0;
}