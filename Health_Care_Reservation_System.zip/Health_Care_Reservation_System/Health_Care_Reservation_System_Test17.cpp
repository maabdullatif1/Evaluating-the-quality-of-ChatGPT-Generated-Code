#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Appointment {
public:
    int id;
    string date;
    string time;
    int patientId;
};

class Patient {
public:
    int id;
    string name;
    int age;
    
    Patient(int i, string n, int a) : id(i), name(n), age(a) {}
};

class HealthCareSystem {
private:
    vector<Patient> patients;
    vector<Appointment> appointments;
    int patientCounter;
    int appointmentCounter;
    
public:
    HealthCareSystem() : patientCounter(0), appointmentCounter(0) {}
    
    void addPatient(string name, int age) {
        patients.push_back(Patient(++patientCounter, name, age));
    }
    
    void deletePatient(int id) {
        for(auto it = patients.begin(); it != patients.end(); ++it) {
            if(it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }
    
    void updatePatient(int id, string name, int age) {
        for(auto &patient : patients) {
            if(patient.id == id) {
                patient.name = name;
                patient.age = age;
                break;
            }
        }
    }
    
    Patient* searchPatient(int id) {
        for(auto &patient : patients) {
            if(patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }
    
    void displayPatients() {
        for(auto &patient : patients) {
            cout << "ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << endl;
        }
    }
    
    void addAppointment(string date, string time, int patientId) {
        appointments.push_back({++appointmentCounter, date, time, patientId});
    }
    
    void deleteAppointment(int id) {
        for(auto it = appointments.begin(); it != appointments.end(); ++it) {
            if(it->id == id) {
                appointments.erase(it);
                break;
            }
        }
    }
    
    void updateAppointment(int id, string date, string time, int patientId) {
        for(auto &appointment : appointments) {
            if(appointment.id == id) {
                appointment.date = date;
                appointment.time = time;
                appointment.patientId = patientId;
                break;
            }
        }
    }
    
    Appointment* searchAppointment(int id) {
        for(auto &appointment : appointments) {
            if(appointment.id == id) {
                return &appointment;
            }
        }
        return nullptr;
    }
    
    void displayAppointments() {
        for(auto &appointment : appointments) {
            cout << "ID: " << appointment.id << ", Date: " << appointment.date 
                 << ", Time: " << appointment.time << ", Patient ID: " << appointment.patientId << endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("Alice", 30);
    system.addPatient("Bob", 40);
    
    system.addAppointment("2023-12-01", "10:00", 1);
    system.addAppointment("2023-12-02", "11:00", 2);
    
    system.displayPatients();
    system.displayAppointments();
    
    system.updatePatient(1, "Alice Smith", 31);
    system.updateAppointment(1, "2023-12-01", "10:30", 1);
    
    system.displayPatients();
    system.displayAppointments();
    
    system.deletePatient(2);
    system.deleteAppointment(2);
    
    system.displayPatients();
    system.displayAppointments();
    
    return 0;
}