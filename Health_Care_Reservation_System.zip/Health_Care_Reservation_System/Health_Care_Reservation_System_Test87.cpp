#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Appointment {
    string time;
    string doctor;
    string patientID;
};

struct Patient {
    string id;
    string name;
    int age;
    string gender;
};

class HealthCareSystem {
    vector<Patient> patients;
    vector<Appointment> appointments;

    int findPatientIndex(const string &id) {
        for (int i = 0; i < patients.size(); ++i) {
            if (patients[i].id == id) {
                return i;
            }
        }
        return -1;
    }

    int findAppointmentIndex(const string &patientID) {
        for (int i = 0; i < appointments.size(); ++i) {
            if (appointments[i].patientID == patientID) {
                return i;
            }
        }
        return -1;
    }

public:
    void addPatient(const string &id, const string &name, int age, const string &gender) {
        if (findPatientIndex(id) == -1) {
            patients.push_back({id, name, age, gender});
        } else {
            cout << "Patient ID already exists.\n";
        }
    }

    void deletePatient(const string &id) {
        int idx = findPatientIndex(id);
        if (idx != -1) {
            patients.erase(patients.begin() + idx);
        } else {
            cout << "Patient not found.\n";
        }
    }

    void updatePatient(const string &id, const string &name, int age, const string &gender) {
        int idx = findPatientIndex(id);
        if (idx != -1) {
            patients[idx] = {id, name, age, gender};
        } else {
            cout << "Patient not found.\n";
        }
    }

    void searchPatient(const string &id) {
        int idx = findPatientIndex(id);
        if (idx != -1) {
            cout << "Patient ID: " << patients[idx].id << "\n";
            cout << "Name: " << patients[idx].name << "\n";
            cout << "Age: " << patients[idx].age << "\n";
            cout << "Gender: " << patients[idx].gender << "\n";
        } else {
            cout << "Patient not found.\n";
        }
    }

    void displayPatients() {
        if (patients.empty()) {
            cout << "No patients available.\n";
        } else {
            for (const auto &p : patients) {
                cout << "Patient ID: " << p.id << " | Name: " << p.name << " | Age: " << p.age << " | Gender: " << p.gender << "\n";
            }
        }
    }

    void addAppointment(const string &time, const string &doctor, const string &patientID) {
        if (findPatientIndex(patientID) != -1 && findAppointmentIndex(patientID) == -1) {
            appointments.push_back({time, doctor, patientID});
        } else {
            cout << "Invalid operation on appointment.\n";
        }
    }

    void deleteAppointment(const string &patientID) {
        int idx = findAppointmentIndex(patientID);
        if (idx != -1) {
            appointments.erase(appointments.begin() + idx);
        } else {
            cout << "Appointment not found.\n";
        }
    }

    void updateAppointment(const string &time, const string &doctor, const string &patientID) {
        int idx = findAppointmentIndex(patientID);
        if (idx != -1) {
            appointments[idx] = {time, doctor, patientID};
        } else {
            cout << "Appointment not found.\n";
        }
    }

    void searchAppointment(const string &patientID) {
        int idx = findAppointmentIndex(patientID);
        if (idx != -1) {
            cout << "Appointment Time: " << appointments[idx].time << "\n";
            cout << "Doctor: " << appointments[idx].doctor << "\n";
            cout << "Patient ID: " << appointments[idx].patientID << "\n";
        } else {
            cout << "Appointment not found.\n";
        }
    }

    void displayAppointments() {
        if (appointments.empty()) {
            cout << "No appointments available.\n";
        } else {
            for (const auto &a : appointments) {
                cout << "Time: " << a.time << " | Doctor: " << a.doctor << " | Patient ID: " << a.patientID << "\n";
            }
        }
    }
};

int main() {
    HealthCareSystem system;

    system.addPatient("P001", "John Doe", 30, "Male");
    system.addPatient("P002", "Jane Doe", 25, "Female");

    system.displayPatients();

    system.addAppointment("10:00 AM", "Dr. Smith", "P001");
    system.addAppointment("11:00 AM", "Dr. Brown", "P002");

    system.displayAppointments();

    system.searchPatient("P001");
    system.searchAppointment("P001");

    system.updatePatient("P001", "John Smith", 31, "Male");
    system.updateAppointment("10:30 AM", "Dr. Smith", "P002");

    system.displayPatients();
    system.displayAppointments();

    system.deletePatient("P001");
    system.deleteAppointment("P002");

    system.displayPatients();
    system.displayAppointments();

    return 0;
}