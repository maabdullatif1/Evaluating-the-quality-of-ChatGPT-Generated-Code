#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Patient {
    int id;
    string name;
    int age;
    string address;
};

struct Appointment {
    int id;
    int patientId;
    string date;
    string time;
    string doctor;
};

class HealthcareSystem {
    vector<Patient> patients;
    vector<Appointment> appointments;
    int nextPatientId = 1;
    int nextAppointmentId = 1;

    Patient* findPatientById(int id) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }

    Appointment* findAppointmentById(int id) {
        for (auto &appointment : appointments) {
            if (appointment.id == id) {
                return &appointment;
            }
        }
        return nullptr;
    }

public:
    void addPatient(const string &name, int age, const string &address) {
        patients.push_back({nextPatientId++, name, age, address});
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                return;
            }
        }
    }

    void updatePatient(int id, const string &name, int age, const string &address) {
        Patient* patient = findPatientById(id);
        if (patient) {
            patient->name = name;
            patient->age = age;
            patient->address = address;
        }
    }

    void displayPatients() const {
        for (const auto &patient : patients) {
            cout << "ID: " << patient.id << " Name: " << patient.name
                 << " Age: " << patient.age << " Address: " << patient.address << endl;
        }
    }

    void addAppointment(int patientId, const string &date, const string &time, const string &doctor) {
        if (findPatientById(patientId)) {
            appointments.push_back({nextAppointmentId++, patientId, date, time, doctor});
        }
    }

    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->id == id) {
                appointments.erase(it);
                return;
            }
        }
    }

    void updateAppointment(int id, const string &date, const string &time, const string &doctor) {
        Appointment* appointment = findAppointmentById(id);
        if (appointment) {
            appointment->date = date;
            appointment->time = time;
            appointment->doctor = doctor;
        }
    }

    void displayAppointments() const {
        for (const auto &appointment : appointments) {
            cout << "Appointment ID: " << appointment.id << " Patient ID: " << appointment.patientId
                 << " Date: " << appointment.date << " Time: " << appointment.time
                 << " Doctor: " << appointment.doctor << endl;
        }
    }

    void searchPatientById(int id) const {
        for (const auto &patient : patients) {
            if (patient.id == id) {
                cout << "ID: " << patient.id << " Name: " << patient.name
                     << " Age: " << patient.age << " Address: " << patient.address << endl;
                return;
            }
        }
        cout << "Patient not found" << endl;
    }

    void searchAppointmentById(int id) const {
        for (const auto &appointment : appointments) {
            if (appointment.id == id) {
                cout << "Appointment ID: " << appointment.id << " Patient ID: " << appointment.patientId
                     << " Date: " << appointment.date << " Time: " << appointment.time
                     << " Doctor: " << appointment.doctor << endl;
                return;
            }
        }
        cout << "Appointment not found" << endl;
    }
};

int main() {
    HealthcareSystem system;
    system.addPatient("Alice", 30, "123 Main St");
    system.addPatient("Bob", 25, "456 Park Ave");
    system.addAppointment(1, "2023-12-01", "10:00", "Dr. Smith");
    system.addAppointment(2, "2023-12-03", "11:00", "Dr. Jones");
    cout << "Patients:\n";
    system.displayPatients();
    cout << "\nAppointments:\n";
    system.displayAppointments();
    cout << "\nSearch Patient by ID 1:\n";
    system.searchPatientById(1);
    cout << "\nSearch Appointment by ID 1:\n";
    system.searchAppointmentById(1);
    return 0;
}