#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Patient {
    string name;
    int id;
    int age;
    string contact;
};

struct Appointment {
    int patientId;
    string date;
    string time;
    string doctor;
};

class HealthCareSystem {
private:
    vector<Patient> patients;
    vector<Appointment> appointments;

public:
    void addPatient(const string& name, int id, int age, const string& contact) {
        patients.push_back({ name, id, age, contact });
    }

    void deletePatient(int id) {
        for (size_t i = 0; i < patients.size(); ++i) {
            if (patients[i].id == id) {
                patients.erase(patients.begin() + i);
                return;
            }
        }
    }

    void updatePatient(int id, const string& name, int age, const string& contact) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                patient.contact = contact;
                return;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            cout << "ID: " << patient.id << ", Name: " << patient.name
                 << ", Age: " << patient.age << ", Contact: " << patient.contact << endl;
        }
    }

    void addAppointment(int patientId, const string& date, const string& time, const string& doctor) {
        appointments.push_back({ patientId, date, time, doctor });
    }

    void deleteAppointment(int patientId, const string& date) {
        for (size_t i = 0; i < appointments.size(); ++i) {
            if (appointments[i].patientId == patientId && appointments[i].date == date) {
                appointments.erase(appointments.begin() + i);
                return;
            }
        }
    }

    void updateAppointment(int patientId, const string& date, const string& time, const string& doctor) {
        for (auto& appointment : appointments) {
            if (appointment.patientId == patientId && appointment.date == date) {
                appointment.time = time;
                appointment.doctor = doctor;
                return;
            }
        }
    }

    Appointment* searchAppointment(int patientId, const string& date) {
        for (auto& appointment : appointments) {
            if (appointment.patientId == patientId && appointment.date == date) {
                return &appointment;
            }
        }
        return nullptr;
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            cout << "Patient ID: " << appointment.patientId << ", Date: " << appointment.date
                 << ", Time: " << appointment.time << ", Doctor: " << appointment.doctor << endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("John Doe", 1, 30, "123-456-7890");
    system.addPatient("Jane Smith", 2, 25, "098-765-4321");
    system.displayPatients();

    system.addAppointment(1, "2024-01-10", "10:00", "Dr. House");
    system.addAppointment(2, "2024-01-11", "11:00", "Dr. Who");
    system.displayAppointments();

    system.updatePatient(1, "John Doe Jr.", 31, "321-654-0987");
    system.displayPatients();

    system.updateAppointment(1, "2024-01-10", "09:00", "Dr. Strange");
    system.displayAppointments();

    system.deletePatient(2);
    system.displayPatients();

    system.deleteAppointment(1, "2024-01-10");
    system.displayAppointments();

    return 0;
}