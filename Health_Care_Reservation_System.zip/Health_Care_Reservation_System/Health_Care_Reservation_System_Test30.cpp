#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Patient {
public:
    int id;
    string name;
    int age;
    string condition;

    Patient(int id, string name, int age, string condition)
        : id(id), name(name), age(age), condition(condition) {}
};

class Appointment {
public:
    int appointmentID;
    int patientID;
    string date;
    string time;
    string doctor;

    Appointment(int appointmentID, int patientID, string date, string time, string doctor)
        : appointmentID(appointmentID), patientID(patientID), date(date), time(time), doctor(doctor) {}
};

class HealthCareSystem {
private:
    vector<Patient> patients;
    vector<Appointment> appointments;

    int findPatientIndex(int id) {
        for (size_t i = 0; i < patients.size(); i++) {
            if (patients[i].id == id) return i;
        }
        return -1;
    }

    int findAppointmentIndex(int id) {
        for (size_t i = 0; i < appointments.size(); i++) {
            if (appointments[i].appointmentID == id) return i;
        }
        return -1;
    }

public:
    void addPatient(int id, string name, int age, string condition) {
        patients.push_back(Patient(id, name, age, condition));
    }

    void deletePatient(int id) {
        int index = findPatientIndex(id);
        if (index != -1) patients.erase(patients.begin() + index);
    }

    void updatePatient(int id, string name, int age, string condition) {
        int index = findPatientIndex(id);
        if (index != -1) {
            patients[index].name = name;
            patients[index].age = age;
            patients[index].condition = condition;
        }
    }

    void displayPatient(int id) {
        int index = findPatientIndex(id);
        if (index != -1) {
            cout << "Patient ID: " << patients[index].id << ", Name: " << patients[index].name
                 << ", Age: " << patients[index].age << ", Condition: " << patients[index].condition << endl;
        }
    }

    void addAppointment(int appointmentID, int patientID, string date, string time, string doctor) {
        appointments.push_back(Appointment(appointmentID, patientID, date, time, doctor));
    }

    void deleteAppointment(int id) {
        int index = findAppointmentIndex(id);
        if (index != -1) appointments.erase(appointments.begin() + index);
    }

    void updateAppointment(int appointmentID, int patientID, string date, string time, string doctor) {
        int index = findAppointmentIndex(appointmentID);
        if (index != -1) {
            appointments[index].patientID = patientID;
            appointments[index].date = date;
            appointments[index].time = time;
            appointments[index].doctor = doctor;
        }
    }

    void displayAppointment(int id) {
        int index = findAppointmentIndex(id);
        if (index != -1) {
            cout << "Appointment ID: " << appointments[index].appointmentID
                 << ", Patient ID: " << appointments[index].patientID
                 << ", Date: " << appointments[index].date
                 << ", Time: " << appointments[index].time
                 << ", Doctor: " << appointments[index].doctor << endl;
        }
    }

    void displayAllPatients() {
        for (size_t i = 0; i < patients.size(); i++) {
            displayPatient(patients[i].id);
        }
    }

    void displayAllAppointments() {
        for (size_t i = 0; i < appointments.size(); i++) {
            displayAppointment(appointments[i].appointmentID);
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient(1, "John Doe", 30, "Flu");
    system.addPatient(2, "Jane Smith", 25, "Cold");
    system.addAppointment(100, 1, "2023-10-01", "10:00", "Dr. Brown");
    system.addAppointment(101, 2, "2023-10-02", "11:00", "Dr. Green");
    system.displayAllPatients();
    system.displayAllAppointments();
    return 0;
}