#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Patient {
    int id;
    string name;
    int age;
    string address;
};

struct Appointment {
    int id;
    int patientId;
    string doctorName;
    string date;
    string time;
};

class HealthCareSystem {
    vector<Patient> patients;
    vector<Appointment> appointments;
    int patientCounter = 0;
    int appointmentCounter = 0;

public:
    void addPatient(string name, int age, string address) {
        Patient newPatient = {++patientCounter, name, age, address};
        patients.push_back(newPatient);
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, string name, int age, string address) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                patient.address = address;
                break;
            }
        }
    }

    void searchPatient(int id) {
        for (const auto &patient : patients) {
            if (patient.id == id) {
                cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << ", Address: " << patient.address << endl;
                return;
            }
        }
        cout << "Patient not found" << endl;
    }

    void displayPatients() {
        for (const auto &patient : patients) {
            cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << ", Address: " << patient.address << endl;
        }
    }

    void addAppointment(int patientId, string doctorName, string date, string time) {
        Appointment newAppointment = {++appointmentCounter, patientId, doctorName, date, time};
        appointments.push_back(newAppointment);
    }

    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->id == id) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int id, int patientId, string doctorName, string date, string time) {
        for (auto &appointment : appointments) {
            if (appointment.id == id) {
                appointment.patientId = patientId;
                appointment.doctorName = doctorName;
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }

    void searchAppointment(int id) {
        for (const auto &appointment : appointments) {
            if (appointment.id == id) {
                cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId << ", Doctor: " << appointment.doctorName << ", Date: " << appointment.date << ", Time: " << appointment.time << endl;
                return;
            }
        }
        cout << "Appointment not found" << endl;
    }

    void displayAppointments() {
        for (const auto &appointment : appointments) {
            cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId << ", Doctor: " << appointment.doctorName << ", Date: " << appointment.date << ", Time: " << appointment.time << endl;
        }
    }
};

int main() {
    HealthCareSystem hcs;
    hcs.addPatient("John Doe", 30, "123 Elm St");
    hcs.addPatient("Jane Smith", 25, "456 Oak St");
    hcs.displayPatients();
    hcs.addAppointment(1, "Dr. Brown", "2023-12-01", "10:30");
    hcs.addAppointment(2, "Dr. Green", "2023-12-02", "11:00");
    hcs.displayAppointments();
    return 0;
}