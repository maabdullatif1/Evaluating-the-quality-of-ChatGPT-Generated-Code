#include <iostream>
#include <string>
#include <vector>

class Appointment {
public:
    int appointmentID;
    std::string doctor;
    std::string date;
    std::string time;

    Appointment(int id, const std::string& doc, const std::string& dt, const std::string& tm)
        : appointmentID(id), doctor(doc), date(dt), time(tm) {}
};

class Patient {
public:
    int patientID;
    std::string name;
    int age;
    std::string condition;
    std::vector<Appointment> appointments;

    Patient(int id, const std::string& nm, int ag, const std::string& cond)
        : patientID(id), name(nm), age(ag), condition(cond) {}

    void addAppointment(int id, const std::string& doctor, const std::string& date, const std::string& time) {
        appointments.emplace_back(id, doctor, date, time);
    }

    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->appointmentID == id) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int id, const std::string& doctor, const std::string& date, const std::string& time) {
        for (auto& app : appointments) {
            if (app.appointmentID == id) {
                app.doctor = doctor;
                app.date = date;
                app.time = time;
                break;
            }
        }
    }

    Appointment* searchAppointment(int id) {
        for (auto& app : appointments) {
            if (app.appointmentID == id) return &app;
        }
        return nullptr;
    }

    void displayAppointments() const {
        for (const auto& app : appointments) {
            std::cout << "Appointment ID: " << app.appointmentID << "\nDoctor: " << app.doctor
                      << "\nDate: " << app.date << "\nTime: " << app.time << "\n\n";
        }
    }
};

class HealthCareSystem {
    std::vector<Patient> patients;

public:
    void addPatient(int id, const std::string& name, int age, const std::string& condition) {
        patients.emplace_back(id, name, age, condition);
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->patientID == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, const std::string& name, int age, const std::string& condition) {
        for (auto& pat : patients) {
            if (pat.patientID == id) {
                pat.name = name;
                pat.age = age;
                pat.condition = condition;
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (auto& pat : patients) {
            if (pat.patientID == id) return &pat;
        }
        return nullptr;
    }

    void displayPatients() const {
        for (const auto& pat : patients) {
            std::cout << "Patient ID: " << pat.patientID << "\nName: " << pat.name
                      << "\nAge: " << pat.age << "\nCondition: " << pat.condition << "\n";
            pat.displayAppointments();
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient(1, "John Doe", 30, "Flu");
    system.addPatient(2, "Jane Smith", 25, "Cough");

    Patient* patient = system.searchPatient(1);
    if (patient) {
        patient->addAppointment(101, "Dr. Kyle", "2023-09-15", "10:00 AM");
        patient->addAppointment(102, "Dr. Amy", "2023-09-16", "11:00 AM");
    }

    system.displayPatients();

    return 0;
}