#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Appointment {
    int id;
    string date;
    string time;
    string doctor;
};

struct Patient {
    int id;
    string name;
    int age;
    vector<Appointment> appointments;
};

vector<Patient> patients;
int patientIDCounter = 1;
int appointmentIDCounter = 1;

void addPatient() {
    Patient newPatient;
    newPatient.id = patientIDCounter++;
    cout << "Enter patient's name: ";
    cin >> newPatient.name;
    cout << "Enter patient's age: ";
    cin >> newPatient.age;
    patients.push_back(newPatient);
    cout << "Patient added successfully.\n";
}

void deletePatient() {
    int id;
    cout << "Enter patient ID to delete: ";
    cin >> id;
    for (auto it = patients.begin(); it != patients.end(); ++it) {
        if (it->id == id) {
            patients.erase(it);
            cout << "Patient deleted successfully.\n";
            return;
        }
    }
    cout << "Patient not found.\n";
}

void updatePatient() {
    int id;
    cout << "Enter patient ID to update: ";
    cin >> id;
    for (auto &patient : patients) {
        if (patient.id == id) {
            cout << "Enter new name: ";
            cin >> patient.name;
            cout << "Enter new age: ";
            cin >> patient.age;
            cout << "Patient updated successfully.\n";
            return;
        }
    }
    cout << "Patient not found.\n";
}

void addAppointment() {
    int patientId;
    cout << "Enter patient ID for appointment: ";
    cin >> patientId;
    for (auto &patient : patients) {
        if (patient.id == patientId) {
            Appointment newAppointment;
            newAppointment.id = appointmentIDCounter++;
            cout << "Enter appointment date: ";
            cin >> newAppointment.date;
            cout << "Enter appointment time: ";
            cin >> newAppointment.time;
            cout << "Enter doctor's name: ";
            cin >> newAppointment.doctor;
            patient.appointments.push_back(newAppointment);
            cout << "Appointment added successfully.\n";
            return;
        }
    }
    cout << "Patient not found.\n";
}

void deleteAppointment() {
    int patientId, appointmentId;
    cout << "Enter patient ID: ";
    cin >> patientId;
    cout << "Enter appointment ID to delete: ";
    cin >> appointmentId;
    for (auto &patient : patients) {
        if (patient.id == patientId) {
            for (auto it = patient.appointments.begin(); it != patient.appointments.end(); ++it) {
                if (it->id == appointmentId) {
                    patient.appointments.erase(it);
                    cout << "Appointment deleted successfully.\n";
                    return;
                }
            }
        }
    }
    cout << "Appointment not found.\n";
}

void displayPatients() {
    for (const auto &patient : patients) {
        cout << "Patient ID: " << patient.id << ", Name: " << patient.name 
             << ", Age: " << patient.age << "\n";
        for (const auto &appointment : patient.appointments) {
            cout << "  Appointment ID: " << appointment.id 
                 << ", Date: " << appointment.date 
                 << ", Time: " << appointment.time 
                 << ", Doctor: " << appointment.doctor << "\n";
        }
    }
}

void searchPatient() {
    int id;
    cout << "Enter patient ID to search: ";
    cin >> id;
    for (const auto &patient : patients) {
        if (patient.id == id) {
            cout << "Patient ID: " << patient.id << ", Name: " << patient.name 
                 << ", Age: " << patient.age << "\n";
            for (const auto &appointment : patient.appointments) {
                cout << "  Appointment ID: " << appointment.id 
                     << ", Date: " << appointment.date 
                     << ", Time: " << appointment.time 
                     << ", Doctor: " << appointment.doctor << "\n";
            }
            return;
        }
    }
    cout << "Patient not found.\n";
}

int main() {
    int choice;
    do {
        cout << "1. Add Patient\n2. Delete Patient\n3. Update Patient\n4. Add Appointment\n";
        cout << "5. Delete Appointment\n6. Display Patients\n7. Search Patient\n0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addPatient(); break;
            case 2: deletePatient(); break;
            case 3: updatePatient(); break;
            case 4: addAppointment(); break;
            case 5: deleteAppointment(); break;
            case 6: displayPatients(); break;
            case 7: searchPatient(); break;
            case 0: break;
            default: cout << "Invalid choice.\n";
        }
    } while (choice != 0);
    return 0;
}