#include <iostream>
#include <vector>
#include <string>

class Patient {
public:
    int id;
    std::string name;
    int age;
    std::string disease;
};

class Appointment {
public:
    int id;
    int patientId;
    std::string date;
    std::string time;
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;
    int nextPatientId;
    int nextAppointmentId;

public:
    HealthCareSystem() : nextPatientId(1), nextAppointmentId(1) {}

    void addPatient(const std::string& name, int age, const std::string& disease) {
        Patient patient = {nextPatientId++, name, age, disease};
        patients.push_back(patient);
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, const std::string& name, int age, const std::string& disease) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                patient.disease = disease;
                break;
            }
        }
    }

    void searchPatient(int id) {
        for (const auto& patient : patients) {
            if (patient.id == id) {
                std::cout << "Patient ID: " << patient.id << ", Name: " << patient.name 
                          << ", Age: " << patient.age << ", Disease: " << patient.disease << std::endl;
                return;
            }
        }
        std::cout << "Patient not found." << std::endl;
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            std::cout << "Patient ID: " << patient.id << ", Name: " << patient.name 
                      << ", Age: " << patient.age << ", Disease: " << patient.disease << std::endl;
        }
    }

    void addAppointment(int patientId, const std::string& date, const std::string& time) {
        Appointment appointment = {nextAppointmentId++, patientId, date, time};
        appointments.push_back(appointment);
    }

    void deleteAppointment(int id) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->id == id) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int id, int patientId, const std::string& date, const std::string& time) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) {
                appointment.patientId = patientId;
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }

    void searchAppointment(int id) {
        for (const auto& appointment : appointments) {
            if (appointment.id == id) {
                std::cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId 
                          << ", Date: " << appointment.date << ", Time: " << appointment.time << std::endl;
                return;
            }
        }
        std::cout << "Appointment not found." << std::endl;
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            std::cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId 
                      << ", Date: " << appointment.date << ", Time: " << appointment.time << std::endl;
        }
    }
};

int main() {
    HealthCareSystem hcs;
    hcs.addPatient("John Doe", 30, "Flu");
    hcs.addPatient("Jane Smith", 25, "Cold");
    hcs.displayPatients();

    hcs.addAppointment(1, "2023-12-01", "10:00");
    hcs.addAppointment(2, "2023-12-02", "11:00");
    hcs.displayAppointments();

    hcs.updatePatient(1, "John Doe", 31, "Headache");
    hcs.searchPatient(1);

    hcs.updateAppointment(1, 1, "2023-12-03", "09:00");
    hcs.searchAppointment(1);

    hcs.deletePatient(2);
    hcs.displayPatients();

    hcs.deleteAppointment(2);
    hcs.displayAppointments();

    return 0;
}