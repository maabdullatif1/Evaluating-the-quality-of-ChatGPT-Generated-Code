#include <iostream>
#include <string>
#include <vector>

class Appointment {
public:
    std::string date;
    std::string time;
    Appointment(const std::string &d, const std::string &t) : date(d), time(t) {}
};

class Patient {
public:
    int id;
    std::string name;
    std::vector<Appointment> appointments;
    Patient(int i, const std::string &n) : id(i), name(n) {}
};

class System {
private:
    std::vector<Patient> patients;

    Patient* findPatient(int id) {
        for (auto &patient : patients) {
            if (patient.id == id) return &patient;
        }
        return nullptr;
    }

public:
    void addPatient(int id, const std::string &name) {
        if (!findPatient(id))
            patients.emplace_back(id, name);
    }

    void deletePatient(int id) {
        patients.erase(remove_if(patients.begin(), patients.end(), [&](Patient& patient) {
            return patient.id == id;
        }), patients.end());
    }

    void updatePatient(int id, const std::string &name) {
        Patient* patient = findPatient(id);
        if (patient)
            patient->name = name;
    }

    void addAppointment(int id, const std::string &date, const std::string &time) {
        Patient* patient = findPatient(id);
        if (patient)
            patient->appointments.emplace_back(date, time);
    }

    void deleteAppointment(int id, const std::string &date, const std::string &time) {
        Patient* patient = findPatient(id);
        if (patient) {
            auto &appointments = patient->appointments;
            appointments.erase(remove_if(appointments.begin(), appointments.end(), [&](Appointment &appointment) {
                return appointment.date == date && appointment.time == time;
            }), appointments.end());
        }
    }

    void displayPatients() {
        for (auto &patient : patients) {
            std::cout << "Patient ID: " << patient.id << ", Name: " << patient.name << "\n";
            for (auto &appointment : patient.appointments) {
                std::cout << "\tAppointment: " << appointment.date << " at " << appointment.time << "\n";
            }
        }
    }

    void searchPatient(int id) {
        Patient* patient = findPatient(id);
        if (patient) {
            std::cout << "Patient ID: " << patient->id << ", Name: " << patient->name << "\n";
            for (auto &appointment : patient->appointments) {
                std::cout << "\tAppointment: " << appointment.date << " at " << appointment.time << "\n";
            }
        } else {
            std::cout << "Patient not found\n";
        }
    }
};

int main() {
    System healthcareSystem;
    healthcareSystem.addPatient(1, "John Doe");
    healthcareSystem.addAppointment(1, "2023-10-01", "10:00");
    healthcareSystem.addAppointment(1, "2023-10-02", "11:00");
    healthcareSystem.displayPatients();
    healthcareSystem.searchPatient(1);
    healthcareSystem.updatePatient(1, "John A. Doe");
    healthcareSystem.deleteAppointment(1, "2023-10-01", "10:00");
    healthcareSystem.displayPatients();
    healthcareSystem.deletePatient(1);
    healthcareSystem.displayPatients();
    return 0;
}