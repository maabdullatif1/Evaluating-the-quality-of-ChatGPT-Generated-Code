#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Appointment {
public:
    int id;
    string date;
    string time;
    string description;

    Appointment(int _id, string _date, string _time, string _desc)
        : id(_id), date(_date), time(_time), description(_desc) {}
};

class Patient {
public:
    int id;
    string name;
    int age;
    vector<Appointment> appointments;

    Patient(int _id, string _name, int _age)
        : id(_id), name(_name), age(_age) {}
};

class HealthCareSystem {
    vector<Patient> patients;
    int nextPatientId = 1;
    int nextAppointmentId = 1;

public:
    void addPatient(string name, int age) {
        patients.push_back(Patient(nextPatientId++, name, age));
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, string name, int age) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (const auto &patient : patients) {
            cout << "Patient ID: " << patient.id 
                 << ", Name: " << patient.name 
                 << ", Age: " << patient.age << endl;
        }
    }

    void addAppointment(int patientId, string date, string time, string description) {
        auto *patient = searchPatient(patientId);
        if (patient) {
            patient->appointments.push_back(Appointment(nextAppointmentId++, date, time, description));
        }
    }

    void deleteAppointment(int patientId, int appointmentId) {
        auto *patient = searchPatient(patientId);
        if (patient) {
            for (auto it = patient->appointments.begin(); it != patient->appointments.end(); ++it) {
                if (it->id == appointmentId) {
                    patient->appointments.erase(it);
                    break;
                }
            }
        }
    }

    void updateAppointment(int patientId, int appointmentId, string date, string time, string description) {
        auto *patient = searchPatient(patientId);
        if (patient) {
            for (auto &appointment : patient->appointments) {
                if (appointment.id == appointmentId) {
                    appointment.date = date;
                    appointment.time = time;
                    appointment.description = description;
                    break;
                }
            }
        }
    }

    Appointment* searchAppointment(int patientId, int appointmentId) {
        auto *patient = searchPatient(patientId);
        if (patient) {
            for (auto &appointment : patient->appointments) {
                if (appointment.id == appointmentId) {
                    return &appointment;
                }
            }
        }
        return nullptr;
    }

    void displayAppointments(int patientId) {
        auto *patient = searchPatient(patientId);
        if (patient) {
            for (const auto &appointment : patient->appointments) {
                cout << "Appointment ID: " << appointment.id 
                     << ", Date: " << appointment.date 
                     << ", Time: " << appointment.time 
                     << ", Description: " << appointment.description << endl;
            }
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("John Doe", 25);
    system.addPatient("Jane Smith", 30);
    system.addAppointment(1, "2023-12-01", "14:00", "General Check-up");
    system.addAppointment(1, "2023-12-02", "16:00", "Dentist");
    system.addAppointment(2, "2023-12-03", "10:00", "Eye Exam");

    cout << "All Patients:" << endl;
    system.displayPatients();

    cout << "Appointments for Patient ID 1:" << endl;
    system.displayAppointments(1);

    system.updatePatient(1, "Johnathan Doe", 26);
    system.updateAppointment(1, 1, "2023-12-02", "15:00", "Updated Check-up");

    cout << "Updated Patients and Appointments:" << endl;
    system.displayPatients();
    system.displayAppointments(1);

    system.deleteAppointment(1, 2);
    system.deletePatient(2);

    cout << "Final Patients and Appointments List:" << endl;
    system.displayPatients();
    system.displayAppointments(1);

    return 0;
}