#include <iostream>
#include <string>

using namespace std;

struct Patient {
    int id;
    string name;
    int age;
    string ailment;
};

struct Appointment {
    int id;
    int patientId;
    string date;
    string time;
};

const int MAX_PATIENTS = 100;
const int MAX_APPOINTMENTS = 100;

Patient patients[MAX_PATIENTS];
Appointment appointments[MAX_APPOINTMENTS];

int patientCount = 0;
int appointmentCount = 0;

void addPatient() {
    if (patientCount < MAX_PATIENTS) {
        Patient p;
        cout << "Enter Patient ID: ";
        cin >> p.id;
        cout << "Enter Patient Name: ";
        cin.ignore();
        getline(cin, p.name);
        cout << "Enter Patient Age: ";
        cin >> p.age;
        cout << "Enter Ailment: ";
        cin.ignore();
        getline(cin, p.ailment);
        patients[patientCount++] = p;
    } else {
        cout << "Maximum number of patients reached." << endl;
    }
}

void deletePatient(int id) {
    bool found = false;
    for (int i = 0; i < patientCount; i++) {
        if (patients[i].id == id) {
            for (int j = i; j < patientCount - 1; j++) {
                patients[j] = patients[j + 1];
            }
            patientCount--;
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "Patient not found." << endl;
    }
}

void updatePatient(int id) {
    bool found = false;
    for (int i = 0; i < patientCount; i++) {
        if (patients[i].id == id) {
            cout << "Update Patient Name: ";
            cin.ignore();
            getline(cin, patients[i].name);
            cout << "Update Patient Age: ";
            cin >> patients[i].age;
            cout << "Update Ailment: ";
            cin.ignore();
            getline(cin, patients[i].ailment);
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "Patient not found." << endl;
    }
}

void searchPatient(int id) {
    bool found = false;
    for (int i = 0; i < patientCount; i++) {
        if (patients[i].id == id) {
            cout << "ID: " << patients[i].id << ", Name: " << patients[i].name << ", Age: " << patients[i].age << ", Ailment: " << patients[i].ailment << endl;
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "Patient not found." << endl;
    }
}

void displayPatients() {
    for (int i = 0; i < patientCount; i++) {
        cout << "ID: " << patients[i].id << ", Name: " << patients[i].name << ", Age: " << patients[i].age << ", Ailment: " << patients[i].ailment << endl;
    }
}

void addAppointment() {
    if (appointmentCount < MAX_APPOINTMENTS) {
        Appointment a;
        cout << "Enter Appointment ID: ";
        cin >> a.id;
        cout << "Enter Patient ID: ";
        cin >> a.patientId;
        cout << "Enter Date (YYYY-MM-DD): ";
        cin.ignore();
        getline(cin, a.date);
        cout << "Enter Time (HH:MM): ";
        getline(cin, a.time);
        appointments[appointmentCount++] = a;
    } else {
        cout << "Maximum number of appointments reached." << endl;
    }
}

void deleteAppointment(int id) {
    bool found = false;
    for (int i = 0; i < appointmentCount; i++) {
        if (appointments[i].id == id) {
            for (int j = i; j < appointmentCount - 1; j++) {
                appointments[j] = appointments[j + 1];
            }
            appointmentCount--;
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "Appointment not found." << endl;
    }
}

void updateAppointment(int id) {
    bool found = false;
    for (int i = 0; i < appointmentCount; i++) {
        if (appointments[i].id == id) {
            cout << "Update Patient ID: ";
            cin >> appointments[i].patientId;
            cout << "Update Date (YYYY-MM-DD): ";
            cin.ignore();
            getline(cin, appointments[i].date);
            cout << "Update Time (HH:MM): ";
            getline(cin, appointments[i].time);
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "Appointment not found." << endl;
    }
}

void searchAppointment(int id) {
    bool found = false;
    for (int i = 0; i < appointmentCount; i++) {
        if (appointments[i].id == id) {
            cout << "ID: " << appointments[i].id << ", Patient ID: " << appointments[i].patientId << ", Date: " << appointments[i].date << ", Time: " << appointments[i].time << endl;
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "Appointment not found." << endl;
    }
}

void displayAppointments() {
    for (int i = 0; i < appointmentCount; i++) {
        cout << "ID: " << appointments[i].id << ", Patient ID: " << appointments[i].patientId << ", Date: " << appointments[i].date << ", Time: " << appointments[i].time << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Patient" << endl;
        cout << "2. Delete Patient" << endl;
        cout << "3. Update Patient" << endl;
        cout << "4. Search Patient" << endl;
        cout << "5. Display All Patients" << endl;
        cout << "6. Add Appointment" << endl;
        cout << "7. Delete Appointment" << endl;
        cout << "8. Update Appointment" << endl;
        cout << "9. Search Appointment" << endl;
        cout << "10. Display All Appointments" << endl;
        cout << "11. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;
        
        switch (choice) {
            case 1:
                addPatient();
                break;
            case 2:
                int deletePid;
                cout << "Enter Patient ID to Delete: ";
                cin >> deletePid;
                deletePatient(deletePid);
                break;
            case 3:
                int updatePid;
                cout << "Enter Patient ID to Update: ";
                cin >> updatePid;
                updatePatient(updatePid);
                break;
            case 4:
                int searchPid;
                cout << "Enter Patient ID to Search: ";
                cin >> searchPid;
                searchPatient(searchPid);
                break;
            case 5:
                displayPatients();
                break;
            case 6:
                addAppointment();
                break;
            case 7:
                int deleteAid;
                cout << "Enter Appointment ID to Delete: ";
                cin >> deleteAid;
                deleteAppointment(deleteAid);
                break;
            case 8:
                int updateAid;
                cout << "Enter Appointment ID to Update: ";
                cin >> updateAid;
                updateAppointment(updateAid);
                break;
            case 9:
                int searchAid;
                cout << "Enter Appointment ID to Search: ";
                cin >> searchAid;
                searchAppointment(searchAid);
                break;
            case 10:
                displayAppointments();
                break;
        }
        
    } while (choice != 11);

    return 0;
}