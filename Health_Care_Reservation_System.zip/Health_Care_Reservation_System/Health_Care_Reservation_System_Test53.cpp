#include <iostream>
#include <string>
using namespace std;

struct Patient {
    int id;
    string name;
    int age;
    string appointment;
};

class HealthCareSystem {
    Patient patients[100];
    int count;
public:
    HealthCareSystem() : count(0) {}

    void addPatient(int id, const string& name, int age, const string& appointment) {
        patients[count].id = id;
        patients[count].name = name;
        patients[count].age = age;
        patients[count].appointment = appointment;
        count++;
    }

    void deletePatient(int id) {
        for (int i = 0; i < count; i++) {
            if (patients[i].id == id) {
                for (int j = i; j < count - 1; j++) {
                    patients[j] = patients[j + 1];
                }
                count--;
                break;
            }
        }
    }

    void updatePatient(int id, const string& name, int age, const string& appointment) {
        for (int i = 0; i < count; i++) {
            if (patients[i].id == id) {
                patients[i].name = name;
                patients[i].age = age;
                patients[i].appointment = appointment;
                break;
            }
        }
    }

    void searchPatient(int id) const {
        for (int i = 0; i < count; i++) {
            if (patients[i].id == id) {
                cout << "Patient ID: " << patients[i].id << endl;
                cout << "Name: " << patients[i].name << endl;
                cout << "Age: " << patients[i].age << endl;
                cout << "Appointment: " << patients[i].appointment << endl;
                return;
            }
        }
        cout << "Patient not found." << endl;
    }

    void displayPatients() const {
        for (int i = 0; i < count; i++) {
            cout << "Patient ID: " << patients[i].id << endl;
            cout << "Name: " << patients[i].name << endl;
            cout << "Age: " << patients[i].age << endl;
            cout << "Appointment: " << patients[i].appointment << endl;
            cout << "---------" << endl;
        }
    }
};

int main() {
    HealthCareSystem hcs;
    hcs.addPatient(1, "John Doe", 30, "2023-11-10 09:30");
    hcs.addPatient(2, "Jane Smith", 25, "2023-11-10 10:00");
    hcs.displayPatients();
    hcs.searchPatient(1);
    hcs.updatePatient(1, "John Doe", 31, "2023-11-11 10:30");
    hcs.displayPatients();
    hcs.deletePatient(2);
    hcs.displayPatients();
    return 0;
}