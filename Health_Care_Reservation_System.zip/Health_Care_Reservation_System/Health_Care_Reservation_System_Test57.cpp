#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Patient {
public:
    int id;
    string name;
    int age;

    Patient(int id, const string &name, int age) : id(id), name(name), age(age) {}
};

class Appointment {
public:
    int patientId;
    string date;
    string time;

    Appointment(int patientId, const string &date, const string &time) : patientId(patientId), date(date), time(time) {}
};

class HealthCareSystem {
private:
    vector<Patient> patients;
    vector<Appointment> appointments;

    Patient* findPatientById(int id) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }

public:
    void addPatient(int id, const string &name, int age) {
        if (findPatientById(id)) return;
        patients.push_back(Patient(id, name, age));
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
        auto it = appointments.begin();
        while (it != appointments.end()) {
            if (it->patientId == id) {
                it = appointments.erase(it);
            } else {
                ++it;
            }
        }
    }

    void updatePatient(int id, const string &name, int age) {
        Patient *patient = findPatientById(id);
        if (patient) {
            patient->name = name;
            patient->age = age;
        }
    }

    Patient* searchPatient(int id) {
        return findPatientById(id);
    }

    void displayPatients() {
        for (const auto &patient : patients) {
            cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << endl;
        }
    }

    void addAppointment(int patientId, const string &date, const string &time) {
        if (!findPatientById(patientId)) return;
        appointments.push_back(Appointment(patientId, date, time));
    }

    void deleteAppointment(int patientId, const string &date, const string &time) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->patientId == patientId && it->date == date && it->time == time) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int patientId, const string &oldDate, const string &oldTime, const string &newDate, const string &newTime) {
        for (auto &appointment : appointments) {
            if (appointment.patientId == patientId && appointment.date == oldDate && appointment.time == oldTime) {
                appointment.date = newDate;
                appointment.time = newTime;
                break;
            }
        }
    }

    void displayAppointments() {
        for (const auto &appointment : appointments) {
            cout << "Patient ID: " << appointment.patientId << ", Date: " << appointment.date << ", Time: " << appointment.time << endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient(1, "Alice", 30);
    system.addPatient(2, "Bob", 24);
    system.updatePatient(2, "Robert", 25);
    system.addAppointment(1, "2023-10-15", "10:00");
    system.addAppointment(1, "2023-10-16", "11:30");
    system.displayPatients();
    system.displayAppointments();
    system.deleteAppointment(1, "2023-10-15", "10:00");
    system.deletePatient(2);
    system.displayPatients();
    system.displayAppointments();
    return 0;
}