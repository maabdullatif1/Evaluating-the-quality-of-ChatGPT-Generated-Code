#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Appointment {
    string date;
    string time;
    string doctor;
};

struct Patient {
    int id;
    string name;
    string contact;
    vector<Appointment> appointments;
};

vector<Patient> patients;

Patient* searchPatient(int id) {
    for (auto& patient : patients) {
        if (patient.id == id) {
            return &patient;
        }
    }
    return nullptr;
}

void addPatient(int id, string name, string contact) {
    if (!searchPatient(id)) {
        patients.push_back({id, name, contact, {}});
    } else {
        cout << "Patient with ID " << id << " already exists.\n";
    }
}

void deletePatient(int id) {
    for (auto it = patients.begin(); it != patients.end(); ++it) {
        if (it->id == id) {
            patients.erase(it);
            return;
        }
    }
    cout << "Patient not found.\n";
}

void updatePatient(int id, string name, string contact) {
    Patient* patient = searchPatient(id);
    if (patient) {
        patient->name = name;
        patient->contact = contact;
    } else {
        cout << "Patient not found.\n";
    }
}

void displayPatients() {
    for (const auto& patient : patients) {
        cout << "ID: " << patient.id << ", Name: " << patient.name 
             << ", Contact: " << patient.contact << "\n";
        for (const auto& appointment : patient.appointments) {
            cout << "  Appointment - Date: " << appointment.date 
                 << ", Time: " << appointment.time 
                 << ", Doctor: " << appointment.doctor << "\n";
        }
    }
}

void addAppointment(int id, string date, string time, string doctor) {
    Patient* patient = searchPatient(id);
    if (patient) {
        patient->appointments.push_back({date, time, doctor});
    } else {
        cout << "Patient not found.\n";
    }
}

void deleteAppointment(int id, string date, string time) {
    Patient* patient = searchPatient(id);
    if (patient) {
        for (auto it = patient->appointments.begin(); it != patient->appointments.end(); ++it) {
            if (it->date == date && it->time == time) {
                patient->appointments.erase(it);
                return;
            }
        }
        cout << "Appointment not found.\n";
    } else {
        cout << "Patient not found.\n";
    }
}

void updateAppointment(int id, string date, string time, string newDate, string newTime, string newDoctor) {
    Patient* patient = searchPatient(id);
    if (patient) {
        for (auto& appointment : patient->appointments) {
            if (appointment.date == date && appointment.time == time) {
                appointment.date = newDate;
                appointment.time = newTime;
                appointment.doctor = newDoctor;
                return;
            }
        }
        cout << "Appointment not found.\n";
    } else {
        cout << "Patient not found.\n";
    }
}

int main() {
    addPatient(1, "John Doe", "123-456-7890");
    addPatient(2, "Jane Smith", "098-765-4321");
    
    addAppointment(1, "2023-11-01", "10:00", "Dr. Brown");
    addAppointment(2, "2023-11-01", "11:00", "Dr. Smith");
    
    displayPatients();
    
    deleteAppointment(1, "2023-11-01", "10:00");
    
    updatePatient(2, "Jane Doe", "555-555-5555");
    updateAppointment(2, "2023-11-01", "11:00", "2023-11-02", "12:00", "Dr. Green");
    
    displayPatients();
    
    deletePatient(1);

    displayPatients();

    return 0;
}