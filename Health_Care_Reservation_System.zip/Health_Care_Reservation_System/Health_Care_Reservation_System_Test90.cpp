#include <iostream>
#include <vector>
#include <string>

class Patient {
public:
    int id;
    std::string name;
    int age;
    std::string ailment;

    Patient(int id, const std::string& name, int age, const std::string& ailment)
        : id(id), name(name), age(age), ailment(ailment) {}
};

class Appointment {
public:
    int appointmentId;
    int patientId;
    std::string date;
    std::string time;

    Appointment(int appointmentId, int patientId, const std::string& date, const std::string& time)
        : appointmentId(appointmentId), patientId(patientId), date(date), time(time) {}
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;

public:
    void addPatient(int id, const std::string& name, int age, const std::string& ailment) {
        patients.push_back(Patient(id, name, age, ailment));
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, const std::string& name, int age, const std::string& ailment) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                patient.ailment = ailment;
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (auto& patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            std::cout << "ID: " << patient.id << ", Name: " << patient.name
                      << ", Age: " << patient.age << ", Ailment: " << patient.ailment << std::endl;
        }
    }

    void addAppointment(int appointmentId, int patientId, const std::string& date, const std::string& time) {
        appointments.push_back(Appointment(appointmentId, patientId, date, time));
    }

    void deleteAppointment(int appointmentId) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->appointmentId == appointmentId) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int appointmentId, int patientId, const std::string& date, const std::string& time) {
        for (auto& appointment : appointments) {
            if (appointment.appointmentId == appointmentId) {
                appointment.patientId = patientId;
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }

    Appointment* searchAppointment(int appointmentId) {
        for (auto& appointment : appointments) {
            if (appointment.appointmentId == appointmentId) {
                return &appointment;
            }
        }
        return nullptr;
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            std::cout << "Appointment ID: " << appointment.appointmentId
                      << ", Patient ID: " << appointment.patientId
                      << ", Date: " << appointment.date
                      << ", Time: " << appointment.time << std::endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient(1, "John Doe", 30, "Flu");
    system.addPatient(2, "Jane Smith", 25, "Cold");
    system.addAppointment(1, 1, "2023-10-12", "10:00");
    system.addAppointment(2, 2, "2023-10-13", "11:00");

    std::cout << "Patients:\n";
    system.displayPatients();

    std::cout << "\nAppointments:\n";
    system.displayAppointments();

    system.updatePatient(1, "John Doe", 31, "Allergy");
    system.updateAppointment(1, 1, "2023-10-15", "09:00");

    std::cout << "\nUpdated Patients:\n";
    system.displayPatients();

    std::cout << "\nUpdated Appointments:\n";
    system.displayAppointments();

    return 0;
}