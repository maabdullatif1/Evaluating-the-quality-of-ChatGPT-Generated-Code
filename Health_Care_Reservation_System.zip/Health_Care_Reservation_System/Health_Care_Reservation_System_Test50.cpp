#include <iostream>
#include <string>
#include <vector>

class Patient {
public:
    int id;
    std::string name;
    std::string phone;

    Patient(int id, std::string name, std::string phone)
        : id(id), name(name), phone(phone) {}
};

class Appointment {
public:
    int patientId;
    std::string date;
    std::string time;

    Appointment(int patientId, std::string date, std::string time)
        : patientId(patientId), date(date), time(time) {}
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;

public:
    void addPatient(int id, std::string name, std::string phone) {
        patients.push_back(Patient(id, name, phone));
    }

    void deletePatient(int id) {
        for (auto it = patients.begin(); it != patients.end(); ++it) {
            if (it->id == id) {
                patients.erase(it);
                break;
            }
        }
    }

    void updatePatient(int id, std::string name, std::string phone) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.phone = phone;
                break;
            }
        }
    }

    Patient* searchPatient(int id) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                return &patient;
            }
        }
        return nullptr;
    }

    void displayPatients() {
        for (auto &patient : patients) {
            std::cout << "ID: " << patient.id << ", Name: " << patient.name 
                      << ", Phone: " << patient.phone << std::endl;
        }
    }

    void addAppointment(int patientId, std::string date, std::string time) {
        appointments.push_back(Appointment(patientId, date, time));
    }

    void deleteAppointment(int patientId) {
        for (auto it = appointments.begin(); it != appointments.end(); ++it) {
            if (it->patientId == patientId) {
                appointments.erase(it);
                break;
            }
        }
    }

    void updateAppointment(int patientId, std::string date, std::string time) {
        for (auto &appointment : appointments) {
            if (appointment.patientId == patientId) {
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }

    void displayAppointments() {
        for (auto &appointment : appointments) {
            std::cout << "Patient ID: " << appointment.patientId 
                      << ", Date: " << appointment.date 
                      << ", Time: " << appointment.time << std::endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient(1, "John Doe", "1234567890");
    system.addPatient(2, "Jane Smith", "0987654321");

    system.addAppointment(1, "2023-10-01", "10:00 AM");
    system.addAppointment(2, "2023-10-02", "11:00 AM");

    system.displayPatients();
    std::cout << std::endl;
    system.displayAppointments();

    std::cout << std::endl << "Updating John Doe's information and appointment" << std::endl;
    system.updatePatient(1, "Johnathan Doe", "1111111111");
    system.updateAppointment(1, "2023-10-01", "02:00 PM");
    
    system.displayPatients();
    std::cout << std::endl;
    system.displayAppointments();

    return 0;
}