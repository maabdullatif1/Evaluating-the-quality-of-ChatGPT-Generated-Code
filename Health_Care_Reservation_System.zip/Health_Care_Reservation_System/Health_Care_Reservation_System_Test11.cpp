#include <iostream>
#include <vector>
#include <string>

struct Patient {
    int id;
    std::string name;
    int age;
};

struct Appointment {
    int id;
    int patientId;
    std::string date;
    std::string time;
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;

    Patient* findPatientById(int id) {
        for (auto& patient : patients) {
            if (patient.id == id) return &patient;
        }
        return nullptr;
    }

    Appointment* findAppointmentById(int id) {
        for (auto& appointment : appointments) {
            if (appointment.id == id) return &appointment;
        }
        return nullptr;
    }

public:
    void addPatient(int id, const std::string& name, int age) {
        patients.push_back({id, name, age});
    }

    void deletePatient(int id) {
        patients.erase(std::remove_if(patients.begin(), patients.end(),
                                      [id](const Patient& p) { return p.id == id; }),
                      patients.end());
    }

    void updatePatient(int id, const std::string& name, int age) {
        Patient* patient = findPatientById(id);
        if (patient) {
            patient->name = name;
            patient->age = age;
        }
    }

    Patient* searchPatient(int id) {
        return findPatientById(id);
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            std::cout << "Patient ID: " << patient.id
                      << ", Name: " << patient.name
                      << ", Age: " << patient.age << std::endl;
        }
    }

    void addAppointment(int id, int patientId, const std::string& date, const std::string& time) {
        appointments.push_back({id, patientId, date, time});
    }

    void deleteAppointment(int id) {
        appointments.erase(std::remove_if(appointments.begin(), appointments.end(),
                                          [id](const Appointment& a) { return a.id == id; }),
                           appointments.end());
    }

    void updateAppointment(int id, int patientId, const std::string& date, const std::string& time) {
        Appointment* appointment = findAppointmentById(id);
        if (appointment) {
            appointment->patientId = patientId;
            appointment->date = date;
            appointment->time = time;
        }
    }

    Appointment* searchAppointment(int id) {
        return findAppointmentById(id);
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            std::cout << "Appointment ID: " << appointment.id
                      << ", Patient ID: " << appointment.patientId
                      << ", Date: " << appointment.date
                      << ", Time: " << appointment.time << std::endl;
        }
    }
};

int main() {
    HealthCareSystem hcs;
    hcs.addPatient(1, "John Doe", 30);
    hcs.addPatient(2, "Jane Smith", 25);
    hcs.displayPatients();

    hcs.addAppointment(1, 1, "2023-10-25", "10:00");
    hcs.addAppointment(2, 2, "2023-10-26", "11:00");
    hcs.displayAppointments();

    hcs.updatePatient(1, "John Doe", 31);
    hcs.deletePatient(2);
    hcs.displayPatients();

    hcs.updateAppointment(1, 1, "2023-10-27", "10:30");
    hcs.deleteAppointment(2);
    hcs.displayAppointments();

    return 0;
}