#include <iostream>
#include <string>
#include <vector>

class Patient {
public:
    int id;
    std::string name;
    int age;
    std::string address;

    Patient(int id, std::string name, int age, std::string address)
        : id(id), name(name), age(age), address(address) {}
};

class Appointment {
public:
    int appId;
    int patientId;
    std::string date;
    std::string time;

    Appointment(int appId, int patientId, std::string date, std::string time)
        : appId(appId), patientId(patientId), date(date), time(time) {}
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;

public:
    void addPatient(int id, std::string name, int age, std::string address) {
        patients.push_back(Patient(id, name, age, address));
    }

    void deletePatient(int id) {
        for (size_t i = 0; i < patients.size(); ++i) {
            if (patients[i].id == id) {
                patients.erase(patients.begin() + i);
                break;
            }
        }
    }

    void updatePatient(int id, std::string name, int age, std::string address) {
        for (auto &patient : patients) {
            if (patient.id == id) {
                patient.name = name;
                patient.age = age;
                patient.address = address;
                break;
            }
        }
    }

    void searchPatient(int id) {
        for (const auto &patient : patients) {
            if (patient.id == id) {
                std::cout << "Patient ID: " << patient.id
                          << ", Name: " << patient.name
                          << ", Age: " << patient.age
                          << ", Address: " << patient.address << "\n";
                return;
            }
        }
        std::cout << "Patient not found\n";
    }

    void displayPatients() {
        for (const auto &patient : patients) {
            std::cout << "Patient ID: " << patient.id
                      << ", Name: " << patient.name
                      << ", Age: " << patient.age
                      << ", Address: " << patient.address << "\n";
        }
    }

    void addAppointment(int appId, int patientId, std::string date, std::string time) {
        appointments.push_back(Appointment(appId, patientId, date, time));
    }

    void deleteAppointment(int appId) {
        for (size_t i = 0; i < appointments.size(); ++i) {
            if (appointments[i].appId == appId) {
                appointments.erase(appointments.begin() + i);
                break;
            }
        }
    }

    void updateAppointment(int appId, int patientId, std::string date, std::string time) {
        for (auto &appointment : appointments) {
            if (appointment.appId == appId) {
                appointment.patientId = patientId;
                appointment.date = date;
                appointment.time = time;
                break;
            }
        }
    }

    void searchAppointment(int appId) {
        for (const auto &appointment : appointments) {
            if (appointment.appId == appId) {
                std::cout << "Appointment ID: " << appointment.appId
                          << ", Patient ID: " << appointment.patientId
                          << ", Date: " << appointment.date
                          << ", Time: " << appointment.time << "\n";
                return;
            }
        }
        std::cout << "Appointment not found\n";
    }

    void displayAppointments() {
        for (const auto &appointment : appointments) {
            std::cout << "Appointment ID: " << appointment.appId
                      << ", Patient ID: " << appointment.patientId
                      << ", Date: " << appointment.date
                      << ", Time: " << appointment.time << "\n";
        }
    }
};

int main() {
    HealthCareSystem hcs;

    hcs.addPatient(1, "John Doe", 30, "123 Main St");
    hcs.addPatient(2, "Jane Smith", 25, "456 Elm St");

    hcs.displayPatients();

    hcs.addAppointment(101, 1, "2022-12-05", "09:00");
    hcs.addAppointment(102, 2, "2022-12-06", "10:00");

    hcs.displayAppointments();

    return 0;
}