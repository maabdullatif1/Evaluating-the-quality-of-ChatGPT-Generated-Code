#include <iostream>
#include <vector>
#include <string>

class Patient {
public:
    int id;
    std::string name;
    int age;

    Patient(int id, const std::string& name, int age) : id(id), name(name), age(age) {}
};

class Appointment {
public:
    int id;
    int patientId;
    std::string date;
    std::string time;

    Appointment(int id, int patientId, const std::string& date, const std::string& time) : id(id), patientId(patientId), date(date), time(time) {}
};

class HealthCareSystem {
private:
    std::vector<Patient> patients;
    std::vector<Appointment> appointments;
    int patientIdCounter = 1;
    int appointmentIdCounter = 1;

public:
    void addPatient(const std::string& name, int age) {
        patients.push_back(Patient(patientIdCounter++, name, age));
    }

    void deletePatient(int patientId) {
        patients.erase(std::remove_if(patients.begin(), patients.end(),
                                      [patientId](const Patient& p) { return p.id == patientId; }), patients.end());
    }

    void updatePatient(int patientId, const std::string& name, int age) {
        for (auto& patient : patients) {
            if (patient.id == patientId) {
                patient.name = name;
                patient.age = age;
            }
        }
    }

    void searchPatient(int patientId) {
        for (const auto& patient : patients) {
            if (patient.id == patientId) {
                std::cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << std::endl;
            }
        }
    }

    void displayPatients() {
        for (const auto& patient : patients) {
            std::cout << "Patient ID: " << patient.id << ", Name: " << patient.name << ", Age: " << patient.age << std::endl;
        }
    }

    void addAppointment(int patientId, const std::string& date, const std::string& time) {
        appointments.push_back(Appointment(appointmentIdCounter++, patientId, date, time));
    }

    void deleteAppointment(int appointmentId) {
        appointments.erase(std::remove_if(appointments.begin(), appointments.end(),
                                          [appointmentId](const Appointment& a) { return a.id == appointmentId; }), appointments.end());
    }

    void updateAppointment(int appointmentId, const std::string& date, const std::string& time) {
        for (auto& appointment : appointments) {
            if (appointment.id == appointmentId) {
                appointment.date = date;
                appointment.time = time;
            }
        }
    }

    void searchAppointment(int appointmentId) {
        for (const auto& appointment : appointments) {
            if (appointment.id == appointmentId) {
                std::cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId 
                          << ", Date: " << appointment.date << ", Time: " << appointment.time << std::endl;
            }
        }
    }

    void displayAppointments() {
        for (const auto& appointment : appointments) {
            std::cout << "Appointment ID: " << appointment.id << ", Patient ID: " << appointment.patientId 
                      << ", Date: " << appointment.date << ", Time: " << appointment.time << std::endl;
        }
    }
};

int main() {
    HealthCareSystem system;
    system.addPatient("John Doe", 30);
    system.addPatient("Jane Smith", 25);
    system.displayPatients();

    system.addAppointment(1, "2024-01-01", "10:00");
    system.addAppointment(2, "2024-01-02", "11:00");
    system.displayAppointments();

    system.updatePatient(1, "John Doe", 31);
    system.searchPatient(1);

    system.updateAppointment(1, "2024-01-10", "10:30");
    system.searchAppointment(1);

    system.deletePatient(2);
    system.deleteAppointment(2);
    system.displayPatients();
    system.displayAppointments();

    return 0;
}