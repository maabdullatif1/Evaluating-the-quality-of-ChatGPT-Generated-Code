#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    int age;
    string id;
};

class NurseryManagementSystem {
private:
    vector<Person> children;
    vector<Person> babysitters;

public:
    void addChild(const string& name, int age, const string& id) {
        children.push_back({name, age, id});
    }
    
    void addBabysitter(const string& name, int age, const string& id) {
        babysitters.push_back({name, age, id});
    }

    void deleteChild(const string& id) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->id == id) {
                children.erase(it);
                break;
            }
        }
    }

    void deleteBabysitter(const string& id) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->id == id) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateChild(const string& id, const string& name, int age) {
        for (auto& child : children) {
            if (child.id == id) {
                child.name = name;
                child.age = age;
                break;
            }
        }
    }

    void updateBabysitter(const string& id, const string& name, int age) {
        for (auto& babysitter : babysitters) {
            if (babysitter.id == id) {
                babysitter.name = name;
                babysitter.age = age;
                break;
            }
        }
    }

    Person* searchChild(const string& id) {
        for (auto& child : children) {
            if (child.id == id) {
                return &child;
            }
        }
        return nullptr;
    }

    Person* searchBabysitter(const string& id) {
        for (auto& babysitter : babysitters) {
            if (babysitter.id == id) {
                return &babysitter;
            }
        }
        return nullptr;
    }

    void displayChildren() const {
        cout << "Children Info:\n";
        for (const auto& child : children) {
            cout << "Name: " << child.name << ", Age: " << child.age << ", ID: " << child.id << endl;
        }
    }

    void displayBabysitters() const {
        cout << "Babysitters Info:\n";
        for (const auto& babysitter : babysitters) {
            cout << "Name: " << babysitter.name << ", Age: " << babysitter.age << ", ID: " << babysitter.id << endl;
        }
    }
};

int main() {
    NurseryManagementSystem system;
    
    system.addChild("Alice", 4, "C001");
    system.addChild("Bob", 5, "C002");
    system.addBabysitter("Emily", 30, "B001");
    system.addBabysitter("John", 28, "B002");
    
    system.displayChildren();
    system.displayBabysitters();
    
    system.updateChild("C001", "Alicia", 5);
    system.updateBabysitter("B002", "John Doe", 29);
    
    Person* child = system.searchChild("C001");
    if (child) {
        cout << "Found Child: " << child->name << ".\n";
    }
    
    Person* babysitter = system.searchBabysitter("B003");
    if (!babysitter) {
        cout << "Babysitter not found.\n";
    }
    
    system.deleteChild("C002");
    system.deleteBabysitter("B001");
    
    system.displayChildren();
    system.displayBabysitters();
    
    return 0;
}