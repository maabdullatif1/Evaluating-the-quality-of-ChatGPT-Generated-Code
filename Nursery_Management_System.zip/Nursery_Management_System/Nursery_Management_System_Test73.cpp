#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
public:
    string name;
    int age;
    string id;

    Person(string name, int age, string id)
        : name(name), age(age), id(id) {}
};

class Child : public Person {
public:
    Child(string name, int age, string id)
        : Person(name, age, id) {}
};

class Babysitter : public Person {
public:
    Babysitter(string name, int age, string id)
        : Person(name, age, id) {}
};

class NurseryManagementSystem {
    vector<Child> children;
    vector<Babysitter> babysitters;

    template<typename T>
    void addPerson(vector<T>& people, const T& person) {
        people.push_back(person);
    }

    template<typename T>
    void deletePerson(vector<T>& people, const string& id) {
        for (auto it = people.begin(); it != people.end(); ++it) {
            if (it->id == id) {
                people.erase(it);
                return;
            }
        }
    }

    template<typename T>
    void updatePerson(vector<T>& people, const string& id, const string& newName, int newAge) {
        for (auto& person : people) {
            if (person.id == id) {
                person.name = newName;
                person.age = newAge;
                return;
            }
        }
    }

    template<typename T>
    void searchPerson(const vector<T>& people, const string& id) const {
        for (const auto& person : people) {
            if (person.id == id) {
                cout << "Name: " << person.name << ", Age: " << person.age << ", ID: " << person.id << endl;
                return;
            }
        }
        cout << "Person not found." << endl;
    }

    template<typename T>
    void displayPeople(const vector<T>& people) const {
        for (const auto& person : people) {
            cout << "Name: " << person.name << ", Age: " << person.age << ", ID: " << person.id << endl;
        }
    }

public:
    void addChild(const string& name, int age, const string& id) {
        addPerson(children, Child(name, age, id));
    }

    void addBabysitter(const string& name, int age, const string& id) {
        addPerson(babysitters, Babysitter(name, age, id));
    }

    void deleteChild(const string& id) {
        deletePerson(children, id);
    }

    void deleteBabysitter(const string& id) {
        deletePerson(babysitters, id);
    }

    void updateChild(const string& id, const string& newName, int newAge) {
        updatePerson(children, id, newName, newAge);
    }

    void updateBabysitter(const string& id, const string& newName, int newAge) {
        updatePerson(babysitters, id, newName, newAge);
    }

    void searchChild(const string& id) const {
        searchPerson(children, id);
    }

    void searchBabysitter(const string& id) const {
        searchPerson(babysitters, id);
    }

    void displayChildren() const {
        displayPeople(children);
    }

    void displayBabysitters() const {
        displayPeople(babysitters);
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 4, "C001");
    nms.addChild("Bob", 5, "C002");
    nms.addBabysitter("John", 30, "B001");
    nms.addBabysitter("Jane", 28, "B002");

    cout << "All children:" << endl;
    nms.displayChildren();

    cout << "All babysitters:" << endl;
    nms.displayBabysitters();

    cout << "Searching for child with ID C001:" << endl;
    nms.searchChild("C001");

    cout << "Updating child with ID C001:" << endl;
    nms.updateChild("C001", "Alice Updated", 6);

    cout << "Searching for child with ID C001 after update:" << endl;
    nms.searchChild("C001");

    cout << "Deleting child with ID C002:" << endl;
    nms.deleteChild("C002");

    cout << "All children after deletion:" << endl;
    nms.displayChildren();

    return 0;
}