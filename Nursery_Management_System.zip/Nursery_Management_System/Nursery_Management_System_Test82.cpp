#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;
    Person(std::string name, int age) : name(name), age(age) {}
};

class Child : public Person {
public:
    Child(std::string name, int age) : Person(name, age) {}
};

class Babysitter : public Person {
public:
    Babysitter(std::string name, int age) : Person(name, age) {}
};

class Nursery {
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

    template<class T>
    void displayList(const std::vector<T>& list) {
        for (const auto& item : list) {
            std::cout << "Name: " << item.name << ", Age: " << item.age << "\n";
        }
    }

public:
    void addChild(const std::string& name, int age) {
        children.push_back(Child(name, age));
    }

    void deleteChild(const std::string& name) {
        children.erase(std::remove_if(children.begin(), children.end(), [&](Child& c) { return c.name == name; }), children.end());
    }

    void updateChild(const std::string& name, int age) {
        for (auto& child : children) {
            if (child.name == name) {
                child.age = age;
                break;
            }
        }
    }

    void searchChild(const std::string& name) {
        for (const auto& child : children) {
            if (child.name == name) {
                std::cout << "Child Found - Name: " << child.name << ", Age: " << child.age << "\n";
                return;
            }
        }
        std::cout << "Child Not Found\n";
    }

    void displayChildren() {
        displayList(children);
    }

    void addBabysitter(const std::string& name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteBabysitter(const std::string& name) {
        babysitters.erase(std::remove_if(babysitters.begin(), babysitters.end(), [&](Babysitter& b) { return b.name == name; }), babysitters.end());
    }

    void updateBabysitter(const std::string& name, int age) {
        for (auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                babysitter.age = age;
                break;
            }
        }
    }

    void searchBabysitter(const std::string& name) {
        for (const auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                std::cout << "Babysitter Found - Name: " << babysitter.name << ", Age: " << babysitter.age << "\n";
                return;
            }
        }
        std::cout << "Babysitter Not Found\n";
    }

    void displayBabysitters() {
        displayList(babysitters);
    }
};

int main() {
    Nursery nursery;
    nursery.addChild("Alice", 4);
    nursery.addChild("Bob", 3);
    nursery.displayChildren();
    
    nursery.addBabysitter("Carol", 25);
    nursery.addBabysitter("Dave", 30);
    nursery.displayBabysitters();

    nursery.searchChild("Alice");
    nursery.searchBabysitter("Carol");

    nursery.updateChild("Alice", 5);
    nursery.updateBabysitter("Carol", 26);

    nursery.displayChildren();
    nursery.displayBabysitters();

    nursery.deleteChild("Bob");
    nursery.deleteBabysitter("Dave");

    nursery.displayChildren();
    nursery.displayBabysitters();

    return 0;
}