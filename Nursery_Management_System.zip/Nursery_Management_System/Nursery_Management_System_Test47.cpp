#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Person {
    string name;
    int age;
    string id;
};

class NurseryManagementSystem {
    vector<Person> children;
    vector<Person> babysitters;

public:
    void addPerson(bool isChild, string name, int age, string id) {
        Person person = {name, age, id};
        if (isChild) {
            children.push_back(person);
        } else {
            babysitters.push_back(person);
        }
    }

    void deletePerson(bool isChild, string id) {
        vector<Person>& persons = isChild ? children : babysitters;
        for (auto it = persons.begin(); it != persons.end(); ++it) {
            if (it->id == id) {
                persons.erase(it);
                break;
            }
        }
    }

    void updatePerson(bool isChild, string id, string newName, int newAge) {
        vector<Person>& persons = isChild ? children : babysitters;
        for (auto& person : persons) {
            if (person.id == id) {
                person.name = newName;
                person.age = newAge;
                break;
            }
        }
    }

    void searchPerson(bool isChild, string id) {
        vector<Person>& persons = isChild ? children : babysitters;
        for (const auto& person : persons) {
            if (person.id == id) {
                cout << "Name: " << person.name << ", Age: " << person.age << ", ID: " << person.id << endl;
                return;
            }
        }
        cout << "Person not found" << endl;
    }

    void displayPersons(bool isChild) {
        vector<Person>& persons = isChild ? children : babysitters;
        for (const auto& person : persons) {
            cout << "Name: " << person.name << ", Age: " << person.age << ", ID: " << person.id << endl;
        }
    }
};

int main() {
    NurseryManagementSystem system;
    system.addPerson(true, "John Doe", 3, "C1");
    system.addPerson(false, "Jane Smith", 28, "B1");

    system.displayPersons(true);
    system.displayPersons(false);

    system.searchPerson(true, "C1");
    system.updatePerson(true, "C1", "John Doe Jr.", 4);
    system.searchPerson(true, "C1");

    system.deletePerson(true, "C1");
    system.displayPersons(true);

    return 0;
}