#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Person {
    string name;
    int age;
};

class NurseryManagementSystem {
private:
    vector<Person> children;
    vector<Person> babysitters;

public:
    void addChild(const string& name, int age) {
        children.push_back({name, age});
    }

    void addBabysitter(const string& name, int age) {
        babysitters.push_back({name, age});
    }

    void deleteChild(const string& name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->name == name) {
                children.erase(it);
                break;
            }
        }
    }

    void deleteBabysitter(const string& name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->name == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateChild(const string& name, const string& newName, int newAge) {
        for (auto& child : children) {
            if (child.name == name) {
                child.name = newName;
                child.age = newAge;
                break;
            }
        }
    }

    void updateBabysitter(const string& name, const string& newName, int newAge) {
        for (auto& sitter : babysitters) {
            if (sitter.name == name) {
                sitter.name = newName;
                sitter.age = newAge;
                break;
            }
        }
    }

    void searchChild(const string& name) {
        for (const auto& child : children) {
            if (child.name == name) {
                cout << "Child found: " << child.name << ", Age: " << child.age << endl;
                return;
            }
        }
        cout << "Child not found." << endl;
    }

    void searchBabysitter(const string& name) {
        for (const auto& sitter : babysitters) {
            if (sitter.name == name) {
                cout << "Babysitter found: " << sitter.name << ", Age: " << sitter.age << endl;
                return;
            }
        }
        cout << "Babysitter not found." << endl;
    }

    void displayChildren() {
        cout << "Children Information:" << endl;
        for (const auto& child : children) {
            cout << "Name: " << child.name << ", Age: " << child.age << endl;
        }
    }

    void displayBabysitters() {
        cout << "Babysitters Information:" << endl;
        for (const auto& sitter : babysitters) {
            cout << "Name: " << sitter.name << ", Age: " << sitter.age << endl;
        }
    }
};

int main() {
    NurseryManagementSystem system;
    system.addChild("Alice", 5);
    system.addChild("Bob", 6);
    system.addBabysitter("Mary", 25);
    system.addBabysitter("John", 22);

    cout << "All Children and Babysitters:" << endl;
    system.displayChildren();
    system.displayBabysitters();

    cout << "\nSearching for a child named Bob:" << endl;
    system.searchChild("Bob");

    cout << "\nUpdating Babysitter John's details:" << endl;
    system.updateBabysitter("John", "Johnny", 23);
    system.displayBabysitters();

    cout << "\nDeleting child Alice:" << endl;
    system.deleteChild("Alice");
    system.displayChildren();

    return 0;
}