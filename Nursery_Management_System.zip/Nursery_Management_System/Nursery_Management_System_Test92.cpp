#include <iostream>
#include <vector>
#include <string>

struct Person {
    std::string name;
    int age;
};

class NurseryManagement {
    std::vector<Person> children;
    std::vector<Person> babysitters;
    
    void displayPerson(const Person& person) {
        std::cout << "Name: " << person.name << ", Age: " << person.age << std::endl;
    }

public:
    void addChild(const std::string& name, int age) {
        children.push_back({name, age});
    }

    void addBabysitter(const std::string& name, int age) {
        babysitters.push_back({name, age});
    }

    void deleteChild(const std::string& name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->name == name) {
                children.erase(it);
                break;
            }
        }
    }

    void deleteBabysitter(const std::string& name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->name == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateChild(const std::string& name, const std::string& newName, int newAge) {
        for (auto& child : children) {
            if (child.name == name) {
                child.name = newName;
                child.age = newAge;
                break;
            }
        }
    }

    void updateBabysitter(const std::string& name, const std::string& newName, int newAge) {
        for (auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                babysitter.name = newName;
                babysitter.age = newAge;
                break;
            }
        }
    }

    bool searchChild(const std::string& name) {
        for (const auto& child : children) {
            if (child.name == name) {
                displayPerson(child);
                return true;
            }
        }
        return false;
    }

    bool searchBabysitter(const std::string& name) {
        for (const auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                displayPerson(babysitter);
                return true;
            }
        }
        return false;
    }

    void displayChildren() {
        std::cout << "Children Information:" << std::endl;
        for (const auto& child : children) {
            displayPerson(child);
        }
    }

    void displayBabysitters() {
        std::cout << "Babysitters Information:" << std::endl;
        for (const auto& babysitter : babysitters) {
            displayPerson(babysitter);
        }
    }
};

int main() {
    NurseryManagement nm;
    nm.addChild("Alice", 5);
    nm.addChild("Bob", 4);
    nm.addBabysitter("Clara", 30);
    nm.addBabysitter("David", 28);
    nm.displayChildren();
    nm.displayBabysitters();
    nm.updateChild("Alice", "Alicia", 6);
    nm.deleteBabysitter("David");
    nm.searchChild("Alicia");
    nm.displayChildren();
    nm.displayBabysitters();
    return 0;
}