#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int age;
public:
    Person(std::string name, int age) : name(name), age(age) {}
    std::string getName() { return name; }
    int getAge() { return age; }
    void setName(std::string newName) { name = newName; }
    void setAge(int newAge) { age = newAge; }
    virtual void display() = 0;
};

class Child : public Person {
public:
    Child(std::string name, int age) : Person(name, age) {}
    void display() {
        std::cout << "Child Name: " << name << ", Age: " << age << std::endl;
    }
};

class Babysitter : public Person {
private:
    double hourlyRate;
public:
    Babysitter(std::string name, int age, double hourlyRate) : Person(name, age), hourlyRate(hourlyRate) {}
    double getHourlyRate() { return hourlyRate; }
    void setHourlyRate(double newRate) { hourlyRate = newRate; }
    void display() {
        std::cout << "Babysitter Name: " << name << ", Age: " << age << ", Hourly Rate: " << hourlyRate << std::endl;
    }
};

template <typename T>
class NurseryManager {
private:
    std::vector<T> people;
public:
    void addPerson(T person) {
        people.push_back(person);
    }
    void deletePerson(std::string name) {
        for (auto it = people.begin(); it != people.end(); ++it) {
            if (it->getName() == name) {
                people.erase(it);
                break;
            }
        }
    }
    void updatePerson(std::string name, T updatedPerson) {
        for (auto& person : people) {
            if (person.getName() == name) {
                person = updatedPerson;
                break;
            }
        }
    }
    T* searchPerson(std::string name) {
        for (auto& person : people) {
            if (person.getName() == name) {
                return &person;
            }
        }
        return nullptr;
    }
    void displayAll() {
        for (const auto& person : people) {
            person.display();
        }
    }
};

int main() {
    NurseryManager<Child> childManager;
    NurseryManager<Babysitter> babysitterManager;

    Child child1("Alice", 4);
    Child child2("Bob", 5);
    Babysitter babysitter1("Emma", 30, 15.5);
    Babysitter babysitter2("Olivia", 28, 18.0);

    childManager.addPerson(child1);
    childManager.addPerson(child2);
    babysitterManager.addPerson(babysitter1);
    babysitterManager.addPerson(babysitter2);

    childManager.displayAll();
    babysitterManager.displayAll();

    Babysitter newBabysitter("Olivia", 29, 20.0);
    babysitterManager.updatePerson("Olivia", newBabysitter);
    Babysitter* foundBabysitter = babysitterManager.searchPerson("Olivia");
    if (foundBabysitter) {
        foundBabysitter->display();
    }

    childManager.deletePerson("Alice");
    childManager.displayAll();

    return 0;
}