#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int age;
public:
    Person(std::string n, int a) : name(n), age(a) {}
    std::string getName() const { return name; }
    int getAge() const { return age; }
};

class Child : public Person {
public:
    Child(std::string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(std::string n, int a) : Person(n, a) {}
};

class NurseryManagementSystem {
private:
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

    template<typename T>
    void displayList(const std::vector<T>& list) {
        for (const auto& person : list) {
            std::cout << "Name: " << person.getName() << ", Age: " << person.getAge() << std::endl;
        }
    }

public:
    void addChild(const std::string& n, int a) {
        children.emplace_back(n, a);
    }

    void removeChild(const std::string& n) {
        children.erase(std::remove_if(children.begin(), children.end(), [&](const Child& c) { return c.getName() == n; }), children.end());
    }

    void updateChild(const std::string& n, int a) {
        for (auto& child : children) {
            if (child.getName() == n) {
                child = Child(n, a);
                break;
            }
        }
    }

    void searchChild(const std::string& n) {
        for (const auto& child : children) {
            if (child.getName() == n) {
                std::cout << "Found Child - Name: " << child.getName() << ", Age: " << child.getAge() << std::endl;
                return;
            }
        }
        std::cout << "Child not found" << std::endl;
    }

    void displayChildren() {
        displayList(children);
    }

    void addBabysitter(const std::string& n, int a) {
        babysitters.emplace_back(n, a);
    }

    void removeBabysitter(const std::string& n) {
        babysitters.erase(std::remove_if(babysitters.begin(), babysitters.end(), [&](const Babysitter& b) { return b.getName() == n; }), babysitters.end());
    }

    void updateBabysitter(const std::string& n, int a) {
        for (auto& babysitter : babysitters) {
            if (babysitter.getName() == n) {
                babysitter = Babysitter(n, a);
                break;
            }
        }
    }

    void searchBabysitter(const std::string& n) {
        for (const auto& babysitter : babysitters) {
            if (babysitter.getName() == n) {
                std::cout << "Found Babysitter - Name: " << babysitter.getName() << ", Age: " << babysitter.getAge() << std::endl;
                return;
            }
        }
        std::cout << "Babysitter not found" << std::endl;
    }

    void displayBabysitters() {
        displayList(babysitters);
    }
};

int main() {
    NurseryManagementSystem nms;

    nms.addChild("John", 5);
    nms.addChild("Alice", 4);
    nms.addBabysitter("Emma", 25);
    nms.addBabysitter("Olivia", 30);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.searchChild("John");
    nms.searchBabysitter("Emma");

    nms.updateChild("Alice", 6);
    nms.updateBabysitter("Olivia", 32);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.removeChild("John");
    nms.removeBabysitter("Emma");

    nms.displayChildren();
    nms.displayBabysitters();

    return 0;
}