#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
protected:
    string name;
    int age;
public:
    Person(string name, int age) : name(name), age(age) {}
    string getName() const { return name; }
    int getAge() const { return age; }
    virtual void display() const = 0;
};

class Child : public Person {
public:
    Child(string name, int age) : Person(name, age) {}
    void display() const override {
        cout << "Child Name: " << name << ", Age: " << age << endl;
    }
};

class Babysitter : public Person {
public:
    Babysitter(string name, int age) : Person(name, age) {}
    void display() const override {
        cout << "Babysitter Name: " << name << ", Age: " << age << endl;
    }
};

template<typename T>
class NurseryManagement {
    vector<T*> records;
public:
    ~NurseryManagement() {
        for (auto& record : records) {
            delete record;
        }
    }
    void addPerson(T* person) {
        records.push_back(person);
    }
    void deletePerson(const string& name) {
        for (auto it = records.begin(); it != records.end(); ++it) {
            if ((*it)->getName() == name) {
                delete *it;
                records.erase(it);
                break;
            }
        }
    }
    void updatePerson(const string& name, T* updatedPerson) {
        for (auto& person : records) {
            if (person->getName() == name) {
                delete person;
                person = updatedPerson;
                break;
            }
        }
    }
    T* searchPerson(const string& name) const {
        for (auto& person : records) {
            if (person->getName() == name) {
                return person;
            }
        }
        return nullptr;
    }
    void displayAll() const {
        for (auto& person : records) {
            person->display();
        }
    }
};

enum MenuOptions {
    AddChild,
    AddBabysitter,
    DeleteChild,
    DeleteBabysitter,
    UpdateChild,
    UpdateBabysitter,
    SearchChild,
    SearchBabysitter,
    DisplayChildren,
    DisplayBabysitters,
    Exit
};

int main() {
    NurseryManagement<Child> childManagement;
    NurseryManagement<Babysitter> babysitterManagement;
    int option;

    do {
        cout << "Select an option: " << endl;
        cout << "0. Add Child" << endl;
        cout << "1. Add Babysitter" << endl;
        cout << "2. Delete Child" << endl;
        cout << "3. Delete Babysitter" << endl;
        cout << "4. Update Child" << endl;
        cout << "5. Update Babysitter" << endl;
        cout << "6. Search Child" << endl;
        cout << "7. Search Babysitter" << endl;
        cout << "8. Display All Children" << endl;
        cout << "9. Display All Babysitters" << endl;
        cout << "10. Exit" << endl;
        cin >> option;

        string name;
        int age;
        Child* child;
        Babysitter* babysitter;

        switch (option) {
            case AddChild:
                cout << "Enter child's name: ";
                cin >> name;
                cout << "Enter child's age: ";
                cin >> age;
                childManagement.addPerson(new Child(name, age));
                break;
            case AddBabysitter:
                cout << "Enter babysitter's name: ";
                cin >> name;
                cout << "Enter babysitter's age: ";
                cin >> age;
                babysitterManagement.addPerson(new Babysitter(name, age));
                break;
            case DeleteChild:
                cout << "Enter child's name to delete: ";
                cin >> name;
                childManagement.deletePerson(name);
                break;
            case DeleteBabysitter:
                cout << "Enter babysitter's name to delete: ";
                cin >> name;
                babysitterManagement.deletePerson(name);
                break;
            case UpdateChild:
                cout << "Enter child's name to update: ";
                cin >> name;
                cout << "Enter new child's name: ";
                cin >> name;
                cout << "Enter new child's age: ";
                cin >> age;
                childManagement.updatePerson(name, new Child(name, age));
                break;
            case UpdateBabysitter:
                cout << "Enter babysitter's name to update: ";
                cin >> name;
                cout << "Enter new babysitter's name: ";
                cin >> name;
                cout << "Enter new babysitter's age: ";
                cin >> age;
                babysitterManagement.updatePerson(name, new Babysitter(name, age));
                break;
            case SearchChild:
                cout << "Enter child's name to search: ";
                cin >> name;
                child = childManagement.searchPerson(name);
                if (child) {
                    child->display();
                } else {
                    cout << "Child not found." << endl;
                }
                break;
            case SearchBabysitter:
                cout << "Enter babysitter's name to search: ";
                cin >> name;
                babysitter = babysitterManagement.searchPerson(name);
                if (babysitter) {
                    babysitter->display();
                } else {
                    cout << "Babysitter not found." << endl;
                }
                break;
            case DisplayChildren:
                childManagement.displayAll();
                break;
            case DisplayBabysitters:
                babysitterManagement.displayAll();
                break;
        }

    } while (option != Exit);

    return 0;
}