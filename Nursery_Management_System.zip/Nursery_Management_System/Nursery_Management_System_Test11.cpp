#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Child {
    string name;
    int age;
};

struct Babysitter {
    string name;
    int experience;
};

class NurseryManagementSystem {
private:
    vector<Child> children;
    vector<Babysitter> babysitters;

public:
    void addChild(const string& name, int age) {
        children.push_back({name, age});
    }

    void deleteChild(const string& name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->name == name) {
                children.erase(it);
                break;
            }
        }
    }

    void updateChild(const string& name, const string& newName, int newAge) {
        for (auto& child : children) {
            if (child.name == name) {
                child.name = newName;
                child.age = newAge;
                break;
            }
        }
    }

    void searchChild(const string& name) {
        for (const auto& child : children) {
            if (child.name == name) {
                cout << "Child Found: Name: " << child.name << ", Age: " << child.age << endl;
                return;
            }
        }
        cout << "Child not found." << endl;
    }

    void displayChildren() {
        for (const auto& child : children) {
            cout << "Child Name: " << child.name << ", Age: " << child.age << endl;
        }
    }

    void addBabysitter(const string& name, int experience) {
        babysitters.push_back({name, experience});
    }

    void deleteBabysitter(const string& name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->name == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateBabysitter(const string& name, const string& newName, int newExperience) {
        for (auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                babysitter.name = newName;
                babysitter.experience = newExperience;
                break;
            }
        }
    }

    void searchBabysitter(const string& name) {
        for (const auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                cout << "Babysitter Found: Name: " << babysitter.name << ", Experience: " << babysitter.experience << " years" << endl;
                return;
            }
        }
        cout << "Babysitter not found." << endl;
    }

    void displayBabysitters() {
        for (const auto& babysitter : babysitters) {
            cout << "Babysitter Name: " << babysitter.name << ", Experience: " << babysitter.experience << " years" << endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 3);
    nms.addChild("Bob", 4);
    nms.addBabysitter("Mary", 5);
    nms.addBabysitter("John", 7);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.searchChild("Alice");
    nms.searchBabysitter("Mary");

    nms.updateChild("Bob", "Bobby", 5);
    nms.updateBabysitter("John", "Johnny", 8);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.deleteChild("Alice");
    nms.deleteBabysitter("Mary");

    nms.displayChildren();
    nms.displayBabysitters();

    return 0;
}