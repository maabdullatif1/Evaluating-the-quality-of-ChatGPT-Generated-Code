#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int age;
public:
    Person(std::string n, int a) : name(n), age(a) {}
    std::string getName() { return name; }
    int getAge() { return age; }
    virtual void display() = 0;
};

class Child : public Person {
public:
    Child(std::string name, int age) : Person(name, age) {}
    void display() override {
        std::cout << "Child Name: " << name << ", Age: " << age << std::endl;
    }
};

class Babysitter : public Person {
public:
    Babysitter(std::string name, int age) : Person(name, age) {}
    void display() override {
        std::cout << "Babysitter Name: " << name << ", Age: " << age << std::endl;
    }
};

class NurseryManagement {
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;
public:
    void addChild(std::string name, int age) {
        children.push_back(Child(name, age));
    }
    
    void addBabysitter(std::string name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }
    
    void deleteChild(std::string name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->getName() == name) {
                children.erase(it);
                break;
            }
        }
    }
    
    void deleteBabysitter(std::string name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->getName() == name) {
                babysitters.erase(it);
                break;
            }
        }
    }
    
    void updateChild(std::string oldName, std::string newName, int newAge) {
        for (auto &child : children) {
            if (child.getName() == oldName) {
                child = Child(newName, newAge);
            }
        }
    }
    
    void updateBabysitter(std::string oldName, std::string newName, int newAge) {
        for (auto &babysitter : babysitters) {
            if (babysitter.getName() == oldName) {
                babysitter = Babysitter(newName, newAge);
            }
        }
    }
    
    void searchChild(std::string name) {
        for (auto &child : children) {
            if (child.getName() == name) {
                child.display();
                return;
            }
        }
        std::cout << "Child not found." << std::endl;
    }
    
    void searchBabysitter(std::string name) {
        for (auto &babysitter : babysitters) {
            if (babysitter.getName() == name) {
                babysitter.display();
                return;
            }
        }
        std::cout << "Babysitter not found." << std::endl;
    }
    
    void displayAllChildren() {
        for (auto &child : children) {
            child.display();
        }
    }
    
    void displayAllBabysitters() {
        for (auto &babysitter : babysitters) {
            babysitter.display();
        }
    }
};

int main() {
    NurseryManagement nursery;
    nursery.addChild("Alice", 5);
    nursery.addChild("Bob", 4);
    nursery.addBabysitter("Mary", 25);
    nursery.addBabysitter("John", 30);

    nursery.displayAllChildren();
    nursery.displayAllBabysitters();
    
    nursery.searchChild("Alice");
    nursery.searchBabysitter("Mary");

    nursery.updateChild("Alice", "Alice Smith", 6);
    nursery.updateBabysitter("Mary", "Mary Jane", 26);

    nursery.deleteChild("Bob");
    nursery.deleteBabysitter("John");

    nursery.displayAllChildren();
    nursery.displayAllBabysitters();
    
    return 0;
}