#include <iostream>
#include <cstring>

class Person {
protected:
    int id;
    char name[50];
    int age;
public:
    Person(int id = 0, const char* name = "", int age = 0) 
        : id(id), age(age) {
        std::strcpy(this->name, name);
    }
    void updateDetails(const char* newName, int newAge) {
        std::strcpy(name, newName);
        age = newAge;
    }
    int getId() const {
        return id;
    }
    const char* getName() const {
        return name;
    }
    virtual void display() const {
        std::cout << "ID: " << id << ", Name: " << name << ", Age: " << age;
    }
};

class Child : public Person {
public:
    Child(int id = 0, const char* name = "", int age = 0) 
        : Person(id, name, age) {}
    void display() const override {
        std::cout << "Child - ";
        Person::display();
        std::cout << std::endl;
    }
};

class Babysitter : public Person {
public:
    Babysitter(int id = 0, const char* name = "", int age = 0) 
        : Person(id, name, age) {}
    void display() const override {
        std::cout << "Babysitter - ";
        Person::display();
        std::cout << std::endl;
    }
};

template <typename T>
class NurseryManager {
    T items[100];
    int count;
public:
    NurseryManager() : count(0) {}
    void addItem(int id, const char* name, int age) {
        items[count++] = T(id, name, age);
    }
    void deleteItem(int id) {
        for (int i = 0; i < count; ++i) {
            if (items[i].getId() == id) {
                for (int j = i; j < count - 1; ++j) {
                    items[j] = items[j + 1];
                }
                --count;
                break;
            }
        }
    }
    void updateItem(int id, const char* name, int age) {
        for (int i = 0; i < count; ++i) {
            if (items[i].getId() == id) {
                items[i].updateDetails(name, age);
                break;
            }
        }
    }
    T* searchItem(int id) {
        for (int i = 0; i < count; ++i) {
            if (items[i].getId() == id) {
                return &items[i];
            }
        }
        return nullptr;
    }
    void displayItems() const {
        for (int i = 0; i < count; ++i) {
            items[i].display();
        }
    }
};

int main() {
    NurseryManager<Child> childManager;
    NurseryManager<Babysitter> babysitterManager;

    childManager.addItem(1, "Alice", 4);
    childManager.addItem(2, "Bob", 5);

    babysitterManager.addItem(1, "Eve", 25);

    std::cout << "Children:" << std::endl;
    childManager.displayItems();
    std::cout << "Babysitters:" << std::endl;
    babysitterManager.displayItems();

    childManager.updateItem(1, "Alice A.", 5);
    babysitterManager.deleteItem(1);

    std::cout << "\nUpdated Children:" << std::endl;
    childManager.displayItems();
    std::cout << "Updated Babysitters:" << std::endl;
    babysitterManager.displayItems();

    return 0;
}