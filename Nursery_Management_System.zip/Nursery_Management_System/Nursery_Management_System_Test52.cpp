#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    int age;
};

class NurseryManagementSystem {
    vector<Person> children;
    vector<Person> babysitters;

    void displayDetails(const vector<Person>& list) {
        for (const auto& p : list) {
            cout << "Name: " << p.name << ", Age: " << p.age << endl;
        }
    }

public:
    void addChild(const string& name, int age) {
        children.push_back({name, age});
    }

    void deleteChild(const string& name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->name == name) {
                children.erase(it);
                break;
            }
        }
    }

    void updateChild(const string& name, const string& newName, int newAge) {
        for (auto& child : children) {
            if (child.name == name) {
                child.name = newName;
                child.age = newAge;
                break;
            }
        }
    }

    void searchChild(const string& name) {
        for (const auto& child : children) {
            if (child.name == name) {
                cout << "Child found: " << child.name << ", Age: " << child.age << endl;
                return;
            }
        }
        cout << "Child not found." << endl;
    }

    void displayChildren() {
        displayDetails(children);
    }

    void addBabysitter(const string& name, int age) {
        babysitters.push_back({name, age});
    }

    void deleteBabysitter(const string& name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->name == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateBabysitter(const string& name, const string& newName, int newAge) {
        for (auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                babysitter.name = newName;
                babysitter.age = newAge;
                break;
            }
        }
    }

    void searchBabysitter(const string& name) {
        for (const auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                cout << "Babysitter found: " << babysitter.name << ", Age: " << babysitter.age << endl;
                return;
            }
        }
        cout << "Babysitter not found." << endl;
    }

    void displayBabysitters() {
        displayDetails(babysitters);
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 4);
    nms.addChild("Bob", 5);
    nms.displayChildren();
    nms.updateChild("Alice", "Alicia", 5);
    nms.searchChild("Alicia");
    nms.deleteChild("Bob");
    nms.displayChildren();

    nms.addBabysitter("Carol", 30);
    nms.addBabysitter("Dave", 25);
    nms.displayBabysitters();
    nms.updateBabysitter("Dave", "David", 26);
    nms.searchBabysitter("David");
    nms.deleteBabysitter("Carol");
    nms.displayBabysitters();

    return 0;
}