#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
public:
    string name;
    int age;
    Person(string n, int a) : name(n), age(a) {}
};

class Child : public Person {
public:
    Child(string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(string n, int a) : Person(n, a) {}
};

class NurseryManagementSystem {
    vector<Child> children;
    vector<Babysitter> babysitters;

public:
    void addChild(string name, int age) {
        children.push_back(Child(name, age));
    }
    
    void deleteChild(string name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->name == name) {
                children.erase(it);
                break;
            }
        }
    }

    void updateChild(string name, string newName, int newAge) {
        for (auto &child : children) {
            if (child.name == name) {
                child.name = newName;
                child.age = newAge;
                break;
            }
        }
    }
    
    void addBabysitter(string name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }
    
    void deleteBabysitter(string name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->name == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateBabysitter(string name, string newName, int newAge) {
        for (auto &babysitter : babysitters) {
            if (babysitter.name == name) {
                babysitter.name = newName;
                babysitter.age = newAge;
                break;
            }
        }
    }
    
    void searchChild(string name) {
        for (const auto &child : children) {
            if (child.name == name) {
                cout << "Child Found: " << child.name << ", Age: " << child.age << endl;
                return;
            }
        }
        cout << "Child Not Found" << endl;
    }
    
    void searchBabysitter(string name) {
        for (const auto &babysitter : babysitters) {
            if (babysitter.name == name) {
                cout << "Babysitter Found: " << babysitter.name << ", Age: " << babysitter.age << endl;
                return;
            }
        }
        cout << "Babysitter Not Found" << endl;
    }

    void displayChildren() {
        for (const auto &child : children)
            cout << "Child: " << child.name << ", Age: " << child.age << endl;
    }
    
    void displayBabysitters() {
        for (const auto &babysitter : babysitters)
            cout << "Babysitter: " << babysitter.name << ", Age: " << babysitter.age << endl;
    }
};

int main() {
    NurseryManagementSystem system;
    system.addChild("Alice", 3);
    system.addChild("Bob", 4);
    system.addBabysitter("Carol", 30);
    system.addBabysitter("Dave", 28);

    system.displayChildren();
    system.displayBabysitters();

    system.searchChild("Alice");
    system.searchBabysitter("Eve");

    system.updateChild("Alice", "Alice Johnson", 4);
    system.updateBabysitter("Carol", "Carol Smith", 31);

    system.displayChildren();
    system.displayBabysitters();

    system.deleteChild("Bob");
    system.deleteBabysitter("Dave");

    system.displayChildren();
    system.displayBabysitters();

    return 0;
}