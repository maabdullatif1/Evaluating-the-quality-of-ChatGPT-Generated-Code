#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
protected:
    string name;
    int age;
public:
    Person(string name, int age) : name(name), age(age) {}
    string getName() const { return name; }
    int getAge() const { return age; }
    virtual void displayInfo() const = 0;
};

class Child : public Person {
public:
    Child(string name, int age) : Person(name, age) {}
    void displayInfo() const override {
        cout << "Child Name: " << name << " Age: " << age << endl;
    }
};

class Babysitter : public Person {
private:
    int experience;
public:
    Babysitter(string name, int age, int experience) : Person(name, age), experience(experience) {}
    void displayInfo() const override {
        cout << "Babysitter Name: " << name << " Age: " << age << " Experience: " << experience << " years" << endl;
    }
};

class NurseryManagementSystem {
private:
    vector<Child> children;
    vector<Babysitter> babysitters;
public:
    void addChild(string name, int age) {
        children.push_back(Child(name, age));
    }

    void addBabysitter(string name, int age, int experience) {
        babysitters.push_back(Babysitter(name, age, experience));
    }

    void deleteChild(string name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->getName() == name) {
                children.erase(it);
                break;
            }
        }
    }

    void deleteBabysitter(string name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->getName() == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateChild(string currentName, string newName, int newAge) {
        for (auto& child : children) {
            if (child.getName() == currentName) {
                child = Child(newName, newAge);
                break;
            }
        }
    }

    void updateBabysitter(string currentName, string newName, int newAge, int newExperience) {
        for (auto& babysitter : babysitters) {
            if (babysitter.getName() == currentName) {
                babysitter = Babysitter(newName, newAge, newExperience);
                break;
            }
        }
    }

    void searchChild(string name) const {
        for (const auto& child : children) {
            if (child.getName() == name) {
                child.displayInfo();
                return;
            }
        }
        cout << "Child not found.\n";
    }

    void searchBabysitter(string name) const {
        for (const auto& babysitter : babysitters) {
            if (babysitter.getName() == name) {
                babysitter.displayInfo();
                return;
            }
        }
        cout << "Babysitter not found.\n";
    }

    void displayAllChildren() const {
        for (const auto& child : children) {
            child.displayInfo();
        }
    }

    void displayAllBabysitters() const {
        for (const auto& babysitter : babysitters) {
            babysitter.displayInfo();
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 5);
    nms.addChild("Bob", 4);
    nms.addBabysitter("Carol", 30, 5);
    nms.addBabysitter("Dave", 28, 3);

    cout << "All Children:\n";
    nms.displayAllChildren();

    cout << "All Babysitters:\n";
    nms.displayAllBabysitters();

    nms.searchChild("Alice");
    nms.searchBabysitter("Carol");

    nms.updateChild("Bob", "Bobby", 6);
    nms.updateBabysitter("Dave", "David", 29, 4);

    cout << "Updated Information:\n";
    nms.displayAllChildren();
    nms.displayAllBabysitters();

    nms.deleteChild("Alice");
    nms.deleteBabysitter("Carol");

    cout << "After Deletion:\n";
    nms.displayAllChildren();
    nms.displayAllBabysitters();

    return 0;
}