#include <iostream>
#include <string>

using namespace std;

struct Person {
    string name;
    int age;
};

struct Node {
    Person person;
    Node* next;
};

class NurseryManagement {
    Node* childrenHead;
    Node* babysittersHead;

public:
    NurseryManagement() : childrenHead(nullptr), babysittersHead(nullptr) {}

    ~NurseryManagement() {
        clearList(childrenHead);
        clearList(babysittersHead);
    }

    void addPerson(Node*& head, const string& name, int age) {
        Node* newNode = new Node{{name, age}, head};
        head = newNode;
    }

    void deletePerson(Node*& head, const string& name) {
        Node* prev = nullptr;
        Node* current = head;
        while (current != nullptr && current->person.name != name) {
            prev = current;
            current = current->next;
        }
        if (current == nullptr) return;
        if (prev == nullptr)
            head = current->next;
        else
            prev->next = current->next;
        delete current;
    }

    void updatePerson(Node* head, const string& name, const string& newName, int age) {
        Node* current = head;
        while (current != nullptr) {
            if (current->person.name == name) {
                current->person.name = newName;
                current->person.age = age;
                return;
            }
            current = current->next;
        }
    }

    Person* searchPerson(Node* head, const string& name) {
        Node* current = head;
        while (current != nullptr) {
            if (current->person.name == name) {
                return &(current->person);
            }
            current = current->next;
        }
        return nullptr;
    }

    void displayList(Node* head) {
        Node* current = head;
        while (current != nullptr) {
            cout << "Name: " << current->person.name << ", Age: " << current->person.age << endl;
            current = current->next;
        }
    }

    void clearList(Node*& head) {
        while (head != nullptr) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }

    void addChild(const string& name, int age) {
        addPerson(childrenHead, name, age);
    }

    void deleteChild(const string& name) {
        deletePerson(childrenHead, name);
    }

    void updateChild(const string& name, const string& newName, int age) {
        updatePerson(childrenHead, name, newName, age);
    }

    Person* searchChild(const string& name) {
        return searchPerson(childrenHead, name);
    }

    void displayChildren() {
        displayList(childrenHead);
    }

    void addBabysitter(const string& name, int age) {
        addPerson(babysittersHead, name, age);
    }

    void deleteBabysitter(const string& name) {
        deletePerson(babysittersHead, name);
    }

    void updateBabysitter(const string& name, const string& newName, int age) {
        updatePerson(babysittersHead, name, newName, age);
    }

    Person* searchBabysitter(const string& name) {
        return searchPerson(babysittersHead, name);
    }

    void displayBabysitters() {
        displayList(babysittersHead);
    }
};

int main() {
    NurseryManagement nm;
    nm.addChild("Alice", 4);
    nm.addChild("Bob", 5);
    nm.addBabysitter("Carla", 30);
    nm.addBabysitter("Dave", 25);
    
    cout << "Children:" << endl;
    nm.displayChildren();
    
    cout << "Babysitters:" << endl;
    nm.displayBabysitters();
    
    nm.updateChild("Alice", "Alicia", 5);
    nm.deleteBabysitter("Dave");

    cout << "\nUpdated Children:" << endl;
    nm.displayChildren();
    
    cout << "Updated Babysitters:" << endl;
    nm.displayBabysitters();
    
    return 0;
}