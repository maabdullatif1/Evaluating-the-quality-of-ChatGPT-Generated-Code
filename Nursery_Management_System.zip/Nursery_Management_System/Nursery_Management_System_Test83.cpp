#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;
    virtual void display() const = 0;
};

class Child : public Person {
public:
    void display() const override {
        std::cout << "Child Name: " << name << ", Age: " << age << std::endl;
    }
};

class Babysitter : public Person {
public:
    void display() const override {
        std::cout << "Babysitter Name: " << name << ", Age: " << age << std::endl;
    }
};

template<typename T>
class NurseryManagement {
private:
    std::vector<T> records;
public:
    void add(const T& person) {
        records.push_back(person);
    }

    void remove(const std::string& name) {
        for (auto it = records.begin(); it != records.end(); ++it) {
            if (it->name == name) {
                records.erase(it);
                break;
            }
        }
    }

    void update(const std::string& name, const T& updatedPerson) {
        for (auto& person : records) {
            if (person.name == name) {
                person = updatedPerson;
                break;
            }
        }
    }

    T* search(const std::string& name) {
        for (auto& person : records) {
            if (person.name == name) {
                return &person;
            }
        }
        return nullptr;
    }

    void displayAll() const {
        for (const auto& person : records) {
            person.display();
        }
    }
};

int main() {
    NurseryManagement<Child> children;
    NurseryManagement<Babysitter> babysitters;

    Child child1 {"Tom", 5};
    Child child2 {"Alice", 4};
    children.add(child1);
    children.add(child2);

    Babysitter babysitter1 {"Sarah", 30};
    Babysitter babysitter2 {"John", 25};
    babysitters.add(babysitter1);
    babysitters.add(babysitter2);

    children.displayAll();
    babysitters.displayAll();

    children.remove("Alice");
    babysitters.update("Sarah", Babysitter{"Sarah", 31});

    children.displayAll();
    babysitters.displayAll();

    Person* foundChild = children.search("Tom");
    if (foundChild) foundChild->display();

    Person* foundBabysitter = babysitters.search("Sarah");
    if (foundBabysitter) foundBabysitter->display();

    return 0;
}