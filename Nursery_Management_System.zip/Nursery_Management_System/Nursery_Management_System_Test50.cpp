#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    int age;
};

class Nursery {
    vector<Person> children;
    vector<Person> babysitters;

    void displayPerson(vector<Person> &people) {
        for (size_t i = 0; i < people.size(); ++i) {
            cout << i + 1 << ". Name: " << people[i].name << ", Age: " << people[i].age << endl;
        }
    }

    int findPersonIndex(vector<Person> &people, const string &name) {
        for (size_t i = 0; i < people.size(); ++i) {
            if (people[i].name == name) return i;
        }
        return -1;
    }

public:
    void addChild(const string &name, int age) {
        children.push_back({name, age});
    }

    void addBabysitter(const string &name, int age) {
        babysitters.push_back({name, age});
    }

    void deleteChild(const string &name) {
        int index = findPersonIndex(children, name);
        if (index != -1) children.erase(children.begin() + index);
    }

    void deleteBabysitter(const string &name) {
        int index = findPersonIndex(babysitters, name);
        if (index != -1) babysitters.erase(babysitters.begin() + index);
    }

    void updateChild(const string &name, const string &newName, int newAge) {
        int index = findPersonIndex(children, name);
        if (index != -1) {
            children[index].name = newName;
            children[index].age = newAge;
        }
    }

    void updateBabysitter(const string &name, const string &newName, int newAge) {
        int index = findPersonIndex(babysitters, name);
        if (index != -1) {
            babysitters[index].name = newName;
            babysitters[index].age = newAge;
        }
    }

    void searchChild(const string &name) {
        int index = findPersonIndex(children, name);
        if (index != -1) {
            cout << "Child found: Name: " << children[index].name << ", Age: " << children[index].age << endl;
        } else {
            cout << "Child not found." << endl;
        }
    }

    void searchBabysitter(const string &name) {
        int index = findPersonIndex(babysitters, name);
        if (index != -1) {
            cout << "Babysitter found: Name: " << babysitters[index].name << ", Age: " << babysitters[index].age << endl;
        } else {
            cout << "Babysitter not found." << endl;
        }
    }

    void displayChildren() {
        displayPerson(children);
    }

    void displayBabysitters() {
        displayPerson(babysitters);
    }
};

int main() {
    Nursery nursery;
    int option;
    string name, newName;
    int age, newAge;

    do {
        cout << "Nursery Management System\n";
        cout << "1. Add Child\n2. Add Babysitter\n3. Delete Child\n4. Delete Babysitter\n";
        cout << "5. Update Child\n6. Update Babysitter\n7. Search Child\n8. Search Babysitter\n";
        cout << "9. Display Children\n10. Display Babysitters\n11. Exit\n";
        cout << "Choose an option (1-11): ";
        cin >> option;

        switch (option) {
            case 1:
                cout << "Enter child's name and age: ";
                cin >> name >> age;
                nursery.addChild(name, age);
                break;
            case 2:
                cout << "Enter babysitter's name and age: ";
                cin >> name >> age;
                nursery.addBabysitter(name, age);
                break;
            case 3:
                cout << "Enter child's name to delete: ";
                cin >> name;
                nursery.deleteChild(name);
                break;
            case 4:
                cout << "Enter babysitter's name to delete: ";
                cin >> name;
                nursery.deleteBabysitter(name);
                break;
            case 5:
                cout << "Enter child's current name, new name, and new age: ";
                cin >> name >> newName >> newAge;
                nursery.updateChild(name, newName, newAge);
                break;
            case 6:
                cout << "Enter babysitter's current name, new name, and new age: ";
                cin >> name >> newName >> newAge;
                nursery.updateBabysitter(name, newName, newAge);
                break;
            case 7:
                cout << "Enter child's name to search: ";
                cin >> name;
                nursery.searchChild(name);
                break;
            case 8:
                cout << "Enter babysitter's name to search: ";
                cin >> name;
                nursery.searchBabysitter(name);
                break;
            case 9:
                nursery.displayChildren();
                break;
            case 10:
                nursery.displayBabysitters();
                break;
            case 11:
                cout << "Exiting...\n";
                break;
            default:
                cout << "Invalid option. Please choose a number between 1 and 11.\n";
                break;
        }
    } while (option != 11);

    return 0;
}