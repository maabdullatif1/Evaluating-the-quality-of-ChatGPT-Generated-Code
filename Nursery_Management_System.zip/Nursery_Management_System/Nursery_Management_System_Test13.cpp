#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int age;
public:
    Person(const std::string& name, int age) : name(name), age(age) {}
    virtual ~Person() {}

    std::string getName() const { return name; }
    int getAge() const { return age; }

    virtual void display() const = 0;
};

class Child : public Person {
public:
    Child(const std::string& name, int age) : Person(name, age) {}

    void display() const override {
        std::cout << "Child - Name: " << name << ", Age: " << age << std::endl;
    }
};

class Babysitter : public Person {
public:
    Babysitter(const std::string& name, int age) : Person(name, age) {}

    void display() const override {
        std::cout << "Babysitter - Name: " << name << ", Age: " << age << std::endl;
    }
};

template <typename T>
class NurseryManagementSystem {
private:
    std::vector<T> records;

public:
    void addRecord(const T& record) {
        records.push_back(record);
    }

    void deleteRecord(const std::string& name) {
        for (auto it = records.begin(); it != records.end(); ++it) {
            if (it->getName() == name) {
                records.erase(it);
                break;
            }
        }
    }

    void updateRecord(const std::string& name, const T& newRecord) {
        for (auto& record : records) {
            if (record.getName() == name) {
                record = newRecord;
                break;
            }
        }
    }

    T* searchRecord(const std::string& name) {
        for (auto& record : records) {
            if (record.getName() == name) {
                return &record;
            }
        }
        return nullptr;
    }

    void displayRecords() const {
        for (const auto& record : records) {
            record.display();
        }
    }
};

int main() {
    NurseryManagementSystem<Child> childSystem;
    NurseryManagementSystem<Babysitter> babysitterSystem;

    childSystem.addRecord(Child("Alice", 5));
    childSystem.addRecord(Child("Bob", 3));

    babysitterSystem.addRecord(Babysitter("Carol", 25));
    babysitterSystem.addRecord(Babysitter("Dave", 30));

    std::cout << "Children:" << std::endl;
    childSystem.displayRecords();

    std::cout << "Babysitters:" << std::endl;
    babysitterSystem.displayRecords();

    Child* foundChild = childSystem.searchRecord("Alice");
    if (foundChild) {
        std::cout << "Found Child: ";
        foundChild->display();
    }

    Babysitter* foundBabysitter = babysitterSystem.searchRecord("Carol");
    if (foundBabysitter) {
        std::cout << "Found Babysitter: ";
        foundBabysitter->display();
    }

    childSystem.updateRecord("Alice", Child("Alice", 6));
    babysitterSystem.deleteRecord("Dave");

    std::cout << "Updated Children:" << std::endl;
    childSystem.displayRecords();

    std::cout << "Updated Babysitters:" << std::endl;
    babysitterSystem.displayRecords();

    return 0;
}