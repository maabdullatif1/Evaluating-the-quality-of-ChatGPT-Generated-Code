#include <iostream>
#include <string>
#include <vector>

class Person {
protected:
    std::string name;
    int age;
public:
    Person(std::string name, int age) : name(name), age(age) {}
    virtual void displayInfo() const = 0;
    std::string getName() const { return name; }
    int getAge() const { return age; }
};

class Child : public Person {
public:
    Child(std::string name, int age) : Person(name, age) {}
    void displayInfo() const override {
        std::cout << "Child Name: " << name << ", Age: " << age << std::endl;
    }
};

class Babysitter : public Person {
public:
    Babysitter(std::string name, int age) : Person(name, age) {}
    void displayInfo() const override {
        std::cout << "Babysitter Name: " << name << ", Age: " << age << std::endl;
    }
};

template <typename T>
class NurseryManagementSystem {
    std::vector<T> records;
public:
    void addRecord(const T& record) {
        records.push_back(record);
    }

    void deleteRecord(const std::string& name) {
        for (auto it = records.begin(); it != records.end(); ++it) {
            if (it->getName() == name) {
                records.erase(it);
                break;
            }
        }
    }

    void updateRecord(const std::string& name, const T& newRecord) {
        for (auto &record : records) {
            if (record.getName() == name) {
                record = newRecord;
                break;
            }
        }
    }

    T* searchRecord(const std::string& name) {
        for (auto &record : records) {
            if (record.getName() == name) {
                return &record;
            }
        }
        return nullptr;
    }

    void displayRecords() const {
        for (const auto &record : records) {
            record.displayInfo();
        }
    }
};

int main() {
    NurseryManagementSystem<Child> childSystem;
    NurseryManagementSystem<Babysitter> babysitterSystem;

    Child child1("Alice", 5);
    Child child2("Bob", 4);
    Babysitter babysitter1("Eve", 30);
    Babysitter babysitter2("Charlie", 25);

    childSystem.addRecord(child1);
    childSystem.addRecord(child2);
    babysitterSystem.addRecord(babysitter1);
    babysitterSystem.addRecord(babysitter2);

    std::cout << "Children Records:" << std::endl;
    childSystem.displayRecords();

    std::cout << "Babysitters Records:" << std::endl;
    babysitterSystem.displayRecords();

    return 0;
}