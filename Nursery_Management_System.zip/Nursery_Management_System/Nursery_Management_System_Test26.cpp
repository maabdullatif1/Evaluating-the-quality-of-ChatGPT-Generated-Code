#include <iostream>
#include <string>
#include <vector>

class Person {
public:
    std::string name;
    int age;

    Person(std::string name, int age) : name(name), age(age) {}
};

class Child : public Person {
public:
    Child(std::string name, int age) : Person(name, age) {}
};

class Babysitter : public Person {
public:
    Babysitter(std::string name, int age) : Person(name, age) {}
};

template <typename T>
class ManagementSystem {
private:
    std::vector<T> records;
public:
    void addRecord(const T& person) {
        records.push_back(person);
    }

    void deleteRecord(const std::string& name) {
        for (auto it = records.begin(); it != records.end(); ++it) {
            if (it->name == name) {
                records.erase(it);
                return;
            }
        }
    }

    void updateRecord(const std::string& name, const T& updatedPerson) {
        for (auto& record : records) {
            if (record.name == name) {
                record = updatedPerson;
                return;
            }
        }
    }

    T* searchRecord(const std::string& name) {
        for (auto& record : records) {
            if (record.name == name) {
                return &record;
            }
        }
        return nullptr;
    }

    void displayRecords() const {
        for (const auto& record : records) {
            std::cout << "Name: " << record.name << ", Age: " << record.age << std::endl;
        }
    }
};

int main() {
    ManagementSystem<Child> children;
    ManagementSystem<Babysitter> babysitters;

    children.addRecord(Child("Alice", 4));
    children.addRecord(Child("Bob", 3));

    babysitters.addRecord(Babysitter("Charlie", 25));
    babysitters.addRecord(Babysitter("Dana", 30));

    std::cout << "Children Records: " << std::endl;
    children.displayRecords();

    std::cout << "Babysitter Records: " << std::endl;
    babysitters.displayRecords();

    Child* child = children.searchRecord("Alice");
    if (child) {
        std::cout << "Found Child - Name: " << child->name << ", Age: " << child->age << std::endl;
    }

    Babysitter* babysitter = babysitters.searchRecord("Charlie");
    if (babysitter) {
        std::cout << "Found Babysitter - Name: " << babysitter->name << ", Age: " << babysitter->age << std::endl;
    }

    children.updateRecord("Alice", Child("Alice", 5));
    babysitters.deleteRecord("Dana");

    std::cout << "Updated Children Records: " << std::endl;
    children.displayRecords();

    std::cout << "Updated Babysitter Records: " << std::endl;
    babysitters.displayRecords();

    return 0;
}