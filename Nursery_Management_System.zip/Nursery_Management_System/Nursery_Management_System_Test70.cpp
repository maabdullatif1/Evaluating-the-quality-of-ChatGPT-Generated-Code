#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
protected:
    string name;
    int age;
public:
    Person(string name, int age) : name(name), age(age) {}
    string getName() { return name; }
    int getAge() { return age; }
    void setName(string newName) { name = newName; }
    void setAge(int newAge) { age = newAge; }
};

class Child : public Person {
public:
    Child(string name, int age) : Person(name, age) {}
};

class Babysitter : public Person {
public:
    Babysitter(string name, int age) : Person(name, age) {}
};

class NurseryManagementSystem {
private:
    vector<Child> children;
    vector<Babysitter> babysitters;
public:
    void addChild(string name, int age) {
        children.push_back(Child(name, age));
    }

    void addBabysitter(string name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteChild(string name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->getName() == name) {
                children.erase(it);
                return;
            }
        }
    }

    void deleteBabysitter(string name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->getName() == name) {
                babysitters.erase(it);
                return;
            }
        }
    }

    void updateChild(string name, string newName, int newAge) {
        for (auto &child : children) {
            if (child.getName() == name) {
                child.setName(newName);
                child.setAge(newAge);
                return;
            }
        }
    }

    void updateBabysitter(string name, string newName, int newAge) {
        for (auto &babysitter : babysitters) {
            if (babysitter.getName() == name) {
                babysitter.setName(newName);
                babysitter.setAge(newAge);
                return;
            }
        }
    }

    Child* searchChild(string name) {
        for (auto &child : children) {
            if (child.getName() == name) {
                return &child;
            }
        }
        return nullptr;
    }

    Babysitter* searchBabysitter(string name) {
        for (auto &babysitter : babysitters) {
            if (babysitter.getName() == name) {
                return &babysitter;
            }
        }
        return nullptr;
    }

    void displayChildren() {
        for (auto &child : children) {
            cout << "Child: " << child.getName() << ", Age: " << child.getAge() << endl;
        }
    }

    void displayBabysitters() {
        for (auto &babysitter : babysitters) {
            cout << "Babysitter: " << babysitter.getName() << ", Age: " << babysitter.getAge() << endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;

    nms.addChild("Alice", 4);
    nms.addChild("Bob", 3);
    nms.addBabysitter("Mary", 30);
    nms.addBabysitter("John", 28);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.updateChild("Alice", "Alicia", 5);
    nms.updateBabysitter("John", "Jonathan", 29);

    Child* child = nms.searchChild("Alicia");
    if (child) cout << "Found Child: " << child->getName() << ", Age: " << child->getAge() << endl;

    Babysitter* babysitter = nms.searchBabysitter("Jonathan");
    if (babysitter) cout << "Found Babysitter: " << babysitter->getName() << ", Age: " << babysitter->getAge() << endl;

    nms.deleteChild("Bob");
    nms.deleteBabysitter("Mary");

    nms.displayChildren();
    nms.displayBabysitters();

    return 0;
}