#include <iostream>
#include <vector>
#include <string>

struct Person {
    std::string name;
    int age;
    std::string id;
};

class NurseryManagementSystem {
    std::vector<Person> children;
    std::vector<Person> babysitters;

public:
    void addPerson(std::vector<Person>& list, const std::string& name, int age, const std::string& id) {
        list.push_back({name, age, id});
    }

    void deletePerson(std::vector<Person>& list, const std::string& id) {
        for (auto it = list.begin(); it != list.end(); ++it) {
            if (it->id == id) {
                list.erase(it);
                return;
            }
        }
    }

    void updatePerson(std::vector<Person>& list, const std::string& id, const std::string& newName, int newAge) {
        for (auto& person : list) {
            if (person.id == id) {
                person.name = newName;
                person.age = newAge;
                return;
            }
        }
    }

    void searchPerson(const std::vector<Person>& list, const std::string& id) {
        for (const auto& person : list) {
            if (person.id == id) {
                std::cout << "Name: " << person.name << ", Age: " << person.age << ", ID: " << person.id << std::endl;
                return;
            }
        }
        std::cout << "Person with ID " << id << " not found." << std::endl;
    }

    void displayList(const std::vector<Person>& list) {
        for (const auto& person : list) {
            std::cout << "Name: " << person.name << ", Age: " << person.age << ", ID: " << person.id << std::endl;
        }
    }

    void addChild(const std::string& name, int age, const std::string& id) {
        addPerson(children, name, age, id);
    }

    void deleteChild(const std::string& id) {
        deletePerson(children, id);
    }

    void updateChild(const std::string& id, const std::string& newName, int newAge) {
        updatePerson(children, id, newName, newAge);
    }

    void searchChild(const std::string& id) {
        searchPerson(children, id);
    }

    void displayChildren() {
        displayList(children);
    }

    void addBabysitter(const std::string& name, int age, const std::string& id) {
        addPerson(babysitters, name, age, id);
    }

    void deleteBabysitter(const std::string& id) {
        deletePerson(babysitters, id);
    }

    void updateBabysitter(const std::string& id, const std::string& newName, int newAge) {
        updatePerson(babysitters, id, newName, newAge);
    }

    void searchBabysitter(const std::string& id) {
        searchPerson(babysitters, id);
    }

    void displayBabysitters() {
        displayList(babysitters);
    }
};

int main() {
    NurseryManagementSystem nms;

    nms.addChild("Alice", 4, "C001");
    nms.addChild("Bob", 5, "C002");

    nms.addBabysitter("Susan", 30, "B001");
    nms.addBabysitter("John", 25, "B002");

    std::cout << "Children:" << std::endl;
    nms.displayChildren();

    std::cout << "Babysitters:" << std::endl;
    nms.displayBabysitters();

    std::cout << "Search for child C001:" << std::endl;
    nms.searchChild("C001");

    std::cout << "Update child C001:" << std::endl;
    nms.updateChild("C001", "Alice Johnson", 5);
    nms.displayChildren();

    std::cout << "Delete babysitter B002:" << std::endl;
    nms.deleteBabysitter("B002");
    nms.displayBabysitters();

    return 0;
}