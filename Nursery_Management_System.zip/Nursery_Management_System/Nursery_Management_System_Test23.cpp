#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int age;
public:
    Person(std::string n, int a) : name(n), age(a) {}
    virtual ~Person() {}

    std::string getName() const { return name; }
    int getAge() const { return age; }

    void setName(std::string n) { name = n; }
    void setAge(int a) { age = a; }

    virtual void display() const {
        std::cout << "Name: " << name << ", Age: " << age << std::endl;
    }
};

class Child : public Person {
public:
    Child(std::string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(std::string n, int a) : Person(n, a) {}
};

template <typename T>
class ManagementSystem {
    std::vector<T> records;
public:
    void addRecord(T person) {
        records.push_back(person);
    }

    void deleteRecord(std::string name) {
        for (auto it = records.begin(); it != records.end(); ++it) {
            if (it->getName() == name) {
                records.erase(it);
                break;
            }
        }
    }

    void updateRecord(std::string name, T newRecord) {
        for (auto &record : records) {
            if (record.getName() == name) {
                record = newRecord;
                break;
            }
        }
    }

    T* searchRecord(std::string name) {
        for (auto &record : records) {
            if (record.getName() == name) {
                return &record;
            }
        }
        return nullptr;
    }

    void displayRecords() const {
        for (const auto &record : records) {
            record.display();
        }
    }
};

int main() {
    ManagementSystem<Child> childSystem;
    ManagementSystem<Babysitter> babysitterSystem;

    Child c1("John Doe", 5);
    Child c2("Jane Doe", 4);
    Babysitter b1("Alice Smith", 30);
    Babysitter b2("Bob Johnson", 45);

    childSystem.addRecord(c1);
    childSystem.addRecord(c2);
    babysitterSystem.addRecord(b1);
    babysitterSystem.addRecord(b2);

    std::cout << "Children:" << std::endl;
    childSystem.displayRecords();

    std::cout << "Babysitters:" << std::endl;
    babysitterSystem.displayRecords();

    childSystem.deleteRecord("John Doe");
    std::cout << "Children after deletion:" << std::endl;
    childSystem.displayRecords();

    Child c3("Johnny Doe", 6);
    childSystem.updateRecord("Jane Doe", c3);
    std::cout << "Children after update:" << std::endl;
    childSystem.displayRecords();

    return 0;
}