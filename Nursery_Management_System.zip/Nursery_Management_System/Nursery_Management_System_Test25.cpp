#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
protected:
    string name;
    int age;
public:
    Person(string name, int age) : name(name), age(age) {}
    string getName() { return name; }
    int getAge() { return age; }
    void setName(string newName) { name = newName; }
    void setAge(int newAge) { age = newAge; }
};

class Child : public Person {
public:
    Child(string name, int age) : Person(name, age) {}
};

class Babysitter : public Person {
public:
    Babysitter(string name, int age) : Person(name, age) {}
};

class Nursery {
private:
    vector<Child> children;
    vector<Babysitter> babysitters;
public:
    void addChild(string name, int age) {
        children.push_back(Child(name, age));
    }

    void addBabysitter(string name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteChild(string name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->getName() == name) {
                children.erase(it);
                return;
            }
        }
    }

    void deleteBabysitter(string name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->getName() == name) {
                babysitters.erase(it);
                return;
            }
        }
    }

    void updateChild(string name, string newName, int newAge) {
        for (auto &child : children) {
            if (child.getName() == name) {
                child.setName(newName);
                child.setAge(newAge);
                return;
            }
        }
    }

    void updateBabysitter(string name, string newName, int newAge) {
        for (auto &babysitter : babysitters) {
            if (babysitter.getName() == name) {
                babysitter.setName(newName);
                babysitter.setAge(newAge);
                return;
            }
        }
    }

    void searchChild(string name) {
        for (auto &child : children) {
            if (child.getName() == name) {
                cout << "Child Found: " << child.getName() << ", Age: " << child.getAge() << endl;
                return;
            }
        }
        cout << "Child Not Found" << endl;
    }

    void searchBabysitter(string name) {
        for (auto &babysitter : babysitters) {
            if (babysitter.getName() == name) {
                cout << "Babysitter Found: " << babysitter.getName() << ", Age: " << babysitter.getAge() << endl;
                return;
            }
        }
        cout << "Babysitter Not Found" << endl;
    }

    void displayChildren() {
        cout << "Children List:" << endl;
        for (auto &child : children) {
            cout << "Name: " << child.getName() << ", Age: " << child.getAge() << endl;
        }
    }

    void displayBabysitters() {
        cout << "Babysitters List:" << endl;
        for (auto &babysitter : babysitters) {
            cout << "Name: " << babysitter.getName() << ", Age: " << babysitter.getAge() << endl;
        }
    }
};

int main() {
    Nursery nursery;
    
    nursery.addChild("Alice", 5);
    nursery.addChild("Bob", 6);
    nursery.addBabysitter("Charlie", 30);
    nursery.addBabysitter("Diana", 25);
    
    nursery.displayChildren();
    nursery.displayBabysitters();
    
    nursery.updateChild("Alice", "Alice Johnson", 6);
    nursery.updateBabysitter("Charlie", "Charlie Brown", 31);
    
    nursery.searchChild("Alice Johnson");
    nursery.searchBabysitter("Diana");
    
    nursery.deleteChild("Bob");
    nursery.deleteBabysitter("Diana");
    
    nursery.displayChildren();
    nursery.displayBabysitters();

    return 0;
}