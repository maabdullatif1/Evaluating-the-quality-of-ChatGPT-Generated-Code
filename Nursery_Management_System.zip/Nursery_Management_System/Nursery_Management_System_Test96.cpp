#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int age;
public:
    Person(const std::string& name, int age) : name(name), age(age) {}
    std::string getName() const { return name; }
    int getAge() const { return age; }
    void setName(const std::string& newName) { name = newName; }
    void setAge(int newAge) { age = newAge; }
};

class Child : public Person {
public:
    Child(const std::string& name, int age) : Person(name, age) {}
};

class Babysitter : public Person {
public:
    Babysitter(const std::string& name, int age) : Person(name, age) {}
};

class Nursery {
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;
public:
    void addChild(const std::string& name, int age) {
        children.emplace_back(name, age);
    }

    void addBabysitter(const std::string& name, int age) {
        babysitters.emplace_back(name, age);
    }

    void deleteChild(const std::string& name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->getName() == name) {
                children.erase(it);
                break;
            }
        }
    }

    void deleteBabysitter(const std::string& name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->getName() == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateChild(const std::string& name, const std::string& newName, int newAge) {
        for (auto& child : children) {
            if (child.getName() == name) {
                child.setName(newName);
                child.setAge(newAge);
                break;
            }
        }
    }

    void updateBabysitter(const std::string& name, const std::string& newName, int newAge) {
        for (auto& babysitter : babysitters) {
            if (babysitter.getName() == name) {
                babysitter.setName(newName);
                babysitter.setAge(newAge);
                break;
            }
        }
    }

    Child* searchChild(const std::string& name) {
        for (auto& child : children) {
            if (child.getName() == name) {
                return &child;
            }
        }
        return nullptr;
    }

    Babysitter* searchBabysitter(const std::string& name) {
        for (auto& babysitter : babysitters) {
            if (babysitter.getName() == name) {
                return &babysitter;
            }
        }
        return nullptr;
    }

    void displayChildren() const {
        std::cout << "Children List:" << std::endl;
        for (const auto& child : children) {
            std::cout << "Name: " << child.getName() << ", Age: " << child.getAge() << std::endl;
        }
    }

    void displayBabysitters() const {
        std::cout << "Babysitters List:" << std::endl;
        for (const auto& babysitter : babysitters) {
            std::cout << "Name: " << babysitter.getName() << ", Age: " << babysitter.getAge() << std::endl;
        }
    }
};

int main() {
    Nursery nursery;
    nursery.addChild("Alice", 3);
    nursery.addChild("Bob", 4);
    nursery.addBabysitter("John", 25);
    nursery.addBabysitter("Doe", 30);
    
    nursery.displayChildren();
    nursery.displayBabysitters();
    
    nursery.updateChild("Alice", "Alicia", 4);
    nursery.updateBabysitter("John", "Johnny", 26);
    
    nursery.displayChildren();
    nursery.displayBabysitters();
    
    Child* child = nursery.searchChild("Alicia");
    if (child) std::cout << "Found child: " << child->getName() << ", Age: " << child->getAge() << std::endl;
    
    Babysitter* babysitter = nursery.searchBabysitter("Johnny");
    if (babysitter) std::cout << "Found babysitter: " << babysitter->getName() << ", Age: " << babysitter->getAge() << std::endl;
    
    nursery.deleteChild("Alicia");
    nursery.deleteBabysitter("Johnny");
    
    nursery.displayChildren();
    nursery.displayBabysitters();
    
    return 0;
}