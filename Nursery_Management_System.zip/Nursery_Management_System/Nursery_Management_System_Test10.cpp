#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;
    Person(const std::string &n, int a) : name(n), age(a) {}
};

class Child : public Person {
public:
    Child(const std::string &n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(const std::string &n, int a) : Person(n, a) {}
};

class NurseryManagementSystem {
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

    template<typename T>
    void addPerson(std::vector<T> &list, const std::string &name, int age) {
        list.emplace_back(name, age);
    }

    template<typename T>
    void deletePerson(std::vector<T> &list, const std::string &name) {
        for (auto it = list.begin(); it != list.end(); ++it) {
            if (it->name == name) {
                list.erase(it);
                break;
            }
        }
    }

    template<typename T>
    void updatePerson(std::vector<T> &list, const std::string &name, const std::string &new_name, int new_age) {
        for (auto &person : list) {
            if (person.name == name) {
                person.name = new_name;
                person.age = new_age;
                break;
            }
        }
    }

    template<typename T>
    void searchPerson(const std::vector<T> &list, const std::string &name) const {
        for (const auto &person : list) {
            if (person.name == name) {
                std::cout << "Name: " << person.name << ", Age: " << person.age << std::endl;
                return;
            }
        }
        std::cout << name << " not found.\n";
    }

    template<typename T>
    void displayPersons(const std::vector<T> &list) const {
        for (const auto &person : list) {
            std::cout << "Name: " << person.name << ", Age: " << person.age << std::endl;
        }
    }

public:
    void addChild(const std::string &name, int age) {
        addPerson(children, name, age);
    }

    void deleteChild(const std::string &name) {
        deletePerson(children, name);
    }

    void updateChild(const std::string &name, const std::string &new_name, int new_age) {
        updatePerson(children, name, new_name, new_age);
    }

    void searchChild(const std::string &name) const {
        searchPerson(children, name);
    }

    void displayChildren() const {
        displayPersons(children);
    }

    void addBabysitter(const std::string &name, int age) {
        addPerson(babysitters, name, age);
    }

    void deleteBabysitter(const std::string &name) {
        deletePerson(babysitters, name);
    }

    void updateBabysitter(const std::string &name, const std::string &new_name, int new_age) {
        updatePerson(babysitters, name, new_name, new_age);
    }

    void searchBabysitter(const std::string &name) const {
        searchPerson(babysitters, name);
    }

    void displayBabysitters() const {
        displayPersons(babysitters);
    }
};

int main() {
    NurseryManagementSystem system;
    system.addChild("Alice", 3);
    system.addChild("Bob", 4);
    system.addBabysitter("Cathy", 25);
    system.addBabysitter("David", 30);

    std::cout << "Children:\n";
    system.displayChildren();

    std::cout << "\nBabysitters:\n";
    system.displayBabysitters();

    return 0;
}