#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;
};

class Child : public Person {
public:
    int id;
};

class Babysitter : public Person {
public:
    int id;
};

class NurseryManagementSystem {
private:
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

    template<typename T>
    T* searchById(std::vector<T>& list, int id) {
        for (auto& item : list) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

public:
    void addChild(int id, const std::string& name, int age) {
        children.push_back({id, name, age});
    }

    void addBabysitter(int id, const std::string& name, int age) {
        babysitters.push_back({id, name, age});
    }

    void deleteChild(int id) {
        children.erase(std::remove_if(children.begin(), children.end(),
                    [id](const Child& c){ return c.id == id; }), children.end());
    }

    void deleteBabysitter(int id) {
        babysitters.erase(std::remove_if(babysitters.begin(), babysitters.end(),
                    [id](const Babysitter& b){ return b.id == id; }), babysitters.end());
    }

    void updateChild(int id, const std::string& name, int age) {
        Child* child = searchById(children, id);
        if (child) {
            child->name = name;
            child->age = age;
        }
    }

    void updateBabysitter(int id, const std::string& name, int age) {
        Babysitter* babysitter = searchById(babysitters, id);
        if (babysitter) {
            babysitter->name = name;
            babysitter->age = age;
        }
    }

    void searchChild(int id) {
        Child* child = searchById(children, id);
        if (child) {
            std::cout << "Child Found: " << child->id << ", " << child->name << ", " << child->age << std::endl;
        } else {
            std::cout << "Child not found" << std::endl;
        }
    }

    void searchBabysitter(int id) {
        Babysitter* babysitter = searchById(babysitters, id);
        if (babysitter) {
            std::cout << "Babysitter Found: " << babysitter->id << ", " << babysitter->name << ", " << babysitter->age << std::endl;
        } else {
            std::cout << "Babysitter not found" << std::endl;
        }
    }

    void displayChildren() {
        for (const auto& child : children) {
            std::cout << "Child: " << child.id << ", " << child.name << ", " << child.age << std::endl;
        }
    }

    void displayBabysitters() {
        for (const auto& babysitter : babysitters) {
            std::cout << "Babysitter: " << babysitter.id << ", " << babysitter.name << ", " << babysitter.age << std::endl;
        }
    }
};

int main() {
    NurseryManagementSystem system;
    system.addChild(1, "John Doe", 4);
    system.addChild(2, "Jane Smith", 5);
    system.addBabysitter(1, "Alice Brown", 28);
    system.addBabysitter(2, "Bob White", 32);

    system.displayChildren();
    system.displayBabysitters();

    system.searchChild(1);
    system.searchBabysitter(2);

    system.updateChild(1, "Johnny Doe", 5);
    system.updateBabysitter(1, "Alicia Brown", 29);

    system.displayChildren();
    system.displayBabysitters();

    system.deleteChild(2);
    system.deleteBabysitter(1);

    system.displayChildren();
    system.displayBabysitters();

    return 0;
}