#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    int age;
};

class NurseryManagement {
private:
    vector<Person> children;
    vector<Person> babysitters;

public:
    void addPerson(vector<Person>& group, const string& name, int age) {
        group.push_back({name, age});
    }
    
    void deletePerson(vector<Person>& group, const string& name) {
        for (auto it = group.begin(); it != group.end(); ++it) {
            if (it->name == name) {
                group.erase(it);
                break;
            }
        }
    }
    
    void updatePerson(vector<Person>& group, const string& name, const string& newName, int newAge) {
        for (auto& person : group) {
            if (person.name == name) {
                person.name = newName;
                person.age = newAge;
                break;
            }
        }
    }
    
    void searchPerson(const vector<Person>& group, const string& name) {
        for (const auto& person : group) {
            if (person.name == name) {
                cout << "Name: " << person.name << ", Age: " << person.age << endl;
                return;
            }
        }
        cout << "Person not found." << endl;
    }
    
    void displayGroup(const vector<Person>& group) {
        for (const auto& person : group) {
            cout << "Name: " << person.name << ", Age: " << person.age << endl;
        }
    }
    
    void addChild(const string& name, int age) {
        addPerson(children, name, age);
    }
    
    void deleteChild(const string& name) {
        deletePerson(children, name);
    }
    
    void updateChild(const string& name, const string& newName, int newAge) {
        updatePerson(children, name, newName, newAge);
    }
    
    void searchChild(const string& name) {
        searchPerson(children, name);
    }
    
    void displayChildren() {
        cout << "Children List:" << endl;
        displayGroup(children);
    }
    
    void addBabysitter(const string& name, int age) {
        addPerson(babysitters, name, age);
    }
    
    void deleteBabysitter(const string& name) {
        deletePerson(babysitters, name);
    }
    
    void updateBabysitter(const string& name, const string& newName, int newAge) {
        updatePerson(babysitters, name, newName, newAge);
    }
    
    void searchBabysitter(const string& name) {
        searchPerson(babysitters, name);
    }
    
    void displayBabysitters() {
        cout << "Babysitter List:" << endl;
        displayGroup(babysitters);
    }
};

int main() {
    NurseryManagement nm;
    nm.addChild("Alice", 5);
    nm.addChild("Bob", 4);
    nm.addBabysitter("Carol", 25);
    nm.addBabysitter("Dave", 30);
    nm.displayChildren();
    nm.displayBabysitters();
    nm.searchChild("Alice");
    nm.searchBabysitter("Carol");
    nm.updateChild("Alice", "Alice Smith", 6);
    nm.updateBabysitter("Carol", "Carol Johnson", 26);
    nm.displayChildren();
    nm.displayBabysitters();
    nm.deleteChild("Bob");
    nm.deleteBabysitter("Dave");
    nm.displayChildren();
    nm.displayBabysitters();
    return 0;
}