#include <iostream>
#include <vector>
#include <string>

class Child {
public:
    std::string name;
    int age;

    Child(std::string name, int age) : name(name), age(age) {}
};

class Babysitter {
public:
    std::string name;
    int experience;

    Babysitter(std::string name, int experience) : name(name), experience(experience) {}
};

class NurseryManagementSystem {
private:
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

public:
    void addChild(const std::string& name, int age) {
        children.push_back(Child(name, age));
    }

    void deleteChild(const std::string& name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->name == name) {
                children.erase(it);
                break;
            }
        }
    }

    void updateChild(const std::string& name, int newAge) {
        for (auto& child : children) {
            if (child.name == name) {
                child.age = newAge;
                break;
            }
        }
    }

    void searchChild(const std::string& name) {
        for (const auto& child : children) {
            if (child.name == name) {
                std::cout << "Child found: " << child.name << ", Age: " << child.age << "\n";
                return;
            }
        }
        std::cout << "Child not found\n";
    }

    void displayChildren() {
        for (const auto& child : children) {
            std::cout << "Child Name: " << child.name << ", Age: " << child.age << "\n";
        }
    }

    void addBabysitter(const std::string& name, int experience) {
        babysitters.push_back(Babysitter(name, experience));
    }

    void deleteBabysitter(const std::string& name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->name == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateBabysitter(const std::string& name, int newExperience) {
        for (auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                babysitter.experience = newExperience;
                break;
            }
        }
    }

    void searchBabysitter(const std::string& name) {
        for (const auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                std::cout << "Babysitter found: " << babysitter.name << ", Experience: " << babysitter.experience << " years\n";
                return;
            }
        }
        std::cout << "Babysitter not found\n";
    }

    void displayBabysitters() {
        for (const auto& babysitter : babysitters) {
            std::cout << "Babysitter Name: " << babysitter.name << ", Experience: " << babysitter.experience << " years\n";
        }
    }
};

int main() {
    NurseryManagementSystem system;
    system.addChild("Alice", 5);
    system.addChild("Bob", 3);
    system.addBabysitter("Carol", 10);
    system.addBabysitter("Dave", 8);

    std::cout << "Children:\n";
    system.displayChildren();

    std::cout << "\nBabysitters:\n";
    system.displayBabysitters();

    system.searchChild("Alice");
    system.searchBabysitter("Dave");

    system.updateChild("Bob", 4);
    system.updateBabysitter("Carol", 11);

    std::cout << "\nUpdated Children:\n";
    system.displayChildren();

    std::cout << "\nUpdated Babysitters:\n";
    system.displayBabysitters();

    system.deleteChild("Alice");
    system.deleteBabysitter("Dave");

    std::cout << "\nAfter Deletion - Children:\n";
    system.displayChildren();

    std::cout << "\nAfter Deletion - Babysitters:\n";
    system.displayBabysitters();

    return 0;
}