#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    int age;
};

class NurseryManagementSystem {
private:
    vector<Person> children;
    vector<Person> babysitters;

    void displayPerson(const Person& person) {
        cout << "Name: " << person.name << ", Age: " << person.age << endl;
    }

public:
    void addChild(const string& name, int age) {
        children.push_back({name, age});
    }

    void addBabysitter(const string& name, int age) {
        babysitters.push_back({name, age});
    }

    void deleteChild(const string& name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->name == name) {
                children.erase(it);
                return;
            }
        }
    }

    void deleteBabysitter(const string& name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->name == name) {
                babysitters.erase(it);
                return;
            }
        }
    }

    void updateChild(const string& name, const string& newName, int newAge) {
        for (auto& child : children) {
            if (child.name == name) {
                child.name = newName;
                child.age = newAge;
                return;
            }
        }
    }

    void updateBabysitter(const string& name, const string& newName, int newAge) {
        for (auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                babysitter.name = newName;
                babysitter.age = newAge;
                return;
            }
        }
    }

    void searchChild(const string& name) {
        for (const auto& child : children) {
            if (child.name == name) {
                displayPerson(child);
                return;
            }
        }
        cout << "Child not found" << endl;
    }

    void searchBabysitter(const string& name) {
        for (const auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                displayPerson(babysitter);
                return;
            }
        }
        cout << "Babysitter not found" << endl;
    }

    void displayChildren() {
        if (children.empty()) {
            cout << "No children registered" << endl;
            return;
        }
        for (const auto& child : children) {
            displayPerson(child);
        }
    }

    void displayBabysitters() {
        if (babysitters.empty()) {
            cout << "No babysitters registered" << endl;
            return;
        }
        for (const auto& babysitter : babysitters) {
            displayPerson(babysitter);
        }
    }
};

int main() {
    NurseryManagementSystem nursery;
    nursery.addChild("Alice", 5);
    nursery.addChild("Bob", 3);
    nursery.addBabysitter("Mary", 30);
    nursery.addBabysitter("John", 28);

    cout << "Children List:" << endl;
    nursery.displayChildren();

    cout << "Babysitters List:" << endl;
    nursery.displayBabysitters();

    cout << "Searching for Bob:" << endl;
    nursery.searchChild("Bob");

    cout << "Updating Bob to Bobby, age 4:" << endl;
    nursery.updateChild("Bob", "Bobby", 4);
    nursery.displayChildren();

    cout << "Deleting Mary:" << endl;
    nursery.deleteBabysitter("Mary");
    nursery.displayBabysitters();

    return 0;
}