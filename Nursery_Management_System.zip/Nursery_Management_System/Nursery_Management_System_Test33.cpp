#include <iostream>
#include <string>
#include <vector>

class Person {
public:
    std::string name;
    int age;

    Person(std::string n, int a) : name(n), age(a) {}
};

class Child : public Person {
public:
    Child(std::string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(std::string n, int a) : Person(n, a) {}
};

class NurseryManagementSystem {
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

public:
    void addChild(std::string name, int age) {
        children.push_back(Child(name, age));
    }

    void deleteChild(std::string name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->name == name) {
                children.erase(it);
                return;
            }
        }
    }

    void updateChild(std::string name, std::string newName, int newAge) {
        for (auto &child : children) {
            if (child.name == name) {
                child.name = newName;
                child.age = newAge;
                return;
            }
        }
    }

    void searchChild(std::string name) {
        for (const auto &child : children) {
            if (child.name == name) {
                std::cout << "Child found: " << child.name << ", Age: " << child.age << std::endl;
                return;
            }
        }
        std::cout << "Child not found." << std::endl;
    }

    void displayChildren() {
        for (const auto &child : children) {
            std::cout << "Child: " << child.name << ", Age: " << child.age << std::endl;
        }
    }

    void addBabysitter(std::string name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteBabysitter(std::string name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->name == name) {
                babysitters.erase(it);
                return;
            }
        }
    }

    void updateBabysitter(std::string name, std::string newName, int newAge) {
        for (auto &babysitter : babysitters) {
            if (babysitter.name == name) {
                babysitter.name = newName;
                babysitter.age = newAge;
                return;
            }
        }
    }

    void searchBabysitter(std::string name) {
        for (const auto &babysitter : babysitters) {
            if (babysitter.name == name) {
                std::cout << "Babysitter found: " << babysitter.name << ", Age: " << babysitter.age << std::endl;
                return;
            }
        }
        std::cout << "Babysitter not found." << std::endl;
    }

    void displayBabysitters() {
        for (const auto &babysitter : babysitters) {
            std::cout << "Babysitter: " << babysitter.name << ", Age: " << babysitter.age << std::endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 5);
    nms.addChild("Bob", 4);
    nms.addBabysitter("Carol", 30);
    nms.addBabysitter("Dave", 28);
    nms.displayChildren();
    nms.displayBabysitters();
    nms.searchChild("Alice");
    nms.updateChild("Alice", "Alicia", 6);
    nms.searchChild("Alicia");
    nms.deleteChild("Bob");
    nms.displayChildren();
    nms.searchBabysitter("Carol");
    nms.updateBabysitter("Carol", "Caroline", 31);
    nms.searchBabysitter("Caroline");
    nms.deleteBabysitter("Dave");
    nms.displayBabysitters();
    return 0;
}