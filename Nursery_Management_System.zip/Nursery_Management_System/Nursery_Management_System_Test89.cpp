#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    int age;
};

class Nursery {
private:
    vector<Person> children;
    vector<Person> babysitters;

    void displayPersons(const vector<Person>& persons) {
        for (const auto& person : persons) {
            cout << "Name: " << person.name << ", Age: " << person.age << endl;
        }
    }

    int findPersonIndex(const vector<Person>& persons, const string& name) {
        for (int i = 0; i < persons.size(); ++i) {
            if (persons[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addChild(const string& name, int age) {
        children.push_back({name, age});
    }

    void addBabysitter(const string& name, int age) {
        babysitters.push_back({name, age});
    }

    void deleteChild(const string& name) {
        int index = findPersonIndex(children, name);
        if (index != -1) {
            children.erase(children.begin() + index);
        }
    }

    void deleteBabysitter(const string& name) {
        int index = findPersonIndex(babysitters, name);
        if (index != -1) {
            babysitters.erase(babysitters.begin() + index);
        }
    }

    void updateChild(const string& name, int age) {
        int index = findPersonIndex(children, name);
        if (index != -1) {
            children[index].age = age;
        }
    }

    void updateBabysitter(const string& name, int age) {
        int index = findPersonIndex(babysitters, name);
        if (index != -1) {
            babysitters[index].age = age;
        }
    }

    void searchChild(const string& name) {
        int index = findPersonIndex(children, name);
        if (index != -1) {
            cout << "Child found: Name: " << children[index].name << ", Age: " << children[index].age << endl;
        } else {
            cout << "Child not found." << endl;
        }
    }

    void searchBabysitter(const string& name) {
        int index = findPersonIndex(babysitters, name);
        if (index != -1) {
            cout << "Babysitter found: Name: " << babysitters[index].name << ", Age: " << babysitters[index].age << endl;
        } else {
            cout << "Babysitter not found." << endl;
        }
    }

    void displayChildren() {
        displayPersons(children);
    }

    void displayBabysitters() {
        displayPersons(babysitters);
    }
};

int main() {
    Nursery nursery;
    nursery.addChild("John", 5);
    nursery.addChild("Lucy", 4);
    nursery.addBabysitter("Anna", 22);
    nursery.addBabysitter("Mike", 28);

    cout << "Children List:" << endl;
    nursery.displayChildren();

    cout << "\nBabysitters List:" << endl;
    nursery.displayBabysitters();

    nursery.updateChild("Lucy", 5);
    nursery.searchChild("Lucy");

    nursery.deleteBabysitter("Anna");
    nursery.displayBabysitters();

    return 0;
}