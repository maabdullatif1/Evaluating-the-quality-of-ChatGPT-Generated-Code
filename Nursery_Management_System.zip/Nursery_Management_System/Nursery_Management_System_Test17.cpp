#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
public:
    string name;
    int age;
    int id;

    Person(string name, int age, int id) : name(name), age(age), id(id) {}

    virtual void display() {
        cout << "ID: " << id << ", Name: " << name << ", Age: " << age << endl;
    }
};

class Child : public Person {
public:
    Child(string name, int age, int id) : Person(name, age, id) {}
};

class Babysitter : public Person {
public:
    Babysitter(string name, int age, int id) : Person(name, age, id) {}
};

class NurseryManagementSystem {
private:
    vector<Child> children;
    vector<Babysitter> babysitters;
    int nextChildId;
    int nextBabysitterId;

public:
    NurseryManagementSystem() : nextChildId(1), nextBabysitterId(1) {}

    void addChild(string name, int age) {
        children.push_back(Child(name, age, nextChildId++));
    }

    void addBabysitter(string name, int age) {
        babysitters.push_back(Babysitter(name, age, nextBabysitterId++));
    }

    void deleteChild(int id) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->id == id) {
                children.erase(it);
                break;
            }
        }
    }

    void deleteBabysitter(int id) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->id == id) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateChild(int id, string newName, int newAge) {
        for (auto &child : children) {
            if (child.id == id) {
                child.name = newName;
                child.age = newAge;
                break;
            }
        }
    }

    void updateBabysitter(int id, string newName, int newAge) {
        for (auto &babysitter : babysitters) {
            if (babysitter.id == id) {
                babysitter.name = newName;
                babysitter.age = newAge;
                break;
            }
        }
    }

    void searchChild(int id) {
        for (auto &child : children) {
            if (child.id == id) {
                child.display();
                return;
            }
        }
        cout << "Child with ID " << id << " not found." << endl;
    }

    void searchBabysitter(int id) {
        for (auto &babysitter : babysitters) {
            if (babysitter.id == id) {
                babysitter.display();
                return;
            }
        }
        cout << "Babysitter with ID " << id << " not found." << endl;
    }

    void displayChildren() {
        cout << "Children:" << endl;
        for (auto &child : children) {
            child.display();
        }
    }

    void displayBabysitters() {
        cout << "Babysitters:" << endl;
        for (auto &babysitter : babysitters) {
            babysitter.display();
        }
    }
};

int main() {
    NurseryManagementSystem system;
    system.addChild("Alice", 3);
    system.addBabysitter("Bob", 25);
    system.displayChildren();
    system.displayBabysitters();
    system.updateChild(1, "Alice Smith", 4);
    system.searchChild(1);
    system.deleteChild(1);
    system.displayChildren();
    return 0;
}