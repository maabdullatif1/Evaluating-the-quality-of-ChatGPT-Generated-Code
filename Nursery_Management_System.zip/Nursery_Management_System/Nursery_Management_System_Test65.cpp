#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string id;
    string name;
    string age;
};

class Nursery {
    vector<Person> children;
    vector<Person> babysitters;

    vector<Person>& selectDatabase(string type) {
        if (type == "child") {
            return children;
        } else {
            return babysitters;
        }
    }

public:
    void addPerson(string type, const string& id, const string& name, const string& age) {
        vector<Person>& db = selectDatabase(type);
        db.push_back({id, name, age});
    }

    void deletePerson(string type, const string& id) {
        vector<Person>& db = selectDatabase(type);
        for (auto it = db.begin(); it != db.end(); ++it) {
            if (it->id == id) {
                db.erase(it);
                return;
            }
        }
    }

    void updatePerson(string type, const string& id, const string& name, const string& age) {
        vector<Person>& db = selectDatabase(type);
        for (auto& person : db) {
            if (person.id == id) {
                person.name = name;
                person.age = age;
                return;
            }
        }
    }

    Person* searchPerson(string type, const string& id) {
        vector<Person>& db = selectDatabase(type);
        for (auto& person : db) {
            if (person.id == id) {
                return &person;
            }
        }
        return nullptr;
    }

    void displayPersons(string type) {
        vector<Person>& db = selectDatabase(type);
        for (const auto& person : db) {
            cout << "ID: " << person.id << ", Name: " << person.name << ", Age: " << person.age << endl;
        }
    }
};

int main() {
    Nursery nursery;
    nursery.addPerson("child", "1", "Alice", "4");
    nursery.addPerson("child", "2", "Bob", "5");
    nursery.addPerson("babysitter", "101", "Mary", "30");
    nursery.addPerson("babysitter", "102", "John", "28");

    cout << "Children:" << endl;
    nursery.displayPersons("child");

    cout << "\nBabysitters:" << endl;
    nursery.displayPersons("babysitter");

    nursery.updatePerson("child", "1", "Alice Smith", "4");

    cout << "\nUpdated Children:" << endl;
    nursery.displayPersons("child");

    nursery.deletePerson("babysitter", "101");

    cout << "\nUpdated Babysitters:" << endl;
    nursery.displayPersons("babysitter");

    Person* found = nursery.searchPerson("child", "2");
    if (found) {
        cout << "\nFound child: " << found->name << endl;
    } else {
        cout << "\nChild not found" << endl;
    }

    return 0;
}