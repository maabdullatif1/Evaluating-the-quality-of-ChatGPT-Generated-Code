#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;
};

class Child : public Person {
public:
    std::string parentContact;
};

class Babysitter : public Person {
public:
    std::string availability;
};

std::vector<Child> children;
std::vector<Babysitter> babysitters;

void addChild() {
    Child child;
    std::cout << "Enter child's name: ";
    std::cin >> child.name;
    std::cout << "Enter child's age: ";
    std::cin >> child.age;
    std::cout << "Enter parent's contact: ";
    std::cin >> child.parentContact;
    children.push_back(child);
}

void deleteChild() {
    std::string name;
    std::cout << "Enter child's name to delete: ";
    std::cin >> name;
    for (auto it = children.begin(); it != children.end(); ++it) {
        if (it->name == name) {
            children.erase(it);
            break;
        }
    }
}

void updateChild() {
    std::string name;
    std::cout << "Enter child's name to update: ";
    std::cin >> name;
    for (auto &child : children) {
        if (child.name == name) {
            std::cout << "Enter new age: ";
            std::cin >> child.age;
            std::cout << "Enter new parent's contact: ";
            std::cin >> child.parentContact;
            break;
        }
    }
}

void searchChild() {
    std::string name;
    std::cout << "Enter child's name to search: ";
    std::cin >> name;
    for (const auto &child : children) {
        if (child.name == name) {
            std::cout << "Name: " << child.name << ", Age: " << child.age
                      << ", Parent Contact: " << child.parentContact << std::endl;
            return;
        }
    }
}

void displayChildren() {
    for (const auto &child : children) {
        std::cout << "Name: " << child.name << ", Age: " << child.age
                  << ", Parent Contact: " << child.parentContact << std::endl;
    }
}

void addBabysitter() {
    Babysitter babysitter;
    std::cout << "Enter babysitter's name: ";
    std::cin >> babysitter.name;
    std::cout << "Enter babysitter's age: ";
    std::cin >> babysitter.age;
    std::cout << "Enter babysitter's availability: ";
    std::cin >> babysitter.availability;
    babysitters.push_back(babysitter);
}

void deleteBabysitter() {
    std::string name;
    std::cout << "Enter babysitter's name to delete: ";
    std::cin >> name;
    for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
        if (it->name == name) {
            babysitters.erase(it);
            break;
        }
    }
}

void updateBabysitter() {
    std::string name;
    std::cout << "Enter babysitter's name to update: ";
    std::cin >> name;
    for (auto &babysitter : babysitters) {
        if (babysitter.name == name) {
            std::cout << "Enter new age: ";
            std::cin >> babysitter.age;
            std::cout << "Enter new availability: ";
            std::cin >> babysitter.availability;
            break;
        }
    }
}

void searchBabysitter() {
    std::string name;
    std::cout << "Enter babysitter's name to search: ";
    std::cin >> name;
    for (const auto &babysitter : babysitters) {
        if (babysitter.name == name) {
            std::cout << "Name: " << babysitter.name << ", Age: " << babysitter.age
                      << ", Availability: " << babysitter.availability << std::endl;
            return;
        }
    }
}

void displayBabysitters() {
    for (const auto &babysitter : babysitters) {
        std::cout << "Name: " << babysitter.name << ", Age: " << babysitter.age
                  << ", Availability: " << babysitter.availability << std::endl;
    }
}

int main() {
    int choice;
    do {
        std::cout << "1. Add Child\n2. Delete Child\n3. Update Child\n4. Search Child\n5. Display Children\n";
        std::cout << "6. Add Babysitter\n7. Delete Babysitter\n8. Update Babysitter\n9. Search Babysitter\n10. Display Babysitters\n11. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;
        switch (choice) {
            case 1: addChild(); break;
            case 2: deleteChild(); break;
            case 3: updateChild(); break;
            case 4: searchChild(); break;
            case 5: displayChildren(); break;
            case 6: addBabysitter(); break;
            case 7: deleteBabysitter(); break;
            case 8: updateBabysitter(); break;
            case 9: searchBabysitter(); break;
            case 10: displayBabysitters(); break;
        }
    } while (choice != 11);
    return 0;
}