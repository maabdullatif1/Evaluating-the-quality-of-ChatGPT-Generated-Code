#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    int age;
    string id;
};

class NurseryManagementSystem {
    vector<Person> children;
    vector<Person> babysitters;

    vector<Person>* selectList(char type) {
        return (type == 'c') ? &children : &babysitters;
    }

    void displayList(const vector<Person>& list) {
        for (const auto& person : list) {
            cout << "ID: " << person.id << ", Name: " << person.name << ", Age: " << person.age << endl;
        }
    }

    int findIndex(vector<Person>& list, const string& id) {
        for (size_t i = 0; i < list.size(); ++i) {
            if (list[i].id == id)
                return i;
        }
        return -1;
    }

public:
    void addPerson(char type, const string& name, int age, const string& id) {
        Person newPerson = {name, age, id};
        selectList(type)->push_back(newPerson);
    }

    void deletePerson(char type, const string& id) {
        vector<Person>* list = selectList(type);
        int index = findIndex(*list, id);
        if (index != -1) {
            list->erase(list->begin() + index);
        }
    }

    void updatePerson(char type, const string& id, const string& newName, int newAge) {
        vector<Person>* list = selectList(type);
        int index = findIndex(*list, id);
        if (index != -1) {
            (*list)[index].name = newName;
            (*list)[index].age = newAge;
        }
    }

    void searchPerson(char type, const string& id) {
        vector<Person>* list = selectList(type);
        int index = findIndex(*list, id);
        if (index != -1) {
            cout << "ID: " << (*list)[index].id << ", Name: " << (*list)[index].name << ", Age: " << (*list)[index].age << endl;
        } else {
            cout << "Person not found" << endl;
        }
    }

    void displayAll(char type) {
        displayList(*selectList(type));
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addPerson('c', "John", 4, "C001");
    nms.addPerson('s', "Alice", 30, "S001");
    nms.displayAll('c');
    nms.displayAll('s');
    nms.updatePerson('c', "C001", "Johnny", 5);
    nms.searchPerson('c', "C001");
    nms.deletePerson('s', "S001");
    nms.displayAll('s');
    return 0;
}