#include <iostream>
#include <string>
using namespace std;

struct Person {
    int id;
    string name;
    int age;
};

class NurseryManagementSystem {
    Person children[100];
    Person babysitters[100];
    int childrenCount;
    int babysittersCount;

public:
    NurseryManagementSystem() : childrenCount(0), babysittersCount(0) {}

    void addPerson(Person arr[], int& count, int id, string name, int age) {
        arr[count].id = id;
        arr[count].name = name;
        arr[count].age = age;
        count++;
    }

    void deletePerson(Person arr[], int& count, int id) {
        for (int i = 0; i < count; i++) {
            if (arr[i].id == id) {
                for (int j = i; j < count - 1; j++) {
                    arr[j] = arr[j + 1];
                }
                count--;
                break;
            }
        }
    }

    void updatePerson(Person arr[], int count, int id, string name, int age) {
        for (int i = 0; i < count; i++) {
            if (arr[i].id == id) {
                arr[i].name = name;
                arr[i].age = age;
                break;
            }
        }
    }

    Person* searchPerson(Person arr[], int count, int id) {
        for (int i = 0; i < count; i++) {
            if (arr[i].id == id) {
                return &arr[i];
            }
        }
        return NULL;
    }

    void displayPersons(Person arr[], int count) {
        for (int i = 0; i < count; i++) {
            cout << "ID: " << arr[i].id << ", Name: " << arr[i].name << ", Age: " << arr[i].age << endl;
        }
    }

    void addChild(int id, string name, int age) {
        addPerson(children, childrenCount, id, name, age);
    }

    void deleteChild(int id) {
        deletePerson(children, childrenCount, id);
    }

    void updateChild(int id, string name, int age) {
        updatePerson(children, childrenCount, id, name, age);
    }

    Person* searchChild(int id) {
        return searchPerson(children, childrenCount, id);
    }

    void displayChildren() {
        displayPersons(children, childrenCount);
    }

    void addBabysitter(int id, string name, int age) {
        addPerson(babysitters, babysittersCount, id, name, age);
    }

    void deleteBabysitter(int id) {
        deletePerson(babysitters, babysittersCount, id);
    }

    void updateBabysitter(int id, string name, int age) {
        updatePerson(babysitters, babysittersCount, id, name, age);
    }

    Person* searchBabysitter(int id) {
        return searchPerson(babysitters, babysittersCount, id);
    }

    void displayBabysitters() {
        displayPersons(babysitters, babysittersCount);
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild(1, "Alice", 3);
    nms.addChild(2, "Bob", 4);
    nms.addBabysitter(1, "Carol", 25);
    nms.displayChildren();
    nms.displayBabysitters();
    nms.updateChild(1, "Alicia", 3);
    nms.displayChildren();
    nms.deleteBabysitter(1);
    nms.displayBabysitters();
    return 0;
}