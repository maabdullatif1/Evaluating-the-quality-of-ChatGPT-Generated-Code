#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    int age;
    string id;
};

struct Child : Person {
    string favoriteToy;
};

struct Babysitter : Person {
    int experienceYears;
};

class NurseryManagementSystem {
    vector<Child> children;
    vector<Babysitter> babysitters;

public:
    void addChild(string name, int age, string id, string favoriteToy) {
        children.push_back({name, age, id, favoriteToy});
    }

    void addBabysitter(string name, int age, string id, int experienceYears) {
        babysitters.push_back({name, age, id, experienceYears});
    }

    void deleteChild(string id) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->id == id) {
                children.erase(it);
                break;
            }
        }
    }

    void deleteBabysitter(string id) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->id == id) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateChild(string id, string name, int age, string favoriteToy) {
        for (auto& child : children) {
            if (child.id == id) {
                child.name = name;
                child.age = age;
                child.favoriteToy = favoriteToy;
                break;
            }
        }
    }

    void updateBabysitter(string id, string name, int age, int experienceYears) {
        for (auto& sitter : babysitters) {
            if (sitter.id == id) {
                sitter.name = name;
                sitter.age = age;
                sitter.experienceYears = experienceYears;
                break;
            }
        }
    }

    void searchChild(string id) {
        for (const auto& child : children) {
            if (child.id == id) {
                cout << "Child Found: " << child.name << ", Age: " << child.age 
                     << ", Toy: " << child.favoriteToy << "\n";
                return;
            }
        }
        cout << "Child not found.\n";
    }

    void searchBabysitter(string id) {
        for (const auto& sitter : babysitters) {
            if (sitter.id == id) {
                cout << "Babysitter Found: " << sitter.name << ", Age: " << sitter.age 
                     << ", Experience: " << sitter.experienceYears << "\n";
                return;
            }
        }
        cout << "Babysitter not found.\n";
    }

    void displayChildren() {
        cout << "Children List:\n";
        for (const auto& child : children) {
            cout << "Name: " << child.name << ", Age: " << child.age 
                 << ", ID: " << child.id << ", Toy: " << child.favoriteToy << "\n";
        }
        if (children.empty()) cout << "No children available.\n";
    }

    void displayBabysitters() {
        cout << "Babysitters List:\n";
        for (const auto& sitter : babysitters) {
            cout << "Name: " << sitter.name << ", Age: " << sitter.age 
                 << ", ID: " << sitter.id << ", Experience: " << sitter.experienceYears << "\n";
        }
        if (babysitters.empty()) cout << "No babysitters available.\n";
    }
};

int main() {
    NurseryManagementSystem nms;

    nms.addChild("Alice", 5, "C001", "Doll");
    nms.addChild("Bob", 4, "C002", "Car");
    nms.addBabysitter("Lucy", 22, "B001", 3);
    nms.addBabysitter("Mark", 25, "B002", 5);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.searchChild("C001");
    nms.searchBabysitter("B001");

    nms.updateChild("C002", "Bobby", 4, "Truck");
    nms.updateBabysitter("B002", "Marcus", 26, 6);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.deleteChild("C001");
    nms.deleteBabysitter("B001");

    nms.displayChildren();
    nms.displayBabysitters();

    return 0;
}