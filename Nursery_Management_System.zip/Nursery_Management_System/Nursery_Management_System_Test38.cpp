#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int age;
public:
    Person(std::string n, int a) : name(n), age(a) {}
    std::string getName() { return name; }
    int getAge() { return age; }
    virtual void displayInfo() = 0;
};

class Child : public Person {
public:
    Child(std::string n, int a) : Person(n, a) {}
    void displayInfo() {
        std::cout << "Child - Name: " << name << ", Age: " << age << std::endl;
    }
};

class Babysitter : public Person {
public:
    Babysitter(std::string n, int a) : Person(n, a) {}
    void displayInfo() {
        std::cout << "Babysitter - Name: " << name << ", Age: " << age << std::endl;
    }
};

class NurseryManagementSystem {
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;
public:
    void addChild(std::string name, int age) {
        children.push_back(Child(name, age));
    }

    void addBabysitter(std::string name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteChild(std::string name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->getName() == name) {
                children.erase(it);
                break;
            }
        }
    }

    void deleteBabysitter(std::string name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->getName() == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateChild(std::string name, int newAge) {
        for (auto &child : children) {
            if (child.getName() == name) {
                child = Child(name, newAge);
                break;
            }
        }
    }

    void updateBabysitter(std::string name, int newAge) {
        for (auto &babysitter : babysitters) {
            if (babysitter.getName() == name) {
                babysitter = Babysitter(name, newAge);
                break;
            }
        }
    }

    void searchChild(std::string name) {
        for (const auto &child : children) {
            if (child.getName() == name) {
                child.displayInfo();
                return;
            }
        }
        std::cout << "Child not found." << std::endl;
    }

    void searchBabysitter(std::string name) {
        for (const auto &babysitter : babysitters) {
            if (babysitter.getName() == name) {
                babysitter.displayInfo();
                return;
            }
        }
        std::cout << "Babysitter not found." << std::endl;
    }

    void displayChildren() {
        std::cout << "Children List: " << std::endl;
        for (const auto &child : children) {
            child.displayInfo();
        }
    }

    void displayBabysitters() {
        std::cout << "Babysitters List: " << std::endl;
        for (const auto &babysitter : babysitters) {
            babysitter.displayInfo();
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("John", 5);
    nms.addChild("Lucy", 4);
    nms.addBabysitter("Anna", 25);
    nms.addBabysitter("Mike", 30);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.updateChild("John", 6);
    nms.updateBabysitter("Anna", 26);

    nms.searchChild("John");
    nms.searchBabysitter("Anna");

    nms.deleteChild("Lucy");
    nms.deleteBabysitter("Mike");

    nms.displayChildren();
    nms.displayBabysitters();

    return 0;
}