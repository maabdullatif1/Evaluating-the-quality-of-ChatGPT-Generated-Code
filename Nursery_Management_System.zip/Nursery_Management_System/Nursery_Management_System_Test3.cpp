#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int age;

public:
    Person(std::string name, int age) : name(name), age(age) {}
    virtual void display() const = 0;
};

class Child : public Person {
public:
    Child(std::string name, int age) : Person(name, age) {}
    void display() const override {
        std::cout << "Child Name: " << name << ", Age: " << age << std::endl;
    }
};

class Babysitter : public Person {
private:
    int experienceYears;

public:
    Babysitter(std::string name, int age, int experienceYears)
        : Person(name, age), experienceYears(experienceYears) {}
    void display() const override {
        std::cout << "Babysitter Name: " << name << ", Age: " << age
                  << ", Experience: " << experienceYears << " years" << std::endl;
    }
};

template <typename T>
class NurseryManagementSystem {
private:
    std::vector<T> records;

public:
    void add(T person) {
        records.push_back(person);
    }

    void remove(std::string name) {
        for (auto it = records.begin(); it != records.end(); ++it) {
            if (it->name == name) {
                records.erase(it);
                break;
            }
        }
    }

    void update(std::string name, int newAge) {
        for (auto &record : records) {
            if (record.name == name) {
                record.age = newAge;
                break;
            }
        }
    }

    void displayAll() const {
        for (const auto &record : records) {
            record.display();
        }
    }

    void search(std::string name) const {
        for (const auto &record : records) {
            if (record.name == name) {
                record.display();
                return;
            }
        }
        std::cout << "No record found for " << name << std::endl;
    }
};

int main() {
    NurseryManagementSystem<Child> childRecords;
    NurseryManagementSystem<Babysitter> babysitterRecords;

    childRecords.add(Child("Alice", 5));
    childRecords.add(Child("Bob", 6));
    babysitterRecords.add(Babysitter("Clara", 30, 5));
    babysitterRecords.add(Babysitter("David", 25, 2));

    std::cout << "All Children:\n";
    childRecords.displayAll();

    std::cout << "\nAll Babysitters:\n";
    babysitterRecords.displayAll();

    std::cout << "\nSearch for 'Alice':\n";
    childRecords.search("Alice");

    std::cout << "\nUpdating 'Bob's age to 7.\n";
    childRecords.update("Bob", 7);

    std::cout << "\nAll Children after update:\n";
    childRecords.displayAll();

    std::cout << "\nRemoving 'Clara'.\n";
    babysitterRecords.remove("Clara");

    std::cout << "\nAll Babysitters after removal:\n";
    babysitterRecords.displayAll();

    return 0;
}