#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
public:
    string name;
    int age;
    Person(string n, int a) : name(n), age(a) {}
    virtual ~Person() {}
};

class Child : public Person {
public:
    Child(string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(string n, int a) : Person(n, a) {}
};

class NurseryManagementSystem {
    vector<Child> children;
    vector<Babysitter> babysitters;
    
public:
    void addChild(string name, int age) {
        children.push_back(Child(name, age));
    }

    void deleteChild(string name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->name == name) {
                children.erase(it);
                break;
            }
        }
    }

    void updateChild(string oldName, string newName, int newAge) {
        for (auto& child : children) {
            if (child.name == oldName) {
                child.name = newName;
                child.age = newAge;
                break;
            }
        }
    }

    void searchChild(string name) {
        for (const auto& child : children) {
            if (child.name == name) {
                cout << "Child Found: Name: " << child.name << ", Age: " << child.age << endl;
                return;
            }
        }
        cout << "Child not found" << endl;
    }

    void displayChildren() {
        cout << "Children List:" << endl;
        for (const auto& child : children) {
            cout << "Name: " << child.name << ", Age: " << child.age << endl;
        }
    }

    void addBabysitter(string name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteBabysitter(string name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->name == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateBabysitter(string oldName, string newName, int newAge) {
        for (auto& babysitter : babysitters) {
            if (babysitter.name == oldName) {
                babysitter.name = newName;
                babysitter.age = newAge;
                break;
            }
        }
    }

    void searchBabysitter(string name) {
        for (const auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                cout << "Babysitter Found: Name: " << babysitter.name << ", Age: " << babysitter.age << endl;
                return;
            }
        }
        cout << "Babysitter not found" << endl;
    }

    void displayBabysitters() {
        cout << "Babysitters List:" << endl;
        for (const auto& babysitter : babysitters) {
            cout << "Name: " << babysitter.name << ", Age: " << babysitter.age << endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 5);
    nms.addChild("Bob", 3);
    nms.displayChildren();
    nms.searchChild("Alice");
    nms.updateChild("Alice", "Alicia", 6);
    nms.displayChildren();
    nms.deleteChild("Bob");
    nms.displayChildren();
    
    nms.addBabysitter("John", 25);
    nms.addBabysitter("Jane", 30);
    nms.displayBabysitters();
    nms.searchBabysitter("John");
    nms.updateBabysitter("John", "Johnny", 26);
    nms.displayBabysitters();
    nms.deleteBabysitter("Jane");
    nms.displayBabysitters();

    return 0;
}