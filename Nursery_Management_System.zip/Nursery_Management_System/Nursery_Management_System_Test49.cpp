#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;
    Person(std::string n, int a) : name(n), age(a) {}
};

class Child : public Person {
public:
    Child(std::string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(std::string n, int a) : Person(n, a) {}
};

class NurseryManagementSystem {
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

    template<typename T>
    void addPerson(std::vector<T> &list, const T &person) {
        list.push_back(person);
    }

    template<typename T>
    void deletePerson(std::vector<T> &list, const std::string &name) {
        for (auto it = list.begin(); it != list.end(); ++it) {
            if (it->name == name) {
                list.erase(it);
                break;
            }
        }
    }

    template<typename T>
    void updatePerson(std::vector<T> &list, const std::string &name, const std::string &newName, int newAge) {
        for (auto &person : list) {
            if (person.name == name) {
                person.name = newName;
                person.age = newAge;
                break;
            }
        }
    }

    template<typename T>
    T* searchPerson(std::vector<T> &list, const std::string &name) {
        for (auto &person : list) {
            if (person.name == name) {
                return &person;
            }
        }
        return nullptr;
    }

    template<typename T>
    void displayPersons(const std::vector<T> &list) {
        for (const auto &person : list) {
            std::cout << "Name: " << person.name << ", Age: " << person.age << std::endl;
        }
    }

public:
    void addChild(const Child &child) { addPerson(children, child); }
    void addBabysitter(const Babysitter &babysitter) { addPerson(babysitters, babysitter); }

    void deleteChild(const std::string &name) { deletePerson(children, name); }
    void deleteBabysitter(const std::string &name) { deletePerson(babysitters, name); }

    void updateChild(const std::string &name, const std::string &newName, int newAge) { updatePerson(children, name, newName, newAge); }
    void updateBabysitter(const std::string &name, const std::string &newName, int newAge) { updatePerson(babysitters, name, newName, newAge); }

    Child* searchChild(const std::string &name) { return searchPerson(children, name); }
    Babysitter* searchBabysitter(const std::string &name) { return searchPerson(babysitters, name); }

    void displayChildren() { displayPersons(children); }
    void displayBabysitters() { displayPersons(babysitters); }
};

int main() {
    NurseryManagementSystem nursery;
    
    nursery.addChild(Child("Alice", 5));
    nursery.addChild(Child("Bob", 4));
    nursery.addBabysitter(Babysitter("Emma", 28));
    nursery.addBabysitter(Babysitter("Liam", 30));

    std::cout << "Children:" << std::endl;
    nursery.displayChildren();
    std::cout << "Babysitters:" << std::endl;
    nursery.displayBabysitters();

    nursery.updateChild("Alice", "Alicia", 6);
    nursery.deleteBabysitter("Liam");

    std::cout << "\nUpdated Children:" << std::endl;
    nursery.displayChildren();
    std::cout << "Updated Babysitters:" << std::endl;
    nursery.displayBabysitters();

    return 0;
}