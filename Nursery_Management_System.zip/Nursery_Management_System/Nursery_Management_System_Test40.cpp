#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int age;
public:
    Person(std::string n, int a) : name(n), age(a) {}
    std::string getName() { return name; }
    int getAge() { return age; }
    virtual void showDetails() = 0;
};

class Child : public Person {
    std::string parentContact;
public:
    Child(std::string n, int a, std::string p) : Person(n, a), parentContact(p) {}
    void showDetails() {
        std::cout << "Child Name: " << name << ", Age: " << age << ", Parent Contact: " << parentContact << std::endl;
    }
    std::string getParentContact() { return parentContact; }
    void updateDetails(std::string n, int a, std::string p) {
        name = n;
        age = a;
        parentContact = p;
    }
};

class Babysitter : public Person {
    int experience;
public:
    Babysitter(std::string n, int a, int e) : Person(n, a), experience(e) {}
    void showDetails() {
        std::cout << "Babysitter Name: " << name << ", Age: " << age << ", Experience: " << experience << " years" << std::endl;
    }
    int getExperience() { return experience; }
    void updateDetails(std::string n, int a, int e) {
        name = n;
        age = a;
        experience = e;
    }
};

template<typename T>
class NurseryManagementSystem {
    std::vector<T> records;
public:
    void add(T item) { records.push_back(item); }
    void del(std::string name) {
        records.erase(std::remove_if(records.begin(), records.end(),
            [&](T& item) { return item.getName() == name; }), records.end());
    }
    void update(std::string name, T newDetails) {
        for (auto &item : records) {
            if(item.getName() == name) {
                item = newDetails;
                break;
            }
        }
    }
    T* search(std::string name) {
        for (auto &item : records)
            if(item.getName() == name) return &item;
        return nullptr;
    }
    void display() {
        for (const auto &item : records) item.showDetails();
    }
};

int main() {
    NurseryManagementSystem<Child> children;
    NurseryManagementSystem<Babysitter> babysitters;

    Child c1("John", 5, "123-456-7890");
    Child c2("Emily", 4, "098-765-4321");
    Babysitter b1("Anna", 30, 5);
    Babysitter b2("Mike", 25, 2);

    children.add(c1);
    children.add(c2);
    babysitters.add(b1);
    babysitters.add(b2);

    children.display();
    babysitters.display();

    Child* searchedChild = children.search("John");
    if(searchedChild) searchedChild->updateDetails("Johnny", 6, "111-222-3333");

    Babysitter* searchedBabysitter = babysitters.search("Anna");
    if(searchedBabysitter) searchedBabysitter->updateDetails("Anna Smith", 31, 6);

    children.display();
    babysitters.display();

    children.del("Emily");
    babysitters.del("Mike");

    children.display();
    babysitters.display();

    return 0;
}