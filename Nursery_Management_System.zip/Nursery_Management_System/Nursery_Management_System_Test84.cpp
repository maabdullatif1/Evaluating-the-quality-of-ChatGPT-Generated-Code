#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    int id;
    string name;
    int age;
};

class Nursery {
    vector<Person> children;
    vector<Person> babysitters;
    int nextId = 1;

    vector<Person>* getCollection(string type) {
        return (type == "Child") ? &children : &babysitters;
    }

public:
    void addPerson(string type, const string& name, int age) {
        vector<Person>* collection = getCollection(type);
        collection->push_back({nextId++, name, age});
        cout << type << " added successfully.\n";
    }

    void deletePerson(string type, int id) {
        vector<Person>* collection = getCollection(type);
        for (auto it = collection->begin(); it != collection->end(); ++it) {
            if (it->id == id) {
                collection->erase(it);
                cout << type << " deleted successfully.\n";
                return;
            }
        }
        cout << type << " not found.\n";
    }

    void updatePerson(string type, int id, const string& name, int age) {
        vector<Person>* collection = getCollection(type);
        for (auto& person : *collection) {
            if (person.id == id) {
                person.name = name;
                person.age = age;
                cout << type << " updated successfully.\n";
                return;
            }
        }
        cout << type << " not found.\n";
    }

    void searchPerson(string type, int id) {
        vector<Person>* collection = getCollection(type);
        for (const auto& person : *collection) {
            if (person.id == id) {
                cout << "ID: " << person.id << ", Name: " << person.name << ", Age: " << person.age << endl;
                return;
            }
        }
        cout << type << " not found.\n";
    }

    void displayPersons(string type) {
        vector<Person>* collection = getCollection(type);
        cout << type << " List:\n";
        for (const auto& person : *collection) {
            cout << "ID: " << person.id << ", Name: " << person.name << ", Age: " << person.age << endl;
        }
    }
};

int main() {
    Nursery nursery;
    int choice;
    do {
        cout << "Nursery Management System\n";
        cout << "1. Add Child\n";
        cout << "2. Add Babysitter\n";
        cout << "3. Delete Child\n";
        cout << "4. Delete Babysitter\n";
        cout << "5. Update Child\n";
        cout << "6. Update Babysitter\n";
        cout << "7. Search Child\n";
        cout << "8. Search Babysitter\n";
        cout << "9. Display Children\n";
        cout << "10. Display Babysitters\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 0) break;

        int id, age;
        string name;
        switch (choice) {
        case 1:
            cout << "Enter child's name and age: ";
            cin >> name >> age;
            nursery.addPerson("Child", name, age);
            break;
        case 2:
            cout << "Enter babysitter's name and age: ";
            cin >> name >> age;
            nursery.addPerson("Babysitter", name, age);
            break;
        case 3:
            cout << "Enter child's ID to delete: ";
            cin >> id;
            nursery.deletePerson("Child", id);
            break;
        case 4:
            cout << "Enter babysitter's ID to delete: ";
            cin >> id;
            nursery.deletePerson("Babysitter", id);
            break;
        case 5:
            cout << "Enter child's ID, new name, and new age: ";
            cin >> id >> name >> age;
            nursery.updatePerson("Child", id, name, age);
            break;
        case 6:
            cout << "Enter babysitter's ID, new name, and new age: ";
            cin >> id >> name >> age;
            nursery.updatePerson("Babysitter", id, name, age);
            break;
        case 7:
            cout << "Enter child's ID to search: ";
            cin >> id;
            nursery.searchPerson("Child", id);
            break;
        case 8:
            cout << "Enter babysitter's ID to search: ";
            cin >> id;
            nursery.searchPerson("Babysitter", id);
            break;
        case 9:
            nursery.displayPersons("Child");
            break;
        case 10:
            nursery.displayPersons("Babysitter");
            break;
        }
    } while (choice != 0);

    return 0;
}