#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int age;
public:
    Person() : name(""), age(0) {}
    Person(std::string n, int a) : name(n), age(a) {}

    std::string getName() const { return name; }
    int getAge() const { return age; }

    virtual void display() const = 0;

    void setName(const std::string& n) { name = n; }
    void setAge(int a) { age = a; }
};

class Child : public Person {
public:
    Child(std::string n, int a) : Person(n, a) {}

    void display() const override {
        std::cout << "Child Name: " << name << ", Age: " << age << std::endl;
    }
};

class Babysitter : public Person {
public:
    Babysitter(std::string n, int a) : Person(n, a) {}

    void display() const override {
        std::cout << "Babysitter Name: " << name << ", Age: " << age << std::endl;
    }
};

class Nursery {
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;
public:
    void addChild(const Child& child) {
        children.push_back(child);
    }

    void deleteChild(const std::string& name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->getName() == name) {
                children.erase(it);
                break;
            }
        }
    }

    void updateChild(const std::string& name, const std::string& newName, int newAge) {
        for (auto& child : children) {
            if (child.getName() == name) {
                child.setName(newName);
                child.setAge(newAge);
                break;
            }
        }
    }

    void searchChild(const std::string& name) const {
        for (const auto& child : children) {
            if (child.getName() == name) {
                child.display();
                break;
            }
        }
    }

    void displayChildren() const {
        for (const auto& child : children) {
            child.display();
        }
    }

    void addBabysitter(const Babysitter& babysitter) {
        babysitters.push_back(babysitter);
    }

    void deleteBabysitter(const std::string& name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->getName() == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateBabysitter(const std::string& name, const std::string& newName, int newAge) {
        for (auto& babysitter : babysitters) {
            if (babysitter.getName() == name) {
                babysitter.setName(newName);
                babysitter.setAge(newAge);
                break;
            }
        }
    }

    void searchBabysitter(const std::string& name) const {
        for (const auto& babysitter : babysitters) {
            if (babysitter.getName() == name) {
                babysitter.display();
                break;
            }
        }
    }

    void displayBabysitters() const {
        for (const auto& babysitter : babysitters) {
            babysitter.display();
        }
    }
};

int main() {
    Nursery nursery;

    nursery.addChild(Child("Alice", 5));
    nursery.addChild(Child("Bob", 6));

    nursery.addBabysitter(Babysitter("Nina", 25));
    nursery.addBabysitter(Babysitter("Carl", 30));

    nursery.searchChild("Alice");
    nursery.searchBabysitter("Nina");

    nursery.updateChild("Alice", "Alicia", 7);
    nursery.updateBabysitter("Nina", "Nina B", 26);

    nursery.displayChildren();
    nursery.displayBabysitters();

    nursery.deleteChild("Bob");
    nursery.deleteBabysitter("Carl");

    nursery.displayChildren();
    nursery.displayBabysitters();

    return 0;
}