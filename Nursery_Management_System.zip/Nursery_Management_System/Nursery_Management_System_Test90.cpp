#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Person {
    string id;
    string name;
};

class NurseryManagementSystem {
    vector<Person> children;
    vector<Person> babysitters;

    Person inputPerson() {
        Person person;
        cout << "Enter ID: ";
        cin >> person.id;
        cout << "Enter Name: ";
        cin.ignore();
        getline(cin, person.name);
        return person;
    }

    void displayPerson(const Person& person) {
        cout << "ID: " << person.id << ", Name: " << person.name << endl;
    }

    int findPersonIndex(const vector<Person>& list, const string& id) {
        for (int i = 0; i < list.size(); ++i) {
            if (list[i].id == id)
                return i;
        }
        return -1;
    }

    void addPerson(vector<Person>& list) {
        list.push_back(inputPerson());
    }

    void deletePerson(vector<Person>& list) {
        cout << "Enter ID to delete: ";
        string id;
        cin >> id;
        int index = findPersonIndex(list, id);
        if (index != -1) {
            list.erase(list.begin() + index);
            cout << "Deleted." << endl;
        } else {
            cout << "ID not found." << endl;
        }
    }

    void updatePerson(vector<Person>& list) {
        cout << "Enter ID to update: ";
        string id;
        cin >> id;
        int index = findPersonIndex(list, id);
        if (index != -1) {
            cout << "Enter new details: ";
            list[index] = inputPerson();
        } else {
            cout << "ID not found." << endl;
        }
    }

    void searchPerson(const vector<Person>& list) {
        cout << "Enter ID to search: ";
        string id;
        cin >> id;
        int index = findPersonIndex(list, id);
        if (index != -1) {
            displayPerson(list[index]);
        } else {
            cout << "ID not found." << endl;
        }
    }

    void displayList(const vector<Person>& list) {
        for (const auto& person : list) {
            displayPerson(person);
        }
    }

public:
    void addChild() {
        addPerson(children);
    }

    void deleteChild() {
        deletePerson(children);
    }

    void updateChild() {
        updatePerson(children);
    }

    void searchChild() {
        searchPerson(children);
    }

    void displayChildren() {
        displayList(children);
    }

    void addBabysitter() {
        addPerson(babysitters);
    }

    void deleteBabysitter() {
        deletePerson(babysitters);
    }

    void updateBabysitter() {
        updatePerson(babysitters);
    }

    void searchBabysitter() {
        searchPerson(babysitters);
    }

    void displayBabysitters() {
        displayList(babysitters);
    }
};

int main() {
    NurseryManagementSystem nms;
    int choice;
    do {
        cout << "\nNursery Management System\n";
        cout << "1. Add Child\n2. Delete Child\n3. Update Child\n4. Search Child\n5. Display Children\n";
        cout << "6. Add Babysitter\n7. Delete Babysitter\n8. Update Babysitter\n9. Search Babysitter\n10. Display Babysitters\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1: nms.addChild(); break;
            case 2: nms.deleteChild(); break;
            case 3: nms.updateChild(); break;
            case 4: nms.searchChild(); break;
            case 5: nms.displayChildren(); break;
            case 6: nms.addBabysitter(); break;
            case 7: nms.deleteBabysitter(); break;
            case 8: nms.updateBabysitter(); break;
            case 9: nms.searchBabysitter(); break;
            case 10: nms.displayBabysitters(); break;
            case 0: break;
            default: cout << "Invalid choice." << endl; break;
        }
    } while (choice != 0);

    return 0;
}