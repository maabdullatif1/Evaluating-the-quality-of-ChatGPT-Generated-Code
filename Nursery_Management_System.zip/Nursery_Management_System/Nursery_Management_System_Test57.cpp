#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;

    Person(std::string n, int a) : name(n), age(a) {}
};

class Child : public Person {
public:
    Child(std::string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(std::string n, int a) : Person(n, a) {}
};

class NurseryManagement {
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

    template <typename T>
    void displayPersons(const std::vector<T> &persons) {
        for (const auto &p : persons) {
            std::cout << "Name: " << p.name << ", Age: " << p.age << std::endl;
        }
    }

    template <typename T>
    int findPerson(const std::vector<T> &persons, const std::string &name) {
        for (size_t i = 0; i < persons.size(); ++i) {
            if (persons[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addChild(const std::string &name, int age) {
        children.emplace_back(name, age);
    }

    void addBabysitter(const std::string &name, int age) {
        babysitters.emplace_back(name, age);
    }

    void deleteChild(const std::string &name) {
        int index = findPerson(children, name);
        if (index != -1) {
            children.erase(children.begin() + index);
        }
    }

    void deleteBabysitter(const std::string &name) {
        int index = findPerson(babysitters, name);
        if (index != -1) {
            babysitters.erase(babysitters.begin() + index);
        }
    }

    void updateChild(const std::string &name, const std::string &newName, int newAge) {
        int index = findPerson(children, name);
        if (index != -1) {
            children[index].name = newName;
            children[index].age = newAge;
        }
    }

    void updateBabysitter(const std::string &name, const std::string &newName, int newAge) {
        int index = findPerson(babysitters, name);
        if (index != -1) {
            babysitters[index].name = newName;
            babysitters[index].age = newAge;
        }
    }

    void searchChild(const std::string &name) {
        int index = findPerson(children, name);
        if (index != -1) {
            std::cout << "Child found: " << children[index].name << ", Age: " << children[index].age << std::endl;
        } else {
            std::cout << "Child not found." << std::endl;
        }
    }

    void searchBabysitter(const std::string &name) {
        int index = findPerson(babysitters, name);
        if (index != -1) {
            std::cout << "Babysitter found: " << babysitters[index].name << ", Age: " << babysitters[index].age << std::endl;
        } else {
            std::cout << "Babysitter not found." << std::endl;
        }
    }

    void displayChildren() {
        std::cout << "Children List:" << std::endl;
        displayPersons(children);
    }

    void displayBabysitters() {
        std::cout << "Babysitters List:" << std::endl;
        displayPersons(babysitters);
    }
};

int main() {
    NurseryManagement nursery;
    nursery.addChild("John", 5);
    nursery.addChild("Emma", 6);
    nursery.addBabysitter("Alice", 30);
    nursery.addBabysitter("Bob", 28);

    nursery.displayChildren();
    nursery.displayBabysitters();

    nursery.updateChild("John", "Johnny", 7);
    nursery.updateBabysitter("Alice", "Alicia", 32);

    nursery.searchChild("Emma");
    nursery.searchBabysitter("Alicia");

    nursery.deleteChild("Johnny");
    nursery.deleteBabysitter("Bob");

    nursery.displayChildren();
    nursery.displayBabysitters();

    return 0;
}