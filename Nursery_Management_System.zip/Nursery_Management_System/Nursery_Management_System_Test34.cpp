#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;
    std::string id;

    Person(const std::string& name, int age, const std::string& id) 
        : name(name), age(age), id(id) {}

    virtual void display() const = 0;
};

class Child : public Person {
public:
    Child(const std::string& name, int age, const std::string& id)
        : Person(name, age, id) {}

    void display() const override {
        std::cout << "Child Name: " << name << ", Age: " << age << ", ID: " << id << std::endl;
    }
};

class Babysitter : public Person {
public:
    Babysitter(const std::string& name, int age, const std::string& id)
        : Person(name, age, id) {}

    void display() const override {
        std::cout << "Babysitter Name: " << name << ", Age: " << age << ", ID: " << id << std::endl;
    }
};

class NurseryManagementSystem {
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

    template<typename T>
    void addPerson(std::vector<T>& persons, const T& person) {
        persons.push_back(person);
    }

    template<typename T>
    void deletePerson(std::vector<T>& persons, const std::string& id) {
        for (size_t i = 0; i < persons.size(); ++i) {
            if (persons[i].id == id) {
                persons.erase(persons.begin() + i);
                return;
            }
        }
    }

    template<typename T>
    void updatePerson(std::vector<T>& persons, const std::string& id, const T& newPerson) {
        for (size_t i = 0; i < persons.size(); ++i) {
            if (persons[i].id == id) {
                persons[i] = newPerson;
                return;
            }
        }
    }

    template<typename T>
    void searchPerson(const std::vector<T>& persons, const std::string& id) const {
        for (const auto& person : persons) {
            if (person.id == id) {
                person.display();
                return;
            }
        }
        std::cout << "Person with ID " << id << " not found." << std::endl;
    }

    template<typename T>
    void displayPersons(const std::vector<T>& persons) const {
        for (const auto& person : persons) {
            person.display();
        }
    }

public:
    void addChild(const std::string& name, int age, const std::string& id) {
        addPerson(children, Child(name, age, id));
    }

    void addBabysitter(const std::string& name, int age, const std::string& id) {
        addPerson(babysitters, Babysitter(name, age, id));
    }

    void deleteChild(const std::string& id) {
        deletePerson(children, id);
    }

    void deleteBabysitter(const std::string& id) {
        deletePerson(babysitters, id);
    }

    void updateChild(const std::string& id, const std::string& name, int age) {
        updatePerson(children, id, Child(name, age, id));
    }

    void updateBabysitter(const std::string& id, const std::string& name, int age) {
        updatePerson(babysitters, id, Babysitter(name, age, id));
    }

    void searchChild(const std::string& id) const {
        searchPerson(children, id);
    }

    void searchBabysitter(const std::string& id) const {
        searchPerson(babysitters, id);
    }

    void displayChildren() const {
        displayPersons(children);
    }

    void displayBabysitters() const {
        displayPersons(babysitters);
    }
};

int main() {
    NurseryManagementSystem system;
    system.addChild("Alice", 5, "C001");
    system.addBabysitter("John", 30, "B001");
    system.displayChildren();
    system.displayBabysitters();
    system.searchChild("C001");
    system.updateChild("C001", "Alice Smith", 6);
    system.displayChildren();
    system.deleteChild("C001");
    system.displayChildren();
    return 0;
}