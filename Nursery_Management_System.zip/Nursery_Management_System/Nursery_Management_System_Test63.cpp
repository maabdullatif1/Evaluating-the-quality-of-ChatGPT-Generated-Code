#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int age;
public:
    Person(const std::string& name, int age) : name(name), age(age) {}
    std::string getName() const { return name; }
    int getAge() const { return age; }
    void setName(const std::string& name) { this->name = name; }
    void setAge(int age) { this->age = age; }
};

class Child : public Person {
public:
    Child(const std::string& name, int age) : Person(name, age) {}
};

class Babysitter : public Person {
public:
    Babysitter(const std::string& name, int age) : Person(name, age) {}
};

class NurseryManagement {
private:
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;
public:
    void addChild(const std::string& name, int age) {
        children.emplace_back(name, age);
    }
    void addBabysitter(const std::string& name, int age) {
        babysitters.emplace_back(name, age);
    }
    void deleteChild(const std::string& name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->getName() == name) {
                children.erase(it);
                break;
            }
        }
    }
    void deleteBabysitter(const std::string& name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->getName() == name) {
                babysitters.erase(it);
                break;
            }
        }
    }
    void updateChild(const std::string& name, int age) {
        for (auto& child : children) {
            if (child.getName() == name) {
                child.setAge(age);
                break;
            }
        }
    }
    void updateBabysitter(const std::string& name, int age) {
        for (auto& sitter : babysitters) {
            if (sitter.getName() == name) {
                sitter.setAge(age);
                break;
            }
        }
    }
    Child* searchChild(const std::string& name) {
        for (auto& child : children) {
            if (child.getName() == name) {
                return &child;
            }
        }
        return nullptr;
    }
    Babysitter* searchBabysitter(const std::string& name) {
        for (auto& sitter : babysitters) {
            if (sitter.getName() == name) {
                return &sitter;
            }
        }
        return nullptr;
    }
    void displayChildren() const {
        for (const auto& child : children) {
            std::cout << "Child: " << child.getName() << ", Age: " << child.getAge() << std::endl;
        }
    }
    void displayBabysitters() const {
        for (const auto& sitter : babysitters) {
            std::cout << "Babysitter: " << sitter.getName() << ", Age: " << sitter.getAge() << std::endl;
        }
    }
};

int main() {
    NurseryManagement nm;
    nm.addChild("John", 5);
    nm.addChild("Lisa", 3);
    nm.addBabysitter("Mary", 28);
    nm.addBabysitter("Paul", 32);
    nm.displayChildren();
    nm.displayBabysitters();
    nm.updateChild("John", 6);
    nm.displayChildren();
    nm.deleteBabysitter("Mary");
    nm.displayBabysitters();
    return 0;
}