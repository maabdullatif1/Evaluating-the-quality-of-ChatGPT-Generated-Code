#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;
    Person(const std::string& name, int age) : name(name), age(age) {}
};

class Child : public Person {
public:
    Child(const std::string& name, int age) : Person(name, age) {}
};

class Babysitter : public Person {
public:
    Babysitter(const std::string& name, int age) : Person(name, age) {}
};

class NurseryManagementSystem {
private:
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

public:
    void addChild(const std::string& name, int age) {
        children.push_back(Child(name, age));
    }
    
    void deleteChild(const std::string& name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->name == name) {
                children.erase(it);
                break;
            }
        }
    }
    
    void updateChild(const std::string& oldName, const std::string& newName, int newAge) {
        for (auto& child : children) {
            if (child.name == oldName) {
                child.name = newName;
                child.age = newAge;
                break;
            }
        }
    }
    
    void searchChild(const std::string& name) {
        for (const auto& child : children) {
            if (child.name == name) {
                std::cout << "Child Found: Name = " << child.name << ", Age = " << child.age << std::endl;
                return;
            }
        }
        std::cout << "Child not found" << std::endl;
    }
    
    void displayChildren() {
        for (const auto& child : children) {
            std::cout << "Child: Name = " << child.name << ", Age = " << child.age << std::endl;
        }
    }
    
    void addBabysitter(const std::string& name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }
    
    void deleteBabysitter(const std::string& name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->name == name) {
                babysitters.erase(it);
                break;
            }
        }
    }
    
    void updateBabysitter(const std::string& oldName, const std::string& newName, int newAge) {
        for (auto& babysitter : babysitters) {
            if (babysitter.name == oldName) {
                babysitter.name = newName;
                babysitter.age = newAge;
                break;
            }
        }
    }
    
    void searchBabysitter(const std::string& name) {
        for (const auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                std::cout << "Babysitter Found: Name = " << babysitter.name << ", Age = " << babysitter.age << std::endl;
                return;
            }
        }
        std::cout << "Babysitter not found" << std::endl;
    }
    
    void displayBabysitters() {
        for (const auto& babysitter : babysitters) {
            std::cout << "Babysitter: Name = " << babysitter.name << ", Age = " << babysitter.age << std::endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 5);
    nms.addChild("Bob", 6);
    nms.displayChildren();
    nms.searchChild("Alice");
    nms.updateChild("Alice", "Alicia", 6);
    nms.searchChild("Alicia");
    nms.deleteChild("Bob");
    nms.displayChildren();
    nms.addBabysitter("John", 30);
    nms.addBabysitter("Jane", 25);
    nms.displayBabysitters();
    nms.searchBabysitter("Jane");
    nms.updateBabysitter("Jane", "Janet", 26);
    nms.searchBabysitter("Janet");
    nms.deleteBabysitter("John");
    nms.displayBabysitters();
    return 0;
}