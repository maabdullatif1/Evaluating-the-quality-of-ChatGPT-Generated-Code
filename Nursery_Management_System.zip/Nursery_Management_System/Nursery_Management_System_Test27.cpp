#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;

    Person(std::string n, int a) : name(n), age(a) {}
};

class Child : public Person {
public:
    Child(std::string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(std::string n, int a) : Person(n, a) {}
};

class NurseryManagementSystem {
private:
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

public:
    void addChild(std::string name, int age) {
        children.push_back(Child(name, age));
    }

    void addBabysitter(std::string name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteChild(std::string name) {
        for (size_t i = 0; i < children.size(); ++i) {
            if (children[i].name == name) {
                children.erase(children.begin() + i);
                break;
            }
        }
    }

    void deleteBabysitter(std::string name) {
        for (size_t i = 0; i < babysitters.size(); ++i) {
            if (babysitters[i].name == name) {
                babysitters.erase(babysitters.begin() + i);
                break;
            }
        }
    }

    void updateChild(std::string name, std::string newName, int newAge) {
        for (auto &child : children) {
            if (child.name == name) {
                child.name = newName;
                child.age = newAge;
                return;
            }
        }
    }

    void updateBabysitter(std::string name, std::string newName, int newAge) {
        for (auto &babysitter : babysitters) {
            if (babysitter.name == name) {
                babysitter.name = newName;
                babysitter.age = newAge;
                return;
            }
        }
    }

    void searchChild(std::string name) {
        for (auto &child : children) {
            if (child.name == name) {
                std::cout << "Child found: " << child.name << ", Age: " << child.age << std::endl;
                return;
            }
        }
        std::cout << "Child not found." << std::endl;
    }

    void searchBabysitter(std::string name) {
        for (auto &babysitter : babysitters) {
            if (babysitter.name == name) {
                std::cout << "Babysitter found: " << babysitter.name << ", Age: " << babysitter.age << std::endl;
                return;
            }
        }
        std::cout << "Babysitter not found." << std::endl;
    }

    void displayChildren() {
        std::cout << "Children List:" << std::endl;
        for (auto &child : children) {
            std::cout << "Name: " << child.name << ", Age: " << child.age << std::endl;
        }
    }

    void displayBabysitters() {
        std::cout << "Babysitters List:" << std::endl;
        for (auto &babysitter : babysitters) {
            std::cout << "Name: " << babysitter.name << ", Age: " << babysitter.age << std::endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 5);
    nms.addBabysitter("John", 25);
    nms.displayChildren();
    nms.displayBabysitters();
    nms.searchChild("Alice");
    nms.updateChild("Alice", "Alicia", 6);
    nms.displayChildren();
    nms.deleteChild("Alicia");
    nms.displayChildren();
    return 0;
}