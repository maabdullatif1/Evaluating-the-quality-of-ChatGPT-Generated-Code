#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Person {
protected:
    string name;
    int age;
public:
    Person(string n, int a) : name(n), age(a) {}
    string getName() { return name; }
    int getAge() { return age; }
    void setName(string n) { name = n; }
    void setAge(int a) { age = a; }
};

class Child : public Person {
public:
    Child(string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(string n, int a) : Person(n, a) {}
};

class NurseryManagementSystem {
    vector<Child> children;
    vector<Babysitter> babysitters;

public:
    void addChild(string name, int age) {
        children.push_back(Child(name, age));
    }
    
    void addBabysitter(string name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteChild(string name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->getName() == name) {
                children.erase(it);
                break;
            }
        }
    }

    void deleteBabysitter(string name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->getName() == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateChild(string name, string newName, int newAge) {
        for (auto &child : children) {
            if (child.getName() == name) {
                child.setName(newName);
                child.setAge(newAge);
                break;
            }
        }
    }

    void updateBabysitter(string name, string newName, int newAge) {
        for (auto &babysitter : babysitters) {
            if (babysitter.getName() == name) {
                babysitter.setName(newName);
                babysitter.setAge(newAge);
                break;
            }
        }
    }

    Child* searchChild(string name) {
        for (auto &child : children) {
            if (child.getName() == name) {
                return &child;
            }
        }
        return nullptr;
    }

    Babysitter* searchBabysitter(string name) {
        for (auto &babysitter : babysitters) {
            if (babysitter.getName() == name) {
                return &babysitter;
            }
        }
        return nullptr;
    }

    void displayChildren() {
        cout << "Children:\n";
        for (auto &child : children) {
            cout << "Name: " << child.getName() << ", Age: " << child.getAge() << endl;
        }
    }

    void displayBabysitters() {
        cout << "Babysitters:\n";
        for (auto &babysitter : babysitters) {
            cout << "Name: " << babysitter.getName() << ", Age: " << babysitter.getAge() << endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 4);
    nms.addChild("Bob", 5);
    nms.addBabysitter("Carol", 30);
    nms.addBabysitter("Dave", 25);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.updateChild("Alice", "Alicia", 6);
    nms.updateBabysitter("Carol", "Caroline", 32);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.deleteChild("Bob");
    nms.deleteBabysitter("Dave");

    nms.displayChildren();
    nms.displayBabysitters();

    return 0;
}