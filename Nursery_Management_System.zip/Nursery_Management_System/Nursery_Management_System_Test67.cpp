#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
public:
    string name;
    int age;
    Person(string n, int a) : name(n), age(a) {}
};

class Child : public Person {
public:
    Child(string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(string n, int a) : Person(n, a) {}
};

class NurseryManagementSystem {
    vector<Child> children;
    vector<Babysitter> babysitters;

public:
    void addChild(string name, int age) {
        children.push_back(Child(name, age));
    }

    void addBabysitter(string name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteChild(string name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->name == name) {
                children.erase(it);
                break;
            }
        }
    }

    void deleteBabysitter(string name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->name == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateChild(string oldName, string newName, int age) {
        for (auto &child : children) {
            if (child.name == oldName) {
                child.name = newName;
                child.age = age;
                break;
            }
        }
    }

    void updateBabysitter(string oldName, string newName, int age) {
        for (auto &babysitter : babysitters) {
            if (babysitter.name == oldName) {
                babysitter.name = newName;
                babysitter.age = age;
                break;
            }
        }
    }

    void searchChild(string name) {
        for (auto &child : children) {
            if (child.name == name) {
                cout << "Child Found: " << child.name << ", Age: " << child.age << endl;
                return;
            }
        }
        cout << "Child Not Found" << endl;
    }

    void searchBabysitter(string name) {
        for (auto &babysitter : babysitters) {
            if (babysitter.name == name) {
                cout << "Babysitter Found: " << babysitter.name << ", Age: " << babysitter.age << endl;
                return;
            }
        }
        cout << "Babysitter Not Found" << endl;
    }

    void displayChildren() {
        cout << "Children List:" << endl;
        for (auto &child : children) {
            cout << "Name: " << child.name << ", Age: " << child.age << endl;
        }
    }

    void displayBabysitters() {
        cout << "Babysitters List:" << endl;
        for (auto &babysitter : babysitters) {
            cout << "Name: " << babysitter.name << ", Age: " << babysitter.age << endl;
        }
    }
};

int main() {
    NurseryManagementSystem nursery;
    nursery.addChild("John", 5);
    nursery.addBabysitter("Alice", 30);
    nursery.displayChildren();
    nursery.displayBabysitters();
    nursery.searchChild("John");
    nursery.updateChild("John", "Johnny", 6);
    nursery.displayChildren();
    nursery.deleteChild("Johnny");
    nursery.displayChildren();
    return 0;
}