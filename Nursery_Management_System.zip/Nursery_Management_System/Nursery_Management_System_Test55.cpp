#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Person {
public:
    string name;
    int age;
    Person(string n, int a) : name(n), age(a) {}
};

class Child : public Person {
public:
    Child(string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(string n, int a) : Person(n, a) {}
};

class Nursery {
    vector<Child> children;
    vector<Babysitter> babysitters;

public:
    void addChild(string name, int age) {
        children.push_back(Child(name, age));
    }

    void deleteChild(string name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->name == name) {
                children.erase(it);
                break;
            }
        }
    }

    void updateChild(string name, string newName, int newAge) {
        for (auto &child : children) {
            if (child.name == name) {
                child.name = newName;
                child.age = newAge;
                break;
            }
        }
    }

    void searchChild(string name) {
        for (const auto &child : children) {
            if (child.name == name) {
                cout << "Child Found: " << child.name << ", Age: " << child.age << endl;
                return;
            }
        }
        cout << "Child Not Found" << endl;
    }

    void displayChildren() {
        for (const auto &child : children) {
            cout << "Child: " << child.name << ", Age: " << child.age << endl;
        }
    }

    void addBabysitter(string name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteBabysitter(string name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->name == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateBabysitter(string name, string newName, int newAge) {
        for (auto &babysitter : babysitters) {
            if (babysitter.name == name) {
                babysitter.name = newName;
                babysitter.age = newAge;
                break;
            }
        }
    }

    void searchBabysitter(string name) {
        for (const auto &babysitter : babysitters) {
            if (babysitter.name == name) {
                cout << "Babysitter Found: " << babysitter.name << ", Age: " << babysitter.age << endl;
                return;
            }
        }
        cout << "Babysitter Not Found" << endl;
    }

    void displayBabysitters() {
        for (const auto &babysitter : babysitters) {
            cout << "Babysitter: " << babysitter.name << ", Age: " << babysitter.age << endl;
        }
    }
};

int main() {
    Nursery nursery;
    nursery.addChild("Alice", 4);
    nursery.addChild("Bob", 3);
    nursery.addBabysitter("Eve", 27);
    nursery.addBabysitter("John", 25);

    nursery.displayChildren();
    nursery.displayBabysitters();

    nursery.searchChild("Alice");
    nursery.searchBabysitter("Eve");

    nursery.updateChild("Alice", "Alicia", 5);
    nursery.updateBabysitter("Eve", "Evie", 28);

    nursery.displayChildren();
    nursery.displayBabysitters();

    nursery.deleteChild("Bob");
    nursery.deleteBabysitter("John");

    nursery.displayChildren();
    nursery.displayBabysitters();

    return 0;
}