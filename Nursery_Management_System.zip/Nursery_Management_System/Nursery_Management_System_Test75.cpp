#include <iostream>
#include <string>
#include <vector>

class Child {
public:
    std::string name;
    int age;
    std::string id;
    
    Child(const std::string& name, int age, const std::string& id)
        : name(name), age(age), id(id) {}
};

class Babysitter {
public:
    std::string name;
    int experience;
    std::string id;
    
    Babysitter(const std::string& name, int experience, const std::string& id)
        : name(name), experience(experience), id(id) {}
};

class NurseryManagementSystem {
private:
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

public:
    void addChild(const Child& child) {
        children.push_back(child);
    }

    void deleteChild(const std::string& id) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->id == id) {
                children.erase(it);
                break;
            }
        }
    }
    
    void updateChild(const std::string& id, const Child& updatedChild) {
        for (auto& child : children) {
            if (child.id == id) {
                child = updatedChild;
                break;
            }
        }
    }
    
    Child* searchChild(const std::string& id) {
        for (auto& child : children) {
            if (child.id == id) {
                return &child;
            }
        }
        return nullptr;
    }
    
    void displayChildren() const {
        for (const auto& child : children) {
            std::cout << "Child Name: " << child.name << ", Age: " << child.age << ", ID: " << child.id << std::endl;
        }
    }

    void addBabysitter(const Babysitter& babysitter) {
        babysitters.push_back(babysitter);
    }

    void deleteBabysitter(const std::string& id) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->id == id) {
                babysitters.erase(it);
                break;
            }
        }
    }
    
    void updateBabysitter(const std::string& id, const Babysitter& updatedBabysitter) {
        for (auto& babysitter : babysitters) {
            if (babysitter.id == id) {
                babysitter = updatedBabysitter;
                break;
            }
        }
    }
    
    Babysitter* searchBabysitter(const std::string& id) {
        for (auto& babysitter : babysitters) {
            if (babysitter.id == id) {
                return &babysitter;
            }
        }
        return nullptr;
    }
    
    void displayBabysitters() const {
        for (const auto& babysitter : babysitters) {
            std::cout << "Babysitter Name: " << babysitter.name << ", Experience: " << babysitter.experience << ", ID: " << babysitter.id << std::endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild(Child("Alice", 5, "C001"));
    nms.addBabysitter(Babysitter("Jane", 3, "B001"));
    nms.displayChildren();
    nms.displayBabysitters();
    nms.updateChild("C001", Child("Alice", 6, "C001"));
    nms.displayChildren();
    nms.deleteChild("C001");
    nms.displayChildren();
    return 0;
}