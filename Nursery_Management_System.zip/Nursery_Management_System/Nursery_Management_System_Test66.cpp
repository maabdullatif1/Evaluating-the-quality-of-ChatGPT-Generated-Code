#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;
    
    Person(std::string n, int a) : name(n), age(a) {}
};

class Child : public Person {
public:
    Child(std::string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(std::string n, int a) : Person(n, a) {}
};

class NurseryManagementSystem {
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;
    
    template <typename T>
    void display(const std::vector<T>& people) {
        for (const auto& person : people) {
            std::cout << "Name: " << person.name << ", Age: " << person.age << std::endl;
        }
    }
    
    template <typename T>
    int findIndex(const std::vector<T>& people, const std::string& name) {
        for (size_t i = 0; i < people.size(); ++i) {
            if (people[i].name == name) return static_cast<int>(i);
        }
        return -1;
    }
    
public:
    void addChild(const std::string& name, int age) {
        children.push_back(Child(name, age));
    }
    
    void addBabysitter(const std::string& name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }
    
    void deleteChild(const std::string& name) {
        int index = findIndex(children, name);
        if (index != -1) children.erase(children.begin() + index);
    }
    
    void deleteBabysitter(const std::string& name) {
        int index = findIndex(babysitters, name);
        if (index != -1) babysitters.erase(babysitters.begin() + index);
    }
    
    void updateChild(const std::string& name, const std::string& newName, int newAge) {
        int index = findIndex(children, name);
        if (index != -1) {
            children[index].name = newName;
            children[index].age = newAge;
        }
    }
    
    void updateBabysitter(const std::string& name, const std::string& newName, int newAge) {
        int index = findIndex(babysitters, name);
        if (index != -1) {
            babysitters[index].name = newName;
            babysitters[index].age = newAge;
        }
    }
    
    void searchChild(const std::string& name) {
        int index = findIndex(children, name);
        if (index != -1) {
            std::cout << "Child found: " << children[index].name << ", Age: " << children[index].age << std::endl;
        } else {
            std::cout << "Child not found\n";
        }
    }
    
    void searchBabysitter(const std::string& name) {
        int index = findIndex(babysitters, name);
        if (index != -1) {
            std::cout << "Babysitter found: " << babysitters[index].name << ", Age: " << babysitters[index].age << std::endl;
        } else {
            std::cout << "Babysitter not found\n";
        }
    }
    
    void displayChildren() {
        std::cout << "Children: " << std::endl;
        display(children);
    }
    
    void displayBabysitters() {
        std::cout << "Babysitters: " << std::endl;
        display(babysitters);
    }
};

int main() {
    NurseryManagementSystem nms;
    
    nms.addChild("John", 5);
    nms.addChild("Alice", 4);
    nms.addBabysitter("Mary", 30);
    nms.addBabysitter("Tom", 25);
    
    nms.displayChildren();
    nms.displayBabysitters();
    
    nms.updateChild("John", "Johnny", 6);
    nms.updateBabysitter("Tom", "Thomas", 26);
    
    nms.displayChildren();
    nms.displayBabysitters();
    
    nms.searchChild("Alice");
    nms.searchBabysitter("Mary");
    
    nms.deleteChild("Alice");
    nms.deleteBabysitter("Mary");
    
    nms.displayChildren();
    nms.displayBabysitters();
    
    return 0;
}