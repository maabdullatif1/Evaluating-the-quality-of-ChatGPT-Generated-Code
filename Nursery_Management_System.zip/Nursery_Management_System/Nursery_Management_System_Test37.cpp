#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    int id;
    std::string name;
    int age;
    
    Person(int id, const std::string& name, int age) : id(id), name(name), age(age) {}
};

class Child : public Person {
public:
    Child(int id, const std::string& name, int age) : Person(id, name, age) {}
};

class Babysitter : public Person {
public:
    Babysitter(int id, const std::string& name, int age) : Person(id, name, age) {}
};

template<typename T>
class ManagementSystem {
private:
    std::vector<T> records;
    
public:
    void add(int id, const std::string& name, int age) {
        records.push_back(T(id, name, age));
    }
    
    bool remove(int id) {
        for (auto it = records.begin(); it != records.end(); ++it) {
            if (it->id == id) {
                records.erase(it);
                return true;
            }
        }
        return false;
    }
    
    bool update(int id, const std::string& name, int age) {
        for (auto& record : records) {
            if (record.id == id) {
                record.name = name;
                record.age = age;
                return true;
            }
        }
        return false;
    }
    
    void search(int id) {
        for (const auto& record : records) {
            if (record.id == id) {
                std::cout << "ID: " << record.id << " Name: " << record.name << " Age: " << record.age << std::endl;
                return;
            }
        }
        std::cout << "Record not found.\n";
    }
    
    void display() {
        for (const auto& record : records) {
            std::cout << "ID: " << record.id << " Name: " << record.name << " Age: " << record.age << std::endl;
        }
    }
};

int main() {
    ManagementSystem<Child> childSystem;
    ManagementSystem<Babysitter> babysitterSystem;

    childSystem.add(1, "Alice", 4);
    childSystem.add(2, "Bob", 5);
    babysitterSystem.add(1, "Emily", 29);
    babysitterSystem.add(2, "John", 32);

    std::cout << "Children:\n";
    childSystem.display();
    std::cout << "\nBabysitters:\n";
    babysitterSystem.display();

    std::cout << "\nUpdating Babysitter with ID 1.\n";
    babysitterSystem.update(1, "Emilia", 30);
    babysitterSystem.search(1);

    std::cout << "\nDeleting Child with ID 1.\n";
    childSystem.remove(1);
    childSystem.display();

    return 0;
}