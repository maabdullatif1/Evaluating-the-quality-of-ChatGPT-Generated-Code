#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    int age;
    string id;
};

class NurseryManagement {
private:
    vector<Person> children;
    vector<Person> babysitters;

    void displayPerson(const Person& person) {
        cout << "Name: " << person.name << ", Age: " << person.age << ", ID: " << person.id << endl;
    }

    vector<Person>::iterator findPerson(vector<Person>& people, const string& id) {
        for (auto it = people.begin(); it != people.end(); ++it) {
            if (it->id == id) return it;
        }
        return people.end();
    }

public:
    void addChild(const string& name, int age, const string& id) {
        children.push_back({name, age, id});
    }
    
    void addBabysitter(const string& name, int age, const string& id) {
        babysitters.push_back({name, age, id});
    }

    void deleteChild(const string& id) {
        auto it = findPerson(children, id);
        if (it != children.end()) children.erase(it);
    }

    void deleteBabysitter(const string& id) {
        auto it = findPerson(babysitters, id);
        if (it != babysitters.end()) babysitters.erase(it);
    }

    void updateChild(const string& id, const string& name, int age) {
        auto it = findPerson(children, id);
        if (it != children.end()) {
            it->name = name;
            it->age = age;
        }
    }

    void updateBabysitter(const string& id, const string& name, int age) {
        auto it = findPerson(babysitters, id);
        if (it != babysitters.end()) {
            it->name = name;
            it->age = age;
        }
    }

    void searchChildren(const string& id) {
        auto it = findPerson(children, id);
        if (it != children.end()) displayPerson(*it);
    }

    void searchBabysitters(const string& id) {
        auto it = findPerson(babysitters, id);
        if (it != babysitters.end()) displayPerson(*it);
    }

    void displayChildren() {
        for (const auto& child : children) displayPerson(child);
    }

    void displayBabysitters() {
        for (const auto& babysitter : babysitters) displayPerson(babysitter);
    }
};

int main() {
    NurseryManagement system;
    system.addChild("Alice", 5, "C001");
    system.addBabysitter("Jack", 30, "B001");
    system.displayChildren();
    system.displayBabysitters();
    system.updateChild("C001", "Alice Smith", 6);
    system.searchChildren("C001");
    system.deleteChild("C001");
    system.displayChildren();
    return 0;
}