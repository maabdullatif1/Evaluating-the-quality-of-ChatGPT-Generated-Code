#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;
};

class Child : public Person {
public:
    int id;
};

class Babysitter : public Person {
public:
    int id;
};

class NurseryManagementSystem {
private:
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;
    
    int findChildIndexById(int id) {
        for (unsigned int i = 0; i < children.size(); ++i) {
            if (children[i].id == id) return i;
        }
        return -1;
    }
    
    int findBabysitterIndexById(int id) {
        for (unsigned int i = 0; i < babysitters.size(); ++i) {
            if (babysitters[i].id == id) return i;
        }
        return -1;
    }

public:
    void addChild(int id, std::string name, int age) {
        Child child;
        child.id = id;
        child.name = name;
        child.age = age;
        children.push_back(child);
    }
    
    void addBabysitter(int id, std::string name, int age) {
        Babysitter babysitter;
        babysitter.id = id;
        babysitter.name = name;
        babysitter.age = age;
        babysitters.push_back(babysitter);
    }
    
    void deleteChild(int id) {
        int index = findChildIndexById(id);
        if (index != -1)
            children.erase(children.begin() + index);
    }
    
    void deleteBabysitter(int id) {
        int index = findBabysitterIndexById(id);
        if (index != -1)
            babysitters.erase(babysitters.begin() + index);
    }
    
    void updateChild(int id, std::string name, int age) {
        int index = findChildIndexById(id);
        if (index != -1) {
            children[index].name = name;
            children[index].age = age;
        }
    }
    
    void updateBabysitter(int id, std::string name, int age) {
        int index = findBabysitterIndexById(id);
        if (index != -1) {
            babysitters[index].name = name;
            babysitters[index].age = age;
        }
    }
    
    void searchChild(int id) {
        int index = findChildIndexById(id);
        if (index != -1) {
            std::cout << "Child Found: " 
                      << "ID: " << children[index].id 
                      << ", Name: " << children[index].name 
                      << ", Age: " << children[index].age << std::endl;
        } else {
            std::cout << "Child Not Found" << std::endl;
        }
    }
    
    void searchBabysitter(int id) {
        int index = findBabysitterIndexById(id);
        if (index != -1) {
            std::cout << "Babysitter Found: " 
                      << "ID: " << babysitters[index].id 
                      << ", Name: " << babysitters[index].name 
                      << ", Age: " << babysitters[index].age << std::endl;
        } else {
            std::cout << "Babysitter Not Found" << std::endl;
        }
    }
    
    void displayChildren() {
        std::cout << "Children Information:" << std::endl;
        for (const auto& child : children) {
            std::cout << "ID: " << child.id 
                      << ", Name: " << child.name 
                      << ", Age: " << child.age << std::endl;
        }
    }

    void displayBabysitters() {
        std::cout << "Babysitters Information:" << std::endl;
        for (const auto& babysitter : babysitters) {
            std::cout << "ID: " << babysitter.id 
                      << ", Name: " << babysitter.name 
                      << ", Age: " << babysitter.age << std::endl;
        }
    }
};

int main() {
    NurseryManagementSystem system;
    
    system.addChild(1, "Alice", 5);
    system.addChild(2, "Bob", 4);
    
    system.addBabysitter(1, "Carol", 23);
    system.addBabysitter(2, "Dave", 30);
    
    system.displayChildren();
    system.displayBabysitters();
    
    system.searchChild(1);
    system.searchBabysitter(1);
    
    system.updateChild(1, "Alice A.", 6);
    system.updateBabysitter(1, "Carol C.", 24);
    
    system.displayChildren();
    system.displayBabysitters();
    
    system.deleteChild(2);
    system.deleteBabysitter(2);
    
    system.displayChildren();
    system.displayBabysitters();
    
    return 0;
}