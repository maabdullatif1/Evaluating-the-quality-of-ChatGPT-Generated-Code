#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
protected:
    string name;
    int age;
public:
    Person(string name, int age) : name(name), age(age) {}
    virtual string getInfo() const {
        return "Name: " + name + ", Age: " + to_string(age);
    }
    string getName() const {
        return name;
    }
};

class Child : public Person {
public:
    Child(string name, int age) : Person(name, age) {}
};

class Babysitter : public Person {
public:
    Babysitter(string name, int age) : Person(name, age) {}
};

class NurseryManagementSystem {
private:
    vector<Child> children;
    vector<Babysitter> babysitters;
public:
    void addChild(string name, int age) {
        children.push_back(Child(name, age));
    }
    
    void addBabysitter(string name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }
    
    void deleteChild(string name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->getName() == name) {
                children.erase(it);
                break;
            }
        }
    }
    
    void deleteBabysitter(string name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->getName() == name) {
                babysitters.erase(it);
                break;
            }
        }
    }
    
    void updateChild(string name, string newName, int newAge) {
        for (auto &child : children) {
            if (child.getName() == name) {
                child = Child(newName, newAge);
                break;
            }
        }
    }
    
    void updateBabysitter(string name, string newName, int newAge) {
        for (auto &babysitter : babysitters) {
            if (babysitter.getName() == name) {
                babysitter = Babysitter(newName, newAge);
                break;
            }
        }
    }

    void searchChild(string name) const {
        for (const auto &child : children) {
            if (child.getName() == name) {
                cout << child.getInfo() << endl;
                return;
            }
        }
        cout << "Child not found" << endl;
    }
    
    void searchBabysitter(string name) const {
        for (const auto &babysitter : babysitters) {
            if (babysitter.getName() == name) {
                cout << babysitter.getInfo() << endl;
                return;
            }
        }
        cout << "Babysitter not found" << endl;
    }
    
    void displayAllChildren() const {
        for (const auto &child : children) {
            cout << child.getInfo() << endl;
        }
        if (children.empty()) {
            cout << "No children available." << endl;
        }
    }
    
    void displayAllBabysitters() const {
        for (const auto &babysitter : babysitters) {
            cout << babysitter.getInfo() << endl;
        }
        if (babysitters.empty()) {
            cout << "No babysitters available." << endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 4);
    nms.addChild("Bob", 3);
    nms.addBabysitter("John", 25);
    nms.addBabysitter("Emily", 30);

    nms.displayAllChildren();
    nms.displayAllBabysitters();

    nms.searchChild("Alice");
    nms.searchBabysitter("John");

    nms.updateChild("Alice", "Alicia", 5);
    nms.updateBabysitter("John", "Johnny", 26);

    nms.displayAllChildren();
    nms.displayAllBabysitters();

    nms.deleteChild("Bob");
    nms.deleteBabysitter("Emily");

    nms.displayAllChildren();
    nms.displayAllBabysitters();

    return 0;
}