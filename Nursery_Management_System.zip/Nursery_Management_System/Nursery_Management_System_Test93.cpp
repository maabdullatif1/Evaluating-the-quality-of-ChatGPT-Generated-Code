#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Person {
    string name;
    int age;
    string id;
};

class NurseryManagementSystem {
private:
    vector<Person> children;
    vector<Person> babysitters;

    Person* findPersonById(vector<Person>& list, const string& id) {
        for (auto& person : list) {
            if (person.id == id) {
                return &person;
            }
        }
        return nullptr;
    }

public:
    void addChild(const string& name, int age, const string& id) {
        children.push_back({name, age, id});
    }

    void addBabysitter(const string& name, int age, const string& id) {
        babysitters.push_back({name, age, id});
    }

    bool deleteChild(const string& id) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->id == id) {
                children.erase(it);
                return true;
            }
        }
        return false;
    }

    bool deleteBabysitter(const string& id) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->id == id) {
                babysitters.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateChild(const string& id, const string& newName, int newAge) {
        Person* child = findPersonById(children, id);
        if (child) {
            child->name = newName;
            child->age = newAge;
            return true;
        }
        return false;
    }

    bool updateBabysitter(const string& id, const string& newName, int newAge) {
        Person* babysitter = findPersonById(babysitters, id);
        if (babysitter) {
            babysitter->name = newName;
            babysitter->age = newAge;
            return true;
        }
        return false;
    }

    Person* searchChild(const string& id) {
        return findPersonById(children, id);
    }

    Person* searchBabysitter(const string& id) {
        return findPersonById(babysitters, id);
    }

    void displayChildren() const {
        for (const auto& child : children) {
            cout << "Child Name: " << child.name << ", Age: " << child.age << ", ID: " << child.id << endl;
        }
    }

    void displayBabysitters() const {
        for (const auto& babysitter : babysitters) {
            cout << "Babysitter Name: " << babysitter.name << ", Age: " << babysitter.age << ", ID: " << babysitter.id << endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 3, "C001");
    nms.addChild("Bob", 4, "C002");
    nms.addBabysitter("John", 30, "B001");
    nms.addBabysitter("Jane", 28, "B002");
    nms.displayChildren();
    nms.displayBabysitters();

    nms.updateChild("C001", "Alicia", 4);
    nms.updateBabysitter("B002", "Janet", 29);

    Person* child = nms.searchChild("C002");
    if (child) {
        cout << "Found Child - Name: " << child->name << ", Age: " << child->age << ", ID: " << child->id << endl;
    }

    nms.deleteChild("C002");
    nms.deleteBabysitter("B001");
    
    nms.displayChildren();
    nms.displayBabysitters();

    return 0;
}