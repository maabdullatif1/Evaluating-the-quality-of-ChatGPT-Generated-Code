#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Person {
public:
    string name;
    int age;
    string phoneNumber;
    
    Person(string n, int a, string p) : name(n), age(a), phoneNumber(p) {}
};

class Child : public Person {
public:
    Child(string n, int a, string p) : Person(n, a, p) {}
};

class Babysitter : public Person {
public:
    Babysitter(string n, int a, string p) : Person(n, a, p) {}
};

class NurseryManagementSystem {
    vector<Child> children;
    vector<Babysitter> babysitters;

    template <typename T>
    void displayRecords(const vector<T>& records) {
        for (const auto& record : records) {
            cout << "Name: " << record.name << ", Age: " << record.age 
                 << ", Phone: " << record.phoneNumber << endl;
        }
    }

    template <typename T>
    int findRecordIndex(vector<T>& records, const string& name) {
        for (int i = 0; i < records.size(); ++i) {
            if (records[i].name == name) return i;
        }
        return -1;
    }

public:
    void addChild(const string& name, int age, const string& phoneNumber) {
        children.emplace_back(name, age, phoneNumber);
    }

    void addBabysitter(const string& name, int age, const string& phoneNumber) {
        babysitters.emplace_back(name, age, phoneNumber);
    }

    void deleteChild(const string& name) {
        int index = findRecordIndex(children, name);
        if (index != -1) children.erase(children.begin() + index);
    }

    void deleteBabysitter(const string& name) {
        int index = findRecordIndex(babysitters, name);
        if (index != -1) babysitters.erase(babysitters.begin() + index);
    }

    void updateChild(const string& name, const string& newName, int newAge, const string& newPhone) {
        int index = findRecordIndex(children, name);
        if (index != -1) {
            children[index].name = newName;
            children[index].age = newAge;
            children[index].phoneNumber = newPhone;
        }
    }

    void updateBabysitter(const string& name, const string& newName, int newAge, const string& newPhone) {
        int index = findRecordIndex(babysitters, name);
        if (index != -1) {
            babysitters[index].name = newName;
            babysitters[index].age = newAge;
            babysitters[index].phoneNumber = newPhone;
        }
    }

    void searchChild(const string& name) {
        int index = findRecordIndex(children, name);
        if (index != -1) 
            cout << "Found Child: Name: " << children[index].name << ", Age: " << children[index].age 
                 << ", Phone: " << children[index].phoneNumber << endl;
        else 
            cout << "Child not found" << endl;
    }

    void searchBabysitter(const string& name) {
        int index = findRecordIndex(babysitters, name);
        if (index != -1) 
            cout << "Found Babysitter: Name: " << babysitters[index].name << ", Age: " << babysitters[index].age 
                 << ", Phone: " << babysitters[index].phoneNumber << endl;
        else 
            cout << "Babysitter not found" << endl;
    }

    void showAllChildren() {
        cout << "Children Records:" << endl;
        displayRecords(children);
    }

    void showAllBabysitters() {
        cout << "Babysitters Records:" << endl;
        displayRecords(babysitters);
    }
};

int main() {
    NurseryManagementSystem system;
    system.addChild("John", 6, "123456789");
    system.addBabysitter("Alice", 28, "987654321");
    system.showAllChildren();
    system.showAllBabysitters();
    system.updateChild("John", "Johnny", 7, "111222333");
    system.searchChild("Johnny");
    system.deleteBabysitter("Alice");
    system.showAllBabysitters();
    return 0;
}