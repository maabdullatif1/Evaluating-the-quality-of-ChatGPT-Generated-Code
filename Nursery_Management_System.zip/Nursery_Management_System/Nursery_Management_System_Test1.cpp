#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
protected:
    string name;
    int age;
public:
    Person(string name, int age) : name(name), age(age) {}
    string getName() const { return name; }
    int getAge() const { return age; }
    virtual void display() const = 0;
    virtual void update(string name, int age) {
        this->name = name;
        this->age = age;
    }
};

class Child : public Person {
public:
    Child(string name, int age) : Person(name, age) {}
    void display() const override {
        cout << "Child Name: " << name << ", Age: " << age << endl;
    }
};

class Babysitter : public Person {
public:
    Babysitter(string name, int age) : Person(name, age) {}
    void display() const override {
        cout << "Babysitter Name: " << name << ", Age: " << age << endl;
    }
};

class NurseryManagementSystem {
    vector<Child> children;
    vector<Babysitter> babysitters;

public:
    void addChild(string name, int age) {
        children.emplace_back(name, age);
    }

    void addBabysitter(string name, int age) {
        babysitters.emplace_back(name, age);
    }

    void deleteChild(string name) {
        children.erase(remove_if(children.begin(), children.end(), [&](Child &c) { return c.getName() == name; }), children.end());
    }

    void deleteBabysitter(string name) {
        babysitters.erase(remove_if(babysitters.begin(), babysitters.end(), [&](Babysitter &b) { return b.getName() == name; }), babysitters.end());
    }

    void updateChild(string oldName, string newName, int age) {
        for (auto &child : children)
            if (child.getName() == oldName)
                child.update(newName, age);
    }

    void updateBabysitter(string oldName, string newName, int age) {
        for (auto &babysitter : babysitters)
            if (babysitter.getName() == oldName)
                babysitter.update(newName, age);
    }

    Child* searchChild(string name) {
        for (auto &child : children)
            if (child.getName() == name)
                return &child;
        return nullptr;
    }

    Babysitter* searchBabysitter(string name) {
        for (auto &babysitter : babysitters)
            if (babysitter.getName() == name)
                return &babysitter;
        return nullptr;
    }

    void displayChildren() {
        for (const auto &child : children)
            child.display();
    }

    void displayBabysitters() {
        for (const auto &babysitter : babysitters)
            babysitter.display();
    }
};

int main() {
    NurseryManagementSystem nursery;

    nursery.addChild("Alice", 5);
    nursery.addBabysitter("Bob", 23);

    nursery.displayChildren();
    nursery.displayBabysitters();

    Child* child = nursery.searchChild("Alice");
    if (child) child->display();

    Babysitter* sitter = nursery.searchBabysitter("Bob");
    if (sitter) sitter->display();

    nursery.updateChild("Alice", "Alice Green", 6);
    nursery.updateBabysitter("Bob", "Robert Brown", 24);

    nursery.displayChildren();
    nursery.displayBabysitters();

    nursery.deleteChild("Alice Green");
    nursery.deleteBabysitter("Robert Brown");

    nursery.displayChildren();
    nursery.displayBabysitters();

    return 0;
}