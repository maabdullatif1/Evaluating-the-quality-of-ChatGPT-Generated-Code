#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Person {
protected:
    string name;
    int age;
public:
    Person(string n, int a) : name(n), age(a) {}
    string getName() const { return name; }
    int getAge() const { return age; }
    void setName(string n) { name = n; }
    void setAge(int a) { age = a; }
};

class Child : public Person {
public:
    Child(string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(string n, int a) : Person(n, a) {}
};

class NurseryManagementSystem {
private:
    vector<Child> children;
    vector<Babysitter> babysitters;

    template<typename T>
    int findPersonIndex(const vector<T>& people, const string& name) {
        for (size_t i = 0; i < people.size(); ++i) {
            if (people[i].getName() == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addChild(const string& name, int age) {
        children.push_back(Child(name, age));
    }

    void deleteChild(const string& name) {
        int index = findPersonIndex(children, name);
        if (index != -1) {
            children.erase(children.begin() + index);
        }
    }

    void updateChild(const string& name, const string& newName, int newAge) {
        int index = findPersonIndex(children, name);
        if (index != -1) {
            children[index].setName(newName);
            children[index].setAge(newAge);
        }
    }

    void searchChild(const string& name) {
        int index = findPersonIndex(children, name);
        if (index != -1) {
            cout << "Child found: Name = " << children[index].getName() << ", Age = " << children[index].getAge() << "\n";
        } else {
            cout << "Child not found\n";
        }
    }

    void displayChildren() {
        cout << "Children:\n";
        for (const auto& child : children) {
            cout << "Name = " << child.getName() << ", Age = " << child.getAge() << "\n";
        }
    }

    void addBabysitter(const string& name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteBabysitter(const string& name) {
        int index = findPersonIndex(babysitters, name);
        if (index != -1) {
            babysitters.erase(babysitters.begin() + index);
        }
    }

    void updateBabysitter(const string& name, const string& newName, int newAge) {
        int index = findPersonIndex(babysitters, name);
        if (index != -1) {
            babysitters[index].setName(newName);
            babysitters[index].setAge(newAge);
        }
    }

    void searchBabysitter(const string& name) {
        int index = findPersonIndex(babysitters, name);
        if (index != -1) {
            cout << "Babysitter found: Name = " << babysitters[index].getName() << ", Age = " << babysitters[index].getAge() << "\n";
        } else {
            cout << "Babysitter not found\n";
        }
    }

    void displayBabysitters() {
        cout << "Babysitters:\n";
        for (const auto& babysitter : babysitters) {
            cout << "Name = " << babysitter.getName() << ", Age = " << babysitter.getAge() << "\n";
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 3);
    nms.addChild("Bob", 4);
    nms.addBabysitter("Eve", 30);
    nms.addBabysitter("Mallory", 25);
    nms.displayChildren();
    nms.displayBabysitters();
    nms.searchChild("Alice");
    nms.updateChild("Alice", "Alice Smith", 4);
    nms.displayChildren();
    nms.deleteChild("Bob");
    nms.displayChildren();
    nms.searchBabysitter("Eve");
    nms.updateBabysitter("Eve", "Eve Johnson", 31);
    nms.displayBabysitters();
    nms.deleteBabysitter("Mallory");
    nms.displayBabysitters();
    return 0;
}