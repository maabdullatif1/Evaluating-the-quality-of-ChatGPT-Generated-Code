#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Child {
    int id;
    string name;
    int age;
};

struct Babysitter {
    int id;
    string name;
    int age;
};

class NurserySystem {
    vector<Child> children;
    vector<Babysitter> babysitters;

    int findChildIndexById(int id) {
        for (int i = 0; i < children.size(); ++i) {
            if (children[i].id == id) return i;
        }
        return -1;
    }

    int findBabysitterIndexById(int id) {
        for (int i = 0; i < babysitters.size(); ++i) {
            if (babysitters[i].id == id) return i;
        }
        return -1;
    }

public:
    void addChild(int id, string name, int age) {
        if (findChildIndexById(id) == -1) {
            children.push_back(Child{id, name, age});
        }
    }

    void deleteChild(int id) {
        int index = findChildIndexById(id);
        if (index != -1) {
            children.erase(children.begin() + index);
        }
    }

    void updateChild(int id, string name, int age) {
        int index = findChildIndexById(id);
        if (index != -1) {
            children[index].name = name;
            children[index].age = age;
        }
    }

    Child* searchChild(int id) {
        int index = findChildIndexById(id);
        if (index != -1) {
            return &children[index];
        }
        return nullptr;
    }

    void addBabysitter(int id, string name, int age) {
        if (findBabysitterIndexById(id) == -1) {
            babysitters.push_back(Babysitter{id, name, age});
        }
    }

    void deleteBabysitter(int id) {
        int index = findBabysitterIndexById(id);
        if (index != -1) {
            babysitters.erase(babysitters.begin() + index);
        }
    }

    void updateBabysitter(int id, string name, int age) {
        int index = findBabysitterIndexById(id);
        if (index != -1) {
            babysitters[index].name = name;
            babysitters[index].age = age;
        }
    }

    Babysitter* searchBabysitter(int id) {
        int index = findBabysitterIndexById(id);
        if (index != -1) {
            return &babysitters[index];
        }
        return nullptr;
    }

    void displayChildren() {
        for (Child &c : children) {
            cout << "Child ID: " << c.id << ", Name: " << c.name << ", Age: " << c.age << endl;
        }
    }

    void displayBabysitters() {
        for (Babysitter &b : babysitters) {
            cout << "Babysitter ID: " << b.id << ", Name: " << b.name << ", Age: " << b.age << endl;
        }
    }
};

int main() {
    NurserySystem nursery;
    nursery.addChild(1, "Alice", 3);
    nursery.addChild(2, "Bob", 4);
    nursery.addBabysitter(1, "Sophie", 30);
    nursery.addBabysitter(2, "John", 28);
    
    nursery.displayChildren();
    nursery.displayBabysitters();
    
    return 0;
}