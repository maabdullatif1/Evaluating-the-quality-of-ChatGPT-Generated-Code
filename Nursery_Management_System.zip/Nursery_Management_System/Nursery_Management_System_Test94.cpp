#include <iostream>
#include <vector>
#include <string>

using std::string;
using std::vector;
using std::cout;
using std::cin;
using std::endl;

class Child {
public:
    int id;
    string name;
    int age;

    Child(int id, string name, int age) : id(id), name(name), age(age) {}
};

class Babysitter {
public:
    int id;
    string name;
    int experience;

    Babysitter(int id, string name, int experience) : id(id), name(name), experience(experience) {}
};

class NurseryManagement {
private:
    vector<Child> children;
    vector<Babysitter> babysitters;

    template<typename T>
    void display(vector<T>& items) {
        for (const auto& item : items) {
            cout << "ID: " << item.id << ", Name: " << item.name;
            if constexpr (std::is_same_v<T, Child>) {
                cout << ", Age: " << item.age;
            } else if constexpr (std::is_same_v<T, Babysitter>) {
                cout << ", Experience: " << item.experience;
            }
            cout << endl;
        }
    }

    template<typename T>
    T* search(vector<T>& items, int id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    template<typename T>
    void deleteItem(vector<T>& items, int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

public:
    void addChild(int id, string name, int age) {
        children.emplace_back(id, name, age);
    }

    void addBabysitter(int id, string name, int experience) {
        babysitters.emplace_back(id, name, experience);
    }

    void deleteChild(int id) {
        deleteItem(children, id);
    }

    void deleteBabysitter(int id) {
        deleteItem(babysitters, id);
    }

    void updateChild(int id, string name, int age) {
        if (auto* child = search(children, id)) {
            child->name = name;
            child->age = age;
        }
    }

    void updateBabysitter(int id, string name, int experience) {
        if (auto* babysitter = search(babysitters, id)) {
            babysitter->name = name;
            babysitter->experience = experience;
        }
    }

    void displayChildren() {
        display(children);
    }

    void displayBabysitters() {
        display(babysitters);
    }

    void searchChild(int id) {
        if (auto* child = search(children, id)) {
            cout << "Found Child - ID: " << child->id << ", Name: " << child->name << ", Age: " << child->age << endl;
        } else {
            cout << "Child not found" << endl;
        }
    }

    void searchBabysitter(int id) {
        if (auto* babysitter = search(babysitters, id)) {
            cout << "Found Babysitter - ID: " << babysitter->id << ", Name: " << babysitter->name << ", Experience: " << babysitter->experience << " years" << endl;
        } else {
            cout << "Babysitter not found" << endl;
        }
    }
};

int main() {
    NurseryManagement system;
    int choice, id, age, experience;
    string name;

    while (true) {
        cout << "1. Add Child\n2. Add Babysitter\n3. Delete Child\n4. Delete Babysitter\n5. Update Child\n6. Update Babysitter\n7. Search Child\n8. Search Babysitter\n9. Display Children\n10. Display Babysitters\n11. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter ID, Name, Age: ";
            cin >> id >> name >> age;
            system.addChild(id, name, age);
            break;
        case 2:
            cout << "Enter ID, Name, Experience: ";
            cin >> id >> name >> experience;
            system.addBabysitter(id, name, experience);
            break;
        case 3:
            cout << "Enter Child ID to delete: ";
            cin >> id;
            system.deleteChild(id);
            break;
        case 4:
            cout << "Enter Babysitter ID to delete: ";
            cin >> id;
            system.deleteBabysitter(id);
            break;
        case 5:
            cout << "Enter ID, New Name, New Age: ";
            cin >> id >> name >> age;
            system.updateChild(id, name, age);
            break;
        case 6:
            cout << "Enter ID, New Name, New Experience: ";
            cin >> id >> name >> experience;
            system.updateBabysitter(id, name, experience);
            break;
        case 7:
            cout << "Enter Child ID to search: ";
            cin >> id;
            system.searchChild(id);
            break;
        case 8:
            cout << "Enter Babysitter ID to search: ";
            cin >> id;
            system.searchBabysitter(id);
            break;
        case 9:
            system.displayChildren();
            break;
        case 10:
            system.displayBabysitters();
            break;
        case 11:
            return 0;
        default:
            cout << "Invalid choice" << endl;
        }
    }
}