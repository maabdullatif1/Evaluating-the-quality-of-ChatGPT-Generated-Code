#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
public:
    string name;
    int age;
    
    Person(string name, int age) : name(name), age(age) {}
};

class Child : public Person {
public:
    Child(string name, int age) : Person(name, age) {}
};

class Babysitter : public Person {
public:
    Babysitter(string name, int age) : Person(name, age) {}
};

class NurseryManagementSystem {
    vector<Child> children;
    vector<Babysitter> babysitters;

public:
    void addChild(string name, int age) {
        children.push_back(Child(name, age));
    }

    void addBabysitter(string name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteChild(string name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->name == name) {
                children.erase(it);
                break;
            }
        }
    }

    void deleteBabysitter(string name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->name == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateChild(string name, string newName, int newAge) {
        for (auto &child : children) {
            if (child.name == name) {
                child.name = newName;
                child.age = newAge;
                break;
            }
        }
    }

    void updateBabysitter(string name, string newName, int newAge) {
        for (auto &babysitter : babysitters) {
            if (babysitter.name == name) {
                babysitter.name = newName;
                babysitter.age = newAge;
                break;
            }
        }
    }

    void searchChild(string name) {
        for (const auto &child : children) {
            if (child.name == name) {
                cout << "Child found: " << child.name << ", Age: " << child.age << endl;
                return;
            }
        }
        cout << "Child not found." << endl;
    }

    void searchBabysitter(string name) {
        for (const auto &babysitter : babysitters) {
            if (babysitter.name == name) {
                cout << "Babysitter found: " << babysitter.name << ", Age: " << babysitter.age << endl;
                return;
            }
        }
        cout << "Babysitter not found." << endl;
    }

    void displayChildren() {
        cout << "Children:" << endl;
        for (const auto &child : children) {
            cout << "Name: " << child.name << ", Age: " << child.age << endl;
        }
    }

    void displayBabysitters() {
        cout << "Babysitters:" << endl;
        for (const auto &babysitter : babysitters) {
            cout << "Name: " << babysitter.name << ", Age: " << babysitter.age << endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;

    nms.addChild("John", 3);
    nms.addChild("Anna", 4);

    nms.addBabysitter("Mary", 25);
    nms.addBabysitter("Susan", 30);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.updateChild("Anna", "Annabelle", 5);
    nms.updateBabysitter("Mary", "Marianne", 26);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.searchChild("John");
    nms.searchBabysitter("Susan");

    nms.deleteChild("John");
    nms.deleteBabysitter("Susan");

    nms.displayChildren();
    nms.displayBabysitters();

    return 0;
}