#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;
};

class Child : public Person {
public:
    int id;
};

class Babysitter : public Person {
public:
    int id;
};

class NurseryManagementSystem {
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;
    
public:
    void addChild(int id, std::string name, int age) {
        Child child;
        child.id = id;
        child.name = name;
        child.age = age;
        children.push_back(child);
    }

    void addBabysitter(int id, std::string name, int age) {
        Babysitter babysitter;
        babysitter.id = id;
        babysitter.name = name;
        babysitter.age = age;
        babysitters.push_back(babysitter);
    }

    void deleteChild(int id) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->id == id) {
                children.erase(it);
                break;
            }
        }
    }

    void deleteBabysitter(int id) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->id == id) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateChild(int id, std::string name, int age) {
        for (auto& child : children) {
            if (child.id == id) {
                child.name = name;
                child.age = age;
                break;
            }
        }
    }

    void updateBabysitter(int id, std::string name, int age) {
        for (auto& babysitter : babysitters) {
            if (babysitter.id == id) {
                babysitter.name = name;
                babysitter.age = age;
                break;
            }
        }
    }

    Child* searchChild(int id) {
        for (auto& child : children) {
            if (child.id == id) {
                return &child;
            }
        }
        return nullptr;
    }

    Babysitter* searchBabysitter(int id) {
        for (auto& babysitter : babysitters) {
            if (babysitter.id == id) {
                return &babysitter;
            }
        }
        return nullptr;
    }

    void displayChildren() {
        for (const auto& child : children) {
            std::cout << "Child ID: " << child.id 
                      << ", Name: " << child.name 
                      << ", Age: " << child.age << std::endl;
        }
    }

    void displayBabysitters() {
        for (const auto& babysitter : babysitters) {
            std::cout << "Babysitter ID: " << babysitter.id 
                      << ", Name: " << babysitter.name 
                      << ", Age: " << babysitter.age << std::endl;
        }
    }
};

int main() {
    NurseryManagementSystem system;

    system.addChild(1, "Alice", 4);
    system.addBabysitter(1, "John", 30);
    system.displayChildren();
    system.displayBabysitters();

    system.updateChild(1, "Alicia", 5);
    system.updateBabysitter(1, "Jon", 31);
    system.displayChildren();
    system.displayBabysitters();

    Child* child = system.searchChild(1);
    if (child) {
        std::cout << "Found Child: " << child->name << std::endl;
    }

    Babysitter* babysitter = system.searchBabysitter(1);
    if (babysitter) {
        std::cout << "Found Babysitter: " << babysitter->name << std::endl;
    }

    system.deleteChild(1);
    system.deleteBabysitter(1);
    system.displayChildren();
    system.displayBabysitters();

    return 0;
}