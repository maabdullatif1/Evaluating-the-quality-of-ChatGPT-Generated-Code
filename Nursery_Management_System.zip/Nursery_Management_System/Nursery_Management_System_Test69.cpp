#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Person {
    string name;
    int age;
};

class NurserySystem {
public:
    void addChild() {
        Person child;
        cout << "Enter child's name: ";
        cin >> child.name;
        cout << "Enter child's age: ";
        cin >> child.age;
        children.push_back(child);
    }

    void deleteChild() {
        string name;
        cout << "Enter child's name to delete: ";
        cin >> name;
        
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->name == name) {
                children.erase(it);
                cout << "Child removed.\n";
                return;
            }
        }
        cout << "Child not found.\n";
    }

    void updateChild() {
        string name;
        cout << "Enter child's name to update: ";
        cin >> name;
        
        for (auto& child : children) {
            if (child.name == name) {
                cout << "Enter new age: ";
                cin >> child.age;
                cout << "Child's information updated.\n";
                return;
            }
        }
        cout << "Child not found.\n";
    }

    void searchChild() {
        string name;
        cout << "Enter child's name to search: ";
        cin >> name;
        
        for (const auto& child : children) {
            if (child.name == name) {
                cout << "Child found: " << child.name << ", Age: " << child.age << endl;
                return;
            }
        }
        cout << "Child not found.\n";
    }

    void displayChildren() {
        if (children.empty()) {
            cout << "No children in the system.\n";
            return;
        }
        cout << "Children in the system:\n";
        for (const auto& child : children) {
            cout << "Name: " << child.name << ", Age: " << child.age << endl;
        }
    }

    void addBabysitter() {
        Person babysitter;
        cout << "Enter babysitter's name: ";
        cin >> babysitter.name;
        cout << "Enter babysitter's age: ";
        cin >> babysitter.age;
        babysitters.push_back(babysitter);
    }

    void deleteBabysitter() {
        string name;
        cout << "Enter babysitter's name to delete: ";
        cin >> name;
        
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->name == name) {
                babysitters.erase(it);
                cout << "Babysitter removed.\n";
                return;
            }
        }
        cout << "Babysitter not found.\n";
    }

    void updateBabysitter() {
        string name;
        cout << "Enter babysitter's name to update: ";
        cin >> name;
        
        for (auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                cout << "Enter new age: ";
                cin >> babysitter.age;
                cout << "Babysitter's information updated.\n";
                return;
            }
        }
        cout << "Babysitter not found.\n";
    }

    void searchBabysitter() {
        string name;
        cout << "Enter babysitter's name to search: ";
        cin >> name;
        
        for (const auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                cout << "Babysitter found: " << babysitter.name << ", Age: " << babysitter.age << endl;
                return;
            }
        }
        cout << "Babysitter not found.\n";
    }

    void displayBabysitters() {
        if (babysitters.empty()) {
            cout << "No babysitters in the system.\n";
            return;
        }
        cout << "Babysitters in the system:\n";
        for (const auto& babysitter : babysitters) {
            cout << "Name: " << babysitter.name << ", Age: " << babysitter.age << endl;
        }
    }

private:
    vector<Person> children;
    vector<Person> babysitters;
};

int main() {
    NurserySystem system;
    int choice;
    while (true) {
        cout << "Nursery Management System\n";
        cout << "1. Add Child\n";
        cout << "2. Delete Child\n";
        cout << "3. Update Child\n";
        cout << "4. Search Child\n";
        cout << "5. Display Children\n";
        cout << "6. Add Babysitter\n";
        cout << "7. Delete Babysitter\n";
        cout << "8. Update Babysitter\n";
        cout << "9. Search Babysitter\n";
        cout << "10. Display Babysitters\n";
        cout << "11. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        
        switch(choice) {
            case 1: system.addChild(); break;
            case 2: system.deleteChild(); break;
            case 3: system.updateChild(); break;
            case 4: system.searchChild(); break;
            case 5: system.displayChildren(); break;
            case 6: system.addBabysitter(); break;
            case 7: system.deleteBabysitter(); break;
            case 8: system.updateBabysitter(); break;
            case 9: system.searchBabysitter(); break;
            case 10: system.displayBabysitters(); break;
            case 11: return 0;
            default: cout << "Invalid choice, please try again.\n";
        }
    }
    return 0;
}