#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;
    Person(std::string name, int age) : name(name), age(age) {}
};

class Child : public Person {
public:
    Child(std::string name, int age) : Person(name, age) {}
};

class Babysitter : public Person {
public:
    Babysitter(std::string name, int age) : Person(name, age) {}
};

class NurseryManagementSystem {
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

public:
    void addChild(std::string name, int age) {
        children.push_back(Child(name, age));
    }

    void addBabysitter(std::string name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteChild(std::string name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->name == name) {
                children.erase(it);
                break;
            }
        }
    }

    void deleteBabysitter(std::string name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->name == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateChild(std::string name, std::string newName, int newAge) {
        for (auto& child : children) {
            if (child.name == name) {
                child.name = newName;
                child.age = newAge;
                break;
            }
        }
    }

    void updateBabysitter(std::string name, std::string newName, int newAge) {
        for (auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                babysitter.name = newName;
                babysitter.age = newAge;
                break;
            }
        }
    }

    bool searchChild(std::string name) {
        for (const auto& child : children) {
            if (child.name == name) {
                return true;
            }
        }
        return false;
    }

    bool searchBabysitter(std::string name) {
        for (const auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                return true;
            }
        }
        return false;
    }

    void displayChildren() {
        for (const auto& child : children) {
            std::cout << "Child Name: " << child.name << ", Age: " << child.age << std::endl;
        }
    }

    void displayBabysitters() {
        for (const auto& babysitter : babysitters) {
            std::cout << "Babysitter Name: " << babysitter.name << ", Age: " << babysitter.age << std::endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 5);
    nms.addChild("Bob", 4);
    nms.addBabysitter("Clara", 30);
    nms.addBabysitter("Dave", 25);

    std::cout << "\nChildren:" << std::endl;
    nms.displayChildren();
    std::cout << "\nBabysitters:" << std::endl;
    nms.displayBabysitters();

    std::cout << "\nUpdating Bob's information..." << std::endl;
    nms.updateChild("Bob", "Bobby", 6);
    nms.displayChildren();

    std::cout << "\nSearching for Clara: ";
    std::cout << (nms.searchBabysitter("Clara") ? "Found" : "Not Found") << std::endl;

    std::cout << "\nDeleting Alice's record..." << std::endl;
    nms.deleteChild("Alice");
    nms.displayChildren();

    return 0;
}