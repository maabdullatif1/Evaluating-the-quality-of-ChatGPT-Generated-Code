#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Person {
    string name;
    int age;
    string id;
};

class NurseryManagement {
    vector<Person> children;
    vector<Person> babysitters;

    public:
    void addPerson(vector<Person>& list, const string& name, int age, const string& id) {
        list.push_back({name, age, id});
    }

    void deletePerson(vector<Person>& list, const string& id) {
        for (auto it = list.begin(); it != list.end(); ++it) {
            if (it->id == id) {
                list.erase(it);
                return;
            }
        }
    }

    void updatePerson(vector<Person>& list, const string& id, const string& newName, int newAge) {
        for (auto& person : list) {
            if (person.id == id) {
                person.name = newName;
                person.age = newAge;
            }
        }
    }

    Person* searchPerson(vector<Person>& list, const string& id) {
        for (auto& person : list) {
            if (person.id == id) {
                return &person;
            }
        }
        return nullptr;
    }

    void displayList(const vector<Person>& list) {
        for (const auto& person : list) {
            cout << "ID: " << person.id << ", Name: " << person.name << ", Age: " << person.age << endl;
        }
    }

    void addChild(const string& name, int age, const string& id) {
        addPerson(children, name, age, id);
    }

    void deleteChild(const string& id) {
        deletePerson(children, id);
    }

    void updateChild(const string& id, const string& newName, int newAge) {
        updatePerson(children, id, newName, newAge);
    }

    Person* searchChild(const string& id) {
        return searchPerson(children, id);
    }

    void displayChildren() {
        displayList(children);
    }

    void addBabysitter(const string& name, int age, const string& id) {
        addPerson(babysitters, name, age, id);
    }

    void deleteBabysitter(const string& id) {
        deletePerson(babysitters, id);
    }

    void updateBabysitter(const string& id, const string& newName, int newAge) {
        updatePerson(babysitters, id, newName, newAge);
    }

    Person* searchBabysitter(const string& id) {
        return searchPerson(babysitters, id);
    }

    void displayBabysitters() {
        displayList(babysitters);
    }
};

int main() {
    NurseryManagement nm;
    nm.addChild("Alice", 5, "C001");
    nm.addChild("Bob", 4, "C002");
    nm.addBabysitter("Maria", 30, "B001");
    nm.addBabysitter("John", 28, "B002");

    cout << "Children:" << endl;
    nm.displayChildren();

    cout << endl << "Babysitters:" << endl;
    nm.displayBabysitters();

    nm.updateChild("C001", "Alicia", 6);
    nm.deleteBabysitter("B001");

    cout << endl << "Updated Children:" << endl;
    nm.displayChildren();

    cout << endl << "Updated Babysitters:" << endl;
    nm.displayBabysitters();

    return 0;
}