#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    int age;
    string id;
};

class NurseryManagementSystem {
    vector<Person> children;
    vector<Person> babysitters;

public:
    void addPerson(vector<Person>& people, const string& name, int age, const string& id) {
        people.push_back({name, age, id});
    }

    void deletePerson(vector<Person>& people, const string& id) {
        for (auto it = people.begin(); it != people.end(); ++it) {
            if (it->id == id) {
                people.erase(it);
                break;
            }
        }
    }

    void updatePerson(vector<Person>& people, const string& id, const string& name, int age) {
        for (auto& person : people) {
            if (person.id == id) {
                person.name = name;
                person.age = age;
                break;
            }
        }
    }

    Person* searchPerson(vector<Person>& people, const string& id) {
        for (auto& person : people) {
            if (person.id == id) {
                return &person;
            }
        }
        return nullptr;
    }

    void displayPeople(const vector<Person>& people) {
        for (const auto& person : people) {
            cout << "Name: " << person.name << ", Age: " << person.age << ", ID: " << person.id << endl;
        }
    }

    void addChild(const string& name, int age, const string& id) {
        addPerson(children, name, age, id);
    }

    void deleteChild(const string& id) {
        deletePerson(children, id);
    }

    void updateChild(const string& id, const string& name, int age) {
        updatePerson(children, id, name, age);
    }

    Person* searchChild(const string& id) {
        return searchPerson(children, id);
    }

    void displayChildren() {
        displayPeople(children);
    }

    void addBabysitter(const string& name, int age, const string& id) {
        addPerson(babysitters, name, age, id);
    }

    void deleteBabysitter(const string& id) {
        deletePerson(babysitters, id);
    }

    void updateBabysitter(const string& id, const string& name, int age) {
        updatePerson(babysitters, id, name, age);
    }

    Person* searchBabysitter(const string& id) {
        return searchPerson(babysitters, id);
    }

    void displayBabysitters() {
        displayPeople(babysitters);
    }
};

int main() {
    NurseryManagementSystem system;

    system.addChild("Alice", 4, "C001");
    system.addChild("Bob", 5, "C002");
    system.addBabysitter("Nancy", 25, "B001");
    system.addBabysitter("John", 30, "B002");

    cout << "Children:" << endl;
    system.displayChildren();

    cout << "Babysitters:" << endl;
    system.displayBabysitters();

    system.updateChild("C001", "Alice Smith", 4);
    Person* child = system.searchChild("C001");
    if (child) {
        cout << "Updated Child Info: " << child->name << ", " << child->age << endl;
    }

    system.deleteBabysitter("B001");
    cout << "Babysitters after deletion:" << endl;
    system.displayBabysitters();

    return 0;
}