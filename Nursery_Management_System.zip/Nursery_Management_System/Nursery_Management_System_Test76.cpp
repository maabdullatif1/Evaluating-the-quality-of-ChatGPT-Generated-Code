#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Child {
    int id;
    string name;
    int age;
};

struct Babysitter {
    int id;
    string name;
    string phoneNumber;
};

class NurseryManagementSystem {
private:
    vector<Child> children;
    vector<Babysitter> babysitters;
    int childIDCounter = 1;
    int babysitterIDCounter = 1;

public:
    void addChild(const string& name, int age) {
        children.push_back({childIDCounter++, name, age});
    }

    void deleteChild(int id) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->id == id) {
                children.erase(it);
                return;
            }
        }
    }

    void updateChild(int id, const string& name, int age) {
        for (auto& child : children) {
            if (child.id == id) {
                child.name = name;
                child.age = age;
                return;
            }
        }
    }

    void searchChild(int id) const {
        for (const auto& child : children) {
            if (child.id == id) {
                cout << "Child ID: " << child.id << ", Name: " << child.name << ", Age: " << child.age << endl;
                return;
            }
        }
        cout << "Child not found" << endl;
    }

    void displayChildren() const {
        for (const auto& child : children) {
            cout << "Child ID: " << child.id << ", Name: " << child.name << ", Age: " << child.age << endl;
        }
    }

    void addBabysitter(const string& name, const string& phoneNumber) {
        babysitters.push_back({babysitterIDCounter++, name, phoneNumber});
    }

    void deleteBabysitter(int id) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->id == id) {
                babysitters.erase(it);
                return;
            }
        }
    }

    void updateBabysitter(int id, const string& name, const string& phoneNumber) {
        for (auto& babysitter : babysitters) {
            if (babysitter.id == id) {
                babysitter.name = name;
                babysitter.phoneNumber = phoneNumber;
                return;
            }
        }
    }

    void searchBabysitter(int id) const {
        for (const auto& babysitter : babysitters) {
            if (babysitter.id == id) {
                cout << "Babysitter ID: " << babysitter.id << ", Name: " << babysitter.name << ", Phone: " << babysitter.phoneNumber << endl;
                return;
            }
        }
        cout << "Babysitter not found" << endl;
    }

    void displayBabysitters() const {
        for (const auto& babysitter : babysitters) {
            cout << "Babysitter ID: " << babysitter.id << ", Name: " << babysitter.name << ", Phone: " << babysitter.phoneNumber << endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    
    nms.addChild("Alice", 5);
    nms.addChild("Bob", 6);
    nms.displayChildren();
    
    nms.addBabysitter("Emma", "123-456-7890");
    nms.addBabysitter("Liam", "098-765-4321");
    nms.displayBabysitters();
    
    nms.searchChild(1);
    nms.updateChild(2, "Bobby", 7);
    nms.displayChildren();

    nms.searchBabysitter(1);
    nms.updateBabysitter(2, "William", "987-654-3210");
    nms.displayBabysitters();

    nms.deleteChild(1);
    nms.displayChildren();

    nms.deleteBabysitter(1);
    nms.displayBabysitters();

    return 0;
}