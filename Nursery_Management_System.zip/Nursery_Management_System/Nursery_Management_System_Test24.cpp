#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Person {
protected:
    string name;
    int age;
public:
    Person(string n, int a) : name(n), age(a) {}
    virtual string getInfo() {
        return "Name: " + name + ", Age: " + to_string(age);
    }
    string getName() { return name; }
    void setName(string n) { name = n; }
    int getAge() { return age; }
    void setAge(int a) { age = a; }
};

class Child : public Person {
public:
    Child(string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(string n, int a) : Person(n, a) {}
};

class Nursery {
    vector<Child> children;
    vector<Babysitter> babysitters;
public:
    void addChild(string name, int age) {
        children.push_back(Child(name, age));
    }

    void addBabysitter(string name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteChild(string name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->getName() == name) {
                children.erase(it);
                break;
            }
        }
    }

    void deleteBabysitter(string name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->getName() == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateChild(string name, int age) {
        for (auto &child : children) {
            if (child.getName() == name) {
                child.setAge(age);
                break;
            }
        }
    }

    void updateBabysitter(string name, int age) {
        for (auto &babysitter : babysitters) {
            if (babysitter.getName() == name) {
                babysitter.setAge(age);
                break;
            }
        }
    }

    void searchChild(string name) {
        for (auto &child : children) {
            if (child.getName() == name) {
                cout << child.getInfo() << endl;
                return;
            }
        }
        cout << "Child not found." << endl;
    }

    void searchBabysitter(string name) {
        for (auto &babysitter : babysitters) {
            if (babysitter.getName() == name) {
                cout << babysitter.getInfo() << endl;
                return;
            }
        }
        cout << "Babysitter not found." << endl;
    }

    void displayChildren() {
        for (auto &child : children) {
            cout << child.getInfo() << endl;
        }
    }

    void displayBabysitters() {
        for (auto &babysitter : babysitters) {
            cout << babysitter.getInfo() << endl;
        }
    }
};

int main() {
    Nursery nursery;
    nursery.addChild("Alice", 5);
    nursery.addBabysitter("Olivia", 25);
    
    nursery.displayChildren();
    nursery.displayBabysitters();

    nursery.updateChild("Alice", 6);
    nursery.updateBabysitter("Olivia", 26);

    nursery.displayChildren();
    nursery.displayBabysitters();

    nursery.searchChild("Alice");
    nursery.searchBabysitter("Olivia");

    nursery.deleteChild("Alice");
    nursery.deleteBabysitter("Olivia");

    nursery.displayChildren();
    nursery.displayBabysitters();

    return 0;
}