#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int age;

public:
    Person(std::string n, int a) : name(n), age(a) {}

    virtual void display() const = 0;
    virtual std::string getName() const { return name; }
    virtual int getAge() const { return age; }
    virtual void update(std::string n, int a) {
        name = n;
        age = a;
    }
};

class Child : public Person {
public:
    Child(std::string n, int a) : Person(n, a) {}

    void display() const override {
        std::cout << "Child Name: " << name << ", Age: " << age << std::endl;
    }
};

class Babysitter : public Person {
public:
    Babysitter(std::string n, int a) : Person(n, a) {}

    void display() const override {
        std::cout << "Babysitter Name: " << name << ", Age: " << age << std::endl;
    }
};

template<typename T>
class NurseryManagementSystem {
    std::vector<T> list;

public:
    void add(const T& person) {
        list.push_back(person);
    }

    void remove(const std::string& name) {
        for (auto it = list.begin(); it != list.end(); ++it) {
            if (it->getName() == name) {
                list.erase(it);
                break;
            }
        }
    }

    void update(const std::string& name, const std::string& newName, int newAge) {
        for (auto& person : list) {
            if (person.getName() == name) {
                person.update(newName, newAge);
                break;
            }
        }
    }

    void search(const std::string& name) const {
        for (const auto& person : list) {
            if (person.getName() == name) {
                person.display();
                return;
            }
        }
        std::cout << "Person not found" << std::endl;
    }

    void displayAll() const {
        for (const auto& person : list) {
            person.display();
        }
    }
};

int main() {
    NurseryManagementSystem<Child> childrenSystem;
    NurseryManagementSystem<Babysitter> babysitterSystem;

    childrenSystem.add(Child("Alice", 5));
    childrenSystem.add(Child("Bob", 4));
    babysitterSystem.add(Babysitter("Mary", 23));
    babysitterSystem.add(Babysitter("John", 30));

    std::cout << "Displaying all children:" << std::endl;
    childrenSystem.displayAll();

    std::cout << "\nDisplaying all babysitters:" << std::endl;
    babysitterSystem.displayAll();

    std::cout << "\nSearching for Bob:" << std::endl;
    childrenSystem.search("Bob");

    std::cout << "\nUpdating Bob's information:" << std::endl;
    childrenSystem.update("Bob", "Bobby", 6);

    std::cout << "\nRemoving Mary:" << std::endl;
    babysitterSystem.remove("Mary");

    std::cout << "\nDisplaying all children:" << std::endl;
    childrenSystem.displayAll();

    std::cout << "\nDisplaying all babysitters:" << std::endl;
    babysitterSystem.displayAll();

    return 0;
}