#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string id;
    string name;
    int age;
};

struct Child : Person {
    string parentName;
};

struct Babysitter : Person {
    int experience;
};

class NurseryManagementSystem {
private:
    vector<Child> children;
    vector<Babysitter> babysitters;

    template <typename T>
    T* find(vector<T>& list, const string& id) {
        for (auto& item : list) {
            if (item.id == id) return &item;
        }
        return nullptr;
    }

public:
    void addChild(const string& id, const string& name, int age, const string& parentName) {
        children.push_back({id, name, age, parentName});
    }
    
    void addBabysitter(const string& id, const string& name, int age, int experience) {
        babysitters.push_back({id, name, age, experience});
    }
    
    bool deleteChild(const string& id) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->id == id) {
                children.erase(it);
                return true;
            }
        }
        return false;
    }
    
    bool deleteBabysitter(const string& id) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->id == id) {
                babysitters.erase(it);
                return true;
            }
        }
        return false;
    }
    
    bool updateChild(const string& id, const string& name, int age, const string& parentName) {
        Child* child = find(children, id);
        if (child) {
            child->name = name;
            child->age = age;
            child->parentName = parentName;
            return true;
        }
        return false;
    }
    
    bool updateBabysitter(const string& id, const string& name, int age, int experience) {
        Babysitter* babysitter = find(babysitters, id);
        if (babysitter) {
            babysitter->name = name;
            babysitter->age = age;
            babysitter->experience = experience;
            return true;
        }
        return false;
    }
    
    void searchChild(const string& id) {
        Child* child = find(children, id);
        if (child) {
            cout << "Child Found: " << child->name << ", Age: " << child->age << ", Parent: " << child->parentName << endl;
        } else {
            cout << "Child not found." << endl;
        }
    }
    
    void searchBabysitter(const string& id) {
        Babysitter* babysitter = find(babysitters, id);
        if (babysitter) {
            cout << "Babysitter Found: " << babysitter->name << ", Age: " << babysitter->age << ", Experience: " << babysitter->experience << " years" << endl;
        } else {
            cout << "Babysitter not found." << endl;
        }
    }

    void displayChildren() {
        cout << "Children List:" << endl;
        for (auto& child : children) {
            cout << "ID: " << child.id << ", Name: " << child.name << ", Age: " << child.age << ", Parent: " << child.parentName << endl;
        }
    }
    
    void displayBabysitters() {
        cout << "Babysitters List:" << endl;
        for (auto& babysitter : babysitters) {
            cout << "ID: " << babysitter.id << ", Name: " << babysitter.name << ", Age: " << babysitter.age << ", Experience: " << babysitter.experience << " years" << endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;

    nms.addChild("C001", "Alice", 5, "Mary");
    nms.addChild("C002", "Bob", 3, "John");
    nms.addBabysitter("B001", "Eve", 30, 5);
    nms.addBabysitter("B002", "Sophia", 25, 3);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.searchChild("C002");
    nms.searchBabysitter("B001");

    nms.updateChild("C001", "Alicia", 6, "Mary Johnson");
    nms.updateBabysitter("B002", "Sophia Lee", 26, 4);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.deleteChild("C002");
    nms.deleteBabysitter("B001");

    nms.displayChildren();
    nms.displayBabysitters();

    return 0;
}