#include <iostream>
#include <vector>
#include <string>

struct Person {
    std::string name;
    int age;
    std::string id;
};

class Nursery {
    std::vector<Person> children;
    std::vector<Person> babysitters;

    void displayPerson(const Person& person) {
        std::cout << "ID: " << person.id << ", Name: " << person.name << ", Age: " << person.age << std::endl;
    }

    Person createPerson() {
        Person p;
        std::cout << "Enter ID: ";
        std::cin >> p.id;
        std::cout << "Enter Name: ";
        std::cin >> p.name;
        std::cout << "Enter Age: ";
        std::cin >> p.age;
        return p;
    }

    std::vector<Person>::iterator findPerson(std::vector<Person>& list, const std::string& id) {
        for(auto it = list.begin(); it != list.end(); ++it) {
            if (it->id == id) return it;
        }
        return list.end();
    }

public:
    void addChild() {
        children.push_back(createPerson());
    }

    void deleteChild() {
        std::string id;
        std::cout << "Enter child ID to delete: ";
        std::cin >> id;
        auto it = findPerson(children, id);
        if (it != children.end()) children.erase(it);
    }

    void updateChild() {
        std::string id;
        std::cout << "Enter child ID to update: ";
        std::cin >> id;
        auto it = findPerson(children, id);
        if (it != children.end()) *it = createPerson();
    }

    void searchChild() {
        std::string id;
        std::cout << "Enter child ID to search: ";
        std::cin >> id;
        auto it = findPerson(children, id);
        if (it != children.end()) displayPerson(*it);
    }

    void displayAllChildren() {
        for (const auto& child : children) displayPerson(child);
    }

    void addBabysitter() {
        babysitters.push_back(createPerson());
    }

    void deleteBabysitter() {
        std::string id;
        std::cout << "Enter babysitter ID to delete: ";
        std::cin >> id;
        auto it = findPerson(babysitters, id);
        if (it != babysitters.end()) babysitters.erase(it);
    }

    void updateBabysitter() {
        std::string id;
        std::cout << "Enter babysitter ID to update: ";
        std::cin >> id;
        auto it = findPerson(babysitters, id);
        if (it != babysitters.end()) *it = createPerson();
    }

    void searchBabysitter() {
        std::string id;
        std::cout << "Enter babysitter ID to search: ";
        std::cin >> id;
        auto it = findPerson(babysitters, id);
        if (it != babysitters.end()) displayPerson(*it);
    }

    void displayAllBabysitters() {
        for (const auto& babysitter : babysitters) displayPerson(babysitter);
    }
};

int main() {
    Nursery nursery;
    int choice;
    do {
        std::cout << "\nNursery Management System\n";
        std::cout << "1. Add Child\n2. Delete Child\n3. Update Child\n4. Search Child\n5. Display All Children\n";
        std::cout << "6. Add Babysitter\n7. Delete Babysitter\n8. Update Babysitter\n9. Search Babysitter\n10. Display All Babysitters\n";
        std::cout << "0. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;
        
        switch (choice) {
            case 1: nursery.addChild(); break;
            case 2: nursery.deleteChild(); break;
            case 3: nursery.updateChild(); break;
            case 4: nursery.searchChild(); break;
            case 5: nursery.displayAllChildren(); break;
            case 6: nursery.addBabysitter(); break;
            case 7: nursery.deleteBabysitter(); break;
            case 8: nursery.updateBabysitter(); break;
            case 9: nursery.searchBabysitter(); break;
            case 10: nursery.displayAllBabysitters(); break;
        }
    } while (choice != 0);

    return 0;
}