#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    int age;
    string id;
};

class NurseryManagement {
    vector<Person> children;
    vector<Person> babysitters;

    void addPerson(vector<Person>& list, const string& name, int age, const string& id) {
        list.push_back({name, age, id});
    }

    bool deletePerson(vector<Person>& list, const string& id) {
        for (auto it = list.begin(); it != list.end(); ++it) {
            if (it->id == id) {
                list.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updatePerson(vector<Person>& list, const string& id, const string& newName, int newAge) {
        for (auto& person : list) {
            if (person.id == id) {
                person.name = newName;
                person.age = newAge;
                return true;
            }
        }
        return false;
    }

    Person* searchPerson(vector<Person>& list, const string& id) {
        for (auto& person : list) {
            if (person.id == id) {
                return &person;
            }
        }
        return nullptr;
    }

    void displayList(const vector<Person>& list) {
        for (const auto& person : list) {
            cout << "Name: " << person.name << ", Age: " << person.age << ", ID: " << person.id << endl;
        }
    }

public:
    void addChild(const string& name, int age, const string& id) {
        addPerson(children, name, age, id);
    }

    void addBabysitter(const string& name, int age, const string& id) {
        addPerson(babysitters, name, age, id);
    }

    void deleteChild(const string& id) {
        if (!deletePerson(children, id)) {
            cout << "Child not found." << endl;
        }
    }

    void deleteBabysitter(const string& id) {
        if (!deletePerson(babysitters, id)) {
            cout << "Babysitter not found." << endl;
        }
    }

    void updateChild(const string& id, const string& newName, int newAge) {
        if (!updatePerson(children, id, newName, newAge)) {
            cout << "Child not found." << endl;
        }
    }

    void updateBabysitter(const string& id, const string& newName, int newAge) {
        if (!updatePerson(babysitters, id, newName, newAge)) {
            cout << "Babysitter not found." << endl;
        }
    }

    void searchChild(const string& id) {
        Person* person = searchPerson(children, id);
        if (person) {
            cout << "Child Found - Name: " << person->name << ", Age: " << person->age << ", ID: " << person->id << endl;
        } else {
            cout << "Child not found." << endl;
        }
    }

    void searchBabysitter(const string& id) {
        Person* person = searchPerson(babysitters, id);
        if (person) {
            cout << "Babysitter Found - Name: " << person->name << ", Age: " << person->age << ", ID: " << person->id << endl;
        } else {
            cout << "Babysitter not found." << endl;
        }
    }

    void displayChildren() {
        cout << "Children:" << endl;
        displayList(children);
    }

    void displayBabysitters() {
        cout << "Babysitters:" << endl;
        displayList(babysitters);
    }
};

int main() {
    NurseryManagement nm;
    nm.addChild("Alice", 5, "C01");
    nm.addChild("Bob", 4, "C02");
    nm.addBabysitter("Eve", 30, "B01");
    nm.addBabysitter("John", 25, "B02");

    nm.displayChildren();
    nm.displayBabysitters();

    nm.updateChild("C01", "Alice Updated", 6);
    nm.updateBabysitter("B01", "Eve Updated", 31);

    nm.searchChild("C01");
    nm.searchBabysitter("B01");

    nm.deleteChild("C02");
    nm.deleteBabysitter("B02");

    nm.displayChildren();
    nm.displayBabysitters();

    return 0;
}