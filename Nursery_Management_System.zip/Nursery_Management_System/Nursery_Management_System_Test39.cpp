#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;
    Person(const std::string& name, int age) : name(name), age(age) {}
};

class Child : public Person {
public:
    Child(const std::string& name, int age) : Person(name, age) {}
};

class Babysitter : public Person {
public:
    Babysitter(const std::string& name, int age) : Person(name, age) {}
};

class NurseryManagementSystem {
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

    template<typename T>
    int findPersonIndex(const std::vector<T>& persons, const std::string& name) {
        for (size_t i = 0; i < persons.size(); ++i) {
            if (persons[i].name == name) return i;
        }
        return -1;
    }

public:
    void addChild(const std::string& name, int age) {
        children.emplace_back(name, age);
    }

    void addBabysitter(const std::string& name, int age) {
        babysitters.emplace_back(name, age);
    }

    void deleteChild(const std::string& name) {
        int index = findPersonIndex(children, name);
        if (index != -1) children.erase(children.begin() + index);
    }

    void deleteBabysitter(const std::string& name) {
        int index = findPersonIndex(babysitters, name);
        if (index != -1) babysitters.erase(babysitters.begin() + index);
    }

    void updateChild(const std::string& name, const std::string& newName, int newAge) {
        int index = findPersonIndex(children, name);
        if (index != -1) {
            children[index].name = newName;
            children[index].age = newAge;
        }
    }

    void updateBabysitter(const std::string& name, const std::string& newName, int newAge) {
        int index = findPersonIndex(babysitters, name);
        if (index != -1) {
            babysitters[index].name = newName;
            babysitters[index].age = newAge;
        }
    }

    void searchChild(const std::string& name) {
        int index = findPersonIndex(children, name);
        if (index != -1)
            std::cout << "Child found: " << children[index].name << ", Age: " << children[index].age << "\n";
        else
            std::cout << "Child not found\n";
    }

    void searchBabysitter(const std::string& name) {
        int index = findPersonIndex(babysitters, name);
        if (index != -1)
            std::cout << "Babysitter found: " << babysitters[index].name << ", Age: " << babysitters[index].age << "\n";
        else
            std::cout << "Babysitter not found\n";
    }

    void displayChildren() {
        std::cout << "Children:\n";
        for (const auto& child : children) {
            std::cout << child.name << ", Age: " << child.age << "\n";
        }
    }

    void displayBabysitters() {
        std::cout << "Babysitters:\n";
        for (const auto& babysitter : babysitters) {
            std::cout << babysitter.name << ", Age: " << babysitter.age << "\n";
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 4);
    nms.addChild("Bob", 3);
    nms.addBabysitter("Mary", 25);
    nms.addBabysitter("John", 30);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.searchChild("Alice");
    nms.searchBabysitter("John");

    nms.updateChild("Alice", "Alicia", 5);
    nms.updateBabysitter("John", "Johnny", 31);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.deleteChild("Bob");
    nms.deleteBabysitter("Mary");

    nms.displayChildren();
    nms.displayBabysitters();

    return 0;
}