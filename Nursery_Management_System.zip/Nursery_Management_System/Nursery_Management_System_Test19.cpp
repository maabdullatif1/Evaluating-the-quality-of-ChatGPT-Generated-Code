#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    int age;
};

class NurseryManagement {
private:
    vector<Person> children;
    vector<Person> babysitters;

    void displayPerson(const Person& person) const {
        cout << "Name: " << person.name << ", Age: " << person.age << endl;
    }

    int findPerson(const vector<Person>& list, const string& name) const {
        for (int i = 0; i < list.size(); ++i) {
            if (list[i].name == name) {
                return i;
            }
        }
        return -1;
    }

    void addPerson(vector<Person>& list, const string& name, int age) {
        list.push_back({name, age});
    }

    bool deletePerson(vector<Person>& list, const string& name) {
        int index = findPerson(list, name);
        if (index != -1) {
            list.erase(list.begin() + index);
            return true;
        }
        return false;
    }

    bool updatePerson(vector<Person>& list, const string& name, int newAge) {
        int index = findPerson(list, name);
        if (index != -1) {
            list[index].age = newAge;
            return true;
        }
        return false;
    }

    void displayList(const vector<Person>& list) const {
        for (const auto& person : list) {
            displayPerson(person);
        }
    }

public:
    void addChild(const string& name, int age) {
        addPerson(children, name, age);
    }

    bool deleteChild(const string& name) {
        return deletePerson(children, name);
    }

    bool updateChild(const string& name, int newAge) {
        return updatePerson(children, name, newAge);
    }

    void searchChild(const string& name) const {
        int index = findPerson(children, name);
        if (index != -1) {
            displayPerson(children[index]);
        } else {
            cout << "Child not found." << endl;
        }
    }

    void displayChildren() const {
        cout << "Children:" << endl;
        displayList(children);
    }

    void addBabysitter(const string& name, int age) {
        addPerson(babysitters, name, age);
    }

    bool deleteBabysitter(const string& name) {
        return deletePerson(babysitters, name);
    }

    bool updateBabysitter(const string& name, int newAge) {
        return updatePerson(babysitters, name, newAge);
    }

    void searchBabysitter(const string& name) const {
        int index = findPerson(babysitters, name);
        if (index != -1) {
            displayPerson(babysitters[index]);
        } else {
            cout << "Babysitter not found." << endl;
        }
    }

    void displayBabysitters() const {
        cout << "Babysitters:" << endl;
        displayList(babysitters);
    }
};

int main() {
    NurseryManagement nm;
    nm.addChild("Alice", 3);
    nm.addBabysitter("Bob", 25);

    nm.displayChildren();
    nm.displayBabysitters();

    nm.updateChild("Alice", 4);
    nm.searchChild("Alice");

    nm.deleteBabysitter("Bob");
    nm.displayBabysitters();

    return 0;
}