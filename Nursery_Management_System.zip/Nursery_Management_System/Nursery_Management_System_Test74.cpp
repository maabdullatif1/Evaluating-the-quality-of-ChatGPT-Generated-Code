#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int age;
public:
    Person(std::string n, int a) : name(n), age(a) {}
    std::string getName() const { return name; }
    int getAge() const { return age; }
    virtual void display() const = 0;
};

class Child : public Person {
public:
    Child(std::string n, int a) : Person(n, a) {}
    void display() const override {
        std::cout << "Child - Name: " << name << ", Age: " << age << std::endl;
    }
};

class Babysitter : public Person {
public:
    int experience;
    Babysitter(std::string n, int a, int e) : Person(n, a), experience(e) {}
    void display() const override {
        std::cout << "Babysitter - Name: " << name << ", Age: " << age << ", Experience: " << experience << " years" << std::endl;
    }
};

template <typename T>
class ManagementSystem {
private:
    std::vector<T> records;
public:
    void addRecord(const T& record) {
        records.push_back(record);
    }
    
    void deleteRecord(const std::string& name) {
        for (auto it = records.begin(); it != records.end(); ++it) {
            if (it->getName() == name) {
                records.erase(it);
                break;
            }
        }
    }

    void updateRecord(const std::string& name, const T& newRecord) {
        for (auto& record : records) {
            if (record.getName() == name) {
                record = newRecord;
                break;
            }
        }
    }
    
    T* searchRecord(const std::string& name) {
        for (auto& record : records) {
            if (record.getName() == name) {
                return &record;
            }
        }
        return nullptr;
    }
    
    void displayRecords() const {
        for (const auto& record : records) {
            record.display();
        }
    }
};

int main() {
    ManagementSystem<Child> childManager;
    ManagementSystem<Babysitter> babysitterManager;
    
    childManager.addRecord(Child("Alice", 3));
    childManager.addRecord(Child("Bob", 5));
    
    babysitterManager.addRecord(Babysitter("John", 25, 2));
    babysitterManager.addRecord(Babysitter("Jane", 30, 5));
    
    std::cout << "Children Records:" << std::endl;
    childManager.displayRecords();
    
    std::cout << "\nBabysitter Records:" << std::endl;
    babysitterManager.displayRecords();
    
    Child* foundChild = childManager.searchRecord("Alice");
    if (foundChild) foundChild->display();
    
    babysitterManager.updateRecord("John", Babysitter("John", 26, 3));
    
    std::cout << "\nUpdated Babysitter Records:" << std::endl;
    babysitterManager.displayRecords();
    
    childManager.deleteRecord("Alice");
    std::cout << "\nChildren Records after deletion:" << std::endl;
    childManager.displayRecords();

    return 0;
}