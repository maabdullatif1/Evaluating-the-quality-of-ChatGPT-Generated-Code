#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    int age;
    string id;
};

class NurseryManagementSystem {
private:
    vector<Person> children;
    vector<Person> babysitters;

    Person* findPerson(vector<Person>& group, const string& id) {
        for (auto& person : group) {
            if (person.id == id) {
                return &person;
            }
        }
        return nullptr;
    }

    void displayPerson(const Person& person) {
        cout << "ID: " << person.id << ", Name: " << person.name << ", Age: " << person.age << endl;
    }

public:
    void addChild(const string& name, int age, const string& id) {
        children.push_back({name, age, id});
    }

    void addBabysitter(const string& name, int age, const string& id) {
        babysitters.push_back({name, age, id});
    }

    bool deleteChild(const string& id) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->id == id) {
                children.erase(it);
                return true;
            }
        }
        return false;
    }

    bool deleteBabysitter(const string& id) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->id == id) {
                babysitters.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateChild(const string& id, const string& name, int age) {
        Person* child = findPerson(children, id);
        if (child) {
            child->name = name;
            child->age = age;
            return true;
        }
        return false;
    }

    bool updateBabysitter(const string& id, const string& name, int age) {
        Person* babysitter = findPerson(babysitters, id);
        if (babysitter) {
            babysitter->name = name;
            babysitter->age = age;
            return true;
        }
        return false;
    }

    void searchChild(const string& id) {
        Person* child = findPerson(children, id);
        if (child) {
            displayPerson(*child);
        } else {
            cout << "Child not found." << endl;
        }
    }

    void searchBabysitter(const string& id) {
        Person* babysitter = findPerson(babysitters, id);
        if (babysitter) {
            displayPerson(*babysitter);
        } else {
            cout << "Babysitter not found." << endl;
        }
    }

    void displayChildren() {
        cout << "Children List:" << endl;
        for (const auto& child : children) {
            displayPerson(child);
        }
    }

    void displayBabysitters() {
        cout << "Babysitters List:" << endl;
        for (const auto& babysitter : babysitters) {
            displayPerson(babysitter);
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("John", 4, "C001");
    nms.addChild("Emma", 5, "C002");
    nms.addBabysitter("Alice", 25, "B001");
    nms.addBabysitter("Bob", 30, "B002");

    cout << "Initial Lists:" << endl;
    nms.displayChildren();
    nms.displayBabysitters();

    nms.updateChild("C001", "John Doe", 6);
    nms.deleteBabysitter("B002");
    
    cout << "\nUpdated Lists:" << endl;
    nms.displayChildren();
    nms.displayBabysitters();
    
    return 0;
}