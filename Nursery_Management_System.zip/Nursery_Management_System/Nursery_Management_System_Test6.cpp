#include <iostream>
#include <vector>
#include <string>

struct Child {
    int id;
    std::string name;
    int age;
};

struct Babysitter {
    int id;
    std::string name;
    int experience;
};

class NurseryManagementSystem {
private:
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;
    int childIDCounter = 0;
    int babysitterIDCounter = 0;

public:
    void addChild(const std::string& name, int age) {
        children.push_back({childIDCounter++, name, age});
    }

    void addBabysitter(const std::string& name, int experience) {
        babysitters.push_back({babysitterIDCounter++, name, experience});
    }

    bool deleteChild(int id) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->id == id) {
                children.erase(it);
                return true;
            }
        }
        return false;
    }

    bool deleteBabysitter(int id) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->id == id) {
                babysitters.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateChild(int id, const std::string& name, int age) {
        for (auto& child : children) {
            if (child.id == id) {
                child.name = name;
                child.age = age;
                return true;
            }
        }
        return false;
    }

    bool updateBabysitter(int id, const std::string& name, int experience) {
        for (auto& babysitter : babysitters) {
            if (babysitter.id == id) {
                babysitter.name = name;
                babysitter.experience = experience;
                return true;
            }
        }
        return false;
    }

    void searchChild(int id) const {
        for (const auto& child : children) {
            if (child.id == id) {
                std::cout << "Child Found: ID=" << child.id << ", Name=" << child.name << ", Age=" << child.age << "\n";
                return;
            }
        }
        std::cout << "Child Not Found\n";
    }

    void searchBabysitter(int id) const {
        for (const auto& babysitter : babysitters) {
            if (babysitter.id == id) {
                std::cout << "Babysitter Found: ID=" << babysitter.id << ", Name=" << babysitter.name << ", Experience=" << babysitter.experience << " years\n";
                return;
            }
        }
        std::cout << "Babysitter Not Found\n";
    }

    void displayAllChildren() const {
        std::cout << "Children List:\n";
        for (const auto& child : children) {
            std::cout << "ID=" << child.id << ", Name=" << child.name << ", Age=" << child.age << "\n";
        }
    }

    void displayAllBabysitters() const {
        std::cout << "Babysitters List:\n";
        for (const auto& babysitter : babysitters) {
            std::cout << "ID=" << babysitter.id << ", Name=" << babysitter.name << ", Experience=" << babysitter.experience << " years\n";
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("John", 4);
    nms.addChild("Lucy", 3);
    nms.addBabysitter("Alice", 5);
    nms.addBabysitter("Bob", 2);

    nms.displayAllChildren();
    nms.displayAllBabysitters();

    nms.searchChild(0);
    nms.searchBabysitter(1);

    nms.updateChild(0, "Johnny", 5);
    nms.updateBabysitter(1, "Bobby", 3);

    nms.displayAllChildren();
    nms.displayAllBabysitters();

    nms.deleteChild(1);
    nms.deleteBabysitter(0);

    nms.displayAllChildren();
    nms.displayAllBabysitters();

    return 0;
}