#include <iostream>
#include <string>
using namespace std;

struct Person {
    string id;
    string name;
    int age;
};

class NurseryManagement {
    Person children[100];
    Person babysitters[100];
    int childCount;
    int babysitterCount;

public:
    NurseryManagement() : childCount(0), babysitterCount(0) {}

    void addChild(const string& id, const string& name, int age) {
        if (childCount < 100) {
            children[childCount++] = {id, name, age};
        }
    }

    void addBabysitter(const string& id, const string& name, int age) {
        if (babysitterCount < 100) {
            babysitters[babysitterCount++] = {id, name, age};
        }
    }

    void deleteChild(const string& id) {
        for (int i = 0; i < childCount; ++i) {
            if (children[i].id == id) {
                children[i] = children[--childCount];
                break;
            }
        }
    }

    void deleteBabysitter(const string& id) {
        for (int i = 0; i < babysitterCount; ++i) {
            if (babysitters[i].id == id) {
                babysitters[i] = babysitters[--babysitterCount];
                break;
            }
        }
    }

    void updateChild(const string& id, const string& name, int age) {
        for (int i = 0; i < childCount; ++i) {
            if (children[i].id == id) {
                children[i] = {id, name, age};
                break;
            }
        }
    }

    void updateBabysitter(const string& id, const string& name, int age) {
        for (int i = 0; i < babysitterCount; ++i) {
            if (babysitters[i].id == id) {
                babysitters[i] = {id, name, age};
                break;
            }
        }
    }

    void displayChildren() {
        for (int i = 0; i < childCount; ++i) {
            cout << "ID: " << children[i].id << ", Name: " << children[i].name << ", Age: " << children[i].age << endl;
        }
    }

    void displayBabysitters() {
        for (int i = 0; i < babysitterCount; ++i) {
            cout << "ID: " << babysitters[i].id << ", Name: " << babysitters[i].name << ", Age: " << babysitters[i].age << endl;
        }
    }

    void searchChild(const string& id) {
        for (int i = 0; i < childCount; ++i) {
            if (children[i].id == id) {
                cout << "Found Child - ID: " << children[i].id << ", Name: " << children[i].name << ", Age: " << children[i].age << endl;
                return;
            }
        }
        cout << "Child not found." << endl;
    }

    void searchBabysitter(const string& id) {
        for (int i = 0; i < babysitterCount; ++i) {
            if (babysitters[i].id == id) {
                cout << "Found Babysitter - ID: " << babysitters[i].id << ", Name: " << babysitters[i].name << ", Age: " << babysitters[i].age << endl;
                return;
            }
        }
        cout << "Babysitter not found." << endl;
    }
};

int main() {
    NurseryManagement nm;
    nm.addChild("C01", "John", 5);
    nm.addChild("C02", "Jane", 6);
    nm.addBabysitter("B01", "Alice", 25);
    nm.addBabysitter("B02", "Bob", 30);

    cout << "Children:" << endl;
    nm.displayChildren();
    cout << "Babysitters:" << endl;
    nm.displayBabysitters();

    nm.searchChild("C01");
    nm.searchBabysitter("B03");

    nm.updateChild("C02", "Janet", 7);
    nm.searchChild("C02");

    nm.deleteBabysitter("B01");
    cout << "Babysitters after deletion:" << endl;
    nm.displayBabysitters();

    return 0;
}