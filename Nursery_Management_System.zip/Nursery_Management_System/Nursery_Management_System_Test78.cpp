#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int age;
public:
    Person(const std::string& name, int age) : name(name), age(age) {}
    virtual void displayInfo() const = 0;
    std::string getName() const { return name; }
    int getAge() const { return age; }
    void setName(const std::string& newName) { name = newName; }
    void setAge(int newAge) { age = newAge; }
};

class Child : public Person {
public:
    Child(const std::string& name, int age) : Person(name, age) {}
    void displayInfo() const override {
        std::cout << "Child - Name: " << name << ", Age: " << age << std::endl;
    }
};

class Babysitter : public Person {
public:
    Babysitter(const std::string& name, int age) : Person(name, age) {}
    void displayInfo() const override {
        std::cout << "Babysitter - Name: " << name << ", Age: " << age << std::endl;
    }
};

class NurseryManagement {
private:
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

public:
    void addChild(const std::string& name, int age) {
        children.push_back(Child(name, age));
    }

    void addBabysitter(const std::string& name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    bool deleteChild(const std::string& name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->getName() == name) {
                children.erase(it);
                return true;
            }
        }
        return false;
    }

    bool deleteBabysitter(const std::string& name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->getName() == name) {
                babysitters.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateChild(const std::string& name, const std::string& newName, int newAge) {
        for (auto& child : children) {
            if (child.getName() == name) {
                child.setName(newName);
                child.setAge(newAge);
                return true;
            }
        }
        return false;
    }

    bool updateBabysitter(const std::string& name, const std::string& newName, int newAge) {
        for (auto& babysitter : babysitters) {
            if (babysitter.getName() == name) {
                babysitter.setName(newName);
                babysitter.setAge(newAge);
                return true;
            }
        }
        return false;
    }

    Person* searchChild(const std::string& name) const {
        for (const auto& child : children) {
            if (child.getName() == name) {
                return const_cast<Child*>(&child);
            }
        }
        return nullptr;
    }

    Person* searchBabysitter(const std::string& name) const {
        for (const auto& babysitter : babysitters) {
            if (babysitter.getName() == name) {
                return const_cast<Babysitter*>(&babysitter);
            }
        }
        return nullptr;
    }

    void displayChildren() const {
        for (const auto& child : children) {
            child.displayInfo();
        }
    }

    void displayBabysitters() const {
        for (const auto& babysitter : babysitters) {
            babysitter.displayInfo();
        }
    }
};

int main() {
    NurseryManagement nursery;
    nursery.addChild("Alice", 5);
    nursery.addChild("Bob", 6);
    nursery.addBabysitter("Clara", 30);
    nursery.addBabysitter("David", 25);

    nursery.displayChildren();
    nursery.displayBabysitters();

    nursery.updateChild("Alice", "Alicia", 6);
    nursery.deleteBabysitter("David");

    nursery.displayChildren();
    nursery.displayBabysitters();

    return 0;
}