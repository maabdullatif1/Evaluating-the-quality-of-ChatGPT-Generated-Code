#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;
    std::string id;
};

class Child : public Person {
};

class Babysitter : public Person {
};

class NurseryManagementSystem {
private:
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

public:
    void addChild(const std::string& name, int age, const std::string& id) {
        Child child;
        child.name = name;
        child.age = age;
        child.id = id;
        children.push_back(child);
    }

    void deleteChild(const std::string& id) {
        children.erase(std::remove_if(children.begin(), children.end(), [&](Child& c) { return c.id == id; }), children.end());
    }

    void updateChild(const std::string& id, const std::string& name, int age) {
        for (auto& child : children) {
            if (child.id == id) {
                child.name = name;
                child.age = age;
                return;
            }
        }
    }

    Child* searchChild(const std::string& id) {
        for (auto& child : children) {
            if (child.id == id) {
                return &child;
            }
        }
        return nullptr;
    }

    void displayChildren() {
        for (const auto& child : children) {
            std::cout << "ID: " << child.id << ", Name: " << child.name << ", Age: " << child.age << std::endl;
        }
    }

    void addBabysitter(const std::string& name, int age, const std::string& id) {
        Babysitter babysitter;
        babysitter.name = name;
        babysitter.age = age;
        babysitter.id = id;
        babysitters.push_back(babysitter);
    }

    void deleteBabysitter(const std::string& id) {
        babysitters.erase(std::remove_if(babysitters.begin(), babysitters.end(), [&](Babysitter& b) { return b.id == id; }), babysitters.end());
    }

    void updateBabysitter(const std::string& id, const std::string& name, int age) {
        for (auto& babysitter : babysitters) {
            if (babysitter.id == id) {
                babysitter.name = name;
                babysitter.age = age;
                return;
            }
        }
    }

    Babysitter* searchBabysitter(const std::string& id) {
        for (auto& babysitter : babysitters) {
            if (babysitter.id == id) {
                return &babysitter;
            }
        }
        return nullptr;
    }

    void displayBabysitters() {
        for (const auto& babysitter : babysitters) {
            std::cout << "ID: " << babysitter.id << ", Name: " << babysitter.name << ", Age: " << babysitter.age << std::endl;
        }
    }
};

int main() {
    NurseryManagementSystem system;

    system.addChild("Alice", 4, "C1");
    system.addChild("Bob", 5, "C2");
    system.displayChildren();

    system.addBabysitter("Emma", 25, "B1");
    system.addBabysitter("John", 30, "B2");
    system.displayBabysitters();

    system.updateChild("C1", "Alice Smith", 5);
    system.displayChildren();

    system.deleteBabysitter("B2");
    system.displayBabysitters();

    return 0;
}