#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Person {
public:
    string name;
    int age;
    Person(string n, int a) : name(n), age(a) {}
};

class Child : public Person {
public:
    Child(string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(string n, int a) : Person(n, a) {}
};

class Nursery {
private:
    vector<Child> children;
    vector<Babysitter> babysitters;

    template<typename T>
    void displayPersons(const vector<T>& persons) {
        for (size_t i = 0; i < persons.size(); ++i) {
            cout << i + 1 << ". " << persons[i].name << " - Age: " << persons[i].age << endl;
        }
    }

    template<typename T>
    int findPersonIndex(const vector<T>& persons, const string& name) {
        for (size_t i = 0; i < persons.size(); ++i) {
            if (persons[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addChild(const string& name, int age) {
        children.push_back(Child(name, age));
    }

    void addBabysitter(const string& name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteChild(const string& name) {
        int index = findPersonIndex(children, name);
        if (index != -1) {
            children.erase(children.begin() + index);
        }
    }

    void deleteBabysitter(const string& name) {
        int index = findPersonIndex(babysitters, name);
        if (index != -1) {
            babysitters.erase(babysitters.begin() + index);
        }
    }

    void updateChild(const string& name, const string& newName, int newAge) {
        int index = findPersonIndex(children, name);
        if (index != -1) {
            children[index].name = newName;
            children[index].age = newAge;
        }
    }

    void updateBabysitter(const string& name, const string& newName, int newAge) {
        int index = findPersonIndex(babysitters, name);
        if (index != -1) {
            babysitters[index].name = newName;
            babysitters[index].age = newAge;
        }
    }

    void searchChild(const string& name) {
        int index = findPersonIndex(children, name);
        if (index != -1) {
            cout << "Child found: " << children[index].name << " - Age: " << children[index].age << endl;
        } else {
            cout << "Child not found." << endl;
        }
    }

    void searchBabysitter(const string& name) {
        int index = findPersonIndex(babysitters, name);
        if (index != -1) {
            cout << "Babysitter found: " << babysitters[index].name << " - Age: " << babysitters[index].age << endl;
        } else {
            cout << "Babysitter not found." << endl;
        }
    }

    void displayChildren() {
        cout << "Children: " << endl;
        displayPersons(children);
    }

    void displayBabysitters() {
        cout << "Babysitters: " << endl;
        displayPersons(babysitters);
    }
};

int main() {
    Nursery nursery;
    nursery.addChild("Alice", 5);
    nursery.addChild("Bob", 6);
    nursery.addBabysitter("Emma", 25);
    nursery.addBabysitter("John", 30);

    cout << "Initial Lists:" << endl;
    nursery.displayChildren();
    nursery.displayBabysitters();

    nursery.updateChild("Alice", "Alicia", 6);
    nursery.deleteBabysitter("John");

    cout << "Updated Lists:" << endl;
    nursery.displayChildren();
    nursery.displayBabysitters();

    nursery.searchChild("Alicia");
    nursery.searchBabysitter("John");
    
    return 0;
}