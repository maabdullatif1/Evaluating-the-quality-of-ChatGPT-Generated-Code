#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string id;
    string name;
    int age;
};

class NurseryManagementSystem {
private:
    vector<Person> children;
    vector<Person> babysitters;

    void displayPerson(const Person &p) {
        cout << "ID: " << p.id << ", Name: " << p.name << ", Age: " << p.age << endl;
    }

    vector<Person>* selectDatabase(int choice) {
        return choice == 1 ? &children : &babysitters;
    }

public:
    void addPerson(int choice, const string& id, const string& name, int age) {
        vector<Person>* database = selectDatabase(choice);
        database->push_back({id, name, age});
    }

    void deletePerson(int choice, const string& id) {
        vector<Person>* database = selectDatabase(choice);
        for (auto it = database->begin(); it != database->end(); ++it) {
            if (it->id == id) {
                database->erase(it);
                return;
            }
        }
    }

    void updatePerson(int choice, const string& id, const string& name, int age) {
        vector<Person>* database = selectDatabase(choice);
        for (auto& person : *database) {
            if (person.id == id) {
                person.name = name;
                person.age = age;
                return;
            }
        }
    }

    void searchPerson(int choice, const string& id) {
        vector<Person>* database = selectDatabase(choice);
        for (const auto& person : *database) {
            if (person.id == id) {
                displayPerson(person);
                return;
            }
        }
        cout << "Person with ID: " << id << " not found." << endl;
    }

    void displayAll(int choice) {
        vector<Person>* database = selectDatabase(choice);
        for (const auto& person : *database) {
            displayPerson(person);
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    int choice;
    do {
        cout << "1. Add Child\n2. Add Babysitter\n3. Delete Child\n4. Delete Babysitter\n5. Update Child\n";
        cout << "6. Update Babysitter\n7. Search Child\n8. Search Babysitter\n9. Display Children\n";
        cout << "10. Display Babysitters\n0. Exit\nChoice: ";
        cin >> choice;

        string id, name;
        int age;
        switch (choice) {
            case 1:
                cout << "Enter Child ID, Name, Age: ";
                cin >> id >> name >> age;
                nms.addPerson(1, id, name, age);
                break;
            case 2:
                cout << "Enter Babysitter ID, Name, Age: ";
                cin >> id >> name >> age;
                nms.addPerson(2, id, name, age);
                break;
            case 3:
                cout << "Enter Child ID to Delete: ";
                cin >> id;
                nms.deletePerson(1, id);
                break;
            case 4:
                cout << "Enter Babysitter ID to Delete: ";
                cin >> id;
                nms.deletePerson(2, id);
                break;
            case 5:
                cout << "Enter Child ID to Update, New Name, New Age: ";
                cin >> id >> name >> age;
                nms.updatePerson(1, id, name, age);
                break;
            case 6:
                cout << "Enter Babysitter ID to Update, New Name, New Age: ";
                cin >> id >> name >> age;
                nms.updatePerson(2, id, name, age);
                break;
            case 7:
                cout << "Enter Child ID to Search: ";
                cin >> id;
                nms.searchPerson(1, id);
                break;
            case 8:
                cout << "Enter Babysitter ID to Search: ";
                cin >> id;
                nms.searchPerson(2, id);
                break;
            case 9:
                nms.displayAll(1);
                break;
            case 10:
                nms.displayAll(2);
                break;
        }
    } while (choice != 0);

    return 0;
}