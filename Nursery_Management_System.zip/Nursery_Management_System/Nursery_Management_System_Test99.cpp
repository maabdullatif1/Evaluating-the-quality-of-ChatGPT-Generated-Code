#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;

    Person(const std::string& name, int age) : name(name), age(age) {}
};

class Child : public Person {
public:
    Child(const std::string& name, int age) : Person(name, age) {}
};

class Babysitter : public Person {
public:
    Babysitter(const std::string& name, int age) : Person(name, age) {}
};

class NurseryManagement {
private:
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

public:
    void addChild(const std::string& name, int age) {
        children.push_back(Child(name, age));
    }

    void deleteChild(const std::string& name) {
        for (auto it = children.begin(); it != children.end();) {
            if (it->name == name) {
                it = children.erase(it);
            } else {
                ++it;
            }
        }
    }

    void updateChild(const std::string& name, const std::string& newName, int newAge) {
        for (auto& child : children) {
            if (child.name == name) {
                child.name = newName;
                child.age = newAge;
            }
        }
    }

    Child* searchChild(const std::string& name) {
        for (auto& child : children) {
            if (child.name == name) {
                return &child;
            }
        }
        return nullptr;
    }

    void addBabysitter(const std::string& name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteBabysitter(const std::string& name) {
        for (auto it = babysitters.begin(); it != babysitters.end();) {
            if (it->name == name) {
                it = babysitters.erase(it);
            } else {
                ++it;
            }
        }
    }

    void updateBabysitter(const std::string& name, const std::string& newName, int newAge) {
        for (auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                babysitter.name = newName;
                babysitter.age = newAge;
            }
        }
    }

    Babysitter* searchBabysitter(const std::string& name) {
        for (auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                return &babysitter;
            }
        }
        return nullptr;
    }

    void displayChildren() {
        for (const auto& child : children) {
            std::cout << "Child Name: " << child.name << ", Age: " << child.age << std::endl;
        }
    }

    void displayBabysitters() {
        for (const auto& babysitter : babysitters) {
            std::cout << "Babysitter Name: " << babysitter.name << ", Age: " << babysitter.age << std::endl;
        }
    }
};

int main() {
    NurseryManagement nursery;

    nursery.addChild("John", 4);
    nursery.addChild("Emma", 3);
    nursery.addBabysitter("Alice", 30);
    nursery.addBabysitter("Bob", 25);

    std::cout << "Children:\n";
    nursery.displayChildren();

    std::cout << "\nBabysitters:\n";
    nursery.displayBabysitters();

    nursery.updateChild("John", "Johnny", 5);
    nursery.deleteBabysitter("Bob");

    std::cout << "\nAfter Updates:\n";
    std::cout << "Children:\n";
    nursery.displayChildren();

    std::cout << "\nBabysitters:\n";
    nursery.displayBabysitters();

    return 0;
}