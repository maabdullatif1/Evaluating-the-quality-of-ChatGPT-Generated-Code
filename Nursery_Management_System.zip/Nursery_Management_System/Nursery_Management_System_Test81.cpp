#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
public:
    string id;
    string name;
    int age;

    Person(const string& id, const string& name, int age)
        : id(id), name(name), age(age) {}
};

class Child : public Person {
public:
    Child(const string& id, const string& name, int age)
        : Person(id, name, age) {}
};

class Babysitter : public Person {
public:
    Babysitter(const string& id, const string& name, int age)
        : Person(id, name, age) {}
};

class NurseryManagementSystem {
private:
    vector<Child> children;
    vector<Babysitter> babysitters;

public:
    void addChild(const string& id, const string& name, int age) {
        children.push_back(Child(id, name, age));
    }

    void addBabysitter(const string& id, const string& name, int age) {
        babysitters.push_back(Babysitter(id, name, age));
    }

    void deleteChild(const string& id) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->id == id) {
                children.erase(it);
                return;
            }
        }
    }

    void deleteBabysitter(const string& id) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->id == id) {
                babysitters.erase(it);
                return;
            }
        }
    }

    void updateChild(const string& id, const string& name, int age) {
        for (auto& child : children) {
            if (child.id == id) {
                child.name = name;
                child.age = age;
                return;
            }
        }
    }

    void updateBabysitter(const string& id, const string& name, int age) {
        for (auto& babysitter : babysitters) {
            if (babysitter.id == id) {
                babysitter.name = name;
                babysitter.age = age;
                return;
            }
        }
    }

    Child* searchChild(const string& id) {
        for (auto& child : children) {
            if (child.id == id) {
                return &child;
            }
        }
        return nullptr;
    }

    Babysitter* searchBabysitter(const string& id) {
        for (auto& babysitter : babysitters) {
            if (babysitter.id == id) {
                return &babysitter;
            }
        }
        return nullptr;
    }

    void displayChildren() {
        for (const auto& child : children) {
            cout << "ID: " << child.id << ", Name: " << child.name << ", Age: " << child.age << endl;
        }
    }

    void displayBabysitters() {
        for (const auto& babysitter : babysitters) {
            cout << "ID: " << babysitter.id << ", Name: " << babysitter.name << ", Age: " << babysitter.age << endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;

    nms.addChild("C001", "Alice", 4);
    nms.addChild("C002", "Bob", 5);
    nms.addBabysitter("B001", "Emma", 25);
    nms.addBabysitter("B002", "James", 30);

    cout << "Children:" << endl;
    nms.displayChildren();

    cout << "Babysitters:" << endl;
    nms.displayBabysitters();

    nms.updateChild("C001", "Alice Smith", 6);
    nms.deleteBabysitter("B002");

    cout << "Updated Children:" << endl;
    nms.displayChildren();

    cout << "Updated Babysitters:" << endl;
    nms.displayBabysitters();

    return 0;
}