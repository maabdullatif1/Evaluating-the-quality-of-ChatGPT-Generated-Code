#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Child {
    int id;
    string name;
    int age;
};

struct Babysitter {
    int id;
    string name;
    int experience;
};

class NurseryManagementSystem {
private:
    vector<Child> children;
    vector<Babysitter> babysitters;

public:
    void addChild(int id, string name, int age) {
        children.push_back({id, name, age});
    }

    void deleteChild(int id) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->id == id) {
                children.erase(it);
                return;
            }
        }
    }

    void updateChild(int id, string name, int age) {
        for (auto &child : children) {
            if (child.id == id) {
                child.name = name;
                child.age = age;
                return;
            }
        }
    }

    Child* searchChild(int id) {
        for (auto &child : children) {
            if (child.id == id) {
                return &child;
            }
        }
        return nullptr;
    }

    void displayChildren() {
        for (const auto &child : children) {
            cout << "ID: " << child.id << ", Name: " << child.name << ", Age: " << child.age << endl;
        }
    }

    void addBabysitter(int id, string name, int experience) {
        babysitters.push_back({id, name, experience});
    }

    void deleteBabysitter(int id) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->id == id) {
                babysitters.erase(it);
                return;
            }
        }
    }

    void updateBabysitter(int id, string name, int experience) {
        for (auto &babysitter : babysitters) {
            if (babysitter.id == id) {
                babysitter.name = name;
                babysitter.experience = experience;
                return;
            }
        }
    }

    Babysitter* searchBabysitter(int id) {
        for (auto &babysitter : babysitters) {
            if (babysitter.id == id) {
                return &babysitter;
            }
        }
        return nullptr;
    }

    void displayBabysitters() {
        for (const auto &babysitter : babysitters) {
            cout << "ID: " << babysitter.id << ", Name: " << babysitter.name << ", Experience: " << babysitter.experience << endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;

    nms.addChild(1, "Alice", 4);
    nms.addChild(2, "Bob", 5);
    nms.displayChildren();

    nms.addBabysitter(1, "Sophia", 10);
    nms.addBabysitter(2, "Emma", 5);
    nms.displayBabysitters();

    nms.updateChild(1, "Alice Green", 5);
    nms.displayChildren();

    nms.updateBabysitter(1, "Sophia Brown", 12);
    nms.displayBabysitters();

    return 0;
}