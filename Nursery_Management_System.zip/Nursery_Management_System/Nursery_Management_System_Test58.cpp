#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;

    Person(const std::string& name, int age) : name(name), age(age) {}
};

class Child : public Person {
public:
    Child(const std::string& name, int age) : Person(name, age) {}
};

class Babysitter : public Person {
public:
    Babysitter(const std::string& name, int age) : Person(name, age) {}
};

class NurseryManagementSystem {
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

public:
    void addChild(const std::string& name, int age) {
        children.emplace_back(name, age);
    }

    void addBabysitter(const std::string& name, int age) {
        babysitters.emplace_back(name, age);
    }

    void deleteChild(const std::string& name) {
        for (auto it = children.begin(); it != children.end(); it++) {
            if (it->name == name) {
                children.erase(it);
                return;
            }
        }
    }

    void deleteBabysitter(const std::string& name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); it++) {
            if (it->name == name) {
                babysitters.erase(it);
                return;
            }
        }
    }

    void updateChild(const std::string& name, int newAge) {
        for (auto& child : children) {
            if (child.name == name) {
                child.age = newAge;
                return;
            }
        }
    }

    void updateBabysitter(const std::string& name, int newAge) {
        for (auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                babysitter.age = newAge;
                return;
            }
        }
    }

    void searchChild(const std::string& name) {
        for (const auto& child : children) {
            if (child.name == name) {
                std::cout << "Child Found: " << child.name << ", Age: " << child.age << std::endl;
                return;
            }
        }
        std::cout << "Child Not Found" << std::endl;
    }

    void searchBabysitter(const std::string& name) {
        for (const auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                std::cout << "Babysitter Found: " << babysitter.name << ", Age: " << babysitter.age << std::endl;
                return;
            }
        }
        std::cout << "Babysitter Not Found" << std::endl;
    }

    void displayChildren() {
        std::cout << "Children List:" << std::endl;
        for (const auto& child : children) {
            std::cout << "Name: " << child.name << ", Age: " << child.age << std::endl;
        }
    }

    void displayBabysitters() {
        std::cout << "Babysitters List:" << std::endl;
        for (const auto& babysitter : babysitters) {
            std::cout << "Name: " << babysitter.name << ", Age: " << babysitter.age << std::endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 5);
    nms.addChild("Bob", 6);
    nms.addBabysitter("Clara", 30);
    nms.addBabysitter("David", 25);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.searchChild("Alice");
    nms.searchBabysitter("Clara");

    nms.updateChild("Bob", 7);
    nms.updateBabysitter("David", 26);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.deleteChild("Alice");
    nms.deleteBabysitter("Clara");

    nms.displayChildren();
    nms.displayBabysitters();

    return 0;
}