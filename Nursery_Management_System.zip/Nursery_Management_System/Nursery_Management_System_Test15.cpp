#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    int age;
    string id;
};

class NurseryManagementSystem {
private:
    vector<Person> children;
    vector<Person> babysitters;

    Person* findPerson(vector<Person>& list, const string& id) {
        for (auto& person : list) {
            if (person.id == id) {
                return &person;
            }
        }
        return nullptr;
    }

public:
    void addChild(const string& name, int age, const string& id) {
        children.push_back({name, age, id});
    }

    void addBabysitter(const string& name, int age, const string& id) {
        babysitters.push_back({name, age, id});
    }

    void deleteChild(const string& id) {
        children.erase(remove_if(children.begin(), children.end(), [&](Person& p) { return p.id == id; }), children.end());
    }

    void deleteBabysitter(const string& id) {
        babysitters.erase(remove_if(babysitters.begin(), babysitters.end(), [&](Person& p) { return p.id == id; }), babysitters.end());
    }

    void updateChild(const string& id, const string& name, int age) {
        Person* child = findPerson(children, id);
        if (child) {
            child->name = name;
            child->age = age;
        }
    }

    void updateBabysitter(const string& id, const string& name, int age) {
        Person* babysitter = findPerson(babysitters, id);
        if (babysitter) {
            babysitter->name = name;
            babysitter->age = age;
        }
    }

    Person* searchChild(const string& id) {
        return findPerson(children, id);
    }

    Person* searchBabysitter(const string& id) {
        return findPerson(babysitters, id);
    }

    void displayChildren() {
        cout << "Children:\n";
        for (const auto& child : children) {
            cout << "Name: " << child.name << ", Age: " << child.age << ", ID: " << child.id << endl;
        }
    }

    void displayBabysitters() {
        cout << "Babysitters:\n";
        for (const auto& babysitter : babysitters) {
            cout << "Name: " << babysitter.name << ", Age: " << babysitter.age << ", ID: " << babysitter.id << endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 5, "C001");
    nms.addChild("Bob", 4, "C002");
    nms.addBabysitter("Emma", 30, "B001");
    nms.addBabysitter("Liam", 28, "B002");

    nms.displayChildren();
    nms.displayBabysitters();

    nms.updateChild("C001", "Alice Parker", 6);
    nms.updateBabysitter("B001", "Emma Johnson", 31);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.deleteChild("C002");
    nms.deleteBabysitter("B002");

    nms.displayChildren();
    nms.displayBabysitters();

    Person* child = nms.searchChild("C001");
    if (child) {
        cout << "Found child: " << child->name << endl;
    }

    Person* babysitter = nms.searchBabysitter("B001");
    if (babysitter) {
        cout << "Found babysitter: " << babysitter->name << endl;
    }

    return 0;
}