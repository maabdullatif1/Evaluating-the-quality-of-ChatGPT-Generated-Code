#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int age;
    std::string id;
    
    Person(std::string n, int a, std::string i) : name(n), age(a), id(i) {}
};

class Child : public Person {
public:
    Child(std::string n, int a, std::string i) : Person(n, a, i) {}
};

class Babysitter : public Person {
public:
    Babysitter(std::string n, int a, std::string i) : Person(n, a, i) {}
};

class NurseryManagementSystem {
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

    template <typename T>
    void addPerson(std::vector<T>& list, const T& person) {
        list.push_back(person);
    }

    template <typename T>
    bool deletePerson(std::vector<T>& list, const std::string& id) {
        for (auto it = list.begin(); it != list.end(); ++it) {
            if (it->id == id) {
                list.erase(it);
                return true;
            }
        }
        return false;
    }

    template <typename T>
    bool updatePerson(std::vector<T>& list, const std::string& id, const std::string& newName, int newAge) {
        for (auto& person : list) {
            if (person.id == id) {
                person.name = newName;
                person.age = newAge;
                return true;
            }
        }
        return false;
    }

    template <typename T>
    T* searchPerson(std::vector<T>& list, const std::string& id) {
        for (auto& person : list) {
            if (person.id == id) {
                return &person;
            }
        }
        return nullptr;
    }

    template <typename T>
    void displayList(const std::vector<T>& list) {
        for (const auto& person : list) {
            std::cout << "Name: " << person.name << ", Age: " << person.age << ", ID: " << person.id << std::endl;
        }
    }

public:
    void addChild(const std::string& name, int age, const std::string& id) {
        addPerson(children, Child(name, age, id));
    }

    void addBabysitter(const std::string& name, int age, const std::string& id) {
        addPerson(babysitters, Babysitter(name, age, id));
    }

    bool deleteChild(const std::string& id) {
        return deletePerson(children, id);
    }

    bool deleteBabysitter(const std::string& id) {
        return deletePerson(babysitters, id);
    }

    bool updateChild(const std::string& id, const std::string& newName, int newAge) {
        return updatePerson(children, id, newName, newAge);
    }

    bool updateBabysitter(const std::string& id, const std::string& newName, int newAge) {
        return updatePerson(babysitters, id, newName, newAge);
    }

    Child* searchChild(const std::string& id) {
        return searchPerson(children, id);
    }

    Babysitter* searchBabysitter(const std::string& id) {
        return searchPerson(babysitters, id);
    }

    void displayChildren() {
        displayList(children);
    }

    void displayBabysitters() {
        displayList(babysitters);
    }
};

int main() {
    NurseryManagementSystem nms;
    
    nms.addChild("Alice", 5, "C01");
    nms.addChild("Bob", 6, "C02");
    nms.addBabysitter("Sophie", 25, "B01");
    nms.addBabysitter("Tom", 30, "B02");

    nms.displayChildren();
    nms.displayBabysitters();

    nms.updateChild("C01", "Alice Johnson", 6);
    nms.updateBabysitter("B01", "Sophie Smith", 26);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.deleteChild("C02");
    nms.deleteBabysitter("B02");

    nms.displayChildren();
    nms.displayBabysitters();

    return 0;
}