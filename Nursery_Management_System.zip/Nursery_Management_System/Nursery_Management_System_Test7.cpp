#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Person {
public:
    string name;
    int age;
    Person(string n, int a) : name(n), age(a) {}
};

class Child : public Person {
public:
    Child(string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(string n, int a) : Person(n, a) {}
};

class Nursery {
private:
    vector<Child> children;
    vector<Babysitter> babysitters;
public:
    void addChild(string name, int age) {
        children.emplace_back(name, age);
    }

    void addBabysitter(string name, int age) {
        babysitters.emplace_back(name, age);
    }

    void deleteChild(string name) {
        for (size_t i = 0; i < children.size(); ++i) {
            if (children[i].name == name) {
                children.erase(children.begin() + i);
                break;
            }
        }
    }

    void deleteBabysitter(string name) {
        for (size_t i = 0; i < babysitters.size(); ++i) {
            if (babysitters[i].name == name) {
                babysitters.erase(babysitters.begin() + i);
                break;
            }
        }
    }

    void updateChild(string oldName, string newName, int newAge) {
        for (auto &child : children) {
            if (child.name == oldName) {
                child.name = newName;
                child.age = newAge;
                break;
            }
        }
    }

    void updateBabysitter(string oldName, string newName, int newAge) {
        for (auto &babysitter : babysitters) {
            if (babysitter.name == oldName) {
                babysitter.name = newName;
                babysitter.age = newAge;
                break;
            }
        }
    }

    void searchChild(string name) {
        for (const auto &child : children) {
            if (child.name == name) {
                cout << "Child found: " << child.name << ", Age: " << child.age << endl;
                return;
            }
        }
        cout << "Child not found" << endl;
    }

    void searchBabysitter(string name) {
        for (const auto &babysitter : babysitters) {
            if (babysitter.name == name) {
                cout << "Babysitter found: " << babysitter.name << ", Age: " << babysitter.age << endl;
                return;
            }
        }
        cout << "Babysitter not found" << endl;
    }

    void displayChildren() {
        for (const auto &child : children) {
            cout << "Child: " << child.name << ", Age: " << child.age << endl;
        }
    }

    void displayBabysitters() {
        for (const auto &babysitter : babysitters) {
            cout << "Babysitter: " << babysitter.name << ", Age: " << babysitter.age << endl;
        }
    }
};

int main() {
    Nursery nursery;
    nursery.addChild("Alice", 5);
    nursery.addChild("Bob", 4);
    nursery.addBabysitter("Eve", 30);
    nursery.addBabysitter("Charlie", 25);
    nursery.displayChildren();
    nursery.displayBabysitters();
    nursery.searchChild("Alice");
    nursery.searchBabysitter("Eve");
    nursery.updateChild("Alice", "Alicia", 6);
    nursery.updateBabysitter("Charlie", "Chuck", 26);
    nursery.displayChildren();
    nursery.displayBabysitters();
    nursery.deleteChild("Bob");
    nursery.deleteBabysitter("Eve");
    nursery.displayChildren();
    nursery.displayBabysitters();
    return 0;
}