#include <iostream>
#include <string>
#include <vector>

class Person {
public:
    std::string name;
    int age;

    Person(std::string n, int a) : name(n), age(a) {}
};

class Child : public Person {
public:
    Child(std::string n, int a) : Person(n, a) {}
};

class Babysitter : public Person {
public:
    Babysitter(std::string n, int a) : Person(n, a) {}
};

class NurseryManagementSystem {
private:
    std::vector<Child> children;
    std::vector<Babysitter> babysitters;

public:
    void addChild(std::string name, int age) {
        children.push_back(Child(name, age));
    }

    void addBabysitter(std::string name, int age) {
        babysitters.push_back(Babysitter(name, age));
    }

    void deleteChild(std::string name) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (it->name == name) {
                children.erase(it);
                break;
            }
        }
    }

    void deleteBabysitter(std::string name) {
        for (auto it = babysitters.begin(); it != babysitters.end(); ++it) {
            if (it->name == name) {
                babysitters.erase(it);
                break;
            }
        }
    }

    void updateChild(std::string name, int newAge) {
        for (auto& child : children) {
            if (child.name == name) {
                child.age = newAge;
                break;
            }
        }
    }

    void updateBabysitter(std::string name, int newAge) {
        for (auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                babysitter.age = newAge;
                break;
            }
        }
    }

    void searchChild(std::string name) {
        for (const auto& child : children) {
            if (child.name == name) {
                std::cout << "Child found: " << child.name << ", Age: " << child.age << std::endl;
                return;
            }
        }
        std::cout << "Child not found" << std::endl;
    }

    void searchBabysitter(std::string name) {
        for (const auto& babysitter : babysitters) {
            if (babysitter.name == name) {
                std::cout << "Babysitter found: " << babysitter.name << ", Age: " << babysitter.age << std::endl;
                return;
            }
        }
        std::cout << "Babysitter not found" << std::endl;
    }

    void displayChildren() {
        std::cout << "Children List:" << std::endl;
        for (const auto& child : children) {
            std::cout << "Name: " << child.name << ", Age: " << child.age << std::endl;
        }
    }

    void displayBabysitters() {
        std::cout << "Babysitters List:" << std::endl;
        for (const auto& babysitter : babysitters) {
            std::cout << "Name: " << babysitter.name << ", Age: " << babysitter.age << std::endl;
        }
    }
};

int main() {
    NurseryManagementSystem nms;
    nms.addChild("Alice", 5);
    nms.addChild("Bob", 4);
    nms.addBabysitter("Charlie", 30);
    nms.addBabysitter("David", 25);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.searchChild("Alice");
    nms.searchBabysitter("Charlie");

    nms.updateChild("Alice", 6);
    nms.updateBabysitter("David", 26);

    nms.displayChildren();
    nms.displayBabysitters();

    nms.deleteChild("Bob");
    nms.deleteBabysitter("Charlie");

    nms.displayChildren();
    nms.displayBabysitters();

    return 0;
}