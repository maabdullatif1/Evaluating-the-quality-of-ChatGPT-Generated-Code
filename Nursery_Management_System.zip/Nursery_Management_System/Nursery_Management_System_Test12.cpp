#include <iostream>
#include <string>
#include <vector>

class Person {
protected:
    std::string name;
    int age;
public:
    Person(const std::string& name, int age) : name(name), age(age) {}
    virtual void display() const = 0;
    std::string getName() const { return name; }
    int getAge() const { return age; }
    void setName(const std::string& newName) { name = newName; }
    void setAge(int newAge) { age = newAge; }
};

class Child : public Person {
public:
    Child(const std::string& name, int age) : Person(name, age) {}
    void display() const override {
        std::cout << "Child Name: " << name << ", Age: " << age << std::endl;
    }
};

class Babysitter : public Person {
public:
    Babysitter(const std::string& name, int age) : Person(name, age) {}
    void display() const override {
        std::cout << "Babysitter Name: " << name << ", Age: " << age << std::endl;
    }
};

template <typename T>
class NurseryManagement {
private:
    std::vector<T> people;
public:
    void add(const T& person) {
        people.push_back(person);
    }
    void remove(const std::string& name) {
        for (auto it = people.begin(); it != people.end(); ++it) {
            if (it->getName() == name) {
                people.erase(it);
                break;
            }
        }
    }
    void update(const std::string& name, const std::string& newName, int newAge) {
        for (auto& person : people) {
            if (person.getName() == name) {
                person.setName(newName);
                person.setAge(newAge);
                break;
            }
        }
    }
    void search(const std::string& name) const {
        for (const auto& person : people) {
            if (person.getName() == name) {
                person.display();
                return;
            }
        }
        std::cout << name << " not found" << std::endl;
    }
    void display() const {
        for (const auto& person : people) {
            person.display();
        }
    }
};

int main() {
    NurseryManagement<Child> children;
    NurseryManagement<Babysitter> babysitters;

    children.add(Child("Alice", 5));
    children.add(Child("Bob", 4));
    babysitters.add(Babysitter("Emma", 28));
    babysitters.add(Babysitter("John", 30));

    std::cout << "Children:" << std::endl;
    children.display();

    std::cout << "\nBabysitters:" << std::endl;
    babysitters.display();

    std::cout << "\nSearching for Bob:" << std::endl;
    children.search("Bob");

    std::cout << "\nUpdating Bob's info:" << std::endl;
    children.update("Bob", "Robert", 6);

    std::cout << "\nChildren after update:" << std::endl;
    children.display();

    std::cout << "\nDeleting Alice:" << std::endl;
    children.remove("Alice");

    std::cout << "\nChildren after deletion:" << std::endl;
    children.display();

    return 0;
}