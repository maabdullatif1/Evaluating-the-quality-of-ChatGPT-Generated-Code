#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    std::string name;
    std::string id;
    std::string labId;

    Equipment(std::string n, std::string i, std::string lId) : name(n), id(i), labId(lId) {}
};

class Lab {
public:
    std::string name;
    std::string id;
    std::vector<Equipment> equipments;

    Lab(std::string n, std::string i) : name(n), id(i) {}

    void addEquipment(const Equipment& equipment) {
        equipments.push_back(equipment);
    }

    void deleteEquipment(const std::string& equipmentId) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == equipmentId) {
                equipments.erase(it);
                break;
            }
        }
    }

    void updateEquipment(const std::string& equipmentId, const std::string& newName) {
        for (auto& equipment : equipments) {
            if (equipment.id == equipmentId) {
                equipment.name = newName;
                break;
            }
        }
    }

    Equipment* searchEquipment(const std::string& equipmentId) {
        for (auto& equipment : equipments) {
            if (equipment.id == equipmentId) {
                return &equipment;
            }
        }
        return nullptr;
    }
};

class EquipmentManagementSystem {
private:
    std::vector<Lab> labs;

public:
    void addLab(const Lab& lab) {
        labs.push_back(lab);
    }

    void deleteLab(const std::string& labId) {
        for (auto it = labs.begin(); it != labs.end(); ++it) {
            if (it->id == labId) {
                labs.erase(it);
                break;
            }
        }
    }

    void updateLab(const std::string& labId, const std::string& newName) {
        for (auto& lab : labs) {
            if (lab.id == labId) {
                lab.name = newName;
                break;
            }
        }
    }

    Lab* searchLab(const std::string& labId) {
        for (auto& lab : labs) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLabs() const {
        for (const auto& lab : labs) {
            std::cout << "Lab Name: " << lab.name << ", Lab ID: " << lab.id << std::endl;
            for (const auto& equipment : lab.equipments) {
                std::cout << "  Equipment Name: " << equipment.name << ", Equipment ID: " << equipment.id << std::endl;
            }
        }
    }
};

int main() {
    EquipmentManagementSystem system;

    Lab lab1("Chemistry Lab", "Lab001");
    lab1.addEquipment(Equipment("Microscope", "E001", lab1.id));
    lab1.addEquipment(Equipment("Beaker", "E002", lab1.id));

    system.addLab(lab1);

    system.displayLabs();

    Lab* lab = system.searchLab("Lab001");
    if (lab) {
        lab->updateEquipment("E002", "Flask");
    }

    system.displayLabs();

    return 0;
}