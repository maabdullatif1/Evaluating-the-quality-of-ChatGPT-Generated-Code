#include <iostream>
#include <vector>
#include <string>

class Equipment {
    std::string id;
    std::string name;
public:
    Equipment(const std::string& id, const std::string& name) : id(id), name(name) {}

    std::string getId() const { return id; }
    std::string getName() const { return name; }
    void setName(const std::string& newName) { name = newName; }
};

class Laboratory {
    std::string id;
    std::string name;
    std::vector<Equipment> equipmentList;
public:
    Laboratory(const std::string& id, const std::string& name) : id(id), name(name) {}

    std::string getId() const { return id; }
    std::string getName() const { return name; }
    void setName(const std::string& newName) { name = newName; }

    void addEquipment(const Equipment& equipment) {
        equipmentList.push_back(equipment);
    }

    bool removeEquipment(const std::string& equipmentId) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->getId() == equipmentId) {
                equipmentList.erase(it);
                return true;
            }
        }
        return false;
    }

    void displayEquipment() const {
        for (const auto& equipment : equipmentList) {
            std::cout << "Equipment ID: " << equipment.getId() << ", Name: " << equipment.getName() << std::endl;
        }
    }
};

class EquipmentManagementSystem {
    std::vector<Laboratory> labs;
public:
    void addLaboratory(const Laboratory& lab) {
        labs.push_back(lab);
    }

    bool deleteLaboratory(const std::string& labId) {
        for (auto it = labs.begin(); it != labs.end(); ++it) {
            if (it->getId() == labId) {
                labs.erase(it);
                return true;
            }
        }
        return false;
    }

    Laboratory* searchLaboratory(const std::string& labId) {
        for (auto& lab : labs) {
            if (lab.getId() == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLaboratories() const {
        for (const auto& lab : labs) {
            std::cout << "Laboratory ID: " << lab.getId() << ", Name: " << lab.getName() << std::endl;
            lab.displayEquipment();
        }
    }
};

int main() {
    EquipmentManagementSystem ems;

    ems.addLaboratory(Laboratory("Lab1", "Physics Lab"));
    ems.addLaboratory(Laboratory("Lab2", "Chemistry Lab"));

    Laboratory* lab = ems.searchLaboratory("Lab1");
    if (lab) {
        lab->addEquipment(Equipment("E1", "Microscope"));
        lab->addEquipment(Equipment("E2", "Telescope"));
    }

    ems.displayLaboratories();
    
    if (lab) {
        lab->removeEquipment("E1");
    }

    ems.displayLaboratories();

    return 0;
}