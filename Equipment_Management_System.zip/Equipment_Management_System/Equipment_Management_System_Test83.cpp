#include <iostream>
#include <vector>
#include <string>

struct Equipment {
    int id;
    std::string name;
    std::string type;
    std::string lab;

    Equipment(int i, const std::string& n, const std::string& t, const std::string& l)
        : id(i), name(n), type(t), lab(l) {}
};

class EquipmentManagementSystem {
private:
    std::vector<Equipment> equipmentList;

public:
    void addEquipment(int id, const std::string& name, const std::string& type, const std::string& lab) {
        equipmentList.push_back(Equipment(id, name, type, lab));
    }

    void deleteEquipment(int id) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == id) {
                equipmentList.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int id, const std::string& name, const std::string& type, const std::string& lab) {
        for (auto& equipment : equipmentList) {
            if (equipment.id == id) {
                equipment.name = name;
                equipment.type = type;
                equipment.lab = lab;
                break;
            }
        }
    }

    Equipment* searchEquipment(int id) {
        for (auto& equipment : equipmentList) {
            if (equipment.id == id) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void displayAllEquipment() {
        for (const auto& equipment : equipmentList) {
            std::cout << "ID: " << equipment.id
                      << ", Name: " << equipment.name
                      << ", Type: " << equipment.type
                      << ", Lab: " << equipment.lab << "\n";
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addEquipment(1, "Microscope", "Optical", "Biology Lab");
    ems.addEquipment(2, "Spectrometer", "Analytical", "Chemistry Lab");
    ems.displayAllEquipment();
    Equipment* searchResult = ems.searchEquipment(1);
    if (searchResult) {
        std::cout << "Found Equipment: " << searchResult->name << "\n";
    }
    ems.updateEquipment(2, "Spectrometer", "Analytical Instrument", "Chemistry Lab");
    ems.displayAllEquipment();
    ems.deleteEquipment(1);
    ems.displayAllEquipment();
    return 0;
}