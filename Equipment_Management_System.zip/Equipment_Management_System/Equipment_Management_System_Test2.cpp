#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string description;

    Equipment(int i, string n, string d): id(i), name(n), description(d) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipments;

    Laboratory(int i, string n): id(i), name(n) {}
};

class ManagementSystem {
private:
    vector<Laboratory> laboratories;

public:
    void addLaboratory(int id, string name) {
        laboratories.push_back(Laboratory(id, name));
    }

    void deleteLaboratory(int id) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == id) {
                laboratories.erase(it);
                return;
            }
        }
    }

    void updateLaboratory(int id, string name) {
        for (auto &lab : laboratories) {
            if (lab.id == id) {
                lab.name = name;
                return;
            }
        }
    }

    void searchLaboratory(int id) {
        for (auto &lab : laboratories) {
            if (lab.id == id) {
                cout << "Lab ID: " << lab.id << ", Name: " << lab.name << endl;
                for (auto &equip : lab.equipments) {
                    cout << "    Equipment - ID: " << equip.id 
                         << ", Name: " << equip.name
                         << ", Desc: " << equip.description << endl;
                }
                return;
            }
        }
        cout << "Laboratory not found." << endl;
    }

    void addEquipment(int labId, int equipId, string name, string description) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) {
                lab.equipments.push_back(Equipment(equipId, name, description));
                return;
            }
        }
    }

    void deleteEquipment(int labId, int equipId) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) {
                for (auto it = lab.equipments.begin(); it != lab.equipments.end(); ++it) {
                    if (it->id == equipId) {
                        lab.equipments.erase(it);
                        return;
                    }
                }
            }
        }
    }

    void updateEquipment(int labId, int equipId, string name, string description) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) {
                for (auto &equip : lab.equipments) {
                    if (equip.id == equipId) {
                        equip.name = name;
                        equip.description = description;
                        return;
                    }
                }
            }
        }
    }

    void displayAll() {
        for (auto &lab : laboratories) {
            cout << "Lab ID: " << lab.id << ", Name: " << lab.name << endl;
            for (auto &equip : lab.equipments) {
                cout << "    Equipment - ID: " << equip.id 
                     << ", Name: " << equip.name
                     << ", Desc: " << equip.description << endl;
            }
        }
    }
};

int main() {
    ManagementSystem system;

    system.addLaboratory(1, "Physics Lab");
    system.addLaboratory(2, "Chemistry Lab");

    system.addEquipment(1, 101, "Microscope", "High power microscope");
    system.addEquipment(1, 102, "Spectrometer", "Optical spectrometer");
    system.addEquipment(2, 201, "Bunsen Burner", "Gas burner");

    system.displayAll();

    system.updateLaboratory(1, "Advanced Physics Lab");
    system.updateEquipment(1, 101, "Electron Microscope", "Advanced electron microscope");

    system.displayAll();

    system.deleteEquipment(1, 102);
    system.deleteLaboratory(2);

    system.displayAll();

    system.searchLaboratory(1);
    
    return 0;
}