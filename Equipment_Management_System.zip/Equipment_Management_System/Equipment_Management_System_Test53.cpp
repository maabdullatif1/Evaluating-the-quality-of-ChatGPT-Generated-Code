#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    std::string name;
    std::string type;

    Equipment(std::string n, std::string t) : name(n), type(t) {}
};

class Laboratory {
public:
    std::string labName;
    std::vector<Equipment> equipments;

    Laboratory(std::string ln) : labName(ln) {}
    
    void addEquipment(std::string name, std::string type) {
        equipments.emplace_back(name, type);
    }

    void deleteEquipment(std::string name) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->name == name) {
                equipments.erase(it);
                break;
            }
        }
    }

    void updateEquipment(std::string oldName, std::string newName, std::string newType) {
        for (auto &equip : equipments) {
            if (equip.name == oldName) {
                equip.name = newName;
                equip.type = newType;
                break;
            }
        }
    }

    void displayEquipment() {
        for (const auto &equip : equipments) {
            std::cout << "Equipment Name: " << equip.name << ", Type: " << equip.type << std::endl;
        }
    }

    bool searchEquipment(std::string name) {
        for (const auto &equip : equipments) {
            if (equip.name == name) {
                return true;
            }
        }
        return false;
    }
};

class EquipmentManagementSystem {
public:
    std::vector<Laboratory> laboratories;

    void addLaboratory(std::string labName) {
        laboratories.emplace_back(labName);
    }

    Laboratory* findLaboratory(std::string labName) {
        for (auto &lab : laboratories) {
            if (lab.labName == labName) {
                return &lab;
            }
        }
        return nullptr;
    }

    void addEquipmentToLab(std::string labName, std::string equipName, std::string equipType) {
        Laboratory* lab = findLaboratory(labName);
        if (lab != nullptr) {
            lab->addEquipment(equipName, equipType);
        }
    }

    void deleteEquipmentFromLab(std::string labName, std::string equipName) {
        Laboratory* lab = findLaboratory(labName);
        if (lab != nullptr) {
            lab->deleteEquipment(equipName);
        }
    }

    void updateEquipmentInLab(std::string labName, std::string oldEquipName, std::string newEquipName, std::string newEquipType) {
        Laboratory* lab = findLaboratory(labName);
        if (lab != nullptr) {
            lab->updateEquipment(oldEquipName, newEquipName, newEquipType);
        }
    }

    void searchEquipmentInLab(std::string labName, std::string equipName) {
        Laboratory* lab = findLaboratory(labName);
        if (lab != nullptr) {
            if (lab->searchEquipment(equipName)) {
                std::cout << "Equipment " << equipName << " found in laboratory " << labName << "." << std::endl;
            } else {
                std::cout << "Equipment " << equipName << " not found in laboratory " << labName << "." << std::endl;
            }
        }
    }

    void displayLaboratoryInfo(std::string labName) {
        Laboratory* lab = findLaboratory(labName);
        if (lab != nullptr) {
            std::cout << "Laboratory: " << lab->labName << std::endl;
            lab->displayEquipment();
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addLaboratory("Physics Lab");
    ems.addLaboratory("Chemistry Lab");

    ems.addEquipmentToLab("Physics Lab", "Microscope", "Optical");
    ems.addEquipmentToLab("Physics Lab", "Oscilloscope", "Electronic");

    ems.displayLaboratoryInfo("Physics Lab");

    ems.updateEquipmentInLab("Physics Lab", "Microscope", "Digital Microscope", "Optical");

    ems.displayLaboratoryInfo("Physics Lab");

    ems.searchEquipmentInLab("Physics Lab", "Oscilloscope");

    ems.deleteEquipmentFromLab("Physics Lab", "Oscilloscope");

    ems.displayLaboratoryInfo("Physics Lab");

    return 0;
}