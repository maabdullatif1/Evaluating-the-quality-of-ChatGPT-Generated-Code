#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    std::string name;
    std::string type;
    int id;

    Equipment(int id, const std::string& name, const std::string& type)
        : id(id), name(name), type(type) {}
};

class Laboratory {
public:
    std::string name;
    int id;
    std::vector<Equipment> equipmentList;

    Laboratory(int id, const std::string& name) : id(id), name(name) {}

    void addEquipment(const Equipment& equipment) {
        equipmentList.push_back(equipment);
    }

    void deleteEquipment(int equipmentId) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == equipmentId) {
                equipmentList.erase(it);
                return;
            }
        }
    }

    void updateEquipment(int equipmentId, const std::string& newName, const std::string& newType) {
        for (auto& equipment : equipmentList) {
            if (equipment.id == equipmentId) {
                equipment.name = newName;
                equipment.type = newType;
                return;
            }
        }
    }

    Equipment* searchEquipment(int equipmentId) {
        for (auto& equipment : equipmentList) {
            if (equipment.id == equipmentId) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void display() {
        std::cout << "Laboratory ID: " << id << ", Name: " << name << std::endl;
        for (const auto& equipment : equipmentList) {
            std::cout << "  Equipment ID: " << equipment.id 
                      << ", Name: " << equipment.name 
                      << ", Type: " << equipment.type << std::endl;
        }
    }
};

class EquipmentManagementSystem {
    std::vector<Laboratory> labs;

public:
    void addLaboratory(const Laboratory& lab) {
        labs.push_back(lab);
    }

    void deleteLaboratory(int labId) {
        for (auto it = labs.begin(); it != labs.end(); ++it) {
            if (it->id == labId) {
                labs.erase(it);
                return;
            }
        }
    }

    Laboratory* searchLaboratory(int labId) {
        for (auto& lab : labs) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayAll() {
        for (const auto& lab : labs) {
            lab.display();
        }
    }
};

int main() {
    EquipmentManagementSystem system;

    Laboratory lab1(1, "Chem Lab");
    Laboratory lab2(2, "Physics Lab");

    system.addLaboratory(lab1);
    system.addLaboratory(lab2);

    Equipment eq1(101, "Microscope", "Optical");
    Equipment eq2(102, "Bunsen Burner", "Heating");

    lab1.addEquipment(eq1);
    lab1.addEquipment(eq2);

    system.displayAll();

    lab1.updateEquipment(101, "Advanced Microscope", "Optical");
    system.displayAll();

    lab1.deleteEquipment(102);
    system.displayAll();

    return 0;
}