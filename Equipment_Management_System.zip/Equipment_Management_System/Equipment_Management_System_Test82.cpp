#include <iostream>
#include <string>

using namespace std;

struct Equipment {
    string id;
    string name;
    string lab;
};

class EquipmentManagementSystem {
private:
    Equipment equipmentList[100];
    int count;

public:
    EquipmentManagementSystem() : count(0) {}

    void addEquipment(const string& id, const string& name, const string& lab) {
        equipmentList[count].id = id;
        equipmentList[count].name = name;
        equipmentList[count].lab = lab;
        count++;
    }

    void deleteEquipment(const string& id) {
        for (int i = 0; i < count; ++i) {
            if (equipmentList[i].id == id) {
                for (int j = i; j < count - 1; ++j) {
                    equipmentList[j] = equipmentList[j + 1];
                }
                count--;
                break;
            }
        }
    }

    void updateEquipment(const string& id, const string& newName, const string& newLab) {
        for (int i = 0; i < count; ++i) {
            if (equipmentList[i].id == id) {
                equipmentList[i].name = newName;
                equipmentList[i].lab = newLab;
                break;
            }
        }
    }

    Equipment* searchEquipment(const string& id) {
        for (int i = 0; i < count; ++i) {
            if (equipmentList[i].id == id) {
                return &equipmentList[i];
            }
        }
        return nullptr;
    }

    void displayEquipments() {
        for (int i = 0; i < count; ++i) {
            cout << "ID: " << equipmentList[i].id 
                 << ", Name: " << equipmentList[i].name 
                 << ", Lab: " << equipmentList[i].lab << endl;
        }
    }
};

int main() {
    EquipmentManagementSystem system;

    int choice;
    string id, name, lab;

    while (true) {
        cout << "1. Add Equipment" << endl;
        cout << "2. Delete Equipment" << endl;
        cout << "3. Update Equipment" << endl;
        cout << "4. Search Equipment" << endl;
        cout << "5. Display All Equipments" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter ID: ";
                cin >> id;
                cout << "Enter Name: ";
                cin >> name;
                cout << "Enter Lab: ";
                cin >> lab;
                system.addEquipment(id, name, lab);
                break;
            case 2:
                cout << "Enter ID: ";
                cin >> id;
                system.deleteEquipment(id);
                break;
            case 3:
                cout << "Enter ID: ";
                cin >> id;
                cout << "Enter New Name: ";
                cin >> name;
                cout << "Enter New Lab: ";
                cin >> lab;
                system.updateEquipment(id, name, lab);
                break;
            case 4:
                cout << "Enter ID: ";
                cin >> id;
                Equipment* equipment;
                equipment = system.searchEquipment(id);
                if (equipment) {
                    cout << "ID: " << equipment->id 
                         << ", Name: " << equipment->name 
                         << ", Lab: " << equipment->lab << endl;
                } else {
                    cout << "Equipment not found!" << endl;
                }
                break;
            case 5:
                system.displayEquipments();
                break;
            case 6:
                return 0;
            default:
                cout << "Invalid choice" << endl;
                break;
        }
    }

    return 0;
}