#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string manufacturer;
    int quantity;

    Equipment(int id, const std::string& name, const std::string& manufacturer, int quantity)
        : id(id), name(name), manufacturer(manufacturer), quantity(quantity) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;

    Laboratory(int id, const std::string& name)
        : id(id), name(name) {}

    void addEquipment(const Equipment& equipment) {
        equipments.push_back(equipment);
    }

    bool deleteEquipment(int equipmentId) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == equipmentId) {
                equipments.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateEquipment(int equipmentId, const std::string& name, const std::string& manufacturer, int quantity) {
        for (auto& equipment : equipments) {
            if (equipment.id == equipmentId) {
                equipment.name = name;
                equipment.manufacturer = manufacturer;
                equipment.quantity = quantity;
                return true;
            }
        }
        return false;
    }

    Equipment* searchEquipment(int equipmentId) {
        for (auto& equipment : equipments) {
            if (equipment.id == equipmentId) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void displayEquipments() const {
        for (const auto& equipment : equipments) {
            std::cout << "ID: " << equipment.id
                      << ", Name: " << equipment.name
                      << ", Manufacturer: " << equipment.manufacturer
                      << ", Quantity: " << equipment.quantity << std::endl;
        }
    }
};

class EquipmentManagementSystem {
public:
    std::vector<Laboratory> laboratories;

    Laboratory* searchLaboratory(int labId) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void addLaboratory(const Laboratory& laboratory) {
        laboratories.push_back(laboratory);
    }

    bool deleteLaboratory(int labId) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == labId) {
                laboratories.erase(it);
                return true;
            }
        }
        return false;
    }

    void updateLaboratory(int labId, const std::string& name) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                lab.name = name;
            }
        }
    }

    void displayLaboratories() const {
        for (const auto& lab : laboratories) {
            std::cout << "Lab ID: " << lab.id << ", Name: " << lab.name << std::endl;
            lab.displayEquipments();
        }
    }
};

int main() {
    EquipmentManagementSystem system;

    Laboratory lab1(1, "Physics Lab");
    lab1.addEquipment(Equipment(101, "Oscilloscope", "Tektronix", 5));
    lab1.addEquipment(Equipment(102, "Signal Generator", "Keysight", 3));

    system.addLaboratory(lab1);

    system.displayLaboratories();

    return 0;
}