#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string type;
    Equipment(int i, const std::string& n, const std::string& t) : id(i), name(n), type(t) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;
    Laboratory(int i, const std::string& n) : id(i), name(n) {}
};

class System {
    std::vector<Laboratory> labs;
    int equipmentCounter;
public:
    System() : equipmentCounter(0) {}

    void addLab(int id, const std::string& name) {
        labs.push_back(Laboratory(id, name));
    }

    void deleteLab(int id) {
        for (auto it = labs.begin(); it != labs.end(); ++it) {
            if (it->id == id) {
                labs.erase(it);
                return;
            }
        }
    }

    void addEquipment(int labId, const std::string& name, const std::string& type) {
        for (auto& lab : labs) {
            if (lab.id == labId) {
                lab.equipments.emplace_back(++equipmentCounter, name, type);
                return;
            }
        }
    }

    void deleteEquipment(int labId, int equipId) {
        for (auto& lab : labs) {
            if (lab.id == labId) {
                for (auto it = lab.equipments.begin(); it != lab.equipments.end(); ++it) {
                    if (it->id == equipId) {
                        lab.equipments.erase(it);
                        return;
                    }
                }
            }
        }
    }

    void updateEquipment(int labId, int equipId, const std::string& name, const std::string& type) {
        for (auto& lab : labs) {
            if (lab.id == labId) {
                for (auto& equip : lab.equipments) {
                    if (equip.id == equipId) {
                        equip.name = name;
                        equip.type = type;
                        return;
                    }
                }
            }
        }
    }

    Equipment* searchEquipment(int equipId) {
        for (auto& lab : labs) {
            for (auto& equip : lab.equipments) {
                if (equip.id == equipId) {
                    return &equip;
                }
            }
        }
        return nullptr;
    }

    Laboratory* searchLaboratory(int labId) {
        for (auto& lab : labs) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLabs() {
        for (const auto& lab : labs) {
            std::cout << "Lab ID: " << lab.id << ", Name: " << lab.name << "\n";
            for (const auto& equip : lab.equipments) {
                std::cout << "  Equipment ID: " << equip.id << ", Name: " << equip.name << ", Type: " << equip.type << "\n";
            }
        }
    }
};

int main() {
    System system;
    system.addLab(1, "Physics Lab");
    system.addLab(2, "Chemistry Lab");
    system.addEquipment(1, "Oscilloscope", "Electronic");
    system.addEquipment(1, "Microscope", "Optical");
    system.addEquipment(2, "Beaker", "Glassware");
    system.updateEquipment(1, 1, "Digital Oscilloscope", "Electronic");
    system.displayLabs();
    system.deleteEquipment(1, 2);
    system.displayLabs();
    return 0;
}