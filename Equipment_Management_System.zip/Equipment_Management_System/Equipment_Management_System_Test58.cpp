#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    Equipment(const std::string& name, const std::string& id)
        : name(name), id(id) {}

    std::string getName() const { return name; }
    std::string getId() const { return id; }

    void update(const std::string& newName) { name = newName; }

private:
    std::string name;
    std::string id;
};

class Laboratory {
public:
    Laboratory(const std::string& name) : name(name) {}

    void addEquipment(const std::string& eqName, const std::string& eqId) {
        equipments.emplace_back(eqName, eqId);
    }

    bool deleteEquipment(const std::string& eqId) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->getId() == eqId) {
                equipments.erase(it);
                return true;
            }
        }
        return false;
    }

    Equipment* searchEquipment(const std::string& eqId) {
        for (auto& eq : equipments) {
            if (eq.getId() == eqId) return &eq;
        }
        return nullptr;
    }

    void updateEquipment(const std::string& eqId, const std::string& newName) {
        for (auto& eq : equipments) {
            if (eq.getId() == eqId) {
                eq.update(newName);
                return;
            }
        }
    }

    void display() const {
        std::cout << "Laboratory: " << name << std::endl;
        for (const auto& eq : equipments) {
            std::cout << "  Equipment ID: " << eq.getId() << ", Name: " << eq.getName() << std::endl;
        }
    }

private:
    std::string name;
    std::vector<Equipment> equipments;
};

class EquipmentManagementSystem {
public:
    void addLaboratory(const std::string& labName) {
        laboratories.emplace_back(labName);
    }

    Laboratory* searchLaboratory(const std::string& labName) {
        for (auto& lab : laboratories) {
            if (lab.getName() == labName) return &lab;
        }
        return nullptr;
    }

    void display() const {
        for (const auto& lab : laboratories) {
            lab.display();
        }
    }

private:
    std::vector<Laboratory> laboratories;
};

int main() {
    EquipmentManagementSystem ems;

    ems.addLaboratory("Physics Lab");
    ems.addLaboratory("Chemistry Lab");

    Laboratory* physicsLab = ems.searchLaboratory("Physics Lab");
    if (physicsLab) {
        physicsLab->addEquipment("Oscilloscope", "EQ123");
        physicsLab->addEquipment("Voltmeter", "EQ124");
    }

    Laboratory* chemLab = ems.searchLaboratory("Chemistry Lab");
    if (chemLab) {
        chemLab->addEquipment("Bunsen Burner", "EQ223");
    }

    std::cout << "Equipment Management System:" << std::endl;
    ems.display();

    if (physicsLab) {
        physicsLab->updateEquipment("EQ124", "Digital Voltmeter");
    }

    Equipment* eq = chemLab->searchEquipment("EQ223");
    if (eq) {
        std::cout << "Found equipment in Chemistry Lab: " << eq->getName() << std::endl;
        chemLab->deleteEquipment("EQ223");
    }

    std::cout << "\nAfter updates:" << std::endl;
    ems.display();

    return 0;
}