#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    Equipment(std::string name, std::string lab, int id)
        : name(name), lab(lab), id(id) {}

    std::string getName() const {
        return name;
    }

    std::string getLab() const {
        return lab;
    }

    int getId() const {
        return id;
    }

    void setName(const std::string& newName) {
        name = newName;
    }

    void setLab(const std::string& newLab) {
        lab = newLab;
    }

private:
    std::string name;
    std::string lab;
    int id;
};

class EquipmentManager {
public:
    void addEquipment(const std::string& name, const std::string& lab, int id) {
        equipmentList.push_back(Equipment(name, lab, id));
    }

    void deleteEquipment(int id) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->getId() == id) {
                equipmentList.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int id, const std::string& newName, const std::string& newLab) {
        for (auto& equipment : equipmentList) {
            if (equipment.getId() == id) {
                equipment.setName(newName);
                equipment.setLab(newLab);
                break;
            }
        }
    }

    Equipment* searchEquipment(int id) {
        for (auto& equipment : equipmentList) {
            if (equipment.getId() == id) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void displayEquipment() const {
        for (const auto& equipment : equipmentList) {
            std::cout << "ID: " << equipment.getId()
                      << ", Name: " << equipment.getName()
                      << ", Lab: " << equipment.getLab() << std::endl;
        }
    }

private:
    std::vector<Equipment> equipmentList;
};

int main() {
    EquipmentManager manager;
    int choice, id;
    std::string name, lab;
    
    while (true) {
        std::cout << "1. Add Equipment" << std::endl;
        std::cout << "2. Delete Equipment" << std::endl;
        std::cout << "3. Update Equipment" << std::endl;
        std::cout << "4. Search Equipment" << std::endl;
        std::cout << "5. Display All Equipment" << std::endl;
        std::cout << "6. Exit" << std::endl;
        std::cout << "Enter your choice: ";
        std::cin >> choice;
        
        switch (choice) {
        case 1:
            std::cout << "Enter ID, Name, and Lab: ";
            std::cin >> id >> name >> lab;
            manager.addEquipment(name, lab, id);
            break;
        case 2:
            std::cout << "Enter ID to delete: ";
            std::cin >> id;
            manager.deleteEquipment(id);
            break;
        case 3:
            std::cout << "Enter ID to update: ";
            std::cin >> id;
            std::cout << "Enter new Name and Lab: ";
            std::cin >> name >> lab;
            manager.updateEquipment(id, name, lab);
            break;
        case 4:
            std::cout << "Enter ID to search: ";
            std::cin >> id;
            if (auto* equipment = manager.searchEquipment(id)) {
                std::cout << "Found Equipment: "
                          << "ID: " << equipment->getId()
                          << ", Name: " << equipment->getName()
                          << ", Lab: " << equipment->getLab() << std::endl;
            } else {
                std::cout << "Equipment not found." << std::endl;
            }
            break;
        case 5:
            manager.displayEquipment();
            break;
        case 6:
            return 0;
        default:
            std::cout << "Invalid choice. Please try again." << std::endl;
        }
    }
}