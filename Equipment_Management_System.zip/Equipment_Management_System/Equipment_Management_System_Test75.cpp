#include <iostream>
#include <string>
#include <vector>

struct Equipment {
    int id;
    std::string name;
    std::string status;
};

struct Laboratory {
    int id;
    std::string name;
    std::vector<Equipment> equipments;
};

class ManagementSystem {
private:
    std::vector<Laboratory> laboratories;
    int equipCounter = 0;
    int labCounter = 0;

    Laboratory* findLaboratory(int id) {
        for (auto& lab : laboratories) {
            if (lab.id == id) {
                return &lab;
            }
        }
        return nullptr;
    }

    Equipment* findEquipmentInLab(Laboratory& lab, int equipId) {
        for (auto& equip : lab.equipments) {
            if (equip.id == equipId) {
                return &equip;
            }
        }
        return nullptr;
    }

public:
    void addLaboratory(const std::string& labName) {
        Laboratory lab;
        lab.id = ++labCounter;
        lab.name = labName;
        laboratories.push_back(lab);
        std::cout << "Laboratory added: " << labName << "\n";
    }

    void deleteLaboratory(int labId) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == labId) {
                laboratories.erase(it);
                std::cout << "Laboratory deleted.\n";
                return;
            }
        }
        std::cout << "Laboratory not found.\n";
    }

    void addEquipmentToLab(int labId, const std::string& equipName, const std::string& status) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) {
            Equipment equip;
            equip.id = ++equipCounter;
            equip.name = equipName;
            equip.status = status;
            lab->equipments.push_back(equip);
            std::cout << "Equipment added: " << equipName << "\n";
        } else {
            std::cout << "Laboratory not found.\n";
        }
    }

    void updateEquipmentStatus(int labId, int equipId, const std::string& newStatus) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) {
            Equipment* equip = findEquipmentInLab(*lab, equipId);
            if (equip) {
                equip->status = newStatus;
                std::cout << "Equipment status updated.\n";
            } else {
                std::cout << "Equipment not found.\n";
            }
        } else {
            std::cout << "Laboratory not found.\n";
        }
    }

    void deleteEquipmentFromLab(int labId, int equipId) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) {
            for (auto it = lab->equipments.begin(); it != lab->equipments.end(); ++it) {
                if (it->id == equipId) {
                    lab->equipments.erase(it);
                    std::cout << "Equipment deleted.\n";
                    return;
                }
            }
            std::cout << "Equipment not found.\n";
        } else {
            std::cout << "Laboratory not found.\n";
        }
    }

    void displayLaboratories() {
        for (const auto& lab : laboratories) {
            std::cout << "Lab ID: " << lab.id << ", Name: " << lab.name << "\n";
            for (const auto& equip : lab.equipments) {
                std::cout << "  Equipment ID: " << equip.id << ", Name: " << equip.name << ", Status: " << equip.status << "\n";
            }
        }
    }
};

int main() {
    ManagementSystem system;
    system.addLaboratory("Physics Lab");
    system.addLaboratory("Chemistry Lab");
    system.addEquipmentToLab(1, "Microscope", "Available");
    system.addEquipmentToLab(1, "Telescope", "In Use");
    system.updateEquipmentStatus(1, 2, "Available");
    system.displayLaboratories();
    system.deleteEquipmentFromLab(1, 2);
    system.deleteLaboratory(2);
    system.displayLaboratories();
    return 0;
}