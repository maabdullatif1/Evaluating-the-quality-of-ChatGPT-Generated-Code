#include <iostream>
#include <string>
using namespace std;

struct Equipment {
    int id;
    string name;
    string description;
};

struct Laboratory {
    int id;
    string name;
    string location;
    Equipment equipmentList[100];
    int equipmentCount;
};

class EquipmentManagementSystem {
private:
    Laboratory labs[100];
    int labCount;
public:
    EquipmentManagementSystem() : labCount(0) {}

    void addLaboratory(int id, string name, string location) {
        if(labCount < 100) {
            labs[labCount++] = {id, name, location, {}, 0};
        }
    }

    void addEquipment(int labId, int equipmentId, string name, string description) {
        for (int i = 0; i < labCount; ++i) {
            if (labs[i].id == labId && labs[i].equipmentCount < 100) {
                labs[i].equipmentList[labs[i].equipmentCount++] = {equipmentId, name, description};
                break;
            }
        }
    }

    void deleteLaboratory(int id) {
        for (int i = 0; i < labCount; ++i) {
            if (labs[i].id == id) {
                labs[i] = labs[--labCount];
                break;
            }
        }
    }

    void deleteEquipment(int labId, int equipmentId) {
        for (int i = 0; i < labCount; ++i) {
            if (labs[i].id == labId) {
                for (int j = 0; j < labs[i].equipmentCount; ++j) {
                    if (labs[i].equipmentList[j].id == equipmentId) {
                        labs[i].equipmentList[j] = labs[i].equipmentList[--labs[i].equipmentCount];
                        break;
                    }
                }
            }
        }
    }

    void updateLaboratory(int id, string name, string location) {
        for (int i = 0; i < labCount; ++i) {
            if (labs[i].id == id) {
                labs[i].name = name;
                labs[i].location = location;
                break;
            }
        }
    }

    void updateEquipment(int labId, int equipmentId, string name, string description) {
        for (int i = 0; i < labCount; ++i) {
            if (labs[i].id == labId) {
                for (int j = 0; j < labs[i].equipmentCount; ++j) {
                    if (labs[i].equipmentList[j].id == equipmentId) {
                        labs[i].equipmentList[j].name = name;
                        labs[i].equipmentList[j].description = description;
                        break;
                    }
                }
            }
        }
    }

    void searchLaboratory(int id) {
        for (int i = 0; i < labCount; ++i) {
            if (labs[i].id == id) {
                cout << "Lab ID: " << labs[i].id << ", Name: " << labs[i].name << ", Location: " << labs[i].location << endl;
                break;
            }
        }
    }

    void searchEquipment(int labId, int equipmentId) {
        for (int i = 0; i < labCount; ++i) {
            if (labs[i].id == labId) {
                for (int j = 0; j < labs[i].equipmentCount; ++j) {
                    if (labs[i].equipmentList[j].id == equipmentId) {
                        cout << "Equipment ID: " << labs[i].equipmentList[j].id
                             << ", Name: " << labs[i].equipmentList[j].name
                             << ", Description: " << labs[i].equipmentList[j].description << endl;
                        break;
                    }
                }
                break;
            }
        }
    }

    void displayLaboratories() {
        for (int i = 0; i < labCount; ++i) {
            cout << "Lab ID: " << labs[i].id << ", Name: " << labs[i].name << ", Location: " << labs[i].location << endl;
        }
    }

    void displayEquipments(int labId) {
        for (int i = 0; i < labCount; ++i) {
            if (labs[i].id == labId) {
                for (int j = 0; j < labs[i].equipmentCount; ++j) {
                    cout << "Equipment ID: " << labs[i].equipmentList[j].id
                         << ", Name: " << labs[i].equipmentList[j].name
                         << ", Description: " << labs[i].equipmentList[j].description << endl;
                }
                break;
            }
        }
    }
};

int main() {
    EquipmentManagementSystem system;
    system.addLaboratory(1, "Physics Lab", "Building A");
    system.addEquipment(1, 101, "Microscope", "Used for viewing small objects");
    system.displayLaboratories();
    system.displayEquipments(1);
    return 0;
}