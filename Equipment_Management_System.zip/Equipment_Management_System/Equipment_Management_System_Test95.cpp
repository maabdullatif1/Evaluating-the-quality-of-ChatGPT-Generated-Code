#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string type;

    Equipment(int i, std::string n, std::string t) : id(i), name(n), type(t) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;

    Laboratory(int i, std::string n) : id(i), name(n) {}

    void addEquipment(const Equipment& equipment) {
        equipments.push_back(equipment);
    }

    void removeEquipment(int equipmentId) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == equipmentId) {
                equipments.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int equipmentId, const std::string& newName, const std::string& newType) {
        for (auto& equipment : equipments) {
            if (equipment.id == equipmentId) {
                equipment.name = newName;
                equipment.type = newType;
                break;
            }
        }
    }

    Equipment* searchEquipment(int equipmentId) {
        for (auto& equipment : equipments) {
            if (equipment.id == equipmentId)
                return &equipment;
        }
        return nullptr;
    }

    void displayEquipments() {
        for (const auto& equipment : equipments) {
            std::cout << "Equipment ID: " << equipment.id << ", Name: " << equipment.name 
                      << ", Type: " << equipment.type << std::endl;
        }
    }
};

class EquipmentManagementSystem {
public:
    std::vector<Laboratory> laboratories;

    void addLaboratory(int id, const std::string& name) {
        laboratories.emplace_back(id, name);
    }

    void deleteLaboratory(int id) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == id) {
                laboratories.erase(it);
                break;
            }
        }
    }

    void updateLaboratory(int id, const std::string& newName) {
        for (auto& lab : laboratories) {
            if (lab.id == id) {
                lab.name = newName;
                break;
            }
        }
    }

    Laboratory* searchLaboratory(int id) {
        for (auto& lab : laboratories) {
            if (lab.id == id)
                return &lab;
        }
        return nullptr;
    }

    void displayLaboratories() {
        for (const auto& lab : laboratories) {
            std::cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << std::endl;
            lab.displayEquipments();
        }
    }
};

int main() {
    EquipmentManagementSystem ems;

    ems.addLaboratory(1, "Physics Lab");
    ems.addLaboratory(2, "Chemistry Lab");

    Laboratory* lab = ems.searchLaboratory(1);
    if (lab) {
        lab->addEquipment(Equipment(101, "Oscilloscope", "Measurement"));
        lab->addEquipment(Equipment(102, "Voltmeter", "Measurement"));
    }

    lab = ems.searchLaboratory(2);
    if (lab) {
        lab->addEquipment(Equipment(201, "Burette", "Glassware"));
        lab->addEquipment(Equipment(202, "Pipette", "Glassware"));
    }

    ems.displayLaboratories();

    return 0;
}