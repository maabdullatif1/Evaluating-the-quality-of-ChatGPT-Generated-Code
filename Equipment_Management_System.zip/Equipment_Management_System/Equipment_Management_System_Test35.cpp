#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    Equipment(int id, std::string name) : id(id), name(name) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    Laboratory(int id, std::string name) : id(id), name(name) {}
};

class ManagementSystem {
private:
    std::vector<Equipment> equipments;
    std::vector<Laboratory> laboratories;

    template<typename T>
    static typename std::vector<T>::iterator findItemById(std::vector<T>& items, int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                return it;
            }
        }
        return items.end();
    }

public:
    void addEquipment(int id, std::string name) {
        equipments.push_back(Equipment(id, name));
    }

    void deleteEquipment(int id) {
        auto it = findItemById(equipments, id);
        if (it != equipments.end()) {
            equipments.erase(it);
        }
    }

    void updateEquipment(int id, std::string newName) {
        auto it = findItemById(equipments, id);
        if (it != equipments.end()) {
            it->name = newName;
        }
    }

    void searchEquipment(int id) {
        auto it = findItemById(equipments, id);
        if (it != equipments.end()) {
            std::cout << "Equipment ID: " << it->id << ", Name: " << it->name << std::endl;
        } else {
            std::cout << "Equipment not found." << std::endl;
        }
    }

    void displayEquipments() {
        for (const auto& equipment : equipments) {
            std::cout << "Equipment ID: " << equipment.id << ", Name: " << equipment.name << std::endl;
        }
    }

    void addLaboratory(int id, std::string name) {
        laboratories.push_back(Laboratory(id, name));
    }

    void deleteLaboratory(int id) {
        auto it = findItemById(laboratories, id);
        if (it != laboratories.end()) {
            laboratories.erase(it);
        }
    }

    void updateLaboratory(int id, std::string newName) {
        auto it = findItemById(laboratories, id);
        if (it != laboratories.end()) {
            it->name = newName;
        }
    }

    void searchLaboratory(int id) {
        auto it = findItemById(laboratories, id);
        if (it != laboratories.end()) {
            std::cout << "Laboratory ID: " << it->id << ", Name: " << it->name << std::endl;
        } else {
            std::cout << "Laboratory not found." << std::endl;
        }
    }

    void displayLaboratories() {
        for (const auto& laboratory : laboratories) {
            std::cout << "Laboratory ID: " << laboratory.id << ", Name: " << laboratory.name << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;

    system.addEquipment(1, "Microscope");
    system.addEquipment(2, "Centrifuge");
    system.addLaboratory(1, "Biology Lab");
    system.addLaboratory(2, "Chemistry Lab");

    system.displayEquipments();
    system.displayLaboratories();

    system.searchEquipment(1);
    system.updateEquipment(1, "Updated Microscope");
    system.searchEquipment(1);

    system.deleteEquipment(2);
    system.displayEquipments();

    system.searchLaboratory(2);
    system.updateLaboratory(2, "Updated Chemistry Lab");
    system.searchLaboratory(2);

    system.deleteLaboratory(1);
    system.displayLaboratories();

    return 0;
}