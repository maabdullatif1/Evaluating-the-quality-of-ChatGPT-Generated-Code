#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Equipment {
public:
    string name;
    string id;
    string laboratory;

    Equipment(string n, string i, string l) : name(n), id(i), laboratory(l) {}
};

class EquipmentManagementSystem {
private:
    vector<Equipment> equipments;

public:
    void addEquipment(const string& name, const string& id, const string& laboratory) {
        equipments.push_back(Equipment(name, id, laboratory));
    }

    bool deleteEquipment(const string& id) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == id) {
                equipments.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateEquipment(const string& id, const string& newName, const string& newLaboratory) {
        for (auto& equipment : equipments) {
            if (equipment.id == id) {
                equipment.name = newName;
                equipment.laboratory = newLaboratory;
                return true;
            }
        }
        return false;
    }

    Equipment* searchEquipment(const string& id) {
        for (auto& equipment : equipments) {
            if (equipment.id == id) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void displayEquipments() {
        for (const auto& equipment : equipments) {
            cout << "Name: " << equipment.name
                 << ", ID: " << equipment.id
                 << ", Laboratory: " << equipment.laboratory << endl;
        }
    }
};

int main() {
    EquipmentManagementSystem system;
    int choice;
    string name, id, laboratory;

    while (true) {
        cout << "1. Add Equipment\n2. Delete Equipment\n3. Update Equipment\n4. Search Equipment\n5. Display All\n6. Exit\n";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter Name, ID and Laboratory: ";
                cin >> name >> id >> laboratory;
                system.addEquipment(name, id, laboratory);
                break;
            case 2:
                cout << "Enter ID: ";
                cin >> id;
                if (system.deleteEquipment(id)) {
                    cout << "Equipment deleted\n";
                } else {
                    cout << "Equipment not found\n";
                }
                break;
            case 3:
                cout << "Enter ID, New Name and New Laboratory: ";
                cin >> id >> name >> laboratory;
                if (system.updateEquipment(id, name, laboratory)) {
                    cout << "Equipment updated\n";
                } else {
                    cout << "Equipment not found\n";
                }
                break;
            case 4:
                cout << "Enter ID: ";
                cin >> id;
                Equipment* equipment = system.searchEquipment(id);
                if (equipment) {
                    cout << "Name: " << equipment->name
                         << ", ID: " << equipment->id
                         << ", Laboratory: " << equipment->laboratory << endl;
                } else {
                    cout << "Equipment not found\n";
                }
                break;
            case 5:
                system.displayEquipments();
                break;
            case 6:
                return 0;
            default:
                cout << "Invalid choice\n";
        }
    }
}