#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string labName;

    Equipment(int id, string name, string labName) : id(id), name(name), labName(labName) {}
};

class Lab {
public:
    int id;
    string name;

    Lab(int id, string name) : id(id), name(name) {}
};

class ManagementSystem {
private:
    vector<Equipment> equipments;
    vector<Lab> labs;
    int equipIdCounter;
    int labIdCounter;

public:
    ManagementSystem() : equipIdCounter(0), labIdCounter(0) {}

    void addEquipment(string name, string labName) {
        equipments.push_back(Equipment(++equipIdCounter, name, labName));
    }

    void deleteEquipment(int id) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == id) {
                equipments.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int id, string newName, string newLabName) {
        for (auto &e : equipments) {
            if (e.id == id) {
                e.name = newName;
                e.labName = newLabName;
                break;
            }
        }
    }

    Equipment* searchEquipment(int id) {
        for (auto &e : equipments) {
            if (e.id == id) {
                return &e;
            }
        }
        return nullptr;
    }

    void displayAllEquipments() {
        for (auto &e : equipments) {
            cout << "Equipment ID: " << e.id << ", Name: " << e.name << ", Lab: " << e.labName << endl;
        }
    }

    void addLab(string name) {
        labs.push_back(Lab(++labIdCounter, name));
    }

    void deleteLab(int id) {
        for (auto it = labs.begin(); it != labs.end(); ++it) {
            if (it->id == id) {
                labs.erase(it);
                break;
            }
        }
    }

    void updateLab(int id, string newName) {
        for (auto &l : labs) {
            if (l.id == id) {
                l.name = newName;
                break;
            }
        }
    }

    Lab* searchLab(int id) {
        for (auto &l : labs) {
            if (l.id == id) {
                return &l;
            }
        }
        return nullptr;
    }

    void displayAllLabs() {
        for (auto &l : labs) {
            cout << "Lab ID: " << l.id << ", Name: " << l.name << endl;
        }
    }
};

int main() {
    ManagementSystem ms;
    
    ms.addLab("Physics Lab");
    ms.addLab("Chemistry Lab");
    
    ms.addEquipment("Microscope", "Physics Lab");
    ms.addEquipment("Bunsen Burner", "Chemistry Lab");
    
    ms.displayAllLabs();
    ms.displayAllEquipments();

    Lab* lab = ms.searchLab(1);
    if (lab != nullptr) {
        cout << "Found Lab: " << lab->name << endl;
    }

    Equipment* equipment = ms.searchEquipment(1);
    if (equipment != nullptr) {
        cout << "Found Equipment: " << equipment->name << " in " << equipment->labName << endl;
    }

    ms.updateLab(1, "Advanced Physics Lab");
    ms.updateEquipment(1, "Advanced Microscope", "Advanced Physics Lab");

    ms.displayAllLabs();
    ms.displayAllEquipments();

    ms.deleteEquipment(2);
    ms.deleteLab(2);

    ms.displayAllLabs();
    ms.displayAllEquipments();

    return 0;
}