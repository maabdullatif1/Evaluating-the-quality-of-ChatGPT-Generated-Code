#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string description;
    
    Equipment(int id, string name, string desc) : id(id), name(name), description(desc) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipments;

    Laboratory(int id, string name) : id(id), name(name) {}
    
    void addEquipment(int eid, string ename, string edesc) {
        equipments.push_back(Equipment(eid, ename, edesc));
    }
    
    bool removeEquipment(int eid) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == eid) {
                equipments.erase(it);
                return true;
            }
        }
        return false;
    }
    
    void displayEquipments() {
        for (const auto& equipment : equipments) {
            cout << "Equipment ID: " << equipment.id << ", Name: " << equipment.name 
                 << ", Description: " << equipment.description << endl;
        }
    }
};

class EquipmentManagementSystem {
private:
    vector<Laboratory> laboratories;
    
public:
    
    void addLaboratory(int lid, string lname) {
        laboratories.push_back(Laboratory(lid, lname));
    }
    
    bool removeLaboratory(int lid) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == lid) {
                laboratories.erase(it);
                return true;
            }
        }
        return false;
    }

    Laboratory* findLaboratory(int lid) {
        for (auto& lab : laboratories) {
            if (lab.id == lid) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLaboratories() {
        for (const auto& lab : laboratories) {
            cout << "Lab ID: " << lab.id << ", Name: " << lab.name << endl;
            lab.displayEquipments();
        }
    }
    
    void updateEquipment(int lid, int eid, string newName, string newDesc) {
        Laboratory* lab = findLaboratory(lid);
        if (lab != nullptr) {
            for (auto& equipment : lab->equipments) {
                if (equipment.id == eid) {
                    equipment.name = newName;
                    equipment.description = newDesc;
                }
            }
        }
    }
    
    void searchEquipment(int eid) {
        for (const auto& lab : laboratories) {
            for (const auto& equipment : lab.equipments) {
                if (equipment.id == eid) {
                    cout << "Found in Lab ID: " << lab.id << ", Lab Name: " << lab.name 
                         << ", Equipment ID: " << equipment.id << ", Name: " << equipment.name 
                         << ", Description: " << equipment.description << endl;
                }
            }
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    
    ems.addLaboratory(1, "Physics Lab");
    ems.addLaboratory(2, "Chemistry Lab");
    
    Laboratory* lab = ems.findLaboratory(1);
    if (lab != nullptr) {
        lab->addEquipment(101, "Laser", "High intensity laser");
        lab->addEquipment(102, "Microscope", "High resolution microscope");
    }
    
    lab = ems.findLaboratory(2);
    if (lab != nullptr) {
        lab->addEquipment(201, "Beaker", "Glass beaker");
    }
    
    ems.displayLaboratories();
    
    cout << endl << "Updating Equipment..." << endl;
    ems.updateEquipment(1, 101, "Updated Laser", "Updated high intensity laser");
    ems.displayLaboratories();
    
    cout << endl << "Searching Equipment..." << endl;
    ems.searchEquipment(102);
    
    cout << endl << "Removing Equipment..." << endl;
    lab = ems.findLaboratory(1);
    if (lab != nullptr) {
        lab->removeEquipment(102);
    }
    ems.displayLaboratories();
    
    return 0;
}