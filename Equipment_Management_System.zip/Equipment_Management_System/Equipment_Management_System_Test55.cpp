#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string description;

    Equipment(int eid, std::string ename, std::string edescription)
        : id(eid), name(ename), description(edescription) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipmentList;

    Laboratory(int lid, std::string lname)
        : id(lid), name(lname) {}
};

class EquipmentManagementSystem {
private:
    std::vector<Equipment> equipmentData;
    std::vector<Laboratory> laboratoryData;

public:
    void addEquipment(int id, std::string name, std::string description) {
        equipmentData.push_back(Equipment(id, name, description));
    }

    void deleteEquipment(int id) {
        for (auto it = equipmentData.begin(); it != equipmentData.end(); ++it) {
            if (it->id == id) {
                equipmentData.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int id, std::string name, std::string description) {
        for (auto &equipment : equipmentData) {
            if (equipment.id == id) {
                equipment.name = name;
                equipment.description = description;
                break;
            }
        }
    }

    Equipment* searchEquipment(int id) {
        for (auto &equipment : equipmentData) {
            if (equipment.id == id) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void displayEquipments() {
        for (auto &equipment : equipmentData) {
            std::cout << "ID: " << equipment.id << ", Name: " << equipment.name << ", Description: " << equipment.description << std::endl;
        }
    }

    void addLaboratory(int id, std::string name) {
        laboratoryData.push_back(Laboratory(id, name));
    }

    void deleteLaboratory(int id) {
        for (auto it = laboratoryData.begin(); it != laboratoryData.end(); ++it) {
            if (it->id == id) {
                laboratoryData.erase(it);
                break;
            }
        }
    }

    void updateLaboratory(int id, std::string name) {
        for (auto &lab : laboratoryData) {
            if (lab.id == id) {
                lab.name = name;
                break;
            }
        }
    }

    Laboratory* searchLaboratory(int id) {
        for (auto &lab : laboratoryData) {
            if (lab.id == id) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLaboratories() {
        for (auto &lab : laboratoryData) {
            std::cout << "ID: " << lab.id << ", Name: " << lab.name << std::endl;
            for (auto &eq : lab.equipmentList) {
                std::cout << "  Equipment - ID: " << eq.id << ", Name: " << eq.name << ", Description: " << eq.description << std::endl;
            }
        }
    }

    void addEquipmentToLab(int labId, Equipment equipment) {
        for (auto &lab : laboratoryData) {
            if (lab.id == labId) {
                lab.equipmentList.push_back(equipment);
                break;
            }
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addEquipment(1, "Microscope", "Used for magnifying objects.");
    ems.addEquipment(2, "Centrifuge", "Used to separate liquids.");

    ems.addLaboratory(1, "Biology Lab");
    ems.addLaboratory(2, "Chemistry Lab");

    ems.addEquipmentToLab(1, Equipment(1, "Microscope", "Used for magnifying objects."));
    ems.addEquipmentToLab(2, Equipment(2, "Centrifuge", "Used to separate liquids."));

    std::cout << "Equipments:" << std::endl;
    ems.displayEquipments();

    std::cout << "Laboratories:" << std::endl;
    ems.displayLaboratories();

    return 0;
}