#include <iostream>
#include <string>

using namespace std;

struct Equipment {
    int id;
    string name;
    string description;
};

struct Laboratory {
    int id;
    string name;
    Equipment equipments[10];
    int equipmentCount;
};

Laboratory labs[10];
int labCount = 0;

void addLab(int id, string name) {
    labs[labCount].id = id;
    labs[labCount].name = name;
    labs[labCount].equipmentCount = 0;
    labCount++;
}

void addEquipment(int labId, int equipId, string name, string description) {
    for (int i = 0; i < labCount; i++) {
        if (labs[i].id == labId && labs[i].equipmentCount < 10) {
            labs[i].equipments[labs[i].equipmentCount].id = equipId;
            labs[i].equipments[labs[i].equipmentCount].name = name;
            labs[i].equipments[labs[i].equipmentCount].description = description;
            labs[i].equipmentCount++;
            return;
        }
    }
}

void deleteEquipment(int labId, int equipId) {
    for (int i = 0; i < labCount; i++) {
        if (labs[i].id == labId) {
            for (int j = 0; j < labs[i].equipmentCount; j++) {
                if (labs[i].equipments[j].id == equipId) {
                    for (int k = j; k < labs[i].equipmentCount - 1; k++) {
                        labs[i].equipments[k] = labs[i].equipments[k + 1];
                    }
                    labs[i].equipmentCount--;
                    return;
                }
            }
        }
    }
}

void updateEquipment(int labId, int equipId, string newName, string newDescription) {
    for (int i = 0; i < labCount; i++) {
        if (labs[i].id == labId) {
            for (int j = 0; j < labs[i].equipmentCount; j++) {
                if (labs[i].equipments[j].id == equipId) {
                    labs[i].equipments[j].name = newName;
                    labs[i].equipments[j].description = newDescription;
                    return;
                }
            }
        }
    }
}

void searchEquipment(int equipId) {
    for (int i = 0; i < labCount; i++) {
        for (int j = 0; j < labs[i].equipmentCount; j++) {
            if (labs[i].equipments[j].id == equipId) {
                cout << "Lab: " << labs[i].name << ", Equipment: " << labs[i].equipments[j].name << ", Description: " << labs[i].equipments[j].description << endl;
                return;
            }
        }
    }
    cout << "Equipment not found" << endl;
}

void displayLabs() {
    for (int i = 0; i < labCount; i++) {
        cout << "Lab ID: " << labs[i].id << ", Name: " << labs[i].name << endl;
        for (int j = 0; j < labs[i].equipmentCount; j++) {
            cout << "  Equipment ID: " << labs[i].equipments[j].id << ", Name: " << labs[i].equipments[j].name << ", Description: " << labs[i].equipments[j].description << endl;
        }
    }
}

int main() {
    addLab(1, "Physics Lab");
    addLab(2, "Chemistry Lab");

    addEquipment(1, 101, "Microscope", "Optical instrument used to see small objects");
    addEquipment(1, 102, "Telescope", "Instrument used to observe distant objects");
    addEquipment(2, 201, "Bunsen Burner", "Gas burner used in labs");

    displayLabs();

    updateEquipment(1, 101, "Electron Microscope", "Advanced type of microscope");
    searchEquipment(101);

    deleteEquipment(1, 102);
    displayLabs();

    return 0;
}