#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Equipment {
    int id;
    string name;
    string type;
};

struct Laboratory {
    int id;
    string name;
    vector<Equipment> equipmentList;
};

class EquipmentManagementSystem {
private:
    vector<Laboratory> laboratories;
    
    Laboratory* findLaboratoryById(int labId) {
        for (auto& lab : laboratories) {
            if (lab.id == labId)
                return &lab;
        }
        return nullptr;
    }

public:
    void addLaboratory(int id, string name) {
        laboratories.push_back({id, name, {}});
    }
    
    void removeLaboratory(int id) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == id) {
                laboratories.erase(it);
                break;
            }
        }
    }
    
    void updateLaboratory(int id, string name) {
        Laboratory* lab = findLaboratoryById(id);
        if (lab) {
            lab->name = name;
        }
    }

    void addEquipment(int labId, int equipmentId, string name, string type) {
        Laboratory* lab = findLaboratoryById(labId);
        if (lab) {
            lab->equipmentList.push_back({equipmentId, name, type});
        }
    }
    
    void removeEquipment(int labId, int equipmentId) {
        Laboratory* lab = findLaboratoryById(labId);
        if (lab) {
            for (auto it = lab->equipmentList.begin(); it != lab->equipmentList.end(); ++it) {
                if (it->id == equipmentId) {
                    lab->equipmentList.erase(it);
                    break;
                }
            }
        }
    }
    
    void updateEquipment(int labId, int equipmentId, string name, string type) {
        Laboratory* lab = findLaboratoryById(labId);
        if (lab) {
            for (auto& eq : lab->equipmentList) {
                if (eq.id == equipmentId) {
                    eq.name = name;
                    eq.type = type;
                    break;
                }
            }
        }
    }
    
    void searchEquipment(int labId, string name) {
        Laboratory* lab = findLaboratoryById(labId);
        if (lab) {
            for (const auto& eq : lab->equipmentList) {
                if (eq.name == name) {
                    cout << "Equipment Found: ID = " << eq.id << ", Name = " << eq.name << ", Type = " << eq.type << endl;
                }
            }
        }
    }

    void displayLaboratories() {
        for (const auto& lab : laboratories) {
            cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << endl;
            for (const auto& eq : lab.equipmentList) {
                cout << "  Equipment ID: " << eq.id << ", Name: " << eq.name << ", Type: " << eq.type << endl;
            }
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addLaboratory(1, "Physics Lab");
    ems.addLaboratory(2, "Chemistry Lab");
    
    ems.addEquipment(1, 101, "Oscilloscope", "Electronics");
    ems.addEquipment(1, 102, "Spectrometer", "Optics");
    ems.addEquipment(2, 201, "Beaker", "Glassware");

    ems.displayLaboratories();
    ems.searchEquipment(1, "Oscilloscope");
    
    ems.updateEquipment(1, 101, "Oscilloscope", "Electrical Equipment");
    ems.updateLaboratory(1, "Advanced Physics Lab");
    
    ems.displayLaboratories();
    
    ems.removeEquipment(1, 102);
    ems.removeLaboratory(2);
    
    ems.displayLaboratories();

    return 0;
}