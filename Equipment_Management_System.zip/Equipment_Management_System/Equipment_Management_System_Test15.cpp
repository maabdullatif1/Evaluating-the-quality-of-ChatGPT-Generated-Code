#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string description;

    Equipment(int id, string name, string description)
        : id(id), name(name), description(description) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipmentList;

    Laboratory(int id, string name) : id(id), name(name) {}

    void addEquipment(Equipment equipment) {
        equipmentList.push_back(equipment);
    }

    void deleteEquipment(int equipmentId) {
        for (size_t i = 0; i < equipmentList.size(); ++i) {
            if (equipmentList[i].id == equipmentId) {
                equipmentList.erase(equipmentList.begin() + i);
                return;
            }
        }
    }

    void updateEquipment(int equipmentId, string newName, string newDescription) {
        for (size_t i = 0; i < equipmentList.size(); ++i) {
            if (equipmentList[i].id == equipmentId) {
                equipmentList[i].name = newName;
                equipmentList[i].description = newDescription;
                return;
            }
        }
    }

    Equipment* searchEquipment(int equipmentId) {
        for (auto& equipment : equipmentList) {
            if (equipment.id == equipmentId) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void displayEquipments() {
        for (const auto& equipment : equipmentList) {
            cout << "Equipment ID: " << equipment.id 
                 << ", Name: " << equipment.name 
                 << ", Description: " << equipment.description << endl;
        }
    }
};

class EquipmentManagementSystem {
public:
    vector<Laboratory> labs;

    void addLaboratory(Laboratory lab) {
        labs.push_back(lab);
    }

    void deleteLaboratory(int labId) {
        for (size_t i = 0; i < labs.size(); ++i) {
            if (labs[i].id == labId) {
                labs.erase(labs.begin() + i);
                return;
            }
        }
    }

    Laboratory* searchLaboratory(int labId) {
        for (auto& lab : labs) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLaboratories() {
        for (const auto& lab : labs) {
            cout << "Lab ID: " << lab.id << ", Name: " << lab.name << endl;
            lab.displayEquipments();
        }
    }
};

int main() {
    EquipmentManagementSystem ems;

    Laboratory lab1(1, "Chemistry Lab");
    lab1.addEquipment(Equipment(101, "Microscope", "Used for viewing small objects"));
    lab1.addEquipment(Equipment(102, "Beaker", "Used for mixing liquids"));

    ems.addLaboratory(lab1);

    Laboratory lab2(2, "Physics Lab");
    lab2.addEquipment(Equipment(201, "Voltmeter", "Measures electrical potential"));

    ems.addLaboratory(lab2);

    ems.displayLaboratories();

    Laboratory* lab = ems.searchLaboratory(1);
    if (lab) {
        lab->updateEquipment(101, "Advanced Microscope", "High-end microscope for research purposes");
        lab->displayEquipments();
    }

    return 0;
}