#include <iostream>
#include <vector>
#include <string>

struct Equipment {
    int id;
    std::string name;
    std::string description;
};

struct Laboratory {
    int id;
    std::string name;
    std::vector<Equipment> equipmentList;
};

class EquipmentManagementSystem {
private:
    std::vector<Laboratory> laboratories;
    int nextLabId;
    int nextEquipId;

public:
    EquipmentManagementSystem() : nextLabId(1), nextEquipId(1) {}

    void addLaboratory(const std::string& labName) {
        Laboratory lab;
        lab.id = nextLabId++;
        lab.name = labName;
        laboratories.push_back(lab);
    }
    
    void deleteLaboratory(int labId) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == labId) {
                laboratories.erase(it);
                return;
            }
        }
    }
    
    void updateLaboratory(int labId, const std::string& newLabName) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                lab.name = newLabName;
                return;
            }
        }
    }
    
    void displayLaboratories() const {
        for (const auto& lab : laboratories) {
            std::cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << std::endl;
            for (const auto& equip : lab.equipmentList) {
                std::cout << "  Equipment ID: " << equip.id << ", Name: " 
                          << equip.name << ", Description: " << equip.description << std::endl;
            }
        }
    }
    
    void addEquipment(int labId, const std::string& equipName, const std::string& equipDesc) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                Equipment equip;
                equip.id = nextEquipId++;
                equip.name = equipName;
                equip.description = equipDesc;
                lab.equipmentList.push_back(equip);
                return;
            }
        }
    }
    
    void deleteEquipment(int labId, int equipId) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                for (auto it = lab.equipmentList.begin(); it != lab.equipmentList.end(); ++it) {
                    if (it->id == equipId) {
                        lab.equipmentList.erase(it);
                        return;
                    }
                }
            }
        }
    }
    
    void updateEquipment(int labId, int equipId, const std::string& newEquipName, const std::string& newEquipDesc) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                for (auto& equip : lab.equipmentList) {
                    if (equip.id == equipId) {
                        equip.name = newEquipName;
                        equip.description = newEquipDesc;
                        return;
                    }
                }
            }
        }
    }
    
    void searchEquipment(const std::string& searchTerm) const {
        for (const auto& lab : laboratories) {
            for (const auto& equip : lab.equipmentList) {
                if (equip.name.find(searchTerm) != std::string::npos ||
                    equip.description.find(searchTerm) != std::string::npos) {
                    std::cout << "Found in Lab ID: " << lab.id << " - Equipment ID: "
                              << equip.id << ", Name: " << equip.name
                              << ", Description: " << equip.description << std::endl;
                }
            }
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    
    ems.addLaboratory("Computer Lab");
    ems.addLaboratory("Physics Lab");
    
    ems.addEquipment(1, "PC", "Desktop Computer");
    ems.addEquipment(1, "Printer", "Laser Printer");
    ems.addEquipment(2, "Oscilloscope", "Digital Oscilloscope");
    
    ems.updateEquipment(1, 1, "Personal Computer", "High performance desktop");
    
    ems.displayLaboratories();
    
    ems.searchEquipment("Laser");
    
    ems.deleteEquipment(1, 2);
    
    ems.displayLaboratories();
    
    ems.updateLaboratory(2, "Advanced Physics Lab");
    
    ems.displayLaboratories();
    
    ems.deleteLaboratory(1);
    
    ems.displayLaboratories();
    
    return 0;
}