#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string description;

    Equipment(int i, string n, string d) : id(i), name(n), description(d) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipments;

    Laboratory(int i, string n) : id(i), name(n) {}
    
    void addEquipment(int eqId, string eqName, string eqDescription) {
        equipments.push_back(Equipment(eqId, eqName, eqDescription));
    }

    bool deleteEquipment(int eqId) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == eqId) {
                equipments.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateEquipment(int eqId, string eqName, string eqDescription) {
        for (auto &eq : equipments) {
            if (eq.id == eqId) {
                eq.name = eqName;
                eq.description = eqDescription;
                return true;
            }
        }
        return false;
    }

    Equipment* searchEquipment(int eqId) {
        for (auto &eq : equipments) {
            if (eq.id == eqId) {
                return &eq;
            }
        }
        return nullptr;
    }

    void displayEquipments() {
        for (const auto &eq : equipments) {
            cout << "Equipment ID: " << eq.id << ", Name: " << eq.name << ", Description: " << eq.description << endl;
        }
    }
};

class LabSystem {
private:
    vector<Laboratory> labs;

public:
    void addLaboratory(int labId, string labName) {
        labs.push_back(Laboratory(labId, labName));
    }

    bool deleteLaboratory(int labId) {
        for (auto it = labs.begin(); it != labs.end(); ++it) {
            if (it->id == labId) {
                labs.erase(it);
                return true;
            }
        }
        return false;
    }

    Laboratory* searchLaboratory(int labId) {
        for (auto &lab : labs) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLaboratories() {
        for (const auto &lab : labs) {
            cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << ", Equipments: " << endl;
            lab.displayEquipments();
        }
    }
};

int main() {
    LabSystem system;
    system.addLaboratory(1, "Physics Lab");
    system.addLaboratory(2, "Chemistry Lab");

    Laboratory* lab = system.searchLaboratory(1);
    if (lab != nullptr) {
        lab->addEquipment(101, "Microscope", "Used for viewing small objects.");
        lab->addEquipment(102, "Telescope", "Used for viewing distant objects.");
    }

    lab = system.searchLaboratory(2);
    if (lab != nullptr) {
        lab->addEquipment(201, "Beaker", "Used for mixing chemicals.");
    }

    system.displayLaboratories();

    if (lab != nullptr) {
        lab->updateEquipment(201, "Beaker", "Glass container for chemical reactions.");
    }

    system.displayLaboratories();

    if (lab != nullptr) {
        lab->deleteEquipment(201);
    }

    system.displayLaboratories();

    return 0;
}