#include <iostream>
#include <string>
#include <vector>

class Equipment {
public:
    int id;
    std::string name;
    std::string manufacturer;

    Equipment(int id, const std::string& name, const std::string& manufacturer)
        : id(id), name(name), manufacturer(manufacturer) {}
    
    void display() const {
        std::cout << "ID: " << id << ", Name: " << name << ", Manufacturer: " << manufacturer << std::endl;
    }
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipmentList;

    Laboratory(int id, const std::string& name)
        : id(id), name(name) {}
    
    void addEquipment(const Equipment& equipment) {
        equipmentList.push_back(equipment);
    }

    void displayEquipment() const {
        for (const auto& eq : equipmentList) {
            eq.display();
        }
    }

    void display() const {
        std::cout << "Lab ID: " << id << ", Name: " << name << std::endl;
        displayEquipment();
    }
};

class EquipmentManagementSystem {
    std::vector<Equipment> equipList;
    std::vector<Laboratory> labList;
    
public:
    void addEquipment(int id, const std::string& name, const std::string& manufacturer) {
        equipList.push_back(Equipment(id, name, manufacturer));
    }

    void deleteEquipment(int id) {
        for (auto it = equipList.begin(); it != equipList.end(); ++it) {
            if (it->id == id) {
                equipList.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int id, const std::string& name, const std::string& manufacturer) {
        for (auto& eq : equipList) {
            if (eq.id == id) {
                eq.name = name;
                eq.manufacturer = manufacturer;
            }
        }
    }

    void searchEquipment(int id) const {
        for (const auto& eq : equipList) {
            if (eq.id == id) {
                eq.display();
                return;
            }
        }
        std::cout << "Equipment not found." << std::endl;
    }

    void displayAllEquipment() const {
        for (const auto& eq : equipList) {
            eq.display();
        }
    }

    void addLaboratory(int id, const std::string& name) {
        labList.push_back(Laboratory(id, name));
    }

    void deleteLaboratory(int id) {
        for (auto it = labList.begin(); it != labList.end(); ++it) {
            if (it->id == id) {
                labList.erase(it);
                break;
            }
        }
    }

    void updateLaboratory(int id, const std::string& name) {
        for (auto& lab : labList) {
            if (lab.id == id) {
                lab.name = name;
            }
        }
    }

    void searchLaboratory(int id) const {
        for (const auto& lab : labList) {
            if (lab.id == id) {
                lab.display();
                return;
            }
        }
        std::cout << "Laboratory not found." << std::endl;
    }

    void displayAllLaboratories() const {
        for (const auto& lab : labList) {
            lab.display();
        }
    }
};

int main() {
    EquipmentManagementSystem system;

    system.addEquipment(1, "Oscilloscope", "Tektronix");
    system.addEquipment(2, "Multimeter", "Fluke");
    
    system.addLaboratory(1, "Physics Lab");
    system.addLaboratory(2, "Chemistry Lab");
    
    system.displayAllEquipment();
    system.displayAllLaboratories();
    
    system.updateEquipment(1, "Digital Oscilloscope", "Keysight");
    system.searchEquipment(1);

    system.deleteEquipment(2);
    system.displayAllEquipment();

    system.updateLaboratory(1, "Advanced Physics Lab");
    system.searchLaboratory(1);

    system.deleteLaboratory(2);
    system.displayAllLaboratories();
    
    return 0;
}