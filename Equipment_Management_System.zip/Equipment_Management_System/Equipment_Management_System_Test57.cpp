#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string type;

    Equipment(int eid, std::string ename, std::string etype)
        : id(eid), name(ename), type(etype) {}

    void display() const {
        std::cout << "Equipment ID: " << id << ", Name: " << name << ", Type: " << type << std::endl;
    }
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;

    Laboratory(int lid, std::string lname) : id(lid), name(lname) {}

    void addEquipment(const Equipment& equipment) {
        equipments.push_back(equipment);
    }

    void deleteEquipment(int eid) {
        for (size_t i = 0; i < equipments.size(); ++i) {
            if (equipments[i].id == eid) {
                equipments.erase(equipments.begin() + i);
                return;
            }
        }
    }

    void updateEquipment(int eid, const std::string& newName, const std::string& newType) {
        for (auto& equipment : equipments) {
            if (equipment.id == eid) {
                equipment.name = newName;
                equipment.type = newType;
                return;
            }
        }
    }

    void display() const {
        std::cout << "Laboratory ID: " << id << ", Name: " << name << std::endl;
        for (const auto& equipment : equipments) {
            equipment.display();
        }
    }

    Equipment* searchEquipment(int eid) {
        for (auto& equipment : equipments) {
            if (equipment.id == eid) {
                return &equipment;
            }
        }
        return nullptr;
    }
};

class EquipmentManagementSystem {
private:
    std::vector<Laboratory> laboratories;

public:
    void addLaboratory(const Laboratory& lab) {
        laboratories.push_back(lab);
    }

    void deleteLaboratory(int lid) {
        for (size_t i = 0; i < laboratories.size(); ++i) {
            if (laboratories[i].id == lid) {
                laboratories.erase(laboratories.begin() + i);
                return;
            }
        }
    }

    void updateLaboratory(int lid, const std::string& newName) {
        for (auto& lab : laboratories) {
            if (lab.id == lid) {
                lab.name = newName;
                return;
            }
        }
    }

    void displayLaboratories() const {
        for (const auto& lab : laboratories) {
            lab.display();
        }
    }

    Laboratory* searchLaboratory(int lid) {
        for (auto& lab : laboratories) {
            if (lab.id == lid) {
                return &lab;
            }
        }
        return nullptr;
    }
};

int main() {
    EquipmentManagementSystem ems;
    Laboratory lab1(1, "Physics Lab");
    Laboratory lab2(2, "Chemistry Lab");

    Equipment eq1(101, "Microscope", "Optical");
    Equipment eq2(102, "Bunsen Burner", "Heating");

    lab1.addEquipment(eq1);
    lab2.addEquipment(eq2);

    ems.addLaboratory(lab1);
    ems.addLaboratory(lab2);

    std::cout << "All Laboratories:" << std::endl;
    ems.displayLaboratories();

    Laboratory* lab = ems.searchLaboratory(1);
    if (lab != nullptr) {
        lab->updateEquipment(101, "Advanced Microscope", "Optical");
    }

    std::cout << "\nUpdated Laboratories:" << std::endl;
    ems.displayLaboratories();

    return 0;
}