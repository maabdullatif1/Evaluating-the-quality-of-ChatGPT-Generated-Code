#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string description;

    Equipment(int id, string name, string description)
        : id(id), name(name), description(description) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipments;

    Laboratory(int id, string name) : id(id), name(name) {}
};

vector<Laboratory> labs;

void addLab(int id, string name) {
    labs.push_back(Laboratory(id, name));
}

void addEquipment(int labId, int equipId, string name, string description) {
    for (auto& lab : labs) {
        if (lab.id == labId) {
            lab.equipments.push_back(Equipment(equipId, name, description));
            return;
        }
    }
}

void deleteLab(int id) {
    for (auto it = labs.begin(); it != labs.end(); ++it) {
        if (it->id == id) {
            labs.erase(it);
            return;
        }
    }
}

void deleteEquipment(int labId, int equipId) {
    for (auto& lab : labs) {
        if (lab.id == labId) {
            for (auto it = lab.equipments.begin(); it != lab.equipments.end(); ++it) {
                if (it->id == equipId) {
                    lab.equipments.erase(it);
                    return;
                }
            }
        }
    }
}

void updateEquipment(int labId, int equipId, string newName, string newDescription) {
    for (auto& lab : labs) {
        if (lab.id == labId) {
            for (auto& equip : lab.equipments) {
                if (equip.id == equipId) {
                    equip.name = newName;
                    equip.description = newDescription;
                    return;
                }
            }
        }
    }
}

bool searchEquipment(int labId, int equipId) {
    for (const auto& lab : labs) {
        if (lab.id == labId) {
            for (const auto& equip : lab.equipments) {
                if (equip.id == equipId) {
                    cout << "Equipment Found: " << equip.name << ", " << equip.description << endl;
                    return true;
                }
            }
        }
    }
    return false;
}

void displayLabs() {
    for (const auto& lab : labs) {
        cout << "Lab ID: " << lab.id << ", Name: " << lab.name << endl;
        for (const auto& equip : lab.equipments) {
            cout << "  Equipment ID: " << equip.id << ", Name: " << equip.name << ", Description: " << equip.description << endl;
        }
    }
}

int main() {
    addLab(1, "Physics Lab");
    addLab(2, "Chemistry Lab");
    addEquipment(1, 101, "Microscope", "Used for viewing small objects");
    addEquipment(1, 102, "Spectrometer", "Used for measuring wavelengths");
    addEquipment(2, 201, "Bunsen Burner", "Used for heating");
    
    displayLabs();
    
    updateEquipment(1, 101, "Advanced Microscope", "Updated description for microscope");
    searchEquipment(1, 101);
    
    deleteEquipment(1, 102);
    deleteLab(2);
    
    displayLabs();

    return 0;
}