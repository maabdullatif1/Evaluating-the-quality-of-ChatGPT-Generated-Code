#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Equipment {
    int id;
    string name;
    string laboratory;
};

class EquipmentManagementSystem {
private:
    vector<Equipment> equipments;
    int currentId;

public:
    EquipmentManagementSystem() : currentId(1) {}

    void addEquipment(const string& name, const string& laboratory) {
        equipments.push_back({currentId++, name, laboratory});
    }

    void deleteEquipment(int id) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == id) {
                equipments.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int id, const string& name, const string& laboratory) {
        for (auto& eq : equipments) {
            if (eq.id == id) {
                eq.name = name;
                eq.laboratory = laboratory;
                break;
            }
        }
    }

    Equipment* searchEquipment(int id) {
        for (auto& eq : equipments) {
            if (eq.id == id) {
                return &eq;
            }
        }
        return nullptr;
    }

    void displayEquipments() const {
        for (const auto& eq : equipments) {
            cout << "ID: " << eq.id << ", Name: " << eq.name << ", Laboratory: " << eq.laboratory << endl;
        }
    }
};

int main() {
    EquipmentManagementSystem system;
    bool exit = false;

    while (!exit) {
        cout << "1. Add Equipment\n2. Delete Equipment\n3. Update Equipment\n4. Search Equipment\n5. Display All Equipments\n6. Exit\nChoose an option: ";
        
        int choice;
        cin >> choice;

        switch (choice) {
            case 1: {
                string name, laboratory;
                cout << "Enter equipment name: ";
                cin >> name;
                cout << "Enter laboratory name: ";
                cin >> laboratory;
                system.addEquipment(name, laboratory);
                break;
            }
            case 2: {
                int id;
                cout << "Enter equipment ID to delete: ";
                cin >> id;
                system.deleteEquipment(id);
                break;
            }
            case 3: {
                int id;
                string name, laboratory;
                cout << "Enter equipment ID to update: ";
                cin >> id;
                cout << "Enter new equipment name: ";
                cin >> name;
                cout << "Enter new laboratory name: ";
                cin >> laboratory;
                system.updateEquipment(id, name, laboratory);
                break;
            }
            case 4: {
                int id;
                cout << "Enter equipment ID to search: ";
                cin >> id;
                Equipment* eq = system.searchEquipment(id);
                if (eq)
                    cout << "Found - ID: " << eq->id << ", Name: " << eq->name << ", Laboratory: " << eq->laboratory << endl;
                else
                    cout << "Equipment not found." << endl;
                break;
            }
            case 5:
                system.displayEquipments();
                break;
            case 6:
                exit = true;
                break;
            default:
                cout << "Invalid option. Please try again." << endl;
                break;
        }
    }

    return 0;
}