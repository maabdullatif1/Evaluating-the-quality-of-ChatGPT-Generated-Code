#include <iostream>
#include <string>

using namespace std;

class Equipment {
public:
    string id;
    string name;
    string laboratory;

    Equipment() : id(""), name(""), laboratory("") {}

    void display() const {
        cout << "ID: " << id << ", Name: " << name << ", Laboratory: " << laboratory << endl;
    }
};

class EquipmentManagementSystem {
    Equipment equipments[100];
    int count;

public:
    EquipmentManagementSystem() : count(0) {}

    void addEquipment(const string& id, const string& name, const string& laboratory) {
        if (count < 100) {
            equipments[count].id = id;
            equipments[count].name = name;
            equipments[count++].laboratory = laboratory;
        } else {
            cout << "Equipment list is full" << endl;
        }
    }

    void deleteEquipment(const string& id) {
        bool found = false;
        for (int i = 0; i < count; ++i) {
            if (equipments[i].id == id) {
                for (int j = i; j < count - 1; ++j) {
                    equipments[j] = equipments[j + 1];
                }
                count--;
                found = true;
                break;
            }
        }
        if (!found) {
            cout << "Equipment not found" << endl;
        }
    }

    void updateEquipment(const string& id, const string& name, const string& laboratory) {
        bool found = false;
        for (int i = 0; i < count; ++i) {
            if (equipments[i].id == id) {
                equipments[i].name = name;
                equipments[i].laboratory = laboratory;
                found = true;
                break;
            }
        }
        if (!found) {
            cout << "Equipment not found" << endl;
        }
    }

    void searchEquipment(const string& id) const {
        bool found = false;
        for (int i = 0; i < count; ++i) {
            if (equipments[i].id == id) {
                equipments[i].display();
                found = true;
                break;
            }
        }
        if (!found) {
            cout << "Equipment not found" << endl;
        }
    }

    void displayEquipments() const {
        if (count == 0) {
            cout << "No equipments available" << endl;
        } else {
            for (int i = 0; i < count; ++i) {
                equipments[i].display();
            }
        }
    }
};

int main() {
    EquipmentManagementSystem system;
    int choice;
    string id, name, laboratory;

    do {
        cout << "1. Add Equipment\n2. Delete Equipment\n3. Update Equipment\n4. Search Equipment\n5. Display Equipments\n6. Exit\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter ID, Name, Laboratory: ";
            cin >> id >> name >> laboratory;
            system.addEquipment(id, name, laboratory);
            break;
        case 2:
            cout << "Enter ID to delete: ";
            cin >> id;
            system.deleteEquipment(id);
            break;
        case 3:
            cout << "Enter ID to update: ";
            cin >> id;
            cout << "Enter new Name and Laboratory: ";
            cin >> name >> laboratory;
            system.updateEquipment(id, name, laboratory);
            break;
        case 4:
            cout << "Enter ID to search: ";
            cin >> id;
            system.searchEquipment(id);
            break;
        case 5:
            system.displayEquipments();
            break;
        case 6:
            cout << "Exiting..." << endl;
            break;
        default:
            cout << "Invalid choice" << endl;
        }
    } while (choice != 6);

    return 0;
}