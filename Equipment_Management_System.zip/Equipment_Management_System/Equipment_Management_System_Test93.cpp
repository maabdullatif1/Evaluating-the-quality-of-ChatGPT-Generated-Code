#include <iostream>
#include <string>
#include <vector>

class Equipment {
public:
    int id;
    std::string name;
    std::string description;

    Equipment(int id, std::string name, std::string description)
        : id(id), name(name), description(description) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipmentList;

    Laboratory(int id, std::string name) : id(id), name(name) {}

    void addEquipment(int eqId, std::string name, std::string description) {
        equipmentList.push_back(Equipment(eqId, name, description));
    }

    void deleteEquipment(int eqId) {
        for (size_t i = 0; i < equipmentList.size(); ++i) {
            if (equipmentList[i].id == eqId) {
                equipmentList.erase(equipmentList.begin() + i);
                break;
            }
        }
    }

    void updateEquipment(int eqId, std::string name, std::string description) {
        for (size_t i = 0; i < equipmentList.size(); ++i) {
            if (equipmentList[i].id == eqId) {
                equipmentList[i].name = name;
                equipmentList[i].description = description;
                break;
            }
        }
    }

    Equipment* searchEquipment(int eqId) {
        for (size_t i = 0; i < equipmentList.size(); ++i) {
            if (equipmentList[i].id == eqId) {
                return &equipmentList[i];
            }
        }
        return nullptr;
    }

    void displayEquipment() {
        for (const auto& equipment : equipmentList) {
            std::cout << "Equipment ID: " << equipment.id
                      << ", Name: " << equipment.name
                      << ", Description: " << equipment.description << std::endl;
        }
    }
};

class LabManagementSystem {
public:
    std::vector<Laboratory> labs;

    void addLaboratory(int labId, std::string name) {
        labs.push_back(Laboratory(labId, name));
    }

    void deleteLaboratory(int labId) {
        for (size_t i = 0; i < labs.size(); ++i) {
            if (labs[i].id == labId) {
                labs.erase(labs.begin() + i);
                break;
            }
        }
    }

    Laboratory* searchLaboratory(int labId) {
        for (size_t i = 0; i < labs.size(); ++i) {
            if (labs[i].id == labId) {
                return &labs[i];
            }
        }
        return nullptr;
    }

    void displayLaboratories() {
        for (const auto &lab : labs) {
            std::cout << "Laboratory ID: " << lab.id
                      << ", Name: " << lab.name << std::endl;
            lab.displayEquipment();
        }
    }
};

int main() {
    LabManagementSystem system;

    system.addLaboratory(1, "Chemistry Lab");
    system.addLaboratory(2, "Physics Lab");

    Laboratory* chemistryLab = system.searchLaboratory(1);
    if (chemistryLab) {
        chemistryLab->addEquipment(101, "Beaker", "Used to hold liquids");
        chemistryLab->addEquipment(102, "Bunsen Burner", "Used for heating");
    }

    Laboratory* physicsLab = system.searchLaboratory(2);
    if (physicsLab) {
        physicsLab->addEquipment(201, "Voltmeter", "Measures voltage");
    }

    system.displayLaboratories();

    if (chemistryLab) {
        chemistryLab->updateEquipment(102, "Bunsen Burner", "Used for heating substances");
    }

    system.displayLaboratories();

    if (chemistryLab) {
        chemistryLab->deleteEquipment(101);
    }

    system.displayLaboratories();

    return 0;
}