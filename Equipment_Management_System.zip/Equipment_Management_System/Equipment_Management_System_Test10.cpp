#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    string name;
    string id;
    string labName;

    Equipment(string name, string id, string labName) : name(name), id(id), labName(labName) {}
};

class EquipmentManagementSystem {
    vector<Equipment> equipmentList;

public:
    void addEquipment(string name, string id, string labName) {
        equipmentList.push_back(Equipment(name, id, labName));
    }

    void deleteEquipment(string id) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == id) {
                equipmentList.erase(it);
                break;
            }
        }
    }

    void updateEquipment(string id, string newName, string newLabName) {
        for (auto &eq : equipmentList) {
            if (eq.id == id) {
                eq.name = newName;
                eq.labName = newLabName;
                break;
            }
        }
    }

    Equipment* searchEquipment(string id) {
        for (auto &eq : equipmentList) {
            if (eq.id == id) {
                return &eq;
            }
        }
        return nullptr;
    }

    void displayEquipment() {
        for (const auto &eq : equipmentList) {
            cout << "Name: " << eq.name << ", ID: " << eq.id << ", Lab: " << eq.labName << endl;
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addEquipment("Microscope", "E001", "Biology Lab");
    ems.addEquipment("Spectrometer", "E002", "Chemistry Lab");
    
    ems.displayEquipment();

    ems.updateEquipment("E001", "Electron Microscope", "Advanced Biology Lab");

    ems.displayEquipment();

    Equipment* eq = ems.searchEquipment("E001");
    if (eq) {
        cout << "Found Equipment: " << eq->name << endl;
    }

    ems.deleteEquipment("E002");

    ems.displayEquipment();

    return 0;
}