#include <iostream>
#include <vector>
#include <string>

struct Equipment {
    int id;
    std::string name;
    std::string description;
};

struct Laboratory {
    int id;
    std::string name;
    std::vector<Equipment> equipmentList;
};

class EquipmentManagementSystem {
private:
    std::vector<Laboratory> labs;
    int nextEquipmentId = 1;
    int nextLabId = 1;

public:
    void addLaboratory(const std::string& name) {
        Laboratory lab;
        lab.id = nextLabId++;
        lab.name = name;
        labs.push_back(lab);
    }
    
    void deleteLaboratory(int labId) {
        for (auto it = labs.begin(); it != labs.end(); ++it) {
            if (it->id == labId) {
                labs.erase(it);
                break;
            }
        }
    }
    
    void addEquipment(int labId, const std::string& name, const std::string& description) {
        for (auto& lab : labs) {
            if (lab.id == labId) {
                Equipment equipment;
                equipment.id = nextEquipmentId++;
                equipment.name = name;
                equipment.description = description;
                lab.equipmentList.push_back(equipment);
                break;
            }
        }
    }
    
    void deleteEquipment(int labId, int equipmentId) {
        for (auto& lab : labs) {
            if (lab.id == labId) {
                for (auto it = lab.equipmentList.begin(); it != lab.equipmentList.end(); ++it) {
                    if (it->id == equipmentId) {
                        lab.equipmentList.erase(it);
                        break;
                    }
                }
                break;
            }
        }
    }

    void updateEquipment(int labId, int equipmentId, const std::string& name, const std::string& description) {
        for (auto& lab : labs) {
            if (lab.id == labId) {
                for (auto& equipment : lab.equipmentList) {
                    if (equipment.id == equipmentId) {
                        equipment.name = name;
                        equipment.description = description;
                        return;
                    }
                }
            }
        }
    }

    Equipment* searchEquipment(int equipmentId) {
        for (auto& lab : labs) {
            for (auto& equipment : lab.equipmentList) {
                if (equipment.id == equipmentId) {
                    return &equipment;
                }
            }
        }
        return nullptr;
    }

    void display() const {
        for (const auto& lab : labs) {
            std::cout << "Lab ID: " << lab.id << ", Lab Name: " << lab.name << std::endl;
            for (const auto& equipment : lab.equipmentList) {
                std::cout << "  Equipment ID: " << equipment.id << ", Name: " << equipment.name 
                          << ", Description: " << equipment.description << std::endl;
            }
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addLaboratory("Physics Lab");
    ems.addLaboratory("Chemistry Lab");
    
    ems.addEquipment(1, "Oscilloscope", "Electronic device used to display and analyze waveform");
    ems.addEquipment(1, "Voltmeter", "Device used to measure electric potential difference");
    ems.addEquipment(2, "Beaker", "Cylindrical glass container used in labs");

    ems.display();

    Equipment* equipment = ems.searchEquipment(1);
    if (equipment != nullptr) {
        std::cout << "Found Equipment: " << equipment->name << std::endl;
    }
    
    ems.updateEquipment(1, 2, "Digital Voltmeter", "Upgraded device for voltage measurement");

    ems.display();

    ems.deleteEquipment(1, 1);

    ems.display();

    ems.deleteLaboratory(1);

    ems.display();

    return 0;
}