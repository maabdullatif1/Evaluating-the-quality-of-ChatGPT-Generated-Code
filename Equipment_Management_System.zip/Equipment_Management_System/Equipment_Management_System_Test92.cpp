#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Equipment {
public:
    int id;
    string name;
    string description;

    Equipment(int id, string name, string description)
        : id(id), name(name), description(description) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipments;

    Laboratory(int id, string name) : id(id), name(name) {}

    void addEquipment(const Equipment& equip) {
        equipments.push_back(equip);
    }

    void deleteEquipment(int equipID) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == equipID) {
                equipments.erase(it);
                break;
            }
        }
    }
};

class ManagementSystem {
    vector<Laboratory> labs;
    int equipmentCount = 0;
    int labCount = 0;

public:
    void addLab(string name) {
        labs.emplace_back(++labCount, name);
    }

    void deleteLab(int labID) {
        for (auto it = labs.begin(); it != labs.end(); ++it) {
            if (it->id == labID) {
                labs.erase(it);
                break;
            }
        }
    }

    void updateLab(int labID, string name) {
        for (auto& lab : labs) {
            if (lab.id == labID) {
                lab.name = name;
                break;
            }
        }
    }

    void addEquipmentToLab(int labID, string name, string description) {
        for (auto& lab : labs) {
            if (lab.id == labID) {
                lab.addEquipment(Equipment(++equipmentCount, name, description));
                break;
            }
        }
    }

    void deleteEquipmentFromLab(int labID, int equipID) {
        for (auto& lab : labs) {
            if (lab.id == labID) {
                lab.deleteEquipment(equipID);
                break;
            }
        }
    }

    void updateEquipmentInLab(int labID, int equipID, string name, string description) {
        for (auto& lab : labs) {
            if (lab.id == labID) {
                for (auto& equip : lab.equipments) {
                    if (equip.id == equipID) {
                        equip.name = name;
                        equip.description = description;
                        break;
                    }
                }
            }
        }
    }

    void displayAll() {
        for (const auto& lab : labs) {
            cout << "Lab ID: " << lab.id << ", Name: " << lab.name << endl;
            for (const auto& equip : lab.equipments) {
                cout << "  Equipment ID: " << equip.id
                     << ", Name: " << equip.name
                     << ", Description: " << equip.description << endl;
            }
        }
    }

    void searchEquipment(int equipID) {
        for (const auto& lab : labs) {
            for (const auto& equip : lab.equipments) {
                if (equip.id == equipID) {
                    cout << "Found Equipment in Lab ID " << lab.id
                         << ", Name: " << equip.name
                         << ", Description: " << equip.description << endl;
                    return;
                }
            }
        }
        cout << "Equipment not found." << endl;
    }
};

int main() {
    ManagementSystem system;

    system.addLab("Physics Lab");
    system.addLab("Chemistry Lab");
    system.addEquipmentToLab(1, "Microscope", "Used for biological studies");
    system.addEquipmentToLab(1, "Spectrometer", "Measures light intensity");

    system.displayAll();

    system.searchEquipment(1);

    system.updateLab(1, "Advanced Physics Lab");
    system.updateEquipmentInLab(1, 1, "Electron Microscope", "High-resolution microscope");

    system.displayAll();

    system.deleteEquipmentFromLab(1, 2);
    system.deleteLab(2);

    system.displayAll();

    return 0;
}