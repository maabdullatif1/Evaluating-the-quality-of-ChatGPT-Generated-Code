#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string description;
    
    Equipment(int eid, string ename, string edesc) : id(eid), name(ename), description(edesc) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipments;
    
    Laboratory(int lid, string lname) : id(lid), name(lname) {}
    
    void addEquipment(Equipment eq) {
        equipments.push_back(eq);
    }

    void removeEquipment(int eqId) {
        equipments.erase(remove_if(equipments.begin(), equipments.end(),
                                   [eqId](Equipment& eq) { return eq.id == eqId; }), equipments.end());
    }

    void updateEquipment(int eqId, string newName, string newDesc) {
        for(auto& eq : equipments) {
            if(eq.id == eqId) {
                eq.name = newName;
                eq.description = newDesc;
                break;
            }
        }
    }

    void displayEquipments() const {
        for(const auto& eq : equipments) {
            cout << "Equipment ID: " << eq.id << ", Name: " << eq.name << ", Description: " << eq.description << endl;
        }
    }
};

class System {
public:
    vector<Laboratory> laboratories;
    
    void addLaboratory(Laboratory lab) {
        laboratories.push_back(lab);
    }

    void removeLaboratory(int labId) {
        laboratories.erase(remove_if(laboratories.begin(), laboratories.end(),
                                     [labId](Laboratory& lab) { return lab.id == labId; }), laboratories.end());
    }

    Laboratory* searchLaboratory(int labId) {
        for(auto& lab : laboratories) {
            if(lab.id == labId) return &lab;
        }
        return nullptr;
    }

    void displayLaboratories() const {
        for(const auto& lab : laboratories) {
            cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << endl;
            lab.displayEquipments();
        }
    }
};

int main() {
    System sys;
    sys.addLaboratory(Laboratory(1, "Physics Lab"));
    sys.addLaboratory(Laboratory(2, "Chemistry Lab"));

    Laboratory* lab = sys.searchLaboratory(1);
    if(lab) {
        lab->addEquipment(Equipment(101, "Microscope", "Optical instrument used to see objects"));
        lab->addEquipment(Equipment(102, "Thermal Scanner", "Device used to measure temperature"));
    }
    
    sys.displayLaboratories();
    
    if(lab) {
        lab->updateEquipment(101, "Updated Microscope", "Updated description of Microscope");
    }
    
    sys.displayLaboratories();
    
    if(lab) {
        lab->removeEquipment(102);
    }

    sys.displayLaboratories();

    return 0;
}