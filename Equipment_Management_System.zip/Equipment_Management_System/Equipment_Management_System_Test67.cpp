#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string description;

    Equipment(int id, const std::string& name, const std::string& description)
        : id(id), name(name), description(description) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;

    Laboratory(int id, const std::string& name)
        : id(id), name(name) {}
    
    void addEquipment(const Equipment& equipment) {
        equipments.push_back(equipment);
    }

    void deleteEquipment(int equipmentId) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == equipmentId) {
                equipments.erase(it);
                break;
            }
        }
    }

    Equipment* searchEquipment(int equipmentId) {
        for (auto& equipment : equipments) {
            if (equipment.id == equipmentId) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void updateEquipment(int equipmentId, const std::string& newName, const std::string& newDescription) {
        Equipment* equipment = searchEquipment(equipmentId);
        if (equipment) {
            equipment->name = newName;
            equipment->description = newDescription;
        }
    }

    void displayEquipments() const {
        for (const auto& equipment : equipments) {
            std::cout << "Equipment ID: " << equipment.id
                      << ", Name: " << equipment.name
                      << ", Description: " << equipment.description << std::endl;
        }
    }
};

class EquipmentManagementSystem {
public:
    std::vector<Laboratory> laboratories;

    void addLaboratory(const Laboratory& laboratory) {
        laboratories.push_back(laboratory);
    }

    void deleteLaboratory(int labId) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == labId) {
                laboratories.erase(it);
                break;
            }
        }
    }

    Laboratory* searchLaboratory(int labId) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLaboratories() const {
        for (const auto& lab : laboratories) {
            std::cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << std::endl;
            lab.displayEquipments();
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    
    Laboratory lab1(1, "Physics Lab");
    Laboratory lab2(2, "Chemistry Lab");
    
    ems.addLaboratory(lab1);
    ems.addLaboratory(lab2);
    
    Equipment eq1(1, "Microscope", "Optical Instrument");
    Equipment eq2(2, "Test Tube", "Glassware");
    
    lab1.addEquipment(eq1);
    lab1.addEquipment(eq2);
    
    ems.displayLaboratories();
    
    lab1.updateEquipment(1, "Electron Microscope", "Advanced Optical Instrument");
    
    ems.displayLaboratories();
    
    lab1.deleteEquipment(2);
    
    ems.displayLaboratories();
    
    return 0;
}