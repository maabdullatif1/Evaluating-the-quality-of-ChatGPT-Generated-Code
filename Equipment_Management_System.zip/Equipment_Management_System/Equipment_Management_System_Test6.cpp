#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string description;

    Equipment(int id, string name, string description)
        : id(id), name(name), description(description) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipments;

    Laboratory(int id, string name)
        : id(id), name(name) {}
};

class EquipmentManagementSystem {
private:
    vector<Laboratory> laboratories;

    Laboratory* findLaboratory(int id) {
        for (auto& lab : laboratories) {
            if (lab.id == id) return &lab;
        }
        return nullptr;
    }

    Equipment* findEquipment(Laboratory& lab, int id) {
        for (auto& eq : lab.equipments) {
            if (eq.id == id) return &eq;
        }
        return nullptr;
    }

public:
    void addLaboratory(int id, string name) {
        laboratories.push_back(Laboratory(id, name));
    }

    void addEquipment(int labId, int eqId, string name, string description) {
        Laboratory* lab = findLaboratory(labId);
        if (lab)
            lab->equipments.push_back(Equipment(eqId, name, description));
    }

    void deleteLaboratory(int id) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == id) {
                laboratories.erase(it);
                break;
            }
        }
    }

    void deleteEquipment(int labId, int eqId) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) {
            for (auto it = lab->equipments.begin(); it != lab->equipments.end(); ++it) {
                if (it->id == eqId) {
                    lab->equipments.erase(it);
                    break;
                }
            }
        }
    }

    void updateEquipment(int labId, int eqId, string name, string description) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) {
            Equipment* eq = findEquipment(*lab, eqId);
            if (eq) {
                eq->name = name;
                eq->description = description;
            }
        }
    }

    Equipment* searchEquipment(int labId, int eqId) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) return findEquipment(*lab, eqId);
        return nullptr;
    }

    void displayLaboratories() {
        for (auto& lab : laboratories) {
            cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << endl;
            for (auto& eq : lab.equipments) {
                cout << "  Equipment ID: " << eq.id << ", Name: " << eq.name << ", Description: " << eq.description << endl;
            }
        }
    }
};

int main() {
    EquipmentManagementSystem system;
    system.addLaboratory(1, "Physics Lab");
    system.addLaboratory(2, "Chemistry Lab");
    system.addEquipment(1, 101, "Microscope", "Optical microscope");
    system.addEquipment(2, 201, "Bunsen Burner", "Gas burner for laboratory use");
    system.displayLaboratories();
    system.updateEquipment(1, 101, "Advanced Microscope", "Digital optical microscope");
    cout << "After update:" << endl;
    system.displayLaboratories();
    system.deleteEquipment(2, 201);
    cout << "After equipment deletion:" << endl;
    system.displayLaboratories();
    system.deleteLaboratory(1);
    cout << "After laboratory deletion:" << endl;
    system.displayLaboratories();
    return 0;
}