#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string lab;
    Equipment(int id, std::string name, std::string lab) : id(id), name(name), lab(lab) {}
};

class EquipmentManager {
private:
    std::vector<Equipment> equipments;
    int lastId;
    
    int findIndexById(int id) {
        for (int i = 0; i < equipments.size(); ++i) {
            if (equipments[i].id == id)
                return i;
        }
        return -1;
    }

public:
    EquipmentManager() : lastId(0) {}

    void addEquipment(std::string name, std::string lab) {
        equipments.push_back(Equipment(++lastId, name, lab));
        std::cout << "Equipment added successfully.\n";
    }

    void deleteEquipment(int id) {
        int index = findIndexById(id);
        if (index != -1) {
            equipments.erase(equipments.begin() + index);
            std::cout << "Equipment deleted successfully.\n";
        } else {
            std::cout << "Equipment not found.\n";
        }
    }

    void updateEquipment(int id, std::string name, std::string lab) {
        int index = findIndexById(id);
        if (index != -1) {
            equipments[index].name = name;
            equipments[index].lab = lab;
            std::cout << "Equipment updated successfully.\n";
        } else {
            std::cout << "Equipment not found.\n";
        }
    }

    void searchEquipment(int id) {
        int index = findIndexById(id);
        if (index != -1) {
            std::cout << "Equipment found: ID=" << equipments[index].id 
                      << ", Name=" << equipments[index].name 
                      << ", Lab=" << equipments[index].lab << '\n';
        } else {
            std::cout << "Equipment not found.\n";
        }
    }

    void displayAllEquipments() {
        if (equipments.empty()) {
            std::cout << "No equipment to display.\n";
            return;
        }
        for (const auto& equipment : equipments) {
            std::cout << "ID=" << equipment.id 
                      << ", Name=" << equipment.name 
                      << ", Lab=" << equipment.lab << '\n';
        }
    }
};

int main() {
    EquipmentManager manager;
    int choice, id;
    std::string name, lab;

    do {
        std::cout << "\n1. Add Equipment\n";
        std::cout << "2. Delete Equipment\n";
        std::cout << "3. Update Equipment\n";
        std::cout << "4. Search Equipment\n";
        std::cout << "5. Display All Equipments\n";
        std::cout << "6. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
        case 1:
            std::cout << "Enter equipment name: ";
            std::cin >> name;
            std::cout << "Enter equipment lab: ";
            std::cin >> lab;
            manager.addEquipment(name, lab);
            break;
        case 2:
            std::cout << "Enter equipment ID to delete: ";
            std::cin >> id;
            manager.deleteEquipment(id);
            break;
        case 3:
            std::cout << "Enter equipment ID to update: ";
            std::cin >> id;
            std::cout << "Enter new name: ";
            std::cin >> name;
            std::cout << "Enter new lab: ";
            std::cin >> lab;
            manager.updateEquipment(id, name, lab);
            break;
        case 4:
            std::cout << "Enter equipment ID to search: ";
            std::cin >> id;
            manager.searchEquipment(id);
            break;
        case 5:
            manager.displayAllEquipments();
            break;
        case 6:
            break;
        default:
            std::cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 6);

    return 0;
}