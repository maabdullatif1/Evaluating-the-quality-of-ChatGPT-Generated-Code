#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Equipment {
    string id;
    string name;
    string lab;
};

class EquipmentManager {
private:
    vector<Equipment> equipmentList;

public:
    void addEquipment(const string& id, const string& name, const string& lab) {
        Equipment eq = {id, name, lab};
        equipmentList.push_back(eq);
    }

    void deleteEquipment(const string& id) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == id) {
                equipmentList.erase(it);
                return;
            }
        }
    }

    void updateEquipment(const string& id, const string& newName, const string& newLab) {
        for (auto& eq : equipmentList) {
            if (eq.id == id) {
                eq.name = newName;
                eq.lab = newLab;
                return;
            }
        }
    }

    Equipment* searchEquipment(const string& id) {
        for (auto& eq : equipmentList) {
            if (eq.id == id) {
                return &eq;
            }
        }
        return nullptr;
    }

    void displayAll() {
        for (const auto& eq : equipmentList) {
            cout << "ID: " << eq.id << ", Name: " << eq.name << ", Lab: " << eq.lab << endl;
        }
    }
};

int main() {
    EquipmentManager manager;
    int choice;
    string id, name, lab;

    while (true) {
        cout << "1. Add Equipment\n2. Delete Equipment\n3. Update Equipment\n4. Search Equipment\n5. Display All\n6. Exit\nEnter choice: ";
        cin >> choice;
        switch (choice) {
        case 1:
            cout << "Enter ID: "; cin >> id;
            cout << "Enter Name: "; cin >> name;
            cout << "Enter Lab: "; cin >> lab;
            manager.addEquipment(id, name, lab);
            break;
        case 2:
            cout << "Enter ID to delete: "; cin >> id;
            manager.deleteEquipment(id);
            break;
        case 3:
            cout << "Enter ID to update: "; cin >> id;
            cout << "Enter new Name: "; cin >> name;
            cout << "Enter new Lab: "; cin >> lab;
            manager.updateEquipment(id, name, lab);
            break;
        case 4:
            cout << "Enter ID to search: "; cin >> id;
            Equipment* eq = manager.searchEquipment(id);
            if (eq) {
                cout << "Found - ID: " << eq->id << ", Name: " << eq->name << ", Lab: " << eq->lab << endl;
            } else {
                cout << "Equipment not found." << endl;
            }
            break;
        case 5:
            manager.displayAll();
            break;
        case 6:
            return 0;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    }
}