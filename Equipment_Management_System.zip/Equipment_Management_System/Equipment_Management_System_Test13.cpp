#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    std::string id;
    std::string name;

    Equipment(const std::string& id, const std::string& name) : id(id), name(name) {}
};

class Laboratory {
public:
    std::string id;
    std::string name;
    std::vector<Equipment> equipmentList;

    Laboratory(const std::string& id, const std::string& name) : id(id), name(name) {}

    void addEquipment(const Equipment& equipment) {
        equipmentList.push_back(equipment);
    }

    void removeEquipment(const std::string& equipmentId) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == equipmentId) {
                equipmentList.erase(it);
                break;
            }
        }
    }

    Equipment* searchEquipment(const std::string& equipmentId) {
        for (auto& equipment : equipmentList) {
            if (equipment.id == equipmentId) {
                return &equipment;
            }
        }
        return nullptr;
    }
};

class EquipmentManagementSystem {
private:
    std::vector<Laboratory> laboratories;

public:
    void addLaboratory(const Laboratory& laboratory) {
        laboratories.push_back(laboratory);
    }

    void deleteLaboratory(const std::string& labId) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == labId) {
                laboratories.erase(it);
                break;
            }
        }
    }

    Laboratory* searchLaboratory(const std::string& labId) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void updateLaboratory(const std::string& labId, const std::string& newName) {
        Laboratory* lab = searchLaboratory(labId);
        if (lab != nullptr) {
            lab->name = newName;
        }
    }

    void display() {
        for (const auto& lab : laboratories) {
            std::cout << "Lab ID: " << lab.id << ", Name: " << lab.name << '\n';
            for (const auto& equipment : lab.equipmentList) {
                std::cout << "  Equipment ID: " << equipment.id << ", Name: " << equipment.name << '\n';
            }
        }
    }
};

int main() {
    EquipmentManagementSystem ems;

    ems.addLaboratory(Laboratory("L1", "Chemistry Lab"));
    ems.addLaboratory(Laboratory("L2", "Physics Lab"));

    Laboratory* lab = ems.searchLaboratory("L1");
    if (lab != nullptr) {
        lab->addEquipment(Equipment("E1", "Microscope"));
        lab->addEquipment(Equipment("E2", "Test Tube"));
    }

    ems.display();

    ems.updateLaboratory("L2", "Advanced Physics Lab");
    ems.display();

    if (lab != nullptr) {
        lab->removeEquipment("E1");
    }

    ems.display();

    ems.deleteLaboratory("L1");
    ems.display();

    return 0;
}