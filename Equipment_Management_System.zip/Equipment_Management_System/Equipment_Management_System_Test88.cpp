#include <iostream>
#include <vector>
#include <string>

class Equipment {
private:
    int id;
    std::string name;
    std::string lab;

public:
    Equipment(int id, std::string name, std::string lab) : id(id), name(name), lab(lab) {}

    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getLab() const { return lab; }

    void setName(std::string newName) { name = newName; }
    void setLab(std::string newLab) { lab = newLab; }

    void display() const {
        std::cout << "ID: " << id << ", Name: " << name << ", Lab: " << lab << std::endl;
    }
};

class EquipmentManagementSystem {
private:
    std::vector<Equipment> equipments;

    int findEquipmentIndexById(int id) {
        for (int i = 0; i < equipments.size(); ++i) {
            if (equipments[i].getId() == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addEquipment(int id, std::string name, std::string lab) {
        if (findEquipmentIndexById(id) == -1) {
            equipments.emplace_back(id, name, lab);
        } else {
            std::cout << "Equipment ID already exists." << std::endl;
        }
    }

    void deleteEquipment(int id) {
        int index = findEquipmentIndexById(id);
        if (index != -1) {
            equipments.erase(equipments.begin() + index);
        } else {
            std::cout << "Equipment not found." << std::endl;
        }
    }

    void updateEquipment(int id, std::string newName, std::string newLab) {
        int index = findEquipmentIndexById(id);
        if (index != -1) {
            equipments[index].setName(newName);
            equipments[index].setLab(newLab);
        } else {
            std::cout << "Equipment not found." << std::endl;
        }
    }

    void searchEquipment(int id) {
        int index = findEquipmentIndexById(id);
        if (index != -1) {
            equipments[index].display();
        } else {
            std::cout << "Equipment not found." << std::endl;
        }
    }

    void displayAllEquipments() {
        for (const auto& equipment : equipments) {
            equipment.display();
        }
    }
};

int main() {
    EquipmentManagementSystem system;

    system.addEquipment(1, "Microscope", "Biology Lab");
    system.addEquipment(2, "Centrifuge", "Chemistry Lab");
    system.updateEquipment(2, "Centrifuge", "Physics Lab");
    system.displayAllEquipments();
    system.searchEquipment(1);
    system.deleteEquipment(1);
    system.displayAllEquipments();

    return 0;
}