#include <iostream>
#include <string>
#include <vector>

class Equipment {
public:
    int id;
    std::string name;
    std::string lab;

    Equipment(int id, const std::string& name, const std::string& lab)
        : id(id), name(name), lab(lab) {}
};

class EquipmentSystem {
private:
    std::vector<Equipment> equipments;

    int findEquipmentIndex(int id) {
        for (size_t i = 0; i < equipments.size(); ++i) {
            if (equipments[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addEquipment(int id, const std::string& name, const std::string& lab) {
        if (findEquipmentIndex(id) == -1) {
            equipments.emplace_back(id, name, lab);
        } else {
            std::cout << "Equipment with ID " << id << " already exists.\n";
        }
    }

    void deleteEquipment(int id) {
        int index = findEquipmentIndex(id);
        if (index != -1) {
            equipments.erase(equipments.begin() + index);
        } else {
            std::cout << "Equipment with ID " << id << " not found.\n";
        }
    }

    void updateEquipment(int id, const std::string& name, const std::string& lab) {
        int index = findEquipmentIndex(id);
        if (index != -1) {
            equipments[index].name = name;
            equipments[index].lab = lab;
        } else {
            std::cout << "Equipment with ID " << id << " not found.\n";
        }
    }

    void searchEquipment(int id) {
        int index = findEquipmentIndex(id);
        if (index != -1) {
            std::cout << "ID: " << equipments[index].id
                      << ", Name: " << equipments[index].name
                      << ", Lab: " << equipments[index].lab << '\n';
        } else {
            std::cout << "Equipment with ID " << id << " not found.\n";
        }
    }

    void displayAll() {
        for (const auto& eq : equipments) {
            std::cout << "ID: " << eq.id
                      << ", Name: " << eq.name
                      << ", Lab: " << eq.lab << '\n';
        }
    }
};

int main() {
    EquipmentSystem system;
    system.addEquipment(1, "Oscilloscope", "Electronics Lab");
    system.addEquipment(2, "Microscope", "Biology Lab");

    system.displayAll();

    system.searchEquipment(1);

    system.updateEquipment(1, "Digital Oscilloscope", "Physics Lab");
    system.searchEquipment(1);

    system.deleteEquipment(2);
    system.displayAll();

    return 0;
}