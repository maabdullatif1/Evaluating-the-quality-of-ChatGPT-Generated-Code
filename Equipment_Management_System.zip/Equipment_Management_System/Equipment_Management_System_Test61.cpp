#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string description;

    Equipment(int id, const string& name, const string& description)
        : id(id), name(name), description(description) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipments;

    Laboratory(int id, const string& name)
        : id(id), name(name) {}
};

class ManagementSystem {
    vector<Laboratory> labs;
    int equipmentCounter = 0;
    int labCounter = 0;

public:
    void addLaboratory(const string& name) {
        labs.push_back(Laboratory(++labCounter, name));
    }

    void deleteLaboratory(int labId) {
        for (auto it = labs.begin(); it != labs.end(); ++it) {
            if (it->id == labId) {
                labs.erase(it);
                break;
            }
        }
    }

    void updateLaboratory(int labId, const string& name) {
        for (auto& lab : labs) {
            if (lab.id == labId) {
                lab.name = name;
                break;
            }
        }
    }

    Laboratory* searchLaboratory(int labId) {
        for (auto& lab : labs) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void addEquipment(int labId, const string& name, const string& description) {
        Laboratory* lab = searchLaboratory(labId);
        if (lab) {
            lab->equipments.push_back(Equipment(++equipmentCounter, name, description));
        }
    }

    void deleteEquipment(int labId, int equipId) {
        Laboratory* lab = searchLaboratory(labId);
        if (lab) {
            for (auto it = lab->equipments.begin(); it != lab->equipments.end(); ++it) {
                if (it->id == equipId) {
                    lab->equipments.erase(it);
                    break;
                }
            }
        }
    }

    void updateEquipment(int labId, int equipId, const string& name, const string& description) {
        Laboratory* lab = searchLaboratory(labId);
        if (lab) {
            for (auto& equip : lab->equipments) {
                if (equip.id == equipId) {
                    equip.name = name;
                    equip.description = description;
                    break;
                }
            }
        }
    }

    Equipment* searchEquipment(int labId, int equipId) {
        Laboratory* lab = searchLaboratory(labId);
        if (lab) {
            for (auto& equip : lab->equipments) {
                if (equip.id == equipId) {
                    return &equip;
                }
            }
        }
        return nullptr;
    }

    void display() {
        for (const auto& lab : labs) {
            cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << endl;
            for (const auto& equip : lab.equipments) {
                cout << "  Equipment ID: " << equip.id << ", Name: " << equip.name 
                     << ", Description: " << equip.description << endl;
            }
        }
    }
};

int main() {
    ManagementSystem system;
    system.addLaboratory("Physics Lab");
    system.addLaboratory("Chemistry Lab");
    system.addEquipment(1, "Microscope", "Optical instrument for viewing small objects");
    system.addEquipment(1, "Beaker", "Simple container for stirring, mixing, and heating liquids");
    system.display();
    return 0;
}