#include <iostream>
#include <vector>
#include <string>

class Equipment {
private:
    int id;
    std::string name;
    std::string type;
    std::string lab;
public:
    Equipment(int _id, std::string _name, std::string _type, std::string _lab)
        : id(_id), name(_name), type(_type), lab(_lab) {}

    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getType() const { return type; }
    std::string getLab() const { return lab; }

    void setName(const std::string& _name) { name = _name; }
    void setType(const std::string& _type) { type = _type; }
    void setLab(const std::string& _lab) { lab = _lab; }

    void display() const {
        std::cout << "ID: " << id << ", Name: " << name << ", Type: " << type << ", Lab: " << lab << std::endl;
    }
};

class EquipmentManager {
private:
    std::vector<Equipment> equipments;
    int nextId;
public:
    EquipmentManager() : nextId(1) {}

    void addEquipment(std::string name, std::string type, std::string lab) {
        equipments.emplace_back(nextId++, name, type, lab);
    }

    void deleteEquipment(int id) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->getId() == id) {
                equipments.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int id, std::string name, std::string type, std::string lab) {
        for (auto& equipment : equipments) {
            if (equipment.getId() == id) {
                equipment.setName(name);
                equipment.setType(type);
                equipment.setLab(lab);
            }
        }
    }

    void searchEquipment(const std::string& query) const {
        for (const auto& equipment : equipments) {
            if (equipment.getName().find(query) != std::string::npos ||
                equipment.getType().find(query) != std::string::npos ||
                equipment.getLab().find(query) != std::string::npos) {
                equipment.display();
            }
        }
    }

    void displayAllEquipment() const {
        for (const auto& equipment : equipments) {
            equipment.display();
        }
    }
};

int main() {
    EquipmentManager manager;
    int choice;
    while (true) {
        std::cout << "\n1. Add Equipment\n2. Delete Equipment\n3. Update Equipment\n4. Search Equipment\n5. Display All Equipment\n6. Exit\nEnter your choice: ";
        std::cin >> choice;

        if (choice == 1) {
            std::string name, type, lab;
            std::cout << "Enter Equipment Name: ";
            std::cin >> name;
            std::cout << "Enter Equipment Type: ";
            std::cin >> type;
            std::cout << "Enter Laboratory Name: ";
            std::cin >> lab;
            manager.addEquipment(name, type, lab);
        } else if (choice == 2) {
            int id;
            std::cout << "Enter Equipment ID to delete: ";
            std::cin >> id;
            manager.deleteEquipment(id);
        } else if (choice == 3) {
            int id;
            std::string name, type, lab;
            std::cout << "Enter Equipment ID to update: ";
            std::cin >> id;
            std::cout << "Enter new Equipment Name: ";
            std::cin >> name;
            std::cout << "Enter new Equipment Type: ";
            std::cin >> type;
            std::cout << "Enter new Laboratory Name: ";
            std::cin >> lab;
            manager.updateEquipment(id, name, type, lab);
        } else if (choice == 4) {
            std::string query;
            std::cout << "Enter search query: ";
            std::cin >> query;
            manager.searchEquipment(query);
        } else if (choice == 5) {
            manager.displayAllEquipment();
        } else if (choice == 6) {
            break;
        }
    }
    return 0;
}