#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string labName;

    Equipment(int id, const std::string &name, const std::string &labName) 
        : id(id), name(name), labName(labName) {}
};

class EquipmentManagementSystem {
    std::vector<Equipment> equipments;

    int findEquipmentIndex(int id) {
        for (size_t i = 0; i < equipments.size(); ++i) {
            if (equipments[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addEquipment(int id, const std::string &name, const std::string &labName) {
        equipments.push_back(Equipment(id, name, labName));
    }

    void deleteEquipment(int id) {
        int index = findEquipmentIndex(id);
        if (index != -1) {
            equipments.erase(equipments.begin() + index);
        }
    }

    void updateEquipment(int id, const std::string &name, const std::string &labName) {
        int index = findEquipmentIndex(id);
        if (index != -1) {
            equipments[index].name = name;
            equipments[index].labName = labName;
        }
    }

    Equipment* searchEquipment(int id) {
        int index = findEquipmentIndex(id);
        if (index != -1) {
            return &equipments[index];
        }
        return nullptr;
    }

    void displayAllEquipments() {
        for (const auto &equipment : equipments) {
            std::cout << "ID: " << equipment.id << ", Name: " << equipment.name << ", Lab: " << equipment.labName << std::endl;
        }
    }
};

int main() {
    EquipmentManagementSystem managementSystem;
    managementSystem.addEquipment(1, "Microscope", "Biology Lab");
    managementSystem.addEquipment(2, "Thermometer", "Physics Lab");

    managementSystem.displayAllEquipments();

    Equipment* equipment = managementSystem.searchEquipment(1);
    if (equipment != nullptr) {
        std::cout << "Found: " << equipment->name << " in " << equipment->labName << std::endl;
    }

    managementSystem.updateEquipment(1, "Electron Microscope", "Advanced Biology Lab");
    managementSystem.displayAllEquipments();

    managementSystem.deleteEquipment(2);
    managementSystem.displayAllEquipments();

    return 0;
}