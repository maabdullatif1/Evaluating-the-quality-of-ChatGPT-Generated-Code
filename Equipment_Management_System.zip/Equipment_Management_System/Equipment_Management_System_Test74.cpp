#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string manufacturer;

    Equipment(int id, string name, string manufacturer) : id(id), name(name), manufacturer(manufacturer) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipmentList;

    Laboratory(int id, string name) : id(id), name(name) {}

    void addEquipment(Equipment equipment) {
        equipmentList.push_back(equipment);
    }

    void deleteEquipment(int equipmentId) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == equipmentId) {
                equipmentList.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int equipmentId, string name, string manufacturer) {
        for (auto &equipment : equipmentList) {
            if (equipment.id == equipmentId) {
                equipment.name = name;
                equipment.manufacturer = manufacturer;
                break;
            }
        }
    }

    void displayEquipment() {
        for (const auto &equipment : equipmentList) {
            cout << "Equipment ID: " << equipment.id << ", Name: " << equipment.name << ", Manufacturer: " << equipment.manufacturer << endl;
        }
    }
};

class EquipmentManagementSystem {
    vector<Laboratory> laboratories;
    
public:
    void addLaboratory(Laboratory laboratory) {
        laboratories.push_back(laboratory);
    }

    void deleteLaboratory(int labId) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == labId) {
                laboratories.erase(it);
                break;
            }
        }
    }

    void updateLaboratory(int labId, string name) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) {
                lab.name = name;
                break;
            }
        }
    }

    Laboratory* searchLaboratory(int labId) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLaboratories() {
        for (const auto &lab : laboratories) {
            cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << endl;
            lab.displayEquipment();
        }
    }
};

int main() {
    EquipmentManagementSystem ems;

    Laboratory lab1(1, "Physics Lab");
    lab1.addEquipment(Equipment(1, "Oscilloscope", "Tektronix"));
    lab1.addEquipment(Equipment(2, "Multimeter", "Fluke"));

    Laboratory lab2(2, "Chemistry Lab");
    lab2.addEquipment(Equipment(3, "Spectrometer", "Agilent"));

    ems.addLaboratory(lab1);
    ems.addLaboratory(lab2);

    cout << "Available Laboratories and Equipment:\n";
    ems.displayLaboratories();

    Laboratory* searchLab = ems.searchLaboratory(1);
    if (searchLab != nullptr) {
        cout << "Updating equipment in laboratory 1...\n";
        searchLab->updateEquipment(2, "Digital Multimeter", "Fluke Corp");
    }

    cout << "Updated Laboratories and Equipment:\n";
    ems.displayLaboratories();

    return 0;
}