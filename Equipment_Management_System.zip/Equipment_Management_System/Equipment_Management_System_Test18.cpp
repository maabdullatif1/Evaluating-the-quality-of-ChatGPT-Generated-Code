#include <iostream>
#include <string>
#include <vector>

class Equipment {
public:
    int id;
    std::string name;
    std::string description;

    Equipment(int i, std::string n, std::string d) : id(i), name(n), description(d) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipmentList;

    Laboratory(int i, std::string n) : id(i), name(n) {}

    void addEquipment(const Equipment& equipment) {
        equipmentList.push_back(equipment);
    }

    void deleteEquipment(int equipmentId) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == equipmentId) {
                equipmentList.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int equipmentId, const std::string& newName, const std::string& newDescription) {
        for (auto& equipment : equipmentList) {
            if (equipment.id == equipmentId) {
                equipment.name = newName;
                equipment.description = newDescription;
                break;
            }
        }
    }

    void searchEquipment(int equipmentId) const {
        for (const auto& equipment : equipmentList) {
            if (equipment.id == equipmentId) {
                std::cout << "Equipment ID: " << equipment.id << ", Name: " << equipment.name << ", Description: " << equipment.description << std::endl;
                return;
            }
        }
        std::cout << "Equipment not found.\n";
    }

    void displayEquipment() const {
        if (equipmentList.empty()) {
            std::cout << "No equipment available.\n";
        } else {
            std::cout << "Equipment in Laboratory " << name << ":\n";
            for (const auto& equipment : equipmentList) {
                std::cout << "ID: " << equipment.id << ", Name: " << equipment.name << ", Description: " << equipment.description << std::endl;
            }
        }
    }
};

class EquipmentManagementSystem {
public:
    std::vector<Laboratory> labList;

    void addLaboratory(const Laboratory& lab) {
        labList.push_back(lab);
    }

    void deleteLaboratory(int labId) {
        for (auto it = labList.begin(); it != labList.end(); ++it) {
            if (it->id == labId) {
                labList.erase(it);
                break;
            }
        }
    }

    Laboratory* findLaboratory(int labId) {
        for (auto& lab : labList) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLaboratories() const {
        if (labList.empty()) {
            std::cout << "No laboratories available.\n";
        } else {
            for (const auto& lab : labList) {
                std::cout << "Lab ID: " << lab.id << ", Name: " << lab.name << std::endl;
                lab.displayEquipment();
            }
        }
    }
};

int main() {
    EquipmentManagementSystem ems;

    Laboratory lab1(1, "Chemistry Lab");
    Laboratory lab2(2, "Physics Lab");

    ems.addLaboratory(lab1);
    ems.addLaboratory(lab2);

    Equipment eq1(101, "Microscope", "Powerful microscope for detailed examination.");
    Equipment eq2(102, "Test Tube", "Glass tube for chemical experiments.");

    Laboratory* lab = ems.findLaboratory(1);
    if (lab) {
        lab->addEquipment(eq1);
        lab->addEquipment(eq2);
        lab->displayEquipment();
    }

    ems.displayLaboratories();

    lab->deleteEquipment(102);
    lab->displayEquipment();

    lab->updateEquipment(101, "Advanced Microscope", "Updated powerful microscope.");
    lab->displayEquipment();

    lab->searchEquipment(101);
    lab->searchEquipment(103);

    return 0;
}