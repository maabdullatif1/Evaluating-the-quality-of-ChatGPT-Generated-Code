#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    Equipment(const std::string& name, const std::string& id)
        : name(name), id(id) {}

    std::string getName() const { return name; }
    std::string getId() const { return id; }

    void updateName(const std::string& newName) { name = newName; }
    void updateId(const std::string& newId) { id = newId; }

private:
    std::string name;
    std::string id;
};

class Laboratory {
public:
    Laboratory(const std::string& name, const std::string& id)
        : name(name), id(id) {}

    void addEquipment(const Equipment& equipment) {
        equipments.push_back(equipment);
    }

    void deleteEquipment(const std::string& equipmentId) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->getId() == equipmentId) {
                equipments.erase(it);
                return;
            }
        }
    }

    Equipment* searchEquipment(const std::string& equipmentId) {
        for (auto& equipment : equipments) {
            if (equipment.getId() == equipmentId) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void updateEquipment(const std::string& equipmentId, const std::string& newName, const std::string& newId) {
        Equipment* equipment = searchEquipment(equipmentId);
        if (equipment) {
            equipment->updateName(newName);
            equipment->updateId(newId);
        }
    }

    std::string getName() const { return name; }
    std::string getId() const { return id; }

    void displayEquipments() const {
        for (const auto& equipment : equipments) {
            std::cout << "Equipment Name: " << equipment.getName() << ", ID: " << equipment.getId() << "\n";
        }
    }

private:
    std::string name;
    std::string id;
    std::vector<Equipment> equipments;
};

class EquipmentManagementSystem {
public:
    void addLaboratory(const Laboratory& laboratory) {
        laboratories.push_back(laboratory);
    }

    void deleteLaboratory(const std::string& labId) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->getId() == labId) {
                laboratories.erase(it);
                return;
            }
        }
    }

    Laboratory* searchLaboratory(const std::string& labId) {
        for (auto& laboratory : laboratories) {
            if (laboratory.getId() == labId) {
                return &laboratory;
            }
        }
        return nullptr;
    }

    void updateLaboratory(const std::string& labId, const std::string& newName, const std::string& newId) {
        Laboratory* laboratory = searchLaboratory(labId);
        if (laboratory) {
            laboratory->updateName(newName);
            laboratory->updateId(newId);
        }
    }

    void displayLaboratories() const {
        for (const auto& laboratory : laboratories) {
            std::cout << "Laboratory Name: " << laboratory.getName() << ", ID: " << laboratory.getId() << "\n";
            laboratory.displayEquipments();
        }
    }

private:
    std::vector<Laboratory> laboratories;
};

int main() {
    EquipmentManagementSystem system;

    Laboratory lab1("Physics Lab", "L1");
    lab1.addEquipment(Equipment("Microscope", "E1"));
    lab1.addEquipment(Equipment("Spectrometer", "E2"));

    Laboratory lab2("Chemistry Lab", "L2");
    lab2.addEquipment(Equipment("Beaker", "E3"));
    lab2.addEquipment(Equipment("Flask", "E4"));

    system.addLaboratory(lab1);
    system.addLaboratory(lab2);

    system.displayLaboratories();

    return 0;
}