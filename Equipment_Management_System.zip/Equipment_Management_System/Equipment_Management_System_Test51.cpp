#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string manufacturer;
    Equipment(int id, std::string name, std::string manufacturer)
        : id(id), name(name), manufacturer(manufacturer) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;
    Laboratory(int id, std::string name) : id(id), name(name) {}
};

class EquipmentManagementSystem {
public:
    void addLaboratory(int id, std::string name);
    void deleteLaboratory(int id);
    void updateLaboratory(int id, std::string name);
    void displayLaboratories();
    void addEquipment(int labId, int equipId, std::string equipName, std::string manufacturer);
    void deleteEquipment(int labId, int equipId);
    void updateEquipment(int labId, int equipId, std::string equipName, std::string manufacturer);
    void displayEquipments(int labId);
    void searchEquipment(int labId, int equipId);

private:
    std::vector<Laboratory> laboratories;
    Laboratory* findLaboratory(int id);
};

void EquipmentManagementSystem::addLaboratory(int id, std::string name) {
    laboratories.push_back(Laboratory(id, name));
}

void EquipmentManagementSystem::deleteLaboratory(int id) {
    for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
        if (it->id == id) {
            laboratories.erase(it);
            break;
        }
    }
}

void EquipmentManagementSystem::updateLaboratory(int id, std::string name) {
    Laboratory* lab = findLaboratory(id);
    if (lab) {
        lab->name = name;
    }
}

void EquipmentManagementSystem::displayLaboratories() {
    for (const auto& lab : laboratories) {
        std::cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << std::endl;
    }
}

void EquipmentManagementSystem::addEquipment(int labId, int equipId, std::string equipName, std::string manufacturer) {
    Laboratory* lab = findLaboratory(labId);
    if (lab) {
        lab->equipments.push_back(Equipment(equipId, equipName, manufacturer));
    }
}

void EquipmentManagementSystem::deleteEquipment(int labId, int equipId) {
    Laboratory* lab = findLaboratory(labId);
    if (lab) {
        for (auto it = lab->equipments.begin(); it != lab->equipments.end(); ++it) {
            if (it->id == equipId) {
                lab->equipments.erase(it);
                break;
            }
        }
    }
}

void EquipmentManagementSystem::updateEquipment(int labId, int equipId, std::string equipName, std::string manufacturer) {
    Laboratory* lab = findLaboratory(labId);
    if (lab) {
        for (auto& equip : lab->equipments) {
            if (equip.id == equipId) {
                equip.name = equipName;
                equip.manufacturer = manufacturer;
                break;
            }
        }
    }
}

void EquipmentManagementSystem::displayEquipments(int labId) {
    Laboratory* lab = findLaboratory(labId);
    if (lab) {
        for (const auto& equip : lab->equipments) {
            std::cout << "Equipment ID: " << equip.id << ", Name: " << equip.name 
                      << ", Manufacturer: " << equip.manufacturer << std::endl;
        }
    }
}

void EquipmentManagementSystem::searchEquipment(int labId, int equipId) {
    Laboratory* lab = findLaboratory(labId);
    if (lab) {
        for (const auto& equip : lab->equipments) {
            if (equip.id == equipId) {
                std::cout << "Found Equipment - ID: " << equip.id << ", Name: " << equip.name 
                          << ", Manufacturer: " << equip.manufacturer << std::endl;
                return;
            }
        }
    }
    std::cout << "Equipment not found." << std::endl;
}

Laboratory* EquipmentManagementSystem::findLaboratory(int id) {
    for (auto& lab : laboratories) {
        if (lab.id == id) {
            return &lab;
        }
    }
    return nullptr;
}

int main() {
    EquipmentManagementSystem ems;
    ems.addLaboratory(1, "Physics Lab");
    ems.addEquipment(1, 101, "Oscilloscope", "Tektronix");
    ems.displayLaboratories();
    ems.displayEquipments(1);
    ems.searchEquipment(1, 101);
    ems.updateEquipment(1, 101, "Digital Oscilloscope", "Tektronix");
    ems.displayEquipments(1);
    ems.deleteEquipment(1, 101);
    ems.displayEquipments(1);
    ems.deleteLaboratory(1);
    ems.displayLaboratories();
    return 0;
}