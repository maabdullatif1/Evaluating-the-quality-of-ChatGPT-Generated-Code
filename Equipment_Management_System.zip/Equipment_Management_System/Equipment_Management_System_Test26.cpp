#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Equipment {
    int id;
    string name;
    string description;
    string labName;
};

class EquipmentManagement {
private:
    vector<Equipment> equipmentList;
    int nextId;

public:
    EquipmentManagement() : nextId(1) {}

    void addEquipment(const string &name, const string &description, const string &labName) {
        Equipment newEquipment = {nextId++, name, description, labName};
        equipmentList.push_back(newEquipment);
    }

    void deleteEquipment(int id) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == id) {
                equipmentList.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int id, const string &name, const string &description, const string &labName) {
        for (auto &equipment : equipmentList) {
            if (equipment.id == id) {
                equipment.name = name;
                equipment.description = description;
                equipment.labName = labName;
                break;
            }
        }
    }

    void searchEquipment(int id) const {
        for (const auto &equipment : equipmentList) {
            if (equipment.id == id) {
                cout << "ID: " << equipment.id << ", Name: " << equipment.name
                     << ", Description: " << equipment.description
                     << ", Lab: " << equipment.labName << endl;
                return;
            }
        }
        cout << "Equipment not found" << endl;
    }

    void displayAll() const {
        for (const auto &equipment : equipmentList) {
            cout << "ID: " << equipment.id << ", Name: " << equipment.name
                 << ", Description: " << equipment.description
                 << ", Lab: " << equipment.labName << endl;
        }
    }
};

int main() {
    EquipmentManagement system;
    int choice;
    string name, description, labName;
    int id;

    do {
        cout << "1. Add Equipment\n2. Delete Equipment\n3. Update Equipment\n4. Search Equipment\n5. Display All\n6. Exit\n";
        cin >> choice;
        switch (choice) {
            case 1:
                cout << "Enter name, description, lab name: ";
                cin >> name >> description >> labName;
                system.addEquipment(name, description, labName);
                break;
            case 2:
                cout << "Enter equipment ID to delete: ";
                cin >> id;
                system.deleteEquipment(id);
                break;
            case 3:
                cout << "Enter equipment ID to update: ";
                cin >> id;
                cout << "Enter new name, description, lab name: ";
                cin >> name >> description >> labName;
                system.updateEquipment(id, name, description, labName);
                break;
            case 4:
                cout << "Enter equipment ID to search: ";
                cin >> id;
                system.searchEquipment(id);
                break;
            case 5:
                system.displayAll();
                break;
            default:
                break;
        }
    } while (choice != 6);

    return 0;
}