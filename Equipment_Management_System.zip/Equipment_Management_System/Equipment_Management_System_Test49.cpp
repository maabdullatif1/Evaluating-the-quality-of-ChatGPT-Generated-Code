#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string status;

    Equipment(int id, string name, string status) : id(id), name(name), status(status) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipments;

    Laboratory(int id, string name) : id(id), name(name) {}

    void addEquipment(Equipment eq) {
        equipments.push_back(eq);
    }

    void deleteEquipment(int id) {
        for (size_t i = 0; i < equipments.size(); ++i) {
            if (equipments[i].id == id) {
                equipments.erase(equipments.begin() + i);
                break;
            }
        }
    }

    void updateEquipment(int id, string name, string status) {
        for (auto &eq : equipments) {
            if (eq.id == id) {
                eq.name = name;
                eq.status = status;
                break;
            }
        }
    }

    void searchEquipment(int id) {
        for (const auto &eq : equipments) {
            if (eq.id == id) {
                cout << "Equipment Found - ID: " << eq.id << ", Name: " << eq.name << ", Status: " << eq.status << endl;
                return;
            }
        }
        cout << "Equipment not found." << endl;
    }

    void displayEquipments() {
        cout << "Laboratory: " << name << endl;
        for (const auto &eq : equipments) {
            cout << "ID: " << eq.id << ", Name: " << eq.name << ", Status: " << eq.status << endl;
        }
    }
};

int main() {
    vector<Laboratory> labs;
    labs.push_back(Laboratory(1, "Physics Lab"));
    labs.push_back(Laboratory(2, "Chemistry Lab"));

    labs[0].addEquipment(Equipment(101, "Microscope", "Available"));
    labs[0].addEquipment(Equipment(102, "Thermometer", "In Use"));
    labs[1].addEquipment(Equipment(201, "Beaker", "Available"));

    cout << "Displaying Equipments in Laboratories" << endl;
    for (auto &lab : labs) {
        lab.displayEquipments();
    }

    cout << "\nUpdating Equipment Status..." << endl;
    labs[0].updateEquipment(101, "Microscope", "In Use");

    cout << "\nDisplaying Updated Equipments in Laboratories" << endl;
    for (auto &lab : labs) {
        lab.displayEquipments();
    }

    cout << "\nSearching for Equipment with ID 201:" << endl;
    labs[1].searchEquipment(201);

    cout << "\nDeleting Equipment with ID 201 from Chemistry Lab" << endl;
    labs[1].deleteEquipment(201);

    cout << "\nDisplaying Equipments after Deletion in Laboratories" << endl;
    for (auto &lab : labs) {
        lab.displayEquipments();
    }

    return 0;
}