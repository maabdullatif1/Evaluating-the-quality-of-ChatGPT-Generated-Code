#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string type;

    Equipment(int id, std::string name, std::string type) : id(id), name(name), type(type) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;

    Laboratory(int id, std::string name) : id(id), name(name) {}

    void addEquipment(const Equipment& equipment) {
        equipments.push_back(equipment);
    }

    bool removeEquipment(int equipmentId) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == equipmentId) {
                equipments.erase(it);
                return true;
            }
        }
        return false;
    }

    Equipment* findEquipment(int equipmentId) {
        for (auto& equipment : equipments) {
            if (equipment.id == equipmentId) {
                return &equipment;
            }
        }
        return nullptr;
    }
};

class EquipmentManagementSystem {
    std::vector<Laboratory> laboratories;

public:
    void addLaboratory(int id, std::string name) {
        laboratories.push_back(Laboratory(id, name));
    }

    bool deleteLaboratory(int labId) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == labId) {
                laboratories.erase(it);
                return true;
            }
        }
        return false;
    }

    Laboratory* findLaboratory(int labId) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void addEquipmentToLaboratory(int labId, int equipId, std::string name, std::string type) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) {
            lab->addEquipment(Equipment(equipId, name, type));
        }
    }

    bool removeEquipmentFromLaboratory(int labId, int equipId) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) {
            return lab->removeEquipment(equipId);
        }
        return false;
    }

    void updateEquipment(int labId, int equipId, std::string newName, std::string newType) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) {
            Equipment* equip = lab->findEquipment(equipId);
            if (equip) {
                equip->name = newName;
                equip->type = newType;
            }
        }
    }

    Equipment* searchEquipment(int equipId) {
        for (auto& lab : laboratories) {
            Equipment* equip = lab.findEquipment(equipId);
            if (equip) {
                return equip;
            }
        }
        return nullptr;
    }

    void display() {
        for (auto& lab : laboratories) {
            std::cout << "Lab ID: " << lab.id << ", Lab Name: " << lab.name << "\n";
            for (auto& equip : lab.equipments) {
                std::cout << "  Equipment ID: " << equip.id << ", Name: " << equip.name << ", Type: " << equip.type << "\n";
            }
        }
    }
};

int main() {
    EquipmentManagementSystem system;
    system.addLaboratory(1, "Physics Lab");
    system.addEquipmentToLaboratory(1, 101, "Oscilloscope", "Measurement");
    system.addEquipmentToLaboratory(1, 102, "Voltmeter", "Measurement");
    system.display();
    system.updateEquipment(1, 101, "Digital Oscilloscope", "Measurement");
    system.display();
    system.removeEquipmentFromLaboratory(1, 102);
    system.display();
    return 0;
}