#include <iostream>
#include <vector>
#include <string>

class Equipment {
    int id;
    std::string name;
    std::string description;

public:
    Equipment(int id, const std::string &name, const std::string &description)
        : id(id), name(name), description(description) {}

    int getId() const { return id; }
    const std::string &getName() const { return name; }
    const std::string &getDescription() const { return description; }

    void update(const std::string &newName, const std::string &newDescription) {
        name = newName;
        description = newDescription;
    }

    void display() const {
        std::cout << "Equipment ID: " << id << ", Name: " << name
                  << ", Description: " << description << std::endl;
    }
};

class Laboratory {
    int id;
    std::string name;
    std::vector<Equipment> equipments;

public:
    Laboratory(int id, const std::string &name) : id(id), name(name) {}

    int getId() const { return id; }
    const std::string &getName() const { return name; }

    void addEquipment(const Equipment &equipment) {
        equipments.push_back(equipment);
    }

    void deleteEquipment(int equipmentId) {
        equipments.erase(std::remove_if(equipments.begin(), equipments.end(),
                                        [equipmentId](const Equipment &e) { return e.getId() == equipmentId; }),
                         equipments.end());
    }

    Equipment *searchEquipment(int equipmentId) {
        for (auto &equipment : equipments) {
            if (equipment.getId() == equipmentId) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void display() const {
        std::cout << "Laboratory ID: " << id << ", Name: " << name << std::endl;
        for (const auto &equipment : equipments) {
            equipment.display();
        }
    }
};

class EquipmentManagementSystem {
    std::vector<Laboratory> laboratories;

public:
    void addLaboratory(const Laboratory &laboratory) {
        laboratories.push_back(laboratory);
    }

    void deleteLaboratory(int labId) {
        laboratories.erase(std::remove_if(laboratories.begin(), laboratories.end(),
                                          [labId](const Laboratory &lab) { return lab.getId() == labId; }),
                           laboratories.end());
    }

    Laboratory *searchLaboratory(int labId) {
        for (auto &lab : laboratories) {
            if (lab.getId() == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayAll() const {
        for (const auto &lab : laboratories) {
            lab.display();
        }
    }

    void updateEquipment(int labId, int equipmentId, const std::string &newName, const std::string &newDescription) {
        Laboratory *lab = searchLaboratory(labId);
        if (lab) {
            Equipment *equipment = lab->searchEquipment(equipmentId);
            if (equipment) {
                equipment->update(newName, newDescription);
            }
        }
    }
};

int main() {
    EquipmentManagementSystem system;

    Laboratory lab1(1, "Physics Lab");
    lab1.addEquipment(Equipment(101, "Microscope", "Optical magnifying device"));
    lab1.addEquipment(Equipment(102, "Thermometer", "Temperature measuring device"));
    system.addLaboratory(lab1);

    Laboratory lab2(2, "Chemistry Lab");
    lab2.addEquipment(Equipment(201, "Beaker", "Glass container for experiments"));
    system.addLaboratory(lab2);

    system.displayAll();

    system.updateEquipment(1, 101, "Digital Microscope", "Advanced optical magnifying device");
    system.displayAll();

    system.deleteLaboratory(2);
    system.displayAll();

    return 0;
}