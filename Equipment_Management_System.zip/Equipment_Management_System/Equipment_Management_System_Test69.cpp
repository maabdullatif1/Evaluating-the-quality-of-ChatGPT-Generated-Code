#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    string id;
    string name;
    string description;
};

class Laboratory {
public:
    string id;
    string name;
    vector<Equipment> equipmentList;
};

vector<Laboratory> laboratories;

void addLaboratory() {
    Laboratory lab;
    cout << "Enter Laboratory ID: ";
    cin >> lab.id;
    cout << "Enter Laboratory Name: ";
    cin >> lab.name;
    laboratories.push_back(lab);
}

void deleteLaboratory() {
    string id;
    cout << "Enter Laboratory ID to delete: ";
    cin >> id;
    for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
        if (it->id == id) {
            laboratories.erase(it);
            break;
        }
    }
}

void addEquipment() {
    string labId;
    cout << "Enter Laboratory ID to add equipment: ";
    cin >> labId;
    for (auto &lab : laboratories) {
        if (lab.id == labId) {
            Equipment eq;
            cout << "Enter Equipment ID: ";
            cin >> eq.id;
            cout << "Enter Equipment Name: ";
            cin >> eq.name;
            cout << "Enter Equipment Description: ";
            cin.ignore();
            getline(cin, eq.description);
            lab.equipmentList.push_back(eq);
            break;
        }
    }
}

void deleteEquipment() {
    string labId, eqId;
    cout << "Enter Laboratory ID: ";
    cin >> labId;
    for (auto &lab : laboratories) {
        if (lab.id == labId) {
            cout << "Enter Equipment ID to delete: ";
            cin >> eqId;
            for (auto it = lab.equipmentList.begin(); it != lab.equipmentList.end(); ++it) {
                if (it->id == eqId) {
                    lab.equipmentList.erase(it);
                    break;
                }
            }
            break;
        }
    }
}

void updateEquipment() {
    string labId, eqId;
    cout << "Enter Laboratory ID: ";
    cin >> labId;
    for (auto &lab : laboratories) {
        if (lab.id == labId) {
            cout << "Enter Equipment ID to update: ";
            cin >> eqId;
            for (auto &eq : lab.equipmentList) {
                if (eq.id == eqId) {
                    cout << "Enter new Equipment Name: ";
                    cin >> eq.name;
                    cout << "Enter new Equipment Description: ";
                    cin.ignore();
                    getline(cin, eq.description);
                    break;
                }
            }
            break;
        }
    }
}

void searchEquipment() {
    string eqId;
    cout << "Enter Equipment ID to search: ";
    cin >> eqId;
    for (const auto &lab : laboratories) {
        for (const auto &eq : lab.equipmentList) {
            if (eq.id == eqId) {
                cout << "Equipment found in Laboratory: " << lab.name << endl;
                cout << "Equipment Name: " << eq.name << ", Description: " << eq.description << endl;
                return;
            }
        }
    }
    cout << "Equipment not found." << endl;
}

void displayAll() {
    for (const auto &lab : laboratories) {
        cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << endl;
        for (const auto &eq : lab.equipmentList) {
            cout << "    Equipment ID: " << eq.id << ", Name: " << eq.name << ", Description: " << eq.description << endl;
        }
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Laboratory" << endl;
        cout << "2. Delete Laboratory" << endl;
        cout << "3. Add Equipment" << endl;
        cout << "4. Delete Equipment" << endl;
        cout << "5. Update Equipment" << endl;
        cout << "6. Search Equipment" << endl;
        cout << "7. Display All" << endl;
        cout << "0. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;
        
        switch (choice) {
            case 1: addLaboratory(); break;
            case 2: deleteLaboratory(); break;
            case 3: addEquipment(); break;
            case 4: deleteEquipment(); break;
            case 5: updateEquipment(); break;
            case 6: searchEquipment(); break;
            case 7: displayAll(); break;
            case 0: break;
            default: cout << "Invalid choice!" << endl;
        }
    } while (choice != 0);
    
    return 0;
}