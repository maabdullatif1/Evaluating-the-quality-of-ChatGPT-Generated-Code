#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string description;

    Equipment(int i, std::string n, std::string d) : id(i), name(n), description(d) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::string location;

    Laboratory(int i, std::string n, std::string l) : id(i), name(n), location(l) {}
};

class ManagementSystem {
    std::vector<Equipment> equipments;
    std::vector<Laboratory> laboratories;
    
public:
    void addEquipment(int id, std::string name, std::string description) {
        equipments.push_back(Equipment(id, name, description));
    }
    
    void deleteEquipment(int id) {
        for (size_t i = 0; i < equipments.size(); i++) {
            if (equipments[i].id == id) {
                equipments.erase(equipments.begin() + i);
                break;
            }
        }
    }
    
    void updateEquipment(int id, std::string name, std::string description) {
        for (auto &e : equipments) {
            if (e.id == id) {
                e.name = name;
                e.description = description;
                break;
            }
        }
    }
    
    Equipment* searchEquipment(int id) {
        for (auto &e : equipments) {
            if (e.id == id) {
                return &e;
            }
        }
        return nullptr;
    }
    
    void displayEquipments() {
        for (const auto &e : equipments) {
            std::cout << "ID: " << e.id << ", Name: " << e.name << ", Description: " << e.description << std::endl;
        }
    }

    void addLaboratory(int id, std::string name, std::string location) {
        laboratories.push_back(Laboratory(id, name, location));
    }
    
    void deleteLaboratory(int id) {
        for (size_t i = 0; i < laboratories.size(); i++) {
            if (laboratories[i].id == id) {
                laboratories.erase(laboratories.begin() + i);
                break;
            }
        }
    }
    
    void updateLaboratory(int id, std::string name, std::string location) {
        for (auto &l : laboratories) {
            if (l.id == id) {
                l.name = name;
                l.location = location;
                break;
            }
        }
    }
    
    Laboratory* searchLaboratory(int id) {
        for (auto &l : laboratories) {
            if (l.id == id) {
                return &l;
            }
        }
        return nullptr;
    }
    
    void displayLaboratories() {
        for (const auto &l : laboratories) {
            std::cout << "ID: " << l.id << ", Name: " << l.name << ", Location: " << l.location << std::endl;
        }
    }
};

int main() {
    ManagementSystem ms;
    ms.addEquipment(1, "Microscope", "Used for magnifying small samples");
    ms.addEquipment(2, "Bunsen Burner", "Used for heating substances");
    
    ms.addLaboratory(1, "Chemistry Lab", "Building A, Room 101");
    ms.addLaboratory(2, "Physics Lab", "Building B, Room 202");
    
    ms.displayEquipments();
    ms.displayLaboratories();
    
    ms.updateEquipment(1, "Advanced Microscope", "Used for detailed magnifications");
    Equipment* eq = ms.searchEquipment(1);
    if (eq) {
        std::cout << "Found Equipment - ID: " << eq->id << ", Name: " << eq->name << std::endl;
    }
    
    ms.deleteLaboratory(1);
    ms.displayLaboratories();
    
    return 0;
}