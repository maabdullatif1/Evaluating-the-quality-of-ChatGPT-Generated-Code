#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string description;
    Equipment(int id, string name, string description)
        : id(id), name(name), description(description) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipmentList;
    Laboratory(int id, string name) : id(id), name(name) {}
    
    void addEquipment(const Equipment& equipment) {
        equipmentList.push_back(equipment);
    }

    void updateEquipment(int equipmentId, const string& newName, const string& newDescription) {
        for (auto& equipment : equipmentList) {
            if (equipment.id == equipmentId) {
                equipment.name = newName;
                equipment.description = newDescription;
                return;
            }
        }
    }

    void deleteEquipment(int equipmentId) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == equipmentId) {
                equipmentList.erase(it);
                return;
            }
        }
    }

    Equipment* searchEquipment(int equipmentId) {
        for (auto& equipment : equipmentList) {
            if (equipment.id == equipmentId) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void displayEquipment() const {
        for (const auto& equipment : equipmentList) {
            cout << "Equipment ID: " << equipment.id
                 << ", Name: " << equipment.name
                 << ", Description: " << equipment.description << endl;
        }
    }
};

class EquipmentManagementSystem {
private:
    vector<Laboratory> laboratories;
public:
    void addLaboratory(const Laboratory& lab) {
        laboratories.push_back(lab);
    }

    void updateLaboratory(int labId, const string& newName) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                lab.name = newName;
                return;
            }
        }
    }

    void deleteLaboratory(int labId) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == labId) {
                laboratories.erase(it);
                return;
            }
        }
    }

    Laboratory* searchLaboratory(int labId) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLaboratories() const {
        for (const auto& lab : laboratories) {
            cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << endl;
            lab.displayEquipment();
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addLaboratory(Laboratory(1, "Physics Lab"));
    ems.addLaboratory(Laboratory(2, "Chemistry Lab"));

    Laboratory* lab1 = ems.searchLaboratory(1);
    if (lab1) {
        lab1->addEquipment(Equipment(101, "Microscope", "Used for magnification"));
        lab1->addEquipment(Equipment(102, "Spectrometer", "Used to measure spectral content"));

        lab1->updateEquipment(101, "Advanced Microscope", "Provides greater magnification");

        lab1->deleteEquipment(102);
    }

    ems.displayLaboratories();

    return 0;
}