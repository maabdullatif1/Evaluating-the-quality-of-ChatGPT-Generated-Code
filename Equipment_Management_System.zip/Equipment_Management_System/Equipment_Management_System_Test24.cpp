#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string description;

    Equipment(int id, std::string name, std::string description) 
        : id(id), name(name), description(description) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipmentList;

    Laboratory(int id, std::string name) : id(id), name(name) {}

    void addEquipment(const Equipment& equipment) {
        equipmentList.push_back(equipment);
    }

    void removeEquipment(int equipmentId) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == equipmentId) {
                equipmentList.erase(it);
                return;
            }
        }
    }

    void updateEquipment(int equipmentId, const std::string& newName, const std::string& newDescription) {
        for (auto& equipment : equipmentList) {
            if (equipment.id == equipmentId) {
                equipment.name = newName;
                equipment.description = newDescription;
                return;
            }
        }
    }

    Equipment* searchEquipment(int equipmentId) {
        for (auto& equipment : equipmentList) {
            if (equipment.id == equipmentId) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void displayEquipment() const {
        for (const auto& equipment : equipmentList) {
            std::cout << "Equipment ID: " << equipment.id 
                      << ", Name: " << equipment.name 
                      << ", Description: " << equipment.description << std::endl;
        }
    }
};

class EquipmentManagementSystem {
private:
    std::vector<Laboratory> laboratories;
    
public:
    void addLaboratory(int id, const std::string& name) {
        laboratories.push_back(Laboratory(id, name));
    }

    void addEquipmentToLaboratory(int labId, const Equipment& equipment) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                lab.addEquipment(equipment);
                return;
            }
        }
    }

    void deleteEquipmentFromLaboratory(int labId, int equipmentId) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                lab.removeEquipment(equipmentId);
                return;
            }
        }
    }

    void updateEquipmentInLaboratory(int labId, int equipmentId, const std::string& newName, const std::string& newDescription) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                lab.updateEquipment(equipmentId, newName, newDescription);
                return;
            }
        }
    }

    void displayLaboratories() const {
        for (const auto& lab : laboratories) {
            std::cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << std::endl;
            lab.displayEquipment();
        }
    }
};

int main() {
    EquipmentManagementSystem system;
    system.addLaboratory(1, "Physics Lab");
    system.addLaboratory(2, "Chemistry Lab");

    system.addEquipmentToLaboratory(1, Equipment(1, "Microscope", "Optical microscope"));
    system.addEquipmentToLaboratory(1, Equipment(2, "Spectrometer", "Measure properties of light"));
    system.addEquipmentToLaboratory(2, Equipment(3, "Beaker", "Simple container for stirring, mixing"));

    system.displayLaboratories();

    system.updateEquipmentInLaboratory(1, 1, "Electron Microscope", "Advanced microscope");

    system.deleteEquipmentFromLaboratory(2, 3);

    system.displayLaboratories();

    return 0;
}