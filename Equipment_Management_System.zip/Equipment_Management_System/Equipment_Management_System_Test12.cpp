#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string description;

    Equipment(int id, const std::string& name, const std::string& description)
        : id(id), name(name), description(description) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;

    Laboratory(int id, const std::string& name)
        : id(id), name(name) {}
};

class ManagementSystem {
private:
    std::vector<Laboratory> laboratories;

    Laboratory* findLabById(int labId) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) return &lab;
        }
        return nullptr;
    }
    
    Equipment* findEquipmentById(Laboratory& lab, int equipId) {
        for (auto& equipment : lab.equipments) {
            if (equipment.id == equipId) return &equipment;
        }
        return nullptr;
    }

public:
    void addLaboratory(int id, const std::string& name) {
        laboratories.emplace_back(id, name);
    }

    void deleteLaboratory(int id) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == id) {
                laboratories.erase(it);
                return;
            }
        }
    }

    void addEquipment(int labId, int equipId, const std::string& name, const std::string& description) {
        Laboratory* lab = findLabById(labId);
        if (lab) {
            lab->equipments.emplace_back(equipId, name, description);
        }
    }

    void deleteEquipment(int labId, int equipId) {
        Laboratory* lab = findLabById(labId);
        if (lab) {
            for (auto it = lab->equipments.begin(); it != lab->equipments.end(); ++it) {
                if (it->id == equipId) {
                    lab->equipments.erase(it);
                    return;
                }
            }
        }
    }

    void updateEquipment(int labId, int equipId, const std::string& name, const std::string& description) {
        Laboratory* lab = findLabById(labId);
        if (lab) {
            Equipment* equip = findEquipmentById(*lab, equipId);
            if (equip) {
                equip->name = name;
                equip->description = description;
            }
        }
    }

    Equipment* searchEquipment(int labId, int equipId) {
        Laboratory* lab = findLabById(labId);
        if (lab) {
            return findEquipmentById(*lab, equipId);
        }
        return nullptr;
    }

    void displayLaboratories() {
        for (const auto& lab : laboratories) {
            std::cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << std::endl;
            for (const auto& equip : lab.equipments) {
                std::cout << "  Equipment ID: " << equip.id << ", Name: " << equip.name 
                          << ", Description: " << equip.description << std::endl;
            }
        }
    }
};

int main() {
    ManagementSystem system;
    system.addLaboratory(1, "Physics Lab");
    system.addEquipment(1, 101, "Microscope", "An electron microscope.");
    system.addEquipment(1, 102, "Spectrometer", "Used for mass spectrometry.");
    system.displayLaboratories();
    system.updateEquipment(1, 101, "Advanced Microscope", "A high-resolution electron microscope.");
    Equipment* equipment = system.searchEquipment(1, 101);
    if (equipment) {
        std::cout << "Found Equipment - ID: " << equipment->id << ", Name: " << equipment->name << std::endl;
    }
    system.deleteEquipment(1, 102);
    system.displayLaboratories();
    system.deleteLaboratory(1);
    system.displayLaboratories();
    return 0;
}