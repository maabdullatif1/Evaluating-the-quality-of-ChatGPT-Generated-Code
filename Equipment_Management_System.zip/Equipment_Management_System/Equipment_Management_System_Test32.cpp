#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string description;

    Equipment(int id, std::string name, std::string description)
        : id(id), name(name), description(description) {}

    void display() const {
        std::cout << "ID: " << id << ", Name: " << name << ", Description: " << description << std::endl;
    }
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;

    Laboratory(int id, std::string name)
        : id(id), name(name) {}

    void addEquipment(const Equipment& equipment) {
        equipments.push_back(equipment);
    }

    void deleteEquipment(int equipmentID) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == equipmentID) {
                equipments.erase(it);
                break;
            }
        }
    }

    void display() const {
        std::cout << "Laboratory ID: " << id << ", Name: " << name << std::endl;
        for (const auto& equipment : equipments) {
            equipment.display();
        }
    }
};

class EquipmentManagementSystem {
    std::vector<Laboratory> laboratories;

public:
    void addLab(int id, std::string name) {
        laboratories.push_back(Laboratory(id, name));
    }

    void addEquipmentToLab(int labID, const Equipment& equipment) {
        for (auto& lab : laboratories) {
            if (lab.id == labID) {
                lab.addEquipment(equipment);
                break;
            }
        }
    }

    void deleteLab(int labID) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == labID) {
                laboratories.erase(it);
                break;
            }
        }
    }

    void updateLabName(int labID, std::string newName) {
        for (auto& lab : laboratories) {
            if (lab.id == labID) {
                lab.name = newName;
                break;
            }
        }
    }

    void updateEquipment(int labID, int equipmentID, std::string newName, std::string newDescription) {
        for (auto& lab : laboratories) {
            if (lab.id == labID) {
                for (auto& equipment : lab.equipments) {
                    if (equipment.id == equipmentID) {
                        equipment.name = newName;
                        equipment.description = newDescription;
                        break;
                    }
                }
            }
        }
    }

    void deleteEquipmentFromLab(int labID, int equipmentID) {
        for (auto& lab : laboratories) {
            if (lab.id == labID) {
                lab.deleteEquipment(equipmentID);
                break;
            }
        }
    }

    void searchLabByID(int labID) const {
        for (const auto& lab : laboratories) {
            if (lab.id == labID) {
                lab.display();
                return;
            }
        }
        std::cout << "Laboratory not found." << std::endl;
    }

    void searchEquipmentByID(int labID, int equipmentID) const {
        for (const auto& lab : laboratories) {
            if (lab.id == labID) {
                for (const auto& equipment : lab.equipments) {
                    if (equipment.id == equipmentID) {
                        equipment.display();
                        return;
                    }
                }
            }
        }
        std::cout << "Equipment not found." << std::endl;
    }

    void displayAll() const {
        for (const auto& lab : laboratories) {
            lab.display();
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addLab(1, "Physics Lab");
    ems.addLab(2, "Chemistry Lab");

    ems.addEquipmentToLab(1, Equipment(101, "Microscope", "Optical instrument"));
    ems.addEquipmentToLab(1, Equipment(102, "Spectrometer", "Device for measuring wavelengths"));

    ems.addEquipmentToLab(2, Equipment(201, "Burette", "Glass tube with a tap"));
    
    ems.displayAll();

    ems.updateLabName(1, "Advanced Physics Lab");
    ems.updateEquipment(1, 101, "Scanning Electron Microscope", "Advanced optical instrument");
    
    ems.searchLabByID(1);
    ems.searchEquipmentByID(2, 201);
    
    ems.deleteEquipmentFromLab(1, 102);
    ems.deleteLab(2);

    ems.displayAll();

    return 0;
}