#include <iostream>
#include <string>
#include <vector>

class Equipment {
public:
    int id;
    std::string name;
    std::string description;

    Equipment(int id, const std::string& name, const std::string& description)
        : id(id), name(name), description(description) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;

    Laboratory(int id, const std::string& name)
        : id(id), name(name) {}

    void addEquipment(Equipment equipment) {
        equipments.push_back(equipment);
    }

    void deleteEquipment(int equipmentId) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == equipmentId) {
                equipments.erase(it);
                return;
            }
        }
    }

    Equipment* searchEquipment(int equipmentId) {
        for (auto& equipment : equipments) {
            if (equipment.id == equipmentId) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void displayEquipments() const {
        for (const auto& equipment : equipments) {
            std::cout << "  Equipment ID: " << equipment.id
                      << ", Name: " << equipment.name
                      << ", Description: " << equipment.description << '\n';
        }
    }
};

class EquipmentManagementSystem {
public:
    std::vector<Laboratory> labs;

    void addLaboratory(Laboratory lab) {
        labs.push_back(lab);
    }

    void deleteLaboratory(int labId) {
        for (auto it = labs.begin(); it != labs.end(); ++it) {
            if (it->id == labId) {
                labs.erase(it);
                return;
            }
        }
    }

    Laboratory* searchLaboratory(int labId) {
        for (auto& lab : labs) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayAll() const {
        for (const auto& lab : labs) {
            std::cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << '\n';
            lab.displayEquipments();
        }
    }
};

int main() {
    EquipmentManagementSystem system;

    Laboratory lab1(1, "Physics Lab");
    lab1.addEquipment(Equipment(101, "Microscope", "Used for magnifying objects"));
    lab1.addEquipment(Equipment(102, "Spectrometer", "Used to measure properties of light"));

    system.addLaboratory(lab1);

    Laboratory lab2(2, "Chemistry Lab");
    lab2.addEquipment(Equipment(201, "Beaker", "Used for holding liquids"));

    system.addLaboratory(lab2);

    system.displayAll();

    Laboratory* lab = system.searchLaboratory(1);
    if (lab) {
        lab->deleteEquipment(102);
    }

    Equipment* equipment = lab->searchEquipment(101);
    if (equipment) {
        equipment->name = "Advanced Microscope";
    }

    system.displayAll();

    return 0;
}