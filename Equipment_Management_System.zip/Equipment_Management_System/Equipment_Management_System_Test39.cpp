#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string description;
    Equipment(int i, string n, string d) : id(i), name(n), description(d) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipments;
    Laboratory(int i, string n) : id(i), name(n) {}
};

class System {
private:
    vector<Laboratory> laboratories;
    
    Laboratory* findLaboratory(int labId) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) return &lab;
        }
        return nullptr;
    }
    
    Equipment* findEquipment(Laboratory& lab, int equipId) {
        for (auto &equip : lab.equipments) {
            if (equip.id == equipId) return &equip;
        }
        return nullptr;
    }
    
public:
    void addLaboratory(int id, string name) {
        laboratories.push_back(Laboratory(id, name));
    }
    
    void deleteLaboratory(int id) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == id) {
                laboratories.erase(it);
                return;
            }
        }
    }
    
    void updateLaboratory(int id, string newName) {
        Laboratory* lab = findLaboratory(id);
        if (lab) lab->name = newName;
    }
    
    void searchLaboratory(int id) {
        Laboratory* lab = findLaboratory(id);
        if (lab) {
            cout << "Lab ID: " << lab->id << ", Name: " << lab->name << endl;
            for (auto &equip : lab->equipments) {
                cout << "  Equip ID: " << equip.id << ", Name: " << equip.name << ", Desc: " << equip.description << endl;
            }
        }
    }
    
    void displayLaboratories() {
        for (auto &lab : laboratories) {
            cout << "Lab ID: " << lab.id << ", Name: " << lab.name << endl;
        }
    }
    
    void addEquipment(int labId, int equipId, string name, string desc) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) lab->equipments.push_back(Equipment(equipId, name, desc));
    }
    
    void deleteEquipment(int labId, int equipId) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) {
            for (auto it = lab->equipments.begin(); it != lab->equipments.end(); ++it) {
                if (it->id == equipId) {
                    lab->equipments.erase(it);
                    return;
                }
            }
        }
    }
    
    void updateEquipment(int labId, int equipId, string newName, string newDesc) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) {
            Equipment* equip = findEquipment(*lab, equipId);
            if (equip) {
                equip->name = newName;
                equip->description = newDesc;
            }
        }
    }
    
    void searchEquipment(int labId, int equipId) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) {
            Equipment* equip = findEquipment(*lab, equipId);
            if (equip) {
                cout << "Equip ID: " << equip->id << ", Name: " << equip->name << ", Desc: " << equip->description << endl;
            }
        }
    }
    
    void displayEquipments(int labId) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) {
            for (auto &equip : lab->equipments) {
                cout << "Equip ID: " << equip.id << ", Name: " << equip.name << ", Desc: " << equip.description << endl;
            }
        }
    }
};

int main() {
    System sys;
    sys.addLaboratory(1, "Lab A");
    sys.addLaboratory(2, "Lab B");
    sys.addEquipment(1, 101, "Microscope", "Optical Microscope");
    sys.addEquipment(1, 102, "Centrifuge", "High-speed Centrifuge");
    sys.addEquipment(2, 201, "Spectrometer", "Mass Spectrometer");

    sys.displayLaboratories();
    sys.searchLaboratory(1);
    sys.displayEquipments(1);

    sys.updateLaboratory(1, "Physics Lab");
    sys.updateEquipment(1, 101, "Electronics Microscope", "Updated Optical Microscope");

    sys.searchLaboratory(1);
    sys.searchEquipment(1, 101);

    sys.deleteEquipment(1, 102);
    sys.deleteLaboratory(2);

    sys.displayLaboratories();
}