#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string description;

    Equipment(int _id, const std::string& _name, const std::string& _description) 
        : id(_id), name(_name), description(_description) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;

    Laboratory(int _id, const std::string& _name) : id(_id), name(_name) {}
};

class EquipmentManagementSystem {
private:
    std::vector<Laboratory> laboratories;

    Laboratory* findLaboratoryById(int labId) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    Equipment* findEquipmentById(Laboratory& lab, int equipId) {
        for (auto& equip : lab.equipments) {
            if (equip.id == equipId) {
                return &equip;
            }
        }
        return nullptr;
    }

public:
    void addLaboratory(int id, const std::string& name) {
        laboratories.emplace_back(id, name);
    }

    void addEquipment(int labId, int id, const std::string& name, const std::string& description) {
        Laboratory* lab = findLaboratoryById(labId);
        if (lab) {
            lab->equipments.emplace_back(id, name, description);
        }
    }

    void deleteEquipment(int labId, int equipId) {
        Laboratory* lab = findLaboratoryById(labId);
        if (lab) {
            auto& equipments = lab->equipments;
            equipments.erase(std::remove_if(equipments.begin(), equipments.end(),
                [=](Equipment& equip) { return equip.id == equipId; }), equipments.end());
        }
    }

    void updateEquipment(int labId, int equipId, const std::string& newName, const std::string& newDescription) {
        Laboratory* lab = findLaboratoryById(labId);
        if (lab) {
            Equipment* equip = findEquipmentById(*lab, equipId);
            if (equip) {
                equip->name = newName;
                equip->description = newDescription;
            }
        }
    }

    Equipment* searchEquipment(int labId, int equipId) {
        Laboratory* lab = findLaboratoryById(labId);
        if (lab) {
            return findEquipmentById(*lab, equipId);
        }
        return nullptr;
    }

    void display() {
        for (const auto& lab : laboratories) {
            std::cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << "\n";
            for (const auto& equip : lab.equipments) {
                std::cout << "  Equipment ID: " << equip.id << ", Name: " << equip.name 
                          << ", Description: " << equip.description << "\n";
            }
        }
    }
};

int main() {
    EquipmentManagementSystem ems;

    ems.addLaboratory(1, "Physics Lab");
    ems.addLaboratory(2, "Chemistry Lab");

    ems.addEquipment(1, 101, "Microscope", "Used for viewing small objects");
    ems.addEquipment(1, 102, "Spectrometer", "Measures light properties");

    ems.addEquipment(2, 201, "Bunsen Burner", "Provides a single open gas flame");

    ems.updateEquipment(1, 102, "Updated Spectrometer", "Updated description");

    ems.display();

    Equipment* equip = ems.searchEquipment(1, 101);
    if (equip) {
        std::cout << "Found Equipment ID: " << equip->id << ", Name: " << equip->name << "\n";
    }

    ems.deleteEquipment(1, 101);

    ems.display();

    return 0;
}