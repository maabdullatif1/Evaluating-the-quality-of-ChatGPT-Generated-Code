#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string type;
    Equipment(int id, std::string name, std::string type) : id(id), name(name), type(type) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;
    Laboratory(int id, std::string name) : id(id), name(name) {}
};

class EquipmentManagementSystem {
private:
    std::vector<Laboratory> laboratories;
public:
    void addLaboratory(int id, const std::string& name) {
        laboratories.push_back(Laboratory(id, name));
    }

    void deleteLaboratory(int id) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == id) {
                laboratories.erase(it);
                return;
            }
        }
    }

    void updateLaboratory(int id, const std::string& newName) {
        for (auto& lab : laboratories) {
            if (lab.id == id) {
                lab.name = newName;
                return;
            }
        }
    }

    Laboratory* searchLaboratory(int id) {
        for (auto& lab : laboratories) {
            if (lab.id == id) {
                return &lab;
            }
        }
        return nullptr;
    }

    void addEquipment(int labId, int equipId, const std::string& name, const std::string& type) {
        Laboratory* lab = searchLaboratory(labId);
        if (lab != nullptr) {
            lab->equipments.push_back(Equipment(equipId, name, type));
        }
    }

    void deleteEquipment(int labId, int equipId) {
        Laboratory* lab = searchLaboratory(labId);
        if (lab != nullptr) {
            for (auto it = lab->equipments.begin(); it != lab->equipments.end(); ++it) {
                if (it->id == equipId) {
                    lab->equipments.erase(it);
                    return;
                }
            }
        }
    }

    void updateEquipment(int labId, int equipId, const std::string& newName, const std::string& newType) {
        Laboratory* lab = searchLaboratory(labId);
        if (lab != nullptr) {
            for (auto& eq : lab->equipments) {
                if (eq.id == equipId) {
                    eq.name = newName;
                    eq.type = newType;
                    return;
                }
            }
        }
    }

    Equipment* searchEquipment(int labId, int equipId) {
        Laboratory* lab = searchLaboratory(labId);
        if (lab != nullptr) {
            for (auto& eq : lab->equipments) {
                if (eq.id == equipId) {
                    return &eq;
                }
            }
        }
        return nullptr;
    }

    void displayLaboratories() {
        for (const auto& lab : laboratories) {
            std::cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << std::endl;
        }
    }

    void displayEquipments(int labId) {
        Laboratory* lab = searchLaboratory(labId);
        if (lab != nullptr) {
            for (const auto& eq : lab->equipments) {
                std::cout << "Equipment ID: " << eq.id << ", Name: " << eq.name << ", Type: " << eq.type << std::endl;
            }
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addLaboratory(1, "Physics Lab");
    ems.addEquipment(1, 101, "Microscope", "Optical");
    ems.displayLaboratories();
    ems.displayEquipments(1);
    return 0;
}