#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Equipment {
public:
    int id;
    string name;
    string type;
    Equipment(int i, string n, string t) : id(i), name(n), type(t) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipments;
    Laboratory(int i, string n) : id(i), name(n) {}
};

class EquipmentManagementSystem {
private:
    vector<Laboratory> laboratories;
    int equipmentIdCounter = 1;
    int labIdCounter = 1;

public:
    void addLaboratory(string name) {
        laboratories.push_back(Laboratory(labIdCounter++, name));
    }

    void deleteLaboratory(int labId) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == labId) {
                laboratories.erase(it);
                break;
            }
        }
    }

    void addEquipment(int labId, string name, string type) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) {
                lab.equipments.push_back(Equipment(equipmentIdCounter++, name, type));
                break;
            }
        }
    }

    void deleteEquipment(int labId, int equipmentId) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) {
                for (auto it = lab.equipments.begin(); it != lab.equipments.end(); ++it) {
                    if (it->id == equipmentId) {
                        lab.equipments.erase(it);
                        break;
                    }
                }
            }
        }
    }

    void updateEquipment(int labId, int equipmentId, string name, string type) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) {
                for (auto &equip : lab.equipments) {
                    if (equip.id == equipmentId) {
                        equip.name = name;
                        equip.type = type;
                        return;
                    }
                }
            }
        }
    }

    void searchEquipment(string name) {
        for (const auto &lab : laboratories) {
            for (const auto &equip : lab.equipments) {
                if (equip.name == name) {
                    cout << "Found Equipment: " << equip.name 
                         << ", Type: " << equip.type 
                         << ", Lab: " << lab.name << endl;
                }
            }
        }
    }

    void displayEquipment(int labId) {
        for (const auto &lab : laboratories) {
            if (lab.id == labId) {
                cout << "Laboratory: " << lab.name << endl;
                for (const auto &equip : lab.equipments) {
                    cout << "Equipment ID: " << equip.id 
                         << ", Name: " << equip.name 
                         << ", Type: " << equip.type << endl;
                }
            }
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addLaboratory("Physics Lab");
    ems.addEquipment(1, "Spectrometer", "Optical");
    ems.addEquipment(1, "Microscope", "Biological");
    ems.displayEquipment(1);
    ems.updateEquipment(1, 1, "Spectrometer", "Updated Optical");
    ems.searchEquipment("Microscope");
    ems.deleteEquipment(1, 1);
    ems.deleteLaboratory(1);
    return 0;
}