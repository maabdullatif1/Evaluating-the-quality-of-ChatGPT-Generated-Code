#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    Equipment(int id, const std::string& name) : id(id), name(name) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;
    Laboratory(int id, const std::string& name) : id(id), name(name) {}
};

class ManagementSystem {
private:
    std::vector<Equipment> equipments;
    std::vector<Laboratory> laboratories;

    Equipment* findEquipment(int id) {
        for (auto &equipment : equipments) {
            if (equipment.id == id) {
                return &equipment;
            }
        }
        return nullptr;
    }

    Laboratory* findLaboratory(int id) {
        for (auto &lab : laboratories) {
            if (lab.id == id) {
                return &lab;
            }
        }
        return nullptr;
    }

public:
    void addEquipment(int id, const std::string& name) {
        if (!findEquipment(id)) {
            equipments.emplace_back(id, name);
        }
    }

    void deleteEquipment(int id) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == id) {
                equipments.erase(it);
                break;
            }
        }

        for (auto &lab : laboratories) {
            lab.equipments.erase(std::remove_if(lab.equipments.begin(), lab.equipments.end(),
                [&](const Equipment &e) { return e.id == id; }), lab.equipments.end());
        }
    }

    void updateEquipment(int id, const std::string& newName) {
        Equipment* equipment = findEquipment(id);
        if (equipment) {
            equipment->name = newName;
        }
    }

    void addLaboratory(int id, const std::string& name) {
        if (!findLaboratory(id)) {
            laboratories.emplace_back(id, name);
        }
    }

    void deleteLaboratory(int id) {
        laboratories.erase(std::remove_if(laboratories.begin(), laboratories.end(), 
                    [&](const Laboratory &l) { return l.id == id; }), laboratories.end());
    }

    void updateLaboratory(int id, const std::string& newName) {
        Laboratory* lab = findLaboratory(id);
        if (lab) {
            lab->name = newName;
        }
    }

    void assignEquipmentToLab(int equipId, int labId) {
        Equipment* equip = findEquipment(equipId);
        Laboratory* lab = findLaboratory(labId);
        if (equip && lab) {
            lab->equipments.push_back(*equip);
        }
    }

    void searchEquipment(int id) {
        Equipment* equipment = findEquipment(id);
        if (equipment) {
            std::cout << "Equipment ID: " << equipment->id << ", Name: " << equipment->name << std::endl;
        } else {
            std::cout << "Equipment not found." << std::endl;
        }
    }

    void searchLaboratory(int id) {
        Laboratory* lab = findLaboratory(id);
        if (lab) {
            std::cout << "Laboratory ID: " << lab->id << ", Name: " << lab->name << std::endl;
            std::cout << "Equipments: ";
            for (const auto& equipment : lab->equipments) {
                std::cout << equipment.name << " ";
            }
            std::cout << std::endl;
        } else {
            std::cout << "Laboratory not found." << std::endl;
        }
    }

    void displayEquipments() {
        for (const auto& equipment : equipments) {
            std::cout << "Equipment ID: " << equipment.id << ", Name: " << equipment.name << std::endl;
        }
    }

    void displayLaboratories() {
        for (const auto& lab : laboratories) {
            std::cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << std::endl;
            std::cout << "Equipments: ";
            for (const auto& equipment : lab.equipments) {
                std::cout << equipment.name << " ";
            }
            std::cout << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;

    system.addEquipment(1, "Microscope");
    system.addEquipment(2, "Centrifuge");
    system.updateEquipment(2, "High-speed Centrifuge");

    system.addLaboratory(1, "Biology Lab");
    system.addLaboratory(2, "Chemistry Lab");

    system.assignEquipmentToLab(1, 1);
    system.assignEquipmentToLab(2, 1);
    system.assignEquipmentToLab(1, 2);

    system.searchEquipment(1);
    system.searchLaboratory(1);

    system.displayEquipments();
    system.displayLaboratories();

    system.deleteEquipment(1);
    system.deleteLaboratory(2);

    system.displayEquipments();
    system.displayLaboratories();

    return 0;
}