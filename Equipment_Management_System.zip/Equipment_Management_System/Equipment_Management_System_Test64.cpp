#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string type;

    Equipment(int id, string name, string type) : id(id), name(name), type(type) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipments;

    Laboratory(int id, string name) : id(id), name(name) {}

    void addEquipment(Equipment equipment) {
        equipments.push_back(equipment);
    }

    bool removeEquipment(int equipmentId) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == equipmentId) {
                equipments.erase(it);
                return true;
            }
        }
        return false;
    }

    Equipment* searchEquipment(int equipmentId) {
        for (auto& equipment : equipments) {
            if (equipment.id == equipmentId) {
                return &equipment;
            }
        }
        return nullptr;
    }
};

class EquipmentManagementSystem {
private:
    vector<Laboratory> laboratories;

    Laboratory* getLaboratory(int laboratoryId) {
        for (auto& laboratory : laboratories) {
            if (laboratory.id == laboratoryId) {
                return &laboratory;
            }
        }
        return nullptr;
    }

public:
    void addLaboratory(int id, string name) {
        laboratories.push_back(Laboratory(id, name));
    }

    void deleteLaboratory(int id) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == id) {
                laboratories.erase(it);
                break;
            }
        }
    }

    void updateLaboratory(int id, string name) {
        Laboratory* lab = getLaboratory(id);
        if (lab) {
            lab->name = name;
        }
    }

    Laboratory* searchLaboratory(int id) {
        return getLaboratory(id);
    }

    void displayLaboratories() {
        for (auto& laboratory : laboratories) {
            cout << "Laboratory ID: " << laboratory.id << ", Name: " << laboratory.name << endl;
            for (auto& equipment : laboratory.equipments) {
                cout << "    Equipment ID: " << equipment.id << ", Name: " << equipment.name << ", Type: " << equipment.type << endl;
            }
        }
    }

    void addEquipmentToLaboratory(int laboratoryId, Equipment equipment) {
        Laboratory* lab = getLaboratory(laboratoryId);
        if (lab) {
            lab->addEquipment(equipment);
        }
    }

    void deleteEquipmentFromLaboratory(int laboratoryId, int equipmentId) {
        Laboratory* lab = getLaboratory(laboratoryId);
        if (lab) {
            lab->removeEquipment(equipmentId);
        }
    }

    void updateEquipmentInLaboratory(int laboratoryId, int equipmentId, string name, string type) {
        Laboratory* lab = getLaboratory(laboratoryId);
        if (lab) {
            Equipment* equipment = lab->searchEquipment(equipmentId);
            if (equipment) {
                equipment->name = name;
                equipment->type = type;
            }
        }
    }

    Equipment* searchEquipmentInLaboratory(int laboratoryId, int equipmentId) {
        Laboratory* lab = getLaboratory(laboratoryId);
        if (lab) {
            return lab->searchEquipment(equipmentId);
        }
        return nullptr;
    }
};

int main() {
    EquipmentManagementSystem ems;

    ems.addLaboratory(1, "Physics Lab");
    ems.addLaboratory(2, "Chemistry Lab");

    ems.addEquipmentToLaboratory(1, Equipment(101, "Oscilloscope", "Electronic"));
    ems.addEquipmentToLaboratory(1, Equipment(102, "Voltmeter", "Electronic"));
    ems.addEquipmentToLaboratory(2, Equipment(201, "Beaker", "Glassware"));

    ems.displayLaboratories();

    ems.updateLaboratory(1, "Advanced Physics Lab");
    ems.updateEquipmentInLaboratory(1, 101, "Digital Oscilloscope", "Electronic");

    ems.displayLaboratories();

    ems.deleteEquipmentFromLaboratory(2, 201);
    ems.deleteLaboratory(2);

    ems.displayLaboratories();

    return 0;
}