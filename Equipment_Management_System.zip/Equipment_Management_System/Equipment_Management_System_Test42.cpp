#include <iostream>
#include <string>
#include <vector>

class Equipment {
public:
    int id;
    std::string name;
    std::string lab;

    Equipment(int i, const std::string &n, const std::string &l) : id(i), name(n), lab(l) {}
};

class EquipmentManagementSystem {
private:
    std::vector<Equipment> equipments;

    int findEquipmentIndexById(int id) {
        for (int i = 0; i < equipments.size(); ++i) {
            if (equipments[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addEquipment(int id, const std::string &name, const std::string &lab) {
        if (findEquipmentIndexById(id) == -1) {
            equipments.push_back(Equipment(id, name, lab));
            std::cout << "Equipment added successfully.\n";
        } else {
            std::cout << "Equipment with this ID already exists.\n";
        }
    }

    void deleteEquipment(int id) {
        int index = findEquipmentIndexById(id);
        if (index != -1) {
            equipments.erase(equipments.begin() + index);
            std::cout << "Equipment deleted successfully.\n";
        } else {
            std::cout << "Equipment not found.\n";
        }
    }

    void updateEquipment(int id, const std::string &name, const std::string &lab) {
        int index = findEquipmentIndexById(id);
        if (index != -1) {
            equipments[index].name = name;
            equipments[index].lab = lab;
            std::cout << "Equipment updated successfully.\n";
        } else {
            std::cout << "Equipment not found.\n";
        }
    }

    void searchEquipment(int id) {
        int index = findEquipmentIndexById(id);
        if (index != -1) {
            std::cout << "ID: " << equipments[index].id << ", Name: " << equipments[index].name << ", Lab: " << equipments[index].lab << "\n";
        } else {
            std::cout << "Equipment not found.\n";
        }
    }

    void displayAllEquipments() {
        if (equipments.empty()) {
            std::cout << "No equipments available.\n";
        } else {
            std::cout << "Displaying all equipments:\n";
            for (const auto &eq : equipments) {
                std::cout << "ID: " << eq.id << ", Name: " << eq.name << ", Lab: " << eq.lab << "\n";
            }
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addEquipment(1, "Oscilloscope", "Physics Lab");
    ems.addEquipment(2, "Microscope", "Biology Lab");
    ems.displayAllEquipments();
    ems.searchEquipment(1);
    ems.updateEquipment(1, "Digital Oscilloscope", "Advanced Physics Lab");
    ems.searchEquipment(1);
    ems.deleteEquipment(2);
    ems.displayAllEquipments();
    return 0;
}