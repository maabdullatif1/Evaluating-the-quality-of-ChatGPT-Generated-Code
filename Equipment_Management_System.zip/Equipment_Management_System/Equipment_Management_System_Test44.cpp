#include <iostream>
#include <string>

struct Equipment {
    int id;
    std::string name;
    std::string description;
};

struct Laboratory {
    int id;
    std::string name;
    std::string location;
};

Equipment equipments[100];
Laboratory laboratories[100];
int equipmentCount = 0;
int laboratoryCount = 0;

void addEquipment() {
    std::cout << "Enter equipment id: ";
    std::cin >> equipments[equipmentCount].id;
    std::cin.ignore();
    std::cout << "Enter equipment name: ";
    std::getline(std::cin, equipments[equipmentCount].name);
    std::cout << "Enter equipment description: ";
    std::getline(std::cin, equipments[equipmentCount].description);
    equipmentCount++;
}

void deleteEquipment() {
    int id;
    std::cout << "Enter equipment id to delete: ";
    std::cin >> id;
    for (int i = 0; i < equipmentCount; i++) {
        if (equipments[i].id == id) {
            for (int j = i; j < equipmentCount - 1; j++) {
                equipments[j] = equipments[j + 1];
            }
            equipmentCount--;
            break;
        }
    }
}

void updateEquipment() {
    int id;
    std::cout << "Enter equipment id to update: ";
    std::cin >> id;
    std::cin.ignore();
    for (int i = 0; i < equipmentCount; i++) {
        if (equipments[i].id == id) {
            std::cout << "Enter new equipment name: ";
            std::getline(std::cin, equipments[i].name);
            std::cout << "Enter new equipment description: ";
            std::getline(std::cin, equipments[i].description);
            break;
        }
    }
}

void searchEquipment() {
    int id;
    std::cout << "Enter equipment id to search: ";
    std::cin >> id;
    for (int i = 0; i < equipmentCount; i++) {
        if (equipments[i].id == id) {
            std::cout << "Equipment ID: " << equipments[i].id << ", Name: " 
                      << equipments[i].name << ", Description: " 
                      << equipments[i].description << "\n";
            break;
        }
    }
}

void displayEquipments() {
    for (int i = 0; i < equipmentCount; i++) {
        std::cout << "Equipment ID: " << equipments[i].id << ", Name: " 
                  << equipments[i].name << ", Description: " 
                  << equipments[i].description << "\n";
    }
}

void addLaboratory() {
    std::cout << "Enter laboratory id: ";
    std::cin >> laboratories[laboratoryCount].id;
    std::cin.ignore();
    std::cout << "Enter laboratory name: ";
    std::getline(std::cin, laboratories[laboratoryCount].name);
    std::cout << "Enter laboratory location: ";
    std::getline(std::cin, laboratories[laboratoryCount].location);
    laboratoryCount++;
}

void deleteLaboratory() {
    int id;
    std::cout << "Enter laboratory id to delete: ";
    std::cin >> id;
    for (int i = 0; i < laboratoryCount; i++) {
        if (laboratories[i].id == id) {
            for (int j = i; j < laboratoryCount - 1; j++) {
                laboratories[j] = laboratories[j + 1];
            }
            laboratoryCount--;
            break;
        }
    }
}

void updateLaboratory() {
    int id;
    std::cout << "Enter laboratory id to update: ";
    std::cin >> id;
    std::cin.ignore();
    for (int i = 0; i < laboratoryCount; i++) {
        if (laboratories[i].id == id) {
            std::cout << "Enter new laboratory name: ";
            std::getline(std::cin, laboratories[i].name);
            std::cout << "Enter new laboratory location: ";
            std::getline(std::cin, laboratories[i].location);
            break;
        }
    }
}

void searchLaboratory() {
    int id;
    std::cout << "Enter laboratory id to search: ";
    std::cin >> id;
    for (int i = 0; i < laboratoryCount; i++) {
        if (laboratories[i].id == id) {
            std::cout << "Laboratory ID: " << laboratories[i].id 
                      << ", Name: " << laboratories[i].name 
                      << ", Location: " << laboratories[i].location << "\n";
            break;
        }
    }
}

void displayLaboratories() {
    for (int i = 0; i < laboratoryCount; i++) {
        std::cout << "Laboratory ID: " << laboratories[i].id 
                  << ", Name: " << laboratories[i].name 
                  << ", Location: " << laboratories[i].location << "\n";
    }
}

int main() {
    int choice;
    while (true) {
        std::cout << "1. Add Equipment\n"
                  << "2. Delete Equipment\n"
                  << "3. Update Equipment\n"
                  << "4. Search Equipment\n"
                  << "5. Display Equipments\n"
                  << "6. Add Laboratory\n"
                  << "7. Delete Laboratory\n"
                  << "8. Update Laboratory\n"
                  << "9. Search Laboratory\n"
                  << "10. Display Laboratories\n"
                  << "0. Exit\n"
                  << "Enter choice: ";
        std::cin >> choice;
        switch (choice) {
            case 1: addEquipment(); break;
            case 2: deleteEquipment(); break;
            case 3: updateEquipment(); break;
            case 4: searchEquipment(); break;
            case 5: displayEquipments(); break;
            case 6: addLaboratory(); break;
            case 7: deleteLaboratory(); break;
            case 8: updateLaboratory(); break;
            case 9: searchLaboratory(); break;
            case 10: displayLaboratories(); break;
            case 0: return 0;
            default: std::cout << "Invalid choice\n";
        }
    }
}