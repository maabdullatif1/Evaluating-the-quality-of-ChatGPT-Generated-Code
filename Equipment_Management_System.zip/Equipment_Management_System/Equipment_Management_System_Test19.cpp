#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string lab;

    Equipment(int id, std::string name, std::string lab) : id(id), name(name), lab(lab) {}
};

class EquipmentManagementSystem {
private:
    std::vector<Equipment> equipmentList;

    int findEquipmentIndex(int id) {
        for (size_t i = 0; i < equipmentList.size(); ++i) {
            if (equipmentList[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addEquipment(int id, std::string name, std::string lab) {
        if (findEquipmentIndex(id) != -1) {
            std::cout << "Equipment with ID " << id << " already exists.\n";
            return;
        }
        equipmentList.push_back(Equipment(id, name, lab));
    }

    void deleteEquipment(int id) {
        int index = findEquipmentIndex(id);
        if (index != -1) {
            equipmentList.erase(equipmentList.begin() + index);
            std::cout << "Equipment with ID " << id << " deleted.\n";
        } else {
            std::cout << "Equipment with ID " << id << " not found.\n";
        }
    }

    void updateEquipment(int id, std::string newName, std::string newLab) {
        int index = findEquipmentIndex(id);
        if (index != -1) {
            equipmentList[index].name = newName;
            equipmentList[index].lab = newLab;
            std::cout << "Equipment with ID " << id << " updated.\n";
        } else {
            std::cout << "Equipment with ID " << id << " not found.\n";
        }
    }

    void searchEquipment(int id) {
        int index = findEquipmentIndex(id);
        if (index != -1) {
            std::cout << "ID: " << equipmentList[index].id << ", Name: " << equipmentList[index].name << ", Lab: " << equipmentList[index].lab << '\n';
        } else {
            std::cout << "Equipment with ID " << id << " not found.\n";
        }
    }

    void displayEquipment() {
        for (const auto& eq : equipmentList) {
            std::cout << "ID: " << eq.id << ", Name: " << eq.name << ", Lab: " << eq.lab << '\n';
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addEquipment(1, "Oscilloscope", "Lab A");
    ems.addEquipment(2, "Multimeter", "Lab B");
    ems.displayEquipment();
    ems.searchEquipment(1);
    ems.updateEquipment(2, "Digital Multimeter", "Lab C");
    ems.displayEquipment();
    ems.deleteEquipment(1);
    ems.displayEquipment();
    return 0;
}