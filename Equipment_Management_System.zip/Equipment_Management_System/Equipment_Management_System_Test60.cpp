#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string lab;

    Equipment(int i, string n, string l): id(i), name(n), lab(l) {}
};

class EquipmentManagementSystem {
private:
    vector<Equipment> equipmentList;
    int nextId;

    int findEquipmentIndexById(int id) {
        for (size_t i = 0; i < equipmentList.size(); ++i) {
            if (equipmentList[i].id == id) {
                return i;
            }
        }
        return -1;
    }
public:
    EquipmentManagementSystem(): nextId(1) {}

    void addEquipment(string name, string lab) {
        equipmentList.push_back(Equipment(nextId++, name, lab));
    }

    void deleteEquipment(int id) {
        int index = findEquipmentIndexById(id);
        if (index != -1) {
            equipmentList.erase(equipmentList.begin() + index);
        }
    }

    void updateEquipment(int id, string newName, string newLab) {
        int index = findEquipmentIndexById(id);
        if (index != -1) {
            equipmentList[index].name = newName;
            equipmentList[index].lab = newLab;
        }
    }

    Equipment* searchEquipment(int id) {
        int index = findEquipmentIndexById(id);
        if (index != -1) {
            return &equipmentList[index];
        }
        return nullptr;
    }

    void displayEquipment() {
        for (const auto& equipment : equipmentList) {
            cout << "ID: " << equipment.id << ", Name: " << equipment.name << ", Lab: " << equipment.lab << endl;
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addEquipment("Microscope", "Biology Lab");
    ems.addEquipment("Oscilloscope", "Physics Lab");
    ems.addEquipment("Spectrometer", "Chemistry Lab");

    cout << "All Equipment:" << endl;
    ems.displayEquipment();

    Equipment* found = ems.searchEquipment(2);
    if (found) {
        cout << "Found Equipment with ID 2: " << found->name << ", " << found->lab << endl;
    }

    ems.updateEquipment(1, "Advanced Microscope", "Advanced Biology Lab");
    cout << "Updated Equipment:" << endl;
    ems.displayEquipment();

    ems.deleteEquipment(3);
    cout << "After Deletion:" << endl;
    ems.displayEquipment();

    return 0;
}