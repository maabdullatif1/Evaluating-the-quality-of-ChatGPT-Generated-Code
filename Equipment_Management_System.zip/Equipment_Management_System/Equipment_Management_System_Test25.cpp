#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    std::string name;
    std::string id;
    std::string labId;

    Equipment(std::string n, std::string i, std::string lId) : name(n), id(i), labId(lId) {}
};

class Laboratory {
public:
    std::string name;
    std::string id;

    Laboratory(std::string n, std::string i) : name(n), id(i) {}
};

class EquipmentManagementSystem {
private:
    std::vector<Equipment> equipments;
    std::vector<Laboratory> laboratories;

public:
    void addEquipment(const std::string &name, const std::string &id, const std::string &labId) {
        equipments.push_back(Equipment(name, id, labId));
    }

    void deleteEquipment(const std::string &id) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == id) {
                equipments.erase(it);
                break;
            }
        }
    }

    void updateEquipment(const std::string &id, const std::string &newName, const std::string &newLabId) {
        for (auto &equipment : equipments) {
            if (equipment.id == id) {
                equipment.name = newName;
                equipment.labId = newLabId;
                break;
            }
        }
    }

    Equipment* searchEquipment(const std::string &id) {
        for (auto &equipment : equipments) {
            if (equipment.id == id) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void displayEquipments() {
        for (const auto &equipment : equipments) {
            std::cout << "Equipment ID: " << equipment.id
                      << ", Name: " << equipment.name
                      << ", Lab ID: " << equipment.labId << std::endl;
        }
    }

    void addLaboratory(const std::string &name, const std::string &id) {
        laboratories.push_back(Laboratory(name, id));
    }

    void deleteLaboratory(const std::string &id) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == id) {
                laboratories.erase(it);
                break;
            }
        }
    }

    void updateLaboratory(const std::string &id, const std::string &newName) {
        for (auto &lab : laboratories) {
            if (lab.id == id) {
                lab.name = newName;
                break;
            }
        }
    }

    Laboratory* searchLaboratory(const std::string &id) {
        for (auto &lab : laboratories) {
            if (lab.id == id) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLaboratories() {
        for (const auto &lab : laboratories) {
            std::cout << "Laboratory ID: " << lab.id
                      << ", Name: " << lab.name << std::endl;
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addLaboratory("Physics Lab", "L101");
    ems.addLaboratory("Chemistry Lab", "L102");
    ems.addEquipment("Microscope", "E101", "L101");
    ems.addEquipment("Bunsen Burner", "E102", "L102");

    std::cout << "All Laboratories:" << std::endl;
    ems.displayLaboratories();

    std::cout << "All Equipments:" << std::endl;
    ems.displayEquipments();

    return 0;
}