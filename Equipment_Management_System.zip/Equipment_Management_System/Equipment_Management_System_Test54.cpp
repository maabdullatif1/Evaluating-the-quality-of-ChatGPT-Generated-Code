#include <iostream>
#include <string>
#include <vector>

class Equipment {
public:
    int id;
    std::string name;
    std::string type;
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;
};

class EquipmentManagementSystem {
private:
    std::vector<Laboratory> labs;

    Laboratory* findLabByID(int id) {
        for (auto& lab : labs) {
            if (lab.id == id) {
                return &lab;
            }
        }
        return nullptr;
    }

    Equipment* findEquipmentByID(Laboratory& lab, int id) {
        for (auto& equip : lab.equipments) {
            if (equip.id == id) {
                return &equip;
            }
        }
        return nullptr;
    }

public:
    void addLaboratory(int id, const std::string& name) {
        labs.push_back({id, name, {}});
    }

    void deleteLaboratory(int id) {
        labs.erase(std::remove_if(labs.begin(), labs.end(), [id](const Laboratory& lab) { return lab.id == id; }), labs.end());
    }

    void updateLaboratory(int id, const std::string& name) {
        Laboratory* lab = findLabByID(id);
        if (lab) {
            lab->name = name;
        }
    }

    void addEquipment(int labId, int equipId, const std::string& name, const std::string& type) {
        Laboratory* lab = findLabByID(labId);
        if (lab) {
            lab->equipments.push_back({equipId, name, type});
        }
    }

    void deleteEquipment(int labId, int equipId) {
        Laboratory* lab = findLabByID(labId);
        if (lab) {
            lab->equipments.erase(std::remove_if(lab->equipments.begin(), lab->equipments.end(),
                [equipId](const Equipment& equip) { return equip.id == equipId; }), lab->equipments.end());
        }
    }

    void updateEquipment(int labId, int equipId, const std::string& name, const std::string& type) {
        Laboratory* lab = findLabByID(labId);
        if (lab) {
            Equipment* equip = findEquipmentByID(*lab, equipId);
            if (equip) {
                equip->name = name;
                equip->type = type;
            }
        }
    }

    Laboratory* searchLaboratory(int id) {
        return findLabByID(id);
    }

    Equipment* searchEquipment(int labId, int equipId) {
        Laboratory* lab = findLabByID(labId);
        if (lab) {
            return findEquipmentByID(*lab, equipId);
        }
        return nullptr;
    }

    void displayEquipmentDetails(const Equipment& equip) {
        std::cout << "Equipment ID: " << equip.id << ", Name: " << equip.name << ", Type: " << equip.type << std::endl;
    }

    void displayLaboratoryDetails(const Laboratory& lab) {
        std::cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << std::endl;
        for (const auto& equip : lab.equipments) {
            displayEquipmentDetails(equip);
        }
    }

    void displayAll() {
        for (const auto& lab : labs) {
            displayLaboratoryDetails(lab);
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addLaboratory(1, "Physics Lab");
    ems.addLaboratory(2, "Chemistry Lab");
    
    ems.addEquipment(1, 100, "Oscilloscope", "Electronics");
    ems.addEquipment(1, 101, "Voltmeter", "Electronics");
    ems.addEquipment(2, 200, "Burette", "Chemistry");
    
    ems.displayAll();
    
    ems.updateEquipment(1, 100, "Oscilloscope", "Advanced Electronics");
    ems.deleteLaboratory(2);
    
    ems.displayAll();
    
    return 0;
}