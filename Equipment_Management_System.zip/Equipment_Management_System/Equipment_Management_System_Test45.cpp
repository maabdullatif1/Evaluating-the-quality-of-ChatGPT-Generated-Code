#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string status;
    
    Equipment(int i, std::string n, std::string s) : id(i), name(n), status(s) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;

    Laboratory(int i, std::string n) : id(i), name(n) {}

    void addEquipment(int eid, std::string ename, std::string estatus) {
        equipments.push_back(Equipment(eid, ename, estatus));
    }

    void deleteEquipment(int eid) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == eid) {
                equipments.erase(it);
                break;
            }
        }
    }
    
    void updateEquipment(int eid, std::string newName, std::string newStatus) {
        for (auto &equip : equipments) {
            if (equip.id == eid) {
                equip.name = newName;
                equip.status = newStatus;
                break;
            }
        }
    }

    void displayEquipments() const {
        for (const auto &equip : equipments) {
            std::cout << "Equipment ID: " << equip.id << ", Name: " << equip.name << ", Status: " << equip.status << std::endl;
        }
    }
};

class ManagementSystem {
private:
    std::vector<Laboratory> laboratories;

public:
    void addLaboratory(int id, std::string name) {
        laboratories.push_back(Laboratory(id, name));
    }

    void deleteLaboratory(int id) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == id) {
                laboratories.erase(it);
                break;
            }
        }
    }

    Laboratory* searchLaboratory(int id) {
        for (auto &lab : laboratories) {
            if (lab.id == id) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLaboratories() const {
        for (const auto &lab : laboratories) {
            std::cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << std::endl;
            lab.displayEquipments();
        }
    }
};

int main() {
    ManagementSystem system;
    system.addLaboratory(1, "Physics Lab");
    system.addLaboratory(2, "Chemistry Lab");

    Laboratory* lab = system.searchLaboratory(1);
    if (lab) {
        lab->addEquipment(101, "Microscope", "Available");
        lab->addEquipment(102, "Spectrometer", "In-use");
    }

    lab = system.searchLaboratory(2);
    if (lab) {
        lab->addEquipment(201, "Bunsen Burner", "Available");
    }

    system.displayLaboratories();

    return 0;
}