#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Equipment {
public:
    string name;
    string id;
    string labName;

    Equipment(const string& n, const string& i, const string& l) : name(n), id(i), labName(l) {}
};

class EquipmentManager {
private:
    vector<Equipment> equipmentList;

public:
    void addEquipment(const string& name, const string& id, const string& labName) {
        Equipment newEquipment(name, id, labName);
        equipmentList.push_back(newEquipment);
    }

    void deleteEquipment(const string& id) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == id) {
                equipmentList.erase(it);
                return;
            }
        }
    }

    void updateEquipment(const string& id, const string& newName, const string& newLabName) {
        for (auto& equipment : equipmentList) {
            if (equipment.id == id) {
                equipment.name = newName;
                equipment.labName = newLabName;
                return;
            }
        }
    }

    Equipment* searchEquipment(const string& id) {
        for (auto& equipment : equipmentList) {
            if (equipment.id == id) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void displayEquipments() {
        for (auto& equipment : equipmentList) {
            cout << "Name: " << equipment.name << ", ID: " << equipment.id << ", Lab: " << equipment.labName << endl;
        }
    }
};

int main() {
    EquipmentManager manager;
    manager.addEquipment("Oscilloscope", "EQ001", "Physics Lab");
    manager.addEquipment("Microscope", "EQ002", "Biology Lab");

    cout << "Equipment List:" << endl;
    manager.displayEquipments();

    manager.updateEquipment("EQ001", "Digital Oscilloscope", "Advanced Physics Lab");

    cout << "\nAfter Update:" << endl;
    manager.displayEquipments();

    manager.deleteEquipment("EQ002");

    cout << "\nAfter Deletion:" << endl;
    manager.displayEquipments();

    Equipment* equipment = manager.searchEquipment("EQ001");
    if (equipment) {
        cout << "\nSearched Equipment:" << endl;
        cout << "Name: " << equipment->name << ", ID: " << equipment->id << ", Lab: " << equipment->labName << endl;
    } else {
        cout << "\nEquipment not found." << endl;
    }

    return 0;
}