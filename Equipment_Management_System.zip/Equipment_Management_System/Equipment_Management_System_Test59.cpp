#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string description;

    Equipment(int id, std::string name, std::string description)
        : id(id), name(name), description(description) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;

    Laboratory(int id, std::string name)
        : id(id), name(name) {}

    void addEquipment(const Equipment& eq) {
        equipments.push_back(eq);
    }

    void deleteEquipment(int id) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == id) {
                equipments.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int id, const std::string& name, const std::string& description) {
        for (auto& eq : equipments) {
            if (eq.id == id) {
                eq.name = name;
                eq.description = description;
                break;
            }
        }
    }

    Equipment* searchEquipment(int id) {
        for (auto& eq : equipments) {
            if (eq.id == id) {
                return &eq;
            }
        }
        return nullptr;
    }

    void displayEquipments() const {
        for (const auto& eq : equipments) {
            std::cout << "ID: " << eq.id << ", Name: " << eq.name 
                      << ", Description: " << eq.description << std::endl;
        }
    }
};

class EquipmentManagementSystem {
private:
    std::vector<Laboratory> laboratories;

public:
    void addLaboratory(int id, const std::string& name) {
        laboratories.push_back(Laboratory(id, name));
    }

    void deleteLaboratory(int id) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == id) {
                laboratories.erase(it);
                break;
            }
        }
    }

    Laboratory* searchLaboratory(int id) {
        for (auto& lab : laboratories) {
            if (lab.id == id) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLaboratories() const {
        for (const auto& lab : laboratories) {
            std::cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << std::endl;
            lab.displayEquipments();
        }
    }

    void addEquipmentToLab(int labId, const Equipment& eq) {
        Laboratory* lab = searchLaboratory(labId);
        if (lab) {
            lab->addEquipment(eq);
        }
    }

    void deleteEquipmentFromLab(int labId, int eqId) {
        Laboratory* lab = searchLaboratory(labId);
        if (lab) {
            lab->deleteEquipment(eqId);
        }
    }

    void updateEquipmentInLab(int labId, int eqId, const std::string& name, const std::string& description) {
        Laboratory* lab = searchLaboratory(labId);
        if (lab) {
            lab->updateEquipment(eqId, name, description);
        }
    }

    Equipment* searchEquipmentInLab(int labId, int eqId) {
        Laboratory* lab = searchLaboratory(labId);
        return lab ? lab->searchEquipment(eqId) : nullptr;
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addLaboratory(1, "Physics Lab");
    ems.addLaboratory(2, "Chemistry Lab");

    ems.addEquipmentToLab(1, Equipment(101, "Oscilloscope", "Used for observing electrical signals"));
    ems.addEquipmentToLab(1, Equipment(102, "Multimeter", "Used for measuring electrical values"));
    ems.addEquipmentToLab(2, Equipment(201, "Bunsen Burner", "Used for heating substances"));

    ems.displayLaboratories();

    ems.updateEquipmentInLab(1, 101, "Digital Oscilloscope", "Advanced oscilloscope for detailed observation");
    Equipment* eq = ems.searchEquipmentInLab(1, 102);

    if (eq) {
        std::cout << "\nFound Equipment: ID: " << eq->id << ", Name: " << eq->name 
                  << ", Description: " << eq->description << std::endl;
    }

    ems.deleteEquipmentFromLab(2, 201);
    ems.displayLaboratories();

    return 0;
}