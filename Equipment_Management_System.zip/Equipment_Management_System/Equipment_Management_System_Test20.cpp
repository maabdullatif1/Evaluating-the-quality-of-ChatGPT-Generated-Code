#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string description;

    Equipment(int _id, const std::string &_name, const std::string &_desc) 
        : id(_id), name(_name), description(_desc) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::string location;
    std::vector<Equipment> equipmentList;

    Laboratory(int _id, const std::string &_name, const std::string &_location)
        : id(_id), name(_name), location(_location) {}
};

class System {
    std::vector<Laboratory> labs;

    Laboratory* findLaboratoryById(int id) {
        for (auto &lab : labs) {
            if (lab.id == id) return &lab;
        }
        return nullptr;
    }

public:
    void addLaboratory(int id, const std::string &name, const std::string &location) {
        labs.emplace_back(id, name, location);
    }

    void deleteLaboratory(int id) {
        labs.erase(std::remove_if(labs.begin(), labs.end(), [id](Laboratory &lab) {
            return lab.id == id; 
        }), labs.end());
    }

    void updateLaboratory(int id, const std::string &name, const std::string &location) {
        Laboratory* lab = findLaboratoryById(id);
        if (lab) {
            lab->name = name;
            lab->location = location;
        }
    }

    void addEquipmentToLab(int labId, int equipId, const std::string &equipName, const std::string &equipDesc) {
        Laboratory* lab = findLaboratoryById(labId);
        if (lab) {
            lab->equipmentList.emplace_back(equipId, equipName, equipDesc);
        }
    }

    void deleteEquipmentFromLab(int labId, int equipId) {
        Laboratory* lab = findLaboratoryById(labId);
        if (lab) {
            auto &equipments = lab->equipmentList;
            equipments.erase(std::remove_if(equipments.begin(), equipments.end(), [equipId](Equipment &equip) {
                return equip.id == equipId;
            }), equipments.end());
        }
    }

    Equipment* searchEquipment(int labId, int equipId) {
        Laboratory* lab = findLaboratoryById(labId);
        if (lab) {
            for (auto &equip : lab->equipmentList) {
                if (equip.id == equipId) return &equip;
            }
        }
        return nullptr;
    }

    void displayEquipment(int labId) {
        Laboratory* lab = findLaboratoryById(labId);
        if (lab) {
            for (auto &equip : lab->equipmentList) {
                std::cout << "Equipment ID: " << equip.id << ", Name: " << equip.name << ", Description: " << equip.description << std::endl;
            }
        }
    }

    void displayLaboratories() {
        for (auto &lab : labs) {
            std::cout << "Lab ID: " << lab.id << ", Name: " << lab.name << ", Location: " << lab.location << std::endl;
            displayEquipment(lab.id);
        }
    }
};

int main() {
    System sys;
    sys.addLaboratory(1, "Physics Lab", "Building A");
    sys.addLaboratory(2, "Chemistry Lab", "Building B");
    sys.addEquipmentToLab(1, 101, "Microscope", "High resolution");
    sys.addEquipmentToLab(1, 102, "Spectrometer", "For light wavelength analysis");
    sys.displayLaboratories();

    sys.updateLaboratory(1, "Advanced Physics Lab", "Building A, 2nd Floor");
    sys.displayLaboratories();

    sys.deleteEquipmentFromLab(1, 101);
    sys.displayLaboratories();

    Equipment *equip = sys.searchEquipment(1, 102);
    if (equip) {
        std::cout << "Found equipment: " << equip->name << std::endl;
    }

    sys.deleteLaboratory(2);
    sys.displayLaboratories();

    return 0;
}