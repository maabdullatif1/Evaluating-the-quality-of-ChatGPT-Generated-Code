#include<iostream>
#include<string>
using namespace std;

class Equipment {
public:
    int id;
    string name;
    string lab;
    Equipment *next;

    Equipment(int i, string n, string l) : id(i), name(n), lab(l), next(nullptr) {}
};

class EquipmentManagementSystem {
private:
    Equipment *head;
public:
    EquipmentManagementSystem() : head(nullptr) {}

    void addEquipment(int id, string name, string lab) {
        Equipment *newEquipment = new Equipment(id, name, lab);
        if (!head) {
            head = newEquipment;
        } else {
            Equipment *temp = head;
            while (temp->next) {
                temp = temp->next;
            }
            temp->next = newEquipment;
        }
    }

    void deleteEquipment(int id) {
        Equipment *temp = head;
        Equipment *prev = nullptr;
        while (temp && temp->id != id) {
            prev = temp;
            temp = temp->next;
        }
        if (!temp) return;
        if (!prev) {
            head = temp->next;
        } else {
            prev->next = temp->next;
        }
        delete temp;
    }

    void updateEquipment(int id, string name, string lab) {
        Equipment *temp = head;
        while (temp) {
            if (temp->id == id) {
                temp->name = name;
                temp->lab = lab;
                return;
            }
            temp = temp->next;
        }
    }

    Equipment* searchEquipment(int id) {
        Equipment *temp = head;
        while (temp) {
            if (temp->id == id) {
                return temp;
            }
            temp = temp->next;
        }
        return nullptr;
    }

    void displayAll() {
        Equipment *temp = head;
        while (temp) {
            cout << "ID: " << temp->id << ", Name: " << temp->name << ", Lab: " << temp->lab << endl;
            temp = temp->next;
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addEquipment(1, "Microscope", "Biology Lab");
    ems.addEquipment(2, "Oscilloscope", "Physics Lab");
    ems.updateEquipment(1, "Electron Microscope", "Advanced Biology Lab");
    Equipment *eq = ems.searchEquipment(1);
    if (eq) {
        cout << "Found Equipment - ID: " << eq->id << ", Name: " << eq->name << ", Lab: " << eq->lab << endl;
    }
    ems.displayAll();
    ems.deleteEquipment(2);
    ems.displayAll();
    return 0;
}