#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string lab;
    
    Equipment(int eq_id, string eq_name, string eq_lab)
        : id(eq_id), name(eq_name), lab(eq_lab) {}
};

class EquipmentManager {
    vector<Equipment> equipmentList;
public:
    void addEquipment(int id, string name, string lab) {
        Equipment newEquip(id, name, lab);
        equipmentList.push_back(newEquip);
    }
    
    bool deleteEquipment(int id) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == id) {
                equipmentList.erase(it);
                return true;
            }
        }
        return false;
    }
    
    bool updateEquipment(int id, string name, string lab) {
        for (auto& eq : equipmentList) {
            if (eq.id == id) {
                eq.name = name;
                eq.lab = lab;
                return true;
            }
        }
        return false;
    }
    
    Equipment* searchEquipment(int id) {
        for (auto& eq : equipmentList) {
            if (eq.id == id) {
                return &eq;
            }
        }
        return nullptr;
    }
    
    void displayEquipment() {
        for (const auto& eq : equipmentList) {
            cout << "ID: " << eq.id << ", Name: " << eq.name << ", Lab: " << eq.lab << "\n";
        }
        if (equipmentList.empty()) {
            cout << "No equipment available.\n";
        }
    }
};

int main() {
    EquipmentManager manager;
    manager.addEquipment(1, "Microscope", "Biology Lab");
    manager.addEquipment(2, "Oscilloscope", "Physics Lab");
    
    manager.displayEquipment();
    
    Equipment* found = manager.searchEquipment(1);
    if (found) {
        cout << "Found equipment: " << "ID: " << found->id << ", Name: " << found->name << ", Lab: " << found->lab << "\n";
    } else {
        cout << "Equipment not found.\n";
    }
    
    manager.updateEquipment(1, "Advanced Microscope", "Biology Lab");
    
    manager.displayEquipment();
    
    manager.deleteEquipment(2);
    
    manager.displayEquipment();
    
    return 0;
}