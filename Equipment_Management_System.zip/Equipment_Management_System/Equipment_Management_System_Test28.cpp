#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Equipment {
    int id;
    string name;
    string labName;
    bool inLab;
};

class EquipmentManagementSystem {
private:
    vector<Equipment> equipmentList;
    int nextId;

public:
    EquipmentManagementSystem() : nextId(1) {}

    void addEquipment(const string& name, const string& labName) {
        Equipment equipment = {nextId++, name, labName, true};
        equipmentList.push_back(equipment);
    }

    void deleteEquipment(int id) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == id) {
                equipmentList.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int id, const string& newName, const string& newLabName) {
        for (auto& equipment : equipmentList) {
            if (equipment.id == id) {
                equipment.name = newName;
                equipment.labName = newLabName;
                equipment.inLab = true;
                break;
            }
        }
    }

    int searchEquipmentById(int id) {
        for (size_t i = 0; i < equipmentList.size(); ++i) {
            if (equipmentList[i].id == id) {
                return i;
            }
        }
        return -1;
    }

    void displayEquipments() {
        for (const auto& equipment : equipmentList) {
            cout << "ID: " << equipment.id << ", Name: " << equipment.name 
                 << ", Laboratory: " << equipment.labName 
                 << ", In Lab: " << (equipment.inLab ? "Yes" : "No") 
                 << endl;
        }
    }
};

int main() {
    EquipmentManagementSystem system;
    int choice;
    string name, labName;
    int id;

    while (true) {
        cout << "1. Add Equipment\n2. Delete Equipment\n3. Update Equipment\n4. Search Equipment\n5. Display Equipments\n6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter equipment name: ";
            cin >> name;
            cout << "Enter laboratory name: ";
            cin >> labName;
            system.addEquipment(name, labName);
            break;
        case 2:
            cout << "Enter equipment ID to delete: ";
            cin >> id;
            system.deleteEquipment(id);
            break;
        case 3:
            cout << "Enter equipment ID to update: ";
            cin >> id;
            cout << "Enter new equipment name: ";
            cin >> name;
            cout << "Enter new laboratory name: ";
            cin >> labName;
            system.updateEquipment(id, name, labName);
            break;
        case 4:
            cout << "Enter equipment ID to search: ";
            cin >> id;
            id = system.searchEquipmentById(id);
            if (id != -1) {
                cout << "Equipment found: ID = " << system.equipmentList[id].id 
                     << ", Name = " << system.equipmentList[id].name 
                     << ", Laboratory = " << system.equipmentList[id].labName << endl;
            } else {
                cout << "Equipment not found.\n";
            }
            break;
        case 5:
            system.displayEquipments();
            break;
        case 6:
            return 0;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    }
}