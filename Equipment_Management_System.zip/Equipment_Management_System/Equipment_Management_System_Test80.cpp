#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string description;

    Equipment(int i, string n, string d) : id(i), name(n), description(d) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipmentList;

    Laboratory(int i, string n) : id(i), name(n) {}

    void addEquipment(Equipment e) {
        equipmentList.push_back(e);
    }

    void removeEquipment(int equipmentId) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == equipmentId) {
                equipmentList.erase(it);
                return;
            }
        }
    }

    void updateEquipment(int equipmentId, string newName, string newDescription) {
        for (auto& e : equipmentList) {
            if (e.id == equipmentId) {
                e.name = newName;
                e.description = newDescription;
                return;
            }
        }
    }
};

class EquipmentManagementSystem {
private:
    vector<Laboratory> laboratories;

public:
    void addLaboratory(Laboratory l) {
        laboratories.push_back(l);
    }

    void removeLaboratory(int labId) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == labId) {
                laboratories.erase(it);
                return;
            }
        }
    }

    void updateLaboratory(int labId, string newName) {
        for (auto& l : laboratories) {
            if (l.id == labId) {
                l.name = newName;
                return;
            }
        }
    }

    Equipment* searchEquipment(int equipmentId) {
        for (auto& lab : laboratories) {
            for (auto& e : lab.equipmentList) {
                if (e.id == equipmentId) {
                    return &e;
                }
            }
        }
        return nullptr;
    }

    Laboratory* searchLaboratory(int labId) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayAll() {
        for (const auto& lab : laboratories) {
            cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << endl;
            for (const auto& e : lab.equipmentList) {
                cout << "  Equipment ID: " << e.id << ", Name: " << e.name << ", Description: " << e.description << endl;
            }
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    Laboratory lab1(1, "Physics Lab");
    Laboratory lab2(2, "Chemistry Lab");

    Equipment eq1(1, "Microscope", "Used for magnifying objects");
    Equipment eq2(2, "Bunsen Burner", "Used for heating substances");

    lab1.addEquipment(eq1);
    lab2.addEquipment(eq2);

    ems.addLaboratory(lab1);
    ems.addLaboratory(lab2);

    ems.displayAll();

    eq1.name = "Updated Microscope";
    lab1.updateEquipment(1, eq1.name, "Updated description");

    ems.displayAll();

    return 0;
}