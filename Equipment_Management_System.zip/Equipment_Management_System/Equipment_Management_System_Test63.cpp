#include <iostream>
#include <string>
#include <vector>

struct Equipment {
    std::string id;
    std::string name;
    std::string lab_assigned;
};

struct Laboratory {
    std::string name;
    std::string location;
};

std::vector<Equipment> equipments;
std::vector<Laboratory> laboratories;

void addEquipment(const std::string& id, const std::string& name, const std::string& lab) {
    equipments.push_back({id, name, lab});
}

bool deleteEquipment(const std::string& id) {
    for (auto it = equipments.begin(); it != equipments.end(); ++it) {
        if (it->id == id) {
            equipments.erase(it);
            return true;
        }
    }
    return false;
}

bool updateEquipment(const std::string& id, const std::string& newName, const std::string& newLab) {
    for (auto& equip : equipments) {
        if (equip.id == id) {
            equip.name = newName;
            equip.lab_assigned = newLab;
            return true;
        }
    }
    return false;
}

Equipment* searchEquipment(const std::string& id) {
    for (auto& equip : equipments) {
        if (equip.id == id) {
            return &equip;
        }
    }
    return nullptr;
}

void displayEquipments() {
    for (const auto& equip : equipments) {
        std::cout << "ID: " << equip.id << ", Name: " << equip.name << ", Lab Assigned: " << equip.lab_assigned << std::endl;
    }
}

void addLaboratory(const std::string& name, const std::string& location) {
    laboratories.push_back({name, location});
}

bool deleteLaboratory(const std::string& name) {
    for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
        if (it->name == name) {
            laboratories.erase(it);
            return true;
        }
    }
    return false;
}

bool updateLaboratory(const std::string& name, const std::string& newLocation) {
    for (auto& lab : laboratories) {
        if (lab.name == name) {
            lab.location = newLocation;
            return true;
        }
    }
    return false;
}

Laboratory* searchLaboratory(const std::string& name) {
    for (auto& lab : laboratories) {
        if (lab.name == name) {
            return &lab;
        }
    }
    return nullptr;
}

void displayLaboratories() {
    for (const auto& lab : laboratories) {
        std::cout << "Name: " << lab.name << ", Location: " << lab.location << std::endl;
    }
}

int main() {
    addEquipment("E001", "Microscope", "Lab A");
    addEquipment("E002", "Spectrometer", "Lab B");
    addLaboratory("Lab A", "Building 1");
    addLaboratory("Lab B", "Building 2");

    std::cout << "Equipments:" << std::endl;
    displayEquipments();

    std::cout << "Laboratories:" << std::endl;
    displayLaboratories();

    updateEquipment("E001", "Electron Microscope", "Lab B");
    updateLaboratory("Lab A", "Building 3");

    Equipment* e = searchEquipment("E002");
    if (e) {
        std::cout << "Found Equipment ID E002: " << e->name << std::endl;
    }

    Laboratory* l = searchLaboratory("Lab B");
    if (l) {
        std::cout << "Found Laboratory: " << l->name << " in " << l->location << std::endl;
    }

    deleteEquipment("E002");
    deleteLaboratory("Lab A");

    std::cout << "Updated List of Equipments:" << std::endl;
    displayEquipments();

    std::cout << "Updated List of Laboratories:" << std::endl;
    displayLaboratories();

    return 0;
}