#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Equipment {
    int id;
    string name;
    string description;
};

struct Laboratory {
    int id;
    string name;
    vector<Equipment> equipmentList;
};

vector<Laboratory> laboratories;

int generateID() {
    static int id = 1;
    return id++;
}

void addLaboratory() {
    Laboratory lab;
    lab.id = generateID();
    cout << "Enter Laboratory Name: ";
    cin >> lab.name;
    laboratories.push_back(lab);
}

void addEquipment() {
    int labID;
    cout << "Enter Laboratory ID to add equipment: ";
    cin >> labID;

    for (auto &lab : laboratories) {
        if (lab.id == labID) {
            Equipment equip;
            equip.id = generateID();
            cout << "Enter Equipment Name: ";
            cin >> equip.name;
            cout << "Enter Description: ";
            cin >> equip.description;
            lab.equipmentList.push_back(equip);
            return;
        }
    }
    cout << "Laboratory not found." << endl;
}

void deleteEquipment() {
    int equipID, labID;
    cout << "Enter Laboratory ID to delete equipment: ";
    cin >> labID;
    cout << "Enter Equipment ID to delete: ";
    cin >> equipID;

    for (auto &lab : laboratories) {
        if (lab.id == labID) {
            for (auto it = lab.equipmentList.begin(); it != lab.equipmentList.end(); ++it) {
                if (it->id == equipID) {
                    lab.equipmentList.erase(it);
                    cout << "Equipment deleted." << endl;
                    return;
                }
            }
        }
    }
    cout << "Equipment not found." << endl;
}

void updateEquipment() {
    int equipID, labID;
    cout << "Enter Laboratory ID to update equipment: ";
    cin >> labID;
    cout << "Enter Equipment ID to update: ";
    cin >> equipID;

    for (auto &lab : laboratories) {
        if (lab.id == labID) {
            for (auto &equip : lab.equipmentList) {
                if (equip.id == equipID) {
                    cout << "Enter New Equipment Name: ";
                    cin >> equip.name;
                    cout << "Enter New Description: ";
                    cin >> equip.description;
                    cout << "Equipment updated." << endl;
                    return;
                }
            }
        }
    }
    cout << "Equipment not found." << endl;
}

void searchEquipment() {
    string name;
    cout << "Enter Equipment Name to search: ";
    cin >> name;

    for (const auto &lab : laboratories) {
        for (const auto &equip : lab.equipmentList) {
            if (equip.name == name) {
                cout << "Found in Laboratory ID: " << lab.id << " Name: " << lab.name << endl;
                cout << "Equipment ID: " << equip.id << " Name: " << equip.name << " Description: " << equip.description << endl;
                return;
            }
        }
    }
    cout << "Equipment not found." << endl;
}

void displayAll() {
    for (const auto &lab : laboratories) {
        cout << "Laboratory ID: " << lab.id << " Name: " << lab.name << endl;
        for (const auto &equip : lab.equipmentList) {
            cout << "  Equipment ID: " << equip.id << " Name: " << equip.name << " Description: " << equip.description << endl;
        }
    }
}

int main() {
    int choice;
    while (true) {
        cout << "\nEquipment Management System\n";
        cout << "1. Add Laboratory\n";
        cout << "2. Add Equipment\n";
        cout << "3. Delete Equipment\n";
        cout << "4. Update Equipment\n";
        cout << "5. Search Equipment\n";
        cout << "6. Display All\n";
        cout << "7. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                addLaboratory();
                break;
            case 2:
                addEquipment();
                break;
            case 3:
                deleteEquipment();
                break;
            case 4:
                updateEquipment();
                break;
            case 5:
                searchEquipment();
                break;
            case 6:
                displayAll();
                break;
            case 7:
                return 0;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }
    return 0;
}