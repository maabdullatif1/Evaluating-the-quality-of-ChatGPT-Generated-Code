#include <iostream>
#include <vector>
#include <string>

struct Equipment {
    int id;
    std::string name;
    std::string description;
};

struct Laboratory {
    int id;
    std::string name;
    std::vector<Equipment> equipmentList;
};

class EquipmentManagementSystem {
private:
    std::vector<Laboratory> laboratories;

    Laboratory* findLaboratory(int labId) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    Equipment* findEquipment(Laboratory &lab, int equipmentId) {
        for (auto &equip : lab.equipmentList) {
            if (equip.id == equipmentId) {
                return &equip;
            }
        }
        return nullptr;
    }

public:
    void addLaboratory(int id, const std::string &name) {
        if (findLaboratory(id) == nullptr) {
            laboratories.push_back({ id, name, {} });
        }
    }

    void deleteLaboratory(int id) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == id) {
                laboratories.erase(it);
                break;
            }
        }
    }

    void updateLaboratory(int id, const std::string &newName) {
        Laboratory* lab = findLaboratory(id);
        if (lab != nullptr) {
            lab->name = newName;
        }
    }

    void addEquipment(int labId, int equipmentId, const std::string &name, const std::string &description) {
        Laboratory* lab = findLaboratory(labId);
        if (lab != nullptr) {
            lab->equipmentList.push_back({ equipmentId, name, description });
        }
    }

    void deleteEquipment(int labId, int equipmentId) {
        Laboratory* lab = findLaboratory(labId);
        if (lab != nullptr) {
            for (auto it = lab->equipmentList.begin(); it != lab->equipmentList.end(); ++it) {
                if (it->id == equipmentId) {
                    lab->equipmentList.erase(it);
                    break;
                }
            }
        }
    }

    void updateEquipment(int labId, int equipmentId, const std::string &newName, const std::string &newDescription) {
        Laboratory* lab = findLaboratory(labId);
        if (lab != nullptr) {
            Equipment* equip = findEquipment(*lab, equipmentId);
            if (equip != nullptr) {
                equip->name = newName;
                equip->description = newDescription;
            }
        }
    }

    Equipment* searchEquipment(int labId, int equipmentId) {
        Laboratory* lab = findLaboratory(labId);
        if (lab != nullptr) {
            return findEquipment(*lab, equipmentId);
        }
        return nullptr;
    }

    void displayLaboratories() {
        for (const auto &lab : laboratories) {
            std::cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << std::endl;
            for (const auto &equip : lab.equipmentList) {
                std::cout << "  Equipment ID: " << equip.id << ", Name: " << equip.name << ", Description: " << equip.description << std::endl;
            }
        }
    }
};

int main() {
    EquipmentManagementSystem system;

    system.addLaboratory(1, "Physics Lab");
    system.addEquipment(1, 101, "Oscilloscope", "Used for signal display.");
    system.addEquipment(1, 102, "Voltmeter", "Used for measuring voltage.");

    system.addLaboratory(2, "Chemistry Lab");
    system.addEquipment(2, 201, "Bunsen Burner", "Used for heating substances.");

    system.displayLaboratories();

    system.updateEquipment(1, 101, "Digital Oscilloscope", "Advanced signal display.");
    system.displayLaboratories();

    Equipment* found = system.searchEquipment(2, 201);
    if (found != nullptr) {
        std::cout << "Found Equipment: ID=" << found->id << ", Name=" << found->name << std::endl;
    }

    system.deleteEquipment(1, 102);
    system.displayLaboratories();

    system.deleteLaboratory(2);
    system.displayLaboratories();

    return 0;
}