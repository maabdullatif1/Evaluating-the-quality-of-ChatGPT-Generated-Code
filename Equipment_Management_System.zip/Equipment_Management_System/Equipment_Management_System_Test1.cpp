#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string description;

    Equipment(int id, string name, string description) : id(id), name(name), description(description) {}
};

class Laboratory {
public:
    int id;
    string name;
    string location;
    vector<Equipment> equipmentList;

    Laboratory(int id, string name, string location) : id(id), name(name), location(location) {}

    void addEquipment(const Equipment& equipment) {
        equipmentList.push_back(equipment);
    }

    void deleteEquipment(int equipmentId) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == equipmentId) {
                equipmentList.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int equipmentId, const string& newName, const string& newDescription) {
        for (auto& eq : equipmentList) {
            if (eq.id == equipmentId) {
                eq.name = newName;
                eq.description = newDescription;
                break;
            }
        }
    }

    Equipment* searchEquipment(int equipmentId) {
        for (auto& eq : equipmentList) {
            if (eq.id == equipmentId) {
                return &eq;
            }
        }
        return nullptr;
    }

    void displayEquipment() {
        for (auto& eq : equipmentList) {
            cout << "Equipment ID: " << eq.id << ", Name: " << eq.name << ", Description: " << eq.description << endl;
        }
    }
};

class EquipmentManagementSystem {
public:
    vector<Laboratory> laboratoryList;

    void addLaboratory(const Laboratory& lab) {
        laboratoryList.push_back(lab);
    }

    void deleteLaboratory(int labId) {
        for (auto it = laboratoryList.begin(); it != laboratoryList.end(); ++it) {
            if (it->id == labId) {
                laboratoryList.erase(it);
                break;
            }
        }
    }

    void updateLaboratory(int labId, const string& newName, const string& newLocation) {
        for (auto& lab : laboratoryList) {
            if (lab.id == labId) {
                lab.name = newName;
                lab.location = newLocation;
                break;
            }
        }
    }

    Laboratory* searchLaboratory(int labId) {
        for (auto& lab : laboratoryList) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLaboratories() {
        for (auto& lab : laboratoryList) {
            cout << "Lab ID: " << lab.id << ", Name: " << lab.name << ", Location: " << lab.location << endl;
            lab.displayEquipment();
        }
    }
};

int main() {
    EquipmentManagementSystem system;
    Laboratory lab1(1, "Physics Lab", "Building A");
    lab1.addEquipment(Equipment(101, "Oscilloscope", "Measures electrical signals"));
    lab1.addEquipment(Equipment(102, "Voltmeter", "Measures voltage"));

    system.addLaboratory(lab1);
    system.displayLaboratories();

    Laboratory* lab = system.searchLaboratory(1);
    if (lab) {
        lab->updateEquipment(101, "Digital Oscilloscope", "Advanced measurement of electrical signals");
    }

    system.displayLaboratories();
    
    return 0;
}