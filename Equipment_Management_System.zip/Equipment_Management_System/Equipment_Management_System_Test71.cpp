#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string description;

    Equipment(int id, std::string name, std::string description) 
        : id(id), name(name), description(description) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::string location;
    std::vector<Equipment> equipments;

    Laboratory(int id, std::string name, std::string location)
        : id(id), name(name), location(location) {}
    
    void addEquipment(Equipment equipment) {
        equipments.push_back(equipment);
    }

    void deleteEquipment(int equipId) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == equipId) {
                equipments.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int equipId, std::string name, std::string description) {
        for (auto &equipment : equipments) {
            if (equipment.id == equipId) {
                equipment.name = name;
                equipment.description = description;
                break;
            }
        }
    }

    Equipment* searchEquipment(int equipId) {
        for (auto &equipment : equipments) {
            if (equipment.id == equipId) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void displayEquipments() {
        for (const auto &equipment : equipments) {
            std::cout << "Equipment ID: " << equipment.id << ", Name: " << equipment.name << ", Description: " << equipment.description << std::endl;
        }
    }
};

class EquipmentManagementSystem {
private:
    std::vector<Laboratory> laboratories;

public:
    void addLaboratory(Laboratory lab) {
        laboratories.push_back(lab);
    }

    void deleteLaboratory(int labId) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == labId) {
                laboratories.erase(it);
                break;
            }
        }
    }

    void updateLaboratory(int labId, std::string name, std::string location) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) {
                lab.name = name;
                lab.location = location;
                break;
            }
        }
    }

    Laboratory* searchLaboratory(int labId) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLaboratories() {
        for (const auto &lab : laboratories) {
            std::cout << "Lab ID: " << lab.id << ", Name: " << lab.name << ", Location: " << lab.location << std::endl;
            lab.displayEquipments();
        }
    }
};

int main() {
    EquipmentManagementSystem system;

    Laboratory lab1(1, "Physics Lab", "Building A");
    Laboratory lab2(2, "Chemistry Lab", "Building B");

    system.addLaboratory(lab1);
    system.addLaboratory(lab2);

    Equipment equip1(101, "Microscope", "Optical Microscope");
    Equipment equip2(102, "Test Tube", "Glass Test Tube");

    auto lab = system.searchLaboratory(1);
    if (lab) {
        lab->addEquipment(equip1);
        lab->addEquipment(equip2);
    }

    system.displayLaboratories();

    return 0;
}