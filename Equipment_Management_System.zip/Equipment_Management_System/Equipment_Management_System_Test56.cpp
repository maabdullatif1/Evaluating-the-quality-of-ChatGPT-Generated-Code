#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Equipment {
    int id;
    string name;
    string description;
};

struct Laboratory {
    int id;
    string name;
    vector<Equipment> equipments;
};

class EquipmentManagementSystem {
private:
    vector<Laboratory> laboratories;

    Laboratory* findLaboratory(int id) {
        for (auto& lab : laboratories) {
            if (lab.id == id) return &lab;
        }
        return nullptr;
    }

    Equipment* findEquipment(Laboratory& lab, int id) {
        for (auto& eq : lab.equipments) {
            if (eq.id == id) return &eq;
        }
        return nullptr;
    }

public:
    void addLaboratory(int id, const string& name) {
        if (findLaboratory(id) == nullptr) {
            laboratories.push_back({id, name});
        }
    }

    void deleteLaboratory(int id) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == id) {
                laboratories.erase(it);
                break;
            }
        }
    }

    void updateLaboratory(int id, const string& name) {
        Laboratory* lab = findLaboratory(id);
        if (lab) {
            lab->name = name;
        }
    }

    void addEquipment(int labId, int eqId, const string& name, const string& description) {
        Laboratory* lab = findLaboratory(labId);
        if (lab && findEquipment(*lab, eqId) == nullptr) {
            lab->equipments.push_back({eqId, name, description});
        }
    }

    void deleteEquipment(int labId, int eqId) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) {
            for (auto it = lab->equipments.begin(); it != lab->equipments.end(); ++it) {
                if (it->id == eqId) {
                    lab->equipments.erase(it);
                    break;
                }
            }
        }
    }

    void updateEquipment(int labId, int eqId, const string& name, const string& description) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) {
            Equipment* eq = findEquipment(*lab, eqId);
            if (eq) {
                eq->name = name;
                eq->description = description;
            }
        }
    }

    void searchLab(int id) {
        Laboratory* lab = findLaboratory(id);
        if (lab) {
            cout << "Lab ID: " << lab->id << " Name: " << lab->name << endl;
        } else {
            cout << "Laboratory not found" << endl;
        }
    }

    void searchEquipment(int labId, int eqId) {
        Laboratory* lab = findLaboratory(labId);
        if (lab) {
            Equipment* eq = findEquipment(*lab, eqId);
            if (eq) {
                cout << "Equipment ID: " << eq->id << " Name: " << eq->name 
                     << " Description: " << eq->description << endl;
            } else {
                cout << "Equipment not found" << endl;
            }
        } else {
            cout << "Laboratory not found" << endl;
        }
    }

    void displayAll() {
        for (const auto& lab : laboratories) {
            cout << "Lab ID: " << lab.id << " Name: " << lab.name << endl;
            for (const auto& eq : lab.equipments) {
                cout << "  Equipment ID: " << eq.id << " Name: " << eq.name
                     << " Description: " << eq.description << endl;
            }
        }
    }
};

int main() {
    EquipmentManagementSystem system;
    system.addLaboratory(1, "Physics Lab");
    system.addEquipment(1, 101, "Microscope", "Optical instrument used for viewing very small objects");
    system.displayAll();
    return 0;
}