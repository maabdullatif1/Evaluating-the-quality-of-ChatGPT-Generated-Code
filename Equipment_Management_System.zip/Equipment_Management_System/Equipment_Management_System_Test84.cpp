#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    Equipment(int id, const std::string &name, const std::string &lab)
        : id(id), name(name), lab(lab) {}

    int getId() const { return id; }
    const std::string &getName() const { return name; }
    const std::string &getLab() const { return lab; }

    void setName(const std::string &newName) { name = newName; }
    void setLab(const std::string &newLab) { lab = newLab; }

private:
    int id;
    std::string name;
    std::string lab;
};

class EquipmentManagementSystem {
public:
    void addEquipment(int id, const std::string &name, const std::string &lab) {
        equipments.emplace_back(id, name, lab);
    }

    void deleteEquipment(int id) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->getId() == id) {
                equipments.erase(it);
                return;
            }
        }
    }

    void updateEquipment(int id, const std::string &name, const std::string &lab) {
        for (auto &eq : equipments) {
            if (eq.getId() == id) {
                eq.setName(name);
                eq.setLab(lab);
                return;
            }
        }
    }

    Equipment *searchEquipment(int id) {
        for (auto &eq : equipments) {
            if (eq.getId() == id) {
                return &eq;
            }
        }
        return nullptr;
    }

    void displayEquipments() const {
        for (const auto &eq : equipments) {
            std::cout << "ID: " << eq.getId() << ", Name: " << eq.getName() << ", Lab: " << eq.getLab() << std::endl;
        }
    }

private:
    std::vector<Equipment> equipments;
};

int main() {
    EquipmentManagementSystem system;

    system.addEquipment(1, "Microscope", "Bio Lab");
    system.addEquipment(2, "Oscilloscope", "Physics Lab");

    system.displayEquipments();

    system.updateEquipment(1, "Electron Microscope", "Advanced Bio Lab");

    Equipment *eq = system.searchEquipment(2);
    if (eq) {
        std::cout << "Found: " << eq->getName() << " in " << eq->getLab() << std::endl;
    }

    system.deleteEquipment(2);

    system.displayEquipments();

    return 0;
}