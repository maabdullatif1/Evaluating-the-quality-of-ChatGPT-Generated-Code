#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Equipment {
    int id;
    string name;
    string description;
    bool assigned;

    Equipment(int id, string name, string description, bool assigned = false)
        : id(id), name(name), description(description), assigned(assigned) {}
};

struct Laboratory {
    int id;
    string name;
    vector<Equipment> equipments;

    Laboratory(int id, string name) : id(id), name(name) {}
};

class EquipmentManagementSystem {
private:
    vector<Equipment> equipments;
    vector<Laboratory> laboratories;

public:
    void addEquipment(int id, string name, string description) {
        equipments.push_back(Equipment(id, name, description));
    }

    void deleteEquipment(int id) {
        for (size_t i = 0; i < equipments.size(); ++i) {
            if (equipments[i].id == id) {
                equipments.erase(equipments.begin() + i);
                return;
            }
        }
    }

    void updateEquipment(int id, string name, string description) {
        for (auto &equip : equipments) {
            if (equip.id == id) {
                equip.name = name;
                equip.description = description;
                return;
            }
        }
    }

    Equipment* searchEquipment(int id) {
        for (auto &equip : equipments) {
            if (equip.id == id) {
                return &equip;
            }
        }
        return nullptr;
    }

    void displayEquipments() {
        for (const auto &equip : equipments) {
            cout << "Equipment ID: " << equip.id << ", Name: " << equip.name
                 << ", Description: " << equip.description
                 << ", Assigned: " << (equip.assigned ? "Yes" : "No") << endl;
        }
    }

    void addLaboratory(int id, string name) {
        laboratories.push_back(Laboratory(id, name));
    }

    void deleteLaboratory(int id) {
        for (size_t i = 0; i < laboratories.size(); ++i) {
            if (laboratories[i].id == id) {
                laboratories.erase(laboratories.begin() + i);
                return;
            }
        }
    }

    void updateLaboratory(int id, string name) {
        for (auto &lab : laboratories) {
            if (lab.id == id) {
                lab.name = name;
                return;
            }
        }
    }

    Laboratory* searchLaboratory(int id) {
        for (auto &lab : laboratories) {
            if (lab.id == id) {
                return &lab;
            }
        }
        return nullptr;
    }

    void assignEquipmentToLaboratory(int equipmentId, int laboratoryId) {
        Equipment* equip = searchEquipment(equipmentId);
        Laboratory* lab = searchLaboratory(laboratoryId);

        if (equip && lab && !equip->assigned) {
            equip->assigned = true;
            lab->equipments.push_back(*equip);
        }
    }

    void displayLaboratories() {
        for (const auto &lab : laboratories) {
            cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << endl;
            for (const auto &equip : lab.equipments) {
                cout << "\tEquipment ID: " << equip.id << ", Name: " << equip.name
                     << ", Description: " << equip.description << endl;
            }
        }
    }
};

int main() {
    EquipmentManagementSystem ems;

    ems.addEquipment(1, "Microscope", "Optical microscope");
    ems.addEquipment(2, "Oscilloscope", "Digital oscilloscope");
    ems.addLaboratory(1, "Physics Lab");
    ems.addLaboratory(2, "Electronics Lab");
    ems.assignEquipmentToLaboratory(1, 1);
    
    cout << "Equipments:" << endl;
    ems.displayEquipments();

    cout << "\nLaboratories:" << endl;
    ems.displayLaboratories();

    return 0;
}