#include <iostream>
#include <string>
#include <vector>

class Equipment {
public:
    int id;
    std::string name;
    std::string description;

    Equipment(int i, std::string n, std::string d) : id(i), name(n), description(d) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;

    Laboratory(int i, std::string n) : id(i), name(n) {}

    void addEquipment(const Equipment &e) {
        equipments.push_back(e);
    }

    void removeEquipment(int id) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == id) {
                equipments.erase(it);
                return;
            }
        }
    }

    Equipment* findEquipment(int id) {
        for (auto &equipment : equipments) {
            if (equipment.id == id) {
                return &equipment;
            }
        }
        return nullptr;
    }
};

class EquipmentManagementSystem {
public:
    std::vector<Laboratory> laboratories;

    void addLaboratory(int id, std::string name) {
        laboratories.push_back(Laboratory(id, name));
    }

    void removeLaboratory(int id) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == id) {
                laboratories.erase(it);
                return;
            }
        }
    }

    Laboratory* findLaboratory(int id) {
        for (auto &lab : laboratories) {
            if (lab.id == id) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayAllLaboratories() {
        for (const auto &lab : laboratories) {
            std::cout << "Lab ID: " << lab.id << ", Name: " << lab.name << '\n';
            for (const auto &equip : lab.equipments) {
                std::cout << "    Equipment ID: " << equip.id << ", Name: " << equip.name 
                          << ", Description: " << equip.description << '\n';
            }
        }
    }
};

int main() {
    EquipmentManagementSystem system;

    system.addLaboratory(1, "Physics Lab");
    system.addLaboratory(2, "Chemistry Lab");

    Laboratory* lab1 = system.findLaboratory(1);
    if (lab1) {
        lab1->addEquipment(Equipment(101, "Microscope", "Used for magnifying small objects"));
        lab1->addEquipment(Equipment(102, "Thermometer", "Used for measuring temperature"));
    }

    Laboratory* lab2 = system.findLaboratory(2);
    if (lab2) {
        lab2->addEquipment(Equipment(201, "Beaker", "Used for mixing liquids"));
        lab2->addEquipment(Equipment(202, "Bunsen Burner", "Used for heating substances"));
    }

    system.displayAllLaboratories();

    if (lab1) {
        lab1->removeEquipment(101);
    }

    system.displayAllLaboratories();

    return 0;
}