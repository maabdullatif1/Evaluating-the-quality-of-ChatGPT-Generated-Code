#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string description;

    Equipment(int id, string name, string description)
        : id(id), name(name), description(description) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipments;

    Laboratory(int id, string name) : id(id), name(name) {}

    void addEquipment(Equipment equipment) {
        equipments.push_back(equipment);
    }

    void removeEquipment(int equipmentId) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == equipmentId) {
                equipments.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int equipmentId, string name, string description) {
        for (auto& equipment : equipments) {
            if (equipment.id == equipmentId) {
                equipment.name = name;
                equipment.description = description;
                break;
            }
        }
    }

    Equipment* searchEquipment(int equipmentId) {
        for (auto& equipment : equipments) {
            if (equipment.id == equipmentId) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void displayEquipments() {
        for (const auto& equipment : equipments) {
            cout << "Equipment ID: " << equipment.id << ", Name: " << equipment.name
                 << ", Description: " << equipment.description << endl;
        }
    }
};

class EquipmentManagementSystem {
private:
    vector<Laboratory> laboratories;

public:
    void addLaboratory(Laboratory laboratory) {
        laboratories.push_back(laboratory);
    }

    void removeLaboratory(int labId) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == labId) {
                laboratories.erase(it);
                break;
            }
        }
    }

    void updateLaboratory(int labId, string name) {
        for (auto& laboratory : laboratories) {
            if (laboratory.id == labId) {
                laboratory.name = name;
                break;
            }
        }
    }

    Laboratory* searchLaboratory(int labId) {
        for (auto& laboratory : laboratories) {
            if (laboratory.id == labId) {
                return &laboratory;
            }
        }
        return nullptr;
    }

    void displayLaboratories() {
        for (const auto& lab : laboratories) {
            cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << endl;
            lab.displayEquipments();
        }
    }
};

int main() {
    EquipmentManagementSystem system;

    Laboratory lab1(1, "Physics Lab");
    Laboratory lab2(2, "Chemistry Lab");

    system.addLaboratory(lab1);
    system.addLaboratory(lab2);

    Equipment eq1(1, "Microscope", "Optical microscope");
    Equipment eq2(2, "Bunsen Burner", "Used for heating");

    lab1.addEquipment(eq1);
    lab2.addEquipment(eq2);

    system.displayLaboratories();

    Laboratory* lab = system.searchLaboratory(1);
    if (lab) {
        lab->updateEquipment(1, "Electron Microscope", "Advanced microscope");
        lab->displayEquipments();
    }

    system.removeLaboratory(2);
    system.displayLaboratories();

    return 0;
}