#include <iostream>
#include <string>
#include <vector>

class Equipment {
public:
    Equipment(int id, std::string name, std::string lab)
        : id(id), name(name), laboratory(lab) {}

    int getId() const {
        return id;
    }

    std::string getName() const {
        return name;
    }

    std::string getLaboratory() const {
        return laboratory;
    }

    void setName(const std::string& newName) {
        name = newName;
    }

    void setLaboratory(const std::string& newLab) {
        laboratory = newLab;
    }

private:
    int id;
    std::string name;
    std::string laboratory;
};

class EquipmentManagementSystem {
public:
    void addEquipment(int id, const std::string& name, const std::string& lab) {
        equipments.push_back(Equipment(id, name, lab));
    }

    void deleteEquipment(int id) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->getId() == id) {
                equipments.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int id, const std::string& name, const std::string& lab) {
        for (auto& equipment : equipments) {
            if (equipment.getId() == id) {
                equipment.setName(name);
                equipment.setLaboratory(lab);
                break;
            }
        }
    }

    Equipment* searchEquipment(int id) {
        for (auto& equipment : equipments) {
            if (equipment.getId() == id) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void displayEquipments() const {
        for (const auto& equipment : equipments) {
            std::cout << "ID: " << equipment.getId()
                      << ", Name: " << equipment.getName()
                      << ", Laboratory: " << equipment.getLaboratory()
                      << std::endl;
        }
    }

private:
    std::vector<Equipment> equipments;
};

int main() {
    EquipmentManagementSystem system;
    system.addEquipment(1, "Microscope", "Biology Lab");
    system.addEquipment(2, "Spectrometer", "Chemistry Lab");
    
    std::cout << "All Equipments:" << std::endl;
    system.displayEquipments();

    system.updateEquipment(1, "Advanced Microscope", "Biology Lab");

    Equipment* equipment = system.searchEquipment(1);
    if (equipment) {
        std::cout << "Found Equipment ID: " << equipment->getId() << std::endl;
    } else {
        std::cout << "Equipment not found" << std::endl;
    }
    
    system.deleteEquipment(2);

    std::cout << "Equipments after deletion:" << std::endl;
    system.displayEquipments();

    return 0;
}