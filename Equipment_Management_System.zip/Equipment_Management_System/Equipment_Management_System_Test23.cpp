#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    std::string id;
    std::string name;
    std::string status;

    Equipment(std::string id, std::string name, std::string status)
        : id(id), name(name), status(status) {}
};

class Laboratory {
public:
    std::string id;
    std::string name;
    std::vector<Equipment> equipments;

    Laboratory(std::string id, std::string name)
        : id(id), name(name) {}
};

class EquipmentManagementSystem {
private:
    std::vector<Laboratory> laboratories;

public:
    void addLaboratory(std::string id, std::string name) {
        laboratories.push_back(Laboratory(id, name));
    }

    void addEquipmentToLaboratory(std::string labId, std::string equipmentId, std::string equipmentName, std::string status) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) {
                lab.equipments.push_back(Equipment(equipmentId, equipmentName, status));
                return;
            }
        }
    }

    void removeLaboratory(std::string id) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == id) {
                laboratories.erase(it);
                return;
            }
        }
    }

    void removeEquipmentFromLaboratory(std::string labId, std::string equipmentId) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) {
                for (auto it = lab.equipments.begin(); it != lab.equipments.end(); ++it) {
                    if (it->id == equipmentId) {
                        lab.equipments.erase(it);
                        return;
                    }
                }
            }
        }
    }

    void updateEquipmentStatus(std::string labId, std::string equipmentId, std::string newStatus) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) {
                for (auto &equip : lab.equipments) {
                    if (equip.id == equipmentId) {
                        equip.status = newStatus;
                        return;
                    }
                }
            }
        }
    }

    Equipment* searchEquipment(std::string equipmentId) {
        for (auto &lab : laboratories) {
            for (auto &equip : lab.equipments) {
                if (equip.id == equipmentId) {
                    return &equip;
                }
            }
        }
        return nullptr;
    }

    Laboratory* searchLaboratory(std::string labId) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayAllLaboratories() {
        for (auto &lab : laboratories) {
            std::cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << std::endl;
            for (auto &equip : lab.equipments) {
                std::cout << "  Equipment ID: " << equip.id << ", Name: " << equip.name << ", Status: " << equip.status << std::endl;
            }
        }
    }
};

int main() {
    EquipmentManagementSystem ems;
    ems.addLaboratory("L1", "Physics Lab");
    ems.addLaboratory("L2", "Chemistry Lab");
    ems.addEquipmentToLaboratory("L1", "E1", "Microscope", "Available");
    ems.addEquipmentToLaboratory("L1", "E2", "Spectrometer", "In Use");
    ems.addEquipmentToLaboratory("L2", "E3", "Bunsen Burner", "Available");
    ems.updateEquipmentStatus("L1", "E1", "In Maintenance");
    ems.displayAllLaboratories();

    Equipment* searchedEquipment = ems.searchEquipment("E2");
    if (searchedEquipment) {
        std::cout << "Found Equipment - ID: " << searchedEquipment->id << ", Name: " << searchedEquipment->name << ", Status: " << searchedEquipment->status << std::endl;
    }

    Laboratory* searchedLab = ems.searchLaboratory("L2");
    if (searchedLab) {
        std::cout << "Found Laboratory - ID: " << searchedLab->id << ", Name: " << searchedLab->name << std::endl;
    }

    ems.removeEquipmentFromLaboratory("L1", "E1");
    ems.removeLaboratory("L2");
    ems.displayAllLaboratories();

    return 0;
}