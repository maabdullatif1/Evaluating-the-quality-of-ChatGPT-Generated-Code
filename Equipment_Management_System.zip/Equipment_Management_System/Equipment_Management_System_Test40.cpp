#include <iostream>
#include <string>
#include <vector>

class Equipment {
public:
    int id;
    std::string name;
    std::string description;

    Equipment(int i, std::string n, std::string d) : id(i), name(n), description(d) {}
};

class Laboratory {
public:
    int id;
    std::string name;
    std::vector<Equipment> equipments;

    Laboratory(int i, std::string n) : id(i), name(n) {}

    void addEquipment(int id, std::string name, std::string description) {
        equipments.push_back(Equipment(id, name, description));
    }

    void updateEquipment(int eid, std::string name, std::string description) {
        for (auto &equipment : equipments) {
            if (equipment.id == eid) {
                equipment.name = name;
                equipment.description = description;
                return;
            }
        }
    }

    void deleteEquipment(int eid) {
        for (size_t i = 0; i < equipments.size(); ++i) {
            if (equipments[i].id == eid) {
                equipments.erase(equipments.begin() + i);
                return;
            }
        }
    }

    Equipment *searchEquipment(int eid) {
        for (auto &equipment : equipments) {
            if (equipment.id == eid) {
                return &equipment;
            }
        }
        return nullptr;
    }
};

class EquipmentManagementSystem {
public:
    std::vector<Laboratory> laboratories;

    void addLaboratory(int id, std::string name) {
        laboratories.push_back(Laboratory(id, name));
    }

    void deleteLaboratory(int id) {
        for (size_t i = 0; i < laboratories.size(); ++i) {
            if (laboratories[i].id == id) {
                laboratories.erase(laboratories.begin() + i);
                return;
            }
        }
    }

    Laboratory *searchLaboratory(int id) {
        for (auto &lab : laboratories) {
            if (lab.id == id) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayAll() {
        for (const auto &lab : laboratories) {
            std::cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << '\n';
            for (const auto &equipment : lab.equipments) {
                std::cout << "  Equipment ID: " << equipment.id << ", Name: " << equipment.name 
                          << ", Description: " << equipment.description << '\n';
            }
        }
    }
};

int main() {
    EquipmentManagementSystem system;
    system.addLaboratory(1, "Physics Lab");
    system.addLaboratory(2, "Chemistry Lab");

    Laboratory *physicsLab = system.searchLaboratory(1);
    if (physicsLab) {
        physicsLab->addEquipment(101, "Oscilloscope", "Used for measuring waveforms");
        physicsLab->addEquipment(102, "Spectrometer", "Used for measuring light");
    }

    physicsLab->updateEquipment(101, "Advanced Oscilloscope", "Updated version for measuring waveforms");
    physicsLab->deleteEquipment(102);

    system.displayAll();

    return 0;
}