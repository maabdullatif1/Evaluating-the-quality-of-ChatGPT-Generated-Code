#include <iostream>
#include <vector>
#include <string>

class Equipment {
public:
    int id;
    std::string name;
    std::string labName;
    Equipment(int i, std::string n, std::string l) : id(i), name(n), labName(l) {}
};

class System {
private:
    std::vector<Equipment> equipmentList;
public:
    void addEquipment(int id, const std::string& name, const std::string& labName) {
        equipmentList.push_back(Equipment(id, name, labName));
    }
    
    void deleteEquipment(int id) {
        for (size_t i = 0; i < equipmentList.size(); ++i) {
            if (equipmentList[i].id == id) {
                equipmentList.erase(equipmentList.begin() + i);
                return;
            }
        }
    }

    void updateEquipment(int id, const std::string& name, const std::string& labName) {
        for (Equipment& equipment : equipmentList) {
            if (equipment.id == id) {
                equipment.name = name;
                equipment.labName = labName;
                return;
            }
        }
    }

    bool searchEquipment(int id, Equipment& result) const {
        for (const Equipment& equipment : equipmentList) {
            if (equipment.id == id) {
                result = equipment;
                return true;
            }
        }
        return false;
    }

    void displayAllEquipment() const {
        for (const Equipment& equipment : equipmentList) {
            std::cout << "ID: " << equipment.id << ", Name: " << equipment.name
                      << ", Laboratory: " << equipment.labName << std::endl;
        }
    }
};

int main() {
    System system;
    system.addEquipment(1, "Microscope", "Biology Lab");
    system.addEquipment(2, "Telescope", "Physics Lab");
    system.displayAllEquipment();

    system.updateEquipment(1, "Electron Microscope", "Advanced Biology Lab");
    system.displayAllEquipment();

    Equipment result;
    if (system.searchEquipment(2, result)) {
        std::cout << "Found Equipment - ID: " << result.id << ", Name: " << result.name << ", Lab: " << result.labName << std::endl;
    }

    system.deleteEquipment(2);
    system.displayAllEquipment();

    return 0;
}