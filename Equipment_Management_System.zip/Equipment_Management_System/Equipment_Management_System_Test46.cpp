#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string type;

    Equipment(int id, string name, string type) : id(id), name(name), type(type) {}

    void display() const {
        cout << "Equipment ID: " << id << ", Name: " << name << ", Type: " << type << endl;
    }
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipmentList;

    Laboratory(int id, string name) : id(id), name(name) {}

    void display() const {
        cout << "Laboratory ID: " << id << ", Name: " << name << endl;
        for (const auto& equip : equipmentList) {
            equip.display();
        }
    }

    void addEquipment(const Equipment& equipment) {
        equipmentList.push_back(equipment);
    }

    bool removeEquipment(int equipmentId) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == equipmentId) {
                equipmentList.erase(it);
                return true;
            }
        }
        return false;
    }

    Equipment* searchEquipment(int equipmentId) {
        for (auto& equip : equipmentList) {
            if (equip.id == equipmentId) {
                return &equip;
            }
        }
        return nullptr;
    }
};

class ManagementSystem {
public:
    vector<Laboratory> laboratories;

    void addLaboratory(const Laboratory& lab) {
        laboratories.push_back(lab);
    }

    bool removeLaboratory(int labId) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == labId) {
                laboratories.erase(it);
                return true;
            }
        }
        return false;
    }

    Laboratory* searchLaboratory(int labId) {
        for (auto& lab : laboratories) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayAllLaboratories() const {
        for (const auto& lab : laboratories) {
            lab.display();
        }
    }
};

int main() {
    ManagementSystem system;
    int choice, id, labId, equipId;
    string name, type;

    while (true) {
        cout << "1. Add Laboratory\n2. Remove Laboratory\n3. Add Equipment\n4. Remove Equipment\n5. Search Laboratory\n6. Search Equipment\n7. Display All\n8. Exit\n";
        cin >> choice;
        
        switch(choice) {
            case 1:
                cout << "Enter Laboratory ID and Name: ";
                cin >> id >> name;
                system.addLaboratory(Laboratory(id, name));
                break;
            case 2:
                cout << "Enter Laboratory ID to remove: ";
                cin >> id;
                if (!system.removeLaboratory(id)) {
                    cout << "Laboratory not found\n";
                }
                break;
            case 3:
                cout << "Enter Laboratory ID to add equipment to: ";
                cin >> labId;
                if (Laboratory* lab = system.searchLaboratory(labId)) {
                    cout << "Enter Equipment ID, Name, and Type: ";
                    cin >> id >> name >> type;
                    lab->addEquipment(Equipment(id, name, type));
                } else {
                    cout << "Laboratory not found\n";
                }
                break;
            case 4:
                cout << "Enter Laboratory ID to remove equipment from: ";
                cin >> labId;
                if (Laboratory* lab = system.searchLaboratory(labId)) {
                    cout << "Enter Equipment ID to remove: ";
                    cin >> id;
                    if (!lab->removeEquipment(id)) {
                        cout << "Equipment not found\n";
                    }
                } else {
                    cout << "Laboratory not found\n";
                }
                break;
            case 5:
                cout << "Enter Laboratory ID to search: ";
                cin >> id;
                if (Laboratory* lab = system.searchLaboratory(id)) {
                    lab->display();
                } else {
                    cout << "Laboratory not found\n";
                }
                break;
            case 6:
                cout << "Enter Laboratory ID to search equipment in: ";
                cin >> labId;
                if (Laboratory* lab = system.searchLaboratory(labId)) {
                    cout << "Enter Equipment ID to search: ";
                    cin >> equipId;
                    if (Equipment* equip = lab->searchEquipment(equipId)) {
                        equip->display();
                    } else {
                        cout << "Equipment not found\n";
                    }
                } else {
                    cout << "Laboratory not found\n";
                }
                break;
            case 7:
                system.displayAllLaboratories();
                break;
            case 8:
                return 0;
        }
    }
    return 0;
}