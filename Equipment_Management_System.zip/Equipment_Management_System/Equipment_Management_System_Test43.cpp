#include <iostream>
#include <vector>
#include <string>

struct Equipment {
    int id;
    std::string name;
    std::string lab;
};

class EquipmentManager {
private:
    std::vector<Equipment> equipmentList;
    int nextID;

public:
    EquipmentManager() : nextID(1) {}

    void addEquipment(const std::string& name, const std::string& lab) {
        Equipment equipment;
        equipment.id = nextID++;
        equipment.name = name;
        equipment.lab = lab;
        equipmentList.push_back(equipment);
    }

    void deleteEquipment(int id) {
        for (auto it = equipmentList.begin(); it != equipmentList.end(); ++it) {
            if (it->id == id) {
                equipmentList.erase(it);
                return;
            }
        }
    }

    void updateEquipment(int id, const std::string& name, const std::string& lab) {
        for (auto& equipment : equipmentList) {
            if (equipment.id == id) {
                equipment.name = name;
                equipment.lab = lab;
                return;
            }
        }
    }

    Equipment* searchEquipment(int id) {
        for (auto& equipment : equipmentList) {
            if (equipment.id == id) {
                return &equipment;
            }
        }
        return nullptr;
    }

    void displayEquipment() const {
        for (const auto& equipment : equipmentList) {
            std::cout << "ID: " << equipment.id << ", Name: " << equipment.name << ", Laboratory: " << equipment.lab << std::endl;
        }
    }
};

int main() {
    EquipmentManager manager;
    
    manager.addEquipment("Oscilloscope", "Electronics Lab");
    manager.addEquipment("Bunsen Burner", "Chemistry Lab");
    
    manager.displayEquipment();
    
    Equipment* searchResult = manager.searchEquipment(1);
    if (searchResult) {
        std::cout << "Found Equipment: ID: " << searchResult->id << ", Name: " << searchResult->name << ", Lab: " << searchResult->lab << std::endl;
    }
    
    manager.updateEquipment(1, "Digital Oscilloscope", "Advanced Electronics Lab");
    
    manager.displayEquipment();
    
    manager.deleteEquipment(2);
    
    manager.displayEquipment();
    
    return 0;
}