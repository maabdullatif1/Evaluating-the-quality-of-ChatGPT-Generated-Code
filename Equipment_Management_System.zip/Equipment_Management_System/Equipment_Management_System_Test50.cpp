#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string description;

    Equipment(int id, const string &name, const string &description) : id(id), name(name), description(description) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipments;

    Laboratory(int id, const string &name) : id(id), name(name) {}

    void addEquipment(const Equipment& equip) {
        equipments.push_back(equip);
    }
    
    bool removeEquipment(int equipId) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == equipId) {
                equipments.erase(it);
                return true;
            }
        }
        return false;
    }

    Equipment* findEquipment(int equipId) {
        for (auto &equip : equipments) {
            if (equip.id == equipId) {
                return &equip;
            }
        }
        return nullptr;
    }
};

class EquipmentManagementSystem {
private:
    vector<Laboratory> laboratories;
    
public:
    Laboratory* findLaboratory(int labId) {
        for (auto &lab : laboratories) {
            if (lab.id == labId) {
                return &lab;
            }
        }
        return nullptr;
    }

    void addLaboratory(int id, const string &name) {
        laboratories.emplace_back(id, name);
    }

    bool removeLaboratory(int labId) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == labId) {
                laboratories.erase(it);
                return true;
            }
        }
        return false;
    }

    void displayLaboratories() {
        for (const auto &lab : laboratories) {
            cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << endl;
            for (const auto &equip : lab.equipments) {
                cout << "\tEquipment ID: " << equip.id << ", Name: " << equip.name
                     << ", Description: " << equip.description << endl;
            }
        }
    }
};

int main() {
    EquipmentManagementSystem system;

    system.addLaboratory(1, "Physics Lab");
    system.addLaboratory(2, "Chemistry Lab");

    Laboratory *physicsLab = system.findLaboratory(1);
    if (physicsLab) {
        physicsLab->addEquipment(Equipment(1, "Oscilloscope", "Used for signal analysis"));
        physicsLab->addEquipment(Equipment(2, "Voltmeter", "Used for measuring voltage"));
    }

    Laboratory *chemistryLab = system.findLaboratory(2);
    if (chemistryLab) {
        chemistryLab->addEquipment(Equipment(3, "Burner", "Used for heating"));
    }

    system.displayLaboratories();

    Equipment *equip = physicsLab->findEquipment(1);
    if (equip) {
        equip->name = "Digital Oscilloscope";
    }

    physicsLab->removeEquipment(2);

    system.displayLaboratories();

    return 0;
}