#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Equipment {
    int id;
    string name;
    string lab;
};

class EquipmentManager {
private:
    vector<Equipment> equipments;
    int generateId() {
        return equipments.empty() ? 1 : equipments.back().id + 1;
    }

public:
    void addEquipment(const string& name, const string& lab) {
        Equipment eq;
        eq.id = generateId();
        eq.name = name;
        eq.lab = lab;
        equipments.push_back(eq);
    }

    void deleteEquipment(int id) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == id) {
                equipments.erase(it);
                return;
            }
        }
        cout << "Equipment not found" << endl;
    }

    void updateEquipment(int id, const string& name, const string& lab) {
        for (auto& eq : equipments) {
            if (eq.id == id) {
                eq.name = name;
                eq.lab = lab;
                return;
            }
        }
        cout << "Equipment not found" << endl;
    }

    void searchEquipment(int id) {
        for (const auto& eq : equipments) {
            if (eq.id == id) {
                cout << "ID: " << eq.id << ", Name: " << eq.name << ", Lab: " << eq.lab << endl;
                return;
            }
        }
        cout << "Equipment not found" << endl;
    }

    void displayEquipments() {
        for (const auto& eq : equipments) {
            cout << "ID: " << eq.id << ", Name: " << eq.name << ", Lab: " << eq.lab << endl;
        }
    }
};

int main() {
    EquipmentManager manager;
    int choice, id;
    string name, lab;

    while (true) {
        cout << "1. Add Equipment\n2. Delete Equipment\n3. Update Equipment\n";
        cout << "4. Search Equipment\n5. Display Equipments\n6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter name: ";
                cin >> name;
                cout << "Enter lab: ";
                cin >> lab;
                manager.addEquipment(name, lab);
                break;
            case 2:
                cout << "Enter equipment ID to delete: ";
                cin >> id;
                manager.deleteEquipment(id);
                break;
            case 3:
                cout << "Enter equipment ID to update: ";
                cin >> id;
                cout << "Enter new name: ";
                cin >> name;
                cout << "Enter new lab: ";
                cin >> lab;
                manager.updateEquipment(id, name, lab);
                break;
            case 4:
                cout << "Enter equipment ID to search: ";
                cin >> id;
                manager.searchEquipment(id);
                break;
            case 5:
                manager.displayEquipments();
                break;
            case 6:
                return 0;
            default:
                cout << "Invalid choice" << endl;
                break;
        }
    }
}