#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string description;

    Equipment(int i, string n, string d) : id(i), name(n), description(d) {}
};

class Laboratory {
public:
    int id;
    string name;
    vector<Equipment> equipments;

    Laboratory(int i, string n) : id(i), name(n) {}
    
    void addEquipment(const Equipment& eq) {
        equipments.push_back(eq);
    }

    void deleteEquipment(int eq_id) {
        for (auto it = equipments.begin(); it != equipments.end(); ++it) {
            if (it->id == eq_id) {
                equipments.erase(it);
                break;
            }
        }
    }

    void updateEquipment(int eq_id, const Equipment& new_eq) {
        for (auto &eq : equipments) {
            if (eq.id == eq_id) {
                eq = new_eq;
                break;
            }
        }
    }

    void displayEquipments() const {
        for (const auto &eq : equipments) {
            cout << "Equipment ID: " << eq.id << ", Name: " << eq.name 
                 << ", Description: " << eq.description << endl;
        }
    }
};

class EquipmentManagementSystem {
public:
    vector<Laboratory> laboratories;

    void addLaboratory(const Laboratory& lab) {
        laboratories.push_back(lab);
    }

    void deleteLaboratory(int lab_id) {
        for (auto it = laboratories.begin(); it != laboratories.end(); ++it) {
            if (it->id == lab_id) {
                laboratories.erase(it);
                break;
            }
        }
    }

    void updateLaboratory(int lab_id, const Laboratory& new_lab) {
        for (auto &lab : laboratories) {
            if (lab.id == lab_id) {
                lab = new_lab;
                break;
            }
        }
    }

    Laboratory* searchLaboratory(int lab_id) {
        for (auto &lab : laboratories) {
            if (lab.id == lab_id) {
                return &lab;
            }
        }
        return nullptr;
    }

    void displayLaboratories() const {
        for (const auto &lab : laboratories) {
            cout << "Laboratory ID: " << lab.id << ", Name: " << lab.name << endl;
            lab.displayEquipments();
        }
    }
};

int main() {
    EquipmentManagementSystem system;

    Laboratory lab1(1, "Chemistry Lab");
    lab1.addEquipment(Equipment(101, "Beaker", "Glass container used in chemistry labs"));
    lab1.addEquipment(Equipment(102, "Bunsen Burner", "Gas burner used for heating"));

    Laboratory lab2(2, "Physics Lab");
    lab2.addEquipment(Equipment(201, "Voltmeter", "Device used to measure voltage"));
    lab2.addEquipment(Equipment(202, "Ammeter", "Device used to measure current"));

    system.addLaboratory(lab1);
    system.addLaboratory(lab2);

    cout << "Equipment in the system:" << endl;
    system.displayLaboratories();

    return 0;
}