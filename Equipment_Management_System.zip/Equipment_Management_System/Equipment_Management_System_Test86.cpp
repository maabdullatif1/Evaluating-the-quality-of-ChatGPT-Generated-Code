#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Equipment {
public:
    int id;
    string name;
    string lab;

    Equipment(int i, string n, string l) : id(i), name(n), lab(l) {}
};

class EquipmentManager {
    vector<Equipment> equipments;
    int nextId = 1;

    int findEquipmentIndexById(int id) {
        for (size_t i = 0; i < equipments.size(); ++i) {
            if (equipments[i].id == id) return i;
        }
        return -1;
    }
    
public:
    void addEquipment(string name, string lab) {
        equipments.push_back(Equipment(nextId++, name, lab));
    }
    
    void deleteEquipment(int id) {
        int index = findEquipmentIndexById(id);
        if (index != -1) {
            equipments.erase(equipments.begin() + index);
        } else {
            cout << "Equipment not found.\n";
        }
    }
    
    void updateEquipment(int id, string name, string lab) {
        int index = findEquipmentIndexById(id);
        if (index != -1) {
            equipments[index].name = name;
            equipments[index].lab = lab;
        } else {
            cout << "Equipment not found.\n";
        }
    }
    
    Equipment searchEquipment(int id) {
        int index = findEquipmentIndexById(id);
        if (index != -1) {
            return equipments[index];
        } else {
            cout << "Equipment not found.\n";
            return Equipment(-1, "", "");
        }
    }
    
    void displayEquipments() {
        for (const auto& eq : equipments) {
            cout << "ID: " << eq.id << ", Name: " << eq.name << ", Lab: " << eq.lab << endl;
        }
    }
};

int main() {
    EquipmentManager manager;
    manager.addEquipment("Oscilloscope", "Lab A");
    manager.addEquipment("Multimeter", "Lab B");
    manager.displayEquipments();

    manager.updateEquipment(1, "Advanced Oscilloscope", "Lab A");
    manager.displayEquipments();

    Equipment e = manager.searchEquipment(2);
    if (e.id != -1) {
        cout << "Found Equipment: ID: " << e.id << ", Name: " << e.name << ", Lab: " << e.lab << endl;
    }

    manager.deleteEquipment(1);
    manager.displayEquipments();

    return 0;
}