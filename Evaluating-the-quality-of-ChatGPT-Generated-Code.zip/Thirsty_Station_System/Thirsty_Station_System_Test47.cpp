#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
    string phone;
};

struct Shop {
    int id;
    string name;
    string location;
    string contact;
};

class DeliverySystem {
    vector<Customer> customers;
    vector<Shop> shops;
    int customerId;
    int shopId;

public:
    DeliverySystem() : customerId(0), shopId(0) {}

    void addCustomer(string name, string address, string phone) {
        customers.push_back({++customerId, name, address, phone});
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string address, string phone) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                customer.phone = phone;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                displayCustomer(customer);
                return;
            }
        }
        cout << "Customer not found.\n";
    }

    void displayCustomer(const Customer& customer) {
        cout << "Customer ID: " << customer.id << "\n";
        cout << "Name: " << customer.name << "\n";
        cout << "Address: " << customer.address << "\n";
        cout << "Phone: " << customer.phone << "\n";
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            displayCustomer(customer);
        }
    }

    void addShop(string name, string location, string contact) {
        shops.push_back({++shopId, name, location, contact});
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, string name, string location, string contact) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                shop.contact = contact;
                break;
            }
        }
    }

    void searchShop(int id) {
        for (const auto& shop : shops) {
            if (shop.id == id) {
                displayShop(shop);
                return;
            }
        }
        cout << "Shop not found.\n";
    }

    void displayShop(const Shop& shop) {
        cout << "Shop ID: " << shop.id << "\n";
        cout << "Name: " << shop.name << "\n";
        cout << "Location: " << shop.location << "\n";
        cout << "Contact: " << shop.contact << "\n";
    }

    void displayShops() {
        for (const auto& shop : shops) {
            displayShop(shop);
        }
    }
};

int main() {
    DeliverySystem system;
    system.addCustomer("John Doe", "123 Maple St", "555-0199");
    system.addShop("Local Pub", "456 Oak St", "555-0248");

    cout << "All Customers:\n";
    system.displayCustomers();

    cout << "\nAll Shops:\n";
    system.displayShops();

    return 0;
}