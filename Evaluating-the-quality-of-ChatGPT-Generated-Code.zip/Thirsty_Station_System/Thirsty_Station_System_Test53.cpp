#include <iostream>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

Customer customers[100];
Shop shops[100];
int customerCount = 0;
int shopCount = 0;

void addCustomer(int id, string name, string address) {
    customers[customerCount++] = {id, name, address};
}

void addShop(int id, string name, string location) {
    shops[shopCount++] = {id, name, location};
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            customers[i] = customers[--customerCount];
            break;
        }
    }
}

void deleteShop(int id) {
    for (int i = 0; i < shopCount; i++) {
        if (shops[i].id == id) {
            shops[i] = shops[--shopCount];
            break;
        }
    }
}

void updateCustomer(int id, string name, string address) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            customers[i].name = name;
            customers[i].address = address;
            break;
        }
    }
}

void updateShop(int id, string name, string location) {
    for (int i = 0; i < shopCount; i++) {
        if (shops[i].id == id) {
            shops[i].name = name;
            shops[i].location = location;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

Shop* searchShop(int id) {
    for (int i = 0; i < shopCount; i++) {
        if (shops[i].id == id) {
            return &shops[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; i++) {
        cout << "Customer ID: " << customers[i].id
             << ", Name: " << customers[i].name
             << ", Address: " << customers[i].address << endl;
    }
}

void displayShops() {
    for (int i = 0; i < shopCount; i++) {
        cout << "Shop ID: " << shops[i].id
             << ", Name: " << shops[i].name
             << ", Location: " << shops[i].location << endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "123 Main St");
    addCustomer(2, "Jane Doe", "456 Elm St");

    addShop(1, "Shop A", "789 Oak St");
    addShop(2, "Shop B", "101 Pine St");

    displayCustomers();
    displayShops();

    updateCustomer(1, "John Smith", "321 Main St");
    updateShop(2, "Shop B Updated", "111 Pine St Updated");

    displayCustomers();
    displayShops();

    deleteCustomer(1);
    deleteShop(2);

    displayCustomers();
    displayShops();

    return 0;
}