#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string address;

    Customer(int cid, std::string cname, std::string caddress) 
        : id(cid), name(cname), address(caddress) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;

    Shop(int sid, std::string sname, std::string slocation) 
        : id(sid), name(sname), location(slocation) {}
};

class DeliveryServiceSystem {
private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(int id, std::string name, std::string address) {
        customers.push_back(Customer(id, name, address));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string address) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "ID: " << customer.id << " Name: " << customer.name 
                      << " Address: " << customer.address << std::endl;
        }
    }

    void addShop(int id, std::string name, std::string location) {
        shops.push_back(Shop(id, name, location));
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, std::string name, std::string location) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                break;
            }
        }
    }

    Shop* searchShop(int id) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayShops() {
        for (const auto &shop : shops) {
            std::cout << "ID: " << shop.id << " Name: " << shop.name 
                      << " Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    DeliveryServiceSystem system;

    system.addCustomer(1, "Alice", "123 Wonderlane");
    system.addCustomer(2, "Bob", "456 Nowhere Ave");

    system.addShop(1, "DrinkHub", "789 Central St");
    system.addShop(2, "Refreshments R Us", "159 Prime Blvd");

    system.displayCustomers();
    system.displayShops();

    system.updateCustomer(1, "Alice Wonderland", "1234 Fairy Tale Rd");
    system.updateShop(1, "DrinkHub Premium", "7899 Central Park Ave");
    
    system.displayCustomers();
    system.displayShops();

    system.deleteCustomer(2);
    system.deleteShop(2);

    system.displayCustomers();
    system.displayShops();

    return 0;
}