#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string address;

    Customer(int _id, std::string _name, std::string _address)
        : id(_id), name(_name), address(_address) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;

    Shop(int _id, std::string _name, std::string _location)
        : id(_id), name(_name), location(_location) {}
};

class DeliveryServiceSystem {
private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(int id, std::string name, std::string address) {
        customers.push_back(Customer(id, name, address));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string address) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto &customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << std::endl;
                return;
            }
        }
        std::cout << "Customer not found." << std::endl;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << std::endl;
        }
    }

    void addShop(int id, std::string name, std::string location) {
        shops.push_back(Shop(id, name, location));
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, std::string name, std::string location) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                break;
            }
        }
    }

    void searchShop(int id) {
        for (const auto &shop : shops) {
            if (shop.id == id) {
                std::cout << "Shop ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << std::endl;
                return;
            }
        }
        std::cout << "Shop not found." << std::endl;
    }

    void displayShops() {
        for (const auto &shop : shops) {
            std::cout << "Shop ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    DeliveryServiceSystem system;

    system.addCustomer(1, "Alice", "123 Main St");
    system.addCustomer(2, "Bob", "456 Elm St");
    system.displayCustomers();

    system.addShop(1, "Shop A", "Downtown");
    system.addShop(2, "Shop B", "Uptown");
    system.displayShops();

    system.updateCustomer(1, "Alice W", "123 Main St Apt 1");
    system.searchCustomer(1);

    system.updateShop(1, "Shop Alpha", "City Center");
    system.searchShop(1);

    system.deleteCustomer(2);
    system.displayCustomers();

    system.deleteShop(2);
    system.displayShops();

    return 0;
}