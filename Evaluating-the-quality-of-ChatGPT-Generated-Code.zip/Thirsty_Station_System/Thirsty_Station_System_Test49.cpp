#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Customer {
public:
    string name;
    string address;
    string phone;

    Customer(string n, string a, string p) : name(n), address(a), phone(p) {}

    void updateCustomer(string n, string a, string p) {
        name = n;
        address = a;
        phone = p;
    }
};

class Shop {
public:
    string name;
    string address;
    string phone;

    Shop(string n, string a, string p) : name(n), address(a), phone(p) {}

    void updateShop(string n, string a, string p) {
        name = n;
        address = a;
        phone = p;
    }
};

class ServiceSystem {
    vector<Customer> customers;
    vector<Shop> shops;

public:
    void addCustomer(const string& name, const string& address, const string& phone) {
        customers.emplace_back(name, address, phone);
    }
    
    void deleteCustomer(const string& name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(const string& oldName, const string& newName, const string& newAddress, const string& newPhone) {
        for (auto& customer : customers) {
            if (customer.name == oldName) {
                customer.updateCustomer(newName, newAddress, newPhone);
                break;
            }
        }
    }
    
    void searchCustomer(const string& name) {
        for (const auto& customer : customers) {
            if (customer.name == name) {
                cout << "Found Customer: " << customer.name << ", " << customer.address << ", " << customer.phone << endl;
                return;
            }
        }
        cout << "Customer not found." << endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Customer: " << customer.name << ", " << customer.address << ", " << customer.phone << endl;
        }
    }

    void addShop(const string& name, const string& address, const string& phone) {
        shops.emplace_back(name, address, phone);
    }

    void deleteShop(const string& name) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->name == name) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(const string& oldName, const string& newName, const string& newAddress, const string& newPhone) {
        for (auto& shop : shops) {
            if (shop.name == oldName) {
                shop.updateShop(newName, newAddress, newPhone);
                break;
            }
        }
    }

    void searchShop(const string& name) {
        for (const auto& shop : shops) {
            if (shop.name == name) {
                cout << "Found Shop: " << shop.name << ", " << shop.address << ", " << shop.phone << endl;
                return;
            }
        }
        cout << "Shop not found." << endl;
    }

    void displayShops() {
        for (const auto& shop : shops) {
            cout << "Shop: " << shop.name << ", " << shop.address << ", " << shop.phone << endl;
        }
    }
};

int main() {
    ServiceSystem system;
    system.addCustomer("John Doe", "123 Elm Street", "555-1234");
    system.addCustomer("Jane Doe", "456 Oak Avenue", "555-5678");

    system.addShop("Joe's Coffee", "789 Maple Road", "555-8765");
    system.addShop("Tea Time", "321 Pine Lane", "555-4321");

    system.displayCustomers();
    system.displayShops();

    system.searchCustomer("John Doe");
    system.updateCustomer("John Doe", "Johnathan Doe", "123 Elm Street", "555-9999");
    system.displayCustomers();

    system.searchShop("Joe's Coffee");
    system.updateShop("Joe's Coffee", "Joe's Espresso", "789 Maple Road", "555-8888");
    system.displayShops();

    system.deleteCustomer("Jane Doe");
    system.displayCustomers();

    system.deleteShop("Tea Time");
    system.displayShops();

    return 0;
}