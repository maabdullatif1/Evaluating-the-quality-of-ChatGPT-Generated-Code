#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string address;

    Customer(int id, string name, string address) : id(id), name(name), address(address) {}
};

class Shop {
public:
    int id;
    string name;
    string location;

    Shop(int id, string name, string location) : id(id), name(name), location(location) {}
};

vector<Customer> customers;
vector<Shop> shops;

int customerIdCounter = 0;
int shopIdCounter = 0;

void addCustomer(string name, string address) {
    customers.push_back(Customer(++customerIdCounter, name, address));
}

void addShop(string name, string location) {
    shops.push_back(Shop(++shopIdCounter, name, location));
}

void removeCustomer(int id) {
    for (size_t i = 0; i < customers.size(); ++i) {
        if (customers[i].id == id) {
            customers.erase(customers.begin() + i);
            break;
        }
    }
}

void removeShop(int id) {
    for (size_t i = 0; i < shops.size(); ++i) {
        if (shops[i].id == id) {
            shops.erase(shops.begin() + i);
            break;
        }
    }
}

void updateCustomer(int id, string name, string address) {
    for (auto &customer : customers) {
        if (customer.id == id) {
            customer.name = name;
            customer.address = address;
            break;
        }
    }
}

void updateShop(int id, string name, string location) {
    for (auto &shop : shops) {
        if (shop.id == id) {
            shop.name = name;
            shop.location = location;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (auto &customer : customers) {
        if (customer.id == id) {
            return &customer;
        }
    }
    return nullptr;
}

Shop* searchShop(int id) {
    for (auto &shop : shops) {
        if (shop.id == id) {
            return &shop;
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (const auto &customer : customers) {
        cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << endl;
    }
}

void displayShops() {
    for (const auto &shop : shops) {
        cout << "Shop ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << endl;
    }
}

int main() {
    addCustomer("Alice", "123 Main St");
    addCustomer("Bob", "456 Elm St");
    displayCustomers();

    addShop("Downtown Drinks", "City Center");
    addShop("Suburb Sips", "Suburb Plaza");
    displayShops();

    updateCustomer(1, "Alice Johnson", "789 Park Ave");
    updateShop(2, "Suburb Sips Updated", "Suburb Mall");
    displayCustomers();
    displayShops();

    Customer* foundCustomer = searchCustomer(2);
    if (foundCustomer) {
        cout << "Found Customer: " << foundCustomer->name << endl;
    }

    Shop* foundShop = searchShop(1);
    if (foundShop) {
        cout << "Found Shop: " << foundShop->name << endl;
    }

    removeCustomer(1);
    removeShop(2);
    displayCustomers();
    displayShops();

    return 0;
}