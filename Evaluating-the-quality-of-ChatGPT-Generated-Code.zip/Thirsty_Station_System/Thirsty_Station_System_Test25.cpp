#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

class DeliveryService {
    vector<Customer> customers;
    vector<Shop> shops;
    int customerIdCounter = 1;
    int shopIdCounter = 1;

    Customer* findCustomerById(int id) {
        for (auto &customer : customers) {
            if (customer.id == id)
                return &customer;
        }
        return nullptr;
    }

    Shop* findShopById(int id) {
        for (auto &shop : shops) {
            if (shop.id == id)
                return &shop;
        }
        return nullptr;
    }

public:
    void addCustomer(string name, string address) {
        customers.push_back({customerIdCounter++, name, address});
    }

    void deleteCustomer(int id) {
        customers.erase(remove_if(customers.begin(), customers.end(), [=](Customer &c) { return c.id == id; }), customers.end());
    }

    void updateCustomer(int id, string name, string address) {
        Customer* customer = findCustomerById(id);
        if (customer) {
            customer->name = name;
            customer->address = address;
        }
    }

    void addShop(string name, string location) {
        shops.push_back({shopIdCounter++, name, location});
    }

    void deleteShop(int id) {
        shops.erase(remove_if(shops.begin(), shops.end(), [=](Shop &s) { return s.id == id; }), shops.end());
    }

    void updateShop(int id, string name, string location) {
        Shop* shop = findShopById(id);
        if (shop) {
            shop->name = name;
            shop->location = location;
        }
    }

    Customer* searchCustomer(int id) {
        return findCustomerById(id);
    }

    Shop* searchShop(int id) {
        return findShopById(id);
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << endl;
        }
    }

    void displayShops() {
        for (const auto &shop : shops) {
            cout << "ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << endl;
        }
    }
};

int main() {
    DeliveryService service;

    service.addCustomer("Alice", "123 Apple St");
    service.addCustomer("Bob", "456 Banana Ave");
    service.addShop("Cool Drinks", "789 Cherry Blvd");

    service.displayCustomers();
    service.displayShops();

    service.updateCustomer(1, "Alice Smith", "123 Apple St, Apt 1");
    service.updateShop(1, "Coolest Drinks", "789 Cherry Blvd, Suite 101");

    service.displayCustomers();
    service.displayShops();

    Customer* searchedCustomer = service.searchCustomer(2);
    if (searchedCustomer) {
        cout << "Found Customer: " << searchedCustomer->name << endl;
    }

    service.deleteCustomer(2);
    service.deleteShop(1);

    service.displayCustomers();
    service.displayShops();

    return 0;
}