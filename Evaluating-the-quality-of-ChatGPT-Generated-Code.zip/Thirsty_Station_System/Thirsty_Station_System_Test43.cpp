#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
    string phoneNumber;
};

struct Shop {
    int id;
    string name;
    string location;
};

vector<Customer> customers;
vector<Shop> shops;

void addCustomer() {
    Customer c;
    cout << "Enter customer ID: ";
    cin >> c.id;
    cout << "Enter customer Name: ";
    cin >> c.name;
    cout << "Enter customer Address: ";
    cin >> c.address;
    cout << "Enter customer Phone Number: ";
    cin >> c.phoneNumber;
    customers.push_back(c);
}

void deleteCustomer() {
    int id;
    cout << "Enter customer ID to delete: ";
    cin >> id;
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            break;
        }
    }
}

void updateCustomer() {
    int id;
    cout << "Enter customer ID to update: ";
    cin >> id;
    for (auto& c : customers) {
        if (c.id == id) {
            cout << "Enter new customer Name: ";
            cin >> c.name;
            cout << "Enter new customer Address: ";
            cin >> c.address;
            cout << "Enter new customer Phone Number: ";
            cin >> c.phoneNumber;
            break;
        }
    }
}

void searchCustomer() {
    int id;
    cout << "Enter customer ID to search: ";
    cin >> id;
    for (auto& c : customers) {
        if (c.id == id) {
            cout << "Customer ID: " << c.id << ", Name: " << c.name
                 << ", Address: " << c.address << ", Phone Number: " << c.phoneNumber << endl;
            return;
        }
    }
    cout << "Customer not found" << endl;
}

void displayCustomers() {
    for (auto& c : customers) {
        cout << "ID: " << c.id << ", Name: " << c.name
             << ", Address: " << c.address << ", Phone: " << c.phoneNumber << endl;
    }
}

void addShop() {
    Shop s;
    cout << "Enter shop ID: ";
    cin >> s.id;
    cout << "Enter shop Name: ";
    cin >> s.name;
    cout << "Enter shop Location: ";
    cin >> s.location;
    shops.push_back(s);
}

void deleteShop() {
    int id;
    cout << "Enter shop ID to delete: ";
    cin >> id;
    for (auto it = shops.begin(); it != shops.end(); ++it) {
        if (it->id == id) {
            shops.erase(it);
            break;
        }
    }
}

void updateShop() {
    int id;
    cout << "Enter shop ID to update: ";
    cin >> id;
    for (auto& s : shops) {
        if (s.id == id) {
            cout << "Enter new shop Name: ";
            cin >> s.name;
            cout << "Enter new shop Location: ";
            cin >> s.location;
            break;
        }
    }
}

void searchShop() {
    int id;
    cout << "Enter shop ID to search: ";
    cin >> id;
    for (auto& s : shops) {
        if (s.id == id) {
            cout << "Shop ID: " << s.id << ", Name: " << s.name
                 << ", Location: " << s.location << endl;
            return;
        }
    }
    cout << "Shop not found" << endl;
}

void displayShops() {
    for (auto& s : shops) {
        cout << "ID: " << s.id << ", Name: " << s.name
             << ", Location: " << s.location << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "\n1. Add Customer\n2. Delete Customer\n3. Update Customer\n"
             << "4. Search Customer\n5. Display All Customers\n"
             << "6. Add Shop\n7. Delete Shop\n8. Update Shop\n"
             << "9. Search Shop\n10. Display All Shops\n0. Exit\n";
        cin >> choice;
        switch (choice) {
            case 1: addCustomer(); break;
            case 2: deleteCustomer(); break;
            case 3: updateCustomer(); break;
            case 4: searchCustomer(); break;
            case 5: displayCustomers(); break;
            case 6: addShop(); break;
            case 7: deleteShop(); break;
            case 8: updateShop(); break;
            case 9: searchShop(); break;
            case 10: displayShops(); break;
        }
    } while (choice != 0);
    return 0;
}