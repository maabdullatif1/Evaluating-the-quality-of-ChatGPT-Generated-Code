#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    std::string address;
    std::string phone;
};

class Customer : public Person {
public:
    Customer(std::string n, std::string a, std::string p) {
        name = n;
        address = a;
        phone = p;
    }
};

class Shop : public Person {
public:
    Shop(std::string n, std::string a, std::string p) {
        name = n;
        address = a;
        phone = p;
    }
};

template <typename T>
class ManageEntities {
private:
    std::vector<T> entities;
public:
    void addEntity(const T &entity) {
        entities.push_back(entity);
    }

    void deleteEntity(const std::string &name) {
        for (auto it = entities.begin(); it != entities.end(); ++it) {
            if (it->name == name) {
                entities.erase(it);
                return;
            }
        }
    }

    void updateEntity(const std::string &name, const T &updatedEntity) {
        for (auto &entity : entities) {
            if (entity.name == name) {
                entity = updatedEntity;
                return;
            }
        }
    }

    T* searchEntity(const std::string &name) {
        for (auto &entity : entities) {
            if (entity.name == name) {
                return &entity;
            }
        }
        return nullptr;
    }

    void displayEntities() {
        for (const auto &entity : entities) {
            std::cout << "Name: " << entity.name << ", Address: " << entity.address << ", Phone: " << entity.phone << "\n";
        }
    }
};

int main() {
    ManageEntities<Customer> customerManager;
    ManageEntities<Shop> shopManager;

    customerManager.addEntity(Customer("Alice", "123 Main St", "555-1234"));
    customerManager.addEntity(Customer("Bob", "456 Elm St", "555-5678"));
    shopManager.addEntity(Shop("DrinkShop1", "789 High St", "555-8765"));
    shopManager.addEntity(Shop("DrinkShop2", "321 Oak St", "555-4321"));

    std::cout << "Customers:\n";
    customerManager.displayEntities();
    std::cout << "\nShops:\n";
    shopManager.displayEntities();

    std::cout << "\nSearch for 'Alice':\n";
    Customer *searchResult = customerManager.searchEntity("Alice");
    if (searchResult) {
        std::cout << "Found: " << searchResult->name << "\n";
    } else {
        std::cout << "Not found\n";
    }

    std::cout << "\nUpdating 'Bob'\n";
    customerManager.updateEntity("Bob", Customer("Bob", "New Address", "555-0000"));
    customerManager.displayEntities();

    std::cout << "\nDeleting 'DrinkShop1'\n";
    shopManager.deleteEntity("DrinkShop1");
    shopManager.displayEntities();

    return 0;
}