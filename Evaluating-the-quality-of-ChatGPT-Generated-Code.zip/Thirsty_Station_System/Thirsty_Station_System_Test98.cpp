#include <iostream>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string address;
    std::string phone;
    Customer* next;
};

struct Shop {
    int id;
    std::string name;
    std::string address;
    std::string phone;
    Shop* next;
};

class DrinksDeliveryService {
    Customer* headCustomer;
    Shop* headShop;
    int customerCount;
    int shopCount;

public:
    DrinksDeliveryService() : headCustomer(nullptr), headShop(nullptr), customerCount(0), shopCount(0) {}

    void addCustomer(const std::string& name, const std::string& address, const std::string& phone) {
        Customer* newCustomer = new Customer{ ++customerCount, name, address, phone, headCustomer };
        headCustomer = newCustomer;
    }

    void deleteCustomer(int id) {
        Customer** current = &headCustomer;
        while (*current) {
            if ((*current)->id == id) {
                Customer* temp = *current;
                *current = (*current)->next;
                delete temp;
                return;
            }
            current = &((*current)->next);
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& address, const std::string& phone) {
        Customer* current = headCustomer;
        while (current) {
            if (current->id == id) {
                current->name = name;
                current->address = address;
                current->phone = phone;
                return;
            }
            current = current->next;
        }
    }

    Customer* searchCustomer(int id) {
        Customer* current = headCustomer;
        while (current) {
            if (current->id == id) return current;
            current = current->next;
        }
        return nullptr;
    }

    void displayCustomers() {
        Customer* current = headCustomer;
        while (current) {
            std::cout << "ID: " << current->id << ", Name: " << current->name << ", Address: " << current->address << ", Phone: " << current->phone << '\n';
            current = current->next;
        }
    }

    void addShop(const std::string& name, const std::string& address, const std::string& phone) {
        Shop* newShop = new Shop{ ++shopCount, name, address, phone, headShop };
        headShop = newShop;
    }

    void deleteShop(int id) {
        Shop** current = &headShop;
        while (*current) {
            if ((*current)->id == id) {
                Shop* temp = *current;
                *current = (*current)->next;
                delete temp;
                return;
            }
            current = &((*current)->next);
        }
    }

    void updateShop(int id, const std::string& name, const std::string& address, const std::string& phone) {
        Shop* current = headShop;
        while (current) {
            if (current->id == id) {
                current->name = name;
                current->address = address;
                current->phone = phone;
                return;
            }
            current = current->next;
        }
    }

    Shop* searchShop(int id) {
        Shop* current = headShop;
        while (current) {
            if (current->id == id) return current;
            current = current->next;
        }
        return nullptr;
    }

    void displayShops() {
        Shop* current = headShop;
        while (current) {
            std::cout << "ID: " << current->id << ", Name: " << current->name << ", Address: " << current->address << ", Phone: " << current->phone << '\n';
            current = current->next;
        }
    }

    ~DrinksDeliveryService() {
        while (headCustomer) {
            Customer* temp = headCustomer;
            headCustomer = headCustomer->next;
            delete temp;
        }
        while (headShop) {
            Shop* temp = headShop;
            headShop = headShop->next;
            delete temp;
        }
    }
};

int main() {
    DrinksDeliveryService service;
    service.addCustomer("John Doe", "123 Main St", "555-1234");
    service.displayCustomers();
    service.addShop("Drink Hub", "456 High St", "555-5678");
    service.displayShops();
    return 0;
}