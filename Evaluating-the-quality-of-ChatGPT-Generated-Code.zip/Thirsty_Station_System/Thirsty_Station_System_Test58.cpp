#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

class DeliveryService {
    vector<Customer> customers;
    vector<Shop> shops;
    int customerCounter;
    int shopCounter;

public:
    DeliveryService() : customerCounter(0), shopCounter(0) {}

    void addCustomer(const string& name, const string& address) {
        customers.push_back({++customerCounter, name, address});
    }

    void addShop(const string& name, const string& location) {
        shops.push_back({++shopCounter, name, location});
    }

    bool deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return true;
            }
        }
        return false;
    }

    bool deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateCustomer(int id, const string& name, const string& address) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                return true;
            }
        }
        return false;
    }

    bool updateShop(int id, const string& name, const string& location) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                return true;
            }
        }
        return false;
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Shop* searchShop(int id) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << endl;
        }
    }

    void displayShops() {
        for (const auto& shop : shops) {
            cout << "Shop ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << endl;
        }
    }
};

int main() {
    DeliveryService service;
    service.addCustomer("Alice", "123 Main St");
    service.addCustomer("Bob", "456 Broadway");
    service.addShop("City Drinks", "9th Avenue");
    service.addShop("Drink Hub", "Market Street");

    service.displayCustomers();
    service.displayShops();

    service.updateCustomer(1, "Alice Smith", "789 Elm St");
    service.updateShop(1, "City Beverage", "10th Avenue");

    if (Customer* customer = service.searchCustomer(1)) {
        cout << "Found Customer - ID: " << customer->id << ", Name: " << customer->name << ", Address: " << customer->address << endl;
    }

    if (Shop* shop = service.searchShop(1)) {
        cout << "Found Shop - ID: " << shop->id << ", Name: " << shop->name << ", Location: " << shop->location << endl;
    }

    service.deleteCustomer(2);
    service.deleteShop(2);

    service.displayCustomers();
    service.displayShops();

    return 0;
}