#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string address;

    Customer(int i, const std::string& n, const std::string& a) : id(i), name(n), address(a) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;

    Shop(int i, const std::string& n, const std::string& l) : id(i), name(n), location(l) {}
};

class DrinksDeliverySystem {
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(int id, const std::string& name, const std::string& address) {
        customers.push_back(Customer(id, name, address));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& address) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }
    
    void displayCustomers() const {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << std::endl;
        }
    }

    void addShop(int id, const std::string& name, const std::string& location) {
        shops.push_back(Shop(id, name, location));
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, const std::string& name, const std::string& location) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                break;
            }
        }
    }

    Shop* searchShop(int id) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayShops() const {
        for (const auto& shop : shops) {
            std::cout << "Shop ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    DrinksDeliverySystem system;
    system.addCustomer(1, "John Doe", "123 Main St");
    system.addCustomer(2, "Jane Smith", "456 Oak St");

    system.addShop(1, "Cool Drinks", "Market Street");
    system.addShop(2, "Beverage Corner", "High Street");

    system.displayCustomers();
    system.displayShops();

    system.updateCustomer(1, "Johnathan Doe", "789 Pine St");
    system.updateShop(2, "The Drink Hub", "Central Avenue");

    system.displayCustomers();
    system.displayShops();

    system.deleteCustomer(2);
    system.deleteShop(1);

    system.displayCustomers();
    system.displayShops();

    return 0;
}