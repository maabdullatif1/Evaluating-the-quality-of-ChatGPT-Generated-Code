#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string address;
};

struct Shop {
    int id;
    std::string name;
    std::string location;
};

class DeliveryService {
    std::vector<Customer> customers;
    std::vector<Shop> shops;

    int generateCustomerId() {
        return customers.size() + 1;
    }

    int generateShopId() {
        return shops.size() + 1;
    }

public:
    void addCustomer(const std::string& name, const std::string& address) {
        Customer customer = {generateCustomerId(), name, address};
        customers.push_back(customer);
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& address) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id
                      << " Name: " << customer.name
                      << " Address: " << customer.address << std::endl;
        }
    }

    void addShop(const std::string& name, const std::string& location) {
        Shop shop = {generateShopId(), name, location};
        shops.push_back(shop);
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, const std::string& name, const std::string& location) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                break;
            }
        }
    }

    Shop* searchShop(int id) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "Shop ID: " << shop.id
                      << " Name: " << shop.name
                      << " Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    DeliveryService service;
    
    service.addCustomer("John Doe", "123 Elm St");
    service.addCustomer("Jane Smith", "456 Oak Ave");
    service.displayCustomers();

    service.addShop("DrinkHub", "Downtown");
    service.addShop("Beverage Corner", "Uptown");
    service.displayShops();

    service.updateCustomer(1, "John Doe", "789 Pine Rd");
    service.displayCustomers();

    service.deleteShop(1);
    service.displayShops();

    return 0;
}