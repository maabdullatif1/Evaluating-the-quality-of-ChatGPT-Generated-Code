#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

vector<Customer> customers;
vector<Shop> shops;

void addCustomer(int id, const string& name, const string& address) {
    customers.push_back({id, name, address});
}

void deleteCustomer(int id) {
    customers.erase(remove_if(customers.begin(), customers.end(), [&](Customer& c) { return c.id == id; }), customers.end());
}

void updateCustomer(int id, const string& name, const string& address) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            customer.name = name;
            customer.address = address;
        }
    }
}

Customer* searchCustomer(int id) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            return &customer;
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (const auto& customer : customers) {
        cout << "ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << endl;
    }
}

void addShop(int id, const string& name, const string& location) {
    shops.push_back({id, name, location});
}

void deleteShop(int id) {
    shops.erase(remove_if(shops.begin(), shops.end(), [&](Shop& s) { return s.id == id; }), shops.end());
}

void updateShop(int id, const string& name, const string& location) {
    for (auto& shop : shops) {
        if (shop.id == id) {
            shop.name = name;
            shop.location = location;
        }
    }
}

Shop* searchShop(int id) {
    for (auto& shop : shops) {
        if (shop.id == id) {
            return &shop;
        }
    }
    return nullptr;
}

void displayShops() {
    for (const auto& shop : shops) {
        cout << "ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "123 Elm St");
    addCustomer(2, "Jane Doe", "456 Maple Ave");
    displayCustomers();

    addShop(1, "Joe's Coffee", "789 Oak Blvd");
    addShop(2, "Sue's Tea House", "321 Pine Ln");
    displayShops();

    updateCustomer(1, "John Smith", "123 Elm St");
    Customer* customer = searchCustomer(1);
    if (customer) {
        cout << "Found Customer: " << customer->name << endl;
    }

    updateShop(1, "Joe's New Coffee", "789 Oak Blvd");
    Shop* shop = searchShop(1);
    if (shop) {
        cout << "Found Shop: " << shop->name << endl;
    }

    deleteCustomer(2);
    displayCustomers();

    deleteShop(2);
    displayShops();

    return 0;
}