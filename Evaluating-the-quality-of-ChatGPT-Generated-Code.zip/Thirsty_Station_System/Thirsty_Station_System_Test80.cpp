#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string address;
};

struct Shop {
    int id;
    std::string name;
    std::string location;
};

class DeliveryService {
    std::vector<Customer> customers;
    std::vector<Shop> shops;
    int customerIdCounter = 1;
    int shopIdCounter = 1;

public:
    void addCustomer(const std::string &name, const std::string &address) {
        customers.push_back({customerIdCounter++, name, address});
    }

    void deleteCustomer(int id) {
        customers.erase(std::remove_if(customers.begin(), customers.end(),
                     [&id](Customer &c) { return c.id == id; }), customers.end());
    }

    void updateCustomer(int id, const std::string &name, const std::string &address) {
        for (auto &c : customers) {
            if (c.id == id) {
                c.name = name;
                c.address = address;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto &c : customers) {
            if (c.id == id) {
                std::cout << "Customer ID: " << c.id << ", Name: " << c.name << ", Address: " << c.address << std::endl;
                return;
            }
        }
        std::cout << "Customer not found" << std::endl;
    }

    void displayCustomers() {
        for (const auto &c : customers) {
            std::cout << "Customer ID: " << c.id << ", Name: " << c.name << ", Address: " << c.address << std::endl;
        }
    }

    void addShop(const std::string &name, const std::string &location) {
        shops.push_back({shopIdCounter++, name, location});
    }

    void deleteShop(int id) {
        shops.erase(std::remove_if(shops.begin(), shops.end(),
                   [&id](Shop &s) { return s.id == id; }), shops.end());
    }

    void updateShop(int id, const std::string &name, const std::string &location) {
        for (auto &s : shops) {
            if (s.id == id) {
                s.name = name;
                s.location = location;
                break;
            }
        }
    }

    void searchShop(int id) {
        for (const auto &s : shops) {
            if (s.id == id) {
                std::cout << "Shop ID: " << s.id << ", Name: " << s.name << ", Location: " << s.location << std::endl;
                return;
            }
        }
        std::cout << "Shop not found" << std::endl;
    }

    void displayShops() {
        for (const auto &s : shops) {
            std::cout << "Shop ID: " << s.id << ", Name: " << s.name << ", Location: " << s.location << std::endl;
        }
    }
};

int main() {
    DeliveryService service;
    service.addCustomer("John Doe", "123 Elm Street");
    service.addCustomer("Jane Smith", "456 Oak Avenue");
    service.displayCustomers();
    service.addShop("Drink World", "789 Maple Road");
    service.addShop("Beverage Barn", "321 Pine Lane");
    service.displayShops();
    return 0;
}