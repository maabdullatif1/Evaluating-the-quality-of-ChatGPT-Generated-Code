#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

vector<Customer> customers;
vector<Shop> shops;
int customerIdCounter = 1;
int shopIdCounter = 1;

void displayCustomers() {
    for (const auto& customer : customers) {
        cout << "ID: " << customer.id << ", Name: " << customer.name
             << ", Address: " << customer.address << endl;
    }
}

void displayShops() {
    for (const auto& shop : shops) {
        cout << "ID: " << shop.id << ", Name: " << shop.name
             << ", Location: " << shop.location << endl;
    }
}

bool addCustomer(const string& name, const string& address) {
    customers.push_back({customerIdCounter++, name, address});
    return true;
}

bool addShop(const string& name, const string& location) {
    shops.push_back({shopIdCounter++, name, location});
    return true;
}

bool deleteCustomer(int id) {
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            return true;
        }
    }
    return false;
}

bool deleteShop(int id) {
    for (auto it = shops.begin(); it != shops.end(); ++it) {
        if (it->id == id) {
            shops.erase(it);
            return true;
        }
    }
    return false;
}

bool updateCustomer(int id, const string& name, const string& address) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            customer.name = name;
            customer.address = address;
            return true;
        }
    }
    return false;
}

bool updateShop(int id, const string& name, const string& location) {
    for (auto& shop : shops) {
        if (shop.id == id) {
            shop.name = name;
            shop.location = location;
            return true;
        }
    }
    return false;
}

void searchCustomer(int id) {
    for (const auto& customer : customers) {
        if (customer.id == id) {
            cout << "ID: " << customer.id << ", Name: " << customer.name
                 << ", Address: " << customer.address << endl;
            return;
        }
    }
    cout << "Customer not found." << endl;
}

void searchShop(int id) {
    for (const auto& shop : shops) {
        if (shop.id == id) {
            cout << "ID: " << shop.id << ", Name: " << shop.name
                 << ", Location: " << shop.location << endl;
            return;
        }
    }
    cout << "Shop not found." << endl;
}

int main() {
    addCustomer("Alice", "123 Street A");
    addCustomer("Bob", "456 Street B");
    addShop("Shop1", "Market Street");
    addShop("Shop2", "Mall Road");
    displayCustomers();
    displayShops();
    updateCustomer(1, "Alice Updated", "987 Street X");
    updateShop(1, "Shop1 Updated", "New Market Street");
    searchCustomer(1);
    searchShop(1);
    deleteCustomer(2);
    deleteShop(2);
    displayCustomers();
    displayShops();
    return 0;
}