#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    string address;
    string phone;
};

struct Customer : public Person {
    string customerID;
};

struct Shop : public Person {
    string shopID;
};

class DeliverySystem {
    vector<Customer> customers;
    vector<Shop> shops;

    template<typename T>
    void displayInfo(const T& entity) const {
        cout << "Name: " << entity.name << ", Address: " << entity.address << ", Phone: " << entity.phone;
    }

    public:
        void addCustomer(const string& id, const string& name, const string& address, const string& phone) {
            customers.push_back({id, name, address, phone});
        }

        void deleteCustomer(const string& id) {
            for(auto it = customers.begin(); it != customers.end(); ++it) {
                if(it->customerID == id) {
                    customers.erase(it);
                    break;
                }
            }
        }

        void updateCustomer(const string& id, const string& name, const string& address, const string& phone) {
            for(auto& customer : customers) {
                if(customer.customerID == id) {
                    customer.name = name;
                    customer.address = address;
                    customer.phone = phone;
                }
            }
        }

        Customer* searchCustomer(const string& id) {
            for(auto& customer : customers) {
                if(customer.customerID == id) {
                    return &customer;
                }
            }
            return nullptr;
        }

        void displayCustomers() const {
            for(const auto& customer : customers) {
                displayInfo(customer);
                cout << ", Customer ID: " << customer.customerID << endl;
            }
        }

        void addShop(const string& id, const string& name, const string& address, const string& phone) {
            shops.push_back({id, name, address, phone});
        }

        void deleteShop(const string& id) {
            for(auto it = shops.begin(); it != shops.end(); ++it) {
                if(it->shopID == id) {
                    shops.erase(it);
                    break;
                }
            }
        }

        void updateShop(const string& id, const string& name, const string& address, const string& phone) {
            for(auto& shop : shops) {
                if(shop.shopID == id) {
                    shop.name = name;
                    shop.address = address;
                    shop.phone = phone;
                }
            }
        }

        Shop* searchShop(const string& id) {
            for(auto& shop : shops) {
                if(shop.shopID == id) {
                    return &shop;
                }
            }
            return nullptr;
        }

        void displayShops() const {
            for(const auto& shop : shops) {
                displayInfo(shop);
                cout << ", Shop ID: " << shop.shopID << endl;
            }
        }
};

int main() {
    DeliverySystem system;
    system.addCustomer("C001", "John Doe", "123 Elm St", "555-1234");
    system.addShop("S001", "Drink Shop", "456 Oak St", "555-5678");

    cout << "Customers:" << endl;
    system.displayCustomers();

    cout << "Shops:" << endl;
    system.displayShops();

    return 0;
}