#include <iostream>
#include <string>
#include <vector>

struct Customer {
    int id;
    std::string name;
    std::string address;
};

struct Shop {
    int id;
    std::string name;
    std::string location;
};

std::vector<Customer> customers;
std::vector<Shop> shops;

void addCustomer(int id, const std::string& name, const std::string& address) {
    customers.push_back({id, name, address});
}

void deleteCustomer(int id) {
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            break;
        }
    }
}

void updateCustomer(int id, const std::string& name, const std::string& address) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            customer.name = name;
            customer.address = address;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            return &customer;
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (const auto& customer : customers) {
        std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << std::endl;
    }
}

void addShop(int id, const std::string& name, const std::string& location) {
    shops.push_back({id, name, location});
}

void deleteShop(int id) {
    for (auto it = shops.begin(); it != shops.end(); ++it) {
        if (it->id == id) {
            shops.erase(it);
            break;
        }
    }
}

void updateShop(int id, const std::string& name, const std::string& location) {
    for (auto& shop : shops) {
        if (shop.id == id) {
            shop.name = name;
            shop.location = location;
            break;
        }
    }
}

Shop* searchShop(int id) {
    for (auto& shop : shops) {
        if (shop.id == id) {
            return &shop;
        }
    }
    return nullptr;
}

void displayShops() {
    for (const auto& shop : shops) {
        std::cout << "ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << std::endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "123 Elm St");
    addCustomer(2, "Jane Smith", "456 Oak St");
    addShop(1, "Corner Market", "Downtown");
    addShop(2, "Beverage Barn", "Uptown");

    displayCustomers();
    displayShops();

    updateCustomer(1, "Johnathan Doe", "123 Elm St, Apt 4");
    updateShop(1, "Corner Market & Cafe", "Downtown");

    displayCustomers();
    displayShops();

    deleteCustomer(2);
    deleteShop(2);

    displayCustomers();
    displayShops();

    return 0;
}