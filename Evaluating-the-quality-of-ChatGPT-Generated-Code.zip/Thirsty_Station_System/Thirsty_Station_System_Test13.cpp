#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

class DeliveryService {
    vector<Customer> customers;
    vector<Shop> shops;
    
    int generateCustomerId() {
        return customers.empty() ? 1 : customers.back().id + 1;
    }
    
    int generateShopId() {
        return shops.empty() ? 1 : shops.back().id + 1;
    }

public:
    void addCustomer(string name, string address) {
        customers.push_back({generateCustomerId(), name, address});
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string address) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << endl;
        }
    }

    void addShop(string name, string location) {
        shops.push_back({generateShopId(), name, location});
    }
    
    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, string name, string location) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                break;
            }
        }
    }

    Shop* searchShop(int id) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayShops() {
        for (const auto& shop : shops) {
            cout << "Shop ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << endl;
        }
    }
};

int main() {
    DeliveryService ds;
    ds.addCustomer("Alice", "123 Maple St");
    ds.addCustomer("Bob", "456 Oak St");
    ds.displayCustomers();

    ds.addShop("Cool Drinks", "Downtown");
    ds.addShop("Juice Bar", "Uptown");
    ds.displayShops();

    ds.updateCustomer(1, "Alice Johnson", "789 Willow St");
    ds.displayCustomers();

    ds.deleteShop(1);
    ds.displayShops();

    return 0;
}