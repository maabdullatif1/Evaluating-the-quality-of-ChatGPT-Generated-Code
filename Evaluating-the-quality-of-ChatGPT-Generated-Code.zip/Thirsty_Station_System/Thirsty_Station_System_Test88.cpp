#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string address;
    string phone;
};

struct Shop {
    int id;
    string name;
    string address;
    string phone;
};

class DeliveryService {
    Customer customers[100];
    Shop shops[100];
    int customerCount = 0;
    int shopCount = 0;

public:
    void addCustomer(int id, string name, string address, string phone) {
        customers[customerCount++] = {id, name, address, phone};
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                for (int j = i; j < customerCount - 1; ++j) {
                    customers[j] = customers[j + 1];
                }
                --customerCount;
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string address, string phone) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i] = {id, name, address, phone};
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                return &customers[i];
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; ++i) {
            cout << "Customer ID: " << customers[i].id << "\nName: "
                 << customers[i].name << "\nAddress: " << customers[i].address
                 << "\nPhone: " << customers[i].phone << "\n\n";
        }
    }

    void addShop(int id, string name, string address, string phone) {
        shops[shopCount++] = {id, name, address, phone};
    }

    void deleteShop(int id) {
        for (int i = 0; i < shopCount; ++i) {
            if (shops[i].id == id) {
                for (int j = i; j < shopCount - 1; ++j) {
                    shops[j] = shops[j + 1];
                }
                --shopCount;
                break;
            }
        }
    }

    void updateShop(int id, string name, string address, string phone) {
        for (int i = 0; i < shopCount; ++i) {
            if (shops[i].id == id) {
                shops[i] = {id, name, address, phone};
                break;
            }
        }
    }

    Shop* searchShop(int id) {
        for (int i = 0; i < shopCount; ++i) {
            if (shops[i].id == id) {
                return &shops[i];
            }
        }
        return nullptr;
    }

    void displayShops() {
        for (int i = 0; i < shopCount; ++i) {
            cout << "Shop ID: " << shops[i].id << "\nName: " << shops[i].name
                 << "\nAddress: " << shops[i].address << "\nPhone: "
                 << shops[i].phone << "\n\n";
        }
    }
};

int main() {
    DeliveryService service;
    service.addCustomer(1, "Alice", "123 Main St", "555-1234");
    service.addCustomer(2, "Bob", "456 Oak St", "555-5678");
    service.updateCustomer(1, "Alice", "123 Main St", "555-0000");
    service.displayCustomers();
    Customer* customer = service.searchCustomer(1);
    if (customer) {
        cout << "Found Customer: " << customer->name << "\n";
    }
    service.deleteCustomer(1);
    service.displayCustomers();

    service.addShop(1, "Shop A", "789 Pine St", "555-2468");
    service.addShop(2, "Shop B", "321 Elm St", "555-1357");
    service.updateShop(2, "Shop B", "322 Elm St", "555-9999");
    service.displayShops();
    Shop* shop = service.searchShop(1);
    if (shop) {
        cout << "Found Shop: " << shop->name << "\n";
    }
    service.deleteShop(1);
    service.displayShops();
    
    return 0;
}