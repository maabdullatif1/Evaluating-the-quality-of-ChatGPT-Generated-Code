#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string address;
    
    Customer(int id, std::string name, std::string address) : id(id), name(name), address(address) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;
    
    Shop(int id, std::string name, std::string location) : id(id), name(name), location(location) {}
};

class System {
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(int id, std::string name, std::string address) {
        customers.push_back(Customer(id, name, address));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string address) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                return;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) return &customer;
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name 
                      << ", Address: " << customer.address << std::endl;
        }
    }

    void addShop(int id, std::string name, std::string location) {
        shops.push_back(Shop(id, name, location));
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                return;
            }
        }
    }

    void updateShop(int id, std::string name, std::string location) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                return;
            }
        }
    }

    Shop* searchShop(int id) {
        for (auto& shop : shops) {
            if (shop.id == id) return &shop;
        }
        return nullptr;
    }

    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "ID: " << shop.id << ", Name: " << shop.name 
                      << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    System system;

    system.addCustomer(1, "John Doe", "123 Elm St");
    system.addCustomer(2, "Jane Smith", "456 Oak St");

    system.addShop(1, "Beverage Barn", "789 Pine St");
    system.addShop(2, "Drink Depot", "101 Maple St");

    system.displayCustomers();
    system.displayShops();

    system.updateCustomer(1, "John Doe", "321 Elm St");
    system.updateShop(2, "Drink Hub", "102 Maple St");

    system.displayCustomers();
    system.displayShops();

    Customer* customer = system.searchCustomer(1);
    if (customer) {
        std::cout << "Found Customer: " << customer->name << std::endl;
    }

    Shop* shop = system.searchShop(1);
    if (shop) {
        std::cout << "Found Shop: " << shop->name << std::endl;
    }

    system.deleteCustomer(2);
    system.deleteShop(1);

    system.displayCustomers();
    system.displayShops();

    return 0;
}