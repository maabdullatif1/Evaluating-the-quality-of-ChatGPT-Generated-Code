#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

class DeliverySystem {
    vector<Customer> customers;
    vector<Shop> shops;
    
    Customer* findCustomerById(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) return &customer;
        }
        return nullptr;
    }

    Shop* findShopById(int id) {
        for (auto& shop : shops) {
            if (shop.id == id) return &shop;
        }
        return nullptr;
    }

public:
    void addCustomer(int id, const string& name, const string& address) {
        if (!findCustomerById(id)) {
            customers.push_back({ id, name, address });
        }
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, const string& name, const string& address) {
        Customer* customer = findCustomerById(id);
        if (customer) {
            customer->name = name;
            customer->address = address;
        }
    }
    
    void searchCustomer(int id) {
        Customer* customer = findCustomerById(id);
        if (customer) {
            cout << "Customer ID: " << customer->id << ", Name: " << customer->name << ", Address: " << customer->address << endl;
        }
    }
    
    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << endl;
        }
    }
    
    void addShop(int id, const string& name, const string& location) {
        if (!findShopById(id)) {
            shops.push_back({ id, name, location });
        }
    }
    
    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }
    
    void updateShop(int id, const string& name, const string& location) {
        Shop* shop = findShopById(id);
        if (shop) {
            shop->name = name;
            shop->location = location;
        }
    }
    
    void searchShop(int id) {
        Shop* shop = findShopById(id);
        if (shop) {
            cout << "Shop ID: " << shop->id << ", Name: " << shop->name << ", Location: " << shop->location << endl;
        }
    }
    
    void displayShops() {
        for (const auto& shop : shops) {
            cout << "Shop ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << endl;
        }
    }
};

int main() {
    DeliverySystem system;
    
    system.addCustomer(1, "Alice", "123 Main St");
    system.addCustomer(2, "Bob", "456 Elm St");
    system.displayCustomers();
    
    system.addShop(1, "Drink Hub", "9th Ave");
    system.addShop(2, "Liquid Store", "Maple St");
    system.displayShops();
    
    system.updateCustomer(1, "Alice Williams", "123 Main St, Apt 4");
    system.searchCustomer(1);
    
    system.deleteCustomer(2);
    system.displayCustomers();
    
    system.updateShop(1, "Drink Hub Plus", "9th Ave and Elm");
    system.searchShop(1);
    
    system.deleteShop(2);
    system.displayShops();
    
    return 0;
}