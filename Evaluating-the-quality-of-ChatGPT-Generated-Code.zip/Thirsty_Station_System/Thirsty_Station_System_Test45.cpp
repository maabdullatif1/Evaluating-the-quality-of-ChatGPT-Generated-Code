#include <iostream>
#include <string>
#include <vector>

using namespace std;

class User {
public:
    string name;
    string address;
    string phone;

    User(string n, string a, string p) : name(n), address(a), phone(p) {}
};

class Customer : public User {
public:
    Customer(string n, string a, string p) : User(n, a, p) {}
};

class Shop : public User {
public:
    Shop(string n, string a, string p) : User(n, a, p) {}
};

class DeliveryServiceSystem {
private:
    vector<Customer> customers;
    vector<Shop> shops;

    template<typename T>
    void displayUser(const vector<T>& users) {
        for (size_t i = 0; i < users.size(); ++i) {
            cout << i + 1 << ". Name: " << users[i].name
                 << ", Address: " << users[i].address
                 << ", Phone: " << users[i].phone << endl;
        }
    }

public:
    void addCustomer(const Customer& customer) {
        customers.push_back(customer);
    }

    void addShop(const Shop& shop) {
        shops.push_back(shop);
    }

    void deleteCustomerByName(const string& name) {
        customers.erase(remove_if(customers.begin(), customers.end(), [&](Customer c) { return c.name == name; }), customers.end());
    }

    void deleteShopByName(const string& name) {
        shops.erase(remove_if(shops.begin(), shops.end(), [&](Shop s) { return s.name == name; }), shops.end());
    }

    void updateCustomer(const string& name, const Customer& updatedCustomer) {
        for (auto& c : customers) {
            if (c.name == name) {
                c = updatedCustomer;
                break;
            }
        }
    }

    void updateShop(const string& name, const Shop& updatedShop) {
        for (auto& s : shops) {
            if (s.name == name) {
                s = updatedShop;
                break;
            }
        }
    }

    Customer* searchCustomerByName(const string& name) {
        for (auto& c : customers) {
            if (c.name == name) {
                return &c;
            }
        }
        return nullptr;
    }

    Shop* searchShopByName(const string& name) {
        for (auto& s : shops) {
            if (s.name == name) {
                return &s;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        displayUser(customers);
    }

    void displayShops() {
        displayUser(shops);
    }
};

int main() {
    DeliveryServiceSystem system;

    system.addCustomer(Customer("John Doe", "123 Elm St", "555-1234"));
    system.addShop(Shop("Joe's Drinks", "99 Main St", "555-5678"));

    system.displayCustomers();
    system.displayShops();

    system.updateCustomer("John Doe", Customer("Johnny Doe", "123 Elm St", "555-4321"));
    system.displayCustomers();

    system.deleteShopByName("Joe's Drinks");
    system.displayShops();

    return 0;
}