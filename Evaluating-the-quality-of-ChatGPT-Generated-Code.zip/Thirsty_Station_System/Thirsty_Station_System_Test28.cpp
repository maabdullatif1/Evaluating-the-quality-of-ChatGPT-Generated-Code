#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    std::string name;
    std::string address;
    std::string phone;

    Customer(const std::string& name, const std::string& address, const std::string& phone)
        : name(name), address(address), phone(phone) {}
};

class Shop {
public:
    std::string name;
    std::string location;

    Shop(const std::string& name, const std::string& location)
        : name(name), location(location) {}
};

class DrinksDeliveryService {
    std::vector<Customer> customers;
    std::vector<Shop> shops;

    template <typename T>
    void displayList(const std::vector<T>& list) const {
        for (const auto& item : list) {
            std::cout << item.name << " | " << (std::is_same<T, Customer>::value ? item.address + " | " + item.phone : item.location) << std::endl;
        }
    }

public:
    void addCustomer(const std::string& name, const std::string& address, const std::string& phone) {
        customers.emplace_back(name, address, phone);
    }

    void deleteCustomer(const std::string& name) {
        customers.erase(std::remove_if(customers.begin(), customers.end(),
                         [&name](const Customer& c) { return c.name == name; }),
                         customers.end());
    }

    void updateCustomer(const std::string& name, const std::string& newAddress, const std::string& newPhone) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                customer.address = newAddress;
                customer.phone = newPhone;
            }
        }
    }

    void searchCustomer(const std::string& name) const {
        for (const auto& customer : customers) {
            if (customer.name == name) {
                std::cout << customer.name << " | " << customer.address << " | " << customer.phone << std::endl;
            }
        }
    }

    void displayCustomers() const {
        displayList(customers);
    }

    void addShop(const std::string& name, const std::string& location) {
        shops.emplace_back(name, location);
    }

    void deleteShop(const std::string& name) {
        shops.erase(std::remove_if(shops.begin(), shops.end(),
                      [&name](const Shop& s) { return s.name == name; }),
                      shops.end());
    }

    void updateShop(const std::string& name, const std::string& newLocation) {
        for (auto& shop : shops) {
            if (shop.name == name) {
                shop.location = newLocation;
            }
        }
    }

    void searchShop(const std::string& name) const {
        for (const auto& shop : shops) {
            if (shop.name == name) {
                std::cout << shop.name << " | " << shop.location << std::endl;
            }
        }
    }

    void displayShops() const {
        displayList(shops);
    }
};

int main() {
    DrinksDeliveryService service;

    service.addCustomer("John Doe", "123 Elm St", "555-1234");
    service.addCustomer("Jane Smith", "456 Maple Ave", "555-5678");
    service.displayCustomers();

    service.addShop("Beverage Barn", "789 Oak Blvd");
    service.addShop("Drink Depot", "101 Pine Pl");
    service.displayShops();

    service.updateCustomer("John Doe", "321 Elm St", "555-4321");
    service.searchCustomer("John Doe");

    service.updateShop("Beverage Barn", "900 Oak Blvd");
    service.searchShop("Beverage Barn");

    service.deleteCustomer("Jane Smith");
    service.displayCustomers();

    service.deleteShop("Drink Depot");
    service.displayShops();

    return 0;
}