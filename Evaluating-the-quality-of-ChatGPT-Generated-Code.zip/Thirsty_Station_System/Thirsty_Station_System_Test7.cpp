#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

struct Customer customers[100];
struct Shop shops[100];
int customerCount = 0;
int shopCount = 0;

void addCustomer(int id, string name, string address) {
    customers[customerCount++] = {id, name, address};
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; j++) {
                customers[j] = customers[j + 1];
            }
            customerCount--;
            break;
        }
    }
}

void updateCustomer(int id, string name, string address) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            customers[i].name = name;
            customers[i].address = address;
            break;
        }
    }
}

void searchCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            cout << "Customer found: " << customers[i].name << ", " << customers[i].address << endl;
            return;
        }
    }
    cout << "Customer not found\n";
}

void displayCustomers() {
    for (int i = 0; i < customerCount; i++) {
        cout << "ID: " << customers[i].id << ", Name: " << customers[i].name 
             << ", Address: " << customers[i].address << endl;
    }
}

void addShop(int id, string name, string location) {
    shops[shopCount++] = {id, name, location};
}

void deleteShop(int id) {
    for (int i = 0; i < shopCount; i++) {
        if (shops[i].id == id) {
            for (int j = i; j < shopCount - 1; j++) {
                shops[j] = shops[j + 1];
            }
            shopCount--;
            break;
        }
    }
}

void updateShop(int id, string name, string location) {
    for (int i = 0; i < shopCount; i++) {
        if (shops[i].id == id) {
            shops[i].name = name;
            shops[i].location = location;
            break;
        }
    }
}

void searchShop(int id) {
    for (int i = 0; i < shopCount; i++) {
        if (shops[i].id == id) {
            cout << "Shop found: " << shops[i].name << ", " << shops[i].location << endl;
            return;
        }
    }
    cout << "Shop not found\n";
}

void displayShops() {
    for (int i = 0; i < shopCount; i++) {
        cout << "ID: " << shops[i].id << ", Name: " << shops[i].name 
             << ", Location: " << shops[i].location << endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "123 Elm St");
    addCustomer(2, "Jane Smith", "456 Oak St");

    addShop(1, "Drinkers Paradise", "789 Maple Ave");
    addShop(2, "Liquid Essentials", "101 Pine Lane");

    displayCustomers();
    displayShops();

    searchCustomer(1);
    searchShop(2);

    updateCustomer(1, "Johnathan Doe", "321 Elm St");
    updateShop(1, "Drink Haven", "890 Maple Ave");

    deleteCustomer(2);
    deleteShop(2);

    displayCustomers();
    displayShops();

    return 0;
}