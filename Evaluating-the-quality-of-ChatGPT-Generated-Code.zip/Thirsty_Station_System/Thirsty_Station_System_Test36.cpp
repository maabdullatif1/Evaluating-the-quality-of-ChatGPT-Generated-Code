#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string address;

    Customer(int id, std::string name, std::string address) 
        : id(id), name(name), address(address) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;

    Shop(int id, std::string name, std::string location) 
        : id(id), name(name), location(location) {}
};

class ServiceSystem {
private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(int id, std::string name, std::string address) {
        customers.push_back(Customer(id, name, address));
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string address) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) return &customer;
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "Customer ID: " << customer.id 
                      << ", Name: " << customer.name 
                      << ", Address: " << customer.address << std::endl;
        }
    }
    
    void addShop(int id, std::string name, std::string location) {
        shops.push_back(Shop(id, name, location));
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, std::string name, std::string location) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                break;
            }
        }
    }

    Shop* searchShop(int id) {
        for (auto &shop : shops) {
            if (shop.id == id) return &shop;
        }
        return nullptr;
    }

    void displayShops() {
        for (const auto &shop : shops) {
            std::cout << "Shop ID: " << shop.id 
                      << ", Name: " << shop.name 
                      << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    ServiceSystem system;
    system.addCustomer(1, "Alice", "123 Apple St.");
    system.addCustomer(2, "Bob", "456 Banana Ave.");
    system.addShop(10, "Drink Hub", "789 Cherry Blvd.");
    system.addShop(11, "Beverage Stop", "101 Grape Rd.");
    
    system.displayCustomers();
    system.displayShops();
    
    system.updateCustomer(1, "Alice A.", "321 New Apple St.");
    Customer* customer = system.searchCustomer(1);
    if (customer) {
        std::cout << "Updated Customer: " << customer->name << ", " << customer->address << std::endl;
    }
    
    system.deleteShop(10);
    system.displayShops();
    
    return 0;
}