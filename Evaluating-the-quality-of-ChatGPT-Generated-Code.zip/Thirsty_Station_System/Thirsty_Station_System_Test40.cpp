#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string address;
};

struct Shop {
    int id;
    std::string name;
    std::string location;
};

class DeliveryService {
    std::vector<Customer> customers;
    std::vector<Shop> shops;
    int customerIdCounter = 1;
    int shopIdCounter = 1;
    
    Customer* findCustomerById(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Shop* findShopById(int id) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

public:
    void addCustomer(const std::string& name, const std::string& address) {
        customers.push_back({ customerIdCounter++, name, address });
    }

    void deleteCustomer(int id) {
        customers.erase(std::remove_if(customers.begin(), customers.end(),
            [id](const Customer& c) { return c.id == id; }), customers.end());
    }

    void updateCustomer(int id, const std::string& name, const std::string& address) {
        Customer* customer = findCustomerById(id);
        if (customer) {
            customer->name = name;
            customer->address = address;
        }
    }

    Customer* searchCustomer(int id) {
        return findCustomerById(id);
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name
                      << ", Address: " << customer.address << std::endl;
        }
    }

    void addShop(const std::string& name, const std::string& location) {
        shops.push_back({ shopIdCounter++, name, location });
    }

    void deleteShop(int id) {
        shops.erase(std::remove_if(shops.begin(), shops.end(),
            [id](const Shop& s) { return s.id == id; }), shops.end());
    }

    void updateShop(int id, const std::string& name, const std::string& location) {
        Shop* shop = findShopById(id);
        if (shop) {
            shop->name = name;
            shop->location = location;
        }
    }

    Shop* searchShop(int id) {
        return findShopById(id);
    }

    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "Shop ID: " << shop.id << ", Name: " << shop.name
                      << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    DeliveryService service;
    service.addCustomer("Alice", "123 Main St");
    service.addCustomer("Bob", "456 Park Ave");
    service.addShop("CoffeeShop", "Downtown");
    service.addShop("TeaHouse", "Cherry Lane");
    service.displayCustomers();
    service.displayShops();
    service.updateCustomer(1, "Alice Johnson", "123 Main St, Apt 1");
    service.updateShop(1, "Central Coffee", "Downtown Central");
    Customer* customer = service.searchCustomer(1);
    if (customer) std::cout << "Found Customer: " << customer->name << std::endl;
    Shop* shop = service.searchShop(1);
    if (shop) std::cout << "Found Shop: " << shop->name << std::endl;
    service.deleteCustomer(2);
    service.deleteShop(2);
    service.displayCustomers();
    service.displayShops();
    return 0;
}