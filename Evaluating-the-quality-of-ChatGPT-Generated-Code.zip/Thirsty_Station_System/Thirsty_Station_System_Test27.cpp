#include <iostream>
#include <vector>
#include <string>

class Customer {
    std::string name;
    std::string address;
    std::string phone;
public:
    Customer(std::string n, std::string a, std::string p) : name(n), address(a), phone(p) {}
    
    std::string getName() const { return name; }
    std::string getAddress() const { return address; }
    std::string getPhone() const { return phone; }
    
    void setName(std::string n) { name = n; }
    void setAddress(std::string a) { address = a; }
    void setPhone(std::string p) { phone = p; }
};

class Shop {
    std::string name;
    std::string location;
    std::string contact;
public:
    Shop(std::string n, std::string l, std::string c) : name(n), location(l), contact(c) {}
    
    std::string getName() const { return name; }
    std::string getLocation() const { return location; }
    std::string getContact() const { return contact; }
    
    void setName(std::string n) { name = n; }
    void setLocation(std::string l) { location = l; }
    void setContact(std::string c) { contact = c; }
};

class DeliverySystem {
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(const Customer& customer) {
        customers.push_back(customer);
    }
    
    void deleteCustomer(const std::string& name) {
        customers.erase(std::remove_if(customers.begin(), customers.end(), [&](Customer& c) {
            return c.getName() == name;
        }), customers.end());
    }

    void updateCustomer(const std::string& name, const Customer& updatedCustomer) {
        for (auto& customer : customers) {
            if (customer.getName() == name) {
                customer = updatedCustomer;
                break;
            }
        }
    }

    Customer* searchCustomer(const std::string& name) {
        for (auto& customer : customers) {
            if (customer.getName() == name) {
                return &customer;
            }
        }
        return nullptr;
    }
    
    void addShop(const Shop& shop) {
        shops.push_back(shop);
    }
    
    void deleteShop(const std::string& name) {
        shops.erase(std::remove_if(shops.begin(), shops.end(), [&](Shop& s) {
            return s.getName() == name;
        }), shops.end());
    }

    void updateShop(const std::string& name, const Shop& updatedShop) {
        for (auto& shop : shops) {
            if (shop.getName() == name) {
                shop = updatedShop;
                break;
            }
        }
    }

    Shop* searchShop(const std::string& name) {
        for (auto& shop : shops) {
            if (shop.getName() == name) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer Name: " << customer.getName() << ", "
                      << "Address: " << customer.getAddress() << ", "
                      << "Phone: " << customer.getPhone() << std::endl;
        }
    }

    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "Shop Name: " << shop.getName() << ", "
                      << "Location: " << shop.getLocation() << ", "
                      << "Contact: " << shop.getContact() << std::endl;
        }
    }
};

int main() {
    DeliverySystem system;
    system.addCustomer(Customer("John Doe", "123 Elm St", "555-1234"));
    system.addShop(Shop("DrinkHub", "456 Oak Ave", "555-5678"));

    system.displayCustomers();
    system.displayShops();

    return 0;
}