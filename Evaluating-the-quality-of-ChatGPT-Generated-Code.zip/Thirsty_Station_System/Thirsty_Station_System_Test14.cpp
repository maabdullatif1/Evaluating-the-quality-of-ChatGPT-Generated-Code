#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    std::string name;
    std::string address;
    std::string phone;

    Customer(std::string n, std::string a, std::string p) : name(n), address(a), phone(p) {}
};

class Shop {
public:
    std::string name;
    std::string location;
    std::string contact;

    Shop(std::string n, std::string l, std::string c) : name(n), location(l), contact(c) {}
};

class DeliveryService {
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(const std::string& name, const std::string& address, const std::string& phone) {
        customers.push_back(Customer(name, address, phone));
    }

    void deleteCustomer(const std::string& name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(const std::string& name, const std::string& newAddress, const std::string& newPhone) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                customer.address = newAddress;
                customer.phone = newPhone;
                break;
            }
        }
    }

    void searchCustomer(const std::string& name) {
        for (const auto& customer : customers) {
            if (customer.name == name) {
                std::cout << "Customer Found: " << customer.name << ", Address: " << customer.address << ", Phone: " << customer.phone << "\n";
                return;
            }
        }
        std::cout << "Customer Not Found\n";
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Name: " << customer.name << ", Address: " << customer.address << ", Phone: " << customer.phone << "\n";
        }
    }

    void addShop(const std::string& name, const std::string& location, const std::string& contact) {
        shops.push_back(Shop(name, location, contact));
    }

    void deleteShop(const std::string& name) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->name == name) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(const std::string& name, const std::string& newLocation, const std::string& newContact) {
        for (auto& shop : shops) {
            if (shop.name == name) {
                shop.location = newLocation;
                shop.contact = newContact;
                break;
            }
        }
    }

    void searchShop(const std::string& name) {
        for (const auto& shop : shops) {
            if (shop.name == name) {
                std::cout << "Shop Found: " << shop.name << ", Location: " << shop.location << ", Contact: " << shop.contact << "\n";
                return;
            }
        }
        std::cout << "Shop Not Found\n";
    }

    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "Name: " << shop.name << ", Location: " << shop.location << ", Contact: " << shop.contact << "\n";
        }
    }
};

int main() {
    DeliveryService service;
    service.addCustomer("John Doe", "1234 Elm St", "555-1234");
    service.addShop("Drink Delight", "10 Market St", "555-5678");
    service.displayCustomers();
    service.displayShops();
    service.searchCustomer("John Doe");
    service.searchShop("Drink Delight");
    service.updateCustomer("John Doe", "5678 Maple St", "555-8765");
    service.updateShop("Drink Delight", "20 Commerce St", "555-5679");
    service.displayCustomers();
    service.displayShops();
    service.deleteCustomer("John Doe");
    service.deleteShop("Drink Delight");
    service.displayCustomers();
    service.displayShops();
    return 0;
}