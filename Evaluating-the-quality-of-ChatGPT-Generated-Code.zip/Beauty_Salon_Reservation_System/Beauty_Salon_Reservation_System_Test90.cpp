#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct Hairstylist {
    int id;
    string name;
    string specialization;
};

class Salon {
private:
    vector<Customer> customers;
    vector<Hairstylist> hairstylists;
    int customerCounter;
    int stylistCounter;

public:
    Salon() : customerCounter(0), stylistCounter(0) {}

    void addCustomer(const string &name, const string &phone) {
        Customer customer = {++customerCounter, name, phone};
        customers.push_back(customer);
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const string &name, const string &phone) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phone = phone;
                break;
            }
        }
    }

    Customer searchCustomer(int id) {
        for (const auto &customer : customers) {
            if (customer.id == id) {
                return customer;
            }
        }
        return {0, "", ""};
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "Customer ID: " << customer.id 
                 << ", Name: " << customer.name 
                 << ", Phone: " << customer.phone << endl;
        }
    }

    void addHairstylist(const string &name, const string &specialization) {
        Hairstylist stylist = {++stylistCounter, name, specialization};
        hairstylists.push_back(stylist);
    }

    void deleteHairstylist(int id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->id == id) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateHairstylist(int id, const string &name, const string &specialization) {
        for (auto &stylist : hairstylists) {
            if (stylist.id == id) {
                stylist.name = name;
                stylist.specialization = specialization;
                break;
            }
        }
    }

    Hairstylist searchHairstylist(int id) {
        for (const auto &stylist : hairstylists) {
            if (stylist.id == id) {
                return stylist;
            }
        }
        return {0, "", ""};
    }

    void displayHairstylists() {
        for (const auto &stylist : hairstylists) {
            cout << "Hairstylist ID: " << stylist.id 
                 << ", Name: " << stylist.name 
                 << ", Specialization: " << stylist.specialization << endl;
        }
    }
};

int main() {
    Salon salon;

    salon.addCustomer("Alice", "1234567890");
    salon.addCustomer("Bob", "0987654321");
    salon.displayCustomers();

    salon.addHairstylist("Charlie", "cut");
    salon.addHairstylist("David", "color");
    salon.displayHairstylists();

    return 0;
}