#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    std::string contact;
    Person(const std::string &n, const std::string &c) : name(n), contact(c) {}
};

class Customer : public Person {
public:
    Customer(const std::string &n, const std::string &c) : Person(n, c) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(const std::string &n, const std::string &c) : Person(n, c) {}
};

template<typename T>
class ManagementSystem {
private:
    std::vector<T> records;
public:
    void add(const T &record) {
        records.push_back(record);
    }

    void remove(const std::string &name) {
        for (size_t i = 0; i < records.size(); ++i) {
            if (records[i].name == name) {
                records.erase(records.begin() + i);
                break;
            }
        }
    }

    void update(const std::string &name, const std::string &newName, const std::string &newContact) {
        for (auto &record : records) {
            if (record.name == name) {
                record.name = newName;
                record.contact = newContact;
                break;
            }
        }
    }

    T* search(const std::string &name) {
        for (auto &record : records) {
            if (record.name == name) {
                return &record;
            }
        }
        return nullptr;
    }
    
    void display() {
        for (const auto &record : records) {
            std::cout << "Name: " << record.name << ", Contact: " << record.contact << std::endl;
        }
    }
};

int main() {
    ManagementSystem<Customer> customerManagement;
    ManagementSystem<Hairstylist> hairstylistManagement;

    customerManagement.add(Customer("John Doe", "123-456-7890"));
    customerManagement.add(Customer("Jane Smith", "098-765-4321"));

    hairstylistManagement.add(Hairstylist("Stylist A", "555-555-5555"));
    hairstylistManagement.add(Hairstylist("Stylist B", "666-666-6666"));

    std::cout << "Customers:" << std::endl;
    customerManagement.display();

    std::cout << "Hairstylists:" << std::endl;
    hairstylistManagement.display();

    customerManagement.update("John Doe", "Johnathan Doe", "111-222-3333");
    hairstylistManagement.remove("Stylist B");

    std::cout << "\nUpdated Customers:" << std::endl;
    customerManagement.display();

    std::cout << "Updated Hairstylists:" << std::endl;
    hairstylistManagement.display();
    
    return 0;
}