#include <iostream>
#include <string>

class Person {
protected:
    std::string name;
    std::string phoneNumber;
public:
    Person(const std::string& n, const std::string& p) : name(n), phoneNumber(p) {}
    virtual std::string getInfo() const = 0;
};

class Customer : public Person {
public:
    Customer(const std::string& n, const std::string& p) : Person(n, p) {}
    std::string getInfo() const override {
        return "Customer: " + name + ", Phone: " + phoneNumber;
    }
};

class Hairstylist : public Person {
public:
    Hairstylist(const std::string& n, const std::string& p) : Person(n, p) {}
    std::string getInfo() const override {
        return "Hairstylist: " + name + ", Phone: " + phoneNumber;
    }
};

template<typename T>
class Manager {
private:
    T* data[100];
    int count;
public:
    Manager() : count(0) {}
    void add(const std::string& name, const std::string& phoneNumber) {
        data[count++] = new T(name, phoneNumber);
    }
    void remove(const std::string& name) {
        for (int i = 0; i < count; ++i) {
            if (data[i]->getInfo().find(name) != std::string::npos) {
                delete data[i];
                data[i] = data[--count];
                break;
            }
        }
    }
    void update(const std::string& oldName, const std::string& newName, const std::string& newPhoneNumber) {
        for (int i = 0; i < count; ++i) {
            if (data[i]->getInfo().find(oldName) != std::string::npos) {
                delete data[i];
                data[i] = new T(newName, newPhoneNumber);
                break;
            }
        }
    }
    std::string search(const std::string& name) const {
        for (int i = 0; i < count; ++i) {
            if (data[i]->getInfo().find(name) != std::string::npos) {
                return data[i]->getInfo();
            }
        }
        return "Not Found";
    }
    void display() const {
        for (int i = 0; i < count; ++i) {
            std::cout << data[i]->getInfo() << std::endl;
        }
    }
    ~Manager() {
        for (int i = 0; i < count; ++i) {
            delete data[i];
        }
    }
};

int main() {
    Manager<Customer> customerManager;
    Manager<Hairstylist> hairstylistManager;
    
    customerManager.add("Alice", "12345");
    customerManager.add("Bob", "67890");
    hairstylistManager.add("Charlie", "54321");
    hairstylistManager.add("Dave", "98765");
    
    std::cout << customerManager.search("Alice") << std::endl;
    std::cout << hairstylistManager.search("Charlie") << std::endl;
    
    customerManager.update("Alice", "Alice Smith", "11111");
    hairstylistManager.remove("Dave");
    
    customerManager.display();
    hairstylistManager.display();
    
    return 0;
}