#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string phone;
    
    Customer(int id, const std::string& name, const std::string& phone)
        : id(id), name(name), phone(phone) {}
};

class Hairstylist {
public:
    int id;
    std::string name;
    std::string specialization;
    
    Hairstylist(int id, const std::string& name, const std::string& specialization)
        : id(id), name(name), specialization(specialization) {}
};

class Salon {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

    Customer* findCustomerById(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) return &customer;
        }
        return nullptr;
    }

    Hairstylist* findHairstylistById(int id) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) return &hairstylist;
        }
        return nullptr;
    }

public:
    void addCustomer(int id, const std::string& name, const std::string& phone) {
        customers.push_back(Customer(id, name, phone));
    }

    bool deleteCustomer(int id) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) {
                customers.erase(customers.begin() + i);
                return true;
            }
        }
        return false;
    }

    bool updateCustomer(int id, const std::string& newName, const std::string& newPhone) {
        Customer* customer = findCustomerById(id);
        if (customer) {
            customer->name = newName;
            customer->phone = newPhone;
            return true;
        }
        return false;
    }

    Customer* searchCustomer(int id) {
        return findCustomerById(id);
    }

    void addHairstylist(int id, const std::string& name, const std::string& specialization) {
        hairstylists.push_back(Hairstylist(id, name, specialization));
    }

    bool deleteHairstylist(int id) {
        for (size_t i = 0; i < hairstylists.size(); ++i) {
            if (hairstylists[i].id == id) {
                hairstylists.erase(hairstylists.begin() + i);
                return true;
            }
        }
        return false;
    }

    bool updateHairstylist(int id, const std::string& newName, const std::string& newSpecialization) {
        Hairstylist* hairstylist = findHairstylistById(id);
        if (hairstylist) {
            hairstylist->name = newName;
            hairstylist->specialization = newSpecialization;
            return true;
        }
        return false;
    }

    Hairstylist* searchHairstylist(int id) {
        return findHairstylistById(id);
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name
                      << ", Phone: " << customer.phone << std::endl;
        }
    }

    void displayHairstylists() {
        for (const auto& hairstylist : hairstylists) {
            std::cout << "ID: " << hairstylist.id << ", Name: " << hairstylist.name
                      << ", Specialization: " << hairstylist.specialization << std::endl;
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer(1, "Alice", "123456789");
    salon.addCustomer(2, "Bob", "987654321");
    salon.updateCustomer(1, "Alicia", "1234567890");
    salon.displayCustomers();
    Customer* c = salon.searchCustomer(2);
    if (c) std::cout << "Found customer with ID 2: " << c->name << std::endl;
    salon.deleteCustomer(1);
    salon.addHairstylist(1, "Jake", "Cutting");
    salon.addHairstylist(2, "Mary", "Coloring");
    salon.updateHairstylist(1, "Jacob", "Styling");
    salon.displayHairstylists();
    Hairstylist* h = salon.searchHairstylist(2);
    if (h) std::cout << "Found hairstylist with ID 2: " << h->name << std::endl;
    salon.deleteHairstylist(2);
    return 0;
}