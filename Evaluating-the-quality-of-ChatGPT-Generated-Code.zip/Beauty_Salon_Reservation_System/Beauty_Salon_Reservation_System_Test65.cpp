#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    std::string phone;
public:
    Person(std::string n, std::string p) : name(n), phone(p) {}
    void update(std::string n, std::string p) {
        name = n;
        phone = p;
    }
    std::string getName() const {
        return name;
    }
    std::string getPhone() const {
        return phone;
    }
};

class Customer : public Person {
public:
    Customer(std::string n, std::string p) : Person(n, p) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(std::string n, std::string p) : Person(n, p) {}
};

class SalonSystem {
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

    template <typename T>
    void displayList(const std::vector<T>& list) {
        for (const auto& person : list) {
            std::cout << "Name: " << person.getName() << ", Phone: " << person.getPhone() << std::endl;
        }
    }

    template <typename T>
    int searchIndex(const std::vector<T>& list, const std::string& name) {
        for (size_t i = 0; i < list.size(); ++i) {
            if (list[i].getName() == name) {
                return i;
            }
        }
        return -1;
    }

    template <typename T>
    void deleteFromList(std::vector<T>& list, const std::string& name) {
        int index = searchIndex(list, name);
        if (index != -1) {
            list.erase(list.begin() + index);
        }
    }

    template <typename T>
    void updateList(std::vector<T>& list, const std::string& name, const std::string& newName, const std::string& newPhone) {
        int index = searchIndex(list, name);
        if (index != -1) {
            list[index].update(newName, newPhone);
        }
    }

    template <typename T>
    void searchList(const std::vector<T>& list, const std::string& name) {
        int index = searchIndex(list, name);
        if (index != -1) {
            std::cout << "Name: " << list[index].getName() << ", Phone: " << list[index].getPhone() << std::endl;
        }
    }

public:
    void addCustomer(const std::string& name, const std::string& phone) {
        customers.emplace_back(name, phone);
    }

    void addHairstylist(const std::string& name, const std::string& phone) {
        hairstylists.emplace_back(name, phone);
    }

    void deleteCustomer(const std::string& name) {
        deleteFromList(customers, name);
    }

    void deleteHairstylist(const std::string& name) {
        deleteFromList(hairstylists, name);
    }

    void updateCustomer(const std::string& name, const std::string& newName, const std::string& newPhone) {
        updateList(customers, name, newName, newPhone);
    }

    void updateHairstylist(const std::string& name, const std::string& newName, const std::string& newPhone) {
        updateList(hairstylists, name, newName, newPhone);
    }

    void searchCustomer(const std::string& name) {
        searchList(customers, name);
    }

    void searchHairstylist(const std::string& name) {
        searchList(hairstylists, name);
    }

    void displayCustomers() {
        displayList(customers);
    }

    void displayHairstylists() {
        displayList(hairstylists);
    }
};

int main() {
    SalonSystem salon;
    salon.addCustomer("Alice", "123-456-7890");
    salon.addHairstylist("Bob", "098-765-4321");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.updateCustomer("Alice", "Allie", "111-222-3333");
    salon.searchCustomer("Allie");
    salon.deleteHairstylist("Bob");
    salon.displayHairstylists();
    return 0;
}