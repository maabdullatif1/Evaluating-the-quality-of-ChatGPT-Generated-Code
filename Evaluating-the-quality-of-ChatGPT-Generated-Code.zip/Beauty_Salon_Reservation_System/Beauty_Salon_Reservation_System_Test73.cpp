#include <iostream>
#include <string>
#include <vector>

class Person {
protected:
    std::string name;
    std::string contact;
public:
    Person(std::string n, std::string c) : name(n), contact(c) {}
    std::string getName() { return name; }
    std::string getContact() { return contact; }
    void setName(std::string n) { name = n; }
    void setContact(std::string c) { contact = c; }
};

class Customer : public Person {
public:
    Customer(std::string n, std::string c) : Person(n, c) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(std::string n, std::string c) : Person(n, c) {}
};

class BeautySalon {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;
public:
    void addCustomer(std::string name, std::string contact) {
        customers.push_back(Customer(name, contact));
    }
    
    void deleteCustomer(std::string name) {
        for(auto it = customers.begin(); it != customers.end();) {
            if(it->getName() == name) {
                it = customers.erase(it);
            } else {
                ++it;
            }
        }
    }

    void updateCustomer(std::string name, std::string newName, std::string newContact) {
        for(auto &customer : customers) {
            if(customer.getName() == name) {
                customer.setName(newName);
                customer.setContact(newContact);
            }
        }
    }
    
    Customer* searchCustomer(std::string name) {
        for(auto &customer : customers) {
            if(customer.getName() == name) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for(const auto &customer : customers) {
            std::cout << "Customer Name: " << customer.getName() 
                      << ", Contact: " << customer.getContact() << std::endl;
        }
    }

    void addHairstylist(std::string name, std::string contact) {
        hairstylists.push_back(Hairstylist(name, contact));
    }
    
    void deleteHairstylist(std::string name) {
        for(auto it = hairstylists.begin(); it != hairstylists.end();) {
            if(it->getName() == name) {
                it = hairstylists.erase(it);
            } else {
                ++it;
            }
        }
    }
    
    void updateHairstylist(std::string name, std::string newName, std::string newContact) {
        for(auto &hairstylist : hairstylists) {
            if(hairstylist.getName() == name) {
                hairstylist.setName(newName);
                hairstylist.setContact(newContact);
            }
        }
    }

    Hairstylist* searchHairstylist(std::string name) {
        for(auto &hairstylist : hairstylists) {
            if(hairstylist.getName() == name) {
                return &hairstylist;
            }
        }
        return nullptr;
    }

    void displayHairstylists() {
        for(const auto &hairstylist : hairstylists) {
            std::cout << "Hairstylist Name: " << hairstylist.getName() 
                      << ", Contact: " << hairstylist.getContact() << std::endl;
        }
    }
};

int main() {
    BeautySalon salon;
    salon.addCustomer("Alice", "12345");
    salon.addHairstylist("Bob", "67890");

    salon.displayCustomers();
    salon.displayHairstylists();
    
    when needed return value was as written above in called for display, search , entrance & general. 
    search for email over here or maybe a similar term would help.

    return 0;
}