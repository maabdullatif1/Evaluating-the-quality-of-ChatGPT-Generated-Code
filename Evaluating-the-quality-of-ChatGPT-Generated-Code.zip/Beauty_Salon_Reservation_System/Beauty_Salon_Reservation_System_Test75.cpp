#include <iostream>
#include <string>

using namespace std;

struct Person {
    string name;
    string contactInfo;
};

struct Reservation {
    Person customer;
    Person hairstylist;
    string time;
};

struct Node {
    Reservation data;
    Node* next;
};

class BeautySalon {
public:
    BeautySalon() : head(nullptr) {}

    void addReservation(const Reservation& res) {
        Node* newNode = new Node{res, nullptr};
        if(!head) {
            head = newNode;
        } else {
            Node* temp = head;
            while(temp->next)
                temp = temp->next;
            temp->next = newNode;
        }
    }
    
    void deleteReservation(const string& customerName) {
        Node* temp = head;
        Node* prev = nullptr;
        while(temp && temp->data.customer.name != customerName) {
            prev = temp;
            temp = temp->next;
        }
        if(temp) {
            if(prev) {
                prev->next = temp->next;
            } else {
                head = temp->next;
            }
            delete temp;
        }
    }

    void updateReservation(const string& customerName, const Reservation& newRes) {
        Node* temp = head;
        while(temp) {
            if(temp->data.customer.name == customerName) {
                temp->data = newRes;
                break;
            }
            temp = temp->next;
        }
    }

    Reservation* searchReservation(const string& customerName) {
        Node* temp = head;
        while(temp) {
            if(temp->data.customer.name == customerName) {
                return &temp->data;
            }
            temp = temp->next;
        }
        return nullptr;
    }

    void displayReservations() const {
        Node* temp = head;
        while(temp) {
            cout << "Customer: " << temp->data.customer.name 
                 << ", Hairstylist: " << temp->data.hairstylist.name 
                 << ", Time: " << temp->data.time << endl;
            temp = temp->next;
        }
    }

private:
    Node* head;
};

int main() {
    BeautySalon salon;
    Person cust1 = {"Alice", "123456"};
    Person style1 = {"Bob", "654321"};
    Reservation res1 = {cust1, style1, "10:00 AM"};

    salon.addReservation(res1);
    salon.displayReservations();

    Person cust2 = {"Charlie", "789012"};
    Reservation res2 = {cust2, style1, "11:00 AM"};
    salon.updateReservation("Alice", res2);
    salon.displayReservations();

    salon.deleteReservation("Charlie");
    salon.displayReservations();

    return 0;
}