#include <iostream>
#include <string>

using namespace std;

struct Person {
    string name;
    int id;
};

struct Customer : Person {
    string phone;
};

struct Hairstylist : Person {
    string specialty;
};

class Salon {
    Customer customers[100];
    Hairstylist stylists[100];
    int customerCount;
    int stylistCount;

public:
    Salon() : customerCount(0), stylistCount(0) {}

    void addCustomer(string name, int id, string phone) {
        customers[customerCount++] = {name, id, phone};
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i] = customers[--customerCount];
                break;
            }
        }
    }

    void updateCustomer(int id, string name = "", string phone = "") {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                if (!name.empty()) customers[i].name = name;
                if (!phone.empty()) customers[i].phone = phone;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                return &customers[i];
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; ++i) {
            cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << ", Phone: " << customers[i].phone << endl;
        }
    }

    void addHairstylist(string name, int id, string specialty) {
        stylists[stylistCount++] = {name, id, specialty};
    }

    void deleteHairstylist(int id) {
        for (int i = 0; i < stylistCount; ++i) {
            if (stylist[i].id == id) {
                stylist[i] = stylists[--stylistCount];
                break;
            }
        }
    }

    void updateHairstylist(int id, string name = "", string specialty = "") {
        for (int i = 0; i < stylistCount; ++i) {
            if (stylists[i].id == id) {
                if (!name.empty()) stylists[i].name = name;
                if (!specialty.empty()) stylists[i].specialty = specialty;
                break;
            }
        }
    }

    Hairstylist* searchHairstylist(int id) {
        for (int i = 0; i < stylistCount; ++i) {
            if (stylists[i].id == id) {
                return &stylists[i];
            }
        }
        return nullptr;
    }

    void displayHairstylists() {
        for (int i = 0; i < stylistCount; ++i) {
            cout << "Stylist ID: " << stylists[i].id << ", Name: " << stylists[i].name << ", Specialty: " << stylists[i].specialty << endl;
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("Alice", 1, "123-456-7890");
    salon.addCustomer("Bob", 2, "234-567-8901");
    salon.addHairstylist("Eve", 1, "Coloring");
    salon.addHairstylist("Charlie", 2, "Cutting");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.updateCustomer(1, "Alice A.", "098-765-4321");
    salon.updateHairstylist(1, "Eve E.", "Styling");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.deleteCustomer(2);
    salon.deleteHairstylist(2);
    salon.displayCustomers();
    salon.displayHairstylists();
    return 0;
}