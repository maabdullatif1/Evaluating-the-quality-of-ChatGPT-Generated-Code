#include <iostream>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string contact;
};

struct Hairstylist {
    int id;
    string name;
    string specialty;
};

class SalonSystem {
    Customer customers[100];
    Hairstylist hairstylists[100];
    int customerCount;
    int hairstylistCount;

public:
    SalonSystem() : customerCount(0), hairstylistCount(0) {}

    void addCustomer(int id, const string &name, const string &contact) {
        customers[customerCount++] = {id, name, contact};
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                for (int j = i; j < customerCount - 1; ++j) {
                    customers[j] = customers[j + 1];
                }
                --customerCount;
                break;
            }
        }
    }

    void updateCustomer(int id, const string &name, const string &contact) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i] = {id, name, contact};
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                cout << "Customer Found: " << customers[i].name << ", " << customers[i].contact << endl;
                return;
            }
        }
        cout << "Customer not found" << endl;
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; ++i) {
            cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name 
                 << ", Contact: " << customers[i].contact << endl;
        }
    }

    void addHairstylist(int id, const string &name, const string &specialty) {
        hairstylists[hairstylistCount++] = {id, name, specialty};
    }

    void deleteHairstylist(int id) {
        for (int i = 0; i < hairstylistCount; ++i) {
            if (hairstylists[i].id == id) {
                for (int j = i; j < hairstylistCount - 1; ++j) {
                    hairstylists[j] = hairstylists[j + 1];
                }
                --hairstylistCount;
                break;
            }
        }
    }

    void updateHairstylist(int id, const string &name, const string &specialty) {
        for (int i = 0; i < hairstylistCount; ++i) {
            if (hairstylists[i].id == id) {
                hairstylists[i] = {id, name, specialty};
                break;
            }
        }
    }

    void searchHairstylist(int id) {
        for (int i = 0; i < hairstylistCount; ++i) {
            if (hairstylists[i].id == id) {
                cout << "Hairstylist Found: " << hairstylists[i].name << ", " << hairstylists[i].specialty << endl;
                return;
            }
        }
        cout << "Hairstylist not found" << endl;
    }

    void displayHairstylists() {
        for (int i = 0; i < hairstylistCount; ++i) {
            cout << "Hairstylist ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name 
                 << ", Specialty: " << hairstylists[i].specialty << endl;
        }
    }
};

int main() {
    SalonSystem salon;
    salon.addCustomer(1, "Alice", "123-456-7890");
    salon.addCustomer(2, "Bob", "987-654-3210");
    salon.addHairstylist(1, "Charlie", "Curly Cuts");
    salon.addHairstylist(2, "Dave", "Color Specialist");

    salon.displayCustomers();
    salon.displayHairstylists();

    salon.searchCustomer(1);
    salon.searchHairstylist(2);

    salon.updateCustomer(1, "Alice Wonderland", "111-222-3333");
    salon.updateHairstylist(2, "Dave Smith", "Highlights");

    salon.displayCustomers();
    salon.displayHairstylists();

    salon.deleteCustomer(2);
    salon.deleteHairstylist(1);

    salon.displayCustomers();
    salon.displayHairstylists();

    return 0;
}