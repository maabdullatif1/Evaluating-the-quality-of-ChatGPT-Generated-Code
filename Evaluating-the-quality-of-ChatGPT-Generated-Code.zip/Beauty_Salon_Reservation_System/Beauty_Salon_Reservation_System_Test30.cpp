#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string phone;

    Customer(int i, std::string n, std::string p) : id(i), name(n), phone(p) {}
};

class Hairstylist {
public:
    int id;
    std::string name;
    std::string expertise;

    Hairstylist(int i, std::string n, std::string e) : id(i), name(n), expertise(e) {}
};

class Salon {
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;
    int customerIDCounter = 1;
    int hairstylistIDCounter = 1;

public:
    void addCustomer(std::string name, std::string phone) {
        customers.push_back(Customer(customerIDCounter++, name, phone));
    }

    void addHairstylist(std::string name, std::string expertise) {
        hairstylists.push_back(Hairstylist(hairstylistIDCounter++, name, expertise));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void deleteHairstylist(int id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->id == id) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string phone) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phone = phone;
                break;
            }
        }
    }

    void updateHairstylist(int id, std::string name, std::string expertise) {
        for (auto &hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                hairstylist.name = name;
                hairstylist.expertise = expertise;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Hairstylist* searchHairstylist(int id) {
        for (auto &hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                return &hairstylist;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << std::endl;
        }
    }

    void displayHairstylists() {
        for (const auto &hairstylist : hairstylists) {
            std::cout << "ID: " << hairstylist.id << ", Name: " << hairstylist.name << ", Expertise: " << hairstylist.expertise << std::endl;
        }
    }
};

int main() {
    Salon salon;

    // Example Usage
    salon.addCustomer("Alice", "123456789");
    salon.addHairstylist("Bob", "Coloring");

    salon.displayCustomers();
    salon.displayHairstylists();

    salon.updateCustomer(1, "Alice Johnson", "987654321");
    salon.updateHairstylist(1, "Bob Smith", "Styling");

    salon.displayCustomers();
    salon.displayHairstylists();
    
    salon.deleteCustomer(1);
    salon.deleteHairstylist(1);

    salon.displayCustomers();
    salon.displayHairstylists();

    return 0;
}