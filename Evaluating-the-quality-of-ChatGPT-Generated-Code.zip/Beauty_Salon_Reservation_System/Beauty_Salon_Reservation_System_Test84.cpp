#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;

    Customer(int id, const std::string& name) : id(id), name(name) {}
};

class Hairstylist {
public:
    int id;
    std::string name;

    Hairstylist(int id, const std::string& name) : id(id), name(name) {}
};

class SalonSystem {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

    template<typename T>
    typename std::vector<T>::iterator findById(std::vector<T>& vec, int id) {
        return std::find_if(vec.begin(), vec.end(), [&id](T& t) { return t.id == id; });
    }

    template<typename T>
    void displayInfo(const std::vector<T>& vec) {
        for (const auto& entry : vec) {
            std::cout << "ID: " << entry.id << ", Name: " << entry.name << std::endl;
        }
    }

public:
    void addCustomer(int id, const std::string& name) {
        if (findById(customers, id) == customers.end()) {
            customers.emplace_back(id, name);
        }
    }

    void deleteCustomer(int id) {
        auto it = findById(customers, id);
        if (it != customers.end()) {
            customers.erase(it);
        }
    }

    void updateCustomer(int id, const std::string& newName) {
        auto it = findById(customers, id);
        if (it != customers.end()) {
            it->name = newName;
        }
    }

    void searchCustomer(int id) {
        auto it = findById(customers, id);
        if (it != customers.end()) {
            std::cout << "Found Customer - ID: " << it->id << ", Name: " << it->name << std::endl;
        } else {
            std::cout << "Customer not found" << std::endl;
        }
    }

    void displayCustomers() {
        displayInfo(customers);
    }

    void addHairstylist(int id, const std::string& name) {
        if (findById(hairstylists, id) == hairstylists.end()) {
            hairstylists.emplace_back(id, name);
        }
    }

    void deleteHairstylist(int id) {
        auto it = findById(hairstylists, id);
        if (it != hairstylists.end()) {
            hairstylists.erase(it);
        }
    }

    void updateHairstylist(int id, const std::string& newName) {
        auto it = findById(hairstylists, id);
        if (it != hairstylists.end()) {
            it->name = newName;
        }
    }

    void searchHairstylist(int id) {
        auto it = findById(hairstylists, id);
        if (it != hairstylists.end()) {
            std::cout << "Found Hairstylist - ID: " << it->id << ", Name: " << it->name << std::endl;
        } else {
            std::cout << "Hairstylist not found" << std::endl;
        }
    }

    void displayHairstylists() {
        displayInfo(hairstylists);
    }
};

int main() {
    SalonSystem salon;

    salon.addCustomer(1, "Alice");
    salon.addCustomer(2, "Bob");
    salon.addHairstylist(1, "Jane");
    salon.addHairstylist(2, "John");

    salon.displayCustomers();
    salon.displayHairstylists();

    salon.updateCustomer(1, "Alicia");
    salon.updateHairstylist(2, "Johnny");

    salon.searchCustomer(1);
    salon.searchHairstylist(2);

    salon.deleteCustomer(2);
    salon.deleteHairstylist(1);

    salon.displayCustomers();
    salon.displayHairstylists();

    return 0;
}