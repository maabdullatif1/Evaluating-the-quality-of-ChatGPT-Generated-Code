#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string phone;
};

struct Hairstylist {
    int id;
    std::string name;
    std::string specialty;
};

class BeautySalon {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;
    int nextCustomerId;
    int nextHairstylistId;

public:
    BeautySalon() : nextCustomerId(1), nextHairstylistId(1) {}

    void addCustomer(const std::string& name, const std::string& phone) {
        customers.push_back({nextCustomerId++, name, phone});
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& phone) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phone = phone;
                return;
            }
        }
    }

    void searchCustomer(const std::string& name) {
        for (const auto& customer : customers) {
            if (customer.name == name) {
                std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << std::endl;
            }
        }
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << std::endl;
        }
    }

    void addHairstylist(const std::string& name, const std::string& specialty) {
        hairstylists.push_back({nextHairstylistId++, name, specialty});
    }

    void deleteHairstylist(int id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->id == id) {
                hairstylists.erase(it);
                return;
            }
        }
    }

    void updateHairstylist(int id, const std::string& name, const std::string& specialty) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                hairstylist.name = name;
                hairstylist.specialty = specialty;
                return;
            }
        }
    }

    void searchHairstylist(const std::string& name) {
        for (const auto& hairstylist : hairstylists) {
            if (hairstylist.name == name) {
                std::cout << "Hairstylist ID: " << hairstylist.id << ", Name: " << hairstylist.name << ", Specialty: " << hairstylist.specialty << std::endl;
            }
        }
    }

    void displayHairstylists() {
        for (const auto& hairstylist : hairstylists) {
            std::cout << "Hairstylist ID: " << hairstylist.id << ", Name: " << hairstylist.name << ", Specialty: " << hairstylist.specialty << std::endl;
        }
    }
};

int main() {
    BeautySalon salon;
    
    salon.addCustomer("Alice", "1234567890");
    salon.addCustomer("Bob", "0987654321");
    salon.displayCustomers();
    salon.updateCustomer(1, "Alicia", "1234567899");
    salon.searchCustomer("Alicia");
    salon.deleteCustomer(2);
    salon.displayCustomers();

    salon.addHairstylist("Tom", "Coloring");
    salon.addHairstylist("Jerry", "Styling");
    salon.displayHairstylists();
    salon.updateHairstylist(1, "Tommy", "Cutting");
    salon.searchHairstylist("Tommy");
    salon.deleteHairstylist(2);
    salon.displayHairstylists();

    return 0;
}