#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string phone;

    Customer(int i, std::string n, std::string p) : id(i), name(n), phone(p) {}
};

class Hairstylist {
public:
    int id;
    std::string name;
    std::string specialty;

    Hairstylist(int i, std::string n, std::string s) : id(i), name(n), specialty(s) {}
};

class SalonSystem {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

    template <typename T>
    int findIndexById(std::vector<T>& vec, int id) {
        for (int i = 0; i < vec.size(); ++i)
            if (vec[i].id == id)
                return i;
        return -1;
    }
    
public:
    void addCustomer(int id, std::string name, std::string phone) {
        customers.push_back(Customer(id, name, phone));
    }

    void deleteCustomer(int id) {
        int idx = findIndexById(customers, id);
        if (idx != -1) {
            customers.erase(customers.begin() + idx);
        }
    }

    void updateCustomer(int id, std::string name, std::string phone) {
        int idx = findIndexById(customers, id);
        if (idx != -1) {
            customers[idx].name = name;
            customers[idx].phone = phone;
        }
    }

    void displayCustomers() {
        for (auto& customer : customers)
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << std::endl;
    }

    Customer* searchCustomer(int id) {
        int idx = findIndexById(customers, id);
        return (idx != -1) ? &customers[idx] : nullptr;
    }

    void addHairstylist(int id, std::string name, std::string specialty) {
        hairstylists.push_back(Hairstylist(id, name, specialty));
    }

    void deleteHairstylist(int id) {
        int idx = findIndexById(hairstylists, id);
        if (idx != -1) {
            hairstylists.erase(hairstylists.begin() + idx);
        }
    }

    void updateHairstylist(int id, std::string name, std::string specialty) {
        int idx = findIndexById(hairstylists, id);
        if (idx != -1) {
            hairstylists[idx].name = name;
            hairstylists[idx].specialty = specialty;
        }
    }

    void displayHairstylists() {
        for (auto& stylist : hairstylists)
            std::cout << "ID: " << stylist.id << ", Name: " << stylist.name << ", Specialty: " << stylist.specialty << std::endl;
    }

    Hairstylist* searchHairstylist(int id) {
        int idx = findIndexById(hairstylists, id);
        return (idx != -1) ? &hairstylists[idx] : nullptr;
    }
};

int main() {
    SalonSystem system;
    system.addCustomer(1, "Alice", "123456789");
    system.addCustomer(2, "Bob", "987654321");
    system.addHairstylist(1, "Charlie", "Cutting");
    system.addHairstylist(2, "Dave", "Coloring");

    system.displayCustomers();
    system.displayHairstylists();

    system.updateCustomer(1, "Alicia", "111222333");
    system.updateHairstylist(2, "David", "Styling");

    system.displayCustomers();
    system.displayHairstylists();

    system.deleteCustomer(2);
    system.deleteHairstylist(1);

    system.displayCustomers();
    system.displayHairstylists();

    return 0;
}