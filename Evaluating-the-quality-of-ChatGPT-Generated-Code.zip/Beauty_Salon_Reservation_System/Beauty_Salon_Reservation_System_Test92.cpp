#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int id;

public:
    Person(std::string n, int i) : name(n), id(i) {}
    int getId() const { return id; }
    std::string getName() const { return name; }
    void setName(const std::string& n) { name = n; }
};

class Customer : public Person {
public:
    Customer(std::string n, int i) : Person(n, i) {}
};

class HairStylist : public Person {
public:
    HairStylist(std::string n, int i) : Person(n, i) {}
};

template <typename T>
class ManagementSystem {
private:
    std::vector<T> records;

public:
    void addRecord(const T& record) {
        records.push_back(record);
    }

    void deleteRecord(int id) {
        for (auto it = records.begin(); it != records.end(); ++it) {
            if (it->getId() == id) {
                records.erase(it);
                return;
            }
        }
    }

    void updateRecord(int id, const std::string& newName) {
        for (auto& record : records) {
            if (record.getId() == id) {
                record.setName(newName);
                return;
            }
        }
    }

    T* searchRecord(int id) {
        for (auto& record : records) {
            if (record.getId() == id) {
                return &record;
            }
        }
        return nullptr;
    }

    void displayRecords() const {
        for (const auto& record : records) {
            std::cout << "ID: " << record.getId() << ", Name: " << record.getName() << std::endl;
        }
    }
};

int main() {
    ManagementSystem<Customer> customerSystem;
    ManagementSystem<HairStylist> stylistSystem;

    customerSystem.addRecord(Customer("Alice", 1));
    customerSystem.addRecord(Customer("Bob", 2));
    stylistSystem.addRecord(HairStylist("Charlie", 101));
    stylistSystem.addRecord(HairStylist("Dave", 102));

    customerSystem.updateRecord(1, "Alice Smith");
    stylistSystem.deleteRecord(102);

    Customer* customer = customerSystem.searchRecord(2);
    HairStylist* stylist = stylistSystem.searchRecord(101);

    if (customer) {
        std::cout << "Found Customer: " << customer->getName() << std::endl;
    }

    if (stylist) {
        std::cout << "Found HairStylist: " << stylist->getName() << std::endl;
    }

    std::cout << "Customer Records:" << std::endl;
    customerSystem.displayRecords();

    std::cout << "HairStylist Records:" << std::endl;
    stylistSystem.displayRecords();

    return 0;
}