#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
};

struct Hairstylist {
    int id;
    string name;
};

const int MAX_CUSTOMERS = 100;
const int MAX_HAIRSTYLISTS = 100;

Customer customers[MAX_CUSTOMERS];
Hairstylist hairstylists[MAX_HAIRSTYLISTS];

int customerCount = 0;
int hairstylistCount = 0;

void addCustomer(int id, string name) {
    if (customerCount < MAX_CUSTOMERS) {
        customers[customerCount++] = {id, name};
    }
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; ++j) {
                customers[j] = customers[j + 1];
            }
            --customerCount;
            break;
        }
    }
}

void updateCustomer(int id, string newName) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            customers[i].name = newName;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; ++i) {
        cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << endl;
    }
}

void addHairstylist(int id, string name) {
    if (hairstylistCount < MAX_HAIRSTYLISTS) {
        hairstylists[hairstylistCount++] = {id, name};
    }
}

void deleteHairstylist(int id) {
    for (int i = 0; i < hairstylistCount; ++i) {
        if (hairstylists[i].id == id) {
            for (int j = i; j < hairstylistCount - 1; ++j) {
                hairstylists[j] = hairstylists[j + 1];
            }
            --hairstylistCount;
            break;
        }
    }
}

void updateHairstylist(int id, string newName) {
    for (int i = 0; i < hairstylistCount; ++i) {
        if (hairstylists[i].id == id) {
            hairstylists[i].name = newName;
            break;
        }
    }
}

Hairstylist* searchHairstylist(int id) {
    for (int i = 0; i < hairstylistCount; ++i) {
        if (hairstylists[i].id == id) {
            return &hairstylists[i];
        }
    }
    return nullptr;
}

void displayHairstylists() {
    for (int i = 0; i < hairstylistCount; ++i) {
        cout << "Hairstylist ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name << endl;
    }
}

int main() {
    addCustomer(1, "Alice");
    addCustomer(2, "Bob");
    displayCustomers();

    addHairstylist(1, "Charlie");
    addHairstylist(2, "David");
    displayHairstylists();

    Customer* foundCustomer = searchCustomer(1);
    if (foundCustomer) {
        cout << "Found Customer: " << foundCustomer->name << endl;
    }

    deleteCustomer(2);
    displayCustomers();

    updateCustomer(1, "Alice Smith");
    displayCustomers();

    return 0;
}