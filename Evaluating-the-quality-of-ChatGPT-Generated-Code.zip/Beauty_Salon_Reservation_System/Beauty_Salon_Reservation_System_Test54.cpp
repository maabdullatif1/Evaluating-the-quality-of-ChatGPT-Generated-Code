#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
protected:
    string name;
    string phone;
public:
    Person(string n, string p) : name(n), phone(p) {}
    string getName() { return name; }
    string getPhone() { return phone; }
    void setName(string n) { name = n; }
    void setPhone(string p) { phone = p; }
};

class Customer : public Person {
public:
    Customer(string n, string p) : Person(n, p) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(string n, string p) : Person(n, p) {}
};

class SalonSystem {
private:
    vector<Customer> customers;
    vector<Hairstylist> hairstylists;

public:
    void addCustomer(string name, string phone) {
        customers.push_back(Customer(name, phone));
    }

    void deleteCustomer(string name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getName() == name) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(string name, string newName, string newPhone) {
        for (auto& c : customers) {
            if (c.getName() == name) {
                c.setName(newName);
                c.setPhone(newPhone);
                break;
            }
        }
    }

    void searchCustomer(string name) {
        for (auto& c : customers) {
            if (c.getName() == name) {
                cout << "Customer Name: " << c.getName() << ", Phone: " << c.getPhone() << endl;
                return;
            }
        }
        cout << "Customer not found." << endl;
    }

    void displayCustomers() {
        for (auto& c : customers) {
            cout << "Customer Name: " << c.getName() << ", Phone: " << c.getPhone() << endl;
        }
    }

    void addHairstylist(string name, string phone) {
        hairstylists.push_back(Hairstylist(name, phone));
    }

    void deleteHairstylist(string name) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->getName() == name) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateHairstylist(string name, string newName, string newPhone) {
        for (auto& h : hairstylists) {
            if (h.getName() == name) {
                h.setName(newName);
                h.setPhone(newPhone);
                break;
            }
        }
    }

    void searchHairstylist(string name) {
        for (auto& h : hairstylists) {
            if (h.getName() == name) {
                cout << "Hairstylist Name: " << h.getName() << ", Phone: " << h.getPhone() << endl;
                return;
            }
        }
        cout << "Hairstylist not found." << endl;
    }

    void displayHairstylists() {
        for (auto& h : hairstylists) {
            cout << "Hairstylist Name: " << h.getName() << ", Phone: " << h.getPhone() << endl;
        }
    }
};

int main() {
    SalonSystem system;
    
    system.addCustomer("Alice", "1234567890");
    system.addCustomer("Bob", "0987654321");
    system.displayCustomers();
    
    system.addHairstylist("John", "5678901234");
    system.addHairstylist("Emma", "6789012345");
    system.displayHairstylists();
    
    system.updateCustomer("Alice", "Alice Brown", "1122334455");
    system.searchCustomer("Alice Brown");

    system.deleteHairstylist("John");
    system.displayHairstylists();

    return 0;
}