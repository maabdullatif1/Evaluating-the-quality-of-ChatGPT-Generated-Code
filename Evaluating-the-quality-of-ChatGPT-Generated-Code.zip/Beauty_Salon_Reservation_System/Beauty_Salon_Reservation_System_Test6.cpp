#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    string phoneNumber;
};

class BeautySalon {
private:
    vector<Person> customers;
    vector<Person> hairstylists;

public:
    void addCustomer(const string& name, const string& phone) {
        customers.push_back({name, phone});
    }

    void deleteCustomer(const string& name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(const string& oldName, const string& newName, const string& newPhone) {
        for (auto& customer : customers) {
            if (customer.name == oldName) {
                customer.name = newName;
                customer.phoneNumber = newPhone;
                break;
            }
        }
    }

    Person* searchCustomer(const string& name) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Name: " << customer.name << ", Phone: " << customer.phoneNumber << endl;
        }
    }

    void addHairstylist(const string& name, const string& phone) {
        hairstylists.push_back({name, phone});
    }

    void deleteHairstylist(const string& name) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->name == name) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateHairstylist(const string& oldName, const string& newName, const string& newPhone) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.name == oldName) {
                hairstylist.name = newName;
                hairstylist.phoneNumber = newPhone;
                break;
            }
        }
    }

    Person* searchHairstylist(const string& name) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.name == name) {
                return &hairstylist;
            }
        }
        return nullptr;
    }

    void displayHairstylists() {
        for (const auto& hairstylist : hairstylists) {
            cout << "Name: " << hairstylist.name << ", Phone: " << hairstylist.phoneNumber << endl;
        }
    }
};

int main() {
    BeautySalon salon;
    
    salon.addCustomer("Alice", "1234");
    salon.addCustomer("Bob", "5678");
    salon.addHairstylist("Charlie", "8765");
    salon.addHairstylist("Diana", "4321");
    
    cout << "Customers:" << endl;
    salon.displayCustomers();
    
    cout << "Hairstylists:" << endl;
    salon.displayHairstylists();
    
    return 0;
}