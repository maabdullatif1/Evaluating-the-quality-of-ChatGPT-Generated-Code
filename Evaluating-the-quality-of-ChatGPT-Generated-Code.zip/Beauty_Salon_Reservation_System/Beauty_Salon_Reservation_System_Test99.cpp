#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;

    Customer(int cid, std::string cname) : id(cid), name(cname) {}
};

class Hairstylist {
public:
    int id;
    std::string name;

    Hairstylist(int hid, std::string hname) : id(hid), name(hname) {}
};

class Salon {
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;
    int customer_counter = 1;
    int hairstylist_counter = 1;

public:
    void addCustomer(std::string name) {
        customers.push_back(Customer(customer_counter++, name));
    }

    void addHairstylist(std::string name) {
        hairstylists.push_back(Hairstylist(hairstylist_counter++, name));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void deleteHairstylist(int id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->id == id) {
                hairstylists.erase(it);
                return;
            }
        }
    }

    void updateCustomer(int id, std::string new_name) {
        for (auto &cust : customers) {
            if (cust.id == id) {
                cust.name = new_name;
                return;
            }
        }
    }

    void updateHairstylist(int id, std::string new_name) {
        for (auto &hair : hairstylists) {
            if (hair.id == id) {
                hair.name = new_name;
                return;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto &cust : customers) {
            if (cust.id == id) {
                std::cout << "Customer ID: " << cust.id << ", Name: " << cust.name << std::endl;
                return;
            }
        }
        std::cout << "Customer not found" << std::endl;
    }

    void searchHairstylist(int id) {
        for (const auto &hair : hairstylists) {
            if (hair.id == id) {
                std::cout << "Hairstylist ID: " << hair.id << ", Name: " << hair.name << std::endl;
                return;
            }
        }
        std::cout << "Hairstylist not found" << std::endl;
    }

    void displayCustomers() {
        std::cout << "Customers List:" << std::endl;
        for (const auto &cust : customers) {
            std::cout << "ID: " << cust.id << ", Name: " << cust.name << std::endl;
        }
    }

    void displayHairstylists() {
        std::cout << "Hairstylists List:" << std::endl;
        for (const auto &hair : hairstylists) {
            std::cout << "ID: " << hair.id << ", Name: " << hair.name << std::endl;
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("Alice");
    salon.addHairstylist("John");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.searchCustomer(1);
    salon.updateCustomer(1, "Alicia");
    salon.displayCustomers();
    salon.deleteCustomer(1);
    salon.displayCustomers();
    return 0;
}