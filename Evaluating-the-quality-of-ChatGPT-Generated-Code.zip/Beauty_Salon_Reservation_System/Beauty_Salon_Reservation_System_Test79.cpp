#include <iostream>
#include <string>
#include <vector>

class Customer {
public:
    int id;
    std::string name;
    std::string phone;
    Customer(int id, std::string name, std::string phone) : id(id), name(name), phone(phone) {}
};

class Hairstylist {
public:
    int id;
    std::string name;
    Hairstylist(int id, std::string name) : id(id), name(name) {}
};

class BeautySalon {
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;
    
    Customer* findCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) return &customer;
        }
        return nullptr;
    }
    
    Hairstylist* findHairstylist(int id) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) return &hairstylist;
        }
        return nullptr;
    }
    
public:
    void addCustomer(int id, std::string name, std::string phone) {
        customers.push_back(Customer(id, name, phone));
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, std::string name, std::string phone) {
        Customer* customer = findCustomer(id);
        if (customer) {
            customer->name = name;
            customer->phone = phone;
        }
    }
    
    Customer* searchCustomer(int id) {
        return findCustomer(id);
    }
    
    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << std::endl;
        }
    }
    
    void addHairstylist(int id, std::string name) {
        hairstylists.push_back(Hairstylist(id, name));
    }
    
    void deleteHairstylist(int id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->id == id) {
                hairstylists.erase(it);
                break;
            }
        }
    }
    
    void updateHairstylist(int id, std::string name) {
        Hairstylist* hairstylist = findHairstylist(id);
        if (hairstylist) {
            hairstylist->name = name;
        }
    }
    
    Hairstylist* searchHairstylist(int id) {
        return findHairstylist(id);
    }
    
    void displayHairstylists() {
        for (const auto& hairstylist : hairstylists) {
            std::cout << "ID: " << hairstylist.id << ", Name: " << hairstylist.name << std::endl;
        }
    }
};

int main() {
    BeautySalon salon;
    salon.addCustomer(1, "Alice", "1234567890");
    salon.addHairstylist(1, "Bob");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.updateCustomer(1, "Alice Smith", "0987654321");
    salon.updateHairstylist(1, "Bob Johnson");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.deleteCustomer(1);
    salon.deleteHairstylist(1);
    salon.displayCustomers();
    salon.displayHairstylists();
    return 0;
}