#include <iostream>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct Hairstylist {
    int id;
    string name;
    string specialization;
};

class BeautySalon {
private:
    Customer customers[100];
    Hairstylist hairstylists[100];
    int customerCount;
    int hairstylistCount;

public:
    BeautySalon() : customerCount(0), hairstylistCount(0) {}

    void addCustomer(int id, string name, string phone) {
        customers[customerCount++] = {id, name, phone};
    }

    void removeCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                for (int j = i; j < customerCount - 1; ++j) {
                    customers[j] = customers[j + 1];
                }
                --customerCount;
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string phone) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i].name = name;
                customers[i].phone = phone;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                cout << "Customer ID: " << customers[i].id << " Name: " << customers[i].name << " Phone: " << customers[i].phone << endl;
                return;
            }
        }
        cout << "Customer not found" << endl;
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; ++i) {
            cout << "Customer ID: " << customers[i].id << " Name: " << customers[i].name << " Phone: " << customers[i].phone << endl;
        }
    }

    void addHairstylist(int id, string name, string specialization) {
        hairstylists[hairstylistCount++] = {id, name, specialization};
    }

    void removeHairstylist(int id) {
        for (int i = 0; i < hairstylistCount; ++i) {
            if (hairstylists[i].id == id) {
                for (int j = i; j < hairstylistCount - 1; ++j) {
                    hairstylists[j] = hairstylists[j + 1];
                }
                --hairstylistCount;
                break;
            }
        }
    }

    void updateHairstylist(int id, string name, string specialization) {
        for (int i = 0; i < hairstylistCount; ++i) {
            if (hairstylists[i].id == id) {
                hairstylists[i].name = name;
                hairstylists[i].specialization = specialization;
                break;
            }
        }
    }

    void searchHairstylist(int id) {
        for (int i = 0; i < hairstylistCount; ++i) {
            if (hairstylists[i].id == id) {
                cout << "Hairstylist ID: " << hairstylists[i].id << " Name: " << hairstylists[i].name << " Specialization: " << hairstylists[i].specialization << endl;
                return;
            }
        }
        cout << "Hairstylist not found" << endl;
    }

    void displayHairstylists() {
        for (int i = 0; i < hairstylistCount; ++i) {
            cout << "Hairstylist ID: " << hairstylists[i].id << " Name: " << hairstylists[i].name << " Specialization: " << hairstylists[i].specialization << endl;
        }
    }
};

int main() {
    BeautySalon salon;
    salon.addCustomer(1, "Alice", "123-456-7890");
    salon.addCustomer(2, "Bob", "234-567-8901");
    salon.displayCustomers();
    salon.updateCustomer(1, "Alice Smith", "111-222-3333");
    salon.searchCustomer(1);
    salon.removeCustomer(2);
    salon.displayCustomers();

    salon.addHairstylist(1, "Jane", "Coloring");
    salon.addHairstylist(2, "John", "Cutting");
    salon.displayHairstylists();
    salon.updateHairstylist(1, "Jane Doe", "Styling");
    salon.searchHairstylist(1);
    salon.removeHairstylist(2);
    salon.displayHairstylists();

    return 0;
}