#include <iostream>
#include <vector>
#include <string>

class BeautySalon {
private:
    struct Person {
        int id;
        std::string name;
    };

    std::vector<Person> customers;
    std::vector<Person> stylists;

    void displayPersonList(const std::vector<Person>& people) {
        for (const auto& person : people) {
            std::cout << "ID: " << person.id << ", Name: " << person.name << std::endl;
        }
    }

    int findPersonIndexById(const std::vector<Person>& people, int id) {
        for (int i = 0; i < people.size(); ++i) {
            if (people[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCustomer(int id, const std::string& name) {
        customers.push_back({ id, name });
    }

    void addStylist(int id, const std::string& name) {
        stylists.push_back({ id, name });
    }

    void deleteCustomer(int id) {
        int index = findPersonIndexById(customers, id);
        if (index != -1) customers.erase(customers.begin() + index);
    }

    void deleteStylist(int id) {
        int index = findPersonIndexById(stylists, id);
        if (index != -1) stylists.erase(stylists.begin() + index);
    }

    void updateCustomer(int id, const std::string& newName) {
        int index = findPersonIndexById(customers, id);
        if (index != -1) customers[index].name = newName;
    }

    void updateStylist(int id, const std::string& newName) {
        int index = findPersonIndexById(stylists, id);
        if (index != -1) stylists[index].name = newName;
    }

    void searchCustomer(int id) {
        int index = findPersonIndexById(customers, id);
        if (index != -1) {
            std::cout << "Customer found: ID: " << customers[index].id << ", Name: " << customers[index].name << std::endl;
        } else {
            std::cout << "Customer not found." << std::endl;
        }
    }

    void searchStylist(int id) {
        int index = findPersonIndexById(stylists, id);
        if (index != -1) {
            std::cout << "Stylist found: ID: " << stylists[index].id << ", Name: " << stylists[index].name << std::endl;
        } else {
            std::cout << "Stylist not found." << std::endl;
        }
    }

    void displayCustomers() {
        std::cout << "Customers:" << std::endl;
        displayPersonList(customers);
    }

    void displayStylists() {
        std::cout << "Stylists:" << std::endl;
        displayPersonList(stylists);
    }
};

int main() {
    BeautySalon salon;
    salon.addCustomer(1, "Alice");
    salon.addCustomer(2, "Bob");
    salon.addStylist(101, "Stylist1");
    salon.addStylist(102, "Stylist2");

    salon.displayCustomers();
    salon.displayStylists();

    salon.updateCustomer(1, "Alice Cooper");
    salon.updateStylist(101, "Stylist One");

    salon.displayCustomers();
    salon.displayStylists();

    salon.searchCustomer(2);
    salon.searchStylist(102);

    salon.deleteCustomer(2);
    salon.deleteStylist(102);

    salon.displayCustomers();
    salon.displayStylists();

    return 0;
}