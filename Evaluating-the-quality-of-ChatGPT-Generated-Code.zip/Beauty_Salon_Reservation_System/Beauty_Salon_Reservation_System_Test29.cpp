#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    std::string phone;
};

class Customer : public Person {
public:
    std::string email;

    Customer(std::string n, std::string p, std::string e) {
        name = n;
        phone = p;
        email = e;
    }
};

class Hairstylist : public Person {
public:
    std::string specialization;

    Hairstylist(std::string n, std::string p, std::string s) {
        name = n;
        phone = p;
        specialization = s;
    }
};

class Salon {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

    template<typename T>
    void displayPersonInfo(const std::vector<T>& list) {
        for (const auto& person : list) {
            std::cout << "Name: " << person.name << "\n";
            std::cout << "Phone: " << person.phone << "\n";
        }
    }

public:
    void addCustomer(Customer customer) {
        customers.push_back(customer);
    }

    void deleteCustomer(std::string name) {
        customers.erase(std::remove_if(customers.begin(), customers.end(), [&](Customer& c) { return c.name == name; }), customers.end());
    }

    void updateCustomer(std::string name, Customer newInfo) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                customer = newInfo;
                break;
            }
        }
    }

    void searchCustomer(std::string name) {
        for (const auto& customer : customers) {
            if (customer.name == name) {
                std::cout << "Found Customer: " << customer.name << ", Phone: " << customer.phone << ", Email: " << customer.email << "\n";
                return;
            }
        }
        std::cout << "Customer not found.\n";
    }

    void displayCustomers() {
        displayPersonInfo(customers);
    }

    void addHairstylist(Hairstylist hairstylist) {
        hairstylists.push_back(hairstylist);
    }

    void deleteHairstylist(std::string name) {
        hairstylists.erase(std::remove_if(hairstylists.begin(), hairstylists.end(), [&](Hairstylist& h) { return h.name == name; }), hairstylists.end());
    }

    void updateHairstylist(std::string name, Hairstylist newInfo) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.name == name) {
                hairstylist = newInfo;
                break;
            }
        }
    }

    void searchHairstylist(std::string name) {
        for (const auto& hairstylist : hairstylists) {
            if (hairstylist.name == name) {
                std::cout << "Found Hairstylist: " << hairstylist.name << ", Phone: " << hairstylist.phone << ", Specialization: " << hairstylist.specialization << "\n";
                return;
            }
        }
        std::cout << "Hairstylist not found.\n";
    }

    void displayHairstylists() {
        displayPersonInfo(hairstylists);
    }
};

int main() {
    Salon salon;

    salon.addCustomer(Customer("Alice", "12345", "alice@example.com"));
    salon.addCustomer(Customer("Bob", "67890", "bob@example.com"));
    
    salon.addHairstylist(Hairstylist("Charlie", "54321", "Curly Hair"));
    salon.addHairstylist(Hairstylist("David", "98765", "Straight Hair"));

    salon.displayCustomers();
    salon.displayHairstylists();

    salon.searchCustomer("Alice");
    salon.searchHairstylist("Charlie");

    salon.updateCustomer("Alice", Customer("Alice Cooper", "12345", "alicec@example.com"));
    salon.updateHairstylist("Charlie", Hairstylist("Charlie Puth", "54321", "Wavy Hair"));

    salon.displayCustomers();
    salon.displayHairstylists();

    salon.deleteCustomer("Bob");
    salon.deleteHairstylist("David");

    salon.displayCustomers();
    salon.displayHairstylists();

    return 0;
}