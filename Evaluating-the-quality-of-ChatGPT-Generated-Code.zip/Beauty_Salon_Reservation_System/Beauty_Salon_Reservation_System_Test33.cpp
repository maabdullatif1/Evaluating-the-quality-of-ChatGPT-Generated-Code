#include <iostream>
#include <string>
#include <vector>

class Person {
public:
    std::string id;
    std::string name;

    Person(std::string id, std::string name) : id(id), name(name) {}
};

class Customer : public Person {
public:
    Customer(std::string id, std::string name) : Person(id, name) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(std::string id, std::string name) : Person(id, name) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

    template<typename T>
    void display(const std::vector<T>& people) {
        for (const auto& person : people) {
            std::cout << "ID: " << person.id << ", Name: " << person.name << std::endl;
        }
    }

    template<typename T>
    T* search(std::vector<T>& people, const std::string& id) {
        for (auto& person : people) {
            if (person.id == id) {
                return &person;
            }
        }
        return nullptr;
    }

public:
    void addCustomer(const std::string& id, const std::string& name) {
        customers.push_back(Customer(id, name));
    }

    void deleteCustomer(const std::string& id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(const std::string& id, const std::string& newName) {
        Customer* customer = search(customers, id);
        if (customer) {
            customer->name = newName;
        }
    }

    void addHairstylist(const std::string& id, const std::string& name) {
        hairstylists.push_back(Hairstylist(id, name));
    }

    void deleteHairstylist(const std::string& id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->id == id) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateHairstylist(const std::string& id, const std::string& newName) {
        Hairstylist* hairstylist = search(hairstylists, id);
        if (hairstylist) {
            hairstylist->name = newName;
        }
    }

    void displayCustomers() {
        display(customers);
    }

    void displayHairstylists() {
        display(hairstylists);
    }
};

int main() {
    ReservationSystem salon;
    salon.addCustomer("C1", "Alice");
    salon.addHairstylist("H1", "Bob");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.updateCustomer("C1", "Alicia");
    salon.updateHairstylist("H1", "Bobby");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.deleteCustomer("C1");
    salon.deleteHairstylist("H1");
    salon.displayCustomers();
    salon.displayHairstylists();
    return 0;
}