#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    string name;
    string phone;
    string email;

    Customer(string n, string p, string e) : name(n), phone(p), email(e) {}
};

class Hairstylist {
public:
    string name;
    string expertise;

    Hairstylist(string n, string e) : name(n), expertise(e) {}
};

class Salon {
private:
    vector<Customer> customers;
    vector<Hairstylist> hairstylists;

public:
    void addCustomer(const string& name, const string& phone, const string& email) {
        customers.push_back(Customer(name, phone, email));
    }

    void deleteCustomer(const string& name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(const string& name, const string& phone, const string& email) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                customer.phone = phone;
                customer.email = email;
                break;
            }
        }
    }

    void addHairstylist(const string& name, const string& expertise) {
        hairstylists.push_back(Hairstylist(name, expertise));
    }

    void deleteHairstylist(const string& name) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->name == name) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateHairstylist(const string& name, const string& expertise) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.name == name) {
                hairstylist.expertise = expertise;
                break;
            }
        }
    }

    void searchCustomer(const string& name) {
        for (const auto& customer : customers) {
            if (customer.name == name) {
                cout << "Customer Found:\n";
                cout << "Name: " << customer.name << "\nPhone: " << customer.phone << "\nEmail: " << customer.email << endl;
                return;
            }
        }
        cout << "Customer Not Found" << endl;
    }

    void searchHairstylist(const string& name) {
        for (const auto& hairstylist : hairstylists) {
            if (hairstylist.name == name) {
                cout << "Hairstylist Found:\n";
                cout << "Name: " << hairstylist.name << "\nExpertise: " << hairstylist.expertise << endl;
                return;
            }
        }
        cout << "Hairstylist Not Found" << endl;
    }

    void displayCustomers() {
        cout << "Customers List:\n";
        for (const auto& customer : customers) {
            cout << "Name: " << customer.name << "\nPhone: " << customer.phone << "\nEmail: " << customer.email << "\n\n";
        }
    }

    void displayHairstylists() {
        cout << "Hairstylists List:\n";
        for (const auto& hairstylist : hairstylists) {
            cout << "Name: " << hairstylist.name << "\nExpertise: " << hairstylist.expertise << "\n\n";
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("Alice Smith", "123-456-7890", "alice@example.com");
    salon.addCustomer("Bob Jones", "234-567-8901", "bob@example.com");
    salon.addHairstylist("John Doe", "Hair Coloring");
    salon.addHairstylist("Jane Doe", "Hair Cutting");

    salon.displayCustomers();
    salon.displayHairstylists();

    salon.updateCustomer("Alice Smith", "999-888-7777", "alice.smith@example.com");
    salon.searchCustomer("Alice Smith");

    salon.deleteCustomer("Bob Jones");
    salon.displayCustomers();

    salon.searchHairstylist("Jane Doe");
    salon.updateHairstylist("Jane Doe", "Styling");
    salon.searchHairstylist("Jane Doe");

    salon.deleteHairstylist("John Doe");
    salon.displayHairstylists();

    return 0;
}