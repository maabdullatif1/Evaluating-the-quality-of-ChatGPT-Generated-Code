#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    std::string phone;
};

class Customer : public Person {
public:
    Customer(std::string n, std::string p) {
        name = n;
        phone = p;
    }
};

class Hairstylist : public Person {
public:
    Hairstylist(std::string n, std::string p) {
        name = n;
        phone = p;
    }
};

class Salon {
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

    template<typename T>
    void addPerson(T person, std::vector<T>& container) {
        container.push_back(person);
    }

    template<typename T>
    void deletePerson(std::string name, std::vector<T>& container) {
        for (auto it = container.begin(); it != container.end(); ++it) {
            if (it->name == name) {
                container.erase(it);
                break;
            }
        }
    }

    template<typename T>
    void updatePerson(std::string name, std::string newName, std::string newPhone, std::vector<T>& container) {
        for (auto& person : container) {
            if (person.name == name) {
                person.name = newName;
                person.phone = newPhone;
                break;
            }
        }
    }

    template<typename T>
    T* searchPerson(std::string name, std::vector<T>& container) {
        for (auto& person : container) {
            if (person.name == name) {
                return &person;
            }
        }
        return nullptr;
    }

    template<typename T>
    void displayPersons(const std::vector<T>& container) {
        for (const auto& person : container) {
            std::cout << "Name: " << person.name << ", Phone: " << person.phone << std::endl;
        }
    }

public:
    void addCustomer(std::string name, std::string phone) {
        Customer customer(name, phone);
        addPerson(customer, customers);
    }

    void deleteCustomer(std::string name) {
        deletePerson(name, customers);
    }

    void updateCustomer(std::string name, std::string newName, std::string newPhone) {
        updatePerson(name, newName, newPhone, customers);
    }

    void searchCustomer(std::string name) {
        Customer* customer = searchPerson(name, customers);
        if (customer) {
            std::cout << "Found Customer - Name: " << customer->name << ", Phone: " << customer->phone << std::endl;
        } else {
            std::cout << "Customer not found." << std::endl;
        }
    }

    void displayCustomers() {
        displayPersons(customers);
    }

    void addHairstylist(std::string name, std::string phone) {
        Hairstylist hairstylist(name, phone);
        addPerson(hairstylist, hairstylists);
    }

    void deleteHairstylist(std::string name) {
        deletePerson(name, hairstylists);
    }

    void updateHairstylist(std::string name, std::string newName, std::string newPhone) {
        updatePerson(name, newName, newPhone, hairstylists);
    }

    void searchHairstylist(std::string name) {
        Hairstylist* hairstylist = searchPerson(name, hairstylists);
        if (hairstylist) {
            std::cout << "Found Hairstylist - Name: " << hairstylist->name << ", Phone: " << hairstylist->phone << std::endl;
        } else {
            std::cout << "Hairstylist not found." << std::endl;
        }
    }

    void displayHairstylists() {
        displayPersons(hairstylists);
    }
};

int main() {
    Salon salon;
    salon.addCustomer("Alice", "123456789");
    salon.addCustomer("Bob", "987654321");
    salon.addHairstylist("Charlie", "555555555");
    salon.addHairstylist("Diana", "666666666");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.updateCustomer("Alice", "Alicia", "111111111");
    salon.searchCustomer("Alicia");
    salon.deleteHairstylist("Charlie");
    salon.displayHairstylists();
    return 0;
}