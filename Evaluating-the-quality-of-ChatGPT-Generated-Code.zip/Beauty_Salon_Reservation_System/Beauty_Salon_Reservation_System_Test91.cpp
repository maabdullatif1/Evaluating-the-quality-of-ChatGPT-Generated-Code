#include <iostream>
#include <vector>
#include <string>

struct Person {
    int id;
    std::string name;
    std::string contact;
};

class SalonSystem {
private:
    std::vector<Person> customers;
    std::vector<Person> hairstylists;

    int findPersonIndex(const std::vector<Person>& list, int id) {
        for (size_t i = 0; i < list.size(); ++i) {
            if (list[i].id == id) return i;
        }
        return -1;
    }

    void displayPerson(const Person& person) {
        std::cout << "ID: " << person.id << ", Name: " << person.name 
                  << ", Contact: " << person.contact << std::endl;
    }

public:
    void addCustomer(int id, const std::string& name, const std::string& contact) {
        customers.push_back({id, name, contact});
    }

    void addHairstylist(int id, const std::string& name, const std::string& contact) {
        hairstylists.push_back({id, name, contact});
    }

    void deleteCustomer(int id) {
        int index = findPersonIndex(customers, id);
        if (index != -1) customers.erase(customers.begin() + index);
    }

    void deleteHairstylist(int id) {
        int index = findPersonIndex(hairstylists, id);
        if (index != -1) hairstylists.erase(hairstylists.begin() + index);
    }

    void updateCustomer(int id, const std::string& name, const std::string& contact) {
        int index = findPersonIndex(customers, id);
        if (index != -1) {
            customers[index].name = name;
            customers[index].contact = contact;
        }
    }

    void updateHairstylist(int id, const std::string& name, const std::string& contact) {
        int index = findPersonIndex(hairstylists, id);
        if (index != -1) {
            hairstylists[index].name = name;
            hairstylists[index].contact = contact;
        }
    }

    void searchCustomer(int id) {
        int index = findPersonIndex(customers, id);
        if (index != -1) displayPerson(customers[index]);
        else std::cout << "Customer not found." << std::endl;
    }

    void searchHairstylist(int id) {
        int index = findPersonIndex(hairstylists, id);
        if (index != -1) displayPerson(hairstylists[index]);
        else std::cout << "Hairstylist not found." << std::endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            displayPerson(customer);
        }
    }

    void displayHairstylists() {
        for (const auto& hairstylist : hairstylists) {
            displayPerson(hairstylist);
        }
    }
};

int main() {
    SalonSystem salon;
    salon.addCustomer(1, "Alice", "123456789");
    salon.addHairstylist(1, "Bob", "987654321");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.updateCustomer(1, "Alice Smith", "123123123");
    salon.searchCustomer(1);
    salon.deleteCustomer(1);
    salon.displayCustomers();
    return 0;
}