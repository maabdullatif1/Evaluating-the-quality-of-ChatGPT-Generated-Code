#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Person {
    string name;
    string phone;
};

struct Customer : public Person {
    string email;
};

struct Hairstylist : public Person {
    string specialty;
};

class SalonReservationSystem {
    vector<Customer> customers;
    vector<Hairstylist> hairstylists;
    
public:
    void addCustomer(const string &name, const string &phone, const string &email) {
        customers.push_back({name, phone, email});
    }

    void deleteCustomer(const string &name) {
        for(auto it = customers.begin(); it != customers.end(); ++it) {
            if(it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(const string &name, const string &phone, const string &email) {
        for(auto &customer : customers) {
            if(customer.name == name) {
                customer.phone = phone;
                customer.email = email;
                break;
            }
        }
    }

    Customer* searchCustomer(const string &name) {
        for(auto &customer : customers) {
            if(customer.name == name) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for(const auto &customer : customers) {
            cout << "Name: " << customer.name << ", Phone: " << customer.phone << ", Email: " << customer.email << endl;
        }
    }

    void addHairstylist(const string &name, const string &phone, const string &specialty) {
        hairstylists.push_back({name, phone, specialty});
    }

    void deleteHairstylist(const string &name) {
        for(auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if(it->name == name) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateHairstylist(const string &name, const string &phone, const string &specialty) {
        for(auto &hairstylist : hairstylists) {
            if(hairstylist.name == name) {
                hairstylist.phone = phone;
                hairstylist.specialty = specialty;
                break;
            }
        }
    }

    Hairstylist* searchHairstylist(const string &name) {
        for(auto &hairstylist : hairstylists) {
            if(hairstylist.name == name) {
                return &hairstylist;
            }
        }
        return nullptr;
    }

    void displayHairstylists() {
        for(const auto &hairstylist : hairstylists) {
            cout << "Name: " << hairstylist.name << ", Phone: " << hairstylist.phone << ", Specialty: " << hairstylist.specialty << endl;
        }
    }
};

int main() {
    SalonReservationSystem salon;

    salon.addCustomer("Alice", "12345", "alice@mail.com");
    salon.addCustomer("Bob", "67890", "bob@mail.com");
    salon.displayCustomers();

    salon.addHairstylist("Sarah", "54321", "Cutting");
    salon.addHairstylist("John", "09876", "Coloring");
    salon.displayHairstylists();

    salon.updateCustomer("Alice", "55555", "newalice@mail.com");
    salon.displayCustomers();

    salon.updateHairstylist("Sarah", "11111", "Styling");
    salon.displayHairstylists();

    salon.deleteCustomer("Bob");
    salon.displayCustomers();

    return 0;
}