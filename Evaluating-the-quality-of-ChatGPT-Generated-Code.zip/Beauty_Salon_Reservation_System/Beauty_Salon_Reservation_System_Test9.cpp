#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    int id;
    Person(std::string n, int i) : name(n), id(i) {}
};

class Customer : public Person {
public:
    Customer(std::string n, int i) : Person(n, i) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(std::string n, int i) : Person(n, i) {}
};

class BeautySalon {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

public:
    void addCustomer(std::string name, int id) {
        customers.push_back(Customer(name, id));
    }

    void deleteCustomer(int id) {
        for (size_t i = 0; i < customers.size(); i++) {
            if (customers[i].id == id) {
                customers.erase(customers.begin() + i);
                return;
            }
        }
    }

    void updateCustomer(int id, std::string newName) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = newName;
                return;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "Customer ID: " << customer.id 
                      << ", Name: " << customer.name << std::endl;
        }
    }

    void addHairstylist(std::string name, int id) {
        hairstylists.push_back(Hairstylist(name, id));
    }

    void deleteHairstylist(int id) {
        for (size_t i = 0; i < hairstylists.size(); i++) {
            if (hairstylists[i].id == id) {
                hairstylists.erase(hairstylists.begin() + i);
                return;
            }
        }
    }

    void updateHairstylist(int id, std::string newName) {
        for (auto &hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                hairstylist.name = newName;
                return;
            }
        }
    }

    Hairstylist* searchHairstylist(int id) {
        for (auto &hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                return &hairstylist;
            }
        }
        return nullptr;
    }

    void displayHairstylists() {
        for (const auto &hairstylist : hairstylists) {
            std::cout << "Hairstylist ID: " << hairstylist.id 
                      << ", Name: " << hairstylist.name << std::endl;
        }
    }
};

int main() {
    BeautySalon salon;
    
    salon.addCustomer("Alice", 1);
    salon.addCustomer("Bob", 2);
    salon.displayCustomers();
    
    salon.updateCustomer(1, "Alicia");
    salon.displayCustomers();
    
    salon.deleteCustomer(2);
    salon.displayCustomers();

    salon.addHairstylist("Charlie", 1);
    salon.addHairstylist("Dave", 2);
    salon.displayHairstylists();
    
    salon.updateHairstylist(2, "David");
    salon.displayHairstylists();
    
    salon.deleteHairstylist(1);
    salon.displayHairstylists();

    return 0;
}