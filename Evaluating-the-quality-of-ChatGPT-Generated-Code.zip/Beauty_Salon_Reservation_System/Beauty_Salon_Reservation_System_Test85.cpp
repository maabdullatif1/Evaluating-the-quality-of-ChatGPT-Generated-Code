#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct Hairstylist {
    int id;
    string name;
    string specialization;
};

class BeautySalon {
private:
    Customer customers[100];
    Hairstylist hairstylists[50];
    int customerCount;
    int hairstylistCount;

public:
    BeautySalon() : customerCount(0), hairstylistCount(0) {}

    void addCustomer(int id, string name, string phone) {
        customers[customerCount++] = {id, name, phone};
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; i++) {
            if (customers[i].id == id) {
                for (int j = i; j < customerCount - 1; j++) {
                    customers[j] = customers[j + 1];
                }
                customerCount--;
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string phone) {
        for (int i = 0; i < customerCount; i++) {
            if (customers[i].id == id) {
                customers[i] = {id, name, phone};
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (int i = 0; i < customerCount; i++) {
            if (customers[i].id == id) {
                cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name 
                     << ", Phone: " << customers[i].phone << endl;
                return;
            }
        }
        cout << "Customer not found." << endl;
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; i++) {
            cout << "ID: " << customers[i].id << ", Name: " << customers[i].name 
                 << ", Phone: " << customers[i].phone << endl;
        }
    }

    void addHairstylist(int id, string name, string specialization) {
        hairstylists[hairstylistCount++] = {id, name, specialization};
    }

    void deleteHairstylist(int id) {
        for (int i = 0; i < hairstylistCount; i++) {
            if (hairstylists[i].id == id) {
                for (int j = i; j < hairstylistCount - 1; j++) {
                    hairstylists[j] = hairstylists[j + 1];
                }
                hairstylistCount--;
                break;
            }
        }
    }

    void updateHairstylist(int id, string name, string specialization) {
        for (int i = 0; i < hairstylistCount; i++) {
            if (hairstylists[i].id == id) {
                hairstylists[i] = {id, name, specialization};
                break;
            }
        }
    }

    void searchHairstylist(int id) {
        for (int i = 0; i < hairstylistCount; i++) {
            if (hairstylists[i].id == id) {
                cout << "Hairstylist ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name
                     << ", Specialization: " << hairstylists[i].specialization << endl;
                return;
            }
        }
        cout << "Hairstylist not found." << endl;
    }

    void displayHairstylists() {
        for (int i = 0; i < hairstylistCount; i++) {
            cout << "ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name
                 << ", Specialization: " << hairstylists[i].specialization << endl;
        }
    }
};

int main() {
    BeautySalon salon;
    salon.addCustomer(1, "Alice", "1234567890");
    salon.addHairstylist(1, "Bob", "Coloring");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.searchCustomer(1);
    salon.searchHairstylist(1);
    salon.updateCustomer(1, "Alice Green", "0987654321");
    salon.updateHairstylist(1, "Bob Brown", "Cutting");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.deleteCustomer(1);
    salon.deleteHairstylist(1);
    salon.displayCustomers();
    salon.displayHairstylists();
    return 0;
}