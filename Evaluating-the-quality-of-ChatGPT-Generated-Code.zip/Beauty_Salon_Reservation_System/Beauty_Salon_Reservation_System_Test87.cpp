#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string contact;
};

struct Hairstylist {
    int id;
    string name;
    string specialty;
};

vector<Customer> customers;
vector<Hairstylist> hairstylists;

void addCustomer(int id, string name, string contact) {
    customers.push_back({id, name, contact});
}

void deleteCustomer(int id) {
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            break;
        }
    }
}

void updateCustomer(int id, string name, string contact) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            customer.name = name;
            customer.contact = contact;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            return &customer;
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (const auto& customer : customers) {
        cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
    }
}

void addHairstylist(int id, string name, string specialty) {
    hairstylists.push_back({id, name, specialty});
}

void deleteHairstylist(int id) {
    for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
        if (it->id == id) {
            hairstylists.erase(it);
            break;
        }
    }
}

void updateHairstylist(int id, string name, string specialty) {
    for (auto& hairstylist : hairstylists) {
        if (hairstylist.id == id) {
            hairstylist.name = name;
            hairstylist.specialty = specialty;
            break;
        }
    }
}

Hairstylist* searchHairstylist(int id) {
    for (auto& hairstylist : hairstylists) {
        if (hairstylist.id == id) {
            return &hairstylist;
        }
    }
    return nullptr;
}

void displayHairstylists() {
    for (const auto& hairstylist : hairstylists) {
        cout << "ID: " << hairstylist.id << ", Name: " << hairstylist.name << ", Specialty: " << hairstylist.specialty << endl;
    }
}

int main() {
    addCustomer(1, "Alice", "123-456-7890");
    addCustomer(2, "Bob", "987-654-3210");
    updateCustomer(2, "Bob", "555-555-5555");
    displayCustomers();
    
    addHairstylist(1, "Charlie", "Coloring");
    addHairstylist(2, "Dave", "Cutting");
    updateHairstylist(2, "Dave", "Styling");
    displayHairstylists();
    
    Customer* c = searchCustomer(1);
    if (c) cout << "Found customer: " << c->name << endl;
    
    Hairstylist* h = searchHairstylist(1);
    if (h) cout << "Found hairstylist: " << h->name << endl;
    
    deleteCustomer(1);
    deleteHairstylist(1);
    
    displayCustomers();
    displayHairstylists();
    
    return 0;
}