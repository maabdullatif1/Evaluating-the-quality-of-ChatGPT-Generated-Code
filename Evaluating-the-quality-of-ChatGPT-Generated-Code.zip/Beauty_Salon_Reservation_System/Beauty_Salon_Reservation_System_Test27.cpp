#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    string name;
    string phone;

    Customer(string name, string phone) : name(name), phone(phone) {}
};

class Hairstylist {
public:
    string name;
    string expertise;

    Hairstylist(string name, string expertise) : name(name), expertise(expertise) {}
};

class Salon {
private:
    vector<Customer> customers;
    vector<Hairstylist> hairstylists;

public:
    void addCustomer(string name, string phone) {
        customers.push_back(Customer(name, phone));
    }

    void deleteCustomer(string name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(string oldName, string newName, string newPhone) {
        for (auto &customer : customers) {
            if (customer.name == oldName) {
                customer.name = newName;
                customer.phone = newPhone;
                break;
            }
        }
    }

    Customer* searchCustomer(string name) {
        for (auto &customer : customers) {
            if (customer.name == name) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "Name: " << customer.name << ", Phone: " << customer.phone << endl;
        }
    }

    void addHairstylist(string name, string expertise) {
        hairstylists.push_back(Hairstylist(name, expertise));
    }

    void deleteHairstylist(string name) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->name == name) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateHairstylist(string oldName, string newName, string newExpertise) {
        for (auto &hairstylist : hairstylists) {
            if (hairstylist.name == oldName) {
                hairstylist.name = newName;
                hairstylist.expertise = newExpertise;
                break;
            }
        }
    }

    Hairstylist* searchHairstylist(string name) {
        for (auto &hairstylist : hairstylists) {
            if (hairstylist.name == name) {
                return &hairstylist;
            }
        }
        return nullptr;
    }

    void displayHairstylists() {
        for (const auto &hairstylist : hairstylists) {
            cout << "Name: " << hairstylist.name << ", Expertise: " << hairstylist.expertise << endl;
        }
    }
};

int main() {
    Salon salon;

    salon.addCustomer("Alice", "1234567890");
    salon.addCustomer("Bob", "0987654321");
    salon.addHairstylist("Charlie", "Haircut");
    salon.addHairstylist("Dave", "Coloring");

    salon.displayCustomers();
    salon.displayHairstylists();

    salon.updateCustomer("Alice", "Alice Smith", "1122334455");
    salon.updateHairstylist("Charlie", "Charlie Brown", "Styling");

    salon.displayCustomers();
    salon.displayHairstylists();

    salon.deleteCustomer("Bob");
    salon.deleteHairstylist("Dave");

    salon.displayCustomers();
    salon.displayHairstylists();

    return 0;
}