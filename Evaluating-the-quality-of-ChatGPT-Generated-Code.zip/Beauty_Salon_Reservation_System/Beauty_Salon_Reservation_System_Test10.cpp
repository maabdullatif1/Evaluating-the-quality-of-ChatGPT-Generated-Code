#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    int id;
    string name;
    string contact;
};

class BeautySalon {
    vector<Person> customers;
    vector<Person> hairstylists;
    
    vector<Person>& getCollection(char type) {
        return (type == 'C') ? customers : hairstylists;
    }

    void addPerson(char type) {
        Person person;
        cout << "Enter ID: ";
        cin >> person.id;
        cout << "Enter Name: ";
        cin >> person.name;
        cout << "Enter Contact: ";
        cin >> person.contact;
        getCollection(type).push_back(person);
    }

    void deletePerson(char type) {
        int id;
        cout << "Enter ID to delete: ";
        cin >> id;
        auto& list = getCollection(type);
        for (auto it = list.begin(); it != list.end(); ++it) {
            if (it->id == id) {
                list.erase(it);
                return;
            }
        }
    }

    void updatePerson(char type) {
        int id;
        cout << "Enter ID to update: ";
        cin >> id;
        auto& list = getCollection(type);
        for (auto& person : list) {
            if (person.id == id) {
                cout << "Enter new Name: ";
                cin >> person.name;
                cout << "Enter new Contact: ";
                cin >> person.contact;
                return;
            }
        }
    }

    void searchPerson(char type) {
        int id;
        cout << "Enter ID to search: ";
        cin >> id;
        auto& list = getCollection(type);
        for (const auto& person : list) {
            if (person.id == id) {
                cout << "ID: " << person.id << ", Name: " << person.name << ", Contact: " << person.contact << endl;
                return;
            }
        }
    }

    void displayPeople(char type) {
        auto& list = getCollection(type);
        for (const auto& person : list) {
            cout << "ID: " << person.id << ", Name: " << person.name << ", Contact: " << person.contact << endl;
        }
    }

public:
    void menu() {
        int choice;
        char type;
        
        while (true) {
            cout << "1. Add Customer\n2. Delete Customer\n3. Update Customer\n4. Search Customer\n5. Display Customers\n"
                 << "6. Add Hairstylist\n7. Delete Hairstylist\n8. Update Hairstylist\n9. Search Hairstylist\n10. Display Hairstylists\n11. Exit\n";
            cout << "Enter choice: ";
            cin >> choice;

            if (choice >= 1 && choice <= 5) type = 'C';
            else if (choice >= 6 && choice <= 10) type = 'H';

            switch (choice) {
                case 1: addPerson(type); break;
                case 2: deletePerson(type); break;
                case 3: updatePerson(type); break;
                case 4: searchPerson(type); break;
                case 5: displayPeople(type); break;
                case 6: addPerson(type); break;
                case 7: deletePerson(type); break;
                case 8: updatePerson(type); break;
                case 9: searchPerson(type); break;
                case 10: displayPeople(type); break;
                case 11: return;
                default: cout << "Invalid choice\n"; break;
            }
        }
    }
};

int main() {
    BeautySalon salon;
    salon.menu();
    return 0;
}