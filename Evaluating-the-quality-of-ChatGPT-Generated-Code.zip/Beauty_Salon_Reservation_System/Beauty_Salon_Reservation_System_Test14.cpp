#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    std::string phone;

public:
    Person(const std::string& n, const std::string& p) : name(n), phone(p) {}

    std::string getName() const { return name; }
    std::string getPhone() const { return phone; }
    
    void setName(const std::string& n) { name = n; }
    void setPhone(const std::string& p) { phone = p; }
};

class Customer : public Person {
public:
    Customer(const std::string& n, const std::string& p) : Person(n, p) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(const std::string& n, const std::string& p) : Person(n, p) {}
};

template <typename T>
class ManagementSystem {
private:
    std::vector<T> records;

public:
    void addRecord(const T& record) {
        records.push_back(record);
    }

    void deleteRecord(const std::string& name) {
        for (auto it = records.begin(); it != records.end(); ++it) {
            if (it->getName() == name) {
                records.erase(it);
                break;
            }
        }
    }

    void updateRecord(const std::string& name, const std::string& new_name, const std::string& new_phone) {
        for (auto& record : records) {
            if (record.getName() == name) {
                record.setName(new_name);
                record.setPhone(new_phone);
                break;
            }
        }
    }

    T* searchRecord(const std::string& name) {
        for (auto& record : records) {
            if (record.getName() == name) {
                return &record;
            }
        }
        return nullptr;
    }

    void displayRecords() const {
        for (const auto& record : records) {
            std::cout << "Name: " << record.getName() << ", Phone: " << record.getPhone() << std::endl;
        }
    }
};

int main() {
    ManagementSystem<Customer> customerManagement;
    ManagementSystem<Hairstylist> hairstylistManagement;

    Customer c1("Alice", "1234567890");
    Customer c2("Bob", "0987654321");
    customerManagement.addRecord(c1);
    customerManagement.addRecord(c2);

    Hairstylist h1("Charles", "5556667777");
    Hairstylist h2("Diana", "7778889999");
    hairstylistManagement.addRecord(h1);
    hairstylistManagement.addRecord(h2);

    customerManagement.updateRecord("Alice", "Alice Smith", "1112131415");
    hairstylistManagement.deleteRecord("Diana");

    Customer* searchResult = customerManagement.searchRecord("Bob");
    if (searchResult) {
        std::cout << "Found customer: " << searchResult->getName() << ", " << searchResult->getPhone() << std::endl;
    }

    std::cout << "Customers:" << std::endl;
    customerManagement.displayRecords();

    std::cout << "Hairstylists:" << std::endl;
    hairstylistManagement.displayRecords();

    return 0;
}