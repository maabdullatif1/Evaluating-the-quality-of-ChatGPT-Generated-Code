#include <iostream>
#include <string>
#include <vector>

class Person {
public:
    std::string name;
    std::string phone;
};

class Customer : public Person {
public:
    int id;
};

class Hairstylist : public Person {
public:
    int id;
};

class Salon {
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

public:
    void addCustomer(const Customer& customer) {
        customers.push_back(customer);
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& phone) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phone = phone;
                break;
            }
        }
    }
    
    void searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer ID: " << customer.id << "\n";
                std::cout << "Name: " << customer.name << "\n";
                std::cout << "Phone: " << customer.phone << "\n";
                break;
            }
        }
    }

    void displayCustomers() {
        for (auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << "\n";
            std::cout << "Name: " << customer.name << "\n";
            std::cout << "Phone: " << customer.phone << "\n";
        }
    }

    void addHairstylist(const Hairstylist& hairstylist) {
        hairstylists.push_back(hairstylist);
    }
    
    void deleteHairstylist(int id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->id == id) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateHairstylist(int id, const std::string& name, const std::string& phone) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                hairstylist.name = name;
                hairstylist.phone = phone;
                break;
            }
        }
    }
    
    void searchHairstylist(int id) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                std::cout << "Hairstylist ID: " << hairstylist.id << "\n";
                std::cout << "Name: " << hairstylist.name << "\n";
                std::cout << "Phone: " << hairstylist.phone << "\n";
                break;
            }
        }
    }

    void displayHairstylists() {
        for (auto& hairstylist : hairstylists) {
            std::cout << "Hairstylist ID: " << hairstylist.id << "\n";
            std::cout << "Name: " << hairstylist.name << "\n";
            std::cout << "Phone: " << hairstylist.phone << "\n";
        }
    }
};

int main() {
    Salon salon;

    Customer customer1;
    customer1.id = 1;
    customer1.name = "Alice";
    customer1.phone = "111-222-3333";
    salon.addCustomer(customer1);

    Hairstylist hairstylist1;
    hairstylist1.id = 1;
    hairstylist1.name = "Bob";
    hairstylist1.phone = "444-555-6666";
    salon.addHairstylist(hairstylist1);

    salon.displayCustomers();
    salon.displayHairstylists();

    return 0;
}