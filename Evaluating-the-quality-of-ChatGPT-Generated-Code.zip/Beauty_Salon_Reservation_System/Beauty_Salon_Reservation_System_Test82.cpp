#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    std::string contact;
    
    Person(std::string n, std::string c) : name(n), contact(c) {}
};

class Customer : public Person {
public:
    Customer(std::string n, std::string c) : Person(n, c) {}
};

class Hairstylist : public Person {
public:
    std::string speciality;
    
    Hairstylist(std::string n, std::string c, std::string s) : Person(n, c), speciality(s) {}
};

class Salon {
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

public:
    void addCustomer(std::string name, std::string contact) {
        customers.push_back(Customer(name, contact));
    }
    
    void deleteCustomer(std::string name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(std::string oldName, std::string newName, std::string newContact) {
        for (auto& customer : customers) {
            if (customer.name == oldName) {
                customer.name = newName;
                customer.contact = newContact;
                break;
            }
        }
    }
    
    void searchCustomer(std::string name) {
        for (const auto& customer : customers) {
            if (customer.name == name) {
                std::cout << "Found: " << customer.name << ", " << customer.contact << "\n";
                return;
            }
        }
        std::cout << "Customer not found\n";
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << customer.name << ", " << customer.contact << "\n";
        }
    }
    
    void addHairstylist(std::string name, std::string contact, std::string speciality) {
        hairstylists.push_back(Hairstylist(name, contact, speciality));
    }
    
    void deleteHairstylist(std::string name) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->name == name) {
                hairstylists.erase(it);
                break;
            }
        }
    }
    
    void updateHairstylist(std::string oldName, std::string newName, std::string newContact, std::string newSpeciality) {
        for (auto& stylist : hairstylists) {
            if (stylist.name == oldName) {
                stylist.name = newName;
                stylist.contact = newContact;
                stylist.speciality = newSpeciality;
                break;
            }
        }
    }
    
    void searchHairstylist(std::string name) {
        for (const auto& stylist : hairstylists) {
            if (stylist.name == name) {
                std::cout << "Found: " << stylist.name << ", " << stylist.contact << ", " << stylist.speciality << "\n";
                return;
            }
        }
        std::cout << "Hairstylist not found\n";
    }

    void displayHairstylists() {
        for (const auto& stylist : hairstylists) {
            std::cout << stylist.name << ", " << stylist.contact << ", " << stylist.speciality << "\n";
        }
    }
};

int main() {
    Salon salon;
    
    salon.addCustomer("Alice", "123456789");
    salon.addCustomer("Bob", "987654321");
    salon.displayCustomers();
    
    salon.addHairstylist("Eve", "543216789", "Cuts");
    salon.addHairstylist("Mallory", "321678945", "Coloring");
    salon.displayHairstylists();
    
    salon.searchCustomer("Alice");
    salon.searchHairstylist("Eve");
    
    salon.updateCustomer("Alice", "Alice Wonderland", "123000000");
    salon.displayCustomers();
    
    salon.updateHairstylist("Eve", "Eve Adams", "543210000", "All-Rounder");
    salon.displayHairstylists();
    
    salon.deleteCustomer("Bob");
    salon.displayCustomers();
    
    salon.deleteHairstylist("Mallory");
    salon.displayHairstylists();
    
    return 0;
}