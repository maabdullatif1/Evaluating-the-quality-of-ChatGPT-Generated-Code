#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Car {
    string carID;
    string model;
    string owner;
    string insuranceCompanyID;
};

struct InsuranceCompany {
    string companyID;
    string name;
};

class InsuranceService {
private:
    vector<Car> cars;
    vector<InsuranceCompany> companies;

    int findCarIndex(const string &carID) {
        for (int i = 0; i < cars.size(); ++i) {
            if (cars[i].carID == carID) return i;
        }
        return -1;
    }

    int findCompanyIndex(const string &companyID) {
        for (int i = 0; i < companies.size(); ++i) {
            if (companies[i].companyID == companyID) return i;
        }
        return -1;
    }

public:
    void addCar(const string &carID, const string &model, const string &owner, const string &insuranceCompanyID) {
        if (findCarIndex(carID) == -1) {
            cars.push_back(Car{carID, model, owner, insuranceCompanyID});
        }
    }

    void deleteCar(const string &carID) {
        int index = findCarIndex(carID);
        if (index != -1) {
            cars.erase(cars.begin() + index);
        }
    }

    void updateCar(const string &carID, const string &model, const string &owner, const string &insuranceCompanyID) {
        int index = findCarIndex(carID);
        if (index != -1) {
            cars[index].model = model;
            cars[index].owner = owner;
            cars[index].insuranceCompanyID = insuranceCompanyID;
        }
    }

    Car* searchCar(const string &carID) {
        int index = findCarIndex(carID);
        return index != -1 ? &cars[index] : nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "CarID: " << car.carID << ", Model: " << car.model << ", Owner: " << car.owner
                 << ", InsuranceCompany: " << car.insuranceCompanyID << endl;
        }
    }

    void addInsuranceCompany(const string &companyID, const string &name) {
        if (findCompanyIndex(companyID) == -1) {
            companies.push_back(InsuranceCompany{companyID, name});
        }
    }

    void deleteInsuranceCompany(const string &companyID) {
        int index = findCompanyIndex(companyID);
        if (index != -1) {
            companies.erase(companies.begin() + index);
        }
    }

    void updateInsuranceCompany(const string &companyID, const string &name) {
        int index = findCompanyIndex(companyID);
        if (index != -1) {
            companies[index].name = name;
        }
    }

    InsuranceCompany* searchInsuranceCompany(const string &companyID) {
        int index = findCompanyIndex(companyID);
        return index != -1 ? &companies[index] : nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto &company : companies) {
            cout << "CompanyID: " << company.companyID << ", Name: " << company.name << endl;
        }
    }
};

int main() {
    InsuranceService service;
    service.addCar("C01", "Toyota", "Alice", "IC01");
    service.addCar("C02", "Honda", "Bob", "IC02");
    service.addInsuranceCompany("IC01", "InsureCo");
    service.addInsuranceCompany("IC02", "SafeGuard");

    service.displayCars();
    service.displayInsuranceCompanies();

    Car* car = service.searchCar("C01");
    if (car) {
        cout << "Found Car: " << car->carID << endl;
    }

    InsuranceCompany* company = service.searchInsuranceCompany("IC01");
    if (company) {
        cout << "Found Company: " << company->name << endl;
    }

    return 0;
}