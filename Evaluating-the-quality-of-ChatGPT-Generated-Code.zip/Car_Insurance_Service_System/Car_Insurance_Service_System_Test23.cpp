#include <iostream>
#include <cstring>

const int MAX_CARS = 100;
const int MAX_COMPANIES = 50;

struct Car {
    int id;
    char owner[50];
    char model[50];
    int year;
};

struct InsuranceCompany {
    int id;
    char name[50];
    char address[100];
};

Car cars[MAX_CARS];
InsuranceCompany companies[MAX_COMPANIES];
int car_count = 0;
int company_count = 0;

void addCar(int id, const char* owner, const char* model, int year) {
    if(car_count < MAX_CARS) {
        cars[car_count].id = id;
        strcpy(cars[car_count].owner, owner);
        strcpy(cars[car_count].model, model);
        cars[car_count].year = year;
        car_count++;
    }
}

void deleteCar(int id) {
    for(int i = 0; i < car_count; ++i) {
        if(cars[i].id == id) {
            for(int j = i; j < car_count - 1; ++j) {
                cars[j] = cars[j + 1];
            }
            car_count--;
            break;
        }
    }
}

void updateCar(int id, const char* owner, const char* model, int year) {
    for(int i = 0; i < car_count; ++i) {
        if(cars[i].id == id) {
            strcpy(cars[i].owner, owner);
            strcpy(cars[i].model, model);
            cars[i].year = year;
            break;
        }
    }
}

Car* searchCar(int id) {
    for(int i = 0; i < car_count; ++i) {
        if(cars[i].id == id) {
            return &cars[i];
        }
    }
    return nullptr;
}

void displayCars() {
    for(int i = 0; i < car_count; ++i) {
        std::cout << "Car ID: " << cars[i].id
                  << ", Owner: " << cars[i].owner
                  << ", Model: " << cars[i].model
                  << ", Year: " << cars[i].year << std::endl;
    }
}

void addCompany(int id, const char* name, const char* address) {
    if(company_count < MAX_COMPANIES) {
        companies[company_count].id = id;
        strcpy(companies[company_count].name, name);
        strcpy(companies[company_count].address, address);
        company_count++;
    }
}

void deleteCompany(int id) {
    for(int i = 0; i < company_count; ++i) {
        if(companies[i].id == id) {
            for(int j = i; j < company_count - 1; ++j) {
                companies[j] = companies[j + 1];
            }
            company_count--;
            break;
        }
    }
}

void updateCompany(int id, const char* name, const char* address) {
    for(int i = 0; i < company_count; ++i) {
        if(companies[i].id == id) {
            strcpy(companies[i].name, name);
            strcpy(companies[i].address, address);
            break;
        }
    }
}

InsuranceCompany* searchCompany(int id) {
    for(int i = 0; i < company_count; ++i) {
        if(companies[i].id == id) {
            return &companies[i];
        }
    }
    return nullptr;
}

void displayCompanies() {
    for(int i = 0; i < company_count; ++i) {
        std::cout << "Company ID: " << companies[i].id
                  << ", Name: " << companies[i].name
                  << ", Address: " << companies[i].address << std::endl;
    }
}

int main() {
    addCar(1, "John Doe", "Toyota Camry", 2020);
    addCompany(1, "ABC Insurance", "123 Main St");
    displayCars();
    displayCompanies();
    return 0;
}