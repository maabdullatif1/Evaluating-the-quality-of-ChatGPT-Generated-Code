#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string make;
    std::string model;
    
    Car(std::string lp, std::string mk, std::string md) 
        : licensePlate(lp), make(mk), model(md) {}
};

class InsuranceCompany {
public:
    std::string companyName;
    std::string policyNumber;
    
    InsuranceCompany(std::string cn, std::string pn) 
        : companyName(cn), policyNumber(pn) {}
};

std::vector<Car> cars;
std::vector<InsuranceCompany> insuranceCompanies;

void addCar() {
    std::string lp, mk, md;
    std::cout << "Enter license plate: ";
    std::cin >> lp;
    std::cout << "Enter make: ";
    std::cin >> mk;
    std::cout << "Enter model: ";
    std::cin >> md;
    cars.push_back(Car(lp, mk, md));
}

void deleteCar() {
    std::string lp;
    std::cout << "Enter license plate to delete: ";
    std::cin >> lp;
    for (auto it = cars.begin(); it != cars.end(); ++it) {
        if (it->licensePlate == lp) {
            cars.erase(it);
            break;
        }
    }
}

void updateCar() {
    std::string lp, mk, md;
    std::cout << "Enter license plate to update: ";
    std::cin >> lp;
    for (auto &car : cars) {
        if (car.licensePlate == lp) {
            std::cout << "Enter new make: ";
            std::cin >> mk;
            std::cout << "Enter new model: ";
            std::cin >> md;
            car.make = mk;
            car.model = md;
            break;
        }
    }
}

void searchCar() {
    std::string lp;
    std::cout << "Enter license plate to search: ";
    std::cin >> lp;
    for (const auto &car : cars) {
        if (car.licensePlate == lp) {
            std::cout << "Car Found: " << car.licensePlate << ", " << car.make << ", " << car.model << '\n';
            return;
        }
    }
    std::cout << "Car not found.\n";
}

void displayCars() {
    std::cout << "Cars:\n";
    for (const auto &car : cars) {
        std::cout << car.licensePlate << ", " << car.make << ", " << car.model << '\n';
    }
}

void addInsuranceCompany() {
    std::string cn, pn;
    std::cout << "Enter company name: ";
    std::cin >> cn;
    std::cout << "Enter policy number: ";
    std::cin >> pn;
    insuranceCompanies.push_back(InsuranceCompany(cn, pn));
}

void deleteInsuranceCompany() {
    std::string cn;
    std::cout << "Enter company name to delete: ";
    std::cin >> cn;
    for (auto it = insuranceCompanies.begin(); it != insuranceCompanies.end(); ++it) {
        if (it->companyName == cn) {
            insuranceCompanies.erase(it);
            break;
        }
    }
}

void updateInsuranceCompany() {
    std::string cn, pn;
    std::cout << "Enter company name to update: ";
    std::cin >> cn;
    for (auto &company : insuranceCompanies) {
        if (company.companyName == cn) {
            std::cout << "Enter new policy number: ";
            std::cin >> pn;
            company.policyNumber = pn;
            break;
        }
    }
}

void searchInsuranceCompany() {
    std::string cn;
    std::cout << "Enter company name to search: ";
    std::cin >> cn;
    for (const auto &company : insuranceCompanies) {
        if (company.companyName == cn) {
            std::cout << "Company Found: " << company.companyName << ", " << company.policyNumber << '\n';
            return;
        }
    }
    std::cout << "Company not found.\n";
}

void displayInsuranceCompanies() {
    std::cout << "Insurance Companies:\n";
    for (const auto &company : insuranceCompanies) {
        std::cout << company.companyName << ", " << company.policyNumber << '\n';
    }
}

int main() {
    int choice;
    while (true) {
        std::cout << "\n1. Add Car\n2. Delete Car\n3. Update Car\n4. Search Car\n5. Display Cars\n";
        std::cout << "6. Add Insurance Company\n7. Delete Insurance Company\n";
        std::cout << "8. Update Insurance Company\n9. Search Insurance Company\n10. Display Insurance Companies\n";
        std::cout << "0. Exit\nChoose an option: ";
        std::cin >> choice;
        switch (choice) {
            case 1: addCar(); break;
            case 2: deleteCar(); break;
            case 3: updateCar(); break;
            case 4: searchCar(); break;
            case 5: displayCars(); break;
            case 6: addInsuranceCompany(); break;
            case 7: deleteInsuranceCompany(); break;
            case 8: updateInsuranceCompany(); break;
            case 9: searchInsuranceCompany(); break;
            case 10: displayInsuranceCompanies(); break;
            case 0: return 0;
            default: std::cout << "Invalid choice\n";
        }
    }
}