#include <iostream>
#include <string>
#include <vector>

using namespace std;

class InsuranceCompany {
public:
    string name;
    string address;
    void display() {
        cout << "Insurance Company: " << name << ", Address: " << address << endl;
    }
};

class Car {
public:
    string make;
    string model;
    int year;
    string owner;
    string insuranceCompany;
    void display() {
        cout << "Car: " << make << " " << model << ", Year: " << year 
             << ", Owner: " << owner << ", Insurance: " << insuranceCompany << endl;
    }
};

class InsuranceServiceSystem {
private:
    vector<Car> cars;
    vector<InsuranceCompany> insuranceCompanies;

public:
    void addCar(const Car& car) {
        cars.push_back(car);
    }

    void deleteCar(const string& owner) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->owner == owner) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const string& owner, const Car& newCar) {
        for (auto& car : cars) {
            if (car.owner == owner) {
                car = newCar;
                break;
            }
        }
    }

    void searchCar(const string& owner) {
        for (const auto& car : cars) {
            if (car.owner == owner) {
                car.display();
                return;
            }
        }
        cout << "Car not found for owner: " << owner << endl;
    }

    void displayCars() {
        for (const auto& car : cars) {
            car.display();
        }
    }

    void addInsuranceCompany(const InsuranceCompany& company) {
        insuranceCompanies.push_back(company);
    }

    void deleteInsuranceCompany(const string& name) {
        for (auto it = insuranceCompanies.begin(); it != insuranceCompanies.end(); ++it) {
            if (it->name == name) {
                insuranceCompanies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(const string& name, const InsuranceCompany& newCompany) {
        for (auto& company : insuranceCompanies) {
            if (company.name == name) {
                company = newCompany;
                break;
            }
        }
    }

    void searchInsuranceCompany(const string& name) {
        for (const auto& company : insuranceCompanies) {
            if (company.name == name) {
                company.display();
                return;
            }
        }
        cout << "Insurance Company not found: " << name << endl;
    }

    void displayInsuranceCompanies() {
        for (const auto& company : insuranceCompanies) {
            company.display();
        }
    }
};

int main() {
    InsuranceServiceSystem system;

    Car car1 = {"Toyota", "Camry", 2020, "John Doe", "InsureIt"};
    Car car2 = {"Ford", "Focus", 2018, "Jane Smith", "SecureCo"};
    system.addCar(car1);
    system.addCar(car2);

    InsuranceCompany company1 = {"InsureIt", "123 Elm St"};
    InsuranceCompany company2 = {"SecureCo", "456 Oak St"};
    system.addInsuranceCompany(company1);
    system.addInsuranceCompany(company2);

    cout << "Display Cars:\n";
    system.displayCars();
    cout << "\nDisplay Insurance Companies:\n";
    system.displayInsuranceCompanies();

    cout << "\nSearch Car by owner 'John Doe':\n";
    system.searchCar("John Doe");

    cout << "\nSearch Insurance Company 'InsureIt':\n";
    system.searchInsuranceCompany("InsureIt");

    return 0;
}