#include <iostream>
#include <string>
#include <vector>

using namespace std;

class InsuranceCompany {
public:
    string companyName;
    string companyID;

    InsuranceCompany(string name, string id) : companyName(name), companyID(id) {}
};

class Car {
public:
    string carModel;
    string ownerName;
    string licensePlate;
    string insuranceCompanyID;

    Car(string model, string owner, string plate, string insuranceID) 
        : carModel(model), ownerName(owner), licensePlate(plate), insuranceCompanyID(insuranceID) {}
};

class CarInsuranceService {
private:
    vector<Car> cars;
    vector<InsuranceCompany> companies;

public:
    void addCar(string model, string owner, string plate, string insuranceID) {
        cars.push_back(Car(model, owner, plate, insuranceID));
    }

    void deleteCar(string plate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == plate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(string plate, string newModel, string newOwner, string newInsuranceID) {
        for (auto &car : cars) {
            if (car.licensePlate == plate) {
                car.carModel = newModel;
                car.ownerName = newOwner;
                car.insuranceCompanyID = newInsuranceID;
                break;
            }
        }
    }

    Car* searchCar(string plate) {
        for (auto &car : cars) {
            if (car.licensePlate == plate) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (auto &car : cars) {
            cout << "Model: " << car.carModel << ", Owner: " << car.ownerName 
                 << ", Plate: " << car.licensePlate << ", Insurance Co ID: " << car.insuranceCompanyID << endl;
        }
    }

    void addInsuranceCompany(string name, string id) {
        companies.push_back(InsuranceCompany(name, id));
    }

    void deleteInsuranceCompany(string id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->companyID == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(string id, string newName) {
        for (auto &company : companies) {
            if (company.companyID == id) {
                company.companyName = newName;
                break;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(string id) {
        for (auto &company : companies) {
            if (company.companyID == id) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (auto &company : companies) {
            cout << "Company Name: " << company.companyName 
                 << ", Company ID: " << company.companyID << endl;
        }
    }
};

int main() {
    CarInsuranceService service;
    service.addInsuranceCompany("InsureCo", "123");
    service.addCar("Toyota", "Alice", "ABC123", "123");
    service.displayCars();
    service.displayInsuranceCompanies();

    return 0;
}