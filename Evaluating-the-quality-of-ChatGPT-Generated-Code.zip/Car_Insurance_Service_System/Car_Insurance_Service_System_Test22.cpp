#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Car {
public:
    string model;
    string licensePlate;
    int year;

    Car(string m, string l, int y) : model(m), licensePlate(l), year(y) {}
};

class InsuranceCompany {
public:
    string name;
    string policyNumber;

    InsuranceCompany(string n, string p) : name(n), policyNumber(p) {}
};

class InsuranceService {
    vector<Car> cars;
    vector<InsuranceCompany> companies;

    int findCarIndex(const string& licensePlate) {
        for (int i = 0; i < cars.size(); ++i) {
            if (cars[i].licensePlate == licensePlate) {
                return i;
            }
        }
        return -1;
    }

    int findCompanyIndex(const string& policyNumber) {
        for (int i = 0; i < companies.size(); ++i) {
            if (companies[i].policyNumber == policyNumber) {
                return i;
            }
        }
        return -1;
    }

public:
    void addCar(const Car& car) {
        cars.push_back(car);
    }

    void deleteCar(const string& licensePlate) {
        int index = findCarIndex(licensePlate);
        if (index != -1) {
            cars.erase(cars.begin() + index);
        }
    }

    void updateCar(const string& licensePlate, const Car& newCar) {
        int index = findCarIndex(licensePlate);
        if (index != -1) {
            cars[index] = newCar;
        }
    }

    void displayCars() {
        for (const Car& car : cars) {
            cout << "Model: " << car.model << ", License Plate: " << car.licensePlate << ", Year: " << car.year << endl;
        }
    }

    Car* searchCar(const string& licensePlate) {
        int index = findCarIndex(licensePlate);
        if (index != -1) {
            return &cars[index];
        }
        return nullptr;
    }

    void addCompany(const InsuranceCompany& company) {
        companies.push_back(company);
    }

    void deleteCompany(const string& policyNumber) {
        int index = findCompanyIndex(policyNumber);
        if (index != -1) {
            companies.erase(companies.begin() + index);
        }
    }

    void updateCompany(const string& policyNumber, const InsuranceCompany& newCompany) {
        int index = findCompanyIndex(policyNumber);
        if (index != -1) {
            companies[index] = newCompany;
        }
    }

    void displayCompanies() {
        for (const InsuranceCompany& company : companies) {
            cout << "Name: " << company.name << ", Policy Number: " << company.policyNumber << endl;
        }
    }

    InsuranceCompany* searchCompany(const string& policyNumber) {
        int index = findCompanyIndex(policyNumber);
        if (index != -1) {
            return &companies[index];
        }
        return nullptr;
    }
};

int main() {
    InsuranceService service;

    service.addCar(Car("Toyota Camry", "ABC123", 2012));
    service.addCar(Car("Honda Accord", "XYZ987", 2015));

    service.addCompany(InsuranceCompany("Progressive", "POL123"));
    service.addCompany(InsuranceCompany("Geico", "POL456"));

    cout << "Cars:" << endl;
    service.displayCars();

    cout << "\nInsurance Companies:" << endl;
    service.displayCompanies();

    Car* car = service.searchCar("ABC123");
    if (car) {
        cout << "\nFound car: " << car->model << endl;
    }

    InsuranceCompany* company = service.searchCompany("POL123");
    if (company) {
        cout << "Found insurance company: " << company->name << endl;
    }

    service.deleteCar("XYZ987");
    service.deleteCompany("POL456");

    cout << "\nAfter deletion:" << endl;
    service.displayCars();
    service.displayCompanies();

    return 0;
}