#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    string licensePlate;
    string ownerName;

    Car(string lp, string owner) : licensePlate(lp), ownerName(owner) {}
};

class InsuranceCompany {
public:
    string name;
    string policyNumber;

    InsuranceCompany(string n, string p) : name(n), policyNumber(p) {}
};

class CarInsuranceService {
public:
    vector<Car> cars;
    vector<InsuranceCompany> companies;

    void addCar(string licensePlate, string ownerName) {
        cars.push_back(Car(licensePlate, ownerName));
    }

    void deleteCar(string licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(string licensePlate, string newOwnerName) {
        for (auto &car : cars) {
            if (car.licensePlate == licensePlate) {
                car.ownerName = newOwnerName;
                break;
            }
        }
    }

    void searchCar(string licensePlate) {
        for (auto &car : cars) {
            if (car.licensePlate == licensePlate) {
                cout << "Car: " << car.licensePlate << ", Owner: " << car.ownerName << endl;
                return;
            }
        }
        cout << "Car not found" << endl;
    }

    void displayCars() {
        for (auto &car : cars) {
            cout << "Car: " << car.licensePlate << ", Owner: " << car.ownerName << endl;
        }
    }

    void addInsuranceCompany(string name, string policyNumber) {
        companies.push_back(InsuranceCompany(name, policyNumber));
    }

    void deleteInsuranceCompany(string name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(string name, string newPolicyNumber) {
        for (auto &company : companies) {
            if (company.name == name) {
                company.policyNumber = newPolicyNumber;
                break;
            }
        }
    }

    void searchInsuranceCompany(string name) {
        for (auto &company : companies) {
            if (company.name == name) {
                cout << "Company: " << company.name << ", Policy #: " << company.policyNumber << endl;
                return;
            }
        }
        cout << "Insurance Company not found" << endl;
    }

    void displayInsuranceCompanies() {
        for (auto &company : companies) {
            cout << "Company: " << company.name << ", Policy #: " << company.policyNumber << endl;
        }
    }
};

int main() {
    CarInsuranceService service;
    service.addCar("123ABC", "John Doe");
    service.addInsuranceCompany("InsureCo", "POL987");

    service.displayCars();
    service.displayInsuranceCompanies();

    service.searchCar("123ABC");
    service.searchInsuranceCompany("InsureCo");

    service.updateCar("123ABC", "Jane Doe");
    service.updateInsuranceCompany("InsureCo", "POL123");

    service.displayCars();
    service.displayInsuranceCompanies();

    service.deleteCar("123ABC");
    service.deleteInsuranceCompany("InsureCo");

    service.displayCars();
    service.displayInsuranceCompanies();

    return 0;
}