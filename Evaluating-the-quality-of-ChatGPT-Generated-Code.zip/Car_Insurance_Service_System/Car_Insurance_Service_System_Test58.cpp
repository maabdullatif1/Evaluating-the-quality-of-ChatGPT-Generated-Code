#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string model;
    string make;
    
    Car(int id, const string &model, const string &make) : id(id), model(model), make(make) {}

    void display() const {
        cout << "Car ID: " << id << ", Model: " << model << ", Make: " << make << endl;
    }
};

class InsuranceCompany {
public:
    int id;
    string name;
    string address;
    
    InsuranceCompany(int id, const string &name, const string &address) : id(id), name(name), address(address) {}

    void display() const {
        cout << "Company ID: " << id << ", Name: " << name << ", Address: " << address << endl;
    }
};

class CarInsuranceService {
    vector<Car> cars;
    vector<InsuranceCompany> companies;

public:
    void addCar(int id, const string &model, const string &make) {
        cars.push_back(Car(id, model, make));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, const string &newModel, const string &newMake) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.model = newModel;
                car.make = newMake;
                break;
            }
        }
    }

    Car *searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() const {
        for (const auto &car : cars) {
            car.display();
        }
    }

    void addCompany(int id, const string &name, const string &address) {
        companies.push_back(InsuranceCompany(id, name, address));
    }

    void deleteCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCompany(int id, const string &newName, const string &newAddress) {
        for (auto &company : companies) {
            if (company.id == id) {
                company.name = newName;
                company.address = newAddress;
                break;
            }
        }
    }

    InsuranceCompany *searchCompany(int id) {
        for (auto &company : companies) {
            if (company.id == id) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayCompanies() const {
        for (const auto &company : companies) {
            company.display();
        }
    }
};

int main() {
    CarInsuranceService service;

    service.addCar(1, "Model S", "Tesla");
    service.addCar(2, "Mustang", "Ford");
    service.displayCars();

    service.addCompany(101, "ABC Insurance", "123 Street");
    service.addCompany(102, "XYZ Assurance", "456 Avenue");
    service.displayCompanies();

    service.updateCar(1, "Model 3", "Tesla");
    service.updateCompany(101, "ABC Insure", "789 Boulevard");
    
    Car *car = service.searchCar(1);
    if (car) car->display();
    
    InsuranceCompany *company = service.searchCompany(101);
    if (company) company->display();

    service.deleteCar(2);
    service.deleteCompany(102);

    service.displayCars();
    service.displayCompanies();

    return 0;
}