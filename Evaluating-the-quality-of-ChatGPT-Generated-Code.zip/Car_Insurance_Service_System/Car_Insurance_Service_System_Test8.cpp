#include <iostream>
#include <string>
#include <vector>

struct Car {
    std::string make;
    std::string model;
    std::string registrationNumber;
};

struct InsuranceCompany {
    std::string name;
    std::string contactNumber;
};

class CarInsuranceService {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(const Car& car) {
        cars.push_back(car);
    }

    void deleteCar(const std::string& registrationNumber) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->registrationNumber == registrationNumber) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string& registrationNumber, const Car& updatedCar) {
        for (auto &car : cars) {
            if (car.registrationNumber == registrationNumber) {
                car = updatedCar;
                break;
            }
        }
    }

    Car* searchCar(const std::string& registrationNumber) {
        for (auto &car : cars) {
            if (car.registrationNumber == registrationNumber) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "Make: " << car.make << ", Model: " << car.model 
                      << ", Registration Number: " << car.registrationNumber << std::endl;
        }
    }

    void addInsuranceCompany(const InsuranceCompany& company) {
        companies.push_back(company);
    }

    void deleteInsuranceCompany(const std::string& companyName) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == companyName) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(const std::string& companyName, const InsuranceCompany& updatedCompany) {
        for (auto &company : companies) {
            if (company.name == companyName) {
                company = updatedCompany;
                break;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(const std::string& companyName) {
        for (auto &company : companies) {
            if (company.name == companyName) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto &company : companies) {
            std::cout << "Name: " << company.name << ", Contact Number: " << company.contactNumber << std::endl;
        }
    }
};

int main() {
    CarInsuranceService service;

    Car car1 = {"Toyota", "Corolla", "ABC123"};
    Car car2 = {"Honda", "Civic", "XYZ789"};
    InsuranceCompany company1 = {"InsureCo", "123456789"};
    InsuranceCompany company2 = {"SafeGuard", "987654321"};

    service.addCar(car1);
    service.addCar(car2);
    service.addInsuranceCompany(company1);
    service.addInsuranceCompany(company2);

    service.displayCars();
    service.displayInsuranceCompanies();

    return 0;
}