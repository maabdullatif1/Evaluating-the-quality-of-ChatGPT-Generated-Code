#include <iostream>
#include <vector>
#include <string>

using namespace std;

class InsuranceCompany {
public:
    int id;
    string name;
    string address;

    InsuranceCompany(int companyId, string companyName, string companyAddress) :
        id(companyId), name(companyName), address(companyAddress) {}
};

class Car {
public:
    int id;
    string make;
    string model;
    int insuranceCompanyId;

    Car(int carId, string carMake, string carModel, int companyId) :
        id(carId), make(carMake), model(carModel), insuranceCompanyId(companyId) {}
};

class CarInsuranceService {
private:
    vector<InsuranceCompany> insuranceCompanies;
    vector<Car> cars;

public:
    void addInsuranceCompany(int id, string name, string address) {
        insuranceCompanies.push_back(InsuranceCompany(id, name, address));
    }

    void deleteInsuranceCompany(int id) {
        for(auto it = insuranceCompanies.begin(); it != insuranceCompanies.end(); ++it) {
            if(it->id == id) {
                insuranceCompanies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(int id, string newName, string newAddress) {
        for(auto &company : insuranceCompanies) {
            if(company.id == id) {
                company.name = newName;
                company.address = newAddress;
                break;
            }
        }
    }

    void displayInsuranceCompanies() {
        for(const auto &company : insuranceCompanies) {
            cout << "ID: " << company.id << ", Name: " << company.name << ", Address: " << company.address << endl;
        }
    }

    void addCar(int id, string make, string model, int insuranceCompanyId) {
        cars.push_back(Car(id, make, model, insuranceCompanyId));
    }

    void deleteCar(int id) {
        for(auto it = cars.begin(); it != cars.end(); ++it) {
            if(it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string newMake, string newModel, int newInsuranceCompanyId) {
        for(auto &car : cars) {
            if(car.id == id) {
                car.make = newMake;
                car.model = newModel;
                car.insuranceCompanyId = newInsuranceCompanyId;
                break;
            }
        }
    }

    void displayCars() {
        for(const auto &car : cars) {
            cout << "ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model
                 << ", Insurance Company ID: " << car.insuranceCompanyId << endl;
        }
    }

    void searchCar(int id) {
        for(const auto &car : cars) {
            if(car.id == id) {
                cout << "ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model
                     << ", Insurance Company ID: " << car.insuranceCompanyId << endl;
                return;
            }
        }
        cout << "Car not found." << endl;
    }

    void searchInsuranceCompany(int id) {
        for(const auto &company : insuranceCompanies) {
            if(company.id == id) {
                cout << "ID: " << company.id << ", Name: " << company.name 
                     << ", Address: " << company.address << endl;
                return;
            }
        }
        cout << "Insurance Company not found." << endl;
    }
};

int main() {
    CarInsuranceService service;
    service.addInsuranceCompany(1, "AllState", "123 Main St");
    service.addCar(1, "Toyota", "Camry", 1);

    service.displayInsuranceCompanies();
    service.displayCars();

    service.updateCar(1, "Honda", "Civic", 1);
    service.searchCar(1);

    service.deleteCar(1);
    service.displayCars();

    service.deleteInsuranceCompany(1);
    service.displayInsuranceCompanies();

    return 0;
}