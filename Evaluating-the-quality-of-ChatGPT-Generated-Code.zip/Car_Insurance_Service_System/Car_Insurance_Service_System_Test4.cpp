#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string make;
    string model;
    int year;
    
    Car(int id, string make, string model, int year) 
        : id(id), make(make), model(model), year(year) {}
};

class InsuranceCompany {
public:
    int id;
    string name;
    string contactInfo;
    
    InsuranceCompany(int id, string name, string contactInfo) 
        : id(id), name(name), contactInfo(contactInfo) {}
};

class InsuranceServiceSystem {
private:
    vector<Car> cars;
    vector<InsuranceCompany> companies;

public:
    void addCar(int id, string make, string model, int year) {
        cars.push_back(Car(id, make, model, year));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string make, string model, int year) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.year = year;
                return;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) return &car;
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "ID: " << car.id << ", Make: " << car.make 
                 << ", Model: " << car.model << ", Year: " << car.year << endl;
        }
    }

    void addCompany(int id, string name, string contactInfo) {
        companies.push_back(InsuranceCompany(id, name, contactInfo));
    }

    void deleteCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCompany(int id, string name, string contactInfo) {
        for (auto &company : companies) {
            if (company.id == id) {
                company.name = name;
                company.contactInfo = contactInfo;
                return;
            }
        }
    }

    InsuranceCompany* searchCompany(int id) {
        for (auto &company : companies) {
            if (company.id == id) return &company;
        }
        return nullptr;
    }

    void displayCompanies() {
        for (const auto &company : companies) {
            cout << "ID: " << company.id << ", Name: " << company.name 
                 << ", Contact Info: " << company.contactInfo << endl;
        }
    }
};

int main() {
    InsuranceServiceSystem system;
    system.addCar(1, "Toyota", "Corolla", 2020);
    system.addCar(2, "Honda", "Civic", 2019);
    system.displayCars();
    system.addCompany(1, "InsuranceCorp", "contact@insurance.com");
    system.addCompany(2, "SafeDrive", "info@safedrive.com");
    system.displayCompanies();
    system.updateCar(1, "Toyota", "Camry", 2021);
    system.displayCars();

    return 0;
}