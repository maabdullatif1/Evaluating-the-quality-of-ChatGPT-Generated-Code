#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string ownerName;
    std::string model;
    int year;

    Car(std::string lp, std::string on, std::string m, int y) 
        : licensePlate(lp), ownerName(on), model(m), year(y) {}

    void display() {
        std::cout << "License Plate: " << licensePlate 
                  << ", Owner: " << ownerName 
                  << ", Model: " << model 
                  << ", Year: " << year << "\n";
    }
};

class InsuranceCompany {
public:
    std::string name;
    std::string address;
    std::string contactNumber;

    InsuranceCompany(std::string n, std::string a, std::string cn) 
        : name(n), address(a), contactNumber(cn) {}

    void display() {
        std::cout << "Company Name: " << name 
                  << ", Address: " << address 
                  << ", Contact: " << contactNumber << "\n";
    }
};

std::vector<Car> cars;
std::vector<InsuranceCompany> companies;

void addCar() {
    std::string lp, on, m;
    int y;
    std::cout << "Enter License Plate: ";
    std::cin >> lp;
    std::cout << "Enter Owner Name: ";
    std::cin >> on;
    std::cout << "Enter Model: ";
    std::cin >> m;
    std::cout << "Enter Year: ";
    std::cin >> y;
    cars.push_back(Car(lp, on, m, y));
}

void deleteCar() {
    std::string lp;
    std::cout << "Enter License Plate of the car to delete: ";
    std::cin >> lp;
    for (auto it = cars.begin(); it != cars.end(); ++it) {
        if (it->licensePlate == lp) {
            cars.erase(it);
            break;
        }
    }
}

void updateCar() {
    std::string lp;
    std::cout << "Enter License Plate of the car to update: ";
    std::cin >> lp;
    for (auto &car : cars) {
        if (car.licensePlate == lp) {
            std::cout << "Enter new Owner Name: ";
            std::cin >> car.ownerName;
            std::cout << "Enter new Model: ";
            std::cin >> car.model;
            std::cout << "Enter new Year: ";
            std::cin >> car.year;
        }
    }
}

void searchCar() {
    std::string lp;
    std::cout << "Enter License Plate to search: ";
    std::cin >> lp;
    for (const auto &car : cars) {
        if (car.licensePlate == lp) {
            car.display();
            return;
        }
    }
    std::cout << "Car not found\n";
}

void displayCars() {
    for (const auto &car : cars) {
        car.display();
    }
}

void addCompany() {
    std::string n, a, cn;
    std::cout << "Enter Company Name: ";
    std::cin >> n;
    std::cout << "Enter Address: ";
    std::cin >> a;
    std::cout << "Enter Contact Number: ";
    std::cin >> cn;
    companies.push_back(InsuranceCompany(n, a, cn));
}

void deleteCompany() {
    std::string n;
    std::cout << "Enter Company Name to delete: ";
    std::cin >> n;
    for (auto it = companies.begin(); it != companies.end(); ++it) {
        if (it->name == n) {
            companies.erase(it);
            break;
        }
    }
}

void updateCompany() {
    std::string n;
    std::cout << "Enter Company Name to update: ";
    std::cin >> n;
    for (auto &company : companies) {
        if (company.name == n) {
            std::cout << "Enter new Address: ";
            std::cin >> company.address;
            std::cout << "Enter new Contact Number: ";
            std::cin >> company.contactNumber;
        }
    }
}

void searchCompany() {
    std::string n;
    std::cout << "Enter Company Name to search: ";
    std::cin >> n;
    for (const auto &company : companies) {
        if (company.name == n) {
            company.display();
            return;
        }
    }
    std::cout << "Company not found\n";
}

void displayCompanies() {
    for (const auto &company : companies) {
        company.display();
    }
}

int main() {
    int choice;
    while (true) {
        std::cout << "\n1. Add Car\n2. Delete Car\n3. Update Car\n4. Search Car\n5. Display Cars\n"
                  << "6. Add Insurance Company\n7. Delete Insurance Company\n8. Update Insurance Company\n"
                  << "9. Search Insurance Company\n10. Display Insurance Companies\n11. Exit\n"
                  << "Enter choice: ";
        std::cin >> choice;
        switch (choice) {
            case 1: addCar(); break;
            case 2: deleteCar(); break;
            case 3: updateCar(); break;
            case 4: searchCar(); break;
            case 5: displayCars(); break;
            case 6: addCompany(); break;
            case 7: deleteCompany(); break;
            case 8: updateCompany(); break;
            case 9: searchCompany(); break;
            case 10: displayCompanies(); break;
            case 11: return 0;
            default: std::cout << "Invalid choice\n";
        }
    }
}