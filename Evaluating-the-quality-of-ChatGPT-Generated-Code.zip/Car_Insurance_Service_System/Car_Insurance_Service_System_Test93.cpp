#include <iostream>
#include <string>
#include <vector>

class CarInsurance {
public:
    struct Car {
        std::string licensePlate;
        std::string make;
        std::string model;
        int year;
    };

    struct InsuranceCompany {
        std::string name;
        std::string address;
        std::string phone;
    };

    void addCar(const Car& car) {
        cars.push_back(car);
    }

    void deleteCar(const std::string& licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                return;
            }
        }
    }

    void updateCar(const std::string& licensePlate, const Car& updatedCar) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                car = updatedCar;
                return;
            }
        }
    }

    Car* searchCar(const std::string& licensePlate) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() const {
        for (const auto& car : cars) {
            std::cout << "License Plate: " << car.licensePlate << ", Make: " << car.make << ", Model: " << car.model << ", Year: " << car.year << std::endl;
        }
    }

    void addInsuranceCompany(const InsuranceCompany& company) {
        companies.push_back(company);
    }

    void deleteInsuranceCompany(const std::string& name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                return;
            }
        }
    }

    void updateInsuranceCompany(const std::string& name, const InsuranceCompany& updatedCompany) {
        for (auto& company : companies) {
            if (company.name == name) {
                company = updatedCompany;
                return;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(const std::string& name) {
        for (auto& company : companies) {
            if (company.name == name) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() const {
        for (const auto& company : companies) {
            std::cout << "Name: " << company.name << ", Address: " << company.address << ", Phone: " << company.phone << std::endl;
        }
    }

private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;
};

int main() {
    CarInsurance system;

    CarInsurance::Car car1 = {"ABC123", "Toyota", "Corolla", 2020};
    CarInsurance::Car car2 = {"XYZ789", "Honda", "Civic", 2019};
    system.addCar(car1);
    system.addCar(car2);

    CarInsurance::InsuranceCompany company1 = {"InsureCorp", "123 Elm Street", "555-1234"};
    CarInsurance::InsuranceCompany company2 = {"Coverage Inc", "456 Oak Street", "555-5678"};
    system.addInsuranceCompany(company1);
    system.addInsuranceCompany(company2);

    system.displayCars();
    system.displayInsuranceCompanies();

    return 0;
}