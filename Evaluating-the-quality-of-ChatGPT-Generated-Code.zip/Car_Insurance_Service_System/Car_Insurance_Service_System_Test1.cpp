#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Car {
public:
    string licensePlate;
    string ownerName;
    string model;
    string insuranceCompany;

    Car(string lp, string owner, string model, string insurance) 
        : licensePlate(lp), ownerName(owner), model(model), insuranceCompany(insurance) {}
};

class InsuranceCompany {
public:
    string name;
    string contactNumber;

    InsuranceCompany(string name, string contact)
        : name(name), contactNumber(contact) {}
};

class CarInsuranceService {
private:
    vector<Car> cars;
    vector<InsuranceCompany> insuranceCompanies;

    int findCarIndex(const string &licensePlate) {
        for (int i = 0; i < cars.size(); i++) {
            if (cars[i].licensePlate == licensePlate) {
                return i;
            }
        }
        return -1;
    }
    
    int findCompanyIndex(const string &name) {
        for (int i = 0; i < insuranceCompanies.size(); i++) {
            if (insuranceCompanies[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addCar(string licensePlate, string ownerName, string model, string insuranceCompany) {
        if (findCarIndex(licensePlate) == -1) {
            cars.push_back(Car(licensePlate, ownerName, model, insuranceCompany));
            cout << "Car added successfully." << endl;
        } else {
            cout << "Car already exists." << endl;
        }
    }

    void deleteCar(string licensePlate) {
        int index = findCarIndex(licensePlate);
        if (index != -1) {
            cars.erase(cars.begin() + index);
            cout << "Car deleted successfully." << endl;
        } else {
            cout << "Car not found." << endl;
        }
    }

    void updateCar(string licensePlate, string newOwnerName, string newModel, string newInsuranceCompany) {
        int index = findCarIndex(licensePlate);
        if (index != -1) {
            cars[index].ownerName = newOwnerName;
            cars[index].model = newModel;
            cars[index].insuranceCompany = newInsuranceCompany;
            cout << "Car updated successfully." << endl;
        } else {
            cout << "Car not found." << endl;
        }
    }

    void searchCar(string licensePlate) {
        int index = findCarIndex(licensePlate);
        if (index != -1) {
            cout << "License Plate: " << cars[index].licensePlate << endl;
            cout << "Owner Name: " << cars[index].ownerName << endl;
            cout << "Model: " << cars[index].model << endl;
            cout << "Insurance Company: " << cars[index].insuranceCompany << endl;
        } else {
            cout << "Car not found." << endl;
        }
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "License Plate: " << car.licensePlate << ", Owner: " << car.ownerName
                 << ", Model: " << car.model << ", Insurance: " << car.insuranceCompany << endl;
        }
    }

    void addInsuranceCompany(string name, string contactNumber) {
        if (findCompanyIndex(name) == -1) {
            insuranceCompanies.push_back(InsuranceCompany(name, contactNumber));
            cout << "Insurance company added successfully." << endl;
        } else {
            cout << "Insurance company already exists." << endl;
        }
    }

    void deleteInsuranceCompany(string name) {
        int index = findCompanyIndex(name);
        if (index != -1) {
            insuranceCompanies.erase(insuranceCompanies.begin() + index);
            cout << "Insurance company deleted successfully." << endl;
        } else {
            cout << "Insurance company not found." << endl;
        }
    }

    void displayInsuranceCompanies() {
        for (const auto &company : insuranceCompanies) {
            cout << "Name: " << company.name << ", Contact: " << company.contactNumber << endl;
        }
    }
};

int main() {
    CarInsuranceService service;
    service.addCar("ABC123", "John Doe", "Toyota Camry", "CompanyA");
    service.addCar("XYZ987", "Jane Smith", "Honda Accord", "CompanyB");
    service.displayCars();
    service.searchCar("ABC123");
    service.updateCar("ABC123", "John Doe", "Toyota Corolla", "CompanyA");
    service.displayCars();
    service.deleteCar("XYZ987");
    service.displayCars();
    service.addInsuranceCompany("CompanyA", "123-456-7890");
    service.addInsuranceCompany("CompanyB", "234-567-8901");
    service.displayInsuranceCompanies();
    service.deleteInsuranceCompany("CompanyB");
    service.displayInsuranceCompanies();
    return 0;
}