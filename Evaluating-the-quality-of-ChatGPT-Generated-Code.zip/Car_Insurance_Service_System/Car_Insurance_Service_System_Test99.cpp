#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    int id;
    string model;
    string owner;
};

struct InsuranceCompany {
    int id;
    string name;
    string contact;
};

vector<Car> cars;
vector<InsuranceCompany> insuranceCompanies;

int carID = 1;
int insuranceID = 1;

void addCar() {
    Car car;
    car.id = carID++;
    cout << "Enter car model: ";
    cin >> car.model;
    cout << "Enter car owner: ";
    cin >> car.owner;
    cars.push_back(car);
}

void addInsuranceCompany() {
    InsuranceCompany company;
    company.id = insuranceID++;
    cout << "Enter insurance company name: ";
    cin >> company.name;
    cout << "Enter contact information: ";
    cin >> company.contact;
    insuranceCompanies.push_back(company);
}

void deleteCar() {
    int id;
    cout << "Enter car ID to delete: ";
    cin >> id;
    for (auto it = cars.begin(); it != cars.end(); ++it) {
        if (it->id == id) {
            cars.erase(it);
            break;
        }
    }
}

void deleteInsuranceCompany() {
    int id;
    cout << "Enter company ID to delete: ";
    cin >> id;
    for (auto it = insuranceCompanies.begin(); it != insuranceCompanies.end(); ++it) {
        if (it->id == id) {
            insuranceCompanies.erase(it);
            break;
        }
    }
}

void updateCar() {
    int id;
    cout << "Enter car ID to update: ";
    cin >> id;
    for (auto &car : cars) {
        if (car.id == id) {
            cout << "Enter new model: ";
            cin >> car.model;
            cout << "Enter new owner: ";
            cin >> car.owner;
            break;
        }
    }
}

void updateInsuranceCompany() {
    int id;
    cout << "Enter company ID to update: ";
    cin >> id;
    for (auto &company : insuranceCompanies) {
        if (company.id == id) {
            cout << "Enter new name: ";
            cin >> company.name;
            cout << "Enter new contact: ";
            cin >> company.contact;
            break;
        }
    }
}

void searchCar() {
    int id;
    cout << "Enter car ID to search: ";
    cin >> id;
    for (const auto &car : cars) {
        if (car.id == id) {
            cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << endl;
            return;
        }
    }
    cout << "Car not found." << endl;
}

void searchInsuranceCompany() {
    int id;
    cout << "Enter company ID to search: ";
    cin >> id;
    for (const auto &company : insuranceCompanies) {
        if (company.id == id) {
            cout << "Company ID: " << company.id << ", Name: " << company.name << ", Contact: " << company.contact << endl;
            return;
        }
    }
    cout << "Company not found." << endl;
}

void displayCars() {
    cout << "Cars:" << endl;
    for (const auto &car : cars) {
        cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << endl;
    }
}

void displayInsuranceCompanies() {
    cout << "Insurance Companies:" << endl;
    for (const auto &company : insuranceCompanies) {
        cout << "Company ID: " << company.id << ", Name: " << company.name << ", Contact: " << company.contact << endl;
    }
}

int main() {
    while (true) {
        int choice;
        cout << "1. Add Car\n2. Add Insurance Company\n3. Delete Car\n4. Delete Insurance Company\n5. Update Car\n6. Update Insurance Company\n7. Search Car\n8. Search Insurance Company\n9. Display Cars\n10. Display Insurance Companies\n11. Exit\nChoose an option: ";
        cin >> choice;

        switch (choice) {
            case 1: addCar(); break;
            case 2: addInsuranceCompany(); break;
            case 3: deleteCar(); break;
            case 4: deleteInsuranceCompany(); break;
            case 5: updateCar(); break;
            case 6: updateInsuranceCompany(); break;
            case 7: searchCar(); break;
            case 8: searchInsuranceCompany(); break;
            case 9: displayCars(); break;
            case 10: displayInsuranceCompanies(); break;
            case 11: return 0;
            default: cout << "Invalid option." << endl;
        }
    }
    return 0;
}