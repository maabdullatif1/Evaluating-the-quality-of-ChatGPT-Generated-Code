#include <iostream>
#include <vector>
#include <string>

struct InsuranceCompany {
    int id;
    std::string name;
};

struct Car {
    int id;
    std::string make;
    std::string model;
    int ownerId;
};

class InsuranceService {
private:
    std::vector<InsuranceCompany> companies;
    std::vector<Car> cars;
    int companyCounter = 0;
    int carCounter = 0;

public:
    void addCompany(const std::string& name) {
        companies.push_back({++companyCounter, name});
    }

    void deleteCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCompany(int id, const std::string& newName) {
        for (auto& company : companies) {
            if (company.id == id) {
                company.name = newName;
                break;
            }
        }
    }

    void displayCompanies() const {
        for (const auto& company : companies) {
            std::cout << "Company ID: " << company.id << ", Name: " << company.name << std::endl;
        }
    }

    void addCar(const std::string& make, const std::string& model, int ownerId) {
        cars.push_back({++carCounter, make, model, ownerId});
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, const std::string& newMake, const std::string& newModel, int newOwnerId) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.make = newMake;
                car.model = newModel;
                car.ownerId = newOwnerId;
                break;
            }
        }
    }

    void displayCars() const {
        for (const auto& car : cars) {
            std::cout << "Car ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << ", Owner ID: " << car.ownerId << std::endl;
        }
    }

    void searchCompanyByName(const std::string& name) const {
        for (const auto& company : companies) {
            if (company.name == name) {
                std::cout << "Company found - ID: " << company.id << ", Name: " << company.name << std::endl;
                return;
            }
        }
        std::cout << "Company not found" << std::endl;
    }

    void searchCarByMakeModel(const std::string& make, const std::string& model) const {
        for (const auto& car : cars) {
            if (car.make == make && car.model == model) {
                std::cout << "Car found - ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << ", Owner ID: " << car.ownerId << std::endl;
                return;
            }
        }
        std::cout << "Car not found" << std::endl;
    }
};

int main() {
    InsuranceService service;

    service.addCompany("Good Insurance");
    service.addCompany("Secure Life");

    service.addCar("Toyota", "Camry", 1);
    service.addCar("Honda", "Civic", 2);

    service.displayCompanies();
    service.displayCars();

    service.searchCompanyByName("Secure Life");
    service.searchCarByMakeModel("Honda", "Civic");

    service.updateCompany(1, "Better Insurance");
    service.updateCar(1, "Toyota", "Corolla", 2);

    service.displayCompanies();
    service.displayCars();

    service.deleteCompany(2);
    service.deleteCar(1);

    service.displayCompanies();
    service.displayCars();

    return 0;
}