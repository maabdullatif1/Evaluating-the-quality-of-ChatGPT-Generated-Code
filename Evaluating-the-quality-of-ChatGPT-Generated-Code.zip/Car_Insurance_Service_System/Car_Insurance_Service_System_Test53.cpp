#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Car {
    int id;
    string make;
    string model;
    string owner;
};

struct InsuranceCompany {
    int id;
    string name;
    string contact;
    vector<Car> insuredCars;
};

class InsuranceServiceSystem {
private:
    vector<Car> cars;
    vector<InsuranceCompany> insuranceCompanies;
    int carIdCounter = 1;
    int companyIdCounter = 1;
    
public:
    void addCar(string make, string model, string owner) {
        cars.push_back({carIdCounter++, make, model, owner});
    }
    
    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }
    
    void updateCar(int id, string make, string model, string owner) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.owner = owner;
                break;
            }
        }
    }
    
    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }
    
    void displayCars() {
        for (const auto& car : cars) {
            cout << "ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << ", Owner: " << car.owner << endl;
        }
    }
    
    void addCompany(string name, string contact) {
        insuranceCompanies.push_back({companyIdCounter++, name, contact, {}});
    }
    
    void deleteCompany(int id) {
        for (auto it = insuranceCompanies.begin(); it != insuranceCompanies.end(); ++it) {
            if (it->id == id) {
                insuranceCompanies.erase(it);
                break;
            }
        }
    }
    
    void updateCompany(int id, string name, string contact) {
        for (auto& company : insuranceCompanies) {
            if (company.id == id) {
                company.name = name;
                company.contact = contact;
                break;
            }
        }
    }
    
    InsuranceCompany* searchCompany(int id) {
        for (auto& company : insuranceCompanies) {
            if (company.id == id) {
                return &company;
            }
        }
        return nullptr;
    }
    
    void displayCompanies() {
        for (const auto& company : insuranceCompanies) {
            cout << "ID: " << company.id << ", Name: " << company.name << ", Contact: " << company.contact << endl;
            for (const auto& car : company.insuredCars) {
                cout << "   Insured Car - ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << ", Owner: " << car.owner << endl;
            }
        }
    }
    
    void addCarToCompany(int companyId, int carId) {
        Car* car = searchCar(carId);
        if (car) {
            for (auto& company : insuranceCompanies) {
                if (company.id == companyId) {
                    company.insuredCars.push_back(*car);
                    break;
                }
            }
        }
    }
};

int main() {
    InsuranceServiceSystem system;
    system.addCar("Toyota", "Corolla", "Alice");
    system.addCar("Honda", "Civic", "Bob");
    system.displayCars();
    
    system.addCompany("A1 Insurance", "123-456-7890");
    system.addCompany("B2 Coverage", "987-654-3210");
    system.displayCompanies();
    
    system.addCarToCompany(1, 1);
    system.displayCompanies();
    
    return 0;
}