#include <iostream>
#include <vector>
#include <string>

struct Car {
    std::string licensePlate;
    std::string model;
    int year;
};

struct InsuranceCompany {
    std::string companyName;
    std::string policyNumber;
};

struct InsuranceService {
    Car car;
    InsuranceCompany insuranceCompany;
};

class InsuranceSystem {
    std::vector<InsuranceService> services;

public:
    void addInsuranceService(const Car& car, const InsuranceCompany& insuranceCompany) {
        InsuranceService service{car, insuranceCompany};
        services.push_back(service);
    }

    void deleteInsuranceService(const std::string& licensePlate) {
        for (auto it = services.begin(); it != services.end(); ++it) {
            if (it->car.licensePlate == licensePlate) {
                services.erase(it);
                break;
            }
        }
    }

    void updateInsuranceService(const std::string& licensePlate, const Car& car, const InsuranceCompany& insuranceCompany) {
        for (auto& service : services) {
            if (service.car.licensePlate == licensePlate) {
                service.car = car;
                service.insuranceCompany = insuranceCompany;
                break;
            }
        }
    }

    void searchInsuranceService(const std::string& licensePlate) {
        for (const auto& service : services) {
            if (service.car.licensePlate == licensePlate) {
                displayInsuranceService(service);
                return;
            }
        }
        std::cout << "Service not found" << std::endl;
    }

    void displayInsuranceService(const InsuranceService& service) {
        std::cout << "License Plate: " << service.car.licensePlate << std::endl;
        std::cout << "Model: " << service.car.model << std::endl;
        std::cout << "Year: " << service.car.year << std::endl;
        std::cout << "Insurance Company: " << service.insuranceCompany.companyName << std::endl;
        std::cout << "Policy Number: " << service.insuranceCompany.policyNumber << std::endl;
    }

    void displayAllServices() {
        for (const auto& service : services) {
            displayInsuranceService(service);
            std::cout << "-----------------" << std::endl;
        }
    }
};

int main() {
    InsuranceSystem system;
    Car car1 = {"ABC123", "Toyota Camry", 2020};
    InsuranceCompany company1 = {"XYZ Insurance", "POL12345"};
    system.addInsuranceService(car1, company1);

    Car car2 = {"DFG456", "Honda Accord", 2019};
    InsuranceCompany company2 = {"ABC Insurance", "POL67890"};
    system.addInsuranceService(car2, company2);

    system.displayAllServices();

    system.searchInsuranceService("ABC123");

    Car updatedCar = {"ABC123", "Toyota Corolla", 2021};
    InsuranceCompany updatedCompany = {"XYZ Insurance", "POL54321"};
    system.updateInsuranceService("ABC123", updatedCar, updatedCompany);

    system.searchInsuranceService("ABC123");

    system.deleteInsuranceService("DFG456");
    system.displayAllServices();

    return 0;
}