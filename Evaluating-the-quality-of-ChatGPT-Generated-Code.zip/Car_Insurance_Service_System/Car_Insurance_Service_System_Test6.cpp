#include <iostream>
#include <vector>
#include <string>

class InsuranceCompany {
public:
    int id;
    std::string name;

    InsuranceCompany(int i, const std::string& n) : id(i), name(n) {}
};

class Car {
public:
    int id;
    std::string model;
    InsuranceCompany* insuranceCompany;

    Car(int i, const std::string& m, InsuranceCompany* ic) : id(i), model(m), insuranceCompany(ic) {}
};

class CarInsuranceService {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> insuranceCompanies;

public:
    void addInsuranceCompany(int id, const std::string& name) {
        insuranceCompanies.emplace_back(id, name);
    }

    void deleteInsuranceCompany(int id) {
        insuranceCompanies.erase(std::remove_if(insuranceCompanies.begin(), insuranceCompanies.end(),
                                                [=](InsuranceCompany& ic) { return ic.id == id; }),
                                 insuranceCompanies.end());
    }

    void updateInsuranceCompany(int id, const std::string& newName) {
        for (auto& ic : insuranceCompanies) {
            if (ic.id == id) {
                ic.name = newName;
                break;
            }
        }
    }

    void displayInsuranceCompanies() {
        for (const auto& ic : insuranceCompanies) {
            std::cout << "Insurance Company ID: " << ic.id << ", Name: " << ic.name << std::endl;
        }
    }

    InsuranceCompany* searchInsuranceCompany(int id) {
        for (auto& ic : insuranceCompanies) {
            if (ic.id == id) return &ic;
        }
        return nullptr;
    }

    void addCar(int id, const std::string& model, int insuranceCompanyId) {
        InsuranceCompany* ic = searchInsuranceCompany(insuranceCompanyId);
        if (ic) {
            cars.emplace_back(id, model, ic);
        }
    }

    void deleteCar(int id) {
        cars.erase(std::remove_if(cars.begin(), cars.end(),
                                  [=](Car& car) { return car.id == id; }),
                   cars.end());
    }

    void updateCar(int id, const std::string& newModel, int newInsuranceCompanyId) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.model = newModel;
                car.insuranceCompany = searchInsuranceCompany(newInsuranceCompanyId);
                break;
            }
        }
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Car ID: " << car.id << ", Model: " << car.model
                      << ", Insurance Company: " << (car.insuranceCompany ? car.insuranceCompany->name : "None") << std::endl;
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) return &car;
        }
        return nullptr;
    }
};

int main() {
    CarInsuranceService service;
    service.addInsuranceCompany(1, "Insurance Co A");
    service.addInsuranceCompany(2, "Insurance Co B");
    service.addCar(1, "Car Model X", 1);
    service.addCar(2, "Car Model Y", 2);
    service.displayInsuranceCompanies();
    service.displayCars();
    return 0;
}