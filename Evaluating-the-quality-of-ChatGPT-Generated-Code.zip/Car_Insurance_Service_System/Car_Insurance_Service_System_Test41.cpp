#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string model;
    std::string owner;

    Car(int id, std::string model, std::string owner)
        : id(id), model(model), owner(owner) {}
};

class InsuranceCompany {
public:
    int id;
    std::string name;
    std::string contact;

    InsuranceCompany(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class CarInsuranceService {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> insuranceCompanies;
    int carID = 0;
    int companyID = 0;

public:
    void addCar(std::string model, std::string owner) {
        cars.push_back(Car(++carID, model, owner));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, std::string model, std::string owner) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.model = model;
                car.owner = owner;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << std::endl;
        }
    }

    void addInsuranceCompany(std::string name, std::string contact) {
        insuranceCompanies.push_back(InsuranceCompany(++companyID, name, contact));
    }

    void deleteInsuranceCompany(int id) {
        for (auto it = insuranceCompanies.begin(); it != insuranceCompanies.end(); ++it) {
            if (it->id == id) {
                insuranceCompanies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(int id, std::string name, std::string contact) {
        for (auto &company : insuranceCompanies) {
            if (company.id == id) {
                company.name = name;
                company.contact = contact;
                break;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(int id) {
        for (auto &company : insuranceCompanies) {
            if (company.id == id) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto &company : insuranceCompanies) {
            std::cout << "ID: " << company.id << ", Name: " << company.name << ", Contact: " << company.contact << std::endl;
        }
    }
};

int main() {
    CarInsuranceService service;
    
    service.addCar("Toyota Corolla", "John Doe");
    service.addCar("Honda Civic", "Jane Smith");
    service.displayCars();

    service.addInsuranceCompany("Insurance Co A", "123-456-7890");
    service.addInsuranceCompany("Insurance Co B", "098-765-4321");
    service.displayInsuranceCompanies();

    service.deleteCar(1);
    service.displayCars();

    return 0;
}