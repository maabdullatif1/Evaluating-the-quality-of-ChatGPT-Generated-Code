#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string registration_number;
    std::string model;
    std::string owner;

    Car(std::string reg_num, std::string mdl, std::string own)
        : registration_number(reg_num), model(mdl), owner(own) {}
};

class InsuranceCompany {
public:
    std::string name;
    std::string address;

    InsuranceCompany(std::string n, std::string addr) 
        : name(n), address(addr) {}
};

class CarInsuranceService {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> insuranceCompanies;

public:
    void addCar(const std::string& reg_num, const std::string& model, const std::string& owner) {
        cars.push_back(Car(reg_num, model, owner));
    }

    void deleteCar(const std::string& reg_num) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->registration_number == reg_num) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string& reg_num, const std::string& model, const std::string& owner) {
        for (auto& car : cars) {
            if (car.registration_number == reg_num) {
                car.model = model;
                car.owner = owner;
                break;
            }
        }
    }

    Car* searchCar(const std::string& reg_num) {
        for (auto& car : cars) {
            if (car.registration_number == reg_num) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Registration Number: " << car.registration_number 
                      << ", Model: " << car.model << ", Owner: " << car.owner << std::endl;
        }
    }

    void addInsuranceCompany(const std::string& name, const std::string& address) {
        insuranceCompanies.push_back(InsuranceCompany(name, address));
    }

    void deleteInsuranceCompany(const std::string& name) {
        for (auto it = insuranceCompanies.begin(); it != insuranceCompanies.end(); ++it) {
            if (it->name == name) {
                insuranceCompanies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(const std::string& name, const std::string& address) {
        for (auto& company : insuranceCompanies) {
            if (company.name == name) {
                company.address = address;
                break;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(const std::string& name) {
        for (auto& company : insuranceCompanies) {
            if (company.name == name) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto& company : insuranceCompanies) {
            std::cout << "Name: " << company.name << ", Address: " << company.address << std::endl;
        }
    }
};

int main() {
    CarInsuranceService service;
    service.addCar("ABC123", "Toyota", "John Doe");
    service.addInsuranceCompany("Company A", "1234 Street");

    service.displayCars();
    service.displayInsuranceCompanies();

    return 0;
}