#include <iostream>
#include <string>
#include <vector>

class Car {
public:
    int id;
    std::string brand;
    std::string model;
    int year;
    
    Car(int id, const std::string& brand, const std::string& model, int year) 
        : id(id), brand(brand), model(model), year(year) {}
};

class InsuranceCompany {
public:
    int id;
    std::string name;
    std::string address;
    
    InsuranceCompany(int id, const std::string& name, const std::string& address) 
        : id(id), name(name), address(address) {}
};

class ServiceSystem {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(int id, const std::string& brand, const std::string& model, int year) {
        cars.emplace_back(id, brand, model, year);
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, const std::string& brand, const std::string& model, int year) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.brand = brand;
                car.model = model;
                car.year = year;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id)
                return &car;
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "ID: " << car.id << ", Brand: " << car.brand 
                      << ", Model: " << car.model << ", Year: " << car.year << std::endl;
        }
    }

    void addInsuranceCompany(int id, const std::string& name, const std::string& address) {
        companies.emplace_back(id, name, address);
    }

    void deleteInsuranceCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(int id, const std::string& name, const std::string& address) {
        for (auto& company : companies) {
            if (company.id == id) {
                company.name = name;
                company.address = address;
                break;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(int id) {
        for (auto& company : companies) {
            if (company.id == id)
                return &company;
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto& company : companies) {
            std::cout << "ID: " << company.id << ", Name: " << company.name 
                      << ", Address: " << company.address << std::endl;
        }
    }
};

int main() {
    ServiceSystem system;
    system.addCar(1, "Toyota", "Camry", 2020);
    system.addInsuranceCompany(1, "Insurance Co.", "123 Main St.");
    
    system.displayCars();
    system.displayInsuranceCompanies();
    
    system.updateCar(1, "Toyota", "Corolla", 2021);
    system.updateInsuranceCompany(1, "New Insurance Co.", "456 Elm St.");
    
    system.displayCars();
    system.displayInsuranceCompanies();

    return 0;
}