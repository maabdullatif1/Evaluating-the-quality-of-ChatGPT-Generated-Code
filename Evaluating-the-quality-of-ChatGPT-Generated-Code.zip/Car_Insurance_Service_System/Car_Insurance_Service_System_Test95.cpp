#include <iostream>
#include <vector>
#include <string>

class InsuranceCompany {
public:
    std::string companyName;
    std::string companyAddress;
    std::string contactNumber;

    InsuranceCompany(std::string name, std::string address, std::string contact)
        : companyName(name), companyAddress(address), contactNumber(contact) {}
};

class Car {
public:
    std::string licensePlate;
    std::string model;
    std::string owner;
    InsuranceCompany* insuranceCompany;

    Car(std::string plate, std::string mod, std::string own, InsuranceCompany* company)
        : licensePlate(plate), model(mod), owner(own), insuranceCompany(company) {}
};

class CarInsuranceSystem {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCompany(const std::string& name, const std::string& address, const std::string& contact) {
        companies.emplace_back(name, address, contact);
    }

    void addCar(const std::string& plate, const std::string& model, const std::string& owner, const std::string& companyName) {
        for (auto& company : companies) {
            if (company.companyName == companyName) {
                cars.emplace_back(plate, model, owner, &company);
                return;
            }
        }
    }

    void deleteCar(const std::string& plate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == plate) {
                cars.erase(it);
                return;
            }
        }
    }

    void updateCarInsurance(const std::string& plate, const std::string& newCompanyName) {
        for (auto& car : cars) {
            if (car.licensePlate == plate) {
                for (auto& company : companies) {
                    if (company.companyName == newCompanyName) {
                        car.insuranceCompany = &company;
                        return;
                    }
                }
            }
        }
    }

    Car* searchCar(const std::string& plate) {
        for (auto& car : cars) {
            if (car.licensePlate == plate) {
                return &car;
            }
        }
        return nullptr;
    }

    InsuranceCompany* searchCompany(const std::string& name) {
        for (auto& company : companies) {
            if (company.companyName == name) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "License Plate: " << car.licensePlate << ", Model: " << car.model
                      << ", Owner: " << car.owner << ", Insurance Company: " 
                      << car.insuranceCompany->companyName << std::endl;
        }
    }

    void displayCompanies() {
        for (const auto& company : companies) {
            std::cout << "Company Name: " << company.companyName
                      << ", Address: " << company.companyAddress
                      << ", Contact: " << company.contactNumber << std::endl;
        }
    }
};

int main() {
    CarInsuranceSystem system;

    system.addCompany("InsureCo", "1234 Elm St", "555-2020");
    system.addCompany("SafeGuard", "5678 Oak St", "555-3030");

    system.addCar("ABC123", "Toyota Corolla", "John Doe", "InsureCo");
    system.addCar("XYZ789", "Honda Civic", "Jane Smith", "SafeGuard");

    system.displayCompanies();
    system.displayCars();

    system.updateCarInsurance("ABC123", "SafeGuard");
    system.displayCars();

    system.deleteCar("XYZ789");
    system.displayCars();

    return 0;
}