#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string make;
    std::string model;
    int year;
    std::string owner;

    Car(int id, std::string make, std::string model, int year, std::string owner)
        : id(id), make(make), model(model), year(year), owner(owner) {}
};

class InsuranceCompany {
public:
    int id;
    std::string name;
    std::string address;
    std::string contactNumber;

    InsuranceCompany(int id, std::string name, std::string address, std::string contactNumber)
        : id(id), name(name), address(address), contactNumber(contactNumber) {}
};

class InsuranceService {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(int id, std::string make, std::string model, int year, std::string owner) {
        cars.push_back(Car(id, make, model, year, owner));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, std::string make, std::string model, int year, std::string owner) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.year = year;
                car.owner = owner;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (auto& car : cars) {
            std::cout << "ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model
                      << ", Year: " << car.year << ", Owner: " << car.owner << std::endl;
        }
    }

    void addInsuranceCompany(int id, std::string name, std::string address, std::string contactNumber) {
        companies.push_back(InsuranceCompany(id, name, address, contactNumber));
    }

    void deleteInsuranceCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(int id, std::string name, std::string address, std::string contactNumber) {
        for (auto& company : companies) {
            if (company.id == id) {
                company.name = name;
                company.address = address;
                company.contactNumber = contactNumber;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(int id) {
        for (auto& company : companies) {
            if (company.id == id) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (auto& company : companies) {
            std::cout << "ID: " << company.id << ", Name: " << company.name
                      << ", Address: " << company.address
                      << ", Contact: " << company.contactNumber << std::endl;
        }
    }
};

int main() {
    InsuranceService service;
    service.addCar(1, "Toyota", "Corolla", 2020, "John Doe");
    service.addCar(2, "Honda", "Civic", 2019, "Jane Doe");
    service.addInsuranceCompany(1, "ABC Insurance", "123 Main St", "123-456-7890");
    service.addInsuranceCompany(2, "XYZ Insurance", "456 Elm St", "987-654-3210");
    service.displayCars();
    service.displayInsuranceCompanies();
    return 0;
}