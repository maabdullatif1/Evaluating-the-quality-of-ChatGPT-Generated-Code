#include <iostream>
#include <string>
#include <vector>

class Car {
public:
    std::string licensePlate;
    std::string model;
    std::string ownerName;

    Car(std::string lp, std::string m, std::string o) 
        : licensePlate(lp), model(m), ownerName(o) {}
};

class InsuranceCompany {
public:
    std::string companyName;
    std::string policyNumber;

    InsuranceCompany(std::string cn, std::string pn) 
        : companyName(cn), policyNumber(pn) {}
};

class InsuranceSystem {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(const std::string& lp, const std::string& m, const std::string& o) {
        cars.push_back(Car(lp, m, o));
    }
    
    void deleteCar(const std::string& lp) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == lp) {
                cars.erase(it);
                break;
            }
        }
    }
    
    void updateCar(const std::string& lp, const std::string& newModel, const std::string& newOwner) {
        for (auto &car : cars) {
            if (car.licensePlate == lp) {
                car.model = newModel;
                car.ownerName = newOwner;
                break;
            }
        }
    }
    
    void searchCar(const std::string& lp) {
        for (const auto &car : cars) {
            if (car.licensePlate == lp) {
                std::cout << "License Plate: " << car.licensePlate 
                          << ", Model: " << car.model 
                          << ", Owner: " << car.ownerName << std::endl;
                return;
            }
        }
        std::cout << "Car not found." << std::endl;
    }
    
    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "License Plate: " << car.licensePlate 
                      << ", Model: " << car.model 
                      << ", Owner: " << car.ownerName << std::endl;
        }
    }

    void addCompany(const std::string& cn, const std::string& pn) {
        companies.push_back(InsuranceCompany(cn, pn));
    }

    void deleteCompany(const std::string& cn) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->companyName == cn) {
                companies.erase(it);
                break;
            }
        }
    }
    
    void updateCompany(const std::string& cn, const std::string& newPolicyNumber) {
        for (auto &company : companies) {
            if (company.companyName == cn) {
                company.policyNumber = newPolicyNumber;
                break;
            }
        }
    }
    
    void searchCompany(const std::string& cn) {
        for (const auto &company : companies) {
            if (company.companyName == cn) {
                std::cout << "Company: " << company.companyName 
                          << ", Policy Number: " << company.policyNumber << std::endl;
                return;
            }
        }
        std::cout << "Company not found." << std::endl;
    }
    
    void displayCompanies() {
        for (const auto &company : companies) {
            std::cout << "Company: " << company.companyName 
                      << ", Policy Number: " << company.policyNumber << std::endl;
        }
    }
};

int main() {
    InsuranceSystem system;
    system.addCar("ABC123", "Toyota", "John Doe");
    system.addCar("XYZ789", "Honda", "Jane Smith");
    system.addCompany("XYZ Insurance", "12345");
    system.addCompany("ABC Insurance", "67890");

    std::cout << "Cars:\n";
    system.displayCars();
    std::cout << "\nInsurance Companies:\n";
    system.displayCompanies();

    return 0;
}