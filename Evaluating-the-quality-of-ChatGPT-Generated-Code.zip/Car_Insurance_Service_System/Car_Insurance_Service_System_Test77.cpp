#include <iostream>
#include <string>
#include <vector>

class Car {
public:
    std::string licensePlate;
    std::string model;
    std::string ownerName;

    Car(std::string lp, std::string m, std::string o) : licensePlate(lp), model(m), ownerName(o) {}
};

class InsuranceCompany {
public:
    std::string name;
    std::string address;
    std::string phone;

    InsuranceCompany(std::string n, std::string a, std::string p) : name(n), address(a), phone(p) {}
};

class CarInsuranceService {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar() {
        std::string lp, model, owner;
        std::cout << "Enter License Plate: ";
        std::cin >> lp;
        std::cout << "Enter Model: ";
        std::cin >> model;
        std::cout << "Enter Owner Name: ";
        std::cin >> owner;
        cars.push_back(Car(lp, model, owner));
    }

    void deleteCar() {
        std::string lp;
        std::cout << "Enter License Plate to delete: ";
        std::cin >> lp;
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == lp) {
                cars.erase(it);
                std::cout << "Car deleted.\n";
                return;
            }
        }
        std::cout << "Car not found.\n";
    }

    void updateCar() {
        std::string lp;
        std::cout << "Enter License Plate to update: ";
        std::cin >> lp;
        for (auto &car : cars) {
            if (car.licensePlate == lp) {
                std::cout << "Enter new Model: ";
                std::cin >> car.model;
                std::cout << "Enter new Owner Name: ";
                std::cin >> car.ownerName;
                std::cout << "Car updated.\n";
                return;
            }
        }
        std::cout << "Car not found.\n";
    }

    void searchCar() {
        std::string lp;
        std::cout << "Enter License Plate to search: ";
        std::cin >> lp;
        for (const auto &car : cars) {
            if (car.licensePlate == lp) {
                std::cout << "License Plate: " << car.licensePlate << "\nModel: " << car.model << "\nOwner: " << car.ownerName << "\n";
                return;
            }
        }
        std::cout << "Car not found.\n";
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "License Plate: " << car.licensePlate << "\nModel: " << car.model << "\nOwner: " << car.ownerName << "\n\n";
        }
    }

    void addInsuranceCompany() {
        std::string name, address, phone;
        std::cout << "Enter Company Name: ";
        std::cin >> name;
        std::cout << "Enter Address: ";
        std::cin >> address;
        std::cout << "Enter Phone: ";
        std::cin >> phone;
        companies.push_back(InsuranceCompany(name, address, phone));
    }

    void deleteInsuranceCompany() {
        std::string name;
        std::cout << "Enter Company Name to delete: ";
        std::cin >> name;
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                std::cout << "Company deleted.\n";
                return;
            }
        }
        std::cout << "Company not found.\n";
    }

    void updateInsuranceCompany() {
        std::string name;
        std::cout << "Enter Company Name to update: ";
        std::cin >> name;
        for (auto &company : companies) {
            if (company.name == name) {
                std::cout << "Enter new Address: ";
                std::cin >> company.address;
                std::cout << "Enter new Phone: ";
                std::cin >> company.phone;
                std::cout << "Company updated.\n";
                return;
            }
        }
        std::cout << "Company not found.\n";
    }

    void searchInsuranceCompany() {
        std::string name;
        std::cout << "Enter Company Name to search: ";
        std::cin >> name;
        for (const auto &company : companies) {
            if (company.name == name) {
                std::cout << "Name: " << company.name << "\nAddress: " << company.address << "\nPhone: " << company.phone << "\n";
                return;
            }
        }
        std::cout << "Company not found.\n";
    }

    void displayInsuranceCompanies() {
        for (const auto &company : companies) {
            std::cout << "Name: " << company.name << "\nAddress: " << company.address << "\nPhone: " << company.phone << "\n\n";
        }
    }
};

int main() {
    CarInsuranceService service;
    int choice;
    do {
        std::cout << "Car Insurance Management System\n";
        std::cout << "1. Add Car\n2. Delete Car\n3. Update Car\n4. Search Car\n5. Display Cars\n";
        std::cout << "6. Add Insurance Company\n7. Delete Insurance Company\n8. Update Insurance Company\n9. Search Insurance Company\n10. Display Insurance Companies\n0. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;
        switch (choice) {
            case 1: service.addCar(); break;
            case 2: service.deleteCar(); break;
            case 3: service.updateCar(); break;
            case 4: service.searchCar(); break;
            case 5: service.displayCars(); break;
            case 6: service.addInsuranceCompany(); break;
            case 7: service.deleteInsuranceCompany(); break;
            case 8: service.updateInsuranceCompany(); break;
            case 9: service.searchInsuranceCompany(); break;
            case 10: service.displayInsuranceCompanies(); break;
        }
    } while (choice != 0);
    return 0;
}