#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string model;
    std::string ownerName;

    Car(std::string lp, std::string m, std::string on)
        : licensePlate(lp), model(m), ownerName(on) {}
};

class InsuranceCompany {
public:
    std::string name;
    std::string address;
    std::vector<Car> insuredCars;

    InsuranceCompany(std::string n, std::string a)
        : name(n), address(a) {}
    
    void addCar(const Car &car) {
        insuredCars.push_back(car);
    }

    void deleteCar(const std::string &licensePlate) {
        for (size_t i = 0; i < insuredCars.size(); ++i) {
            if (insuredCars[i].licensePlate == licensePlate) {
                insuredCars.erase(insuredCars.begin() + i);
                break;
            }
        }
    }
};

class CarInsuranceService {
private:
    std::vector<InsuranceCompany> companies;

public:
    void addCompany(const InsuranceCompany &company) {
        companies.push_back(company);
    }

    void deleteCompany(const std::string &companyName) {
        for (size_t i = 0; i < companies.size(); ++i) {
            if (companies[i].name == companyName) {
                companies.erase(companies.begin() + i);
                break;
            }
        }
    }

    void updateCompany(const std::string &companyName, const std::string &newAddress) {
        for (auto &company : companies) {
            if (company.name == companyName) {
                company.address = newAddress;
                break;
            }
        }
    }

    void searchCompany(const std::string &companyName) {
        for (const auto &company : companies) {
            if (company.name == companyName) {
                std::cout << "Company: " << company.name << ", Address: " << company.address << "\n";
                for (const auto &car : company.insuredCars) {
                    std::cout << "Car: " << car.licensePlate << ", Model: " << car.model 
                              << ", Owner: " << car.ownerName << "\n";
                }
                return;
            }
        }
        std::cout << "Company not found.\n";
    }

    void displayAllCompanies() {
        for (const auto &company : companies) {
            std::cout << "Company: " << company.name << ", Address: " << company.address << "\n";
            for (const auto &car : company.insuredCars) {
                std::cout << "Car: " << car.licensePlate << ", Model: " << car.model 
                          << ", Owner: " << car.ownerName << "\n";
            }
        }
    }
};

int main() {
    CarInsuranceService service;
    InsuranceCompany company1("InsureCo", "123 Maple Street");
    company1.addCar(Car("ABC123", "Toyota Camry", "John Doe"));
    company1.addCar(Car("XYZ789", "Honda Civic", "Jane Smith"));
    service.addCompany(company1);

    InsuranceCompany company2("ProtectMe", "456 Oak Avenue");
    company2.addCar(Car("LMN456", "Ford Focus", "Alice Brown"));
    service.addCompany(company2);

    service.displayAllCompanies();
    service.searchCompany("InsureCo");
    service.updateCompany("ProtectMe", "789 Pine Road");
    service.deleteCompany("InsureCo");
    service.displayAllCompanies();

    return 0;
}