#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Car {
public:
    int id;
    string brand;
    string model;
    int year;
    string owner;

    Car(int id, string brand, string model, int year, string owner)
        : id(id), brand(brand), model(model), year(year), owner(owner) {}
};

class InsuranceCompany {
public:
    int id;
    string name;
    string address;
    string contact;

    InsuranceCompany(int id, string name, string address, string contact)
        : id(id), name(name), address(address), contact(contact) {}
};

class System {
    vector<Car> cars;
    vector<InsuranceCompany> companies;

public:
    void addCar(int id, string brand, string model, int year, string owner) {
        cars.push_back(Car(id, brand, model, year, owner));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string brand, string model, int year, string owner) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.brand = brand;
                car.model = model;
                car.year = year;
                car.owner = owner;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void addCompany(int id, string name, string address, string contact) {
        companies.push_back(InsuranceCompany(id, name, address, contact));
    }

    void deleteCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCompany(int id, string name, string address, string contact) {
        for (auto &company : companies) {
            if (company.id == id) {
                company.name = name;
                company.address = address;
                company.contact = contact;
            }
        }
    }

    InsuranceCompany* searchCompany(int id) {
        for (auto &company : companies) {
            if (company.id == id) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "ID: " << car.id 
                 << ", Brand: " << car.brand 
                 << ", Model: " << car.model 
                 << ", Year: " << car.year 
                 << ", Owner: " << car.owner << endl;
        }
    }

    void displayCompanies() {
        for (const auto &company : companies) {
            cout << "ID: " << company.id
                 << ", Name: " << company.name
                 << ", Address: " << company.address
                 << ", Contact: " << company.contact << endl;
        }
    }
};

int main() {
    System sys;

    sys.addCar(1, "Toyota", "Camry", 2020, "John Doe");
    sys.addCar(2, "Honda", "Civic", 2019, "Jane Smith");
    sys.addCompany(1, "InsureCo", "123 Elm St", "555-1234");
    sys.addCompany(2, "SafeGuard Insurance", "456 Oak St", "555-5678");

    sys.displayCars();
    sys.displayCompanies();

    sys.updateCar(1, "Toyota", "Camry", 2021, "John Doe Updated");
    sys.updateCompany(1, "InsureCo Ltd.", "123 Elm St", "555-1234-99");

    Car* car = sys.searchCar(1);
    if (car) {
        cout << "Found Car: " << car->brand << " " << car->model << endl;
    }

    InsuranceCompany* company = sys.searchCompany(1);
    if (company) {
        cout << "Found Company: " << company->name << endl;
    }

    sys.deleteCar(2);
    sys.deleteCompany(2);

    sys.displayCars();
    sys.displayCompanies();

    return 0;
}