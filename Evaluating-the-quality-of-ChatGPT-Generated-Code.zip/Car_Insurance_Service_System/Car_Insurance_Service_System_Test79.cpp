#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string model;
    std::string owner;

    Car(int id, std::string model, std::string owner)
        : id(id), model(model), owner(owner) {}
};

class InsuranceCompany {
public:
    int id;
    std::string name;
    std::string contact;

    InsuranceCompany(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class Database {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(int id, std::string model, std::string owner) {
        cars.emplace_back(id, model, owner);
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, std::string newModel, std::string newOwner) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.model = newModel;
                car.owner = newOwner;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "Car ID: " << car.id
                      << ", Model: " << car.model
                      << ", Owner: " << car.owner << std::endl;
        }
    }

    void addInsuranceCompany(int id, std::string name, std::string contact) {
        companies.emplace_back(id, name, contact);
    }

    void deleteInsuranceCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(int id, std::string newName, std::string newContact) {
        for (auto &company : companies) {
            if (company.id == id) {
                company.name = newName;
                company.contact = newContact;
                break;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(int id) {
        for (auto &company : companies) {
            if (company.id == id) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto &company : companies) {
            std::cout << "Company ID: " << company.id
                      << ", Name: " << company.name
                      << ", Contact: " << company.contact << std::endl;
        }
    }
};

int main() {
    Database db;
    db.addCar(1, "Toyota Corolla", "John Doe");
    db.addCar(2, "Honda Civic", "Jane Smith");
    db.addInsuranceCompany(1, "InsureCo", "123-456-7890");
    db.addInsuranceCompany(2, "SafeGuard", "987-654-3210");

    std::cout << "All Cars:\n";
    db.displayCars();
    std::cout << "\nAll Insurance Companies:\n";
    db.displayInsuranceCompanies();

    return 0;
}