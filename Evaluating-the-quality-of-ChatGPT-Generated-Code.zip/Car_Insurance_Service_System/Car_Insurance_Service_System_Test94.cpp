#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string model;
    std::string owner;

    Car(int i, const std::string& m, const std::string& o) : id(i), model(m), owner(o) {}
};

class InsuranceCompany {
public:
    int id;
    std::string name;
    std::string address;

    InsuranceCompany(int i, const std::string& n, const std::string& a) : id(i), name(n), address(a) {}
};

class CarInsuranceService {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(int id, const std::string& model, const std::string& owner) {
        cars.push_back(Car(id, model, owner));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, const std::string& model, const std::string& owner) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.model = model;
                car.owner = owner;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() const {
        for (const auto& car : cars) {
            std::cout << "Car ID: " << car.id
                      << ", Model: " << car.model
                      << ", Owner: " << car.owner << std::endl;
        }
    }

    void addInsuranceCompany(int id, const std::string& name, const std::string& address) {
        companies.push_back(InsuranceCompany(id, name, address));
    }

    void deleteInsuranceCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(int id, const std::string& name, const std::string& address) {
        for (auto& company : companies) {
            if (company.id == id) {
                company.name = name;
                company.address = address;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(int id) {
        for (auto& company : companies) {
            if (company.id == id) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() const {
        for (const auto& company : companies) {
            std::cout << "Company ID: " << company.id
                      << ", Name: " << company.name
                      << ", Address: " << company.address << std::endl;
        }
    }
};

int main() {
    CarInsuranceService service;
    service.addCar(1, "Toyota Camry", "John Doe");
    service.addCar(2, "Honda Accord", "Jane Smith");
    service.displayCars();

    service.addInsuranceCompany(100, "SafeAuto", "123 Main St");
    service.addInsuranceCompany(101, "Reliable Coverage", "456 Elm St");
    service.displayInsuranceCompanies();

    service.updateCar(1, "Toyota Corolla", "John Doe");
    service.deleteCar(2);
    service.displayCars();

    service.updateInsuranceCompany(100, "SafeAuto Insurance", "123 Main St, Suite 100");
    service.deleteInsuranceCompany(101);
    service.displayInsuranceCompanies();

    return 0;
}