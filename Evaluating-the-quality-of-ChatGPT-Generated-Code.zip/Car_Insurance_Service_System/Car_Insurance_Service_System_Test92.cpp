#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string model;
    std::string ownerName;

    Car(std::string license, std::string mod, std::string owner) 
        : licensePlate(license), model(mod), ownerName(owner) {}
};

class InsuranceCompany {
public:
    std::string name;
    std::string policyNumber;
    std::string contactInfo;

    InsuranceCompany(std::string n, std::string policy, std::string contact)
        : name(n), policyNumber(policy), contactInfo(contact) {}
};

class InsuranceServiceSystem {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

    template <typename T>
    void display(std::vector<T> &v) {
        for (size_t i = 0; i < v.size(); ++i) {
            std::cout << i+1 << ". " << v[i].licensePlate << ", " 
                      << v[i].model << ", " << v[i].ownerName << std::endl;
        }
    }

public:
    void addCar(Car car) {
        cars.push_back(car);
    }

    void deleteCar(const std::string &licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string &licensePlate, const Car &newCar) {
        for (auto &car : cars) {
            if (car.licensePlate == licensePlate) {
                car = newCar;
                break;
            }
        }
    }

    Car* searchCar(const std::string &licensePlate) {
        for (auto &car : cars) {
            if (car.licensePlate == licensePlate) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        display(cars);
    }

    void addCompany(InsuranceCompany company) {
        companies.push_back(company);
    }

    void deleteCompany(const std::string &name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCompany(const std::string &name, const InsuranceCompany &newCompany) {
        for (auto &company : companies) {
            if (company.name == name) {
                company = newCompany;
                break;
            }
        }
    }

    InsuranceCompany* searchCompany(const std::string &name) {
        for (auto &company : companies) {
            if (company.name == name) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayCompanies() {
        for (size_t i = 0; i < companies.size(); ++i) {
            std::cout << i+1 << ". " << companies[i].name << ", " 
                      << companies[i].policyNumber << ", " 
                      << companies[i].contactInfo << std::endl;
        }
    }
};

int main() {
    InsuranceServiceSystem system;
    
    system.addCar(Car("ABC123", "Toyota", "John Doe"));
    system.addCar(Car("XYZ789", "Honda", "Jane Smith"));

    system.addCompany(InsuranceCompany("SecureInsure", "POL12345", "123-456-7890"));
    system.addCompany(InsuranceCompany("SafeGuard", "POL54321", "987-654-3210"));

    std::cout << "Cars:" << std::endl;
    system.displayCars();

    std::cout << "Companies:" << std::endl;
    system.displayCompanies();

    Car* car = system.searchCar("ABC123");
    if (car) {
        std::cout << "Found Car: " << car->licensePlate << ", " << car->model << ", " << car->ownerName << std::endl;
    }

    InsuranceCompany* company = system.searchCompany("SecureInsure");
    if (company) {
        std::cout << "Found Company: " << company->name << ", " << company->policyNumber << ", " << company->contactInfo << std::endl;
    }

    return 0;
}