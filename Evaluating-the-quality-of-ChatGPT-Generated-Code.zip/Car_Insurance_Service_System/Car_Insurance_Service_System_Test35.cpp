#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    string carId;
    string model;
    string owner;
};

struct InsuranceCompany {
    string companyId;
    string name;
    string contact;
};

vector<Car> carDatabase;
vector<InsuranceCompany> insuranceCompaniesDatabase;

void addCar(const Car& car) {
    carDatabase.push_back(car);
}

void addInsuranceCompany(const InsuranceCompany& company) {
    insuranceCompaniesDatabase.push_back(company);
}

void deleteCar(const string& carId) {
    for (auto it = carDatabase.begin(); it != carDatabase.end(); ++it) {
        if (it->carId == carId) {
            carDatabase.erase(it);
            return;
        }
    }
}

void deleteInsuranceCompany(const string& companyId) {
    for (auto it = insuranceCompaniesDatabase.begin(); it != insuranceCompaniesDatabase.end(); ++it) {
        if (it->companyId == companyId) {
            insuranceCompaniesDatabase.erase(it);
            return;
        }
    }
}

void updateCar(const string& carId, const Car& updatedCar) {
    for (auto& car : carDatabase) {
        if (car.carId == carId) {
            car = updatedCar;
            return;
        }
    }
}

void updateInsuranceCompany(const string& companyId, const InsuranceCompany& updatedCompany) {
    for (auto& company : insuranceCompaniesDatabase) {
        if (company.companyId == companyId) {
            company = updatedCompany;
            return;
        }
    }
}

Car* searchCar(const string& carId) {
    for (auto& car : carDatabase) {
        if (car.carId == carId) {
            return &car;
        }
    }
    return nullptr;
}

InsuranceCompany* searchInsuranceCompany(const string& companyId) {
    for (auto& company : insuranceCompaniesDatabase) {
        if (company.companyId == companyId) {
            return &company;
        }
    }
    return nullptr;
}

void displayCars() {
    for (const auto& car : carDatabase) {
        cout << "Car ID: " << car.carId << ", Model: " << car.model << ", Owner: " << car.owner << endl;
    }
}

void displayInsuranceCompanies() {
    for (const auto& company : insuranceCompaniesDatabase) {
        cout << "Company ID: " << company.companyId << ", Name: " << company.name << ", Contact: " << company.contact << endl;
    }
}

int main() {
    Car car1 = {"1", "Toyota Corolla", "John Doe"};
    Car car2 = {"2", "Honda Civic", "Jane Smith"};
    InsuranceCompany company1 = {"101", "Insurance Co. A", "123456789"};
    InsuranceCompany company2 = {"102", "Insurance Co. B", "987654321"};

    addCar(car1);
    addCar(car2);
    addInsuranceCompany(company1);
    addInsuranceCompany(company2);

    displayCars();
    displayInsuranceCompanies();

    Car* searchedCar = searchCar("1");
    if (searchedCar) {
        cout << "Found Car: " << searchedCar->model << endl;
    }

    InsuranceCompany* searchedCompany = searchInsuranceCompany("102");
    if (searchedCompany) {
        cout << "Found Company: " << searchedCompany->name << endl;
    }

    return 0;
}