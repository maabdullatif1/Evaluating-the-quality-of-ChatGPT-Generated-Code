#include <iostream>
#include <string>
#include <vector>

struct Car {
    std::string licensePlate;
    std::string make;
    std::string model;
};

struct InsuranceCompany {
    std::string name;
    std::string contactNumber;
};

std::vector<Car> cars;
std::vector<InsuranceCompany> companies;

void addCar(const Car& car) {
    cars.push_back(car);
}

void deleteCar(const std::string& licensePlate) {
    for (auto it = cars.begin(); it != cars.end(); ++it) {
        if (it->licensePlate == licensePlate) {
            cars.erase(it);
            break;
        }
    }
}

void updateCar(const std::string& licensePlate, const Car& updatedCar) {
    for (auto& car : cars) {
        if (car.licensePlate == licensePlate) {
            car = updatedCar;
            break;
        }
    }
}

Car* searchCar(const std::string& licensePlate) {
    for (auto& car : cars) {
        if (car.licensePlate == licensePlate) {
            return &car;
        }
    }
    return nullptr;
}

void displayCars() {
    for (const auto& car : cars) {
        std::cout << "License Plate: " << car.licensePlate
                  << ", Make: " << car.make
                  << ", Model: " << car.model << std::endl;
    }
}

void addCompany(const InsuranceCompany& company) {
    companies.push_back(company);
}

void deleteCompany(const std::string& name) {
    for (auto it = companies.begin(); it != companies.end(); ++it) {
        if (it->name == name) {
            companies.erase(it);
            break;
        }
    }
}

void updateCompany(const std::string& name, const InsuranceCompany& updatedCompany) {
    for (auto& company : companies) {
        if (company.name == name) {
            company = updatedCompany;
            break;
        }
    }
}

InsuranceCompany* searchCompany(const std::string& name) {
    for (auto& company : companies) {
        if (company.name == name) {
            return &company;
        }
    }
    return nullptr;
}

void displayCompanies() {
    for (const auto& company : companies) {
        std::cout << "Name: " << company.name
                  << ", Contact: " << company.contactNumber << std::endl;
    }
}

int main() {
    Car car1 = {"ABC123", "Toyota", "Corolla"};
    Car car2 = {"XYZ789", "Honda", "Civic"};
    InsuranceCompany company1 = {"InsureCo", "123-456-7890"};
    InsuranceCompany company2 = {"SafeCover", "098-765-4321"};
    
    addCar(car1);
    addCar(car2);
    addCompany(company1);
    addCompany(company2);
    
    displayCars();
    displayCompanies();
    
    Car* foundCar = searchCar("ABC123");
    if (foundCar) {
        std::cout << "Found Car: " << foundCar->licensePlate << std::endl;
    }
    
    InsuranceCompany* foundCompany = searchCompany("InsureCo");
    if (foundCompany) {
        std::cout << "Found Company: " << foundCompany->name << std::endl;
    }
    
    updateCar("XYZ789", {"XYZ789", "Honda", "Accord"});
    updateCompany("SafeCover", {"SafeCover", "111-222-3333"});
    
    deleteCar("ABC123");
    deleteCompany("InsureCo");
    
    displayCars();
    displayCompanies();
    
    return 0;
}