#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Car {
    string licensePlate;
    string ownerName;
    string model;
    string color;
};

struct InsuranceCompany {
    string name;
    string address;
    vector<Car> insuredCars;
};

class InsuranceServiceSystem {
    vector<InsuranceCompany> companies;

public:
    void addCompany(const InsuranceCompany& company) {
        companies.push_back(company);
    }

    void removeCompany(const string& name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                return;
            }
        }
    }

    void updateCompany(const string& name, const InsuranceCompany& newCompanyInfo) {
        for (auto& company : companies) {
            if (company.name == name) {
                company = newCompanyInfo;
                return;
            }
        }
    }

    void searchCompany(const string& name) {
        for (const auto& company : companies) {
            if (company.name == name) {
                cout << "Company found: " << company.name << ", Address: " << company.address << endl;
                return;
            }
        }
        cout << "Company not found." << endl;
    }

    void displayCompanies() {
        for (const auto& company : companies) {
            cout << "Company: " << company.name << ", Address: " << company.address << endl;
            for (const auto& car : company.insuredCars) {
                cout << "  Car: " << car.licensePlate << ", Owner: " << car.ownerName 
                     << ", Model: " << car.model << ", Color: " << car.color << endl;
            }
        }
    }

    void addCarToCompany(const string& companyName, const Car& car) {
        for (auto& company : companies) {
            if (company.name == companyName) {
                company.insuredCars.push_back(car);
                return;
            }
        }
    }

    void removeCarFromCompany(const string& companyName, const string& licensePlate) {
        for (auto& company : companies) {
            if (company.name == companyName) {
                for (auto it = company.insuredCars.begin(); it != company.insuredCars.end(); ++it) {
                    if (it->licensePlate == licensePlate) {
                        company.insuredCars.erase(it);
                        return;
                    }
                }
            }
        }
    }

    void updateCarInCompany(const string& companyName, const string& licensePlate, const Car& newCarInfo) {
        for (auto& company : companies) {
            if (company.name == companyName) {
                for (auto& car : company.insuredCars) {
                    if (car.licensePlate == licensePlate) {
                        car = newCarInfo;
                        return;
                    }
                }
            }
        }
    }

    void searchCarInCompany(const string& companyName, const string& licensePlate) {
        for (const auto& company : companies) {
            if (company.name == companyName) {
                for (const auto& car : company.insuredCars) {
                    if (car.licensePlate == licensePlate) {
                        cout << "Car found: " << car.licensePlate << ", Owner: " << car.ownerName 
                             << ", Model: " << car.model << ", Color: " << car.color << endl;
                        return;
                    }
                }
            }
        }
        cout << "Car not found." << endl;
    }
};

int main() {
    InsuranceServiceSystem system;

    Car car1 = {"123ABC", "John Doe", "Toyota Corolla", "Red"};
    Car car2 = {"456DEF", "Jane Smith", "Honda Civic", "Blue"};

    InsuranceCompany company1 = {"SecureLife", "123 Main St", {car1, car2}};
    system.addCompany(company1);

    system.displayCompanies();

    system.searchCompany("SecureLife");
    system.searchCarInCompany("SecureLife", "123ABC");

    system.updateCarInCompany("SecureLife", "123ABC", {"123ABC", "John Doe", "Toyota Camry", "Black"});
    system.displayCompanies();

    system.removeCarFromCompany("SecureLife", "456DEF");
    system.displayCompanies();

    system.removeCompany("SecureLife");
    system.displayCompanies();

    return 0;
}