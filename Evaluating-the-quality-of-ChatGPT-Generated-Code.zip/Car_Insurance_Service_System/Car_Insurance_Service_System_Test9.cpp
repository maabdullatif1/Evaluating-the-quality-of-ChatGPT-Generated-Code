#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Car {
    int carId;
    string model;
    string ownerName;
};

struct InsuranceCompany {
    int companyId;
    string companyName;
    string policyNumber;
};

vector<Car> cars;
vector<InsuranceCompany> insuranceCompanies;

void addCar() {
    Car car;
    cout << "Enter Car ID: ";
    cin >> car.carId;
    cout << "Enter Car Model: ";
    cin.ignore();
    getline(cin, car.model);
    cout << "Enter Owner Name: ";
    getline(cin, car.ownerName);
    cars.push_back(car);
}

void addInsuranceCompany() {
    InsuranceCompany company;
    cout << "Enter Company ID: ";
    cin >> company.companyId;
    cout << "Enter Company Name: ";
    cin.ignore();
    getline(cin, company.companyName);
    cout << "Enter Policy Number: ";
    getline(cin, company.policyNumber);
    insuranceCompanies.push_back(company);
}

void deleteCar() {
    int id;
    cout << "Enter Car ID to delete: ";
    cin >> id;

    for (size_t i = 0; i < cars.size(); ++i) {
        if (cars[i].carId == id) {
            cars.erase(cars.begin() + i);
            cout << "Car deleted.\n";
            return;
        }
    }
    cout << "Car not found.\n";
}

void deleteInsuranceCompany() {
    int id;
    cout << "Enter Company ID to delete: ";
    cin >> id;

    for (size_t i = 0; i < insuranceCompanies.size(); ++i) {
        if (insuranceCompanies[i].companyId == id) {
            insuranceCompanies.erase(insuranceCompanies.begin() + i);
            cout << "Company deleted.\n";
            return;
        }
    }
    cout << "Company not found.\n";
}

void updateCar() {
    int id;
    cout << "Enter Car ID to update: ";
    cin >> id;

    for (auto &car : cars) {
        if (car.carId == id) {
            cout << "Enter new Car Model: ";
            cin.ignore();
            getline(cin, car.model);
            cout << "Enter new Owner Name: ";
            getline(cin, car.ownerName);
            cout << "Car updated.\n";
            return;
        }
    }
    cout << "Car not found.\n";
}

void updateInsuranceCompany() {
    int id;
    cout << "Enter Company ID to update: ";
    cin >> id;

    for (auto &company : insuranceCompanies) {
        if (company.companyId == id) {
            cout << "Enter new Company Name: ";
            cin.ignore();
            getline(cin, company.companyName);
            cout << "Enter new Policy Number: ";
            getline(cin, company.policyNumber);
            cout << "Company updated.\n";
            return;
        }
    }
    cout << "Company not found.\n";
}

void searchCar() {
    int id;
    cout << "Enter Car ID to search: ";
    cin >> id;

    for (const auto &car : cars) {
        if (car.carId == id) {
            cout << "Car found: " << car.model << ", Owner: " << car.ownerName << "\n";
            return;
        }
    }
    cout << "Car not found.\n";
}

void searchInsuranceCompany() {
    int id;
    cout << "Enter Company ID to search: ";
    cin >> id;

    for (const auto &company : insuranceCompanies) {
        if (company.companyId == id) {
            cout << "Company found: " << company.companyName << ", Policy: " << company.policyNumber << "\n";
            return;
        }
    }
    cout << "Company not found.\n";
}

void displayCars() {
    cout << "Cars Information:\n";
    for (const auto &car : cars) {
        cout << "Car ID: " << car.carId << ", Model: " << car.model << ", Owner: " << car.ownerName << "\n";
    }
}

void displayInsuranceCompanies() {
    cout << "Insurance Companies Information:\n";
    for (const auto &company : insuranceCompanies) {
        cout << "Company ID: " << company.companyId << ", Name: " << company.companyName
             << ", Policy: " << company.policyNumber << "\n";
    }
}

int main() {
    int choice;
    while (true) {
        cout << "\nCar Insurance Service System\n";
        cout << "1. Add Car\n";
        cout << "2. Add Insurance Company\n";
        cout << "3. Delete Car\n";
        cout << "4. Delete Insurance Company\n";
        cout << "5. Update Car\n";
        cout << "6. Update Insurance Company\n";
        cout << "7. Search Car\n";
        cout << "8. Search Insurance Company\n";
        cout << "9. Display Cars\n";
        cout << "10. Display Insurance Companies\n";
        cout << "11. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        
        switch (choice) {
            case 1: addCar(); break;
            case 2: addInsuranceCompany(); break;
            case 3: deleteCar(); break;
            case 4: deleteInsuranceCompany(); break;
            case 5: updateCar(); break;
            case 6: updateInsuranceCompany(); break;
            case 7: searchCar(); break;
            case 8: searchInsuranceCompany(); break;
            case 9: displayCars(); break;
            case 10: displayInsuranceCompanies(); break;
            case 11: return 0;
            default: cout << "Invalid choice.\n";
        }
    }
}