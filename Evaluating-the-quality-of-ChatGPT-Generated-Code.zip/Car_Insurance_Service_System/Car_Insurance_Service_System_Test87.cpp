#include <iostream>
#include <vector>
#include <string>

struct Car {
    int id;
    std::string make;
    std::string model;
    int year;
};

struct InsuranceCompany {
    int id;
    std::string name;
    std::string contact;
};

class CarInsuranceSystem {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> insuranceCompanies;

    int generateCarId() {
        return cars.empty() ? 1 : cars.back().id + 1;
    }

    int generateCompanyId() {
        return insuranceCompanies.empty() ? 1 : insuranceCompanies.back().id + 1;
    }

public:
    void addCar(const std::string& make, const std::string& model, int year) {
        cars.push_back({generateCarId(), make, model, year});
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, const std::string& make, const std::string& model, int year) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.year = year;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Car ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << ", Year: " << car.year << '\n';
        }
    }

    void addInsuranceCompany(const std::string& name, const std::string& contact) {
        insuranceCompanies.push_back({generateCompanyId(), name, contact});
    }

    void deleteInsuranceCompany(int id) {
        for (auto it = insuranceCompanies.begin(); it != insuranceCompanies.end(); ++it) {
            if (it->id == id) {
                insuranceCompanies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(int id, const std::string& name, const std::string& contact) {
        for (auto& company : insuranceCompanies) {
            if (company.id == id) {
                company.name = name;
                company.contact = contact;
                break;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(int id) {
        for (auto& company : insuranceCompanies) {
            if (company.id == id) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto& company : insuranceCompanies) {
            std::cout << "Company ID: " << company.id << ", Name: " << company.name << ", Contact: " << company.contact << '\n';
        }
    }
};

int main() {
    CarInsuranceSystem system;
    
    system.addCar("Toyota", "Camry", 2020);
    system.addCar("Ford", "Mustang", 2021);
    system.displayCars();

    system.addInsuranceCompany("ABC Insurance", "123-456-7890");
    system.addInsuranceCompany("XYZ Insurance", "987-654-3210");
    system.displayInsuranceCompanies();

    system.updateCar(1, "Toyota", "Corolla", 2020);
    system.displayCars();

    system.deleteInsuranceCompany(1);
    system.displayInsuranceCompanies();

    return 0;
}