#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string model;
    std::string owner;

    Car(int i, const std::string& m, const std::string& o) : id(i), model(m), owner(o) {}
};

class InsuranceCompany {
public:
    int id;
    std::string name;
    std::string contact;

    InsuranceCompany(int i, const std::string& n, const std::string& c) : id(i), name(n), contact(c) {}
};

class CarInsuranceService {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;
    int carIdCounter = 1;
    int companyIdCounter = 1;

public:
    void addCar(const std::string& model, const std::string& owner) {
        cars.emplace_back(carIdCounter++, model, owner);
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, const std::string& model, const std::string& owner) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.model = model;
                car.owner = owner;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() const {
        for (const auto& car : cars) {
            std::cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << '\n';
        }
    }

    void addInsuranceCompany(const std::string& name, const std::string& contact) {
        companies.emplace_back(companyIdCounter++, name, contact);
    }

    void deleteInsuranceCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(int id, const std::string& name, const std::string& contact) {
        for (auto& company : companies) {
            if (company.id == id) {
                company.name = name;
                company.contact = contact;
                break;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(int id) {
        for (auto& company : companies) {
            if (company.id == id) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() const {
        for (const auto& company : companies) {
            std::cout << "Company ID: " << company.id << ", Name: " << company.name << ", Contact: " << company.contact << '\n';
        }
    }
};

int main() {
    CarInsuranceService service;
    service.addCar("Toyota", "John Doe");
    service.addInsuranceCompany("ABC Insurance", "1234567890");
    
    std::cout << "Cars:\n";
    service.displayCars();
    
    std::cout << "\nInsurance Companies:\n";
    service.displayInsuranceCompanies();

    return 0;
}