#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string model;
    std::string owner;
    Car(int id, std::string model, std::string owner) : id(id), model(model), owner(owner) {}
};

class InsuranceCompany {
public:
    int id;
    std::string name;
    std::string address;
    InsuranceCompany(int id, std::string name, std::string address) : id(id), name(name), address(address) {}
};

class CarInsuranceService {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(int id, std::string model, std::string owner) {
        cars.push_back(Car(id, model, owner));
    }
    
    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }
    
    void updateCar(int id, std::string model, std::string owner) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.model = model;
                car.owner = owner;
                break;
            }
        }
    }
    
    void searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                std::cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << std::endl;
                return;
            }
        }
        std::cout << "Car not found." << std::endl;
    }
    
    void displayCars() {
        for (auto &car : cars) {
            std::cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << std::endl;
        }
    }
    
    void addCompany(int id, std::string name, std::string address) {
        companies.push_back(InsuranceCompany(id, name, address));
    }
    
    void deleteCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }
    
    void updateCompany(int id, std::string name, std::string address) {
        for (auto &company : companies) {
            if (company.id == id) {
                company.name = name;
                company.address = address;
                break;
            }
        }
    }
    
    void searchCompany(int id) {
        for (auto &company : companies) {
            if (company.id == id) {
                std::cout << "Company ID: " << company.id << ", Name: " << company.name << ", Address: " << company.address << std::endl;
                return;
            }
        }
        std::cout << "Company not found." << std::endl;
    }
    
    void displayCompanies() {
        for (auto &company : companies) {
            std::cout << "Company ID: " << company.id << ", Name: " << company.name << ", Address: " << company.address << std::endl;
        }
    }
};

int main() {
    CarInsuranceService service;
    service.addCar(1, "Model X", "Alice");
    service.addCar(2, "Model Y", "Bob");
    service.displayCars();
    service.updateCar(1, "Model S", "Alice Smith");
    service.searchCar(1);
    service.deleteCar(2);
    service.displayCars();

    service.addCompany(1, "Insurance A", "123 Main St");
    service.addCompany(2, "Insurance B", "456 Elm St");
    service.displayCompanies();
    service.updateCompany(2, "Insurance B Inc.", "456 Elm St, Suite 100");
    service.searchCompany(2);
    service.deleteCompany(1);
    service.displayCompanies();

    return 0;
}