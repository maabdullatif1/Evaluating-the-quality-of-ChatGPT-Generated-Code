#include <iostream>
#include <string>
#include <vector>

class Car {
public:
    int id;
    std::string model;
    std::string owner;

    Car(int id, const std::string& model, const std::string& owner)
        : id(id), model(model), owner(owner) {}
};

class InsuranceCompany {
public:
    int id;
    std::string name;
    std::string contactDetails;

    InsuranceCompany(int id, const std::string& name, const std::string& contactDetails)
        : id(id), name(name), contactDetails(contactDetails) {}
};

class CarInsuranceService {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(int id, const std::string& model, const std::string& owner) {
        cars.push_back(Car(id, model, owner));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, const std::string& model, const std::string& owner) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.model = model;
                car.owner = owner;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() const {
        for (const auto& car : cars) {
            std::cout << "ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << std::endl;
        }
    }

    void addInsuranceCompany(int id, const std::string& name, const std::string& contactDetails) {
        companies.push_back(InsuranceCompany(id, name, contactDetails));
    }

    void deleteInsuranceCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(int id, const std::string& name, const std::string& contactDetails) {
        for (auto& company : companies) {
            if (company.id == id) {
                company.name = name;
                company.contactDetails = contactDetails;
                break;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(int id) {
        for (auto& company : companies) {
            if (company.id == id) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() const {
        for (const auto& company : companies) {
            std::cout << "ID: " << company.id << ", Name: " << company.name
                      << ", Contact Details: " << company.contactDetails << std::endl;
        }
    }
};

int main() {
    CarInsuranceService service;
    service.addCar(1, "Toyota Corolla", "John Doe");
    service.addCar(2, "Honda Civic", "Jane Smith");

    service.displayCars();

    service.addInsuranceCompany(1, "Progressive", "123-456-7890");
    service.addInsuranceCompany(2, "Geico", "987-654-3210");

    service.displayInsuranceCompanies();

    return 0;
}