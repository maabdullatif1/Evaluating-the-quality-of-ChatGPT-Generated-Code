#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string make;
    string model;
    int year;

    Car(int id, string make, string model, int year) : id(id), make(make), model(model), year(year) {}
};

class InsuranceCompany {
public:
    int id;
    string name;
    string contact;

    InsuranceCompany(int id, string name, string contact) : id(id), name(name), contact(contact) {}
};

class InsuranceServiceSystem {
    vector<Car> cars;
    vector<InsuranceCompany> companies;

public:
    void addCar(int id, string make, string model, int year) {
        cars.push_back(Car(id, make, model, year));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string make, string model, int year) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.year = year;
                break;
            }
        }
    }

    void searchCar(int id) {
        for (const auto& car : cars) {
            if (car.id == id) {
                cout << "Car ID: " << car.id << " Make: " << car.make << " Model: " << car.model << " Year: " << car.year << endl;
                return;
            }
        }
        cout << "Car not found." << endl;
    }

    void displayCars() {
        for (const auto& car : cars) {
            cout << "Car ID: " << car.id << " Make: " << car.make << " Model: " << car.model << " Year: " << car.year << endl;
        }
    }

    void addCompany(int id, string name, string contact) {
        companies.push_back(InsuranceCompany(id, name, contact));
    }

    void deleteCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCompany(int id, string name, string contact) {
        for (auto& company : companies) {
            if (company.id == id) {
                company.name = name;
                company.contact = contact;
                break;
            }
        }
    }

    void searchCompany(int id) {
        for (const auto& company : companies) {
            if (company.id == id) {
                cout << "Company ID: " << company.id << " Name: " << company.name << " Contact: " << company.contact << endl;
                return;
            }
        }
        cout << "Company not found." << endl;
    }

    void displayCompanies() {
        for (const auto& company : companies) {
            cout << "Company ID: " << company.id << " Name: " << company.name << " Contact: " << company.contact << endl;
        }
    }
};

int main() {
    InsuranceServiceSystem service;
    service.addCar(1, "Toyota", "Camry", 2020);
    service.addCar(2, "Honda", "Civic", 2019);
    service.addCompany(1, "ABC Insurance", "123-456-7890");

    cout << "Cars:" << endl;
    service.displayCars();

    cout << "\nCompanies:" << endl;
    service.displayCompanies();

    service.searchCar(1);
    service.updateCar(1, "Toyota", "Corolla", 2021);
    service.displayCars();

    service.deleteCar(2);
    service.displayCars();

    service.searchCompany(1);
    service.updateCompany(1, "XYZ Insurance", "987-654-3210");
    service.displayCompanies();

    service.deleteCompany(1);
    service.displayCompanies();

    return 0;
}