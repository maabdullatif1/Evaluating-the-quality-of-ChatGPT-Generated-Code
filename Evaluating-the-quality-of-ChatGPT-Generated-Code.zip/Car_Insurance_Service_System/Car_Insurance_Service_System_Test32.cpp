#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string make;
    string model;
    string license;

    Car(int id, string make, string model, string license)
        : id(id), make(make), model(model), license(license) {}
};

class InsuranceCompany {
public:
    int id;
    string name;
    string policyNumber;

    InsuranceCompany(int id, string name, string policyNumber)
        : id(id), name(name), policyNumber(policyNumber) {}
};

class CarInsuranceService {
    vector<Car> cars;
    vector<InsuranceCompany> insuranceCompanies;

public:
    void addCar(int id, string make, string model, string license) {
        cars.push_back(Car(id, make, model, license));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                return;
            }
        }
    }

    void updateCar(int id, string newMake, string newModel, string newLicense) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.make = newMake;
                car.model = newModel;
                car.license = newLicense;
                return;
            }
        }
    }

    void searchCar(int id) {
        for (const auto &car : cars) {
            if (car.id == id) {
                cout << "Car found: " << car.make << " " << car.model << " " << car.license << endl;
                return;
            }
        }
        cout << "Car not found" << endl;
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "Car ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << ", License: " << car.license << endl;
        }
    }

    void addInsuranceCompany(int id, string name, string policyNumber) {
        insuranceCompanies.push_back(InsuranceCompany(id, name, policyNumber));
    }

    void deleteInsuranceCompany(int id) {
        for (auto it = insuranceCompanies.begin(); it != insuranceCompanies.end(); ++it) {
            if (it->id == id) {
                insuranceCompanies.erase(it);
                return;
            }
        }
    }

    void updateInsuranceCompany(int id, string newName, string newPolicyNumber) {
        for (auto &company : insuranceCompanies) {
            if (company.id == id) {
                company.name = newName;
                company.policyNumber = newPolicyNumber;
                return;
            }
        }
    }

    void searchInsuranceCompany(int id) {
        for (const auto &company : insuranceCompanies) {
            if (company.id == id) {
                cout << "Insurance Company found: " << company.name << " " << company.policyNumber << endl;
                return;
            }
        }
        cout << "Insurance Company not found" << endl;
    }

    void displayInsuranceCompanies() {
        for (const auto &company : insuranceCompanies) {
            cout << "Company ID: " << company.id << ", Name: " << company.name << ", Policy Number: " << company.policyNumber << endl;
        }
    }
};

int main() {
    CarInsuranceService service;
    service.addCar(1, "Toyota", "Corolla", "AB1234");
    service.addCar(2, "Honda", "Civic", "CD5678");
    service.displayCars();

    service.addInsuranceCompany(1, "InsureCo", "P123456");
    service.addInsuranceCompany(2, "SafeGuard", "P654321");
    service.displayInsuranceCompanies();

    service.searchCar(1);
    service.updateCar(2, "Honda", "Accord", "EF6789");
    service.displayCars();

    service.searchInsuranceCompany(2);
    service.deleteInsuranceCompany(1);
    service.displayInsuranceCompanies();

    return 0;
}