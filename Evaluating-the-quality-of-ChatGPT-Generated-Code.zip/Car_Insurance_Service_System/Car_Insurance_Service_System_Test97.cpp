#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string model;
    std::string owner;

    Car(const std::string& license, const std::string& modelName, const std::string& ownerName)
        : licensePlate(license), model(modelName), owner(ownerName) {}
};

class InsuranceCompany {
public:
    std::string name;
    std::string contactDetails;

    InsuranceCompany(const std::string& companyName, const std::string& contact)
        : name(companyName), contactDetails(contact) {}
};

class InsuranceServiceSystem {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(const std::string& license, const std::string& model, const std::string& owner) {
        cars.emplace_back(license, model, owner);
    }

    void deleteCar(const std::string& license) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == license) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string& license, const std::string& newModel, const std::string& newOwner) {
        for (auto& car : cars) {
            if (car.licensePlate == license) {
                car.model = newModel;
                car.owner = newOwner;
                break;
            }
        }
    }

    void searchCar(const std::string& license) {
        for (const auto& car : cars) {
            if (car.licensePlate == license) {
                std::cout << "License Plate: " << car.licensePlate << ", Model: " << car.model << ", Owner: " << car.owner << "\n";
                return;
            }
        }
        std::cout << "Car not found.\n";
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "License Plate: " << car.licensePlate << ", Model: " << car.model << ", Owner: " << car.owner << "\n";
        }
    }

    void addCompany(const std::string& name, const std::string& contact) {
        companies.emplace_back(name, contact);
    }

    void deleteCompany(const std::string& name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCompany(const std::string& name, const std::string& newContact) {
        for (auto& company : companies) {
            if (company.name == name) {
                company.contactDetails = newContact;
                break;
            }
        }
    }

    void searchCompany(const std::string& name) {
        for (const auto& company : companies) {
            if (company.name == name) {
                std::cout << "Company Name: " << company.name << ", Contact Details: " << company.contactDetails << "\n";
                return;
            }
        }
        std::cout << "Company not found.\n";
    }

    void displayCompanies() {
        for (const auto& company : companies) {
            std::cout << "Company Name: " << company.name << ", Contact Details: " << company.contactDetails << "\n";
        }
    }
};

int main() {
    InsuranceServiceSystem system;
    system.addCar("ABC123", "Toyota", "John Doe");
    system.addCar("XYZ789", "Honda", "Jane Smith");
    system.displayCars();
    system.addCompany("InsureFast", "contact@insurefast.com");
    system.addCompany("SafeCover", "support@safecover.com");
    system.displayCompanies();
    system.searchCar("ABC123");
    system.searchCompany("SafeCover");
    system.updateCar("ABC123", "Toyota Corolla", "John Updated");
    system.updateCompany("InsureFast", "newcontact@insurefast.com");
    system.displayCars();
    system.displayCompanies();
    system.deleteCar("XYZ789");
    system.deleteCompany("SafeCover");
    system.displayCars();
    system.displayCompanies();
    return 0;
}