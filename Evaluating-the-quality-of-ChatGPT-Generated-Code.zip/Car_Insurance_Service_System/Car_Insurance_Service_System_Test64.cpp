#include <iostream>
#include <vector>
#include <string>

struct Car {
    int id;
    std::string make;
    std::string model;
    int year;
};

struct InsuranceCompany {
    int id;
    std::string name;
    std::string address;
};

class InsuranceServiceSystem {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

    Car* findCar(int id) {
        for (size_t i = 0; i < cars.size(); ++i)
            if (cars[i].id == id)
                return &cars[i];
        return nullptr;
    }

    InsuranceCompany* findCompany(int id) {
        for (size_t i = 0; i < companies.size(); ++i)
            if (companies[i].id == id)
                return &companies[i];
        return nullptr;
    }

public:
    void addCar(int id, const std::string& make, const std::string& model, int year) {
        if(findCar(id) == nullptr)
            cars.push_back({id, make, model, year});
    }

    void deleteCar(int id) {
        for (size_t i = 0; i < cars.size(); ++i) {
            if (cars[i].id == id) {
                cars.erase(cars.begin() + i);
                break;
            }
        }
    }

    void updateCar(int id, const std::string& make, const std::string& model, int year) {
        Car* car = findCar(id);
        if (car) {
            car->make = make;
            car->model = model;
            car->year = year;
        }
    }

    Car searchCar(int id) {
        Car* car = findCar(id);
        if (car)
            return *car;
        return {-1, "", "", 0};
    }

    void displayCars() {
        for (const auto& car : cars)
            std::cout << "ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << ", Year: " << car.year << std::endl;
    }

    void addCompany(int id, const std::string& name, const std::string& address) {
        if(findCompany(id) == nullptr)
            companies.push_back({id, name, address});
    }

    void deleteCompany(int id) {
        for (size_t i = 0; i < companies.size(); ++i) {
            if (companies[i].id == id) {
                companies.erase(companies.begin() + i);
                break;
            }
        }
    }

    void updateCompany(int id, const std::string& name, const std::string& address) {
        InsuranceCompany* company = findCompany(id);
        if (company) {
            company->name = name;
            company->address = address;
        }
    }

    InsuranceCompany searchCompany(int id) {
        InsuranceCompany* company = findCompany(id);
        if (company)
            return *company;
        return {-1, "", ""};
    }

    void displayCompanies() {
        for (const auto& company : companies)
            std::cout << "ID: " << company.id << ", Name: " << company.name << ", Address: " << company.address << std::endl;
    }
};

int main() {
    InsuranceServiceSystem iss;
    iss.addCar(1, "Toyota", "Corolla", 2020);
    iss.addCar(2, "Honda", "Civic", 2018);
    iss.displayCars();
    iss.addCompany(1, "Best Insurance", "123 Elm St");
    iss.addCompany(2, "Safe Auto", "456 Oak St");
    iss.displayCompanies();
    return 0;
}