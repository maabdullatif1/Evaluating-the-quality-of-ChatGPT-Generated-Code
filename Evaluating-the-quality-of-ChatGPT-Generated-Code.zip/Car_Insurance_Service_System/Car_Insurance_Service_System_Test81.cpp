#include <iostream>
#include <vector>
#include <string>

class InsuranceCompany {
public:
    std::string name;
    std::string contact;

    InsuranceCompany(std::string name, std::string contact)
        : name(name), contact(contact) {}
};

class Car {
public:
    std::string licensePlate;
    std::string ownerName;
    std::string insuranceCompany;

    Car(std::string licensePlate, std::string ownerName, std::string insuranceCompany)
        : licensePlate(licensePlate), ownerName(ownerName), insuranceCompany(insuranceCompany) {}
};

class CarInsuranceService {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(std::string licensePlate, std::string ownerName, std::string insuranceCompany) {
        cars.push_back(Car(licensePlate, ownerName, insuranceCompany));
    }

    void deleteCar(std::string licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(std::string licensePlate, std::string ownerName, std::string insuranceCompany) {
        for (auto &car : cars) {
            if (car.licensePlate == licensePlate) {
                car.ownerName = ownerName;
                car.insuranceCompany = insuranceCompany;
                break;
            }
        }
    }

    Car* searchCar(std::string licensePlate) {
        for (auto &car : cars) {
            if (car.licensePlate == licensePlate) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "License Plate: " << car.licensePlate
                      << ", Owner: " << car.ownerName
                      << ", Insurance Company: " << car.insuranceCompany << "\n";
        }
    }

    void addCompany(std::string name, std::string contact) {
        companies.push_back(InsuranceCompany(name, contact));
    }

    void deleteCompany(std::string name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCompany(std::string name, std::string contact) {
        for (auto &company : companies) {
            if (company.name == name) {
                company.contact = contact;
                break;
            }
        }
    }

    InsuranceCompany* searchCompany(std::string name) {
        for (auto &company : companies) {
            if (company.name == name) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayCompanies() {
        for (const auto &company : companies) {
            std::cout << "Name: " << company.name << ", Contact: " << company.contact << "\n";
        }
    }
};

int main() {
    CarInsuranceService service;

    service.addCompany("Good Insure", "123-456-7890");
    service.addCompany("Secure Insure", "098-765-4321");

    service.displayCompanies();

    service.addCar("AB123CD", "John Doe", "Good Insure");
    service.addCar("EF456GH", "Jane Smith", "Secure Insure");

    service.displayCars();

    Car* car = service.searchCar("AB123CD");
    if (car) {
        std::cout << "Found car: " << car->licensePlate << ", Owner: " << car->ownerName << "\n";
    }

    InsuranceCompany* company = service.searchCompany("Good Insure");
    if (company) {
        std::cout << "Found company: " << company->name << ", Contact: " << company->contact << "\n";
    }

    service.updateCar("AB123CD", "John Doe", "Secure Insure");
    service.displayCars();

    service.deleteCar("EF456GH");
    service.displayCars();

    service.updateCompany("Good Insure", "321-654-0987");
    service.displayCompanies();

    service.deleteCompany("Secure Insure");
    service.displayCompanies();

    return 0;
}