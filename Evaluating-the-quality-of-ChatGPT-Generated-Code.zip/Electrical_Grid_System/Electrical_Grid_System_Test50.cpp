#include <iostream>
#include <string>
#include <vector>

class Entity {
public:
    virtual void display() const = 0;
    virtual std::string getID() const = 0;
    virtual void update(const std::string& name, const std::string& address, double power) = 0;
};

class Customer : public Entity {
    std::string id;
    std::string name;
    std::string address;
    double powerConsumption;

public:
    Customer(const std::string& id, const std::string& name, const std::string& address, double powerConsumption)
        : id(id), name(name), address(address), powerConsumption(powerConsumption) {}

    void display() const override {
        std::cout << "Customer ID: " << id << ", Name: " << name << ", Address: " << address
                  << ", Power Consumption: " << powerConsumption << " kWh" << std::endl;
    }

    std::string getID() const override {
        return id;
    }

    void update(const std::string& name, const std::string& address, double power) override {
        this->name = name;
        this->address = address;
        this->powerConsumption = power;
    }
};

class Producer : public Entity {
    std::string id;
    std::string name;
    std::string location;
    double powerGeneration;

public:
    Producer(const std::string& id, const std::string& name, const std::string& location, double powerGeneration)
        : id(id), name(name), location(location), powerGeneration(powerGeneration) {}

    void display() const override {
        std::cout << "Producer ID: " << id << ", Name: " << name << ", Location: " << location 
                  << ", Power Generation: " << powerGeneration << " MW" << std::endl;
    }

    std::string getID() const override {
        return id;
    }

    void update(const std::string& name, const std::string& location, double power) override {
        this->name = name;
        this->location = location;
        this->powerGeneration = power;
    }
};

class ElectricGridSystem {
    std::vector<Entity*> entities;

public:
    ~ElectricGridSystem() {
        for (Entity* entity : entities)
            delete entity;
    }

    void addCustomer(const std::string& id, const std::string& name, const std::string& address, double powerConsumption) {
        entities.push_back(new Customer(id, name, address, powerConsumption));
    }

    void addProducer(const std::string& id, const std::string& name, const std::string& location, double powerGeneration) {
        entities.push_back(new Producer(id, name, location, powerGeneration));
    }

    void deleteEntity(const std::string& id) {
        for (auto it = entities.begin(); it != entities.end(); ++it) {
            if ((*it)->getID() == id) {
                delete *it;
                entities.erase(it);
                break;
            }
        }
    }

    void updateEntity(const std::string& id, const std::string& name, const std::string& location, double power) {
        for (Entity* entity : entities) {
            if (entity->getID() == id) {
                entity->update(name, location, power);
                break;
            }
        }
    }

    void searchEntity(const std::string& id) {
        for (Entity* entity : entities) {
            if (entity->getID() == id) {
                entity->display();
                return;
            }
        }
        std::cout << "Entity with ID " << id << " not found." << std::endl;
    }

    void displayEntities() const {
        for (const Entity* entity : entities)
            entity->display();
    }
};

int main() {
    ElectricGridSystem gridSystem;
    gridSystem.addCustomer("C001", "John Doe", "123 Elm St", 350.5);
    gridSystem.addProducer("P001", "Solar Farm One", "Desert Area", 12.5);
    gridSystem.displayEntities();
    gridSystem.searchEntity("C001");
    gridSystem.updateEntity("C001", "Jane Doe", "456 Maple St", 400.0);
    gridSystem.searchEntity("C001");
    gridSystem.deleteEntity("P001");
    gridSystem.displayEntities();
    return 0;
}