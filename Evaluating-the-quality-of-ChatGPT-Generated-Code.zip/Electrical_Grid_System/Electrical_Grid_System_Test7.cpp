#include <iostream>
#include <string>
using namespace std;

class Entity {
public:
    string name;
    string id;
    string type;
    Entity* next;

    Entity(string n, string i, string t) : name(n), id(i), type(t), next(nullptr) {}
};

class ElectricalGridSystem {
private:
    Entity* head;

    Entity* findPrevious(string id) {
        Entity* current = head;
        while (current->next != nullptr && current->next->id != id) {
            current = current->next;
        }
        return current;
    }

public:
    ElectricalGridSystem() : head(nullptr) {}

    void addEntity(string name, string id, string type) {
        if (head == nullptr) {
            head = new Entity(name, id, type);
        } else {
            Entity* current = head;
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = new Entity(name, id, type);
        }
    }

    void deleteEntity(string id) {
        if (head == nullptr) return;
        if (head->id == id) {
            Entity* toDelete = head;
            head = head->next;
            delete toDelete;
        } else {
            Entity* previous = findPrevious(id);
            if (previous->next != nullptr) {
                Entity* toDelete = previous->next;
                previous->next = toDelete->next;
                delete toDelete;
            }
        }
    }

    void updateEntity(string id, string name, string type) {
        Entity* current = head;
        while (current != nullptr && current->id != id) {
            current = current->next;
        }
        if (current != nullptr) {
            current->name = name;
            current->type = type;
        }
    }

    Entity* searchEntity(string id) {
        Entity* current = head;
        while (current != nullptr && current->id != id) {
            current = current->next;
        }
        return current;
    }

    void displayEntities() {
        Entity* current = head;
        while (current != nullptr) {
            cout << "Name: " << current->name << ", ID: " << current->id << ", Type: " << current->type << endl;
            current = current->next;
        }
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addEntity("John Doe", "C001", "Customer");
    grid.addEntity("Jane Smith", "P001", "Producer");
    grid.displayEntities();

    grid.updateEntity("C001", "John Doe Updated", "Customer");
    grid.displayEntities();

    grid.deleteEntity("P001");
    grid.displayEntities();

    Entity* found = grid.searchEntity("C001");
    if (found != nullptr) {
        cout << "Found Entity: " << found->name << endl;
    } else {
        cout << "Entity not found." << endl;
    }

    return 0;
}