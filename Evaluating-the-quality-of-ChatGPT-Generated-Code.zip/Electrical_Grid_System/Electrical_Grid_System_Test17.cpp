#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string address;
    float consumption;
};

struct Producer {
    int id;
    std::string name;
    std::string location;
    float production;
};

class ElectricalGridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;
    
    template<typename T>
    void displayEntity(const std::vector<T>& entities) const {
        for (const auto& entity : entities) {
            std::cout << "ID: " << entity.id << ", Name: " << entity.name << std::endl;
        }
    }
    
    template<typename T>
    typename std::vector<T>::iterator findEntityById(std::vector<T>& entities, int id) {
        return std::find_if(entities.begin(), entities.end(), [id](const T& entity) { return entity.id == id; });
    }

public:
    void addCustomer(int id, const std::string& name, const std::string& address, float consumption) {
        customers.push_back({ id, name, address, consumption });
    }
    
    void deleteCustomer(int id) {
        auto it = findEntityById(customers, id);
        if (it != customers.end()) {
            customers.erase(it);
        }
    }
    
    void updateCustomer(int id, const std::string& name, const std::string& address, float consumption) {
        auto it = findEntityById(customers, id);
        if (it != customers.end()) {
            it->name = name;
            it->address = address;
            it->consumption = consumption;
        }
    }
    
    void searchCustomer(int id) const {
        auto it = std::find_if(customers.begin(), customers.end(), [id](const Customer& c) { return c.id == id; });
        if (it != customers.end()) {
            std::cout << "Customer found: " << it->name << ", " << it->address << ", Consumption: " << it->consumption << std::endl;
        } else {
            std::cout << "Customer not found" << std::endl;
        }
    }
    
    void displayCustomers() const {
        displayEntity(customers);
    }
    
    void addProducer(int id, const std::string& name, const std::string& location, float production) {
        producers.push_back({ id, name, location, production });
    }
    
    void deleteProducer(int id) {
        auto it = findEntityById(producers, id);
        if (it != producers.end()) {
            producers.erase(it);
        }
    }
    
    void updateProducer(int id, const std::string& name, const std::string& location, float production) {
        auto it = findEntityById(producers, id);
        if (it != producers.end()) {
            it->name = name;
            it->location = location;
            it->production = production;
        }
    }
    
    void searchProducer(int id) const {
        auto it = std::find_if(producers.begin(), producers.end(), [id](const Producer& p) { return p.id == id; });
        if (it != producers.end()) {
            std::cout << "Producer found: " << it->name << ", " << it->location << ", Production: " << it->production << std::endl;
        } else {
            std::cout << "Producer not found" << std::endl;
        }
    }
    
    void displayProducers() const {
        displayEntity(producers);
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addCustomer(1, "Alice", "123 Maple St", 150.0);
    grid.addCustomer(2, "Bob", "456 Elm St", 200.0);
    grid.displayCustomers();
    grid.searchCustomer(1);
    grid.updateCustomer(2, "Bob Smith", "456 Elm St, Apt 5", 175.0);
    grid.displayCustomers();
    grid.deleteCustomer(1);
    grid.displayCustomers();
    grid.addProducer(1, "Solar Co", "Desert", 5000.0);
    grid.addProducer(2, "Wind Corp", "Mountain", 3000.0);
    grid.displayProducers();
    grid.searchProducer(1);
    grid.updateProducer(2, "Wind Industries", "Mountain", 3200.0);
    grid.displayProducers();
    grid.deleteProducer(1);
    grid.displayProducers();
    return 0;
}