#include <iostream>
#include <vector>
#include <string>

class Entity {
public:
    std::string id;
    std::string name;
    std::string address;
    
    Entity(const std::string& id, const std::string& name, const std::string& address)
        : id(id), name(name), address(address) {}
};

class Customer : public Entity {
public:
    double consumption;
    
    Customer(const std::string& id, const std::string& name, const std::string& address, double consumption)
        : Entity(id, name, address), consumption(consumption) {}
};

class Producer : public Entity {
public:
    double production;
    
    Producer(const std::string& id, const std::string& name, const std::string& address, double production)
        : Entity(id, name, address), production(production) {}
};

class ElectricalGridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;

public:
    void addCustomer(const std::string& id, const std::string& name, const std::string& address, double consumption) {
        customers.push_back(Customer(id, name, address, consumption));
    }
    
    void addProducer(const std::string& id, const std::string& name, const std::string& address, double production) {
        producers.push_back(Producer(id, name, address, production));
    }

    void deleteCustomer(const std::string& id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void deleteProducer(const std::string& id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->id == id) {
                producers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(const std::string& id, const std::string& name, const std::string& address, double consumption) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                customer.consumption = consumption;
                break;
            }
        }
    }

    void updateProducer(const std::string& id, const std::string& name, const std::string& address, double production) {
        for (auto& producer : producers) {
            if (producer.id == id) {
                producer.name = name;
                producer.address = address;
                producer.production = production;
                break;
            }
        }
    }

    Customer* searchCustomer(const std::string& id) {
        for (auto& customer : customers) {
            if (customer.id == id) return &customer;
        }
        return nullptr;
    }

    Producer* searchProducer(const std::string& id) {
        for (auto& producer : producers) {
            if (producer.id == id) return &producer;
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address
                      << ", Consumption: " << customer.consumption << std::endl;
        }
    }

    void displayProducers() {
        for (const auto& producer : producers) {
            std::cout << "ID: " << producer.id << ", Name: " << producer.name << ", Address: " << producer.address
                      << ", Production: " << producer.production << std::endl;
        }
    }
};

int main() {
    ElectricalGridSystem system;
    system.addCustomer("C001", "John Doe", "123 Elm St", 350.0);
    system.addProducer("P001", "Green Energy Inc.", "456 Oak St", 1000.0);
    system.displayCustomers();
    system.displayProducers();
    return 0;
}