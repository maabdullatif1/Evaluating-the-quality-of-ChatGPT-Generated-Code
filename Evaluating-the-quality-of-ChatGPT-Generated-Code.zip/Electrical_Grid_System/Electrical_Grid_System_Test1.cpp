#include <iostream>
#include <vector>
#include <string>

class Participant {
public:
    virtual void display() const = 0;
    virtual std::string getType() const = 0;
    virtual ~Participant() {}
    
    std::string id;
    std::string name;
    std::string address;
};

class Customer : public Participant {
public:
    void display() const override {
        std::cout << "Customer ID: " << id << ", Name: " << name << ", Address: " << address << std::endl;
    }
    std::string getType() const override {
        return "Customer";
    }
};

class ElectricityProducer : public Participant {
public:
    void display() const override {
        std::cout << "Producer ID: " << id << ", Name: " << name << ", Address: " << address << std::endl;
    }
    std::string getType() const override {
        return "Producer";
    }
};

class GridSystem {
public:
    void addParticipant(Participant* participant) {
        participants.push_back(participant);
    }
    
    void deleteParticipant(const std::string& id) {
        for (auto it = participants.begin(); it != participants.end(); ++it) {
            if ((*it)->id == id) {
                delete *it;
                participants.erase(it);
                return;
            }
        }
    }
    
    void updateParticipant(const std::string& id, const std::string& name, const std::string& address) {
        for (auto& participant : participants) {
            if (participant->id == id) {
                participant->name = name;
                participant->address = address;
                return;
            }
        }
    }
    
    Participant* searchParticipant(const std::string& id) {
        for (auto& participant : participants) {
            if (participant->id == id) {
                return participant;
            }
        }
        return nullptr;
    }
    
    void displayParticipants() const {
        for (const auto& participant : participants) {
            participant->display();
        }
    }
    
    ~GridSystem() {
        for (auto participant : participants) {
            delete participant;
        }
    }

private:
    std::vector<Participant*> participants;
};

int main() {
    GridSystem gridSystem;
    
    Customer* cust1 = new Customer();
    cust1->id = "C001";
    cust1->name = "John Doe";
    cust1->address = "123 Elm St";
    
    ElectricityProducer* prod1 = new ElectricityProducer();
    prod1->id = "P001";
    prod1->name = "Energy Corp";
    prod1->address = "456 Oak St";
    
    gridSystem.addParticipant(cust1);
    gridSystem.addParticipant(prod1);
    
    gridSystem.displayParticipants();
    
    gridSystem.updateParticipant("C001", "John Smith", "789 Pine St");
    gridSystem.displayParticipants();
    
    Participant* foundParticipant = gridSystem.searchParticipant("P001");
    if (foundParticipant) {
        foundParticipant->display();
    } else {
        std::cout << "Participant not found" << std::endl;
    }
    
    gridSystem.deleteParticipant("C001");
    gridSystem.displayParticipants();
    
    return 0;
}