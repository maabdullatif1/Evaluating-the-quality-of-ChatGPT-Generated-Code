#include <iostream>
#include <vector>
#include <string>

class Entity {
public:
    int id;
    std::string name;
    
    Entity(int id, const std::string& name) : id(id), name(name) {}
    virtual void display() const = 0;
};

class Customer : public Entity {
public:
    double consumption;
    
    Customer(int id, const std::string& name, double consumption)
        : Entity(id, name), consumption(consumption) {}
    
    void display() const override {
        std::cout << "Customer ID: " << id << ", Name: " << name << ", Consumption: " << consumption << " kWh\n";
    }
};

class Producer : public Entity {
public:
    double production;
    
    Producer(int id, const std::string& name, double production)
        : Entity(id, name), production(production) {}
    
    void display() const override {
        std::cout << "Producer ID: " << id << ", Name: " << name << ", Production: " << production << " kWh\n";
    }
};

class ElectricalGridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;
    
public:
    void addCustomer(int id, const std::string& name, double consumption) {
        customers.emplace_back(id, name, consumption);
    }

    void addProducer(int id, const std::string& name, double production) {
        producers.emplace_back(id, name, production);
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void deleteProducer(int id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->id == id) {
                producers.erase(it);
                return;
            }
        }
    }

    void updateCustomer(int id, double newConsumption) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.consumption = newConsumption;
                return;
            }
        }
    }

    void updateProducer(int id, double newProduction) {
        for (auto& producer : producers) {
            if (producer.id == id) {
                producer.production = newProduction;
                return;
            }
        }
    }

    void searchCustomer(int id) const {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                customer.display();
                return;
            }
        }
        std::cout << "Customer not found\n";
    }

    void searchProducer(int id) const {
        for (const auto& producer : producers) {
            if (producer.id == id) {
                producer.display();
                return;
            }
        }
        std::cout << "Producer not found\n";
    }

    void displayAllCustomers() const {
        for (const auto& customer : customers) {
            customer.display();
        }
    }

    void displayAllProducers() const {
        for (const auto& producer : producers) {
            producer.display();
        }
    }
};

int main() {
    ElectricalGridSystem system;
    system.addCustomer(1, "Alice", 300.5);
    system.addProducer(1, "Solar Inc.", 5000.0);
    system.displayAllCustomers();
    system.displayAllProducers();
    return 0;
}