#include <iostream>
#include <vector>
#include <string>

class Participant {
protected:
    int id;
    std::string name;
    std::string type;
public:
    Participant(int id, const std::string& name, const std::string& type)
        : id(id), name(name), type(type) {}
    int getId() const { return id; }
    const std::string& getName() const { return name; }
    const std::string& getType() const { return type; }
    void setName(const std::string& newName) { name = newName; }
};

class ElectricalGridSystem {
    std::vector<Participant> participants;
    int nextId = 1;

    int findIndexById(int id) {
        for (int i = 0; i < participants.size(); ++i) {
            if (participants[i].getId() == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addParticipant(const std::string& name, const std::string& type) {
        participants.push_back(Participant(nextId++, name, type));
    }

    void deleteParticipant(int id) {
        int index = findIndexById(id);
        if (index != -1) {
            participants.erase(participants.begin() + index);
        }
    }

    void updateParticipant(int id, const std::string& newName) {
        int index = findIndexById(id);
        if (index != -1) {
            participants[index].setName(newName);
        }
    }

    Participant* searchParticipant(int id) {
        int index = findIndexById(id);
        if (index != -1) {
            return &participants[index];
        }
        return nullptr;
    }

    void displayParticipants() {
        for (const auto& participant : participants) {
            std::cout << "ID: " << participant.getId()
                      << ", Name: " << participant.getName()
                      << ", Type: " << participant.getType() << "\n";
        }
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addParticipant("John Doe", "Customer");
    grid.addParticipant("Solar Inc.", "Producer");
    grid.displayParticipants();
    grid.updateParticipant(1, "Jane Doe");
    grid.displayParticipants();
    Participant* p = grid.searchParticipant(2);
    if (p) std::cout << "Found: " << p->getName() << "\n";
    grid.deleteParticipant(1);
    grid.displayParticipants();
    return 0;
}