#include <iostream>
#include <string>
#include <vector>

class Participant {
protected:
    int id;
    std::string name;
    std::string type;

public:
    Participant(int id, const std::string& name, const std::string& type)
        : id(id), name(name), type(type) {}

    int getID() const { return id; }
    std::string getName() const { return name; }
    std::string getType() const { return type; }

    void updateName(const std::string& newName) { name = newName; }

    void display() const {
        std::cout << "ID: " << id << ", Name: " << name << ", Type: " << type << std::endl;
    }
};

class Customer : public Participant {
public:
    Customer(int id, const std::string& name)
        : Participant(id, name, "Customer") {}
};

class Producer : public Participant {
public:
    Producer(int id, const std::string& name)
        : Participant(id, name, "Producer") {}
};

class GridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;

public:
    void addCustomer(int id, const std::string& name) {
        customers.push_back(Customer(id, name));
    }

    void addProducer(int id, const std::string& name) {
        producers.push_back(Producer(id, name));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getID() == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void deleteProducer(int id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getID() == id) {
                producers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& newName) {
        for (auto& customer : customers) {
            if (customer.getID() == id) {
                customer.updateName(newName);
                break;
            }
        }
    }

    void updateProducer(int id, const std::string& newName) {
        for (auto& producer : producers) {
            if (producer.getID() == id) {
                producer.updateName(newName);
                break;
            }
        }
    }

    void searchCustomer(int id) const {
        for (const auto& customer : customers) {
            if (customer.getID() == id) {
                customer.display();
                return;
            }
        }
        std::cout << "Customer with ID " << id << " not found." << std::endl;
    }

    void searchProducer(int id) const {
        for (const auto& producer : producers) {
            if (producer.getID() == id) {
                producer.display();
                return;
            }
        }
        std::cout << "Producer with ID " << id << " not found." << std::endl;
    }

    void displayAll() const {
        std::cout << "Customers:" << std::endl;
        for (const auto& customer : customers) {
            customer.display();
        }

        std::cout << "Producers:" << std::endl;
        for (const auto& producer : producers) {
            producer.display();
        }
    }
};

int main() {
    GridSystem grid;

    grid.addCustomer(1, "Customer A");
    grid.addCustomer(2, "Customer B");
    grid.addProducer(1, "Producer A");

    grid.displayAll();

    grid.updateCustomer(1, "Customer AA");
    grid.updateProducer(1, "Producer AA");

    grid.searchCustomer(1);
    grid.searchProducer(1);

    grid.deleteCustomer(2);
    grid.deleteProducer(1);

    grid.displayAll();

    return 0;
}