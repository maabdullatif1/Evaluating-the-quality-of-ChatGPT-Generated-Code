#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Customer {
    int id;
    string name;
};

struct Producer {
    int id;
    string name;
};

class ElectricalGrid {
    vector<Customer> customers;
    vector<Producer> producers;
    int customerId;
    int producerId;

public:
    ElectricalGrid() : customerId(0), producerId(0) {}

    void addCustomer(const string& name) {
        customers.push_back({++customerId, name});
    }

    void addProducer(const string& name) {
        producers.push_back({++producerId, name});
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void deleteProducer(int id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->id == id) {
                producers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const string& newName) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = newName;
                break;
            }
        }
    }

    void updateProducer(int id, const string& newName) {
        for (auto& producer : producers) {
            if (producer.id == id) {
                producer.name = newName;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Producer* searchProducer(int id) {
        for (auto& producer : producers) {
            if (producer.id == id) {
                return &producer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << endl;
        }
    }

    void displayProducers() {
        for (const auto& producer : producers) {
            cout << "Producer ID: " << producer.id << ", Name: " << producer.name << endl;
        }
    }
};

int main() {
    ElectricalGrid grid;
    grid.addCustomer("Customer 1");
    grid.addCustomer("Customer 2");
    grid.addProducer("Producer 1");
    grid.addProducer("Producer 2");
    grid.displayCustomers();
    grid.displayProducers();
    grid.updateCustomer(1, "Updated Customer 1");
    grid.updateProducer(2, "Updated Producer 2");
    auto customer = grid.searchCustomer(1);
    if (customer) cout << "Searched Customer: ID-" << customer->id << ", Name-" << customer->name << endl;
    auto producer = grid.searchProducer(2);
    if (producer) cout << "Searched Producer: ID-" << producer->id << ", Name-" << producer->name << endl;
    grid.deleteCustomer(2);
    grid.deleteProducer(1);
    grid.displayCustomers();
    grid.displayProducers();
    return 0;
}