#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Entity {
public:
    string name;
    string id;
    double power;

    Entity(string name, string id, double power) : name(name), id(id), power(power) {}

    void display() const {
        cout << "Name: " << name << ", ID: " << id << ", Power: " << power << " kW" << endl;
    }
};

class GridSystem {
    vector<Entity> customers;
    vector<Entity> producers;

    vector<Entity>* getEntityList(const string& type) {
        return type == "customer" ? &customers : type == "producer" ? &producers : nullptr;
    }

public:
    void addEntity(const string& type, const string& name, const string& id, double power) {
        Entity newEntity(name, id, power);
        vector<Entity>* list = getEntityList(type);
        if (list) {
            list->push_back(newEntity);
        }
    }

    void deleteEntity(const string& type, const string& id) {
        vector<Entity>* list = getEntityList(type);
        if (list) {
            list->erase(remove_if(list->begin(), list->end(), [&](Entity& e) { return e.id == id; }), list->end());
        }
    }

    void updateEntity(const string& type, const string& id, const string& newName, double newPower) {
        vector<Entity>* list = getEntityList(type);
        if (list) {
            for (auto& e : *list) {
                if (e.id == id) {
                    e.name = newName;
                    e.power = newPower;
                }
            }
        }
    }

    Entity* searchEntity(const string& type, const string& id) {
        vector<Entity>* list = getEntityList(type);
        if (list) {
            for (auto& e : *list) {
                if (e.id == id) {
                    return &e;
                }
            }
        }
        return nullptr;
    }

    void displayEntities(const string& type) {
        vector<Entity>* list = getEntityList(type);
        if (list) {
            for (const auto& e : *list) {
                e.display();
            }
        }
    }
};

int main() {
    GridSystem grid;

    grid.addEntity("customer", "John Doe", "C001", 5.0);
    grid.addEntity("producer", "Solar Inc.", "P001", 100.0);

    grid.displayEntities("customer");
    grid.displayEntities("producer");

    Entity* customer = grid.searchEntity("customer", "C001");
    if (customer) {
        customer->display();
    }

    grid.updateEntity("customer", "C001", "Jane Doe", 10.0);

    grid.displayEntities("customer");

    grid.deleteEntity("customer", "C001");

    grid.displayEntities("customer");

    return 0;
}