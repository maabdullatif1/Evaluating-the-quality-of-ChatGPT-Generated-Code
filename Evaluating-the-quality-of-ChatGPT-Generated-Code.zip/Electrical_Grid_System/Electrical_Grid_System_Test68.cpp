#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    std::string name;
    std::string address;
    int usage;
    
    Customer(std::string n, std::string a, int u) : name(n), address(a), usage(u) {}
};

class Producer {
public:
    std::string producerName;
    std::string producerType;
    int output;
    
    Producer(std::string n, std::string t, int o) : producerName(n), producerType(t), output(o) {}
};

class ElectricalGridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;

public:
    void addCustomer(std::string n, std::string a, int u) {
        customers.push_back(Customer(n, a, u));
    }

    void deleteCustomer(std::string n) {
        for(auto it = customers.begin(); it != customers.end(); ++it) {
            if(it->name == n) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(std::string oldName, std::string newName, std::string newAddress, int newUsage) {
        for(auto& c : customers) {
            if(c.name == oldName) {
                c.name = newName;
                c.address = newAddress;
                c.usage = newUsage;
                break;
            }
        }
    }

    void searchCustomer(std::string n) {
        for(auto& c : customers) {
            if(c.name == n) {
                std::cout << c.name << " " << c.address << " " << c.usage << std::endl;
                return;
            }
        }
        std::cout << "Customer not found" << std::endl;
    }

    void displayCustomers() {
        for(auto& c : customers) {
            std::cout << c.name << " " << c.address << " " << c.usage << std::endl;
        }
    }

    void addProducer(std::string n, std::string t, int o) {
        producers.push_back(Producer(n, t, o));
    }

    void deleteProducer(std::string n) {
        for(auto it = producers.begin(); it != producers.end(); ++it) {
            if(it->producerName == n) {
                producers.erase(it);
                break;
            }
        }
    }

    void updateProducer(std::string oldName, std::string newName, std::string newType, int newOutput) {
        for(auto& p : producers) {
            if(p.producerName == oldName) {
                p.producerName = newName;
                p.producerType = newType;
                p.output = newOutput;
                break;
            }
        }
    }

    void searchProducer(std::string n) {
        for(auto& p : producers) {
            if(p.producerName == n) {
                std::cout << p.producerName << " " << p.producerType << " " << p.output << std::endl;
                return;
            }
        }
        std::cout << "Producer not found" << std::endl;
    }

    void displayProducers() {
        for(auto& p : producers) {
            std::cout << p.producerName << " " << p.producerType << " " << p.output << std::endl;
        }
    }
};

int main() {
    ElectricalGridSystem grid;

    grid.addCustomer("Alice", "123 Street", 100);
    grid.addCustomer("Bob", "456 Avenue", 200);
    grid.displayCustomers();
    
    grid.updateCustomer("Alice", "Alice Smith", "123 Street", 150);
    grid.searchCustomer("Alice Smith");
    
    grid.addProducer("Solar", "Renewable", 500);
    grid.addProducer("Coal Plant", "Non-renewable", 1000);
    grid.displayProducers();
    
    grid.deleteCustomer("Bob");
    grid.displayCustomers();
    
    grid.deleteProducer("Solar");
    grid.displayProducers();

    return 0;
}