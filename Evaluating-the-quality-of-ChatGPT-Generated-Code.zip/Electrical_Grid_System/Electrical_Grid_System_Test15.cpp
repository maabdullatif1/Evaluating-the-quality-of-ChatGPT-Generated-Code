#include <iostream>
#include <string>
#include <vector>

class Entity {
public:
    virtual void display() const = 0;
    virtual std::string getId() const = 0;
    virtual void updateInfo() = 0;
};

class Customer : public Entity {
    std::string id, name, address;
    double electricityConsumed;
public:
    Customer(std::string id, std::string name, std::string address, double electricityConsumed)
        : id(id), name(name), address(address), electricityConsumed(electricityConsumed) {}
    
    void display() const override {
        std::cout << "Customer ID: " << id << ", Name: " << name << ", Address: " << address 
                  << ", Electricity Consumed: " << electricityConsumed << " kWh" << std::endl;
    }
    
    std::string getId() const override {
        return id;
    }

    void updateInfo() override {
        std::cout << "Enter new name: ";
        std::cin >> name;
        std::cout << "Enter new address: ";
        std::cin >> address;
        std::cout << "Enter new electricity consumed: ";
        std::cin >> electricityConsumed;
    }
};

class Producer : public Entity {
    std::string id, name, type;
    double electricityProduced;
public:
    Producer(std::string id, std::string name, std::string type, double electricityProduced)
        : id(id), name(name), type(type), electricityProduced(electricityProduced) {}
    
    void display() const override {
        std::cout << "Producer ID: " << id << ", Name: " << name << ", Type: " << type 
                  << ", Electricity Produced: " << electricityProduced << " kWh" << std::endl;
    }
    
    std::string getId() const override {
        return id;
    }

    void updateInfo() override {
        std::cout << "Enter new name: ";
        std::cin >> name;
        std::cout << "Enter new type: ";
        std::cin >> type;
        std::cout << "Enter new electricity produced: ";
        std::cin >> electricityProduced;
    }
};

class GridSystem {
    std::vector<Entity*> entities;
public:
    void addEntity(Entity* entity) {
        entities.push_back(entity);
    }

    void deleteEntity(const std::string& id) {
        for (auto it = entities.begin(); it != entities.end(); ++it) {
            if ((*it)->getId() == id) {
                delete *it;
                entities.erase(it);
                break;
            }
        }
    }

    Entity* searchEntity(const std::string& id) {
        for (auto e : entities) {
            if (e->getId() == id) {
                return e;
            }
        }
        return nullptr;
    }

    void updateEntity(const std::string& id) {
        Entity* entity = searchEntity(id);
        if (entity) {
            entity->updateInfo();
        } else {
            std::cout << "Entity not found." << std::endl;
        }
    }

    void displayEntities() const {
        for (const auto e : entities) {
            e->display();
        }
    }
    
    ~GridSystem() {
        for (auto e : entities) {
            delete e;
        }
    }
};

int main() {
    GridSystem grid;
    grid.addEntity(new Customer("C001", "Alice", "123 Elm St", 350.5));
    grid.addEntity(new Producer("P001", "SolarFarm", "Solar", 500.0));

    grid.displayEntities();

    grid.updateEntity("C001");
    grid.displayEntities();

    grid.deleteEntity("P001");
    grid.displayEntities();

    return 0;
}