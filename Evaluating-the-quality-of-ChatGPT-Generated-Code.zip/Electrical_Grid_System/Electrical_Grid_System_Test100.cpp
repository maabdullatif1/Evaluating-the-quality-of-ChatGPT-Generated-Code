#include <iostream>
#include <string>
using namespace std;

struct Entry {
    string name;
    string type;
    double power;
    Entry* next;
};

class ElectricalGridSystem {
private:
    Entry* head;

    Entry* findEntry(const string& name) {
        Entry* current = head;
        while (current != nullptr) {
            if (current->name == name) return current;
            current = current->next;
        }
        return nullptr;
    }

public:
    ElectricalGridSystem() : head(nullptr) {}

    void addEntry(const string& name, const string& type, double power) {
        if (findEntry(name) != nullptr) return;
        Entry* newEntry = new Entry{name, type, power, head};
        head = newEntry;
    }

    void deleteEntry(const string& name) {
        Entry* current = head;
        Entry* previous = nullptr;
        while (current != nullptr) {
            if (current->name == name) {
                if (previous == nullptr) {
                    head = current->next;
                } else {
                    previous->next = current->next;
                }
                delete current;
                return;
            }
            previous = current;
            current = current->next;
        }
    }

    void updateEntry(const string& name, const string& type, double power) {
        Entry* entry = findEntry(name);
        if (entry != nullptr) {
            entry->type = type;
            entry->power = power;
        }
    }

    void searchEntry(const string& name) {
        Entry* entry = findEntry(name);
        if (entry != nullptr) {
            cout << entry->name << ", " << entry->type << ", " << entry->power << endl;
        } else {
            cout << "Entry not found" << endl;
        }
    }

    void displayAll() {
        Entry* current = head;
        while (current != nullptr) {
            cout << current->name << ", " << current->type << ", " << current->power << endl;
            current = current->next;
        }
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addEntry("Alice", "Customer", 120.5);
    grid.addEntry("Bob Power Co", "Producer", 5000.0);
    grid.displayAll();
    grid.updateEntry("Alice", "Customer", 130.0);
    grid.searchEntry("Alice");
    grid.deleteEntry("Bob Power Co");
    grid.displayAll();
    return 0;
}