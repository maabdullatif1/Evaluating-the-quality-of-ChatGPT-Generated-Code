#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Entity {
public:
    string id;
    string name;
    string type;
    Entity(string i, string n, string t) : id(i), name(n), type(t) {}
};

class GridSystem {
private:
    vector<Entity> entities;

    int findEntityIndex(const string& id) {
        for (size_t i = 0; i < entities.size(); ++i) {
            if (entities[i].id == id) return i;
        }
        return -1;
    }

public:
    void addEntity(const string& id, const string& name, const string& type) {
        if (findEntityIndex(id) == -1) {
            entities.push_back(Entity(id, name, type));
        } else {
            cout << "Entity with ID " << id << " already exists.\n";
        }
    }

    void deleteEntity(const string& id) {
        int index = findEntityIndex(id);
        if (index != -1) {
            entities.erase(entities.begin() + index);
        } else {
            cout << "Entity with ID " << id << " not found.\n";
        }
    }

    void updateEntity(const string& id, const string& name, const string& type) {
        int index = findEntityIndex(id);
        if (index != -1) {
            entities[index].name = name;
            entities[index].type = type;
        } else {
            cout << "Entity with ID " << id << " not found.\n";
        }
    }

    void searchEntity(const string& id) {
        int index = findEntityIndex(id);
        if (index != -1) {
            cout << "ID: " << entities[index].id << ", Name: " << entities[index].name << ", Type: " << entities[index].type << endl;
        } else {
            cout << "Entity with ID " << id << " not found.\n";
        }
    }

    void displayEntities() {
        if (entities.empty()) {
            cout << "No entities to display.\n";
        }
        for (const auto& entity : entities) {
            cout << "ID: " << entity.id << ", Name: " << entity.name << ", Type: " << entity.type << endl;
        }
    }
};

int main() {
    GridSystem grid;
    int choice;
    string id, name, type;

    do {
        cout << "1. Add Entity\n2. Delete Entity\n3. Update Entity\n4. Search Entity\n5. Display All Entities\n6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
        case 1:
            cout << "Enter ID: ";
            cin >> id;
            cout << "Enter Name: ";
            cin >> name;
            cout << "Enter Type (Customer/Producer): ";
            cin >> type;
            grid.addEntity(id, name, type);
            break;
        case 2:
            cout << "Enter ID to delete: ";
            cin >> id;
            grid.deleteEntity(id);
            break;
        case 3:
            cout << "Enter ID to update: ";
            cin >> id;
            cout << "Enter new Name: ";
            cin >> name;
            cout << "Enter new Type (Customer/Producer): ";
            cin >> type;
            grid.updateEntity(id, name, type);
            break;
        case 4:
            cout << "Enter ID to search: ";
            cin >> id;
            grid.searchEntity(id);
            break;
        case 5:
            grid.displayEntities();
            break;
        }
    } while (choice != 6);

    return 0;
}