#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Participant {
protected:
    string id;
    string name;
public:
    Participant(string id, string name) : id(id), name(name) {}
    string getId() { return id; }
    string getName() { return name; }
    virtual void display() = 0;
};

class Customer : public Participant {
    double consumption;
public:
    Customer(string id, string name, double consumption) : Participant(id, name), consumption(consumption) {}
    void updateConsumption(double newConsumption) { consumption = newConsumption; }
    double getConsumption() { return consumption; }
    void display() {
        cout << "Customer ID: " << id << "; Name: " << name << "; Consumption: " << consumption << " kWh" << endl;
    }
};

class Producer : public Participant {
    double generation;
public:
    Producer(string id, string name, double generation) : Participant(id, name), generation(generation) {}
    void updateGeneration(double newGeneration) { generation = newGeneration; }
    double getGeneration() { return generation; }
    void display() {
        cout << "Producer ID: " << id << "; Name: " << name << "; Generation: " << generation << " kWh" << endl;
    }
};

class GridSystem {
    vector<Customer> customers;
    vector<Producer> producers;
public:
    void addCustomer(string id, string name, double consumption) {
        customers.push_back(Customer(id, name, consumption));
    }

    void addProducer(string id, string name, double generation) {
        producers.push_back(Producer(id, name, generation));
    }

    void deleteCustomer(string id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void deleteProducer(string id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getId() == id) {
                producers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(string id, double newConsumption) {
        for (auto &customer : customers) {
            if (customer.getId() == id) {
                customer.updateConsumption(newConsumption);
            }
        }
    }

    void updateProducer(string id, double newGeneration) {
        for (auto &producer : producers) {
            if (producer.getId() == id) {
                producer.updateGeneration(newGeneration);
            }
        }
    }

    void searchCustomer(string id) {
        for (auto &customer : customers) {
            if (customer.getId() == id) {
                customer.display();
            }
        }
    }

    void searchProducer(string id) {
        for (auto &producer : producers) {
            if (producer.getId() == id) {
                producer.display();
            }
        }
    }

    void displayCustomers() {
        for (auto &customer : customers) {
            customer.display();
        }
    }

    void displayProducers() {
        for (auto &producer : producers) {
            producer.display();
        }
    }
};

int main() {
    GridSystem grid;

    grid.addCustomer("C1", "Alice", 1500);
    grid.addCustomer("C2", "Bob", 2000);
    grid.addProducer("P1", "Solar Farm", 5000);
    grid.addProducer("P2", "Wind Turbine", 3000);

    grid.displayCustomers();
    grid.displayProducers();

    grid.updateCustomer("C1", 1600);
    grid.updateProducer("P2", 3500);

    grid.searchCustomer("C1");
    grid.searchProducer("P1");

    grid.deleteCustomer("C2");
    grid.deleteProducer("P1");

    grid.displayCustomers();
    grid.displayProducers();

    return 0;
}