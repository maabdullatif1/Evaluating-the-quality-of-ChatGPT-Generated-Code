#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Participant {
public:
    string id;
    string name;
    double power;

    Participant(string id, string name, double power) : id(id), name(name), power(power) {}
};

class GridSystem {
private:
    vector<Participant> customers;
    vector<Participant> producers;

    void displayParticipants(const vector<Participant>& participants) {
        for (const auto& p : participants) {
            cout << "ID: " << p.id << ", Name: " << p.name << ", Power: " << p.power << " kW" << endl;
        }
    }

    int findParticipantIndex(const vector<Participant>& participants, const string& id) {
        for (int i = 0; i < participants.size(); ++i) {
            if (participants[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addCustomer(const string& id, const string& name, double power) {
        customers.emplace_back(id, name, power);
    }

    void deleteCustomer(const string& id) {
        int index = findParticipantIndex(customers, id);
        if (index != -1) {
            customers.erase(customers.begin() + index);
        }
    }

    void updateCustomer(const string& id, const string& name, double power) {
        int index = findParticipantIndex(customers, id);
        if (index != -1) {
            customers[index] = Participant(id, name, power);
        }
    }

    void searchCustomer(const string& id) {
        int index = findParticipantIndex(customers, id);
        if (index != -1) {
            cout << "Customer found: ID: " << customers[index].id << ", Name: " << customers[index].name << ", Power: " << customers[index].power << " kW" << endl;
        } else {
            cout << "Customer not found." << endl;
        }
    }

    void displayCustomers() {
        cout << "Customers:" << endl;
        displayParticipants(customers);
    }

    void addProducer(const string& id, const string& name, double power) {
        producers.emplace_back(id, name, power);
    }

    void deleteProducer(const string& id) {
        int index = findParticipantIndex(producers, id);
        if (index != -1) {
            producers.erase(producers.begin() + index);
        }
    }

    void updateProducer(const string& id, const string& name, double power) {
        int index = findParticipantIndex(producers, id);
        if (index != -1) {
            producers[index] = Participant(id, name, power);
        }
    }

    void searchProducer(const string& id) {
        int index = findParticipantIndex(producers, id);
        if (index != -1) {
            cout << "Producer found: ID: " << producers[index].id << ", Name: " << producers[index].name << ", Power: " << producers[index].power << " kW" << endl;
        } else {
            cout << "Producer not found." << endl;
        }
    }

    void displayProducers() {
        cout << "Producers:" << endl;
        displayParticipants(producers);
    }
};

int main() {
    GridSystem grid;

    grid.addCustomer("C001", "Customer One", 300.0);
    grid.addCustomer("C002", "Customer Two", 450.5);
    grid.updateCustomer("C001", "Customer 1", 320.0);
    grid.displayCustomers();
    grid.searchCustomer("C001");
    grid.deleteCustomer("C002");
    grid.displayCustomers();

    grid.addProducer("P001", "Producer One", 1500.0);
    grid.addProducer("P002", "Producer Two", 2500.0);
    grid.updateProducer("P001", "Producer 1", 1600.0);
    grid.displayProducers();
    grid.searchProducer("P002");
    grid.deleteProducer("P002");
    grid.displayProducers();

    return 0;
}