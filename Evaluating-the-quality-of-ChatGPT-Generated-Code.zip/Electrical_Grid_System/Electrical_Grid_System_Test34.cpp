#include <iostream>
#include <string>

class User {
public:
    std::string id;
    std::string name;
    std::string address;
    virtual void display() = 0;
};

class Customer : public User {
public:
    float consumption;
    Customer(std::string i, std::string n, std::string a, float c) {
        id = i;
        name = n;
        address = a;
        consumption = c;
    }
    void display() override {
        std::cout << "Customer ID: " << id << ", Name: " << name 
                  << ", Address: " << address << ", Consumption: " 
                  << consumption << "\n";
    }
};

class Producer : public User {
public:
    float production;
    Producer(std::string i, std::string n, std::string a, float p) {
        id = i;
        name = n;
        address = a;
        production = p;
    }
    void display() override {
        std::cout << "Producer ID: " << id << ", Name: " << name 
                  << ", Address: " << address << ", Production: " 
                  << production << "\n";
    }
};

class GridSystem {
    User* users[100];
    int total_users;
public:
    GridSystem() : total_users(0) {}
    void add(User* u) {
        if (total_users < 100) {
            users[total_users++] = u;
        }
    }
    void remove(std::string id) {
        for (int i = 0; i < total_users; ++i) {
            if (users[i]->id == id) {
                for (int j = i; j < total_users - 1; ++j) {
                    users[j] = users[j + 1];
                }
                --total_users;
                return;
            }
        }
    }
    void update(std::string id, std::string name, std::string address, float value, bool isCustomer) {
        for (int i = 0; i < total_users; ++i) {
            if (users[i]->id == id) {
                users[i]->name = name;
                users[i]->address = address;
                if (isCustomer) {
                    static_cast<Customer*>(users[i])->consumption = value;
                } else {
                    static_cast<Producer*>(users[i])->production = value;
                }
                return;
            }
        }
    }
    void search(std::string id) {
        for (int i = 0; i < total_users; ++i) {
            if (users[i]->id == id) {
                users[i]->display();
                return;
            }
        }
        std::cout << "User not found\n";
    }
    void displayAll() {
        for (int i = 0; i < total_users; ++i) {
            users[i]->display();
        }
    }
};

int main() {
    GridSystem grid;
    grid.add(new Customer("C1", "Alice", "123 Road St", 350.5));
    grid.add(new Producer("P1", "SolarCorp", "456 Green Ave", 1000.0));
    grid.displayAll();
    grid.search("C1");
    grid.update("C1", "Alice B", "123 Road St", 400.0, true);
    grid.search("C1");
    grid.remove("P1");
    grid.displayAll();
    return 0;
}