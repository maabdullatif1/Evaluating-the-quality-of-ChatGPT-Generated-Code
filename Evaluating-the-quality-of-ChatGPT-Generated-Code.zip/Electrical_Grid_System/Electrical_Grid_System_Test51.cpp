#include <iostream>
#include <string>

using namespace std;

class Person {
protected:
    string name;
    string address;
public:
    Person(string name = "", string address = "") : name(name), address(address) {}
    string getName() const { return name; }
    string getAddress() const { return address; }
    void setName(const string& name) { this->name = name; }
    void setAddress(const string& address) { this->address = address; }
};

class Customer : public Person {
    int usage;
public:
    Customer(string name = "", string address = "", int usage = 0) : Person(name, address), usage(usage) {}
    int getUsage() const { return usage; }
    void setUsage(int usage) { this->usage = usage; }
};

class Producer : public Person {
    int production;
public:
    Producer(string name = "", string address = "", int production = 0) : Person(name, address), production(production) {}
    int getProduction() const { return production; }
    void setProduction(int production) { this->production = production; }
};

template <typename T>
class GridSystem {
    T *list[100];
    int count;
public:
    GridSystem() : count(0) {}
    void add(const T& obj) {
        if (count < 100) {
            list[count++] = new T(obj);
        }
    }
    void remove(const string& name) {
        for (int i = 0; i < count; ++i) {
            if (list[i]->getName() == name) {
                delete list[i];
                for (int j = i; j < count - 1; ++j) {
                    list[j] = list[j + 1];
                }
                --count;
                break;
            }
        }
    }
    T* search(const string& name) {
        for (int i = 0; i < count; ++i) {
            if (list[i]->getName() == name) {
                return list[i];
            }
        }
        return nullptr;
    }
    void display() {
        for (int i = 0; i < count; ++i) {
            cout << "Name: " << list[i]->getName() << ", Address: " << list[i]->getAddress() << endl;
            if constexpr (is_same_v<T, Customer>) {
                cout << "Usage: " << list[i]->getUsage() << " kWh" << endl;
            } else if constexpr (is_same_v<T, Producer>) {
                cout << "Production: " << list[i]->getProduction() << " kWh" << endl;
            }
            cout << "-----" << endl;
        }
    }
};

int main() {
    GridSystem<Customer> customers;
    GridSystem<Producer> producers;

    customers.add(Customer("Alice", "123 Maple St", 300));
    customers.add(Customer("Bob", "456 Oak Rd", 500));
    
    producers.add(Producer("Solar Inc", "789 Sun Dr", 1000));
    producers.add(Producer("Wind LLC", "101 Wind Ave", 800));

    cout << "Customers:" << endl;
    customers.display();
    
    cout << "Producers:" << endl;
    producers.display();

    Customer* c = customers.search("Alice");
    if (c) c->setUsage(350);

    customers.remove("Bob");
    producers.remove("Solar Inc");

    cout << "Updated Customers:" << endl;
    customers.display();
    
    cout << "Updated Producers:" << endl;
    producers.display();

    return 0;
}