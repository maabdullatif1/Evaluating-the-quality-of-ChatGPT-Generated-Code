#include <iostream>
#include <vector>
#include <string>

class Entity {
protected:
    std::string name;
    std::string id;
public:
    Entity(std::string n, std::string i) : name(n), id(i) {}
    std::string getName() { return name; }
    std::string getId() { return id; }
    void setName(std::string n) { name = n; }
    virtual void display() = 0;
};

class Customer : public Entity {
    double consumption;
public:
    Customer(std::string n, std::string i, double c) : Entity(n, i), consumption(c) {}
    double getConsumption() { return consumption; }
    void setConsumption(double c) { consumption = c; }
    void display() override {
        std::cout << "Customer ID: " << id << ", Name: " << name << ", Consumption: " << consumption << " kWh\n";
    }
};

class Producer : public Entity {
    double production;
public:
    Producer(std::string n, std::string i, double p) : Entity(n, i), production(p) {}
    double getProduction() { return production; }
    void setProduction(double p) { production = p; }
    void display() override {
        std::cout << "Producer ID: " << id << ", Name: " << name << ", Production: " << production << " kWh\n";
    }
};

class GridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;
public:
    void addCustomer(Customer c) {
        customers.push_back(c);
    }
    
    void addProducer(Producer p) {
        producers.push_back(p);
    }
    
    void deleteCustomer(std::string id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == id) {
                customers.erase(it);
                return;
            }
        }
    }
    
    void deleteProducer(std::string id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getId() == id) {
                producers.erase(it);
                return;
            }
        }
    }
    
    void updateCustomer(std::string id, std::string newName, double newConsumption) {
        for (auto &customer : customers) {
            if (customer.getId() == id) {
                customer.setName(newName);
                customer.setConsumption(newConsumption);
                return;
            }
        }
    }
    
    void updateProducer(std::string id, std::string newName, double newProduction) {
        for (auto &producer : producers) {
            if (producer.getId() == id) {
                producer.setName(newName);
                producer.setProduction(newProduction);
                return;
            }
        }
    }
    
    Entity* searchEntity(std::string id) {
        for (auto &customer : customers) {
            if (customer.getId() == id) {
                return &customer;
            }
        }
        for (auto &producer : producers) {
            if (producer.getId() == id) {
                return &producer;
            }
        }
        return nullptr;
    }
    
    void displayAll() {
        std::cout << "Customers:\n";
        for (auto &customer : customers) {
            customer.display();
        }
        std::cout << "Producers:\n";
        for (auto &producer : producers) {
            producer.display();
        }
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer(Customer("Alice", "C001", 123.45));
    grid.addProducer(Producer("Solar Co", "P001", 1000.0));
    grid.displayAll();
    grid.updateCustomer("C001", "Alice Smith", 150.0);
    grid.displayAll();
    grid.deleteProducer("P001");
    grid.displayAll();
    return 0;
}