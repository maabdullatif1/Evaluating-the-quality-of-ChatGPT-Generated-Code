#include <iostream>
#include <vector>
#include <string>

class Entity {
protected:
    int id;
    std::string name;
    std::string type;
    double power;
public:
    int getId() const { return id; }
    void setId(int id) { this->id = id; }
    std::string getName() const { return name; }
    void setName(std::string name) { this->name = name; }
    std::string getType() const { return type; }
    void setType(std::string type) { this->type = type; }
    double getPower() const { return power; }
    void setPower(double power) { this->power = power; }
};

class Customer : public Entity {
public:
    Customer(int id, std::string name, double consumption) {
        this->id = id;
        this->name = name;
        this->type = "Customer";
        this->power = consumption;
    }
};

class Producer : public Entity {
public:
    Producer(int id, std::string name, double generation) {
        this->id = id;
        this->name = name;
        this->type = "Producer";
        this->power = generation;
    }
};

class GridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;
public:
    void addCustomer(int id, std::string name, double consumption) {
        customers.push_back(Customer(id, name, consumption));
    }

    void addProducer(int id, std::string name, double generation) {
        producers.push_back(Producer(id, name, generation));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void deleteProducer(int id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getId() == id) {
                producers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string name, double consumption) {
        for (auto &customer : customers) {
            if (customer.getId() == id) {
                customer.setName(name);
                customer.setPower(consumption);
            }
        }
    }

    void updateProducer(int id, std::string name, double generation) {
        for (auto &producer : producers) {
            if (producer.getId() == id) {
                producer.setName(name);
                producer.setPower(generation);
            }
        }
    }

    Entity* searchEntity(int id) {
        for (auto &customer : customers) {
            if (customer.getId() == id) {
                return &customer;
            }
        }
        for (auto &producer : producers) {
            if (producer.getId() == id) {
                return &producer;
            }
        }
        return nullptr;
    }

    void displayAll() {
        std::cout << "Customers:\n";
        for (const auto &customer : customers) {
            std::cout << "ID: " << customer.getId() << ", Name: " << customer.getName() << ", Consumption: " << customer.getPower() << "\n";
        }
        std::cout << "Producers:\n";
        for (const auto &producer : producers) {
            std::cout << "ID: " << producer.getId() << ", Name: " << producer.getName() << ", Generation: " << producer.getPower() << "\n";
        }
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer(1, "Customer A", 100.5);
    grid.addProducer(2, "Producer B", 200.0);
    grid.displayAll();
    grid.updateCustomer(1, "Customer X", 120.0);
    grid.displayAll();
    grid.deleteProducer(2);
    grid.displayAll();
    
    return 0;
}