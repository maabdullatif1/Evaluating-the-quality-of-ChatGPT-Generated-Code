#include <iostream>
#include <vector>
#include <string>

class Entity {
protected:
    int id;
    std::string name;
public:
    Entity(int i, std::string n) : id(i), name(n) {}
    int getId() const { return id; }
    std::string getName() const { return name; }
    virtual void display() const = 0;
};

class Customer : public Entity {
    double consumption;
public:
    Customer(int i, std::string n, double c) : Entity(i, n), consumption(c) {}
    void updateConsumption(double c) { consumption = c; }
    double getConsumption() const { return consumption; }
    void display() const {
        std::cout << "Customer ID: " << id << ", Name: " << name << ", Consumption: " << consumption << std::endl;
    }
};

class Producer : public Entity {
    double production;
public:
    Producer(int i, std::string n, double p) : Entity(i, n), production(p) {}
    void updateProduction(double p) { production = p; }
    double getProduction() const { return production; }
    void display() const {
        std::cout << "Producer ID: " << id << ", Name: " << name << ", Production: " << production << std::endl;
    }
};

class ElectricalGrid {
    std::vector<Entity*> entities;
public:
    ~ElectricalGrid() {
        for (auto entity : entities)
            delete entity;
    }
    void addCustomer(int id, const std::string& name, double consumption) {
        entities.push_back(new Customer(id, name, consumption));
    }
    void addProducer(int id, const std::string& name, double production) {
        entities.push_back(new Producer(id, name, production));
    }
    void deleteEntity(int id) {
        for (auto it = entities.begin(); it != entities.end(); ++it) {
            if ((*it)->getId() == id) {
                delete *it;
                entities.erase(it);
                break;
            }
        }
    }
    void updateCustomer(int id, double consumption) {
        for (auto entity : entities) {
            Customer* customer = dynamic_cast<Customer*>(entity);
            if (customer && customer->getId() == id) {
                customer->updateConsumption(consumption);
                break;
            }
        }
    }
    void updateProducer(int id, double production) {
        for (auto entity : entities) {
            Producer* producer = dynamic_cast<Producer*>(entity);
            if (producer && producer->getId() == id) {
                producer->updateProduction(production);
                break;
            }
        }
    }
    void searchEntity(int id) const {
        for (auto entity : entities) {
            if (entity->getId() == id) {
                entity->display();
                return;
            }
        }
        std::cout << "Entity with ID: " << id << " not found." << std::endl;
    }
    void displayEntities() const {
        for (auto entity : entities) {
            entity->display();
        }
    }
};

int main() {
    ElectricalGrid grid;
    grid.addCustomer(1, "Alice", 150.0);
    grid.addProducer(2, "Solar Plant A", 500.0);
    grid.displayEntities();
    grid.updateCustomer(1, 200.0);
    grid.updateProducer(2, 550.0);
    grid.searchEntity(1);
    grid.searchEntity(3);
    grid.deleteEntity(1);
    grid.displayEntities();
    return 0;
}