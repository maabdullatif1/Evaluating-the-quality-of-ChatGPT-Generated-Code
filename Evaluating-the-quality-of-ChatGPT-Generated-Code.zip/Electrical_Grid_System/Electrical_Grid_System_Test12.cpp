#include <iostream>
#include <vector>
using namespace std;

class Entity {
protected:
    string id;
    string name;
    double power;

public:
    Entity(string id, string name, double power) : id(id), name(name), power(power) {}

    string getId() { return id; }

    void updateInfo(string newName, double newPower) {
        name = newName;
        power = newPower;
    }

    void display() {
        cout << "ID: " << id << ", Name: " << name << ", Power: " << power << endl;
    }
};

class GridSystem {
    vector<Entity> customers;
    vector<Entity> producers;

public:
    void addCustomer(string id, string name, double power) {
        customers.push_back(Entity(id, name, power));
    }

    void addProducer(string id, string name, double power) {
        producers.push_back(Entity(id, name, power));
    }

    void deleteCustomer(string id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void deleteProducer(string id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getId() == id) {
                producers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(string id, string name, double power) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                customer.updateInfo(name, power);
                break;
            }
        }
    }

    void updateProducer(string id, string name, double power) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                producer.updateInfo(name, power);
                break;
            }
        }
    }

    Entity* searchCustomer(string id) {
        for (auto& customer : customers) {
            if (customer.getId() == id) return &customer;
        }
        return nullptr;
    }

    Entity* searchProducer(string id) {
        for (auto& producer : producers) {
            if (producer.getId() == id) return &producer;
        }
        return nullptr;
    }

    void displayCustomers() {
        for (auto& customer : customers) {
            customer.display();
        }
    }

    void displayProducers() {
        for (auto& producer : producers) {
            producer.display();
        }
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer("C001", "John Doe", 100.0);
    grid.addProducer("P001", "Wind Farm", 500.0);

    cout << "Customers:" << endl;
    grid.displayCustomers();

    cout << "Producers:" << endl;
    grid.displayProducers();

    grid.updateCustomer("C001", "John Smith", 120.0);

    cout << "Updated Customers:" << endl;
    grid.displayCustomers();

    Entity* customer = grid.searchCustomer("C001");
    if (customer) customer->display();

    grid.deleteProducer("P001");

    cout << "After Deletion - Producers:" << endl;
    grid.displayProducers();

    return 0;
}