#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Entity {
protected:
    string id;
    string name;
public:
    Entity(string id, string name) : id(id), name(name) {}
    string getId() { return id; }
    string getName() { return name; }
    void setName(string newName) { name = newName; }
};

class Customer : public Entity {
    double consumption;
public:
    Customer(string id, string name, double consumption) : Entity(id, name), consumption(consumption) {}
    double getConsumption() { return consumption; }
    void setConsumption(double newConsumption) { consumption = newConsumption; }
};

class Producer : public Entity {
    double production;
public:
    Producer(string id, string name, double production) : Entity(id, name), production(production) {}
    double getProduction() { return production; }
    void setProduction(double newProduction) { production = newProduction; }
};

class GridSystem {
    vector<Customer> customers;
    vector<Producer> producers;
public:
    void addCustomer(string id, string name, double consumption) {
        customers.push_back(Customer(id, name, consumption));
    }
    
    void addProducer(string id, string name, double production) {
        producers.push_back(Producer(id, name, production));
    }
    
    void deleteCustomer(string id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void deleteProducer(string id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getId() == id) {
                producers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(string id, string name, double consumption) {
        for(auto &customer : customers) {
            if(customer.getId() == id) {
                customer.setName(name);
                customer.setConsumption(consumption);
                break;
            }
        }
    }
    
    void updateProducer(string id, string name, double production) {
        for(auto &producer : producers) {
            if(producer.getId() == id) {
                producer.setName(name);
                producer.setProduction(production);
                break;
            }
        }
    }
    
    Customer* searchCustomer(string id) {
        for(auto &customer : customers) {
            if(customer.getId() == id) return &customer;
        }
        return nullptr;
    }
    
    Producer* searchProducer(string id) {
        for(auto &producer : producers) {
            if(producer.getId() == id) return &producer;
        }
        return nullptr;
    }
    
    void displayCustomers() {
        for(const auto &customer : customers) {
            cout << "ID: " << customer.getId() << ", Name: " << customer.getName() << ", Consumption: " << customer.getConsumption() << endl;
        }
    }
    
    void displayProducers() {
        for(const auto &producer : producers) {
            cout << "ID: " << producer.getId() << ", Name: " << producer.getName() << ", Production: " << producer.getProduction() << endl;
        }
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer("C001", "John Doe", 1500.0);
    grid.addProducer("P001", "Green Energy", 5000.0);
    grid.displayCustomers();
    grid.displayProducers();
    return 0;
}