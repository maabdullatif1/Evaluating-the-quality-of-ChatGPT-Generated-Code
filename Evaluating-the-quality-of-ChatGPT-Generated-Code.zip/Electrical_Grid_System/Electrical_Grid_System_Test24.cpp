#include <iostream>
#include <string>
#include <vector>

class Entity {
protected:
    std::string name;
    int id;
public:
    Entity(std::string n, int i) : name(n), id(i) {}
    virtual void display() const = 0;
    int getId() const { return id; }
};

class Customer : public Entity {
    double consumption;
public:
    Customer(std::string n, int i, double c) : Entity(n, i), consumption(c) {}
    void display() const override {
        std::cout << "Customer Name: " << name << ", ID: " << id << ", Consumption: " << consumption << "\n";
    }
    void updateConsumption(double c) { consumption = c; }
};

class ElectricityProducer : public Entity {
    double production;
public:
    ElectricityProducer(std::string n, int i, double p) : Entity(n, i), production(p) {}
    void display() const override {
        std::cout << "Producer Name: " << name << ", ID: " << id << ", Production: " << production << "\n";
    }
    void updateProduction(double p) { production = p; }
};

class GridSystem {
    std::vector<Customer> customers;
    std::vector<ElectricityProducer> producers;
public:
    void addCustomer(const std::string& name, int id, double consumption) {
        customers.push_back(Customer(name, id, consumption));
    }
    void addProducer(const std::string& name, int id, double production) {
        producers.push_back(ElectricityProducer(name, id, production));
    }
    void deleteCustomer(int id) {
        for(auto it = customers.begin(); it != customers.end(); ++it) {
            if(it->getId() == id) {
                customers.erase(it);
                break;
            }
        }
    }
    void deleteProducer(int id) {
        for(auto it = producers.begin(); it != producers.end(); ++it) {
            if(it->getId() == id) {
                producers.erase(it);
                break;
            }
        }
    }
    void updateCustomer(int id, double consumption) {
        for(auto& customer : customers) {
            if(customer.getId() == id) {
                customer.updateConsumption(consumption);
                break;
            }
        }
    }
    void updateProducer(int id, double production) {
        for(auto& producer : producers) {
            if(producer.getId() == id) {
                producer.updateProduction(production);
                break;
            }
        }
    }
    void searchEntity(int id) const {
        for(const auto& customer : customers) {
            if(customer.getId() == id) {
                customer.display();
                return;
            }
        }
        for(const auto& producer : producers) {
            if(producer.getId() == id) {
                producer.display();
                return;
            }
        }
        std::cout << "Entity not found with ID: " << id << "\n";
    }
    void displayAllEntities() const {
        std::cout << "All Customers:\n";
        for(const auto& customer : customers) customer.display();
        std::cout << "All Producers:\n";
        for(const auto& producer : producers) producer.display();
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer("John Doe", 1, 250.5);
    grid.addProducer("Wind Farm", 101, 5000);
    grid.displayAllEntities();
    grid.updateCustomer(1, 300);
    grid.updateProducer(101, 6000);
    grid.searchEntity(1);
    grid.searchEntity(101);
    grid.deleteCustomer(1);
    grid.deleteProducer(101);
    grid.displayAllEntities();
    return 0;
}