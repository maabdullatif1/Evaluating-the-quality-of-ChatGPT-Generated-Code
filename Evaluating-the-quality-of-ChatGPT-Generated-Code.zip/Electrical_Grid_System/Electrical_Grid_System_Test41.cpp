#include <iostream>
#include <string>

const int MAX_ENTITIES = 100;

struct Entity {
    std::string id;
    std::string name;
    std::string address;
    float electricity_usage;
};

class ElectricalGridSystem {
    Entity customers[MAX_ENTITIES];
    Entity producers[MAX_ENTITIES];
    int customer_count;
    int producer_count;
    
public:
    ElectricalGridSystem() : customer_count(0), producer_count(0) {}

    void addEntity(Entity list[], int &count, const std::string &id, const std::string &name, const std::string &address, float electricity_usage) {
        if(count < MAX_ENTITIES) {
            list[count].id = id;
            list[count].name = name;
            list[count].address = address;
            list[count].electricity_usage = electricity_usage;
            count++;
        }
    }

    void deleteEntity(Entity list[], int &count, const std::string &id) {
        for(int i = 0; i < count; i++) {
            if(list[i].id == id) {
                for(int j = i; j < count - 1; j++) {
                    list[j] = list[j + 1];
                }
                count--;
                break;
            }
        }
    }

    void updateEntity(Entity list[], int count, const std::string &id, const std::string &name, const std::string &address, float electricity_usage) {
        for(int i = 0; i < count; i++) {
            if(list[i].id == id) {
                list[i].name = name;
                list[i].address = address;
                list[i].electricity_usage = electricity_usage;
                break;
            }
        }
    }

    Entity* searchEntity(Entity list[], int count, const std::string &id) {
        for(int i = 0; i < count; i++) {
            if(list[i].id == id) {
                return &list[i];
            }
        }
        return nullptr;
    }

    void displayEntities(Entity list[], int count) {
        for(int i = 0; i < count; i++) {
            std::cout << "ID: " << list[i].id 
                      << ", Name: " << list[i].name 
                      << ", Address: " << list[i].address 
                      << ", Electricity Usage: " << list[i].electricity_usage << " kWh" 
                      << std::endl;
        }
    }

    void addCustomer(const std::string &id, const std::string &name, const std::string &address, float electricity_usage) {
        addEntity(customers, customer_count, id, name, address, electricity_usage);
    }

    void deleteCustomer(const std::string &id) {
        deleteEntity(customers, customer_count, id);
    }

    void updateCustomer(const std::string &id, const std::string &name, const std::string &address, float electricity_usage) {
        updateEntity(customers, customer_count, id, name, address, electricity_usage);
    }

    Entity* searchCustomer(const std::string &id) {
        return searchEntity(customers, customer_count, id);
    }

    void displayCustomers() {
        displayEntities(customers, customer_count);
    }

    void addProducer(const std::string &id, const std::string &name, const std::string &address, float electricity_usage) {
        addEntity(producers, producer_count, id, name, address, electricity_usage);
    }

    void deleteProducer(const std::string &id) {
        deleteEntity(producers, producer_count, id);
    }

    void updateProducer(const std::string &id, const std::string &name, const std::string &address, float electricity_usage) {
        updateEntity(producers, producer_count, id, name, address, electricity_usage);
    }

    Entity* searchProducer(const std::string &id) {
        return searchEntity(producers, producer_count, id);
    }

    void displayProducers() {
        displayEntities(producers, producer_count);
    }
};

int main() {
    ElectricalGridSystem gridSystem;

    gridSystem.addCustomer("C001", "John Doe", "123 Elm St", 250.5);
    gridSystem.addProducer("P001", "Solar Plant", "456 Oak St", 1000.0);

    gridSystem.displayCustomers();
    gridSystem.displayProducers();

    return 0;
}