#include <iostream>
#include <vector>
#include <string>

class Entity {
public:
    virtual void display() const = 0;
    virtual std::string getName() const = 0;
    virtual void update(const std::string &newInfo) = 0;
};

class Customer : public Entity {
    std::string name;
    std::string address;
    int id;
public:
    Customer(const std::string &n, const std::string &a, int i)
        : name(n), address(a), id(i) {}
    
    void display() const {
        std::cout << "Customer ID: " << id << ", Name: " << name 
                  << ", Address: " << address << std::endl;
    }
    
    std::string getName() const {
        return name;
    }
    
    void update(const std::string &newAddress) {
        address = newAddress;
    }
};

class Producer : public Entity {
    std::string name;
    float output;
    int id;
public:
    Producer(const std::string &n, float o, int i)
        : name(n), output(o), id(i) {}
    
    void display() const {
        std::cout << "Producer ID: " << id << ", Name: " << name 
                  << ", Output: " << output << " MW" << std::endl;
    }
    
    std::string getName() const {
        return name;
    }
    
    void update(const std::string &newOutput) {
        output = std::stof(newOutput);
    }
};

class ElectricalGrid {
    std::vector<Entity*> entities;
    int nextCustomerId;
    int nextProducerId;
public:
    ElectricalGrid() : nextCustomerId(1), nextProducerId(1) {}
    
    void addCustomer(const std::string &name, const std::string &address) {
        entities.push_back(new Customer(name, address, nextCustomerId++));
    }
    
    void addProducer(const std::string &name, float output) {
        entities.push_back(new Producer(name, output, nextProducerId++));
    }
    
    void deleteEntity(const std::string &name) {
        for (auto it = entities.begin(); it != entities.end();) {
            if ((*it)->getName() == name) {
                delete *it;
                it = entities.erase(it);
            } else {
                ++it;
            }
        }
    }
    
    void updateEntity(const std::string &name, const std::string &newInfo) {
        for (auto &entity : entities) {
            if (entity->getName() == name) {
                entity->update(newInfo);
            }
        }
    }
    
    void displayEntity(const std::string &name) const {
        for (const auto &entity : entities) {
            if (entity->getName() == name) {
                entity->display();
            }
        }
    }
    
    void displayAll() const {
        for (const auto &entity : entities) {
            entity->display();
        }
    }
    
    ~ElectricalGrid() {
        for (auto &entity : entities) {
            delete entity;
        }
    }
};

int main() {
    ElectricalGrid grid;
    grid.addCustomer("Alice", "123 Main St");
    grid.addProducer("HydroCo", 300.5);
    grid.displayAll();
    grid.updateEntity("Alice", "456 Elm St");
    grid.displayEntity("Alice");
    grid.deleteEntity("HydroCo");
    grid.displayAll();
    return 0;
}