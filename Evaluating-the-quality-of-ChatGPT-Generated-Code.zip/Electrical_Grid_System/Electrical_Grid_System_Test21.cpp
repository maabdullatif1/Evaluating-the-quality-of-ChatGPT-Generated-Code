#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Entity {
public:
    Entity(string n, string a) : name(n), address(a) {}
    string getName() const { return name; }
    string getAddress() const { return address; }
    void setName(string n) { name = n; }
    void setAddress(string a) { address = a; }
    virtual void display() const = 0;
private:
    string name;
    string address;
};

class Customer : public Entity {
public:
    Customer(string n, string a, double c) : Entity(n, a), consumption(c) {}
    double getConsumption() const { return consumption; }
    void setConsumption(double c) { consumption = c; }
    void display() const override {
        cout << "Customer Name: " << getName() << ", Address: " << getAddress() 
             << ", Consumption: " << consumption << " kWh" << endl;
    }
private:
    double consumption;
};

class Producer : public Entity {
public:
    Producer(string n, string a, double p) : Entity(n, a), production(p) {}
    double getProduction() const { return production; }
    void setProduction(double p) { production = p; }
    void display() const override {
        cout << "Producer Name: " << getName() << ", Address: " << getAddress() 
             << ", Production: " << production << " kWh" << endl;
    }
private:
    double production;
};

class GridSystem {
public:
    void addCustomer(const Customer& c) { customers.push_back(c); }
    void addProducer(const Producer& p) { producers.push_back(p); }
    void deleteCustomer(const string& name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getName() == name) {
                customers.erase(it);
                break;
            }
        }
    }
    void deleteProducer(const string& name) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getName() == name) {
                producers.erase(it);
                break;
            }
        }
    }
    void updateCustomer(const string& name, const string& newName, const string& newAddress, double newConsumption) {
        for (auto& c : customers) {
            if (c.getName() == name) {
                c.setName(newName);
                c.setAddress(newAddress);
                c.setConsumption(newConsumption);
                break;
            }
        }
    }
    void updateProducer(const string& name, const string& newName, const string& newAddress, double newProduction) {
        for (auto& p : producers) {
            if (p.getName() == name) {
                p.setName(newName);
                p.setAddress(newAddress);
                p.setProduction(newProduction);
                break;
            }
        }
    }
    void searchCustomer(const string& name) const {
        for (const auto& c : customers) {
            if (c.getName() == name) {
                c.display();
                return;
            }
        }
        cout << "Customer not found" << endl;
    }
    void searchProducer(const string& name) const {
        for (const auto& p : producers) {
            if (p.getName() == name) {
                p.display();
                return;
            }
        }
        cout << "Producer not found" << endl;
    }
    void displayAll() const {
        cout << "Customers:" << endl;
        for (const auto& c : customers) c.display();
        cout << "Producers:" << endl;
        for (const auto& p : producers) p.display();
    }
private:
    vector<Customer> customers;
    vector<Producer> producers;
};

int main() {
    GridSystem grid;
    grid.addCustomer(Customer("John Doe", "123 Elm Street", 500));
    grid.addProducer(Producer("Solar Inc.", "456 Oak Avenue", 1000));
    grid.displayAll();
    grid.updateCustomer("John Doe", "John Smith", "789 Pine Road", 600);
    grid.searchCustomer("John Smith");
    grid.deleteProducer("Solar Inc.");
    grid.displayAll();
    return 0;
}