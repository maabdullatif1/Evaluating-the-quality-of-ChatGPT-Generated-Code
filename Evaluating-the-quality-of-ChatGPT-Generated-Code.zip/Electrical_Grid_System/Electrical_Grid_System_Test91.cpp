#include <iostream>
#include <vector>
#include <string>

class Participant {
protected:
    int id;
    std::string name;
public:
    Participant(int id, const std::string& name) : id(id), name(name) {}
    int getId() const { return id; }
    std::string getName() const { return name; }
    virtual void display() const = 0;
};

class Customer : public Participant {
    double consumedEnergy;
public:
    Customer(int id, const std::string& name, double consumedEnergy) 
        : Participant(id, name), consumedEnergy(consumedEnergy) {}
    void updateEnergy(double energy) { consumedEnergy = energy; }
    void display() const override {
        std::cout << "Customer ID: " << id << ", Name: " << name 
                  << ", Consumed Energy: " << consumedEnergy << std::endl;
    }
};

class Producer : public Participant {
    double producedEnergy;
public:
    Producer(int id, const std::string& name, double producedEnergy) 
        : Participant(id, name), producedEnergy(producedEnergy) {}
    void updateEnergy(double energy) { producedEnergy = energy; }
    void display() const override {
        std::cout << "Producer ID: " << id << ", Name: " << name 
                  << ", Produced Energy: " << producedEnergy << std::endl;
    }
}

class GridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;
    int nextId;
public:
    GridSystem() : nextId(1) {}
    int addCustomer(const std::string& name, double consumedEnergy) {
        customers.emplace_back(nextId, name, consumedEnergy);
        return nextId++;
    }
    int addProducer(const std::string& name, double producedEnergy) {
        producers.emplace_back(nextId, name, producedEnergy);
        return nextId++;
    }
    void deleteCustomer(int id) {
        customers.erase(std::remove_if(customers.begin(), customers.end(), 
            [id](const Customer& c){ return c.getId() == id; }), customers.end());
    }
    void deleteProducer(int id) {
        producers.erase(std::remove_if(producers.begin(), producers.end(), 
            [id](const Producer& p){ return p.getId() == id; }), producers.end());
    }
    void updateCustomerEnergy(int id, double energy) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                customer.updateEnergy(energy);
                break;
            }
        }
    }
    void updateProducerEnergy(int id, double energy) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                producer.updateEnergy(energy);
                break;
            }
        }
    }
    Participant* searchParticipant(int id) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                return &customer;
            }
        }
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                return &producer;
            }
        }
        return nullptr;
    }
    void displayAll() {
        for (const auto& customer : customers) {
            customer.display();
        }
        for (const auto& producer : producers) {
            producer.display();
        }
    }
};

int main() {
    GridSystem grid;
    int id1 = grid.addCustomer("Alice", 300);
    int id2 = grid.addProducer("Bob's Solar", 500);
    grid.displayAll();
    grid.updateCustomerEnergy(id1, 350);
    grid.updateProducerEnergy(id2, 550);
    grid.displayAll();
    grid.deleteCustomer(id1);
    grid.displayAll();
    return 0;
}