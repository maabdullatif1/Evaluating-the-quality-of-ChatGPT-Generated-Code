#include <iostream>
#include <vector>
#include <string>

struct Entity {
    std::string name;
    std::string address;
    double power;
};

class ElectricalGrid {
private:
    std::vector<Entity> customers;
    std::vector<Entity> producers;

public:
    void addEntity(std::vector<Entity>& list, const std::string& name, const std::string& address, double power) {
        list.push_back({name, address, power});
    }

    void deleteEntity(std::vector<Entity>& list, const std::string& name) {
        for (auto it = list.begin(); it != list.end(); ++it) {
            if (it->name == name) {
                list.erase(it);
                return;
            }
        }
    }

    void updateEntity(std::vector<Entity>& list, const std::string& name, const std::string& newAddress, double newPower) {
        for (auto& entity : list) {
            if (entity.name == name) {
                entity.address = newAddress;
                entity.power = newPower;
                return;
            }
        }
    }

    Entity* searchEntity(std::vector<Entity>& list, const std::string& name) {
        for (auto& entity : list) {
            if (entity.name == name) {
                return &entity;
            }
        }
        return nullptr;
    }

    void displayEntities(const std::vector<Entity>& list) {
        for (const auto& entity : list) {
            std::cout << "Name: " << entity.name << ", Address: " << entity.address << ", Power: " << entity.power << std::endl;
        }
    }

    void addCustomer(const std::string& name, const std::string& address, double power) {
        addEntity(customers, name, address, power);
    }

    void deleteCustomer(const std::string& name) {
        deleteEntity(customers, name);
    }

    void updateCustomer(const std::string& name, const std::string& newAddress, double newPower) {
        updateEntity(customers, name, newAddress, newPower);
    }

    Entity* searchCustomer(const std::string& name) {
        return searchEntity(customers, name);
    }

    void displayCustomers() {
        displayEntities(customers);
    }

    void addProducer(const std::string& name, const std::string& address, double power) {
        addEntity(producers, name, address, power);
    }

    void deleteProducer(const std::string& name) {
        deleteEntity(producers, name);
    }

    void updateProducer(const std::string& name, const std::string& newAddress, double newPower) {
        updateEntity(producers, name, newAddress, newPower);
    }

    Entity* searchProducer(const std::string& name) {
        return searchEntity(producers, name);
    }

    void displayProducers() {
        displayEntities(producers);
    }
};

int main() {
    ElectricalGrid grid;
    grid.addCustomer("Alice", "123 Main St", 5.0);
    grid.addProducer("SolarInc", "456 Green Rd", 10.0);
    grid.displayCustomers();
    grid.displayProducers();
    return 0;
}