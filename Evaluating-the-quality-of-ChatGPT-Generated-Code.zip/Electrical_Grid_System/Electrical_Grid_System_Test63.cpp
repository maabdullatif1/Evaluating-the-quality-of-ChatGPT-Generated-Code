#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    float consumption;

    Customer(int id, const std::string& name, float consumption)
        : id(id), name(name), consumption(consumption) {}
};

class Producer {
public:
    int id;
    std::string name;
    float production;

    Producer(int id, const std::string& name, float production)
        : id(id), name(name), production(production) {}
};

class GridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;

public:
    void addCustomer(int id, const std::string& name, float consumption) {
        customers.push_back(Customer(id, name, consumption));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, float consumption) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.consumption = consumption;
                return;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id
                      << ", Name: " << customer.name
                      << ", Consumption: " << customer.consumption << std::endl;
        }
    }

    void addProducer(int id, const std::string& name, float production) {
        producers.push_back(Producer(id, name, production));
    }

    void deleteProducer(int id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->id == id) {
                producers.erase(it);
                return;
            }
        }
    }

    void updateProducer(int id, const std::string& name, float production) {
        for (auto& producer : producers) {
            if (producer.id == id) {
                producer.name = name;
                producer.production = production;
                return;
            }
        }
    }

    Producer* searchProducer(int id) {
        for (auto& producer : producers) {
            if (producer.id == id) {
                return &producer;
            }
        }
        return nullptr;
    }

    void displayProducers() {
        for (const auto& producer : producers) {
            std::cout << "Producer ID: " << producer.id
                      << ", Name: " << producer.name
                      << ", Production: " << producer.production << std::endl;
        }
    }
};

int main() {
    GridSystem grid;

    grid.addCustomer(1, "Alice", 320.5);
    grid.addCustomer(2, "Bob", 150.2);
    grid.displayCustomers();

    grid.addProducer(1, "SolarPlant1", 1000.0);
    grid.addProducer(2, "WindFarm1", 500.0);
    grid.displayProducers();

    grid.updateCustomer(1, "Alice Smith", 330.0);
    grid.displayCustomers();

    grid.deleteProducer(2);
    grid.displayProducers();

    return 0;
}