#include <iostream>
#include <vector>
#include <string>

class Entity {
protected:
    int id;
    std::string name;
    std::string address;
public:
    Entity(int id, const std::string& name, const std::string& address)
        : id(id), name(name), address(address) {}

    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getAddress() const { return address; }

    void updateName(const std::string& newName) { name = newName; }
    void updateAddress(const std::string& newAddress) { address = newAddress; }
    
    virtual void display() const = 0;
};

class Customer : public Entity {
public:
    Customer(int id, const std::string& name, const std::string& address)
        : Entity(id, name, address) {}
    
    void display() const override {
        std::cout << "Customer ID: " << id 
                  << ", Name: " << name 
                  << ", Address: " << address << std::endl;
    }
};

class ElectricityProducer : public Entity {
public:
    ElectricityProducer(int id, const std::string& name, const std::string& address)
        : Entity(id, name, address) {}

    void display() const override {
        std::cout << "Producer ID: " << id 
                  << ", Name: " << name 
                  << ", Address: " << address << std::endl;
    }
};

class ElectricalGridSystem {
private:
    std::vector<Customer> customers;
    std::vector<ElectricityProducer> producers;

    template <typename T>
    void displayEntities(const std::vector<T>& entities) const {
        for (const auto& entity : entities) {
            entity.display();
        }
    }

public:
    void addCustomer(int id, const std::string& name, const std::string& address) {
        customers.push_back(Customer(id, name, address));
    }

    void addProducer(int id, const std::string& name, const std::string& address) {
        producers.push_back(ElectricityProducer(id, name, address));
    }

    void deleteCustomer(int id) {
        customers.erase(std::remove_if(customers.begin(), customers.end(), 
            [id](const Customer& c) { return c.getId() == id; }), customers.end());
    }

    void deleteProducer(int id) {
        producers.erase(std::remove_if(producers.begin(), producers.end(), 
            [id](const ElectricityProducer& p) { return p.getId() == id; }), producers.end());
    }

    void updateCustomer(int id, const std::string& name, const std::string& address) {
        for (auto& c : customers) {
            if (c.getId() == id) {
                c.updateName(name);
                c.updateAddress(address);
                break;
            }
        }
    }

    void updateProducer(int id, const std::string& name, const std::string& address) {
        for (auto& p : producers) {
            if (p.getId() == id) {
                p.updateName(name);
                p.updateAddress(address);
                break;
            }
        }
    }

    Entity* searchCustomer(int id) {
        for (auto& c : customers) {
            if (c.getId() == id) {
                return &c;
            }
        }
        return nullptr;
    }

    Entity* searchProducer(int id) {
        for (auto& p : producers) {
            if (p.getId() == id) {
                return &p;
            }
        }
        return nullptr;
    }

    void displayCustomers() const {
        displayEntities(customers);
    }

    void displayProducers() const {
        displayEntities(producers);
    }
};

int main() {
    ElectricalGridSystem system;
    system.addCustomer(1, "John Doe", "123 Elm St");
    system.addProducer(1, "Solar Inc.", "456 Solar Dr");
    system.displayCustomers();
    system.displayProducers();
    system.updateCustomer(1, "John D.", "321 Oak St");
    system.displayCustomers();
    system.deleteProducer(1);
    system.displayProducers();
    return 0;
}