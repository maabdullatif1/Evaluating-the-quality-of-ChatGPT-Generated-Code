#include <iostream>
#include <string>
#include <vector>

class Participant {
public:
    std::string name;
    std::string type;
    double balance;
    Participant(std::string n, std::string t, double b) : name(n), type(t), balance(b) {}
};

class ElectricalGridSystem {
private:
    std::vector<Participant> participants;

    int findParticipantIndex(const std::string& name) {
        for (int i = 0; i < participants.size(); ++i) {
            if (participants[i].name == name) return i;
        }
        return -1;
    }

public:
    void addParticipant(const std::string& name, const std::string& type, double balance) {
        if (type != "customer" && type != "producer") return;
        if (findParticipantIndex(name) == -1) {
            participants.push_back(Participant(name, type, balance));
        }
    }

    void deleteParticipant(const std::string& name) {
        int index = findParticipantIndex(name);
        if (index != -1) participants.erase(participants.begin() + index);
    }

    void updateParticipant(const std::string& name, const std::string& type, double balance) {
        int index = findParticipantIndex(name);
        if (index != -1 && (type == "customer" || type == "producer")) {
            participants[index].type = type;
            participants[index].balance = balance;
        }
    }

    Participant* searchParticipant(const std::string& name) {
        int index = findParticipantIndex(name);
        return index != -1 ? &participants[index] : nullptr;
    }

    void displayParticipants() {
        for (const auto& p : participants) {
            std::cout << "Name: " << p.name << ", Type: " << p.type << ", Balance: " << p.balance << "\n";
        }
        std::cout << std::endl;
    }
};

int main() {
    ElectricalGridSystem gridSystem;

    gridSystem.addParticipant("Alice", "customer", 100.50);
    gridSystem.addParticipant("Bob", "producer", 200.75);
    gridSystem.displayParticipants();

    gridSystem.updateParticipant("Alice", "customer", 150.00);
    gridSystem.displayParticipants();

    gridSystem.deleteParticipant("Bob");
    gridSystem.displayParticipants();

    Participant* participant = gridSystem.searchParticipant("Alice");
    if (participant) {
        std::cout << "Found: " << participant->name << ", " << participant->type << ", " << participant->balance << "\n";
    }

    return 0;
}