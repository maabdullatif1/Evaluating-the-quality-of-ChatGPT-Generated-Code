#include <iostream>
#include <vector>
#include <string>

class Entity {
public:
    std::string id;
    std::string name;
    virtual void display() = 0;
};

class Customer : public Entity {
public:
    double consumption;
    Customer(const std::string& id, const std::string& name, double consumption)
        : consumption(consumption) {
        this->id = id;
        this->name = name;
    }
    void display() override {
        std::cout << "Customer ID: " << id << ", Name: " << name << ", Consumption: " << consumption << std::endl;
    }
};

class Producer : public Entity {
public:
    double production;
    Producer(const std::string& id, const std::string& name, double production)
        : production(production) {
        this->id = id;
        this->name = name;
    }
    void display() override {
        std::cout << "Producer ID: " << id << ", Name: " << name << ", Production: " << production << std::endl;
    }
};

class GridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;

    template <typename T>
    typename std::vector<T>::iterator findEntity(std::vector<T>& entities, const std::string& id) {
        for (auto it = entities.begin(); it != entities.end(); ++it) {
            if (it->id == id) return it;
        }
        return entities.end();
    }

public:
    void addCustomer(const std::string& id, const std::string& name, double consumption) {
        customers.emplace_back(id, name, consumption);
    }

    void addProducer(const std::string& id, const std::string& name, double production) {
        producers.emplace_back(id, name, production);
    }

    void deleteCustomer(const std::string& id) {
        auto it = findEntity(customers, id);
        if (it != customers.end()) customers.erase(it);
    }

    void deleteProducer(const std::string& id) {
        auto it = findEntity(producers, id);
        if (it != producers.end()) producers.erase(it);
    }

    void updateCustomer(const std::string& id, const std::string& name, double consumption) {
        auto it = findEntity(customers, id);
        if (it != customers.end()) {
            it->name = name;
            it->consumption = consumption;
        }
    }

    void updateProducer(const std::string& id, const std::string& name, double production) {
        auto it = findEntity(producers, id);
        if (it != producers.end()) {
            it->name = name;
            it->production = production;
        }
    }

    void searchCustomer(const std::string& id) {
        auto it = findEntity(customers, id);
        if (it != customers.end()) it->display();
        else std::cout << "Customer not found." << std::endl;
    }

    void searchProducer(const std::string& id) {
        auto it = findEntity(producers, id);
        if (it != producers.end()) it->display();
        else std::cout << "Producer not found." << std::endl;
    }

    void displayAllCustomers() {
        for (const auto& customer : customers) {
            customer.display();
        }
    }

    void displayAllProducers() {
        for (const auto& producer : producers) {
            producer.display();
        }
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer("C001", "Alice", 120.5);
    grid.addProducer("P001", "Solar Farm", 5000.0);
    grid.displayAllCustomers();
    grid.displayAllProducers();
    grid.searchCustomer("C001");
    grid.updateCustomer("C001", "Alice A", 130.0);
    grid.searchCustomer("C001");
    grid.deleteCustomer("C001");
    grid.searchCustomer("C001");
    return 0;
}