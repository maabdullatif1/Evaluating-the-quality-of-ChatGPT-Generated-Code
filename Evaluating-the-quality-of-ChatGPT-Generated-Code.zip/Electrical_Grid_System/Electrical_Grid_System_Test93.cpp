#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
    double powerConsumption;
};

struct Producer {
    int id;
    string name;
    string location;
    double powerProduction;
};

class ElectricalGridSystem {
private:
    vector<Customer> customers;
    vector<Producer> producers;
    int customerIDCounter;
    int producerIDCounter;

    template<typename T>
    int findIndexById(vector<T> &list, int id) {
        for (int i = 0; i < list.size(); ++i) {
            if (list[i].id == id) return i;
        }
        return -1;
    }

public:
    ElectricalGridSystem() : customerIDCounter(0), producerIDCounter(0) {}

    void addCustomer(string name, string address, double powerConsumption) {
        customers.push_back({customerIDCounter++, name, address, powerConsumption});
    }

    void deleteCustomer(int id) {
        int index = findIndexById(customers, id);
        if (index != -1) customers.erase(customers.begin() + index);
    }

    void updateCustomer(int id, string name, string address, double powerConsumption) {
        int index = findIndexById(customers, id);
        if (index != -1) {
            customers[index].name = name;
            customers[index].address = address;
            customers[index].powerConsumption = powerConsumption;
        }
    }

    Customer* searchCustomer(int id) {
        int index = findIndexById(customers, id);
        if (index != -1) return &customers[index];
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "ID: " << customer.id << ", Name: " << customer.name 
                 << ", Address: " << customer.address << ", Power Consumption: " 
                 << customer.powerConsumption << endl;
        }
    }

    void addProducer(string name, string location, double powerProduction) {
        producers.push_back({producerIDCounter++, name, location, powerProduction});
    }

    void deleteProducer(int id) {
        int index = findIndexById(producers, id);
        if (index != -1) producers.erase(producers.begin() + index);
    }

    void updateProducer(int id, string name, string location, double powerProduction) {
        int index = findIndexById(producers, id);
        if (index != -1) {
            producers[index].name = name;
            producers[index].location = location;
            producers[index].powerProduction = powerProduction;
        }
    }

    Producer* searchProducer(int id) {
        int index = findIndexById(producers, id);
        if (index != -1) return &producers[index];
        return nullptr;
    }

    void displayProducers() {
        for (const auto &producer : producers) {
            cout << "ID: " << producer.id << ", Name: " << producer.name 
                 << ", Location: " << producer.location << ", Power Production: " 
                 << producer.powerProduction << endl;
        }
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addCustomer("Alice", "123 Main St", 150.5);
    grid.addCustomer("Bob", "456 Elm St", 250.0);
    grid.addProducer("Solar Inc.", "Desert Plains", 5000.0);
    grid.addProducer("Wind Co.", "Hilltop", 1200.0);

    grid.displayCustomers();
    grid.displayProducers();

    grid.updateCustomer(0, "Alice Smith", "123 Main St", 160.0);
    grid.updateProducer(1, "Wind Company", "Hilltop", 1300.0);

    grid.deleteCustomer(1);
    grid.deleteProducer(0);

    grid.displayCustomers();
    grid.displayProducers();

    return 0;
}