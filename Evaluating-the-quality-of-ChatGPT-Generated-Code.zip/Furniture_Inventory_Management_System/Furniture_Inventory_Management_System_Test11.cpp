#include <iostream>
#include <vector>
#include <string>

struct Furniture {
    int id;
    std::string name;
    std::string type;
    double price;
    int quantity;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventoryManagementSystem {
    std::vector<Furniture> furnitures;
    std::vector<Supplier> suppliers;
    int nextFurnitureId;
    int nextSupplierId;

public:
    InventoryManagementSystem() : nextFurnitureId(1), nextSupplierId(1) {}

    void addFurniture(const std::string& name, const std::string& type, double price, int quantity) {
        Furniture newFurniture = {nextFurnitureId++, name, type, price, quantity};
        furnitures.push_back(newFurniture);
    }

    void deleteFurniture(int id) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->id == id) {
                furnitures.erase(it);
                return;
            }
        }
    }

    void updateFurniture(int id, const std::string& name, const std::string& type, double price, int quantity) {
        for (auto& f : furnitures) {
            if (f.id == id) {
                f.name = name;
                f.type = type;
                f.price = price;
                f.quantity = quantity;
                return;
            }
        }
    }
    
    void displayFurnitures() {
        for (const auto& f : furnitures) {
            std::cout << "ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type 
                      << ", Price: " << f.price << ", Quantity: " << f.quantity << "\n";
        }
    }

    void searchFurniture(const std::string& name) {
        for (const auto& f : furnitures) {
            if (f.name == name) {
                std::cout << "Found - ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type 
                          << ", Price: " << f.price << ", Quantity: " << f.quantity << "\n";
                return;
            }
        }
        std::cout << "Furniture not found\n";
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        Supplier newSupplier = {nextSupplierId++, name, contact};
        suppliers.push_back(newSupplier);
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                return;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& s : suppliers) {
            if (s.id == id) {
                s.name = name;
                s.contact = contact;
                return;
            }
        }
    }

    void displaySuppliers() {
        for (const auto& s : suppliers) {
            std::cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << "\n";
        }
    }

    void searchSupplier(const std::string& name) {
        for (const auto& s : suppliers) {
            if (s.name == name) {
                std::cout << "Found - ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << "\n";
                return;
            }
        }
        std::cout << "Supplier not found\n";
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addFurniture("Chair", "Wood", 49.99, 100);
    ims.addFurniture("Table", "Metal", 89.99, 50);
    ims.displayFurnitures();
    ims.searchFurniture("Chair");
    ims.updateFurniture(1, "Chair", "Plastic", 39.99, 150);
    ims.deleteFurniture(2);
    ims.displayFurnitures();
    ims.addSupplier("John's Supplies", "555-0123");
    ims.addSupplier("Furniture Inc.", "555-0456");
    ims.displaySuppliers();
    ims.searchSupplier("John's Supplies");
    ims.updateSupplier(1, "John's Materials", "555-0789");
    ims.deleteSupplier(2);
    ims.displaySuppliers();
    return 0;
}