#include <iostream>
#include <vector>
#include <string>

struct Furniture {
    int id;
    std::string name;
    std::string type;
    int quantity;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventorySystem {
private:
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

    Furniture* findFurniture(int id) {
        for (auto &f : furnitureList) {
            if (f.id == id) return &f;
        }
        return nullptr;
    }

    Supplier* findSupplier(int id) {
        for (auto &s : supplierList) {
            if (s.id == id) return &s;
        }
        return nullptr;
    }

public:
    void addFurniture(int id, const std::string &name, const std::string &type, int quantity) {
        if (!findFurniture(id)) {
            furnitureList.push_back({id, name, type, quantity});
        }
    }
    
    void deleteFurniture(int id) {
        furnitureList.erase(
            std::remove_if(furnitureList.begin(), furnitureList.end(), 
                [id](Furniture &f) { return f.id == id; }), 
            furnitureList.end());
    }

    void updateFurniture(int id, const std::string &name, const std::string &type, int quantity) {
        Furniture* f = findFurniture(id);
        if (f) {
            f->name = name;
            f->type = type;
            f->quantity = quantity;
        }
    }

    Furniture* searchFurniture(int id) {
        return findFurniture(id);
    }

    void displayFurniture() {
        for (const auto &f : furnitureList) {
            std::cout << "ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type 
                      << ", Quantity: " << f.quantity << std::endl;
        }
    }

    void addSupplier(int id, const std::string &name, const std::string &contact) {
        if (!findSupplier(id)) {
            supplierList.push_back({id, name, contact});
        }
    }
    
    void deleteSupplier(int id) {
        supplierList.erase(
            std::remove_if(supplierList.begin(), supplierList.end(), 
                [id](Supplier &s) { return s.id == id; }), 
            supplierList.end());
    }

    void updateSupplier(int id, const std::string &name, const std::string &contact) {
        Supplier* s = findSupplier(id);
        if (s) {
            s->name = name;
            s->contact = contact;
        }
    }  

    Supplier* searchSupplier(int id) {
        return findSupplier(id);
    }

    void displaySuppliers() {
        for (const auto &s : supplierList) {
            std::cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addFurniture(1, "Chair", "Wooden", 20);
    system.addFurniture(2, "Table", "Metal", 15);
    system.addSupplier(1, "ABC Inc.", "123456789");
    system.addSupplier(2, "XYZ Ltd.", "987654321");

    std::cout << "Furniture Inventory:" << std::endl;
    system.displayFurniture();

    std::cout << "\nSupplier Information:" << std::endl;
    system.displaySuppliers();

    return 0;
}