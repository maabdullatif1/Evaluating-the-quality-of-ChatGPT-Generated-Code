#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, std::string name, std::string contact) 
        : id(id), name(name), contact(contact) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    double price;
    int supplierId;

    Furniture(int id, std::string name, std::string type, double price, int supplierId)
        : id(id), name(name), type(type), price(price), supplierId(supplierId) {}
};

class InventorySystem {
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furniture;

public:
    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }
    
    void deleteSupplier(int id) {
        for(auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        for(auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for(auto &supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for(auto &supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }

    void addFurniture(int id, std::string name, std::string type, double price, int supplierId) {
        furniture.push_back(Furniture(id, name, type, price, supplierId));
    }
    
    void deleteFurniture(int id) {
        for(auto it = furniture.begin(); it != furniture.end(); ++it) {
            if (it->id == id) {
                furniture.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, std::string name, std::string type, double price, int supplierId) {
        for(auto &item : furniture) {
            if (item.id == id) {
                item.name = name;
                item.type = type;
                item.price = price;
                item.supplierId = supplierId;
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for(auto &item : furniture) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    void displayFurniture() {
        for(auto &item : furniture) {
            std::cout << "ID: " << item.id << ", Name: " << item.name << ", Type: " << item.type << ", Price: " << item.price << ", Supplier ID: " << item.supplierId << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addSupplier(1, "Acme Corp", "123-456-7890");
    system.addSupplier(2, "Furniture Co", "987-654-3210");
    system.displaySuppliers();

    system.addFurniture(101, "Sofa", "Living Room", 299.99, 1);
    system.addFurniture(102, "Dining Table", "Dining Room", 499.99, 2);
    system.displayFurniture();

    system.updateFurniture(101, "Sofa", "Living Room", 279.99, 1);
    system.displayFurniture();

    system.deleteFurniture(102);
    system.displayFurniture();

    Supplier* supplier = system.searchSupplier(1);
    if (supplier) {
        std::cout << "Found Supplier: " << supplier->name << std::endl;
    }

    Furniture* furniture = system.searchFurniture(101);
    if (furniture) {
        std::cout << "Found Furniture: " << furniture->name << std::endl;
    }

    return 0;
}