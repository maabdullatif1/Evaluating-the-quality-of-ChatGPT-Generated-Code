#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, const std::string& name, const std::string& contact)
        : id(id), name(name), contact(contact) {}
};

class Furniture {
public:
    int id;
    std::string name;
    int supplierId;
    int quantity;

    Furniture(int id, const std::string& name, int supplierId, int quantity)
        : id(id), name(name), supplierId(supplierId), quantity(quantity) {}
};

class InventoryManagementSystem {
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furniture;
    
    Supplier* findSupplierById(int id) {
        for (auto& s : suppliers) {
            if (s.id == id) return &s;
        }
        return nullptr;
    }

    Furniture* findFurnitureById(int id) {
        for (auto& f : furniture) {
            if (f.id == id) return &f;
        }
        return nullptr;
    }

public:
    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.emplace_back(id, name, contact);
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(), [id](const Supplier& s) { return s.id == id; }), suppliers.end());
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        Supplier* s = findSupplierById(id);
        if (s) {
            s->name = name;
            s->contact = contact;
        }
    }

    void displaySuppliers() {
        for (const auto& s : suppliers) {
            std::cout << "Supplier ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << std::endl;
        }
    }

    void addFurniture(int id, const std::string& name, int supplierId, int quantity) {
        furniture.emplace_back(id, name, supplierId, quantity);
    }

    void deleteFurniture(int id) {
        furniture.erase(std::remove_if(furniture.begin(), furniture.end(), [id](const Furniture& f) { return f.id == id; }), furniture.end());
    }

    void updateFurniture(int id, const std::string& name, int supplierId, int quantity) {
        Furniture* f = findFurnitureById(id);
        if (f) {
            f->name = name;
            f->supplierId = supplierId;
            f->quantity = quantity;
        }
    }

    void displayFurniture() {
        for (const auto& f : furniture) {
            std::cout << "Furniture ID: " << f.id << ", Name: " << f.name << ", Supplier ID: " << f.supplierId << ", Quantity: " << f.quantity << std::endl;
        }
    }

    Supplier* searchSupplier(int id) {
        return findSupplierById(id);
    }

    Furniture* searchFurniture(int id) {
        return findFurnitureById(id);
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier(1, "Supplier One", "123-456");
    ims.addSupplier(2, "Supplier Two", "789-012");
    ims.addFurniture(1, "Chair", 1, 30);
    ims.addFurniture(2, "Table", 2, 20);
    ims.displaySuppliers();
    ims.displayFurniture();
    ims.updateFurniture(1, "Office Chair", 1, 25);
    ims.displayFurniture();
    return 0;
}