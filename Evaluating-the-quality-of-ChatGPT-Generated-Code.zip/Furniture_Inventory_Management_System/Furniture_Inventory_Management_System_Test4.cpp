#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    
    Supplier(int i, std::string n, std::string c) : id(i), name(n), contact(c) {}
};

class Furniture {
public:
    int id;
    std::string name;
    double price;
    Supplier supplier;
    
    Furniture(int i, std::string n, double p, Supplier s) : id(i), name(n), price(p), supplier(s) {}
};

class InventoryManagementSystem {
private:
    std::vector<Furniture> furnitures;
    std::vector<Supplier> suppliers;

    Supplier* findSupplierById(int id) {
        for (auto& s : suppliers) {
            if (s.id == id)
                return &s;
        }
        return nullptr;
    }

public:
    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (size_t i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].id == id) {
                suppliers.erase(suppliers.begin() + i);
                return;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    Supplier* searchSupplier(int id) {
        return findSupplierById(id);
    }

    void displaySuppliers() {
        for (const auto& s : suppliers) {
            std::cout << "Supplier ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << std::endl;
        }
    }

    void addFurniture(int id, std::string name, double price, int supplierId) {
        Supplier* supplier = findSupplierById(supplierId);
        if (supplier) {
            furnitures.push_back(Furniture(id, name, price, *supplier));
        }
    }

    void deleteFurniture(int id) {
        for (size_t i = 0; i < furnitures.size(); ++i) {
            if (furnitures[i].id == id) {
                furnitures.erase(furnitures.begin() + i);
                return;
            }
        }
    }

    void updateFurniture(int id, std::string name, double price, int supplierId) {
        for (auto& f : furnitures) {
            if (f.id == id) {
                f.name = name;
                f.price = price;
                Supplier* supplier = findSupplierById(supplierId);
                if (supplier) {
                    f.supplier = *supplier;
                }
                return;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto& f : furnitures) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayFurnitures() {
        for (const auto& f : furnitures) {
            std::cout << "Furniture ID: " << f.id << ", Name: " << f.name << ", Price: " << f.price 
                      << ", Supplier: " << f.supplier.name << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addSupplier(1, "Supplier1", "123456789");
    ims.addSupplier(2, "Supplier2", "987654321");

    ims.addFurniture(101, "Chair", 49.99, 1);
    ims.addFurniture(102, "Table", 119.99, 2);

    ims.displaySuppliers();
    ims.displayFurnitures();

    ims.updateFurniture(101, "Armchair", 59.99, 1);
    ims.updateSupplier(2, "Best Supplier", "987654321");

    ims.displayFurnitures();
    ims.displaySuppliers();

    ims.deleteFurniture(102);
    ims.deleteSupplier(1);

    ims.displayFurnitures();
    ims.displaySuppliers();

    return 0;
}