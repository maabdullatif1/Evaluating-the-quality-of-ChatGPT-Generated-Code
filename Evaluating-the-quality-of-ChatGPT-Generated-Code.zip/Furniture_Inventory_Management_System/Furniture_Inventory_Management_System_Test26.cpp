#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInfo;
    Supplier(int i, std::string n, std::string c) : id(i), name(n), contactInfo(c) {}
};

class Furniture {
public:
    int id;
    std::string type;
    std::string material;
    int supplierId;
    Furniture(int i, std::string t, std::string m, int sId) : id(i), type(t), material(m), supplierId(sId) {}
};

class Inventory {
private:
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

    int findFurnitureById(int id) {
        for (size_t i = 0; i < furnitureList.size(); i++) {
            if (furnitureList[i].id == id) return i;
        }
        return -1;
    }

    int findSupplierById(int id) {
        for (size_t i = 0; i < supplierList.size(); i++) {
            if (supplierList[i].id == id) return i;
        }
        return -1;
    }

public:
    void addFurniture(int id, std::string type, std::string material, int supplierId) {
        furnitureList.push_back(Furniture(id, type, material, supplierId));
    }

    void deleteFurniture(int id) {
        int index = findFurnitureById(id);
        if (index != -1) {
            furnitureList.erase(furnitureList.begin() + index);
        }
    }

    void updateFurniture(int id, std::string newType, std::string newMaterial, int newSupplierId) {
        int index = findFurnitureById(id);
        if (index != -1) {
            furnitureList[index].type = newType;
            furnitureList[index].material = newMaterial;
            furnitureList[index].supplierId = newSupplierId;
        }
    }

    void addSupplier(int id, std::string name, std::string contactInfo) {
        supplierList.push_back(Supplier(id, name, contactInfo));
    }

    void deleteSupplier(int id) {
        int index = findSupplierById(id);
        if (index != -1) {
            supplierList.erase(supplierList.begin() + index);
        }
    }

    void updateSupplier(int id, std::string newName, std::string newContactInfo) {
        int index = findSupplierById(id);
        if (index != -1) {
            supplierList[index].name = newName;
            supplierList[index].contactInfo = newContactInfo;
        }
    }

    void displayFurnitures() {
        for (const auto& furniture : furnitureList) {
            std::cout << "ID: " << furniture.id << ", Type: " << furniture.type 
                      << ", Material: " << furniture.material 
                      << ", Supplier ID: " << furniture.supplierId << '\n';
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : supplierList) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name 
                      << ", Contact Info: " << supplier.contactInfo << '\n';
        }
    }

    void searchFurnitureById(int id) {
        int index = findFurnitureById(id);
        if (index != -1) {
            std::cout << "ID: " << furnitureList[index].id << ", Type: " << furnitureList[index].type 
                      << ", Material: " << furnitureList[index].material 
                      << ", Supplier ID: " << furnitureList[index].supplierId << '\n';
        } else {
            std::cout << "Furniture not found.\n";
        }
    }

    void searchSupplierById(int id) {
        int index = findSupplierById(id);
        if (index != -1) {
            std::cout << "ID: " << supplierList[index].id << ", Name: " << supplierList[index].name 
                      << ", Contact Info: " << supplierList[index].contactInfo << '\n';
        } else {
            std::cout << "Supplier not found.\n";
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addSupplier(1, "ABC Furnishings", "abc@contact.com");
    inventory.addFurniture(101, "Chair", "Wood", 1);
    inventory.displaySuppliers();
    inventory.displayFurnitures();
    inventory.searchFurnitureById(101);
    inventory.updateFurniture(101, "Table", "Metal", 1);
    inventory.displayFurnitures();
    inventory.deleteFurniture(101);
    inventory.displayFurnitures();
    return 0;
}