#include <iostream>
#include <vector>
#include <string>

class Furniture {
    int id;
    std::string name;
    double price;
    std::string supplier;

public:
    Furniture(int fid, const std::string &fname, double fprice, const std::string &fsupplier) 
        : id(fid), name(fname), price(fprice), supplier(fsupplier) {}

    int getId() const { return id; }
    const std::string &getName() const { return name; }
    double getPrice() const { return price; }
    const std::string &getSupplier() const { return supplier; }

    void setName(const std::string &fname) { name = fname; }
    void setPrice(double fprice) { price = fprice; }
    void setSupplier(const std::string &fsupplier) { supplier = fsupplier; }

    void display() const {
        std::cout << "ID: " << id
                  << ", Name: " << name
                  << ", Price: $" << price
                  << ", Supplier: " << supplier << std::endl;
    }
};

class Inventory {
    std::vector<Furniture> furnitures;

public:
    void addFurniture(int id, const std::string &name, double price, const std::string &supplier) {
        furnitures.emplace_back(id, name, price, supplier);
    }

    void deleteFurniture(int id) {
        furnitures.erase(std::remove_if(furnitures.begin(), furnitures.end(),
                                        [id](const Furniture &f) { return f.getId() == id; }),
                         furnitures.end());
    }

    void updateFurniture(int id, const std::string &name, double price, const std::string &supplier) {
        for (auto &f : furnitures) {
            if (f.getId() == id) {
                f.setName(name);
                f.setPrice(price);
                f.setSupplier(supplier);
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto &f : furnitures) {
            if (f.getId() == id) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayInventory() const {
        for (const auto &f : furnitures) {
            f.display();
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addFurniture(1, "Chair", 25.99, "Supplier A");
    inventory.addFurniture(2, "Table", 89.99, "Supplier B");
    
    std::cout << "Inventory:\n";
    inventory.displayInventory();

    std::cout << "\nUpdating Table...\n";
    inventory.updateFurniture(2, "Table", 79.99, "Supplier B");
    inventory.displayInventory();
    
    std::cout << "\nSearching for Table...\n";
    Furniture* item = inventory.searchFurniture(2);
    if(item) item->display();

    std::cout << "\nDeleting Chair...\n";
    inventory.deleteFurniture(1);
    inventory.displayInventory();

    return 0;
}