#include <iostream>
#include <string>
#include <vector>

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInfo;
    Supplier(int id, const std::string& name, const std::string& contactInfo) : id(id), name(name), contactInfo(contactInfo) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    int supplierId;
    Furniture(int id, const std::string& name, const std::string& type, int supplierId) : id(id), name(name), type(type), supplierId(supplierId) {}
};

class InventorySystem {
private:
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furnitureItems;

public:
    void addSupplier(int id, const std::string& name, const std::string& contactInfo) {
        suppliers.emplace_back(id, name, contactInfo);
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(), [id](Supplier& s) { return s.id == id; }), suppliers.end());
    }

    void updateSupplier(int id, const std::string& name, const std::string& contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                std::cout << "Supplier ID: " << supplier.id << " Name: " << supplier.name << " Contact: " << supplier.contactInfo << '\n';
                return;
            }
        }
        std::cout << "Supplier not found\n";
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << " Name: " << supplier.name << " Contact: " << supplier.contactInfo << '\n';
        }
    }

    void addFurniture(int id, const std::string& name, const std::string& type, int supplierId) {
        furnitureItems.emplace_back(id, name, type, supplierId);
    }

    void deleteFurniture(int id) {
        furnitureItems.erase(std::remove_if(furnitureItems.begin(), furnitureItems.end(), [id](Furniture& f) { return f.id == id; }), furnitureItems.end());
    }

    void updateFurniture(int id, const std::string& name, const std::string& type, int supplierId) {
        for (auto& furniture : furnitureItems) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.supplierId = supplierId;
                break;
            }
        }
    }

    void searchFurniture(int id) {
        for (const auto& furniture : furnitureItems) {
            if (furniture.id == id) {
                std::cout << "Furniture ID: " << furniture.id << " Name: " << furniture.name << " Type: " << furniture.type << " Supplier ID: " << furniture.supplierId << '\n';
                return;
            }
        }
        std::cout << "Furniture not found\n";
    }

    void displayFurniture() {
        for (const auto& furniture : furnitureItems) {
            std::cout << "Furniture ID: " << furniture.id << " Name: " << furniture.name << " Type: " << furniture.type << " Supplier ID: " << furniture.supplierId << '\n';
        }
    }
};

int main() {
    InventorySystem system;
    system.addSupplier(1, "Supplier One", "123-4567");
    system.addFurniture(101, "Chair", "Seating", 1);
    system.displaySuppliers();
    system.displayFurniture();
    system.updateSupplier(1, "Updated Supplier", "765-4321");
    system.updateFurniture(101, "Updated Chair", "Office Seating", 1);
    system.searchSupplier(1);
    system.searchFurniture(101);
    system.deleteSupplier(1);
    system.deleteFurniture(101);
    system.displaySuppliers();
    system.displayFurniture();
    return 0;
}