#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, const std::string& name, const std::string& contact)
        : id(id), name(name), contact(contact) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    int quantity;
    Supplier supplier;

    Furniture(int id, const std::string& name, const std::string& type, int quantity, const Supplier& supplier)
        : id(id), name(name), type(type), quantity(quantity), supplier(supplier) {}
};

class InventorySystem {
    std::vector<Furniture> furnitureInventory;
    std::vector<Supplier> supplierList;

public:
    void addSupplier(int id, const std::string& name, const std::string& contact) {
        supplierList.push_back(Supplier(id, name, contact));
    }

    Supplier* findSupplier(int id) {
        for(auto &supplier : supplierList) {
            if(supplier.id == id) return &supplier;
        }
        return nullptr;
    }

    void addFurniture(int id, const std::string& name, const std::string& type, int quantity, int supplierId) {
        Supplier* supplier = findSupplier(supplierId);
        if(supplier) {
            furnitureInventory.push_back(Furniture(id, name, type, quantity, *supplier));
        }
    }

    void deleteFurniture(int id) {
        for(auto it = furnitureInventory.begin(); it != furnitureInventory.end(); ++it) {
            if(it->id == id) {
                furnitureInventory.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, const std::string& name, const std::string& type, int quantity, int supplierId) {
        for(auto &furniture : furnitureInventory) {
            if(furniture.id == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.quantity = quantity;
                Supplier* supplier = findSupplier(supplierId);
                if(supplier) {
                    furniture.supplier = *supplier;
                }
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for(auto &furniture : furnitureInventory) {
            if(furniture.id == id) return &furniture;
        }
        return nullptr;
    }

    void displayFurnitures() {
        for(const auto &furniture : furnitureInventory) {
            std::cout << "ID: " << furniture.id << ", Name: " << furniture.name
                      << ", Type: " << furniture.type << ", Quantity: " << furniture.quantity
                      << ", Supplier: " << furniture.supplier.name << "\n";
        }
    }

    void displaySuppliers() {
        for(const auto &supplier : supplierList) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventorySystem system;
    system.addSupplier(1, "Supplier A", "123-456-7890");
    system.addSupplier(2, "Supplier B", "098-765-4321");
    system.addFurniture(1, "Chair", "Office", 50, 1);
    system.addFurniture(2, "Table", "Dining", 20, 2);
    system.displayFurnitures();
    system.displaySuppliers();
    system.updateFurniture(1, "Chair", "Office", 60, 1);
    system.displayFurnitures();
    system.deleteFurniture(2);
    system.displayFurnitures();
    return 0;
}