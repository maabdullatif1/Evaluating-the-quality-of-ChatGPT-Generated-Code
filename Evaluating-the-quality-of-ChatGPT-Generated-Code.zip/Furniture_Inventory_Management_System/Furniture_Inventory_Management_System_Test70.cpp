#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    std::string name;
    std::string contact;
    Supplier(std::string n, std::string c) : name(n), contact(c) {}
};

class Furniture {
public:
    std::string id;
    std::string name;
    std::string type;
    double price;
    int quantity;
    Supplier supplier;
    Furniture(std::string i, std::string n, std::string t, double p, int q, Supplier s) 
        : id(i), name(n), type(t), price(p), quantity(q), supplier(s) {}
};

class InventorySystem {
private:
    std::vector<Furniture> furnitureList;
public:
    void addFurniture(Furniture f) {
        furnitureList.push_back(f);
    }

    void deleteFurniture(std::string id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(std::string id, std::string name, std::string type, double price, int quantity, Supplier supplier) {
        for (auto &f : furnitureList) {
            if (f.id == id) {
                f.name = name;
                f.type = type;
                f.price = price;
                f.quantity = quantity;
                f.supplier = supplier;
                break;
            }
        }
    }

    Furniture* searchFurniture(std::string id) {
        for (auto &f : furnitureList) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayFurniture() {
        for (const auto &f : furnitureList) {
            std::cout << "ID: " << f.id
                      << ", Name: " << f.name
                      << ", Type: " << f.type
                      << ", Price: " << f.price 
                      << ", Quantity: " << f.quantity
                      << ", Supplier Name: " << f.supplier.name
                      << ", Supplier Contact: " << f.supplier.contact 
                      << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    Supplier sup1("Supplier1", "123-456-7890");
    system.addFurniture(Furniture("1", "Chair", "Seating", 49.99, 100, sup1));
    Supplier sup2("Supplier2", "987-654-3210");
    system.addFurniture(Furniture("2", "Table", "Dining", 149.99, 200, sup2));
    
    system.displayFurniture();

    system.deleteFurniture("1");
    system.displayFurniture();

    Supplier sup3("Supplier3", "111-222-3333");
    system.updateFurniture("2", "Updated Table", "Dining", 199.99, 150, sup3);
    system.displayFurniture();

    Furniture* f = system.searchFurniture("2");
    if (f) {
        std::cout << "Found furniture: " << f->name << std::endl;
    } else {
        std::cout << "Furniture not found." << std::endl;
    }

    return 0;
}