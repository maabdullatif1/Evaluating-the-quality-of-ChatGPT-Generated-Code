#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Supplier {
    int id;
    string name;
    string contact;
};

struct Furniture {
    int id;
    string name;
    string type;
    int supplierId;
    int quantity;
    double price;
};

class InventoryManagement {
private:
    vector<Furniture> furnitureList;
    vector<Supplier> supplierList;
    int furnitureIdCounter;
    int supplierIdCounter;

    Furniture* findFurnitureById(int id) {
        for (auto &furniture : furnitureList) {
            if (furniture.id == id) {
                return &furniture;
            }
        }
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for (auto &supplier : supplierList) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

public:
    InventoryManagement() : furnitureIdCounter(0), supplierIdCounter(0) {}

    void addSupplier(const string& name, const string& contact) {
        supplierList.push_back({++supplierIdCounter, name, contact});
    }

    void deleteSupplier(int id) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->id == id) {
                supplierList.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const string& name, const string& contact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void searchSupplier(int id) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            cout << "Supplier ID: " << supplier->id << ", Name: " << supplier->name << ", Contact: " << supplier->contact << "\n";
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : supplierList) {
            cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << "\n";
        }
    }

    void addFurniture(const string& name, const string& type, int supplierId, int quantity, double price) {
        if (findSupplierById(supplierId)) {
            furnitureList.push_back({++furnitureIdCounter, name, type, supplierId, quantity, price});
        }
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, const string& name, const string& type, int supplierId, int quantity, double price) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture && findSupplierById(supplierId)) {
            furniture->name = name;
            furniture->type = type;
            furniture->supplierId = supplierId;
            furniture->quantity = quantity;
            furniture->price = price;
        }
    }

    void searchFurniture(int id) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture) {
            cout << "Furniture ID: " << furniture->id << ", Name: " << furniture->name << ", Type: " << furniture->type 
                 << ", Supplier ID: " << furniture->supplierId << ", Quantity: " << furniture->quantity 
                 << ", Price: " << furniture->price << "\n";
        }
    }

    void displayFurniture() {
        for (const auto& furniture : furnitureList) {
            cout << "Furniture ID: " << furniture.id << ", Name: " << furniture.name << ", Type: " << furniture.type 
                 << ", Supplier ID: " << furniture.supplierId << ", Quantity: " << furniture.quantity 
                 << ", Price: " << furniture.price << "\n";
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addSupplier("Supplier A", "123456789");
    inventory.addSupplier("Supplier B", "987654321");
    
    inventory.displaySuppliers();
    
    inventory.addFurniture("Chair", "Seating", 1, 50, 29.99);
    inventory.addFurniture("Table", "Dining", 2, 20, 199.99);
    
    inventory.displayFurniture();
    
    return 0;
}