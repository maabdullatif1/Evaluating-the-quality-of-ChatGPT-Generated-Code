#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInfo;

    Supplier(int aid, const std::string& aname, const std::string& acontactInfo)
        : id(aid), name(aname), contactInfo(acontactInfo) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    int quantity;
    int supplierId;

    Furniture(int aid, const std::string& aname, const std::string& atype, int aquantity, int asupplierId)
        : id(aid), name(aname), type(atype), quantity(aquantity), supplierId(asupplierId) {}
};

class InventorySystem {
private:
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furnitureItems;
    int nextSupplierId = 1;
    int nextFurnitureId = 1;

public:
    void addSupplier(const std::string& name, const std::string& contactInfo) {
        suppliers.push_back(Supplier(nextSupplierId++, name, contactInfo));
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(),
                       [id](Supplier& supplier) { return supplier.id == id; }),
                       suppliers.end());
    }

    void updateSupplier(int id, const std::string& name, const std::string& contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) return &supplier;
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contactInfo << std::endl;
        }
    }

    void addFurniture(const std::string& name, const std::string& type, int quantity, int supplierId) {
        if (searchSupplier(supplierId) != nullptr) {
            furnitureItems.push_back(Furniture(nextFurnitureId++, name, type, quantity, supplierId));
        }
    }

    void deleteFurniture(int id) {
        furnitureItems.erase(std::remove_if(furnitureItems.begin(), furnitureItems.end(),
                            [id](Furniture& furniture) { return furniture.id == id; }),
                            furnitureItems.end());
    }

    void updateFurniture(int id, const std::string& name, const std::string& type, int quantity, int supplierId) {
        if (searchSupplier(supplierId) != nullptr) {
            for (auto& furniture : furnitureItems) {
                if (furniture.id == id) {
                    furniture.name = name;
                    furniture.type = type;
                    furniture.quantity = quantity;
                    furniture.supplierId = supplierId;
                    break;
                }
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto& furniture : furnitureItems) {
            if (furniture.id == id) return &furniture;
        }
        return nullptr;
    }

    void displayFurniture() {
        for (const auto& furniture : furnitureItems) {
            std::cout << "ID: " << furniture.id << ", Name: " << furniture.name
                      << ", Type: " << furniture.type << ", Quantity: " << furniture.quantity
                      << ", Supplier ID: " << furniture.supplierId << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addSupplier("John's Supplies", "john@supplies.com");
    system.addSupplier("Smith Furnishings", "smith@furnishings.com");

    system.displaySuppliers();

    system.addFurniture("Chair", "Seating", 10, 1);
    system.addFurniture("Table", "Dining", 5, 2);

    system.displayFurniture();

    return 0;
}