#include <iostream>
#include <vector>
#include <string>

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

struct Furniture {
    int id;
    std::string name;
    std::string type;
    double price;
    int supplierId;
};

class InventoryManager {
private:
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;
    int nextFurnitureId = 1;
    int nextSupplierId = 1;

public:
    void addSupplier(const std::string &name, const std::string &contact) {
        Supplier supplier = {nextSupplierId++, name, contact};
        supplierList.push_back(supplier);
    }

    void addFurniture(const std::string &name, const std::string &type, double price, int supplierId) {
        Furniture furniture = {nextFurnitureId++, name, type, price, supplierId};
        furnitureList.push_back(furniture);
    }

    void deleteSupplier(int supplierId) {
        supplierList.erase(std::remove_if(supplierList.begin(), supplierList.end(),
                                          [supplierId](Supplier s) { return s.id == supplierId; }),
                           supplierList.end());
    }

    void deleteFurniture(int furnitureId) {
        furnitureList.erase(std::remove_if(furnitureList.begin(), furnitureList.end(),
                                           [furnitureId](Furniture f) { return f.id == furnitureId; }),
                            furnitureList.end());
    }

    void updateFurniture(int furnitureId, const std::string &name, const std::string &type, double price, int supplierId) {
        for (auto &furniture : furnitureList) {
            if (furniture.id == furnitureId) {
                furniture.name = name;
                furniture.type = type;
                furniture.price = price;
                furniture.supplierId = supplierId;
            }
        }
    }

    Furniture* searchFurniture(int furnitureId) {
        for (auto &furniture : furnitureList) {
            if (furniture.id == furnitureId)
                return &furniture;
        }
        return nullptr;
    }

    Supplier* searchSupplier(int supplierId) {
        for (auto &supplier : supplierList) {
            if (supplier.id == supplierId)
                return &supplier;
        }
        return nullptr;
    }

    void displayFurniture() const {
        for (const auto &furniture : furnitureList) {
            std::cout << "Furniture ID: " << furniture.id << "\n"
                      << "Name: " << furniture.name << "\n"
                      << "Type: " << furniture.type << "\n"
                      << "Price: " << furniture.price << "\n"
                      << "Supplier ID: " << furniture.supplierId << "\n\n";
        }
    }

    void displaySuppliers() const {
        for (const auto &supplier : supplierList) {
            std::cout << "Supplier ID: " << supplier.id << "\n"
                      << "Name: " << supplier.name << "\n"
                      << "Contact: " << supplier.contact << "\n\n";
        }
    }
};

int main() {
    InventoryManager manager;
    manager.addSupplier("Supplier 1", "123-456-7890");
    manager.addSupplier("Supplier 2", "987-654-3210");
    manager.addFurniture("Chair", "Seating", 49.99, 1);
    manager.addFurniture("Table", "Dining", 149.99, 2);
    manager.displaySuppliers();
    manager.displayFurniture();
    manager.updateFurniture(1, "Armchair", "Seating", 59.99, 1);
    manager.deleteFurniture(2);
    manager.displayFurniture();
    return 0;
}