#include <iostream>
#include <string>
#include <vector>

class Furniture {
public:
    std::string name;
    std::string type;
    int quantity;
    double price;
    
    Furniture(std::string n, std::string t, int q, double p) 
    : name(n), type(t), quantity(q), price(p) {}
};

class Supplier {
public:
    std::string name;
    std::string contact;
    
    Supplier(std::string n, std::string c) 
    : name(n), contact(c) {}
};

class Inventory {
private:
    std::vector<Furniture> furnitures;
    std::vector<Supplier> suppliers;
    
    int findFurniture(const std::string &name) {
        for (int i = 0; i < furnitures.size(); ++i) {
            if (furnitures[i].name == name)
                return i;
        }
        return -1;
    }
    
    int findSupplier(const std::string &name) {
        for (int i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].name == name)
                return i;
        }
        return -1;
    }

public:
    void addFurniture(const std::string &name, const std::string &type, int quantity, double price) {
        if (findFurniture(name) == -1)
            furnitures.push_back(Furniture(name, type, quantity, price));
    }
    
    void deleteFurniture(const std::string &name) {
        int index = findFurniture(name);
        if (index != -1)
            furnitures.erase(furnitures.begin() + index);
    }

    void updateFurniture(const std::string &name, const std::string &type, int quantity, double price) {
        int index = findFurniture(name);
        if (index != -1)
            furnitures[index] = Furniture(name, type, quantity, price);
    }
    
    void addSupplier(const std::string &name, const std::string &contact) {
        if (findSupplier(name) == -1)
            suppliers.push_back(Supplier(name, contact));
    }
    
    void deleteSupplier(const std::string &name) {
        int index = findSupplier(name);
        if (index != -1)
            suppliers.erase(suppliers.begin() + index);
    }
    
    void searchFurniture(const std::string &name) {
        int index = findFurniture(name);
        if (index != -1)
            std::cout << "Furniture found: " << furnitures[index].name 
                      << ", Type: " << furnitures[index].type 
                      << ", Quantity: " << furnitures[index].quantity 
                      << ", Price: $" << furnitures[index].price << std::endl;
        else
            std::cout << "Furniture not found." << std::endl;
    }
    
    void searchSupplier(const std::string &name) {
        int index = findSupplier(name);
        if (index != -1)
            std::cout << "Supplier found: " << suppliers[index].name 
                      << ", Contact: " << suppliers[index].contact << std::endl;
        else
            std::cout << "Supplier not found." << std::endl;
    }
    
    void displayFurnitures() {
        std::cout << "Furniture List:" << std::endl;
        for (const auto &furniture : furnitures)
            std::cout << "Name: " << furniture.name 
                      << ", Type: " << furniture.type 
                      << ", Quantity: " << furniture.quantity 
                      << ", Price: $" << furniture.price << std::endl;
    }
    
    void displaySuppliers() {
        std::cout << "Supplier List:" << std::endl;
        for (const auto &supplier : suppliers)
            std::cout << "Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << std::endl;
    }
};

int main() {
    Inventory inventory;
    
    inventory.addFurniture("Chair", "Office", 10, 79.99);
    inventory.addFurniture("Desk", "Home", 5, 159.99);
    
    inventory.addSupplier("ABC Corp", "123-456-7890");
    inventory.addSupplier("XYZ Ltd", "987-654-3210");
    
    inventory.displayFurnitures();
    inventory.displaySuppliers();
    
    inventory.searchFurniture("Chair");
    inventory.searchSupplier("XYZ Ltd");
    
    inventory.updateFurniture("Desk", "Home", 12, 139.99);
    inventory.displayFurnitures();
    
    inventory.deleteFurniture("Chair");
    inventory.displayFurnitures();
    
    inventory.deleteSupplier("XYZ Ltd");
    inventory.displaySuppliers();
    
    return 0;
}