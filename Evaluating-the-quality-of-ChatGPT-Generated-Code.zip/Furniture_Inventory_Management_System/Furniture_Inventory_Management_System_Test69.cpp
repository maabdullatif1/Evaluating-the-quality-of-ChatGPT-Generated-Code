#include <iostream>
#include <string>
#include <vector>

struct Supplier {
    int id;
    std::string name;
    std::string contactInfo;
};

struct Furniture {
    int id;
    std::string name;
    std::string type;
    int supplierId;
    int quantity;
};

class InventorySystem {
private:
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furnitureList;
    int nextSupplierId;
    int nextFurnitureId;

    Supplier* findSupplierById(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) return &supplier;
        }
        return nullptr;
    }

    Furniture* findFurnitureById(int id) {
        for (auto& furniture : furnitureList) {
            if (furniture.id == id) return &furniture;
        }
        return nullptr;
    }

public:
    InventorySystem() : nextSupplierId(1), nextFurnitureId(1) {}

    void addSupplier(const std::string& name, const std::string& contactInfo) {
        suppliers.push_back({nextSupplierId++, name, contactInfo});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contactInfo) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contactInfo = contactInfo;
        }
    }

    void addFurniture(const std::string& name, const std::string& type, int supplierId, int quantity) {
        if (findSupplierById(supplierId)) {
            furnitureList.push_back({nextFurnitureId++, name, type, supplierId, quantity});
        }
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, const std::string& name, const std::string& type, int supplierId, int quantity) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture && findSupplierById(supplierId)) {
            furniture->name = name;
            furniture->type = type;
            furniture->supplierId = supplierId;
            furniture->quantity = quantity;
        }
    }

    Furniture* searchFurnitureByName(const std::string& name) {
        for (auto& furniture : furnitureList) {
            if (furniture.name == name) return &furniture;
        }
        return nullptr;
    }

    Supplier* searchSupplierByName(const std::string& name) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) return &supplier;
        }
        return nullptr;
    }

    void displayFurniture() {
        for (const auto& furniture : furnitureList) {
            std::cout << "ID: " << furniture.id << ", Name: " << furniture.name
                      << ", Type: " << furniture.type << ", Supplier ID: " << furniture.supplierId
                      << ", Quantity: " << furniture.quantity << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact Info: " << supplier.contactInfo << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addSupplier("Supplier1", "contact1@example.com");
    system.addFurniture("Chair", "Seating", 1, 10);
    system.displaySuppliers();
    system.displayFurniture();
    return 0;
}