#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Supplier {
public:
    string id;
    string name;
    string contact;

    Supplier(string id, string name, string contact)
        : id(id), name(name), contact(contact) {}
};

class Furniture {
public:
    string id;
    string name;
    string supplierId;
    int quantity;
    double price;

    Furniture(string id, string name, string supplierId, int quantity, double price)
        : id(id), name(name), supplierId(supplierId), quantity(quantity), price(price) {}
};

class InventorySystem {
private:
    vector<Furniture> furnitureList;
    vector<Supplier> supplierList;

public:
    void addSupplier(const string& id, const string& name, const string& contact) {
        supplierList.push_back(Supplier(id, name, contact));
    }

    void addFurniture(const string& id, const string& name, const string& supplierId, int quantity, double price) {
        furnitureList.push_back(Furniture(id, name, supplierId, quantity, price));
    }

    void deleteSupplier(const string& id) {
        supplierList.erase(remove_if(supplierList.begin(), supplierList.end(),
            [&](const Supplier& supplier) { return supplier.id == id; }), supplierList.end());
    }

    void deleteFurniture(const string& id) {
        furnitureList.erase(remove_if(furnitureList.begin(), furnitureList.end(),
            [&](const Furniture& furniture) { return furniture.id == id; }), furnitureList.end());
    }

    void updateSupplier(const string& id, const string& name, const string& contact) {
        for(auto& supplier : supplierList) {
            if(supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void updateFurniture(const string& id, const string& name, const string& supplierId, int quantity, double price) {
        for(auto& furniture : furnitureList) {
            if(furniture.id == id) {
                furniture.name = name;
                furniture.supplierId = supplierId;
                furniture.quantity = quantity;
                furniture.price = price;
                break;
            }
        }
    }

    Supplier* searchSupplier(const string& id) {
        for(auto& supplier : supplierList) {
            if(supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    Furniture* searchFurniture(const string& id) {
        for(auto& furniture : furnitureList) {
            if(furniture.id == id) {
                return &furniture;
            }
        }
        return nullptr;
    }

    void displaySuppliers() const {
        for(const auto& supplier : supplierList) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }

    void displayFurniture() const {
        for(const auto& furniture : furnitureList) {
            cout << "ID: " << furniture.id << ", Name: " << furniture.name << ", SupplierID: " << furniture.supplierId 
                 << ", Quantity: " << furniture.quantity << ", Price: " << furniture.price << endl;
        }
    }
};

int main() {
    InventorySystem system;

    system.addSupplier("S001", "Supplier1", "123-456-7890");
    system.addSupplier("S002", "Supplier2", "987-654-3210");

    system.addFurniture("F001", "Chair", "S001", 10, 50.0);
    system.addFurniture("F002", "Table", "S002", 5, 200.0);

    system.displaySuppliers();
    system.displayFurniture();

    Supplier* supplier = system.searchSupplier("S001");
    if (supplier) {
        cout << "Found Supplier: " << supplier->name << endl;
    }

    Furniture* furniture = system.searchFurniture("F001");
    if (furniture) {
        cout << "Found Furniture: " << furniture->name << endl;
    }

    system.updateSupplier("S001", "New Supplier1", "111-222-3333");
    system.updateFurniture("F001", "New Chair", "S001", 20, 45.0);

    system.displaySuppliers();
    system.displayFurniture();

    system.deleteSupplier("S002");
    system.deleteFurniture("F002");

    system.displaySuppliers();
    system.displayFurniture();

    return 0;
}