#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Furniture {
    int id;
    string name;
    string type;
    int supplierId;
    int quantity;
};

struct Supplier {
    int id;
    string name;
    string contactInfo;
};

class InventoryManagement {
    vector<Furniture> furnitureList;
    vector<Supplier> supplierList;

    Furniture* findFurniture(int id) {
        for (auto& item : furnitureList)
            if (item.id == id)
                return &item;
        return nullptr;
    }

    Supplier* findSupplier(int id) {
        for (auto& supplier : supplierList)
            if (supplier.id == id)
                return &supplier;
        return nullptr;
    }

public:
    void addFurniture(int id, string name, string type, int supplierId, int quantity) {
        if (!findFurniture(id))
            furnitureList.push_back({id, name, type, supplierId, quantity});
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                return;
            }
        }
    }

    void updateFurniture(int id, string name, string type, int supplierId, int quantity) {
        Furniture* item = findFurniture(id);
        if (item) {
            item->name = name;
            item->type = type;
            item->supplierId = supplierId;
            item->quantity = quantity;
        }
    }

    Furniture* searchFurniture(int id) {
        return findFurniture(id);
    }

    void displayFurniture() {
        for (auto& item : furnitureList)
            cout << "ID: " << item.id << ", Name: " << item.name << ", Type: " << item.type 
                 << ", Supplier ID: " << item.supplierId << ", Quantity: " << item.quantity << endl;
    }

    void addSupplier(int id, string name, string contactInfo) {
        if (!findSupplier(id))
            supplierList.push_back({id, name, contactInfo});
    }

    void deleteSupplier(int id) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->id == id) {
                supplierList.erase(it);
                return;
            }
        }
    }

    void updateSupplier(int id, string name, string contactInfo) {
        Supplier* supplier = findSupplier(id);
        if (supplier) {
            supplier->name = name;
            supplier->contactInfo = contactInfo;
        }
    }

    Supplier* searchSupplier(int id) {
        return findSupplier(id);
    }

    void displaySuppliers() {
        for (auto& supplier : supplierList)
            cout << "ID: " << supplier.id << ", Name: " << supplier.name  
                 << ", Contact Info: " << supplier.contactInfo << endl;
    }
};

int main() {
    InventoryManagement system;
    system.addSupplier(1, "Supplier A", "123-456-7890");
    system.addFurniture(101, "Chair", "Office", 1, 50);
    system.displayFurniture();
    system.displaySuppliers();
    return 0;
}