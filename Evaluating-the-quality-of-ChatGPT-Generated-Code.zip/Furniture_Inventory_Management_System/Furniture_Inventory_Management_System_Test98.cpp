#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int i, std::string n, std::string c) : id(i), name(n), contact(c) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    double price;
    int supplierId;

    Furniture(int i, std::string n, std::string t, double p, int sId) 
        : id(i), name(n), type(t), price(p), supplierId(sId) {}
};

class InventoryManager {
private:
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;
    
public:
    void addSupplier(int id, std::string name, std::string contact) {
        supplierList.push_back(Supplier(id, name, contact));
    }
    
    void addFurniture(int id, std::string name, std::string type, double price, int supplierId) {
        furnitureList.push_back(Furniture(id, name, type, price, supplierId));
    }
    
    void deleteSupplier(int id) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->id == id) {
                supplierList.erase(it);
                break;
            }
        }
    }
    
    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }
    
    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto &sup : supplierList) {
            if (sup.id == id) {
                sup.name = name;
                sup.contact = contact;
                break;
            }
        }
    }
    
    void updateFurniture(int id, std::string name, std::string type, double price, int supplierId) {
        for (auto &furn : furnitureList) {
            if (furn.id == id) {
                furn.name = name;
                furn.type = type;
                furn.price = price;
                furn.supplierId = supplierId;
                break;
            }
        }
    }
    
    void displaySuppliers() {
        for (const auto &sup : supplierList) {
            std::cout << "Supplier ID: " << sup.id << ", Name: " << sup.name << ", Contact: " << sup.contact << "\n";
        }
    }
    
    void displayFurniture() {
        for (const auto &furn : furnitureList) {
            std::cout << "Furniture ID: " << furn.id << ", Name: " << furn.name << ", Type: " << furn.type 
                      << ", Price: " << furn.price << ", Supplier ID: " << furn.supplierId << "\n";
        }
    }
    
    void searchSupplier(int id) {
        for (const auto &sup : supplierList) {
            if (sup.id == id) {
                std::cout << "Found Supplier -> ID: " << sup.id << ", Name: " << sup.name << ", Contact: " << sup.contact << "\n";
                return;
            }
        }
        std::cout << "Supplier not found.\n";
    }
    
    void searchFurniture(int id) {
        for (const auto &furn : furnitureList) {
            if (furn.id == id) {
                std::cout << "Found Furniture -> ID: " << furn.id << ", Name: " << furn.name << ", Type: " << furn.type 
                          << ", Price: " << furn.price << ", Supplier ID: " << furn.supplierId << "\n";
                return;
            }
        }
        std::cout << "Furniture not found.\n";
    }
};

int main() {
    InventoryManager manager;
    manager.addSupplier(1, "ABC Furnishings", "123-456-7890");
    manager.addSupplier(2, "XYZ Supplies", "098-765-4321");
    manager.addFurniture(101, "Sofa", "Living Room", 499.99, 1);
    manager.addFurniture(102, "Dining Table", "Dining Room", 299.99, 2);
    manager.displaySuppliers();
    manager.displayFurniture();
    manager.searchSupplier(1);
    manager.searchFurniture(101);
    manager.updateSupplier(1, "ABC Furnishings Ltd", "123-456-7891");
    manager.updateFurniture(101, "Sofa Deluxe", "Living Room", 599.99, 1);
    manager.displaySuppliers();
    manager.displayFurniture();
    manager.deleteSupplier(2);
    manager.deleteFurniture(102);
    manager.displaySuppliers();
    manager.displayFurniture();
}