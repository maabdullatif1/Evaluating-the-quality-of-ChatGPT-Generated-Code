#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    int id;
    std::string name;
    int quantity;

    Furniture(int i, std::string n, int q) : id(i), name(n), quantity(q) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int i, std::string n, std::string c) : id(i), name(n), contact(c) {}
};

class InventoryManagement {
private:
    std::vector<Furniture> furnitures;
    std::vector<Supplier> suppliers;

public:
    void addFurniture(int id, std::string name, int quantity) {
        furnitures.push_back(Furniture(id, name, quantity));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->id == id) {
                furnitures.erase(it);
                return;
            }
        }
    }

    void updateFurniture(int id, std::string name, int quantity) {
        for (auto& furniture : furnitures) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.quantity = quantity;
                return;
            }
        }
    }

    void searchFurniture(int id) {
        for (const auto& furniture : furnitures) {
            if (furniture.id == id) {
                std::cout << "Furniture ID: " << furniture.id
                          << ", Name: " << furniture.name
                          << ", Quantity: " << furniture.quantity << std::endl;
                return;
            }
        }
        std::cout << "Furniture not found." << std::endl;
    }

    void displayFurnitures() {
        for (const auto& furniture : furnitures) {
            std::cout << "Furniture ID: " << furniture.id
                      << ", Name: " << furniture.name
                      << ", Quantity: " << furniture.quantity << std::endl;
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                return;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                return;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                std::cout << "Supplier ID: " << supplier.id
                          << ", Name: " << supplier.name
                          << ", Contact: " << supplier.contact << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found." << std::endl;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id
                      << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagement system;
    
    system.addFurniture(1, "Chair", 50);
    system.addFurniture(2, "Table", 20);
    
    system.displayFurnitures();
    system.searchFurniture(1);
    system.updateFurniture(1, "Armchair", 60);
    system.displayFurnitures();
    system.deleteFurniture(2);
    system.displayFurnitures();
    
    system.addSupplier(1, "ABC Suppliers", "123456789");
    system.addSupplier(2, "XYZ Distributors", "987654321");
    
    system.displaySuppliers();
    system.searchSupplier(1);
    system.updateSupplier(1, "New ABC Suppliers", "111111111");
    system.displaySuppliers();
    system.deleteSupplier(2);
    system.displaySuppliers();

    return 0;
}