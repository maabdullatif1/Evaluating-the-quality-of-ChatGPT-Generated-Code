#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Furniture {
    int id;
    string name;
    string type;
    double price;
    int supplierId;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

vector<Furniture> furnitures;
vector<Supplier> suppliers;

void addFurniture() {
    Furniture f;
    cout << "Enter Furniture ID: ";
    cin >> f.id;
    cout << "Enter Furniture Name: ";
    cin >> f.name;
    cout << "Enter Furniture Type: ";
    cin >> f.type;
    cout << "Enter Furniture Price: ";
    cin >> f.price;
    cout << "Enter Supplier ID: ";
    cin >> f.supplierId;
    furnitures.push_back(f);
}

void deleteFurniture() {
    int id;
    cout << "Enter Furniture ID to delete: ";
    cin >> id;
    for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
        if (it->id == id) {
            furnitures.erase(it);
            cout << "Furniture deleted.\n";
            return;
        }
    }
    cout << "Furniture not found.\n";
}

void updateFurniture() {
    int id;
    cout << "Enter Furniture ID to update: ";
    cin >> id;
    for (auto& f : furnitures) {
        if (f.id == id) {
            cout << "Enter new Furniture Name: ";
            cin >> f.name;
            cout << "Enter new Furniture Type: ";
            cin >> f.type;
            cout << "Enter new Furniture Price: ";
            cin >> f.price;
            cout << "Enter new Supplier ID: ";
            cin >> f.supplierId;
            cout << "Furniture updated.\n";
            return;
        }
    }
    cout << "Furniture not found.\n";
}

void searchFurniture() {
    int id;
    cout << "Enter Furniture ID to search: ";
    cin >> id;
    for (const auto& f : furnitures) {
        if (f.id == id) {
            cout << "ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type
                 << ", Price: " << f.price << ", Supplier ID: " << f.supplierId << "\n";
            return;
        }
    }
    cout << "Furniture not found.\n";
}

void displayFurnitures() {
    for (const auto& f : furnitures) {
        cout << "ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type
             << ", Price: " << f.price << ", Supplier ID: " << f.supplierId << "\n";
    }
}

void addSupplier() {
    Supplier s;
    cout << "Enter Supplier ID: ";
    cin >> s.id;
    cout << "Enter Supplier Name: ";
    cin >> s.name;
    cout << "Enter Supplier Contact: ";
    cin >> s.contact;
    suppliers.push_back(s);
}

void deleteSupplier() {
    int id;
    cout << "Enter Supplier ID to delete: ";
    cin >> id;
    for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
        if (it->id == id) {
            suppliers.erase(it);
            cout << "Supplier deleted.\n";
            return;
        }
    }
    cout << "Supplier not found.\n";
}

void updateSupplier() {
    int id;
    cout << "Enter Supplier ID to update: ";
    cin >> id;
    for (auto& s : suppliers) {
        if (s.id == id) {
            cout << "Enter new Supplier Name: ";
            cin >> s.name;
            cout << "Enter new Supplier Contact: ";
            cin >> s.contact;
            cout << "Supplier updated.\n";
            return;
        }
    }
    cout << "Supplier not found.\n";
}

void searchSupplier() {
    int id;
    cout << "Enter Supplier ID to search: ";
    cin >> id;
    for (const auto& s : suppliers) {
        if (s.id == id) {
            cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << "\n";
            return;
        }
    }
    cout << "Supplier not found.\n";
}

void displaySuppliers() {
    for (const auto& s : suppliers) {
        cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << "\n";
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Furniture\n2. Delete Furniture\n3. Update Furniture\n4. Search Furniture\n5. Display Furnitures\n";
        cout << "6. Add Supplier\n7. Delete Supplier\n8. Update Supplier\n9. Search Supplier\n10. Display Suppliers\n0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addFurniture(); break;
            case 2: deleteFurniture(); break;
            case 3: updateFurniture(); break;
            case 4: searchFurniture(); break;
            case 5: displayFurnitures(); break;
            case 6: addSupplier(); break;
            case 7: deleteSupplier(); break;
            case 8: updateSupplier(); break;
            case 9: searchSupplier(); break;
            case 10: displaySuppliers(); break;
        }
    } while (choice != 0);
    return 0;
}