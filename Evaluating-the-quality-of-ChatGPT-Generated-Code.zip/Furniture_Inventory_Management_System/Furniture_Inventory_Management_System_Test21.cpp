#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    int id;
    std::string name;
    int quantity;
    double price;

    Furniture(int id, std::string name, int quantity, double price) : id(id), name(name), quantity(quantity), price(price) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, std::string name, std::string contact) : id(id), name(name), contact(contact) {}
};

class InventoryManagementSystem {
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

public:
    void addFurniture(int id, std::string name, int quantity, double price) {
        furnitureList.push_back(Furniture(id, name, quantity, price));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, std::string name, int quantity, double price) {
        for (auto &f : furnitureList) {
            if (f.id == id) {
                f.name = name;
                f.quantity = quantity;
                f.price = price;
                break;
            }
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        supplierList.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->id == id) {
                supplierList.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto &s : supplierList) {
            if (s.id == id) {
                s.name = name;
                s.contact = contact;
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto &f : furnitureList) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }

    Supplier* searchSupplier(int id) {
        for (auto &s : supplierList) {
            if (s.id == id) {
                return &s;
            }
        }
        return nullptr;
    }

    void displayFurniture() {
        for (const auto &f : furnitureList) {
            std::cout << "ID: " << f.id << ", Name: " << f.name 
                      << ", Quantity: " << f.quantity << ", Price: " << f.price << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto &s : supplierList) {
            std::cout << "ID: " << s.id << ", Name: " << s.name 
                      << ", Contact: " << s.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addFurniture(1, "Chair", 10, 49.99);
    ims.addFurniture(2, "Table", 5, 149.99);
    ims.addSupplier(1, "Wood Suppliers Inc.", "123-456-7890");
    ims.addSupplier(2, "MetalWorks Co.", "987-654-3210");
    
    std::cout << "Furniture Inventory:" << std::endl;
    ims.displayFurniture();
    
    std::cout << "Suppliers List:" << std::endl;
    ims.displaySuppliers();

    return 0;
}