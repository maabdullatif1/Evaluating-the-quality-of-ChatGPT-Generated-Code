#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    Furniture(const std::string &name, const std::string &type, int quantity)
        : name(name), type(type), quantity(quantity) {}

    std::string getName() const { return name; }
    std::string getType() const { return type; }
    int getQuantity() const { return quantity; }
    void setQuantity(int qty) { quantity = qty; }

private:
    std::string name;
    std::string type;
    int quantity;
};

class Supplier {
public:
    Supplier(const std::string &name, const std::string &contact)
        : name(name), contact(contact) {}

    std::string getName() const { return name; }
    std::string getContact() const { return contact; }

private:
    std::string name;
    std::string contact;
};

class InventorySystem {
public:
    void addFurniture(const Furniture &furniture) {
        furnitures.push_back(furniture);
    }

    void deleteFurniture(const std::string &name) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->getName() == name) {
                furnitures.erase(it);
                break;
            }
        }
    }

    void updateFurnitureQuantity(const std::string &name, int quantity) {
        for (auto &furniture : furnitures) {
            if (furniture.getName() == name) {
                furniture.setQuantity(quantity);
                break;
            }
        }
    }

    void searchFurniture(const std::string &name) const {
        for (const auto &furniture : furnitures) {
            if (furniture.getName() == name) {
                std::cout << "Furniture: " << furniture.getName()
                          << ", Type: " << furniture.getType()
                          << ", Quantity: " << furniture.getQuantity() << std::endl;
                return;
            }
        }
        std::cout << "Furniture not found." << std::endl;
    }

    void displayFurnitures() const {
        for (const auto &furniture : furnitures) {
            std::cout << "Furniture: " << furniture.getName()
                      << ", Type: " << furniture.getType()
                      << ", Quantity: " << furniture.getQuantity() << std::endl;
        }
    }

    void addSupplier(const Supplier &supplier) {
        suppliers.push_back(supplier);
    }

    void deleteSupplier(const std::string &name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->getName() == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void searchSupplier(const std::string &name) const {
        for (const auto &supplier : suppliers) {
            if (supplier.getName() == name) {
                std::cout << "Supplier: " << supplier.getName()
                          << ", Contact: " << supplier.getContact() << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found." << std::endl;
    }

    void displaySuppliers() const {
        for (const auto &supplier : suppliers) {
            std::cout << "Supplier: " << supplier.getName()
                      << ", Contact: " << supplier.getContact() << std::endl;
        }
    }

private:
    std::vector<Furniture> furnitures;
    std::vector<Supplier> suppliers;
};

int main() {
    InventorySystem system;
    system.addFurniture(Furniture("Chair", "Seating", 10));
    system.addFurniture(Furniture("Table", "Surface", 5));
    system.addSupplier(Supplier("FurniCo", "123-456-7890"));
    system.addSupplier(Supplier("WoodWorks", "987-654-3210"));

    system.displayFurnitures();
    system.displaySuppliers();

    system.searchFurniture("Chair");
    system.updateFurnitureQuantity("Chair", 15);
    system.searchFurniture("Chair");

    system.deleteFurniture("Table");
    system.displayFurnitures();

    system.searchSupplier("FurniCo");
    system.deleteSupplier("WoodWorks");
    system.displaySuppliers();

    return 0;
}