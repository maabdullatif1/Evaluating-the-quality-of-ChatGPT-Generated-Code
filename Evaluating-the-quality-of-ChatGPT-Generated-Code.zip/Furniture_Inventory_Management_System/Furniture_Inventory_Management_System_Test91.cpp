#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Supplier {
public:
    string supplierID;
    string name;
    string contact;

    Supplier(string id, string n, string c) : supplierID(id), name(n), contact(c) {}
};

class Furniture {
public:
    string furnitureID;
    string name;
    string type;
    Supplier* supplier;
    int quantity;

    Furniture(string id, string n, string t, Supplier* s, int q)
        : furnitureID(id), name(n), type(t), supplier(s), quantity(q) {}
};

class InventorySystem {
    vector<Supplier> suppliers;
    vector<Furniture> furnitures;

public:
    void addSupplier(string id, string name, string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(string id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->supplierID == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    Supplier* searchSupplier(string id) {
        for (auto& s : suppliers) {
            if (s.supplierID == id) return &s;
        }
        return nullptr;
    }

    void addFurniture(string id, string name, string type, string supplierID, int quantity) {
        Supplier* supplier = searchSupplier(supplierID);
        if (supplier) furnitures.push_back(Furniture(id, name, type, supplier, quantity));
    }

    void deleteFurniture(string id) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->furnitureID == id) {
                furnitures.erase(it);
                break;
            }
        }
    }

    void updateFurniture(string id, string name, string type, string supplierID, int quantity) {
        for (auto& f : furnitures) {
            if (f.furnitureID == id) {
                f.name = name;
                f.type = type;
                f.quantity = quantity;
                f.supplier = searchSupplier(supplierID);
            }
        }
    }

    Furniture* searchFurniture(string id) {
        for (auto& f : furnitures) {
            if (f.furnitureID == id) return &f;
        }
        return nullptr;
    }

    void displayFurniture() {
        for (const auto& f : furnitures) {
            cout << "Furniture ID: " << f.furnitureID
                 << " Name: " << f.name
                 << " Type: " << f.type
                 << " Quantity: " << f.quantity
                 << " Supplier Name: " << f.supplier->name << endl;
        }
    }

    void displaySuppliers() {
        for (const auto& s : suppliers) {
            cout << "Supplier ID: " << s.supplierID
                 << " Name: " << s.name
                 << " Contact: " << s.contact << endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addSupplier("S1", "ABC Furniture", "555-1234");
    system.addSupplier("S2", "XYZ Supplies", "555-5678");

    system.addFurniture("F1", "Chair", "Seating", "S1", 10);
    system.addFurniture("F2", "Table", "Dining", "S2", 5);

    cout << "Furniture List:" << endl;
    system.displayFurniture();

    cout << "\nSuppliers List:" << endl;
    system.displaySuppliers();
    
    return 0;
}