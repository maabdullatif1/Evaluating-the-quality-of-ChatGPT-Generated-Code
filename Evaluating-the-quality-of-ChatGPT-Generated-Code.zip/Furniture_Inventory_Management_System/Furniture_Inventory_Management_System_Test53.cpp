#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Supplier {
public:
    string name;
    string contact;

    Supplier(string n, string c) : name(n), contact(c) {}
};

class Furniture {
public:
    string name;
    int quantity;
    float price;
    Supplier supplier;

    Furniture(string n, int q, float p, Supplier s) : name(n), quantity(q), price(p), supplier(s) {}
};

class Inventory {
private:
    vector<Furniture> inventory;
    vector<Supplier> suppliers;

public:
    void addSupplier(string name, string contact) {
        suppliers.push_back(Supplier(name, contact));
    }

    void addFurniture(string name, int quantity, float price, string supplierName) {
        for (auto &supplier : suppliers) {
            if (supplier.name == supplierName) {
                inventory.push_back(Furniture(name, quantity, price, supplier));
                return;
            }
        }
        cout << "Supplier not found." << endl;
    }

    void deleteFurniture(string name) {
        for (auto it = inventory.begin(); it != inventory.end(); ++it) {
            if (it->name == name) {
                inventory.erase(it);
                return;
            }
        }
        cout << "Furniture not found." << endl;
    }

    void updateFurniture(string name, int quantity, float price) {
        for (auto &item : inventory) {
            if (item.name == name) {
                item.quantity = quantity;
                item.price = price;
                return;
            }
        }
        cout << "Furniture not found." << endl;
    }

    void searchFurniture(string name) {
        for (auto &item : inventory) {
            if (item.name == name) {
                cout << "Name: " << item.name << ", Quantity: " << item.quantity 
                     << ", Price: $" << item.price << ", Supplier: " 
                     << item.supplier.name << endl;
                return;
            }
        }
        cout << "Furniture not found." << endl;
    }

    void displayFurniture() {
        for (auto &item : inventory) {
            cout << "Name: " << item.name << ", Quantity: " << item.quantity 
                 << ", Price: $" << item.price << ", Supplier: " 
                 << item.supplier.name << endl;
        }
    }
};

int main() {
    Inventory inventory;

    inventory.addSupplier("WoodWorks", "123-456-7890");
    inventory.addFurniture("Chair", 10, 49.99, "WoodWorks");
    inventory.addFurniture("Table", 5, 149.99, "WoodWorks");

    inventory.displayFurniture();
    
    inventory.searchFurniture("Chair");
    inventory.updateFurniture("Chair", 12, 59.99);
    inventory.searchFurniture("Chair");

    inventory.deleteFurniture("Table");
    inventory.displayFurniture();

    return 0;
}