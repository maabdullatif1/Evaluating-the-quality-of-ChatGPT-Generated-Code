#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInfo;

    Supplier(int id, const std::string& name, const std::string& contactInfo)
        : id(id), name(name), contactInfo(contactInfo) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    int quantity;
    Supplier supplier;

    Furniture(int id, const std::string& name, const std::string& type, int quantity, const Supplier& supplier)
        : id(id), name(name), type(type), quantity(quantity), supplier(supplier) {}
};

class InventoryManagement {
private:
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furnitures;

public:
    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.emplace_back(id, name, contact);
    }

    void addFurniture(int id, const std::string& name, const std::string& type, int quantity, int supplierId) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == supplierId) {
                furnitures.emplace_back(id, name, type, quantity, supplier);
                return;
            }
        }
        std::cout << "Supplier not found.\n";
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(),
            [id](Supplier& s) { return s.id == id; }), suppliers.end());
    }

    void deleteFurniture(int id) {
        furnitures.erase(std::remove_if(furnitures.begin(), furnitures.end(),
            [id](Furniture& f) { return f.id == id; }), furnitures.end());
    }

    void updateFurniture(int id, const std::string& name, const std::string& type, int quantity, int supplierId) {
        for (auto& furniture : furnitures) {
            if (furniture.id == id) {
                for (const auto& supplier : suppliers) {
                    if (supplier.id == supplierId) {
                        furniture.name = name;
                        furniture.type = type;
                        furniture.quantity = quantity;
                        furniture.supplier = supplier;
                        return;
                    }
                }
            }
        }
        std::cout << "Furniture or Supplier not found.\n";
    }

    void searchFurniture(int id) const {
        for (const auto& furniture : furnitures) {
            if (furniture.id == id) {
                std::cout << "Furniture ID: " << furniture.id << ", Name: " << furniture.name
                          << ", Type: " << furniture.type << ", Quantity: " << furniture.quantity
                          << ", Supplier: " << furniture.supplier.name << "\n";
                return;
            }
        }
        std::cout << "Furniture not found.\n";
    }

    void displayFurnitures() const {
        for (const auto& furniture : furnitures) {
            std::cout << "ID: " << furniture.id << ", Name: " << furniture.name
                      << ", Type: " << furniture.type << ", Quantity: " << furniture.quantity
                      << ", Supplier: " << furniture.supplier.name << "\n";
        }
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contactInfo << "\n";
        }
    }
};

int main() {
    InventoryManagement system;
    system.addSupplier(1, "Supplier A", "123-456-789");

    system.addFurniture(101, "Chair", "Office", 50, 1);
    system.addFurniture(102, "Table", "Conference", 20, 1);

    system.displayFurnitures();
    system.displaySuppliers();

    system.searchFurniture(101);

    system.updateFurniture(101, "Chair", "Executive", 45, 1);
    system.searchFurniture(101);

    system.deleteFurniture(102);
    system.displayFurnitures();

    return 0;
}