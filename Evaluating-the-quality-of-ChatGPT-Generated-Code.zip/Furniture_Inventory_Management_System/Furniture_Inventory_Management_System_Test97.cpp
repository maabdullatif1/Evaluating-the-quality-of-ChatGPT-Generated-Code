#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInfo;

    Supplier(int id, const std::string& name, const std::string& contactInfo)
        : id(id), name(name), contactInfo(contactInfo) {}
};

class Furniture {
public:
    int id;
    std::string type;
    std::string material;
    int supplierId;
    int quantity;

    Furniture(int id, const std::string& type, const std::string& material, int supplierId, int quantity)
        : id(id), type(type), material(material), supplierId(supplierId), quantity(quantity) {}
};

class InventoryManagementSystem {
private:
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

    Furniture* findFurnitureById(int id) {
        for (auto& item : furnitureList) {
            if (item.id == id)
                return &item;
        }
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for (auto& supplier : supplierList) {
            if (supplier.id == id)
                return &supplier;
        }
        return nullptr;
    }

public:
    void addFurniture(const Furniture& furniture) {
        furnitureList.push_back(furniture);
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                return;
            }
        }
    }

    void updateFurniture(int id, const std::string& type, const std::string& material, int supplierId, int quantity) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture) {
            furniture->type = type;
            furniture->material = material;
            furniture->supplierId = supplierId;
            furniture->quantity = quantity;
        }
    }

    void searchFurniture(int id) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture) {
            std::cout << "Furniture ID: " << furniture->id << "\nType: " << furniture->type
                      << "\nMaterial: " << furniture->material << "\nSupplier ID: " << furniture->supplierId
                      << "\nQuantity: " << furniture->quantity << "\n";
        } else {
            std::cout << "Furniture not found\n";
        }
    }

    void displayFurniture() {
        for (const auto& furniture : furnitureList) {
            std::cout << "Furniture ID: " << furniture.id << "\nType: " << furniture.type
                      << "\nMaterial: " << furniture.material << "\nSupplier ID: " << furniture.supplierId
                      << "\nQuantity: " << furniture.quantity << "\n\n";
        }
    }

    void addSupplier(const Supplier& supplier) {
        supplierList.push_back(supplier);
    }

    void deleteSupplier(int id) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->id == id) {
                supplierList.erase(it);
                return;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contactInfo) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contactInfo = contactInfo;
        }
    }

    void searchSupplier(int id) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            std::cout << "Supplier ID: " << supplier->id << "\nName: " << supplier->name
                      << "\nContact Info: " << supplier->contactInfo << "\n";
        } else {
            std::cout << "Supplier not found\n";
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : supplierList) {
            std::cout << "Supplier ID: " << supplier.id << "\nName: " << supplier.name
                      << "\nContact Info: " << supplier.contactInfo << "\n\n";
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier(Supplier(1, "SupplierOne", "123-456-7890"));
    ims.addSupplier(Supplier(2, "SupplierTwo", "098-765-4321"));
    ims.addFurniture(Furniture(1, "Chair", "Wood", 1, 100));
    ims.addFurniture(Furniture(2, "Table", "Metal", 2, 50));
    ims.displaySuppliers();
    ims.displayFurniture();
    ims.updateFurniture(1, "Chair", "Plastic", 1, 120);
    ims.searchFurniture(1);
    ims.deleteSupplier(1);
    ims.displaySuppliers();
    return 0;
}