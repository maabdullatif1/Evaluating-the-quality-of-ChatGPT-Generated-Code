#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;

    Supplier(int id, std::string name) : id(id), name(name) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    double price;
    int supplierId;

    Furniture(int id, std::string name, std::string type, double price, int supplierId)
        : id(id), name(name), type(type), price(price), supplierId(supplierId) {}
};

class InventoryManagement {
private:
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furnitureItems;

public:
    void addSupplier(int id, std::string name) {
        suppliers.push_back(Supplier(id, name));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, std::string name) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                break;
            }
        }
    }

    void addFurniture(int id, std::string name, std::string type, double price, int supplierId) {
        furnitureItems.push_back(Furniture(id, name, type, price, supplierId));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureItems.begin(); it != furnitureItems.end(); ++it) {
            if (it->id == id) {
                furnitureItems.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, std::string name, std::string type, double price, int supplierId) {
        for (auto& furniture : furnitureItems) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.price = price;
                furniture.supplierId = supplierId;
                break;
            }
        }
    }

    void searchFurniture(int id) {
        for (const auto& furniture : furnitureItems) {
            if (furniture.id == id) {
                std::cout << "Furniture ID: " << furniture.id
                          << ", Name: " << furniture.name
                          << ", Type: " << furniture.type
                          << ", Price: " << furniture.price
                          << ", Supplier ID: " << furniture.supplierId << std::endl;
                return;
            }
        }
        std::cout << "Furniture not found" << std::endl;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << std::endl;
        }
    }

    void displayFurniture() {
        for (const auto& furniture : furnitureItems) {
            std::cout << "Furniture ID: " << furniture.id
                      << ", Name: " << furniture.name
                      << ", Type: " << furniture.type
                      << ", Price: " << furniture.price
                      << ", Supplier ID: " << furniture.supplierId << std::endl;
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addSupplier(1, "Supplier A");
    inventory.addSupplier(2, "Supplier B");
    inventory.addFurniture(1, "Chair", "Seating", 150.0, 1);
    inventory.addFurniture(2, "Table", "Dining", 300.0, 2);
    
    std::cout << "Suppliers:\n";
    inventory.displaySuppliers();
    
    std::cout << "\nFurniture:\n";
    inventory.displayFurniture();
    
    inventory.updateFurniture(1, "Office Chair", "Seating", 175.0, 1);
    inventory.searchFurniture(1);
    
    inventory.deleteSupplier(2);
    std::cout << "\nAfter deleting Supplier 2:\n";
    inventory.displaySuppliers();
    
    inventory.deleteFurniture(2);
    std::cout << "\nAfter deleting Furniture 2:\n";
    inventory.displayFurniture();
    
    return 0;
}