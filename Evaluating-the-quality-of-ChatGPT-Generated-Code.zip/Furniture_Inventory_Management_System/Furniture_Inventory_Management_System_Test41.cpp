#include <iostream>
#include <vector>
#include <string>

struct Furniture {
    int id;
    std::string name;
    int quantity;
    double price;
    int supplierId;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventoryManagement {
private:
    std::vector<Furniture> furnitureInventory;
    std::vector<Supplier> suppliers;

    Furniture* findFurnitureById(int id) {
        for (auto &f : furnitureInventory) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for (auto &s : suppliers) {
            if (s.id == id) {
                return &s;
            }
        }
        return nullptr;
    }

public:
    void addFurniture(int id, const std::string &name, int quantity, double price, int supplierId) {
        if (findFurnitureById(id) == nullptr) {
            furnitureInventory.push_back({id, name, quantity, price, supplierId});
        }
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureInventory.begin(); it != furnitureInventory.end(); ++it) {
            if (it->id == id) {
                furnitureInventory.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, const std::string &name, int quantity, double price, int supplierId) {
        Furniture *f = findFurnitureById(id);
        if (f) {
            f->name = name;
            f->quantity = quantity;
            f->price = price;
            f->supplierId = supplierId;
        }
    }

    void displayFurniture() {
        for (const auto &f : furnitureInventory) {
            std::cout << "ID: " << f.id << ", Name: " << f.name << ", Quantity: " << f.quantity 
                      << ", Price: " << f.price << ", Supplier ID: " << f.supplierId << std::endl;
        }
    }

    Furniture* searchFurniture(int id) {
        return findFurnitureById(id);
    }

    void addSupplier(int id, const std::string &name, const std::string &contact) {
        if (findSupplierById(id) == nullptr) {
            suppliers.push_back({id, name, contact});
        }
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string &name, const std::string &contact) {
        Supplier *s = findSupplierById(id);
        if (s) {
            s->name = name;
            s->contact = contact;
        }
    }

    void displaySuppliers() {
        for (const auto &s : suppliers) {
            std::cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addSupplier(1, "Supplier A", "contact@suppliera.com");
    inventory.addSupplier(2, "Supplier B", "contact@supplierb.com");
    
    inventory.addFurniture(1, "Table", 5, 150.0, 1);
    inventory.addFurniture(2, "Chair", 20, 50.0, 2);
    
    inventory.displaySuppliers();
    inventory.displayFurniture();
    
    Furniture* f = inventory.searchFurniture(2);
    if (f) {
        std::cout << "Found Furniture - ID: " << f->id << ", Name: " << f->name << std::endl;
    }

    inventory.updateFurniture(1, "Dining Table", 10, 200.0, 1);
    inventory.displayFurniture();
    
    inventory.deleteFurniture(2);
    inventory.displayFurniture();
    
    return 0;
}