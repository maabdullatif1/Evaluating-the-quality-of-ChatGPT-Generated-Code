#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Supplier {
public:
    int id;
    string name;
    string contact;

    Supplier(int sup_id, string sup_name, string sup_contact)
        : id(sup_id), name(sup_name), contact(sup_contact) {}
};

class Furniture {
public:
    int id;
    string name;
    string type;
    float price;
    int supplier_id;

    Furniture(int fur_id, string fur_name, string fur_type, float fur_price, int sup_id)
        : id(fur_id), name(fur_name), type(fur_type), price(fur_price), supplier_id(sup_id) {}
};

class Inventory {
private:
    vector<Furniture> furnitures;
    vector<Supplier> suppliers;

public:
    void addSupplier(int id, string name, string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }

    void addFurniture(int id, string name, string type, float price, int supplier_id) {
        furnitures.push_back(Furniture(id, name, type, price, supplier_id));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->id == id) {
                furnitures.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, string name, string type, float price, int supplier_id) {
        for (auto& furniture : furnitures) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.price = price;
                furniture.supplier_id = supplier_id;
                break;
            }
        }
    }

    void searchFurniture(int id) {
        for (const auto& furniture : furnitures) {
            if (furniture.id == id) {
                cout << "ID: " << furniture.id << ", Name: " << furniture.name << ", Type: " << furniture.type
                     << ", Price: " << furniture.price << ", Supplier ID: " << furniture.supplier_id << endl;
                return;
            }
        }
        cout << "Furniture not found." << endl;
    }

    void displayFurniture() {
        for (const auto& furniture : furnitures) {
            cout << "ID: " << furniture.id << ", Name: " << furniture.name << ", Type: " << furniture.type
                 << ", Price: " << furniture.price << ", Supplier ID: " << furniture.supplier_id << endl;
        }
    }
};

int main() {
    Inventory inventory;

    inventory.addSupplier(1, "Supplier A", "1234");
    inventory.addSupplier(2, "Supplier B", "5678");

    inventory.addFurniture(1, "Chair", "Seating", 49.99, 1);
    inventory.addFurniture(2, "Table", "Dining", 89.99, 2);

    cout << "Suppliers:" << endl;
    inventory.displaySuppliers();

    cout << "\nFurniture:" << endl;
    inventory.displayFurniture();

    return 0;
}