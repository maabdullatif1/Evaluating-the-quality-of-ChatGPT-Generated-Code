#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    
    Supplier(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    int quantity;
    int supplierId;
    
    Furniture(int id, std::string name, std::string type, int quantity, int supplierId)
        : id(id), name(name), type(type), quantity(quantity), supplierId(supplierId) {}
};

class InventoryManager {
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furniture;

    Supplier* findSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id)
                return &supplier;
        }
        return nullptr;
    }

    Furniture* findFurniture(int id) {
        for (auto& item : furniture) {
            if (item.id == id)
                return &item;
        }
        return nullptr;
    }

public:
    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                return;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        Supplier* supplier = findSupplier(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void addFurniture(int id, std::string name, std::string type, int quantity, int supplierId) {
        furniture.push_back(Furniture(id, name, type, quantity, supplierId));
    }

    void deleteFurniture(int id) {
        for (auto it = furniture.begin(); it != furniture.end(); ++it) {
            if (it->id == id) {
                furniture.erase(it);
                return;
            }
        }
    }

    void updateFurniture(int id, std::string name, std::string type, int quantity, int supplierId) {
        Furniture* item = findFurniture(id);
        if (item) {
            item->name = name;
            item->type = type;
            item->quantity = quantity;
            item->supplierId = supplierId;
        }
    }

    void searchFurniture(int id) {
        Furniture* item = findFurniture(id);
        if (item) {
            std::cout << "Furniture ID: " << item->id << " Name: " << item->name 
                      << " Type: " << item->type << " Quantity: " << item->quantity 
                      << " Supplier ID: " << item->supplierId << std::endl;
        } else {
            std::cout << "Furniture not found." << std::endl;
        }
    }

    void searchSupplier(int id) {
        Supplier* supplier = findSupplier(id);
        if (supplier) {
            std::cout << "Supplier ID: " << supplier->id << " Name: " << supplier->name 
                      << " Contact: " << supplier->contact << std::endl;
        } else {
            std::cout << "Supplier not found." << std::endl;
        }
    }

    void displayFurniture() {
        for (const auto& item : furniture) {
            std::cout << "Furniture ID: " << item.id << " Name: " << item.name 
                      << " Type: " << item.type << " Quantity: " << item.quantity 
                      << " Supplier ID: " << item.supplierId << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << " Name: " << supplier.name 
                      << " Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManager manager;
    manager.addSupplier(1, "ABC Furniture", "123-456-789");
    manager.addFurniture(101, "Chair", "Office", 50, 1);
    manager.displaySuppliers();
    manager.displayFurniture();
    manager.updateFurniture(101, "Chair", "Office", 100, 1);
    manager.searchFurniture(101);
    manager.deleteFurniture(101);
    manager.displayFurniture();
    return 0;
}