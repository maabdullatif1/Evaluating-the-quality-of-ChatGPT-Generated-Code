#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Supplier {
public:
    int id;
    string name;
    string contact;

    Supplier(int i, const string& n, const string& c) : id(i), name(n), contact(c) {}
};

class Furniture {
public:
    int id;
    string name;
    int quantity;
    int supplierId;

    Furniture(int i, const string& n, int q, int sId) : id(i), name(n), quantity(q), supplierId(sId) {}
};

class Inventory {
private:
    vector<Furniture> furnitureList;
    vector<Supplier> supplierList;

public:
    void addSupplier(int id, const string& name, const string& contact) {
        supplierList.emplace_back(id, name, contact);
    }

    void deleteSupplier(int id) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->id == id) {
                supplierList.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const string& name, const string& contact) {
        for (auto &supplier : supplierList) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto &supplier : supplierList) {
            if (supplier.id == id) {
                cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
            }
        }
    }

    void displaySuppliers() {
        for (const auto &supplier : supplierList) {
            cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }

    void addFurniture(int id, const string& name, int quantity, int supplierId) {
        furnitureList.emplace_back(id, name, quantity, supplierId);
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, const string& name, int quantity, int supplierId) {
        for (auto &furniture : furnitureList) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.quantity = quantity;
                furniture.supplierId = supplierId;
            }
        }
    }

    void searchFurniture(int id) {
        for (const auto &furniture : furnitureList) {
            if (furniture.id == id) {
                cout << "Furniture ID: " << furniture.id << ", Name: " << furniture.name
                     << ", Quantity: " << furniture.quantity << ", Supplier ID: " << furniture.supplierId << endl;
            }
        }
    }

    void displayFurniture() {
        for (const auto &furniture : furnitureList) {
            cout << "Furniture ID: " << furniture.id << ", Name: " << furniture.name
                 << ", Quantity: " << furniture.quantity << ", Supplier ID: " << furniture.supplierId << endl;
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addSupplier(1, "ABC Supplies", "123-456-7890");
    inventory.addSupplier(2, "XYZ Supplies", "098-765-4321");
    
    inventory.addFurniture(101, "Chair", 50, 1);
    inventory.addFurniture(102, "Table", 30, 2);
    
    inventory.displaySuppliers();
    inventory.displayFurniture();
    
    return 0;
}