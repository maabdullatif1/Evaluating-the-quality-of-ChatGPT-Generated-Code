#include <iostream>
#include <string>
#include <vector>

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

struct Furniture {
    int id;
    std::string name;
    std::string type;
    double price;
    int supplierId;
};

class InventorySystem {
private:
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furnitureItems;

    Supplier* findSupplierById(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id)
                return &supplier;
        }
        return nullptr;
    }

    Furniture* findFurnitureById(int id) {
        for (auto& furniture : furnitureItems) {
            if (furniture.id == id)
                return &furniture;
        }
        return nullptr;
    }

public:
    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.push_back({id, name, contact});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void searchSupplier(int id) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            std::cout << "Supplier ID: " << supplier->id << "\n"
                      << "Name: " << supplier->name << "\n"
                      << "Contact: " << supplier->contact << "\n";
        } else {
            std::cout << "Supplier not found!\n";
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << "\n";
        }
    }

    void addFurniture(int id, const std::string& name, const std::string& type, double price, int supplierId) {
        furnitureItems.push_back({id, name, type, price, supplierId});
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureItems.begin(); it != furnitureItems.end(); ++it) {
            if (it->id == id) {
                furnitureItems.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, const std::string& name, const std::string& type, double price, int supplierId) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture) {
            furniture->name = name;
            furniture->type = type;
            furniture->price = price;
            furniture->supplierId = supplierId;
        }
    }

    void searchFurniture(int id) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture) {
            std::cout << "Furniture ID: " << furniture->id << "\n"
                      << "Name: " << furniture->name << "\n"
                      << "Type: " << furniture->type << "\n"
                      << "Price: " << furniture->price << "\n"
                      << "Supplier ID: " << furniture->supplierId << "\n";
        } else {
            std::cout << "Furniture not found!\n";
        }
    }

    void displayFurniture() {
        for (const auto& furniture : furnitureItems) {
            std::cout << "Furniture ID: " << furniture.id << ", Name: " << furniture.name
                      << ", Type: " << furniture.type << ", Price: " << furniture.price 
                      << ", Supplier ID: " << furniture.supplierId << "\n";
        }
    }
};

int main() {
    InventorySystem inventory;
    inventory.addSupplier(1, "ABC Suppliers", "123-456-7890");
    inventory.addFurniture(1, "Chair", "Seating", 49.99, 1);
    inventory.displaySuppliers();
    inventory.displayFurniture();
    return 0;
}