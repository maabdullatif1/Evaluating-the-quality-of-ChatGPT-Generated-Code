#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Supplier {
public:
    int id;
    string name;
    string contact;
    
    Supplier(int id, string name, string contact) : id(id), name(name), contact(contact) {}
};

class Furniture {
public:
    int id;
    string name;
    string type;
    int supplierId;
    
    Furniture(int id, string name, string type, int supplierId) : id(id), name(name), type(type), supplierId(supplierId) {}
};

class InventoryManagementSystem {
private:
    vector<Supplier> suppliers;
    vector<Furniture> furniture;

    int findSupplierById(int id) {
        for (int i = 0; i < suppliers.size(); i++) {
            if (suppliers[i].id == id) return i;
        }
        return -1;
    }

    int findFurnitureById(int id) {
        for (int i = 0; i < furniture.size(); i++) {
            if (furniture[i].id == id) return i;
        }
        return -1;
    }
    
public:
    void addSupplier(int id, string name, string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        int index = findSupplierById(id);
        if (index != -1) suppliers.erase(suppliers.begin() + index);
    }

    void updateSupplier(int id, string name, string contact) {
        int index = findSupplierById(id);
        if (index != -1) {
            suppliers[index].name = name;
            suppliers[index].contact = contact;
        }
    }

    void displaySuppliers() {
        for (auto& s : suppliers) {
            cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << endl;
        }
    }

    void addFurniture(int id, string name, string type, int supplierId) {
        furniture.push_back(Furniture(id, name, type, supplierId));
    }

    void deleteFurniture(int id) {
        int index = findFurnitureById(id);
        if (index != -1) furniture.erase(furniture.begin() + index);
    }

    void updateFurniture(int id, string name, string type, int supplierId) {
        int index = findFurnitureById(id);
        if (index != -1) {
            furniture[index].name = name;
            furniture[index].type = type;
            furniture[index].supplierId = supplierId;
        }
    }

    void searchFurniture(string name) {
        for (auto& f : furniture) {
            if (f.name == name) {
                cout << "ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type << ", Supplier ID: " << f.supplierId << endl;
            }
        }
    }

    void displayFurniture() {
        for (auto& f : furniture) {
            cout << "ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type << ", Supplier ID: " << f.supplierId << endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier(1, "Supplier A", "123-456-7890");
    ims.addSupplier(2, "Supplier B", "987-654-3210");
    ims.addFurniture(1, "Chair", "Seating", 1);
    ims.addFurniture(2, "Table", "Surface", 2);
    cout << "All Suppliers:" << endl;
    ims.displaySuppliers();
    cout << "All Furniture:" << endl;
    ims.displayFurniture();
    ims.searchFurniture("Chair");
    ims.updateSupplier(1, "Supplier A+", "111-222-3333");
    ims.updateFurniture(1, "Chair+", "Seating", 1);
    ims.deleteSupplier(2);
    ims.deleteFurniture(2);
    cout << "Updated Suppliers:" << endl;
    ims.displaySuppliers();
    cout << "Updated Furniture:" << endl;
    ims.displayFurniture();
    return 0;
}