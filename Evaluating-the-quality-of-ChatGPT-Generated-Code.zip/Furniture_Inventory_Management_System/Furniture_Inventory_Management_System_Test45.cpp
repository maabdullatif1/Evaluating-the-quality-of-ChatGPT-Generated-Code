#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    int id;
    std::string name;
    std::string supplierName;
    int quantity;

    Furniture(int i, std::string n, std::string s, int q) : id(i), name(n), supplierName(s), quantity(q) {}
};

class Inventory {
    std::vector<Furniture> furnitureList;

public:
    void addFurniture(int id, std::string name, std::string supplierName, int quantity) {
        furnitureList.push_back(Furniture(id, name, supplierName, quantity));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, std::string name, std::string supplierName, int quantity) {
        for (auto& f : furnitureList) {
            if (f.id == id) {
                f.name = name;
                f.supplierName = supplierName;
                f.quantity = quantity;
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto& f : furnitureList) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayFurniture() {
        for (const auto& f : furnitureList) {
            std::cout << "ID: " << f.id << ", Name: " << f.name
                      << ", Supplier: " << f.supplierName
                      << ", Quantity: " << f.quantity << std::endl;
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addFurniture(1, "Chair", "XYZ Corp", 50);
    inventory.addFurniture(2, "Table", "ABC Ltd", 30);
    inventory.displayFurniture();
    
    Furniture* furniture = inventory.searchFurniture(1);
    if (furniture) {
        std::cout << "Found furniture ID: " << furniture->id << std::endl;
    }
    
    inventory.updateFurniture(2, "Office Table", "ABC Ltd", 25);
    inventory.displayFurniture();
    
    inventory.deleteFurniture(1);
    inventory.displayFurniture();

    return 0;
}