#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    int quantity;

    Furniture(int id, const std::string& name, const std::string& type, int quantity)
        : id(id), name(name), type(type), quantity(quantity) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, const std::string& name, const std::string& contact)
        : id(id), name(name), contact(contact) {}
};

class FurnitureInventory {
    std::vector<Furniture> furnitures;
    std::vector<Supplier> suppliers;

public:
    void addFurniture(int id, const std::string& name, const std::string& type, int quantity) {
        furnitures.push_back(Furniture(id, name, type, quantity));
    }

    void deleteFurniture(int id) {
        for(auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if(it->id == id) {
                furnitures.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, const std::string& name, const std::string& type, int quantity) {
        for(auto& furniture : furnitures) {
            if(furniture.id == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.quantity = quantity;
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for(auto& furniture : furnitures) {
            if(furniture.id == id) return &furniture;
        }
        return nullptr;
    }

    void displayFurniture() const {
        for(const auto& furniture : furnitures) {
            std::cout << "ID: " << furniture.id 
                      << ", Name: " << furniture.name 
                      << ", Type: " << furniture.type 
                      << ", Quantity: " << furniture.quantity << std::endl;
        }
    }

    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for(auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if(it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for(auto& supplier : suppliers) {
            if(supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for(auto& supplier : suppliers) {
            if(supplier.id == id) return &supplier;
        }
        return nullptr;
    }

    void displaySuppliers() const {
        for(const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id 
                      << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    FurnitureInventory inventory;
    inventory.addFurniture(1, "Chair", "Office", 10);
    inventory.addFurniture(2, "Table", "Dining", 5);
    inventory.addSupplier(1, "ABC Furnitures", "123-456-7890");
    inventory.addSupplier(2, "XYZ Supplies", "098-765-4321");

    std::cout << "Furnitures:" << std::endl;
    inventory.displayFurniture();

    std::cout << "Suppliers:" << std::endl;
    inventory.displaySuppliers();

    return 0;
}