#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Supplier {
    int id;
    string name;
    string contact;
};

struct Furniture {
    int id;
    string name;
    string type;
    Supplier supplier;
    int quantity;
};

class Inventory {
private:
    vector<Furniture> furnitures;
    vector<Supplier> suppliers;

    Supplier* findSupplierById(int id) {
        for (auto &s : suppliers) {
            if (s.id == id) {
                return &s;
            }
        }
        return nullptr;
    }

    Furniture* findFurnitureById(int id) {
        for (auto &f : furnitures) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }
public:
    void addSupplier(int id, const string& name, const string& contact) {
        suppliers.push_back({id, name, contact});
    }

    void addFurniture(int id, const string& name, const string& type, int supplierId, int quantity) {
        Supplier* supplier = findSupplierById(supplierId);
        if (supplier) {
            furnitures.push_back({id, name, type, *supplier, quantity});
        }
    }

    void deleteSupplier(int id) {
        suppliers.erase(remove_if(suppliers.begin(), suppliers.end(), [&](Supplier& s) { return s.id == id; }), suppliers.end());
    }

    void deleteFurniture(int id) {
        furnitures.erase(remove_if(furnitures.begin(), furnitures.end(), [&](Furniture& f) { return f.id == id; }), furnitures.end());
    }

    void updateSupplier(int id, const string& name, const string& contact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void updateFurniture(int id, const string& name, const string& type, int supplierId, int quantity) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture) {
            furniture->name = name;
            furniture->type = type;
            Supplier* supplier = findSupplierById(supplierId);
            if (supplier) {
                furniture->supplier = *supplier;
            }
            furniture->quantity = quantity;
        }
    }

    Furniture* searchFurniture(int id) {
        return findFurnitureById(id);
    }

    Supplier* searchSupplier(int id) {
        return findSupplierById(id);
    }

    void displayFurnitures() {
        for (const auto &f : furnitures) {
            cout << "ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type
                 << ", Supplier: " << f.supplier.name << ", Quantity: " << f.quantity << endl;
        }
    }

    void displaySuppliers() {
        for (const auto &s : suppliers) {
            cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << endl;
        }
    }
};

int main() {
    Inventory inventory;

    inventory.addSupplier(1, "ABC Furniture", "123-456-7890");
    inventory.addSupplier(2, "XYZ Furnishings", "098-765-4321");

    inventory.addFurniture(1, "Chair", "Seating", 1, 50);
    inventory.addFurniture(2, "Table", "Dining", 2, 20);

    inventory.displaySuppliers();
    cout << endl;
    inventory.displayFurnitures();

    return 0;
}