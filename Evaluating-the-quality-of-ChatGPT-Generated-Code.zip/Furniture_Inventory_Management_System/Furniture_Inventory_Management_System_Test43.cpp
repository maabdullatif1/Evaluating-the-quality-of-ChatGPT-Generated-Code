#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    std::string id;
    std::string name;
    std::string type;
    double price;
    int quantity;

    Furniture(std::string id, std::string name, std::string type, double price, int quantity)
        : id(id), name(name), type(type), price(price), quantity(quantity) {}
};

class Supplier {
public:
    std::string id;
    std::string name;
    std::string contact;

    Supplier(std::string id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class InventoryManagement {
private:
    std::vector<Furniture> furnitures;
    std::vector<Supplier> suppliers;

public:
    void addFurniture(const Furniture& furniture) {
        furnitures.push_back(furniture);
    }

    void deleteFurniture(const std::string& id) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->id == id) {
                furnitures.erase(it);
                break;
            }
        }
    }

    void updateFurniture(const Furniture& furniture) {
        for (auto& f : furnitures) {
            if (f.id == furniture.id) {
                f.name = furniture.name;
                f.type = furniture.type;
                f.price = furniture.price;
                f.quantity = furniture.quantity;
                break;
            }
        }
    }

    Furniture* searchFurniture(const std::string& id) {
        for (auto& f : furnitures) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayFurniture() {
        for (const auto& f : furnitures) {
            std::cout << "ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type
                      << ", Price: " << f.price << ", Quantity: " << f.quantity << "\n";
        }
    }

    void addSupplier(const Supplier& supplier) {
        suppliers.push_back(supplier);
    }

    void deleteSupplier(const std::string& id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(const Supplier& supplier) {
        for (auto& s : suppliers) {
            if (s.id == supplier.id) {
                s.name = supplier.name;
                s.contact = supplier.contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(const std::string& id) {
        for (auto& s : suppliers) {
            if (s.id == id) {
                return &s;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& s : suppliers) {
            std::cout << "ID: " << s.id << ", Name: " << s.name 
                      << ", Contact: " << s.contact << "\n";
        }
    }
};

int main() {
    InventoryManagement system;

    system.addFurniture(Furniture("F001", "Chair", "Seating", 49.99, 100));
    system.addFurniture(Furniture("F002", "Table", "Dining", 89.99, 50));
    system.addSupplier(Supplier("S001", "Supplier A", "123-456-789"));

    system.displayFurniture();
    system.displaySuppliers();

    Furniture* found = system.searchFurniture("F001");
    if (found) {
        std::cout << "Found: " << found->name << "\n";
    }

    system.updateFurniture(Furniture("F001", "Armchair", "Seating", 59.99, 90));
    system.displayFurniture();

    system.deleteFurniture("F002");
    system.displayFurniture();

    return 0;
}