#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    double price;
    int supplierId;
    Furniture(int i, const std::string& n, const std::string& t, double p, int sId)
        : id(i), name(n), type(t), price(p), supplierId(sId) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    Supplier(int i, const std::string& n, const std::string& c)
        : id(i), name(n), contact(c) {}
};

class InventoryManagementSystem {
private:
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

public:
    void addFurniture(int id, const std::string& name, const std::string& type, double price, int supplierId) {
        furnitureList.push_back(Furniture(id, name, type, price, supplierId));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, const std::string& name, const std::string& type, double price, int supplierId) {
        for (auto& furniture : furnitureList) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.price = price;
                furniture.supplierId = supplierId;
                break;
            }
        }
    }

    void searchFurniture(int id) {
        for (const auto& furniture : furnitureList) {
            if (furniture.id == id) {
                std::cout << "ID: " << furniture.id
                          << ", Name: " << furniture.name
                          << ", Type: " << furniture.type
                          << ", Price: " << furniture.price
                          << ", Supplier ID: " << furniture.supplierId << std::endl;
                return;
            }
        }
        std::cout << "Furniture not found." << std::endl;
    }

    void displayFurniture() {
        for (const auto& furniture : furnitureList) {
            std::cout << "ID: " << furniture.id
                      << ", Name: " << furniture.name
                      << ", Type: " << furniture.type
                      << ", Price: " << furniture.price
                      << ", Supplier ID: " << furniture.supplierId << std::endl;
        }
    }

    void addSupplier(int id, const std::string& name, const std::string& contact) {
        supplierList.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->id == id) {
                supplierList.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& supplier : supplierList) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto& supplier : supplierList) {
            if (supplier.id == id) {
                std::cout << "ID: " << supplier.id
                          << ", Name: " << supplier.name
                          << ", Contact: " << supplier.contact << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found." << std::endl;
    }

    void displaySuppliers() {
        for (const auto& supplier : supplierList) {
            std::cout << "ID: " << supplier.id
                      << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addFurniture(1, "Chair", "Seating", 45.99, 101);
    ims.addSupplier(101, "ABC Supplies", "123-456-7890");
    ims.displayFurniture();
    ims.displaySuppliers();
    return 0;
}