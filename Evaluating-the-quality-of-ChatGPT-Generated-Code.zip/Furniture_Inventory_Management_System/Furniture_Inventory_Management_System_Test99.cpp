#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Supplier {
public:
    int supplierID;
    string name;
    string contactInfo;
    
    Supplier(int id, string n, string c) : supplierID(id), name(n), contactInfo(c) {}
};

class Furniture {
public:
    int furnitureID;
    string name;
    int quantity;
    int supplierID;

    Furniture(int id, string n, int q, int sid) : furnitureID(id), name(n), quantity(q), supplierID(sid) {}
};

class InventoryManager {
private:
    vector<Furniture> furnitures;
    vector<Supplier> suppliers;

    Supplier* findSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.supplierID == id) return &supplier;
        }
        return nullptr;
    }

    Furniture* findFurniture(int id) {
        for (auto &furniture : furnitures) {
            if (furniture.furnitureID == id) return &furniture;
        }
        return nullptr;
    }

public:
    void addSupplier(int id, string name, string contact) {
        if (!findSupplier(id)) {
            suppliers.push_back(Supplier(id, name, contact));
        }
    }

    void deleteSupplier(int id) {
        for (size_t i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].supplierID == id) {
                suppliers.erase(suppliers.begin() + i);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contact) {
        Supplier* supplier = findSupplier(id);
        if (supplier) {
            supplier->name = name;
            supplier->contactInfo = contact;
        }
    }

    void addFurniture(int id, string name, int quantity, int supplierID) {
        if (!findFurniture(id) && findSupplier(supplierID)) {
            furnitures.push_back(Furniture(id, name, quantity, supplierID));
        }
    }

    void deleteFurniture(int id) {
        for (size_t i = 0; i < furnitures.size(); ++i) {
            if (furnitures[i].furnitureID == id) {
                furnitures.erase(furnitures.begin() + i);
                break;
            }
        }
    }

    void updateFurniture(int id, string name, int quantity, int supplierID) {
        Furniture* furniture = findFurniture(id);
        if (furniture && findSupplier(supplierID)) {
            furniture->name = name;
            furniture->quantity = quantity;
            furniture->supplierID = supplierID;
        }
    }

    void searchFurniture(int id) {
        Furniture* furniture = findFurniture(id);
        if (furniture) {
            cout << "Furniture ID: " << furniture->furnitureID << "\n";
            cout << "Name: " << furniture->name << "\n";
            cout << "Quantity: " << furniture->quantity << "\n";
            cout << "Supplier ID: " << furniture->supplierID << "\n";
        } else {
            cout << "Furniture not found.\n";
        }
    }

    void displayFurniture() {
        for (auto &furniture : furnitures) {
            cout << "Furniture ID: " << furniture.furnitureID << ", Name: " << furniture.name
                 << ", Quantity: " << furniture.quantity << ", Supplier ID: " << furniture.supplierID << "\n";
        }
    }

    void displaySuppliers() {
        for (auto &supplier : suppliers) {
            cout << "Supplier ID: " << supplier.supplierID << ", Name: " << supplier.name
                 << ", Contact Info: " << supplier.contactInfo << "\n";
        }
    }
};

int main() {
    InventoryManager manager;
    manager.addSupplier(1, "John Doe Supplies", "123-456-7890");
    manager.addFurniture(101, "Oak Chair", 15, 1);
    manager.displaySuppliers();
    manager.displayFurniture();
    manager.updateFurniture(101, "Pine Chair", 20, 1);
    manager.searchFurniture(101);
}