#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
};

class Furniture {
public:
    int id;
    std::string name;
    int quantity;
    double price;
    int supplierId;
};

class InventoryManagement {
    std::vector<Furniture> furnitures;
    std::vector<Supplier> suppliers;
    
    int getFurnitureIndex(int id) {
        for (size_t i = 0; i < furnitures.size(); ++i) {
            if (furnitures[i].id == id) return i;
        }
        return -1;
    }
    
    int getSupplierIndex(int id) {
        for (size_t i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].id == id) return i;
        }
        return -1;
    }
    
public:
    void addFurniture(int id, const std::string& name, int quantity, double price, int supplierId) {
        furnitures.push_back({id, name, quantity, price, supplierId});
    }
    
    void deleteFurniture(int id) {
        int index = getFurnitureIndex(id);
        if (index != -1) {
            furnitures.erase(furnitures.begin() + index);
        }
    }
    
    void updateFurniture(int id, const std::string& name, int quantity, double price, int supplierId) {
        int index = getFurnitureIndex(id);
        if (index != -1) {
            furnitures[index] = {id, name, quantity, price, supplierId};
        }
    }
    
    Furniture* searchFurniture(int id) {
        int index = getFurnitureIndex(id);
        if (index != -1) {
            return &furnitures[index];
        }
        return nullptr;
    }
    
    void displayFurnitures() {
        for (const auto& furniture : furnitures) {
            std::cout << "ID: " << furniture.id << " Name: " << furniture.name 
                      << " Quantity: " << furniture.quantity << " Price: " << furniture.price 
                      << " Supplier ID: " << furniture.supplierId << "\n";
        }
    }
    
    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.push_back({id, name, contact});
    }
    
    void deleteSupplier(int id) {
        int index = getSupplierIndex(id);
        if (index != -1) {
            suppliers.erase(suppliers.begin() + index);
        }
    }
    
    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        int index = getSupplierIndex(id);
        if (index != -1) {
            suppliers[index] = {id, name, contact};
        }
    }
    
    Supplier* searchSupplier(int id) {
        int index = getSupplierIndex(id);
        if (index != -1) {
            return &suppliers[index];
        }
        return nullptr;
    }
    
    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << " Name: " << supplier.name
                      << " Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addSupplier(1, "Supplier A", "123-456-7890");
    inventory.addFurniture(101, "Chair", 50, 25.75, 1);
    inventory.addFurniture(102, "Table", 20, 75.50, 1);

    std::cout << "Suppliers:\n";
    inventory.displaySuppliers();
    
    std::cout << "\nFurnitures:\n";
    inventory.displayFurnitures();
    
    Furniture* furniture = inventory.searchFurniture(101);
    if (furniture) {
        std::cout << "\nSearched Furniture ID 101: " << furniture->name << "\n";
    }

    inventory.updateFurniture(101, "Recliner", 40, 45.99, 1);
    std::cout << "\nUpdated Furniture List:\n";
    inventory.displayFurnitures();
    
    inventory.deleteFurniture(102);
    std::cout << "\nFurniture List After Deletion:\n";
    inventory.displayFurnitures();
    
    return 0;
}