#include <iostream>
#include <vector>
#include <string>

struct Publisher {
    int id;
    std::string name;
    std::string address;
};

struct Book {
    int id;
    std::string title;
    std::string author;
    int publisherId;
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;
    int bookCounter = 1;
    int publisherCounter = 1;

public:
    void addPublisher(const std::string& name, const std::string& address) {
        Publisher publisher{publisherCounter++, name, address};
        publishers.push_back(publisher);
    }

    void addBook(const std::string& title, const std::string& author, int publisherId) {
        Book book{bookCounter++, title, author, publisherId};
        books.push_back(book);
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }

        books.erase(std::remove_if(books.begin(), books.end(), [id](const Book& book) {
            return book.publisherId == id;
        }), books.end());
    }

    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(), [id](const Book& book) {
            return book.id == id;
        }), books.end());
    }

    void updatePublisher(int id, const std::string& name, const std::string& address) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = name;
                publisher.address = address;
                break;
            }
        }
    }

    void updateBook(int id, const std::string& title, const std::string& author, int publisherId) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                book.publisherId = publisherId;
                break;
            }
        }
    }

    Publisher* searchPublisher(int id) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id
                      << ", Name: " << publisher.name
                      << ", Address: " << publisher.address << std::endl;
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id
                      << ", Title: " << book.title
                      << ", Author: " << book.author
                      << ", Publisher ID: " << book.publisherId << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("O'Reilly Media", "1005 Gravenstein Highway North");
    system.addPublisher("Penguin Books", "80 Strand, London");

    system.addBook("C++ Programming", "Bjarne Stroustrup", 1);
    system.addBook("The Catcher in the Rye", "J.D. Salinger", 2);

    system.displayPublishers();
    system.displayBooks();

    system.updatePublisher(1, "O'Reilly Media, Inc.", "1005 Gravenstein Highway North, CA");
    system.updateBook(1, "The C++ Programming Language", "Bjarne Stroustrup", 1);

    system.displayPublishers();
    system.displayBooks();

    system.deleteBook(2);
    system.deletePublisher(2);

    system.displayPublishers();
    system.displayBooks();

    return 0;
}