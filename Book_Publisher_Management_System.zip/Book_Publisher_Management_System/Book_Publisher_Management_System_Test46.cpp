#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Publisher {
public:
    int id;
    string name;
    string address;

    Publisher(int i, string n, string a) : id(i), name(n), address(a) {}
};

class Book {
public:
    int id;
    string title;
    string author;
    int publisherId;

    Book(int i, string t, string a, int pId) : id(i), title(t), author(a), publisherId(pId) {}
};

class ManagementSystem {
    vector<Publisher> publishers;
    vector<Book> books;

public:
    void addPublisher(int id, string name, string address) {
        publishers.push_back(Publisher(id, name, address));
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, string newName, string newAddress) {
        for (auto &pub : publishers) {
            if (pub.id == id) {
                pub.name = newName;
                pub.address = newAddress;
                break;
            }
        }
    }

    Publisher* searchPublisher(int id) {
        for (auto &pub : publishers) {
            if (pub.id == id) return &pub;
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto &pub : publishers) {
            cout << "Publisher ID: " << pub.id << ", Name: " << pub.name << ", Address: " << pub.address << endl;
        }
    }

    void addBook(int id, string title, string author, int publisherId) {
        books.push_back(Book(id, title, author, publisherId));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string newTitle, string newAuthor, int newPublisherId) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = newTitle;
                book.author = newAuthor;
                book.publisherId = newPublisherId;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto &book : books) {
            if (book.id == id) return &book;
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto &book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title 
                 << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << endl;
        }
    }
};

int main() {
    ManagementSystem system;

    system.addPublisher(1, "Publisher One", "1234 Street A");
    system.addPublisher(2, "Publisher Two", "5678 Street B");
    
    system.addBook(101, "Book A", "Author A", 1);
    system.addBook(102, "Book B", "Author B", 2);

    cout << "Publishers:" << endl;
    system.displayPublishers();

    cout << "Books:" << endl;
    system.displayBooks();

    system.updatePublisher(1, "Publisher One Updated", "5678 Street A Updated");
    system.updateBook(101, "Book A Updated", "Author A Updated", 1);

    cout << "Updated Publishers:" << endl;
    system.displayPublishers();

    cout << "Updated Books:" << endl;
    system.displayBooks();

    system.deletePublisher(2);
    system.deleteBook(102);

    cout << "Final Publishers:" << endl;
    system.displayPublishers();

    cout << "Final Books:" << endl;
    system.displayBooks();

    return 0;
}