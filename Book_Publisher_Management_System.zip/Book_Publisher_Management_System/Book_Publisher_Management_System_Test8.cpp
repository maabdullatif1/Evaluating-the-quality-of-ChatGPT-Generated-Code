#include <iostream>
#include <vector>
#include <string>

struct Publisher {
    int id;
    std::string name;
};

struct Book {
    int id;
    std::string title;
    Publisher publisher;
};

class ManagementSystem {
    std::vector<Book> books;
    std::vector<Publisher> publishers;
    int bookIdCounter;
    int publisherIdCounter;

public:
    ManagementSystem() : bookIdCounter(1), publisherIdCounter(1) {}

    void addPublisher(const std::string& name) {
        Publisher publisher = {publisherIdCounter++, name};
        publishers.push_back(publisher);
    }

    void deletePublisher(int id) {
        publishers.erase(std::remove_if(publishers.begin(), publishers.end(), [id](const Publisher& p) {
            return p.id == id;
        }), publishers.end());

        books.erase(std::remove_if(books.begin(), books.end(), [id](const Book& b) {
            return b.publisher.id == id;
        }), books.end());
    }

    void updatePublisher(int id, const std::string& name) {
        for (auto& p : publishers) {
            if (p.id == id) {
                p.name = name;
                break;
            }
        }
    }

    void addBook(const std::string& title, int publisherId) {
        for (const auto& p : publishers) {
            if (p.id == publisherId) {
                Book book = {bookIdCounter++, title, p};
                books.push_back(book);
                return;
            }
        }
    }

    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(), [id](const Book& b) {
            return b.id == id;
        }), books.end());
    }

    void updateBook(int id, const std::string& title, int publisherId) {
        for (auto& b : books) {
            if (b.id == id) {
                for (const auto& p : publishers) {
                    if (p.id == publisherId) {
                        b.title = title;
                        b.publisher = p;
                        return;
                    }
                }
            }
        }
    }

    Book* searchBookByTitle(const std::string& title) {
        for (auto& b : books) {
            if (b.title == title) {
                return &b;
            }
        }
        return nullptr;
    }

    Publisher* searchPublisherByName(const std::string& name) {
        for (auto& p : publishers) {
            if (p.name == name) {
                return &p;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& b : books) {
            std::cout << "Book ID: " << b.id << ", Title: " << b.title << ", Publisher: " << b.publisher.name << "\n";
        }
    }

    void displayPublishers() {
        for (const auto& p : publishers) {
            std::cout << "Publisher ID: " << p.id << ", Name: " << p.name << "\n";
        }
    }
};

int main() {
    ManagementSystem ms;
    ms.addPublisher("Penguin");
    ms.addPublisher("HarperCollins");
    ms.addBook("1984", 1);
    ms.addBook("To Kill a Mockingbird", 2);
    ms.displayBooks();
    ms.displayPublishers();
    Book* book = ms.searchBookByTitle("1984");
    if (book) {
        std::cout << "Found Book: " << book->title << " by " << book->publisher.name << "\n";
    }
    Publisher* publisher = ms.searchPublisherByName("HarperCollins");
    if (publisher) {
        std::cout << "Found Publisher: " << publisher->name << "\n";
    }
    return 0;
}