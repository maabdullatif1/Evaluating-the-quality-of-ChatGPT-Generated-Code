#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    std::string address;

    Publisher(int id, std::string name, std::string address)
        : id(id), name(name), address(address) {}
};

class Book {
public:
    int id;
    std::string title;
    std::string author;
    int publisherId;

    Book(int id, std::string title, std::string author, int publisherId)
        : id(id), title(title), author(author), publisherId(publisherId) {}
};

class ManagementSystem {
public:
    std::vector<Publisher> publishers;
    std::vector<Book> books;

    void addPublisher(int id, std::string name, std::string address) {
        publishers.push_back(Publisher(id, name, address));
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, std::string name, std::string address) {
        for (auto &pub : publishers) {
            if (pub.id == id) {
                pub.name = name;
                pub.address = address;
                break;
            }
        }
    }

    Publisher* searchPublisher(int id) {
        for (auto &pub : publishers) {
            if (pub.id == id) {
                return &pub;
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto &pub : publishers) {
            std::cout << "Publisher ID: " << pub.id << ", Name: " << pub.name
                      << ", Address: " << pub.address << std::endl;
        }
    }

    void addBook(int id, std::string title, std::string author, int publisherId) {
        books.push_back(Book(id, title, author, publisherId));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string title, std::string author, int publisherId) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                book.publisherId = publisherId;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto &book : books) {
            Publisher* pub = searchPublisher(book.publisherId);
            std::cout << "Book ID: " << book.id
                      << ", Title: " << book.title
                      << ", Author: " << book.author
                      << ", Publisher Name: " << (pub ? pub->name : "Unknown") 
                      << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "Publisher A", "123 Main St");
    system.addPublisher(2, "Publisher B", "456 Elm St");

    system.addBook(1, "Book One", "Author A", 1);
    system.addBook(2, "Book Two", "Author B", 2);

    system.displayPublishers();
    system.displayBooks();

    return 0;
}