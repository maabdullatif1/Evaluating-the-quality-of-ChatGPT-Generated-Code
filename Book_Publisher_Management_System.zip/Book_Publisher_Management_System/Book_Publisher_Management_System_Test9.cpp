#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Publisher {
public:
    string name;
    string address;

    Publisher(string n, string a) : name(n), address(a) {}
};

class Book {
public:
    string title;
    string author;
    Publisher publisher;

    Book(string t, string a, Publisher p) : title(t), author(a), publisher(p) {}
};

class System {
private:
    vector<Book> books;
    vector<Publisher> publishers;

    int findPublisher(string name) {
        for (int i = 0; i < publishers.size(); ++i) {
            if (publishers[i].name == name) return i;
        }
        return -1;
    }

    int findBook(string title) {
        for (int i = 0; i < books.size(); ++i) {
            if (books[i].title == title) return i;
        }
        return -1;
    }

public:
    void addPublisher(string name, string address) {
        if (findPublisher(name) == -1) {
            publishers.push_back(Publisher(name, address));
        }
    }

    void deletePublisher(string name) {
        int index = findPublisher(name);
        if (index != -1) {
            publishers.erase(publishers.begin() + index);
        }
    }

    void updatePublisher(string name, string newAddress) {
        int index = findPublisher(name);
        if (index != -1) {
            publishers[index].address = newAddress;
        }
    }

    void addBook(string title, string author, string publisherName) {
        int index = findPublisher(publisherName);
        if (index != -1) {
            books.push_back(Book(title, author, publishers[index]));
        }
    }

    void deleteBook(string title) {
        int index = findBook(title);
        if (index != -1) {
            books.erase(books.begin() + index);
        }
    }

    void updateBook(string title, string newAuthor, string newPublisherName) {
        int index = findBook(title);
        if (index != -1) {
            books[index].author = newAuthor;
            int pubIndex = findPublisher(newPublisherName);
            if (pubIndex != -1) {
                books[index].publisher = publishers[pubIndex];
            }
        }
    }

    void searchBook(string title) {
        int index = findBook(title);
        if (index != -1) {
            cout << "Book: " << books[index].title << ", Author: " << books[index].author
                 << ", Publisher: " << books[index].publisher.name << endl;
        } else {
            cout << "Book not found" << endl;
        }
    }

    void searchPublisher(string name) {
        int index = findPublisher(name);
        if (index != -1) {
            cout << "Publisher: " << publishers[index].name 
                 << ", Address: " << publishers[index].address << endl;
        } else {
            cout << "Publisher not found" << endl;
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "Book: " << book.title << ", Author: " << book.author 
                 << ", Publisher: " << book.publisher.name << endl;
        }
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            cout << "Publisher: " << publisher.name << ", Address: " << publisher.address << endl;
        }
    }
};

int main() {
    System system;
    system.addPublisher("Penguin", "123 Penguin Rd");
    system.addPublisher("HarperCollins", "456 Harper St");
    
    system.addBook("1984", "George Orwell", "Penguin");
    system.addBook("Brave New World", "Aldous Huxley", "HarperCollins");
    
    system.displayBooks();
    system.displayPublishers();
    
    system.updatePublisher("Penguin", "789 New Penguin Rd");
    system.updateBook("1984", "G. Orwell", "HarperCollins");
    
    system.searchBook("1984");
    system.searchPublisher("Penguin");
    
    system.deleteBook("1984");
    system.deletePublisher("HarperCollins");
    
    system.displayBooks();
    system.displayPublishers();

    return 0;
}