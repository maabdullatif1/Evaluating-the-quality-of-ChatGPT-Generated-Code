#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    std::string address;

    Publisher(int id, std::string name, std::string address) 
        : id(id), name(name), address(address) {}
};

class Book {
public:
    int isbn;
    std::string title;
    int publisherId;

    Book(int isbn, std::string title, int publisherId) 
        : isbn(isbn), title(title), publisherId(publisherId) {}
};

class PublisherManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;

    Publisher* findPublisherById(int id) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) 
                return &publisher;
        }
        return nullptr;
    }

    Book* findBookByISBN(int isbn) {
        for (auto &book : books) {
            if (book.isbn == isbn) 
                return &book;
        }
        return nullptr;
    }

public:
    void addPublisher(int id, std::string name, std::string address) {
        publishers.emplace_back(id, name, address);
    }

    void addBook(int isbn, std::string title, int publisherId) {
        if (findPublisherById(publisherId)) {
            books.emplace_back(isbn, title, publisherId);
        }
    }

    void deletePublisher(int id) {
        publishers.erase(std::remove_if(publishers.begin(), publishers.end(), 
            [id](Publisher &p) { return p.id == id; }), publishers.end());
        books.erase(std::remove_if(books.begin(), books.end(), 
            [id](Book &b) { return b.publisherId == id; }), books.end());
    }

    void deleteBook(int isbn) {
        books.erase(std::remove_if(books.begin(), books.end(), 
            [isbn](Book &b) { return b.isbn == isbn; }), books.end());
    }

    void updatePublisher(int id, std::string name, std::string address) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            publisher->name = name;
            publisher->address = address;
        }
    }

    void updateBook(int isbn, std::string title, int publisherId) {
        Book* book = findBookByISBN(isbn);
        if (book) {
            book->title = title;
            book->publisherId = publisherId;
        }
    }

    void searchPublisherById(int id) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            std::cout << "Publisher ID: " << publisher->id 
                      << ", Name: " << publisher->name 
                      << ", Address: " << publisher->address << "\n";
        } else {
            std::cout << "Publisher not found.\n";
        }
    }

    void searchBookByISBN(int isbn) {
        Book* book = findBookByISBN(isbn);
        if (book) {
            std::cout << "ISBN: " << book->isbn 
                      << ", Title: " << book->title 
                      << ", Publisher ID: " << book->publisherId << "\n";
        } else {
            std::cout << "Book not found.\n";
        }
    }

    void displayAllPublishers() {
        for (const auto &publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id 
                      << ", Name: " << publisher.name 
                      << ", Address: " << publisher.address << "\n";
        }
    }

    void displayAllBooks() {
        for (const auto &book : books) {
            std::cout << "ISBN: " << book.isbn 
                      << ", Title: " << book.title 
                      << ", Publisher ID: " << book.publisherId << "\n";
        }
    }
};

int main() {
    PublisherManagementSystem system;

    system.addPublisher(1, "Random House", "123 Main St");
    system.addBook(101, "C++ Programming", 1);

    system.displayAllPublishers();
    system.displayAllBooks();

    system.searchPublisherById(1);
    system.searchBookByISBN(101);

    system.updatePublisher(1, "Penguin Random House", "456 Elm St");
    system.updateBook(101, "Advanced C++ Programming", 1);

    system.displayAllPublishers();
    system.displayAllBooks();

    system.deleteBook(101);
    system.deletePublisher(1);

    system.displayAllPublishers();
    system.displayAllBooks();

    return 0;
}