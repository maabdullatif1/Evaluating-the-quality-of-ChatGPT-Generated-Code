#include <iostream>
#include <vector>
#include <string>

struct Publisher {
    int id;
    std::string name;
};

struct Book {
    int id;
    std::string title;
    int publisher_id;
};

class ManagementSystem {
    std::vector<Publisher> publishers;
    std::vector<Book> books;
    int publisherCounter = 0;
    int bookCounter = 0;

public:
    void addPublisher(const std::string& name) {
        publishers.push_back({publisherCounter++, name});
    }
    
    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }
    
    void updatePublisher(int id, const std::string& name) {
        for (auto& pub : publishers) {
            if (pub.id == id) {
                pub.name = name;
                break;
            }
        }
    }
    
    void searchPublisher(int id) {
        for (const auto& pub : publishers) {
            if (pub.id == id) {
                std::cout << "Publisher ID: " << pub.id << ", Name: " << pub.name << "\n";
                return;
            }
        }
        std::cout << "Publisher not found\n";
    }
    
    void displayPublishers() {
        for (const auto& pub : publishers) {
            std::cout << "Publisher ID: " << pub.id << ", Name: " << pub.name << "\n";
        }
    }
    
    void addBook(const std::string& title, int publisher_id) {
        books.push_back({bookCounter++, title, publisher_id});
    }
    
    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }
    
    void updateBook(int id, const std::string& title, int publisher_id) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.publisher_id = publisher_id;
                break;
            }
        }
    }
    
    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisher_id << "\n";
                return;
            }
        }
        std::cout << "Book not found\n";
    }
    
    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisher_id << "\n";
        }
    }
};

int main() {
    ManagementSystem system;
    
    system.addPublisher("Publisher A");
    system.addPublisher("Publisher B");
    system.displayPublishers();
    
    system.addBook("Book 1", 0);
    system.addBook("Book 2", 1);
    system.displayBooks();
    
    system.updateBook(0, "Updated Book 1", 1);
    system.displayBooks();
    
    system.deleteBook(0);
    system.displayBooks();
    
    system.searchPublisher(0);
    system.searchBook(1);
    
    return 0;
}