#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Book {
public:
    int id;
    string title;
    string author;
    int publisherId;
    Book(int id, string title, string author, int publisherId)
        : id(id), title(title), author(author), publisherId(publisherId) {}
};

class Publisher {
public:
    int id;
    string name;
    vector<Book> books;
    Publisher(int id, string name) : id(id), name(name) {}
};

class PublisherManagementSystem {
private:
    vector<Publisher> publishers;
    int bookCounter = 0;
    int publisherCounter = 0;
    
    Publisher* findPublisherById(int id) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    Book* findBookById(int id) {
        for (auto& publisher : publishers) {
            for (auto& book : publisher.books) {
                if (book.id == id) {
                    return &book;
                }
            }
        }
        return nullptr;
    }

public:
    void addPublisher(string name) {
        publishers.push_back(Publisher(++publisherCounter, name));
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, string name) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            publisher->name = name;
        }
    }

    void addBook(string title, string author, int publisherId) {
        Publisher* publisher = findPublisherById(publisherId);
        if (publisher) {
            publisher->books.push_back(Book(++bookCounter, title, author, publisherId));
        }
    }

    void deleteBook(int id) {
        for (auto& publisher : publishers) {
            for (auto it = publisher.books.begin(); it != publisher.books.end(); ++it) {
                if (it->id == id) {
                    publisher.books.erase(it);
                    return;
                }
            }
        }
    }

    void updateBook(int id, string title, string author) {
        Book* book = findBookById(id);
        if (book) {
            book->title = title;
            book->author = author;
        }
    }

    void searchBook(int id) {
        Book* book = findBookById(id);
        if (book) {
            cout << "Book ID: " << book->id << ", Title: " << book->title << ", Author: " << book->author << ", Publisher ID: " << book->publisherId << endl;
        } else {
            cout << "Book not found." << endl;
        }
    }

    void searchPublisher(int id) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            cout << "Publisher ID: " << publisher->id << ", Name: " << publisher->name << endl;
        } else {
            cout << "Publisher not found." << endl;
        }
    }

    void displayBooks() {
        for (const auto& publisher : publishers) {
            for (const auto& book : publisher.books) {
                cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << endl;
            }
        }
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << endl;
        }
    }
};

int main() {
    PublisherManagementSystem pms;
    pms.addPublisher("Penguin");
    pms.addPublisher("HarperCollins");
    pms.addBook("1984", "George Orwell", 1);
    pms.addBook("Animal Farm", "George Orwell", 1);
    pms.displayBooks();
    pms.displayPublishers();
    pms.searchBook(1);
    pms.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    pms.searchBook(1);
    pms.deleteBook(2);
    pms.displayBooks();
    pms.updatePublisher(2, "Harper & Collins");
    pms.searchPublisher(2);
    pms.deletePublisher(1);
    pms.displayPublishers();
    return 0;
}