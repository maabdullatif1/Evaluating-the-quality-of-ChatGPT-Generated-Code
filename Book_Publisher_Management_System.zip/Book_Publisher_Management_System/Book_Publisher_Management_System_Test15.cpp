#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Publisher {
public:
    string name;
    string address;
    string phone;

    Publisher(string n, string addr, string ph) : name(n), address(addr), phone(ph) {}
};

class Book {
public:
    string title;
    string author;
    string isbn;
    Publisher* publisher;

    Book(string t, string a, string i, Publisher* p) : title(t), author(a), isbn(i), publisher(p) {}
};

class ManagementSystem {
private:
    vector<Publisher> publishers;
    vector<Book> books;

public:
    void addPublisher(const string& name, const string& address, const string& phone) {
        publishers.emplace_back(name, address, phone);
    }

    void deletePublisher(const string& name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->name == name) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(const string& name, const string& newAddress, const string& newPhone) {
        for (auto& publisher : publishers) {
            if (publisher.name == name) {
                publisher.address = newAddress;
                publisher.phone = newPhone;
            }
        }
    }

    Publisher* searchPublisher(const string& name) {
        for (auto& publisher : publishers) {
            if (publisher.name == name) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void addBook(const string& title, const string& author, const string& isbn, const string& publisherName) {
        Publisher* pub = searchPublisher(publisherName);
        if (pub != nullptr) {
            books.emplace_back(title, author, isbn, pub);
        }
    }

    void deleteBook(const string& isbn) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->isbn == isbn) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(const string& isbn, const string& newTitle, const string& newAuthor, const string& newPublisherName) {
        for (auto& book : books) {
            if (book.isbn == isbn) {
                book.title = newTitle;
                book.author = newAuthor;
                book.publisher = searchPublisher(newPublisherName);
            }
        }
    }

    Book* searchBook(const string& isbn) {
        for (auto& book : books) {
            if (book.isbn == isbn) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            cout << "Name: " << publisher.name << ", Address: " << publisher.address << ", Phone: " << publisher.phone << endl;
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "Title: " << book.title << ", Author: " << book.author << ", ISBN: " << book.isbn << ", Publisher: " << book.publisher->name << endl;
        }
    }
};

int main() {
    ManagementSystem ms;
    ms.addPublisher("Publisher1", "Address1", "123456789");
    ms.addPublisher("Publisher2", "Address2", "987654321");

    ms.addBook("Book1", "Author1", "111111", "Publisher1");
    ms.addBook("Book2", "Author2", "222222", "Publisher1");
    ms.addBook("Book3", "Author3", "333333", "Publisher2");

    cout << "All Publishers:" << endl;
    ms.displayPublishers();
    cout << "\nAll Books:" << endl;
    ms.displayBooks();

    ms.updateBook("111111", "Updated Book1", "Updated Author1", "Publisher2");
    ms.deletePublisher("Publisher1");

    cout << "\nAfter Updates:" << endl;
    cout << "All Publishers:" << endl;
    ms.displayPublishers();
    cout << "\nAll Books:" << endl;
    ms.displayBooks();

    return 0;
}