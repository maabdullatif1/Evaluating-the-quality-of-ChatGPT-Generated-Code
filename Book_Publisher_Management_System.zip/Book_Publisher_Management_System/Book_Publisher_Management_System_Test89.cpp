#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    std::string name;
    std::string address;
    std::string phone;
    
    Publisher(std::string n, std::string a, std::string p) 
        : name(n), address(a), phone(p) {}
};

class Book {
public:
    std::string title;
    std::string author;
    std::string isbn;
    Publisher* publisher;
    
    Book(std::string t, std::string a, std::string i, Publisher* p) 
        : title(t), author(a), isbn(i), publisher(p) {}
};

class ManagementSystem {
    std::vector<Publisher> publishers;
    std::vector<Book> books;

public:
    void addPublisher(const std::string& name, const std::string& address, const std::string& phone) {
        publishers.emplace_back(name, address, phone);
    }

    void addBook(const std::string& title, const std::string& author, const std::string& isbn, const std::string& publisherName) {
        for (auto& pub : publishers) {
            if (pub.name == publisherName) {
                books.emplace_back(title, author, isbn, &pub);
                return;
            }
        }
    }

    void deletePublisher(const std::string& name) {
        auto it = std::remove_if(publishers.begin(), publishers.end(), [&](Publisher& pub) {
            return pub.name == name;
        });
        publishers.erase(it, publishers.end());
        books.erase(std::remove_if(books.begin(), books.end(), [&](Book& book) {
            return book.publisher->name == name;
        }), books.end());
    }

    void deleteBook(const std::string& isbn) {
        auto it = std::remove_if(books.begin(), books.end(), [&](Book& book) {
            return book.isbn == isbn;
        });
        books.erase(it, books.end());
    }

    void updatePublisher(const std::string& oldName, const std::string& newName, const std::string& newAddress, const std::string& newPhone) {
        for (auto& pub : publishers) {
            if (pub.name == oldName) {
                pub.name = newName;
                pub.address = newAddress;
                pub.phone = newPhone;
            }
        }
    }

    void updateBook(const std::string& isbn, const std::string& newTitle, const std::string& newAuthor) {
        for (auto& book : books) {
            if (book.isbn == isbn) {
                book.title = newTitle;
                book.author = newAuthor;
            }
        }
    }

    void searchBooksByTitle(const std::string& title) {
        for (const auto& book : books) {
            if (book.title == title) {
                std::cout << book.title << ", " << book.author << ", " << book.isbn << ", " << book.publisher->name << std::endl;
            }
        }
    }

    void searchPublishersByName(const std::string& name) {
        for (const auto& pub : publishers) {
            if (pub.name == name) {
                std::cout << pub.name << ", " << pub.address << ", " << pub.phone << std::endl;
            }
        }
    }

    void displayAllBooks() {
        for (const auto& book : books) {
            std::cout << book.title << ", " << book.author << ", " << book.isbn << ", " << book.publisher->name << std::endl;
        }
    }

    void displayAllPublishers() {
        for (const auto& pub : publishers) {
            std::cout << pub.name << ", " << pub.address << ", " << pub.phone << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("Pub1", "Address1", "Phone1");
    system.addPublisher("Pub2", "Address2", "Phone2");

    system.addBook("Title1", "Author1", "ISBN1", "Pub1");
    system.addBook("Title2", "Author2", "ISBN2", "Pub2");

    std::cout << "All Books:" << std::endl;
    system.displayAllBooks();
    std::cout << std::endl;
    
    std::cout << "All Publishers:" << std::endl;
    system.displayAllPublishers();
    std::cout << std::endl;

    std::cout << "Search Book by Title (Title1):" << std::endl;
    system.searchBooksByTitle("Title1");
    std::cout << std::endl;

    std::cout << "Search Publisher by Name (Pub1):" << std::endl;
    system.searchPublishersByName("Pub1");
    std::cout << std::endl;

    system.updateBook("ISBN1", "UpdatedTitle1", "UpdatedAuthor1");
    system.updatePublisher("Pub1", "UpdatedPub1", "UpdatedAddress1", "UpdatedPhone1");

    std::cout << "All Books after update:" << std::endl;
    system.displayAllBooks();
    std::cout << std::endl;
    
    std::cout << "All Publishers after update:" << std::endl;
    system.displayAllPublishers();
    std::cout << std::endl;

    system.deleteBook("ISBN1");
    system.deletePublisher("UpdatedPub1");

    std::cout << "All Books after delete:" << std::endl;
    system.displayAllBooks();
    std::cout << std::endl;
    
    std::cout << "All Publishers after delete:" << std::endl;
    system.displayAllPublishers();
    std::cout << std::endl;

    return 0;
}