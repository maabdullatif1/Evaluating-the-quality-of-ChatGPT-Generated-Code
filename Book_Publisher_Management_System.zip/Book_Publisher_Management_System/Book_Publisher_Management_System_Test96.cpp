#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

class Publisher {
public:
    int id;
    std::string name;
    std::string address;
    
    Publisher(int id, const std::string& name, const std::string& address)
        : id(id), name(name), address(address) {}
};

class Book {
public:
    int id;
    std::string title;
    std::string author;
    Publisher* publisher;

    Book(int id, const std::string& title, const std::string& author, Publisher* publisher)
        : id(id), title(title), author(author), publisher(publisher) {}
};

class ManagementSystem {
    std::vector<Publisher> publishers;
    std::vector<Book> books;

    Publisher* findPublisher(int id) {
        for (auto& pub : publishers) {
            if (pub.id == id)
                return &pub;
        }
        return nullptr;
    }

    Book* findBook(int id) {
        for (auto& book : books) {
            if (book.id == id)
                return &book;
        }
        return nullptr;
    }

public:
    void addPublisher(int id, const std::string& name, const std::string& address) {
        publishers.emplace_back(id, name, address);
    }

    void deletePublisher(int id) {
        publishers.erase(std::remove_if(publishers.begin(), publishers.end(),
                       [id](const Publisher& p) { return p.id == id; }), publishers.end());
    }

    void updatePublisher(int id, const std::string& name, const std::string& address) {
        for (auto& pub : publishers) {
            if (pub.id == id) {
                pub.name = name;
                pub.address = address;
            }
        }
    }

    void addBook(int id, const std::string& title, const std::string& author, int publisherId) {
        Publisher* pub = findPublisher(publisherId);
        if (pub != nullptr) {
            books.emplace_back(id, title, author, pub);
        }
    }

    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(),
                   [id](const Book& b) { return b.id == id; }), books.end());
    }

    void updateBook(int id, const std::string& title, const std::string& author, int publisherId) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                book.publisher = findPublisher(publisherId);
            }
        }
    }

    void searchBook(int id) {
        Book* book = findBook(id);
        if (book != nullptr) {
            std::cout << "Book ID: " << book->id << "\nTitle: " << book->title
                      << "\nAuthor: " << book->author << "\nPublisher: " << book->publisher->name << "\n";
        } else {
            std::cout << "Book not found.\n";
        }
    }

    void searchPublisher(int id) {
        Publisher* pub = findPublisher(id);
        if (pub != nullptr) {
            std::cout << "Publisher ID: " << pub->id << "\nName: " << pub->name
                      << "\nAddress: " << pub->address << "\n";
        } else {
            std::cout << "Publisher not found.\n";
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << "\nTitle: " << book.title
                      << "\nAuthor: " << book.author << "\nPublisher: " << book.publisher->name << "\n";
        }
    }

    void displayPublishers() {
        for (const auto& pub : publishers) {
            std::cout << "Publisher ID: " << pub.id << "\nName: " << pub.name
                      << "\nAddress: " << pub.address << "\n";
        }
    }
};

int main() {
    ManagementSystem ms;

    ms.addPublisher(1, "Penguin", "123 Book St");
    ms.addBook(101, "C++ Primer", "Lippman", 1);

    ms.displayPublishers();
    ms.displayBooks();

    ms.updateBook(101, "C++ Primer Plus", "Lippman", 1);
    ms.searchBook(101);

    ms.deleteBook(101);

    ms.displayBooks();

    return 0;
}