#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Publisher {
public:
    int id;
    string name;
    string address;

    Publisher(int id, string name, string address) : id(id), name(name), address(address) {}

    void display() {
        cout << "Publisher ID: " << id << ", Name: " << name << ", Address: " << address << endl;
    }
};

class Book {
public:
    int id;
    string title;
    string author;
    int publisherId;

    Book(int id, string title, string author, int publisherId) 
        : id(id), title(title), author(author), publisherId(publisherId) {}

    void display() {
        cout << "Book ID: " << id << ", Title: " << title << ", Author: " << author << ", Publisher ID: " << publisherId << endl;
    }
};

class ManagementSystem {
    vector<Publisher> publishers;
    vector<Book> books;

public:
    void addPublisher(int id, string name, string address) {
        publishers.push_back(Publisher(id, name, address));
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, string name, string address) {
        for (auto &pub : publishers) {
            if (pub.id == id) {
                pub.name = name;
                pub.address = address;
                break;
            }
        }
    }

    void searchPublisher(int id) {
        for (const auto &pub : publishers) {
            if (pub.id == id) {
                pub.display();
                return;
            }
        }
        cout << "Publisher not found!" << endl;
    }

    void addBook(int id, string title, string author, int publisherId) {
        books.push_back(Book(id, title, author, publisherId));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string title, string author, int publisherId) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                book.publisherId = publisherId;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto &book : books) {
            if (book.id == id) {
                book.display();
                return;
            }
        }
        cout << "Book not found!" << endl;
    }

    void displayPublishers() {
        cout << "Publishers:" << endl;
        for (const auto &pub : publishers) {
            pub.display();
        }
    }

    void displayBooks() {
        cout << "Books:" << endl;
        for (const auto &book : books) {
            book.display();
        }
    }
};

int main() {
    ManagementSystem system;

    system.addPublisher(1, "Penguin Random House", "123 Publisher St.");
    system.addPublisher(2, "HarperCollins", "456 Publisher Ave.");
    
    system.addBook(101, "The Great Gatsby", "F. Scott Fitzgerald", 1);
    system.addBook(102, "To Kill a Mockingbird", "Harper Lee", 2);

    system.displayPublishers();
    system.displayBooks();

    system.searchPublisher(1);
    system.searchBook(101);

    system.updatePublisher(1, "Penguin Books", "789 New Address St.");
    system.updateBook(101, "The Great Gatsby: Revised", "F. Scott Fitzgerald", 1);

    system.displayPublishers();
    system.displayBooks();

    system.deletePublisher(2);
    system.deleteBook(102);

    system.displayPublishers();
    system.displayBooks();

    return 0;
}