#include <iostream>
#include <string>
#include <vector>

class Publisher {
public:
    std::string name;
    std::string address;
    
    Publisher(std::string name, std::string address) : name(name), address(address) {}
};

class Book {
public:
    std::string title;
    std::string author;
    std::string isbn;
    Publisher* publisher;
    
    Book(std::string title, std::string author, std::string isbn, Publisher* publisher)
        : title(title), author(author), isbn(isbn), publisher(publisher) {}
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;

    Publisher* findPublisherByName(const std::string& name) {
        for (auto &publisher : publishers) {
            if (publisher.name == name) {
                return &publisher;
            }
        }
        return nullptr;
    }

public:
    void addPublisher(const std::string& name, const std::string& address) {
        publishers.push_back(Publisher(name, address));
    }

    void deletePublisher(const std::string& name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->name == name) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(const std::string& name, const std::string& newAddress) {
        Publisher* publisher = findPublisherByName(name);
        if (publisher != nullptr) {
            publisher->address = newAddress;
        }
    }

    void addBook(const std::string& title, const std::string& author, const std::string& isbn, const std::string& publisherName) {
        Publisher* publisher = findPublisherByName(publisherName);
        if (publisher != nullptr) {
            books.push_back(Book(title, author, isbn, publisher));
        }
    }

    void deleteBook(const std::string& isbn) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->isbn == isbn) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(const std::string& isbn, const std::string& newTitle, const std::string& newAuthor, const std::string& newPublisherName) {
        for (auto &book : books) {
            if (book.isbn == isbn) {
                book.title = newTitle;
                book.author = newAuthor;
                book.publisher = findPublisherByName(newPublisherName);
                break;
            }
        }
    }

    void searchBookByTitle(const std::string& title) {
        for (const auto &book : books) {
            if (book.title == title) {
                std::cout << "Title: " << book.title << ", Author: " << book.author 
                          << ", ISBN: " << book.isbn << ", Publisher: " << book.publisher->name << std::endl;
            }
        }
    }

    void searchPublisherByName(const std::string& name) {
        for (const auto &publisher : publishers) {
            if (publisher.name == name) {
                std::cout << "Name: " << publisher.name << ", Address: " << publisher.address << std::endl;
            }
        }
    }

    void displayAllBooks() {
        for (const auto &book : books) {
            std::cout << "Title: " << book.title << ", Author: " << book.author 
                      << ", ISBN: " << book.isbn << ", Publisher: " << book.publisher->name << std::endl;
        }
    }

    void displayAllPublishers() {
        for (const auto &publisher : publishers) {
            std::cout << "Name: " << publisher.name << ", Address: " << publisher.address << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("Penguin", "123 Fiction Ave");
    system.addPublisher("HarperCollins", "456 Novel St");

    system.addBook("The Great Gatsby", "F. Scott Fitzgerald", "1234567890", "Penguin");
    system.addBook("Moby Dick", "Herman Melville", "2345678901", "HarperCollins");

    system.displayAllBooks();
    system.displayAllPublishers();

    system.updateBook("1234567890", "The Greatest Gatsby", "F. Scott Fitzgerald", "HarperCollins");
    system.searchBookByTitle("The Greatest Gatsby");

    system.deleteBook("2345678901");
    system.displayAllBooks();
    
    system.searchPublisherByName("Penguin");
    system.deletePublisher("Penguin");
    system.displayAllPublishers();

    return 0;
}