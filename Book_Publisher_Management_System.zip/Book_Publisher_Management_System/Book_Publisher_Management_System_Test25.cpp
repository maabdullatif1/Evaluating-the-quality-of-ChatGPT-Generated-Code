#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Publisher {
    string name;
    string address;
public:
    Publisher(string name, string address) : name(name), address(address) {}
    void update(string name, string address) {
        this->name = name;
        this->address = address;
    }
    string getName() const { return name; }
    string getAddress() const { return address; }
};

class Book {
    string title;
    string author;
    Publisher* publisher;
public:
    Book(string title, string author, Publisher* publisher)
        : title(title), author(author), publisher(publisher) {}
    void update(string title, string author, Publisher* publisher) {
        this->title = title;
        this->author = author;
        this->publisher = publisher;
    }
    string getTitle() const { return title; }
    string getAuthor() const { return author; }
    Publisher* getPublisher() const { return publisher; }
};

class ManagementSystem {
    vector<Publisher*> publishers;
    vector<Book*> books;
public:
    ~ManagementSystem() {
        for (auto publisher : publishers) delete publisher;
        for (auto book : books) delete book;
    }

    void addPublisher(string name, string address) {
        publishers.push_back(new Publisher(name, address));
    }

    void addBook(string title, string author, string publisherName) {
        Publisher* publisher = findPublisher(publisherName);
        if (publisher) {
            books.push_back(new Book(title, author, publisher));
        }
    }

    void deletePublisher(string name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if ((*it)->getName() == name) {
                delete *it;
                publishers.erase(it);
                break;
            }
        }
    }

    void deleteBook(string title) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if ((*it)->getTitle() == title) {
                delete *it;
                books.erase(it);
                break;
            }
        }
    }

    void updatePublisher(string name, string newName, string newAddress) {
        Publisher* publisher = findPublisher(name);
        if (publisher) {
            publisher->update(newName, newAddress);
        }
    }

    void updateBook(string title, string newTitle, string newAuthor, string publisherName) {
        Book* book = findBook(title);
        Publisher* publisher = findPublisher(publisherName);
        if (book && publisher) {
            book->update(newTitle, newAuthor, publisher);
        }
    }

    Publisher* findPublisher(string name) {
        for (auto publisher : publishers) {
            if (publisher->getName() == name) return publisher;
        }
        return nullptr;
    }

    Book* findBook(string title) {
        for (auto book : books) {
            if (book->getTitle() == title) return book;
        }
        return nullptr;
    }

    void displayPublishers() const {
        for (auto publisher : publishers) {
            cout << "Publisher: " << publisher->getName() 
                 << ", Address: " << publisher->getAddress() << endl;
        }
    }

    void displayBooks() const {
        for (auto book : books) {
            cout << "Book: " << book->getTitle() 
                 << ", Author: " << book->getAuthor() 
                 << ", Publisher: " << book->getPublisher()->getName() << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("Publisher A", "123 Street A");
    system.addPublisher("Publisher B", "456 Street B");
    system.addBook("Book 1", "Author A", "Publisher A");
    system.addBook("Book 2", "Author B", "Publisher B");
    system.displayPublishers();
    system.displayBooks();
    system.updateBook("Book 1", "Book 1 Updated", "Author A1", "Publisher B");
    system.displayBooks();
    system.deletePublisher("Publisher A");
    system.displayPublishers();
    system.deleteBook("Book 2");
    system.displayBooks();
    return 0;
}