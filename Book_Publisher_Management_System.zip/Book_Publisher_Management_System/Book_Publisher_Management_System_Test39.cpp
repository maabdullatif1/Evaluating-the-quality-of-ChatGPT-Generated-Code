#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    std::string title;
    std::string author;
    std::string ISBN;

    Book(std::string t, std::string a, std::string i) 
        : title(t), author(a), ISBN(i) {}
};

class Publisher {
public:
    std::string name;
    std::string address;
    std::vector<Book> books;

    Publisher(std::string n, std::string add) 
        : name(n), address(add) {}

    void addBook(const Book& book) {
        books.push_back(book);
    }

    void deleteBook(const std::string& isbn) {
        for(auto it = books.begin(); it != books.end(); ++it) {
            if(it->ISBN == isbn) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(const std::string& isbn, const std::string& newTitle, const std::string& newAuthor) {
        for(auto& book : books) {
            if(book.ISBN == isbn) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }

    Book* searchBook(const std::string& isbn) {
        for(auto& book : books) {
            if(book.ISBN == isbn) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() const {
        for(const auto& book : books) {
            std::cout << "Title: " << book.title << ", Author: " << book.author << ", ISBN: " << book.ISBN << std::endl;
        }
    }
};

class PublisherManager {
public:
    std::vector<Publisher> publishers;

    void addPublisher(const Publisher& publisher) {
        publishers.push_back(publisher);
    }

    void deletePublisher(const std::string& name) {
        for(auto it = publishers.begin(); it != publishers.end(); ++it) {
            if(it->name == name) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(const std::string& name, const std::string& newAddress) {
        for(auto& publisher : publishers) {
            if(publisher.name == name) {
                publisher.address = newAddress;
                break;
            }
        }
    }

    Publisher* searchPublisher(const std::string& name) {
        for(auto& publisher : publishers) {
            if(publisher.name == name) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void displayPublishers() const {
        for(const auto& publisher : publishers) {
            std::cout << "Publisher: " << publisher.name << ", Address: " << publisher.address << std::endl;
            publisher.displayBooks();
        }
    }
};

int main() {
    PublisherManager pm;
    Publisher p1("Publisher1", "123 Main St");
    p1.addBook(Book("Book1", "Author1", "ISBN1"));
    pm.addPublisher(p1);

    pm.displayPublishers();

    Publisher* p = pm.searchPublisher("Publisher1");
    if (p) p->addBook(Book("Book2", "Author2", "ISBN2"));

    pm.displayPublishers();
    
    return 0;
}