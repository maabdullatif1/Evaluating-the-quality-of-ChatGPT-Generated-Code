#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    Publisher(int id, std::string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;
    int publisherId;
    Book(int id, std::string title, int publisherId) : id(id), title(title), publisherId(publisherId) {}
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;

    Publisher* findPublisherById(int id) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) return &publisher;
        }
        return nullptr;
    }

    Book* findBookById(int id) {
        for (auto& book : books) {
            if (book.id == id) return &book;
        }
        return nullptr;
    }

public:
    void addPublisher(int id, std::string name) {
        publishers.push_back(Publisher(id, name));
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                return;
            }
        }
    }

    void updatePublisher(int id, std::string name) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            publisher->name = name;
        }
    }

    void addBook(int id, std::string title, int publisherId) {
        books.push_back(Book(id, title, publisherId));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                return;
            }
        }
    }

    void updateBook(int id, std::string title, int publisherId) {
        Book* book = findBookById(id);
        if (book) {
            book->title = title;
            book->publisherId = publisherId;
        }
    }

    void searchAndDisplayBook(int id) {
        Book* book = findBookById(id);
        if (book) {
            std::cout << "Book ID: " << book->id << ", Title: " << book->title 
                      << ", Publisher ID: " << book->publisherId << "\n";
        } else {
            std::cout << "Book not found\n";
        }
    }

    void searchAndDisplayPublisher(int id) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            std::cout << "Publisher ID: " << publisher->id << ", Name: " << publisher->name << "\n";
        } else {
            std::cout << "Publisher not found\n";
        }
    }

    void displayAllBooks() {
        if (books.empty()) {
            std::cout << "No books to display\n";
        } else {
            for (const auto& book : books) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title 
                          << ", Publisher ID: " << book.publisherId << "\n";
            }
        }
    }

    void displayAllPublishers() {
        if (publishers.empty()) {
            std::cout << "No publishers to display\n";
        } else {
            for (const auto& publisher : publishers) {
                std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << "\n";
            }
        }
    }
};

int main() {
    ManagementSystem system;

    system.addPublisher(1, "Penguin");
    system.addPublisher(2, "HarperCollins");

    system.addBook(101, "C++ Programming", 1);
    system.addBook(102, "Data Structures", 2);

    system.displayAllPublishers();
    system.displayAllBooks();

    system.searchAndDisplayPublisher(1);
    system.searchAndDisplayBook(101);

    system.updatePublisher(1, "Penguin Books");
    system.updateBook(101, "Advanced C++ Programming", 1);

    system.displayAllPublishers();
    system.displayAllBooks();

    system.deletePublisher(2);
    system.deleteBook(102);

    system.displayAllPublishers();
    system.displayAllBooks();

    return 0;
}