#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    std::string address;
    
    Publisher(int id, std::string name, std::string address)
        : id(id), name(name), address(address) {}
};

class Book {
public:
    int id;
    std::string title;
    std::string author;
    int publisherId;
    
    Book(int id, std::string title, std::string author, int publisherId)
        : id(id), title(title), author(author), publisherId(publisherId) {}
};

class ManagementSystem {
    std::vector<Publisher> publishers;
    std::vector<Book> books;
    
    Publisher* findPublisherById(int id) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) return &publisher;
        }
        return nullptr;
    }
    
    Book* findBookById(int id) {
        for (auto &book : books) {
            if (book.id == id) return &book;
        }
        return nullptr;
    }
    
public:
    void addPublisher(int id, std::string name, std::string address) {
        publishers.emplace_back(id, name, address);
    }
    
    void deletePublisher(int id) {
        publishers.erase(std::remove_if(publishers.begin(), publishers.end(),
                                        [id](Publisher &p){ return p.id == id; }), publishers.end());
    }
    
    void updatePublisher(int id, std::string name, std::string address) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            publisher->name = name;
            publisher->address = address;
        }
    }
    
    void displayPublishers() {
        for (auto &publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << ", Address: " << publisher.address << std::endl;
        }
    }
    
    void addBook(int id, std::string title, std::string author, int publisherId) {
        books.emplace_back(id, title, author, publisherId);
    }
    
    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(),
                                   [id](Book &b){ return b.id == id; }), books.end());
    }
    
    void updateBook(int id, std::string title, std::string author, int publisherId) {
        Book* book = findBookById(id);
        if (book) {
            book->title = title;
            book->author = author;
            book->publisherId = publisherId;
        }
    }
    
    void displayBooks() {
        for (auto &book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title 
                      << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << std::endl;
        }
    }
    
    void searchBookByTitle(std::string title) {
        for (auto &book : books) {
            if (book.title == title) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title 
                          << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << std::endl;
            }
        }
    }
    
    void searchPublisherByName(std::string name) {
        for (auto &publisher : publishers) {
            if (publisher.name == name) {
                std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name 
                          << ", Address: " << publisher.address << std::endl;
            }
        }
    }
};

int main() {
    ManagementSystem ms;
    ms.addPublisher(1, "Publisher One", "123 Main St");
    ms.addPublisher(2, "Publisher Two", "456 Side St");
    ms.addBook(1, "Book One", "Author One", 1);
    ms.addBook(2, "Book Two", "Author Two", 2);
    ms.addBook(3, "Book Three", "Author Three", 1);
    ms.displayPublishers();
    ms.displayBooks();
    ms.searchBookByTitle("Book One");
    ms.searchPublisherByName("Publisher One");
    ms.updateBook(1, "Updated Book One", "Updated Author One", 2);
    ms.deletePublisher(2);
    ms.displayBooks();
    ms.displayPublishers();
    return 0;
}