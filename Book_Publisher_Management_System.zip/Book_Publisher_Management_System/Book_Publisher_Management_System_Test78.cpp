#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Publisher {
public:
    int id;
    string name;
    Publisher(int id, string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    string title;
    Publisher* publisher;
    Book(int id, string title, Publisher* publisher) : id(id), title(title), publisher(publisher) {}
};

class ManagementSystem {
private:
    vector<Publisher> publishers;
    vector<Book> books;

    Publisher* findPublisherById(int id) {
        for (size_t i = 0; i < publishers.size(); i++) {
            if (publishers[i].id == id) {
                return &publishers[i];
            }
        }
        return nullptr;
    }

    Book* findBookById(int id) {
        for (size_t i = 0; i < books.size(); i++) {
            if (books[i].id == id) {
                return &books[i];
            }
        }
        return nullptr;
    }

public:
    void addPublisher(int id, string name) {
        publishers.push_back(Publisher(id, name));
    }

    void deletePublisher(int id) {
        for (size_t i = 0; i < publishers.size(); i++) {
            if (publishers[i].id == id) {
                publishers.erase(publishers.begin() + i);
                break;
            }
        }
    }

    void updatePublisher(int id, string newName) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            publisher->name = newName;
        }
    }

    void displayPublishers() {
        for (size_t i = 0; i < publishers.size(); i++) {
            cout << "Publisher ID: " << publishers[i].id << ", Name: " << publishers[i].name << endl;
        }
    }

    void addBook(int id, string title, int publisherId) {
        Publisher* publisher = findPublisherById(publisherId);
        if (publisher) {
            books.push_back(Book(id, title, publisher));
        }
    }

    void deleteBook(int id) {
        for (size_t i = 0; i < books.size(); i++) {
            if (books[i].id == id) {
                books.erase(books.begin() + i);
                break;
            }
        }
    }

    void updateBook(int id, string newTitle, int publisherId) {
        Book* book = findBookById(id);
        Publisher* publisher = findPublisherById(publisherId);
        if (book && publisher) {
            book->title = newTitle;
            book->publisher = publisher;
        }
    }

    void displayBooks() {
        for (size_t i = 0; i < books.size(); i++) {
            cout << "Book ID: " << books[i].id << ", Title: " << books[i].title
                 << ", Publisher: " << books[i].publisher->name << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "Publisher A");
    system.addPublisher(2, "Publisher B");

    system.addBook(1, "Book One", 1);
    system.addBook(2, "Book Two", 2);

    cout << "Books in the system:" << endl;
    system.displayBooks();

    cout << "Publishers in the system:" << endl;
    system.displayPublishers();

    return 0;
}