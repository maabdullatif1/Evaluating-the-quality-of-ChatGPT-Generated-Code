#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Publisher {
public:
    string name;
    string address;
    Publisher(string n, string a) : name(n), address(a) {}
};

class Book {
public:
    string title;
    string author;
    Publisher* publisher;
    Book(string t, string a, Publisher* p) : title(t), author(a), publisher(p) {}
};

class ManagementSystem {
private:
    vector<Publisher*> publishers;
    vector<Book*> books;

public:
    void addPublisher(string name, string address) {
        Publisher* publisher = new Publisher(name, address);
        publishers.push_back(publisher);
    }

    void addBook(string title, string author, string publisherName) {
        Publisher* publisher = findPublisherByName(publisherName);
        if (publisher) {
            Book* book = new Book(title, author, publisher);
            books.push_back(book);
        } else {
            cout << "Publisher not found" << endl;
        }
    }

    Publisher* findPublisherByName(string name) {
        for (auto pub : publishers) {
            if (pub->name == name)
                return pub;
        }
        return nullptr;
    }

    Book* findBookByTitle(string title) {
        for (auto bk : books) {
            if (bk->title == title)
                return bk;
        }
        return nullptr;
    }

    void deletePublisher(string name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if ((*it)->name == name) {
                delete *it;
                publishers.erase(it);
                break;
            }
        }
    }

    void deleteBook(string title) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if ((*it)->title == title) {
                delete *it;
                books.erase(it);
                break;
            }
        }
    }

    void updatePublisher(string oldName, string newName, string newAddress) {
        Publisher* publisher = findPublisherByName(oldName);
        if (publisher) {
            publisher->name = newName;
            publisher->address = newAddress;
        }
    }

    void updateBook(string oldTitle, string newTitle, string newAuthor, string newPublisherName) {
        Book* book = findBookByTitle(oldTitle);
        if (book) {
            book->title = newTitle;
            book->author = newAuthor;
            book->publisher = findPublisherByName(newPublisherName);
        }
    }

    void displayPublishers() {
        for (auto pub : publishers) {
            cout << "Publisher: " << pub->name << ", Address: " << pub->address << endl;
        }
    }

    void displayBooks() {
        for (auto book : books) {
            cout << "Title: " << book->title << ", Author: " << book->author 
                 << ", Publisher: " << book->publisher->name << endl;
        }
    }
};

int main() {
    ManagementSystem ms;
    ms.addPublisher("Publisher1", "Address1");
    ms.addPublisher("Publisher2", "Address2");
    ms.addBook("Book1", "Author1", "Publisher1");
    ms.addBook("Book2", "Author2", "Publisher2");

    ms.displayBooks();
    ms.displayPublishers();

    ms.updateBook("Book1", "UpdatedBook1", "UpdatedAuthor1", "Publisher2");
    ms.updatePublisher("Publisher2", "UpdatedPublisher2", "UpdatedAddress2");

    ms.displayBooks();
    ms.displayPublishers();

    ms.deleteBook("UpdatedBook1");
    ms.deletePublisher("UpdatedPublisher2");

    ms.displayBooks();
    ms.displayPublishers();

    return 0;
}