#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    std::string name;
    std::string address;

    Publisher(std::string n, std::string a) : name(n), address(a) {}
};

class Book {
public:
    std::string title;
    std::string author;
    std::string isbn;
    Publisher* publisher;

    Book(std::string t, std::string a, std::string i, Publisher* p)
        : title(t), author(a), isbn(i), publisher(p) {}
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;

    Publisher* findPublisher(const std::string& name) {
        for (auto& pub : publishers) {
            if (pub.name == name)
                return &pub;
        }
        return nullptr;
    }

    Book* findBook(const std::string& isbn) {
        for (auto& book : books) {
            if (book.isbn == isbn)
                return &book;
        }
        return nullptr;
    }

public:
    void addPublisher(const std::string& name, const std::string& address) {
        publishers.push_back(Publisher(name, address));
    }

    void deletePublisher(const std::string& name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->name == name) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(const std::string& name, const std::string& newAddress) {
        Publisher* publisher = findPublisher(name);
        if (publisher) {
            publisher->address = newAddress;
        }
    }

    void addBook(const std::string& title, const std::string& author, const std::string& isbn, const std::string& publisherName) {
        Publisher* publisher = findPublisher(publisherName);
        if (publisher) {
            books.push_back(Book(title, author, isbn, publisher));
        }
    }

    void deleteBook(const std::string& isbn) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->isbn == isbn) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(const std::string& isbn, const std::string& newTitle, const std::string& newAuthor) {
        Book* book = findBook(isbn);
        if (book) {
            book->title = newTitle;
            book->author = newAuthor;
        }
    }

    void searchBook(const std::string& isbn) {
        Book* book = findBook(isbn);
        if (book) {
            std::cout << "ISBN: " << book->isbn << ", Title: " << book->title << ", Author: " << book->author 
                      << ", Publisher: " << book->publisher->name << "\n";
        }
    }

    void displayPublishers() {
        for (const auto& pub : publishers) {
            std::cout << "Publisher: " << pub.name << ", Address: " << pub.address << "\n";
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "ISBN: " << book.isbn << ", Title: " << book.title << ", Author: " << book.author 
                      << ", Publisher: " << book.publisher->name << "\n";
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("Penguin", "123 Main St");
    system.addPublisher("HarperCollins", "456 Broad St");

    system.addBook("The Great Gatsby", "F. Scott Fitzgerald", "1234567890", "Penguin");
    system.addBook("1984", "George Orwell", "2345678901", "HarperCollins");

    std::cout << "Books List:\n";
    system.displayBooks();

    std::cout << "\nPublishers List:\n";
    system.displayPublishers();

    std::cout << "\nSearch for book with ISBN 1234567890:\n";
    system.searchBook("1234567890");

    return 0;
}