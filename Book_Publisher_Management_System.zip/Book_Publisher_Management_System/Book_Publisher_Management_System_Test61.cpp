#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    std::string name;
    std::string address;
    Publisher(std::string n, std::string a) : name(n), address(a) {}
};

class Book {
public:
    std::string title;
    std::string author;
    Publisher *publisher;
    Book(std::string t, std::string a, Publisher *p) : title(t), author(a), publisher(p) {}
};

class System {
    std::vector<Publisher> publishers;
    std::vector<Book> books;

public:
    void addPublisher(std::string name, std::string address) {
        publishers.push_back(Publisher(name, address));
    }

    void addBook(std::string title, std::string author, std::string publisherName) {
        Publisher *pub = findPublisherByName(publisherName);
        if (pub) books.push_back(Book(title, author, pub));
    }

    void deletePublisher(std::string name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->name == name) {
                publishers.erase(it);
                break;
            }
        }
    }

    void deleteBook(std::string title) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->title == title) {
                books.erase(it);
                break;
            }
        }
    }

    void updatePublisher(std::string oldName, std::string newName, std::string newAddress) {
        for (auto &pub : publishers) {
            if (pub.name == oldName) {
                pub.name = newName;
                pub.address = newAddress;
                break;
            }
        }
    }

    void updateBook(std::string oldTitle, std::string newTitle, std::string newAuthor, std::string newPublisherName) {
        for (auto &book : books) {
            if (book.title == oldTitle) {
                book.title = newTitle;
                book.author = newAuthor;
                book.publisher = findPublisherByName(newPublisherName);
                break;
            }
        }
    }

    void searchPublisher(std::string name) {
        for (auto &pub : publishers) {
            if (pub.name == name) {
                std::cout << "Publisher: " << pub.name << ", Address: " << pub.address << "\n";
                return;
            }
        }
        std::cout << "Publisher not found.\n";
    }

    void searchBook(std::string title) {
        for (auto &book : books) {
            if (book.title == title) {
                std::cout << "Book: " << book.title << ", Author: " << book.author
                          << ", Publisher: " << book.publisher->name << "\n";
                return;
            }
        }
        std::cout << "Book not found.\n";
    }

    void displayPublishers() {
        for (auto &pub : publishers) {
            std::cout << "Publisher: " << pub.name << ", Address: " << pub.address << "\n";
        }
    }

    void displayBooks() {
        for (auto &book : books) {
            std::cout << "Book: " << book.title << ", Author: " << book.author
                      << ", Publisher: " << book.publisher->name << "\n";
        }
    }

private:
    Publisher* findPublisherByName(const std::string& name) {
        for (auto &pub : publishers) {
            if (pub.name == name) {
                return &pub;
            }
        }
        return nullptr;
    }
};

int main() {
    System system;
    system.addPublisher("Penguin", "123 Penguin Rd");
    system.addPublisher("HarperCollins", "456 Harper St");

    system.addBook("1984", "George Orwell", "Penguin");
    system.addBook("To Kill a Mockingbird", "Harper Lee", "HarperCollins");

    system.displayPublishers();
    system.displayBooks();

    system.searchBook("1984");
    system.searchPublisher("HarperCollins");

    system.updatePublisher("Penguin", "Penguin Books", "789 New Penguin Rd");
    system.updateBook("1984", "Nineteen Eighty-Four", "George Orwell", "Penguin Books");

    system.displayPublishers();
    system.displayBooks();

    system.deleteBook("Nineteen Eighty-Four");
    system.deletePublisher("HarperCollins");

    system.displayPublishers();
    system.displayBooks();

    return 0;
}