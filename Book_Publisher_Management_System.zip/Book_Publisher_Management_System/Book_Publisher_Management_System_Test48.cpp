#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Publisher {
public:
    int id;
    string name;

    Publisher(int id, string name) : id(id), name(name) {}
};

class Book {
public:
    string title;
    string author;
    int publisherId;

    Book(string title, string author, int publisherId) : title(title), author(author), publisherId(publisherId) {}
};

class ManagementSystem {
    vector<Publisher> publishers;
    vector<Book> books;

    Publisher* findPublisherById(int id) {
        for (auto& p : publishers) {
            if (p.id == id) {
                return &p;
            }
        }
        return nullptr;
    }

    Book* findBookByTitle(const string& title) {
        for (auto& b : books) {
            if (b.title == title) {
                return &b;
            }
        }
        return nullptr;
    }

public:
    void addPublisher(int id, string name) {
        if (findPublisherById(id) == nullptr) {
            publishers.emplace_back(id, name);
            cout << "Publisher added.\n";
        } else {
            cout << "Publisher already exists.\n";
        }
    }

    void addBook(string title, string author, int publisherId) {
        if (findPublisherById(publisherId) && findBookByTitle(title) == nullptr) {
            books.emplace_back(title, author, publisherId);
            cout << "Book added.\n";
        } else {
            cout << "Invalid publisher or book already exists.\n";
        }
    }

    void deletePublisher(int id) {
        auto it = remove_if(publishers.begin(), publishers.end(), [id](Publisher& p) { return p.id == id; });
        if (it != publishers.end()) {
            publishers.erase(it, publishers.end());
            cout << "Publisher deleted.\n";
        } else {
            cout << "Publisher not found.\n";
        }
    }

    void deleteBook(string title) {
        auto it = remove_if(books.begin(), books.end(), [&title](Book& b) { return b.title == title; });
        if (it != books.end()) {
            books.erase(it, books.end());
            cout << "Book deleted.\n";
        } else {
            cout << "Book not found.\n";
        }
    }

    void updatePublisher(int id, string newName) {
        Publisher* p = findPublisherById(id);
        if (p) {
            p->name = newName;
            cout << "Publisher updated.\n";
        } else {
            cout << "Publisher not found.\n";
        }
    }

    void updateBook(string title, string newAuthor, int newPublisherId) {
        Book* b = findBookByTitle(title);
        if (b && findPublisherById(newPublisherId)) {
            b->author = newAuthor;
            b->publisherId = newPublisherId;
            cout << "Book updated.\n";
        } else {
            cout << "Invalid book or publisher.\n";
        }
    }

    void searchBook(string title) {
        Book* b = findBookByTitle(title);
        if (b) {
            cout << "Title: " << b->title << ", Author: " << b->author << ", Publisher ID: " << b->publisherId << "\n";
        } else {
            cout << "Book not found.\n";
        }
    }

    void searchPublisher(int id) {
        Publisher* p = findPublisherById(id);
        if (p) {
            cout << "Publisher ID: " << p->id << ", Name: " << p->name << "\n";
        } else {
            cout << "Publisher not found.\n";
        }
    }

    void displayBooks() {
        for (auto& b : books) {
            cout << "Title: " << b.title << ", Author: " << b.author << ", Publisher ID: " << b.publisherId << "\n";
        }
    }

    void displayPublishers() {
        for (auto& p : publishers) {
            cout << "Publisher ID: " << p.id << ", Name: " << p.name << "\n";
        }
    }
};

int main() {
    ManagementSystem sys;
    sys.addPublisher(1, "O'Reilly Media");
    sys.addPublisher(2, "Pearson");
    sys.addBook("C++ Programming", "Bjarne Stroustrup", 1);
    sys.addBook("Effective Java", "Joshua Bloch", 2);
    
    sys.displayBooks();
    sys.displayPublishers();
    
    sys.searchBook("C++ Programming");
    sys.searchPublisher(1);
    
    sys.updateBook("C++ Programming", "B. Stroustrup", 2);
    sys.updatePublisher(1, "O'Reilly");
    
    sys.displayBooks();
    sys.displayPublishers();
    
    sys.deleteBook("Effective Java");
    sys.deletePublisher(2);
    
    sys.displayBooks();
    sys.displayPublishers();
    
    return 0;
}