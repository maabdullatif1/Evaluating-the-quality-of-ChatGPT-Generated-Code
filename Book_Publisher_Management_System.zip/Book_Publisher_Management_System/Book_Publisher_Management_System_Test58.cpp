#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Publisher {
public:
    string name;
    string address;

    Publisher(string n, string a) : name(n), address(a) {}
};

class Book {
public:
    string title;
    string author;
    string isbn;
    Publisher* publisher;

    Book(string t, string a, string i, Publisher* p) : title(t), author(a), isbn(i), publisher(p) {}
};

class ManagementSystem {
private:
    vector<Publisher> publishers;
    vector<Book> books;

public:
    void addPublisher(string name, string address) {
        publishers.push_back(Publisher(name, address));
    }

    void deletePublisher(string name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->name == name) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(string name, string newName, string newAddress) {
        for (auto& publisher : publishers) {
            if (publisher.name == name) {
                publisher.name = newName;
                publisher.address = newAddress;
                break;
            }
        }
    }

    Publisher* findPublisher(string name) {
        for (auto& publisher : publishers) {
            if (publisher.name == name) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void addBook(string title, string author, string isbn, string publisherName) {
        Publisher* publisher = findPublisher(publisherName);
        if (publisher) {
            books.push_back(Book(title, author, isbn, publisher));
        }
    }

    void deleteBook(string isbn) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->isbn == isbn) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(string isbn, string newTitle, string newAuthor, string newPublisherName) {
        for (auto& book : books) {
            if (book.isbn == isbn) {
                book.title = newTitle;
                book.author = newAuthor;
                book.publisher = findPublisher(newPublisherName);
                break;
            }
        }
    }

    void findBook(string isbn) {
        for (auto& book : books) {
            if (book.isbn == isbn) {
                cout << "Title: " << book.title << ", Author: " << book.author 
                     << ", ISBN: " << book.isbn << ", Publisher: " << book.publisher->name << endl;
                return;
            }
        }
        cout << "Book not found" << endl;
    }

    void displayPublishers() {
        for (auto& publisher : publishers) {
            cout << "Name: " << publisher.name << ", Address: " << publisher.address << endl;
        }
    }

    void displayBooks() {
        for (auto& book : books) {
            cout << "Title: " << book.title << ", Author: " << book.author 
                 << ", ISBN: " << book.isbn << ", Publisher: " << book.publisher->name << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("Penguin", "123 Main St");
    system.addPublisher("HarperCollins", "456 Elm St");

    system.addBook("1984", "George Orwell", "1234567890", "Penguin");
    system.addBook("To Kill a Mockingbird", "Harper Lee", "0987654321", "HarperCollins");

    system.displayPublishers();
    system.displayBooks();

    system.findBook("1234567890");

    system.updateBook("1234567890", "Nineteen Eighty-Four", "George Orwell", "Penguin");
    system.updatePublisher("Penguin", "Penguin Books", "789 Maple Ave");

    system.displayBooks();
    system.displayPublishers();

    system.deleteBook("1234567890");
    system.deletePublisher("HarperCollins");

    system.displayBooks();
    system.displayPublishers();

    return 0;
}