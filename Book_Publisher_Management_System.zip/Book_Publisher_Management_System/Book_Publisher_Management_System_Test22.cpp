#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Publisher {
    int id;
    string name;
    string address;
};

struct Book {
    int id;
    string title;
    string author;
    Publisher publisher;
};

vector<Publisher> publishers;
vector<Book> books;

void addPublisher() {
    Publisher publisher;
    cout << "Enter Publisher ID: ";
    cin >> publisher.id;
    cout << "Enter Publisher Name: ";
    cin.ignore();
    getline(cin, publisher.name);
    cout << "Enter Publisher Address: ";
    getline(cin, publisher.address);
    publishers.push_back(publisher);
}

void addBook() {
    Book book;
    int publisherId;
    cout << "Enter Book ID: ";
    cin >> book.id;
    cout << "Enter Book Title: ";
    cin.ignore();
    getline(cin, book.title);
    cout << "Enter Book Author: ";
    getline(cin, book.author);
    cout << "Enter Publisher ID of the Book: ";
    cin >> publisherId;
    for (const auto &pub : publishers) {
        if (pub.id == publisherId) {
            book.publisher = pub;
            books.push_back(book);
            return;
        }
    }
    cout << "Publisher not found!\n";
}

void deletePublisher() {
    int id;
    cout << "Enter Publisher ID to Delete: ";
    cin >> id;
    for (auto it = publishers.begin(); it != publishers.end(); ++it) {
        if (it->id == id) {
            publishers.erase(it);
            cout << "Publisher Deleted\n";
            return;
        }
    }
    cout << "Publisher not found!\n";
}

void deleteBook() {
    int id;
    cout << "Enter Book ID to Delete: ";
    cin >> id;
    for (auto it = books.begin(); it != books.end(); ++it) {
        if (it->id == id) {
            books.erase(it);
            cout << "Book Deleted\n";
            return;
        }
    }
    cout << "Book not found!\n";
}

void updatePublisher() {
    int id;
    cout << "Enter Publisher ID to Update: ";
    cin >> id;
    for (auto &pub : publishers) {
        if (pub.id == id) {
            cout << "Enter New Publisher Name: ";
            cin.ignore();
            getline(cin, pub.name);
            cout << "Enter New Publisher Address: ";
            getline(cin, pub.address);
            cout << "Publisher Updated\n";
            return;
        }
    }
    cout << "Publisher not found!\n";
}

void updateBook() {
    int id;
    cout << "Enter Book ID to Update: ";
    cin >> id;
    for (auto &book : books) {
        if (book.id == id) {
            cout << "Enter New Book Title: ";
            cin.ignore();
            getline(cin, book.title);
            cout << "Enter New Book Author: ";
            getline(cin, book.author);
            int pubId;
            cout << "Enter New Publisher ID: ";
            cin >> pubId;
            for (const auto &pub : publishers) {
                if (pub.id == pubId) {
                    book.publisher = pub;
                    cout << "Book Updated\n";
                    return;
                }
            }
            cout << "Publisher not found!\n";
            return;
        }
    }
    cout << "Book not found!\n";
}

void searchPublisher() {
    int id;
    cout << "Enter Publisher ID to Search: ";
    cin >> id;
    for (const auto &pub : publishers) {
        if (pub.id == id) {
            cout << "Publisher ID: " << pub.id << ", Name: " << pub.name 
                 << ", Address: " << pub.address << endl;
            return;
        }
    }
    cout << "Publisher not found!\n";
}

void searchBook() {
    int id;
    cout << "Enter Book ID to Search: ";
    cin >> id;
    for (const auto &book : books) {
        if (book.id == id) {
            cout << "Book ID: " << book.id << ", Title: " << book.title 
                 << ", Author: " << book.author << ", Publisher: " 
                 << book.publisher.name << endl;
            return;
        }
    }
    cout << "Book not found!\n";
}

void displayPublishers() {
    cout << "Publishers List:\n";
    for (const auto &pub : publishers) {
        cout << "ID: " << pub.id << ", Name: " << pub.name 
             << ", Address: " << pub.address << endl;
    }
}

void displayBooks() {
    cout << "Books List:\n";
    for (const auto &book : books) {
        cout << "ID: " << book.id << ", Title: " << book.title 
             << ", Author: " << book.author << ", Publisher: " 
             << book.publisher.name << endl;
    }
}

int main() {
    int choice;
    while (1) {
        cout << "1. Add Publisher\n2. Add Book\n3. Delete Publisher\n4. Delete Book\n";
        cout << "5. Update Publisher\n6. Update Book\n7. Search Publisher\n";
        cout << "8. Search Book\n9. Display Publishers\n10. Display Books\n11. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addPublisher(); break;
            case 2: addBook(); break;
            case 3: deletePublisher(); break;
            case 4: deleteBook(); break;
            case 5: updatePublisher(); break;
            case 6: updateBook(); break;
            case 7: searchPublisher(); break;
            case 8: searchBook(); break;
            case 9: displayPublishers(); break;
            case 10: displayBooks(); break;
            case 11: return 0;
            default: cout << "Invalid choice\n";
        }
    }
    return 0;
}