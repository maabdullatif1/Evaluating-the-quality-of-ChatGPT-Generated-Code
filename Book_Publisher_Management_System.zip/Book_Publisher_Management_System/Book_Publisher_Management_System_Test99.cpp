#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    Publisher(int id, std::string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;
    int publisherId;
    Book(int id, std::string title, int publisherId) : id(id), title(title), publisherId(publisherId) {}
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;
    int publisherIdCounter = 1;
    int bookIdCounter = 1;

public:
    void addPublisher(std::string name) {
        publishers.push_back(Publisher(publisherIdCounter++, name));
    }

    void addBook(std::string title, int publisherId) {
        for (auto &publisher : publishers) {
            if (publisher.id == publisherId) {
                books.push_back(Book(bookIdCounter++, title, publisherId));
                return;
            }
        }
        std::cout << "Publisher ID not found.\n";
    }

    bool deletePublisher(int id) {
        for (int i = 0; i < publishers.size(); i++) {
            if (publishers[i].id == id) {
                publishers.erase(publishers.begin() + i);
                books.erase(std::remove_if(books.begin(), books.end(), [id](Book &b) { return b.publisherId == id; }), books.end());
                return true;
            }
        }
        return false;
    }

    bool deleteBook(int id) {
        for (int i = 0; i < books.size(); i++) {
            if (books[i].id == id) {
                books.erase(books.begin() + i);
                return true;
            }
        }
        return false;
    }

    bool updatePublisher(int id, std::string newName) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = newName;
                return true;
            }
        }
        return false;
    }

    bool updateBook(int id, std::string newTitle, int newPublisherId) {
        for (auto &book : books) {
            if (book.id == id) {
                for (auto &publisher : publishers) {
                    if (publisher.id == newPublisherId) {
                        book.title = newTitle;
                        book.publisherId = newPublisherId;
                        return true;
                    }
                }
                std::cout << "New Publisher ID not found.\n";
                return false;
            }
        }
        return false;
    }

    void searchPublishers(std::string name) {
        for (auto &publisher : publishers) {
            if (publisher.name.find(name) != std::string::npos) {
                std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << "\n";
            }
        }
    }

    void searchBooks(std::string title) {
        for (auto &book : books) {
            if (book.title.find(title) != std::string::npos) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << "\n";
            }
        }
    }

    void displayPublishers() {
        for (auto &publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << "\n";
        }
    }

    void displayBooks() {
        for (auto &book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << "\n";
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("Publisher One");
    system.addPublisher("Publisher Two");
    system.addBook("Book One", 1);
    system.addBook("Book Two", 2);
    system.displayPublishers();
    system.displayBooks();
    system.searchPublishers("One");
    system.searchBooks("Two");
    system.updatePublisher(1, "Updated Publisher One");
    system.updateBook(1, "Updated Book One", 2);
    system.displayPublishers();
    system.displayBooks();
    system.deleteBook(1);
    system.deletePublisher(2);
    system.displayPublishers();
    system.displayBooks();
    return 0;
}