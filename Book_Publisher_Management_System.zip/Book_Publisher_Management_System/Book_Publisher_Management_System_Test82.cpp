#include <iostream>
#include <vector>
#include <string>

class Publisher {
    std::string id;
    std::string name;
    
public:
    Publisher(std::string id, std::string name) : id(id), name(name) {}
    std::string getId() const { return id; }
    std::string getName() const { return name; }
    void setName(std::string name) { this->name = name; }
};

class Book {
    std::string isbn;
    std::string title;
    std::string publisherId;
    
public:
    Book(std::string isbn, std::string title, std::string publisherId) : isbn(isbn), title(title), publisherId(publisherId) {}
    std::string getISBN() const { return isbn; }
    std::string getTitle() const { return title; }
    std::string getPublisherId() const { return publisherId; }
    void setTitle(std::string title) { this->title = title; }
    void setPublisherId(std::string publisherId) { this->publisherId = publisherId; }
};

class ManagementSystem {
    std::vector<Publisher> publishers;
    std::vector<Book> books;
    
public:
    void addPublisher(const Publisher& publisher) {
        publishers.push_back(publisher);
    }

    void deletePublisher(const std::string& id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->getId() == id) {
                publishers.erase(it);
                return;
            }
        }
    }

    void updatePublisher(const std::string& id, const std::string& name) {
        for (auto& publisher : publishers) {
            if (publisher.getId() == id) {
                publisher.setName(name);
                return;
            }
        }
    }

    void addBook(const Book& book) {
        books.push_back(book);
    }

    void deleteBook(const std::string& isbn) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->getISBN() == isbn) {
                books.erase(it);
                return;
            }
        }
    }

    void updateBook(const std::string& isbn, const std::string& title, const std::string& publisherId) {
        for (auto& book : books) {
            if (book.getISBN() == isbn) {
                book.setTitle(title);
                book.setPublisherId(publisherId);
                return;
            }
        }
    }

    Book* searchBookByISBN(const std::string& isbn) {
        for (auto& book : books) {
            if (book.getISBN() == isbn) {
                return &book;
            }
        }
        return nullptr;
    }

    Publisher* searchPublisherById(const std::string& id) {
        for (auto& publisher : publishers) {
            if (publisher.getId() == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void displayBooks() const {
        for (const auto& book : books) {
            std::cout << "ISBN: " << book.getISBN() << ", Title: " << book.getTitle() << ", Publisher ID: " << book.getPublisherId() << std::endl;
        }
    }

    void displayPublishers() const {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.getId() << ", Name: " << publisher.getName() << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(Publisher("1", "Pearson"));
    system.addPublisher(Publisher("2", "Penguin"));
    system.addBook(Book("123456", "C++ Programming", "1"));
    system.addBook(Book("654321", "Data Structures", "2"));
    
    system.displayPublishers();
    system.displayBooks();
    
    system.updateBook("123456", "Advanced C++ Programming", "1");
    system.displayBooks();

    system.deletePublisher("2");
    system.displayPublishers();
    
    return 0;
}