#include <iostream>
#include <string>
#include <vector>

class Publisher {
public:
    std::string name;
    std::string address;

    Publisher(std::string pname, std::string paddress) : name(pname), address(paddress) {}
};

class Book {
public:
    std::string title;
    std::string author;
    std::string isbn;
    Publisher* publisher;

    Book(std::string btitle, std::string bauthor, std::string bisbn, Publisher* bpublisher)
        : title(btitle), author(bauthor), isbn(bisbn), publisher(bpublisher) {}
};

class System {
public:
    std::vector<Book> books;
    std::vector<Publisher> publishers;

    void addPublisher(std::string name, std::string address) {
        publishers.push_back(Publisher(name, address));
    }

    void addBook(std::string title, std::string author, std::string isbn, std::string publisherName) {
        Publisher* pub = findPublisherByName(publisherName);
        if (pub != nullptr) {
            books.push_back(Book(title, author, isbn, pub));
        }
    }

    void updatePublisher(std::string name, std::string newAddress) {
        for (auto &publisher : publishers) {
            if (publisher.name == name) {
                publisher.address = newAddress;
                break;
            }
        }
    }

    void updateBook(std::string isbn, std::string newTitle, std::string newAuthor) {
        for (auto &book : books) {
            if (book.isbn == isbn) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }

    void deletePublisher(std::string name) {
        publishers.erase(std::remove_if(publishers.begin(), publishers.end(), 
                                        [&](Publisher &pub) { return pub.name == name; }), 
                         publishers.end());
    }

    void deleteBook(std::string isbn) {
        books.erase(std::remove_if(books.begin(), books.end(), 
                                   [&](Book &book) { return book.isbn == isbn; }), 
                    books.end());
    }

    Publisher* findPublisherByName(std::string name) {
        for (auto &publisher : publishers) {
            if (publisher.name == name) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void searchBooksByTitle(std::string title) {
        for (auto &book : books) {
            if (book.title == title) {
                displayBookInfo(book);
            }
        }
    }

    void searchPublisherByName(std::string name) {
        for (auto &publisher : publishers) {
            if (publisher.name == name) {
                displayPublisherInfo(publisher);
            }
        }
    }

    void displayAllBooks() {
        for (auto &book : books) {
            displayBookInfo(book);
        }
    }

    void displayAllPublishers() {
        for (auto &publisher : publishers) {
            displayPublisherInfo(publisher);
        }
    }

private:
    void displayBookInfo(const Book &book) {
        std::cout << "Title: " << book.title << ", Author: " << book.author 
                  << ", ISBN: " << book.isbn << ", Publisher: " << book.publisher->name << std::endl;
    }

    void displayPublisherInfo(const Publisher &publisher) {
        std::cout << "Publisher Name: " << publisher.name << ", Address: " << publisher.address << std::endl;
    }
};

int main() {
    System system;
    system.addPublisher("Penguin", "123 Penguin St.");
    system.addBook("Book Title", "Author Name", "12345", "Penguin");
    system.displayAllBooks();
    system.displayAllPublishers();
    system.updateBook("12345", "New Book Title", "New Author Name");
    system.searchBooksByTitle("New Book Title");
    system.deleteBook("12345");
    system.displayAllBooks();
    return 0;
}