#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Publisher {
public:
    int id;
    string name;

    Publisher(int id, string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    string title;
    int publisherId;

    Book(int id, string title, int publisherId) : id(id), title(title), publisherId(publisherId) {}
};

class ManagementSystem {
private:
    vector<Publisher> publishers;
    vector<Book> books;

public:
    void addPublisher(int id, string name) {
        publishers.push_back(Publisher(id, name));
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, string name) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = name;
                break;
            }
        }
    }

    void addBook(int id, string title, int publisherId) {
        books.push_back(Book(id, title, publisherId));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string title, int publisherId) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.publisherId = publisherId;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    Publisher* searchPublisher(int id) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << endl;
        }
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "O'Reilly Media");
    system.addPublisher(2, "Penguin Books");
    
    system.addBook(1, "C++ Programming", 1);
    system.addBook(2, "Advanced Algorithms", 2);

    system.displayBooks();
    system.displayPublishers();

    return 0;
}