#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Publisher {
public:
    int publisherId;
    string name;
    string address;

    Publisher(int id, string n, string a) : publisherId(id), name(n), address(a) {}
};

class Book {
public:
    int bookId;
    string title;
    string author;
    int publisherId;

    Book(int id, string t, string a, int pid) : bookId(id), title(t), author(a), publisherId(pid) {}
};

class PublisherManagement {
    vector<Publisher> publishers;
    vector<Book> books;
    
public:
    void addPublisher(int id, string name, string address) {
        publishers.push_back(Publisher(id, name, address));
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->publisherId == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, string name, string address) {
        for (auto& publisher : publishers) {
            if (publisher.publisherId == id) {
                publisher.name = name;
                publisher.address = address;
            }
        }
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            cout << "Publisher ID: " << publisher.publisherId << ", Name: " << publisher.name << ", Address: " << publisher.address << endl;
        }
    }

    Publisher* searchPublisher(int id) {
        for (auto& publisher : publishers) {
            if (publisher.publisherId == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void addBook(int id, string title, string author, int publisherId) {
        books.push_back(Book(id, title, author, publisherId));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->bookId == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string title, string author, int publisherId) {
        for (auto& book : books) {
            if (book.bookId == id) {
                book.title = title;
                book.author = author;
                book.publisherId = publisherId;
            }
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "Book ID: " << book.bookId << ", Title: " << book.title << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << endl;
        }
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.bookId == id) {
                return &book;
            }
        }
        return nullptr;
    }
};

int main() {
    PublisherManagement pm;
    pm.addPublisher(1, "Penguin Random House", "1745 Broadway, New York, NY 10019");
    pm.addPublisher(2, "HarperCollins", "195 Broadway, New York, NY 10007");
    pm.addBook(1, "1984", "George Orwell", 1);
    pm.addBook(2, "To Kill a Mockingbird", "Harper Lee", 2);
    pm.displayPublishers();
    pm.displayBooks();
    pm.updatePublisher(1, "Penguin Books", "375 Hudson Street, New York, NY 10014");
    pm.updateBook(1, "Nineteen Eighty-Four", "George Orwell", 1);
    pm.displayPublishers();
    pm.displayBooks();
    pm.deleteBook(2);
    pm.displayBooks();
    pm.deletePublisher(2);
    pm.displayPublishers();
    return 0;
}