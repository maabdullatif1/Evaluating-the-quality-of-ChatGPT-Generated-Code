#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    Publisher(int id, const std::string& name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;
    Publisher* publisher;
    Book(int id, const std::string& title, Publisher* publisher) : id(id), title(title), publisher(publisher) {}
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;

    Publisher* findPublisherById(int id) {
        for (auto& publisher : publishers)
            if (publisher.id == id)
                return &publisher;
        return nullptr;
    }

    Book* findBookById(int id) {
        for (auto& book : books)
            if (book.id == id)
                return &book;
        return nullptr;
    }

public:
    void addPublisher(int id, const std::string& name) {
        publishers.emplace_back(id, name);
    }

    void deletePublisher(int id) {
        publishers.erase(std::remove_if(publishers.begin(), publishers.end(),
                                        [id](Publisher& p) { return p.id == id; }), publishers.end());
    }

    void updatePublisher(int id, const std::string& name) {
        Publisher* publisher = findPublisherById(id);
        if (publisher)
            publisher->name = name;
    }

    void addBook(int id, const std::string& title, int publisherId) {
        Publisher* publisher = findPublisherById(publisherId);
        if (publisher) 
            books.emplace_back(id, title, publisher);
    }

    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(),
                                   [id](Book& b) { return b.id == id; }), books.end());
    }

    void updateBook(int id, const std::string& title, int publisherId) {
        Book* book = findBookById(id);
        Publisher* publisher = findPublisherById(publisherId);
        if (book && publisher) {
            book->title = title;
            book->publisher = publisher;
        }
    }

    void searchBooksByTitle(const std::string& title) {
        for (const auto& book : books)
            if (book.title.find(title) != std::string::npos)
                std::cout << "Book ID: " << book.id << ", Title: " << book.title 
                          << ", Publisher: " << book.publisher->name << std::endl;
    }

    void searchPublishersByName(const std::string& name) {
        for (const auto& publisher : publishers)
            if (publisher.name.find(name) != std::string::npos)
                std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << std::endl;
    }

    void displayBooks() {
        for (const auto& book : books)
            std::cout << "Book ID: " << book.id << ", Title: " << book.title 
                      << ", Publisher: " << book.publisher->name << std::endl;
    }

    void displayPublishers() {
        for (const auto& publisher : publishers)
            std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << std::endl;
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "O'Reilly Media");
    system.addPublisher(2, "Penguin Random House");
    system.addBook(1, "C++ Programming", 1);
    system.addBook(2, "Effective C++", 1);
    system.addBook(3, "Design Patterns", 2);

    std::cout << "All Publishers:" << std::endl;
    system.displayPublishers();

    std::cout << "\nAll Books:" << std::endl;
    system.displayBooks();

    std::cout << "\nSearch Books by Title 'C++':" << std::endl;
    system.searchBooksByTitle("C++");

    std::cout << "\nUpdating Publisher ID 2 to 'HarperCollins':" << std::endl;
    system.updatePublisher(2, "HarperCollins");
    system.displayPublishers();

    std::cout << "\nDeleting Book ID 1:" << std::endl;
    system.deleteBook(1);
    system.displayBooks();

    return 0;
}