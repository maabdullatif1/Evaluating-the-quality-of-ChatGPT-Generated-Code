#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    std::string address;

    Publisher(int i, const std::string &n, const std::string &a): id(i), name(n), address(a) {}
};

class Book {
public:
    int id;
    std::string title;
    int publisherId;

    Book(int i, const std::string &t, int pId): id(i), title(t), publisherId(pId) {}
};

class PublisherManagementSystem {
    std::vector<Publisher> publishers;
    std::vector<Book> books;

    Publisher* findPublisherById(int id) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    Book* findBookById(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

public:
    void addPublisher(int id, const std::string &name, const std::string &address) {
        publishers.emplace_back(id, name, address);
    }

    void deletePublisher(int id) {
        publishers.erase(std::remove_if(publishers.begin(), publishers.end(), [&](Publisher &p) { return p.id == id; }), publishers.end());
    }

    void updatePublisher(int id, const std::string &name, const std::string &address) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            publisher->name = name;
            publisher->address = address;
        }
    }

    void displayPublishers() {
        for (const auto &publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << ", Address: " << publisher.address << "\n";
        }
    }

    void addBook(int id, const std::string &title, int publisherId) {
        if (findPublisherById(publisherId)) {
            books.emplace_back(id, title, publisherId);
        }
    }

    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(), [&](Book &b) { return b.id == id; }), books.end());
    }

    void updateBook(int id, const std::string &title, int publisherId) {
        Book* book = findBookById(id);
        if (book && findPublisherById(publisherId)) {
            book->title = title;
            book->publisherId = publisherId;
        }
    }

    void displayBooks() {
        for (const auto &book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << "\n";
        }
    }

    void searchPublishers(const std::string &name) {
        for (const auto &publisher : publishers) {
            if (publisher.name.find(name) != std::string::npos) {
                std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << ", Address: " << publisher.address << "\n";
            }
        }
    }

    void searchBooks(const std::string &title) {
        for (const auto &book : books) {
            if (book.title.find(title) != std::string::npos) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << "\n";
            }
        }
    }
};

int main() {
    PublisherManagementSystem system;
    system.addPublisher(1, "Publisher A", "123 Street A");
    system.addPublisher(2, "Publisher B", "456 Street B");
    system.addBook(1, "Book A", 1);
    system.addBook(2, "Book B", 2);
    system.displayPublishers();
    system.displayBooks();
    system.searchPublishers("Publisher A");
    system.searchBooks("Book A");
    return 0;
}