#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    Publisher(int id, const std::string& name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;
    int publisherId;
    Book(int id, const std::string& title, int publisherId) : id(id), title(title), publisherId(publisherId) {}
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;

    Publisher* findPublisherById(int id) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    Book* findBookById(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

public:
    void addPublisher(int id, const std::string& name) {
        if (!findPublisherById(id)) {
            publishers.emplace_back(id, name);
        }
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, const std::string& name) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            publisher->name = name;
        }
    }

    void addBook(int id, const std::string& title, int publisherId) {
        if (!findBookById(id) && findPublisherById(publisherId)) {
            books.emplace_back(id, title, publisherId);
        }
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const std::string& title, int publisherId) {
        Book* book = findBookById(id);
        if (book && findPublisherById(publisherId)) {
            book->title = title;
            book->publisherId = publisherId;
        }
    }

    void searchPublisher(int id) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            std::cout << "Publisher Found: " << publisher->name << "\n";
        } else {
            std::cout << "Publisher not found.\n";
        }
    }

    void searchBook(int id) {
        Book* book = findBookById(id);
        if (book) {
            std::cout << "Book Found: " << book->title << "\n";
        } else {
            std::cout << "Book not found.\n";
        }
    }

    void displayPublishers() {
        std::cout << "Publishers List:\n";
        for (const auto& publisher : publishers) {
            std::cout << "ID: " << publisher.id << ", Name: " << publisher.name << "\n";
        }
    }

    void displayBooks() {
        std::cout << "Books List:\n";
        for (const auto& book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << "\n";
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "Publisher A");
    system.addPublisher(2, "Publisher B");
    system.addBook(1, "Book 1", 1);
    system.addBook(2, "Book 2", 2);
    system.displayPublishers();
    system.displayBooks();
    system.searchPublisher(1);
    system.searchBook(1);
    system.updatePublisher(1, "Updated Publisher A");
    system.updateBook(1, "Updated Book 1", 2);
    system.displayPublishers();
    system.displayBooks();
    system.deletePublisher(2);
    system.deleteBook(2);
    system.displayPublishers();
    system.displayBooks();
    return 0;
}