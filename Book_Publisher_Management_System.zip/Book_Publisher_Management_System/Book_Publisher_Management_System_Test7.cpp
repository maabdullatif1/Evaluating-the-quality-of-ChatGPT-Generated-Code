#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    std::string name;
    std::string address;

    Publisher(const std::string& name, const std::string& address)
        : name(name), address(address) {}
};

class Book {
public:
    std::string title;
    std::string author;
    std::string isbn;
    Publisher* publisher;

    Book(const std::string& title, const std::string& author, const std::string& isbn, Publisher* publisher)
        : title(title), author(author), isbn(isbn), publisher(publisher) {}
};

class BookPublisherManager {
    std::vector<Publisher> publishers;
    std::vector<Book> books;

public:
    void addPublisher(const std::string& name, const std::string& address) {
        publishers.push_back(Publisher(name, address));
    }

    void updatePublisher(int index, const std::string& name, const std::string& address) {
        if (index >= 0 && index < publishers.size()) {
            publishers[index].name = name;
            publishers[index].address = address;
        }
    }

    void deletePublisher(int index) {
        if (index >= 0 && index < publishers.size()) {
            publishers.erase(publishers.begin() + index);
        }
    }

    void addBook(const std::string& title, const std::string& author, const std::string& isbn, int publisherIndex) {
        if (publisherIndex >= 0 && publisherIndex < publishers.size()) {
            books.push_back(Book(title, author, isbn, &publishers[publisherIndex]));
        }
    }

    void updateBook(int index, const std::string& title, const std::string& author, const std::string& isbn, int publisherIndex) {
        if (index >= 0 && index < books.size() && publisherIndex >= 0 && publisherIndex < publishers.size()) {
            books[index].title = title;
            books[index].author = author;
            books[index].isbn = isbn;
            books[index].publisher = &publishers[publisherIndex];
        }
    }

    void deleteBook(int index) {
        if (index >= 0 && index < books.size()) {
            books.erase(books.begin() + index);
        }
    }

    void searchBooksByTitle(const std::string& title) {
        for (const auto& book : books) {
            if (book.title == title) {
                std::cout << "Found Book: " << book.title << ", Author: " << book.author
                          << ", ISBN: " << book.isbn << ", Publisher: " << book.publisher->name << "\n";
            }
        }
    }

    void searchPublisherByName(const std::string& name) {
        for (const auto& publisher : publishers) {
            if (publisher.name == name) {
                std::cout << "Found Publisher: " << publisher.name << ", Address: " << publisher.address << "\n";
            }
        }
    }

    void displayAllBooks() {
        for (const auto& book : books) {
            std::cout << "Book: " << book.title << ", Author: " << book.author
                      << ", ISBN: " << book.isbn << ", Publisher: " << book.publisher->name << "\n";
        }
    }

    void displayAllPublishers() {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher: " << publisher.name << ", Address: " << publisher.address << "\n";
        }
    }
};

int main() {
    BookPublisherManager manager;
    manager.addPublisher("HarperCollins", "New York");
    manager.addPublisher("Penguin Random House", "London");
    manager.addBook("Book Title", "Author Name", "123456789", 0);
    manager.displayAllBooks();
    manager.displayAllPublishers();
    manager.searchBooksByTitle("Book Title");
    manager.searchPublisherByName("HarperCollins");
    return 0;
}