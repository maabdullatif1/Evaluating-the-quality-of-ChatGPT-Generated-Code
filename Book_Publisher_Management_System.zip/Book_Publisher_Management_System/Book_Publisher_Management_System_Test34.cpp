#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    Publisher(const std::string& name, const std::string& address) 
        : name(name), address(address) {}

    void setName(const std::string& name) { this->name = name; }
    std::string getName() const { return name; }

    void setAddress(const std::string& address) { this->address = address; }
    std::string getAddress() const { return address; }

private:
    std::string name;
    std::string address;
};

class Book {
public:
    Book(const std::string& title, const std::string& author, const std::string& isbn, Publisher* publisher)
        : title(title), author(author), isbn(isbn), publisher(publisher) {}

    void setTitle(const std::string& title) { this->title = title; }
    std::string getTitle() const { return title; }

    void setAuthor(const std::string& author) { this->author = author; }
    std::string getAuthor() const { return author; }

    void setISBN(const std::string& isbn) { this->isbn = isbn; }
    std::string getISBN() const { return isbn; }

    void setPublisher(Publisher* publisher) { this->publisher = publisher; }
    Publisher* getPublisher() const { return publisher; }

private:
    std::string title;
    std::string author;
    std::string isbn;
    Publisher* publisher;
};

class ManagementSystem {
public:
    void addPublisher(const std::string& name, const std::string& address) {
        publishers.push_back(new Publisher(name, address));
    }

    void deletePublisher(const std::string& name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if ((*it)->getName() == name) {
                delete *it;
                publishers.erase(it);
                break;
            }
        }
    }

    Publisher* searchPublisher(const std::string& name) {
        for (auto& publisher : publishers) {
            if (publisher->getName() == name) {
                return publisher;
            }
        }
        return nullptr;
    }

    void addBook(const std::string& title, const std::string& author, const std::string& isbn, Publisher* publisher) {
        books.push_back(new Book(title, author, isbn, publisher));
    }

    void deleteBook(const std::string& isbn) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if ((*it)->getISBN() == isbn) {
                delete *it;
                books.erase(it);
                break;
            }
        }
    }

    Book* searchBook(const std::string& isbn) {
        for (auto& book : books) {
            if (book->getISBN() == isbn) {
                return book;
            }
        }
        return nullptr;
    }

    void updateBook(const std::string& isbn, const std::string& newTitle, const std::string& newAuthor, Publisher* newPublisher) {
        Book* book = searchBook(isbn);
        if (book) {
            book->setTitle(newTitle);
            book->setAuthor(newAuthor);
            book->setPublisher(newPublisher);
        }
    }

    void displayPublishers() const {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher: " << publisher->getName() << ", Address: " << publisher->getAddress() << std::endl;
        }
    }

    void displayBooks() const {
        for (const auto& book : books) {
            std::cout << "Book: " << book->getTitle() << ", Author: " << book->getAuthor()
                      << ", ISBN: " << book->getISBN() << ", Publisher: " << book->getPublisher()->getName() << std::endl;
        }
    }

    ~ManagementSystem() {
        for (auto& publisher : publishers) {
            delete publisher;
        }
        for (auto& book : books) {
            delete book;
        }
    }

private:
    std::vector<Publisher*> publishers;
    std::vector<Book*> books;
};

int main() {
    ManagementSystem system;
    system.addPublisher("O'Reilly Media", "1005 Gravenstein Highway North");
    system.addPublisher("Penguin Random House", "1745 Broadway, New York City");

    Publisher* oreilly = system.searchPublisher("O'Reilly Media");
    Publisher* penguin = system.searchPublisher("Penguin Random House");

    system.addBook("C++ Primer", "Stanley B. Lippman", "0321714113", oreilly);
    system.addBook("Effective Modern C++", "Scott Meyers", "1491903996", oreilly);
    system.addBook("1984", "George Orwell", "0451524934", penguin);

    system.displayPublishers();
    system.displayBooks();

    system.deleteBook("0321714113");
    system.deletePublisher("Penguin Random House");

    system.displayPublishers();
    system.displayBooks();

    return 0;
}