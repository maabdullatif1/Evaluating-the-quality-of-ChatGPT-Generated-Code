#include <iostream>
#include <vector>
#include <string>

struct Publisher {
    int id;
    std::string name;
};

struct Book {
    int id;
    std::string title;
    int publisherId;
};

class PublisherManager {
public:
    void addPublisher(int id, std::string name) {
        Publisher p = { id, name };
        publishers.push_back(p);
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, std::string name) {
        for (auto& pub : publishers) {
            if (pub.id == id) {
                pub.name = name;
                break;
            }
        }
    }

    Publisher* searchPublisher(int id) {
        for (auto& pub : publishers) {
            if (pub.id == id) {
                return &pub;
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto& pub : publishers) {
            std::cout << "Publisher ID: " << pub.id << ", Name: " << pub.name << '\n';
        }
    }

private:
    std::vector<Publisher> publishers;
};

class BookManager {
public:
    void addBook(int id, std::string title, int publisherId) {
        Book b = { id, title, publisherId };
        books.push_back(b);
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string title, int publisherId) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.publisherId = publisherId;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << '\n';
        }
    }

private:
    std::vector<Book> books;
};

int main() {
    PublisherManager pubMgr;
    BookManager bookMgr;

    pubMgr.addPublisher(1, "Penguin Random House");
    pubMgr.addPublisher(2, "HarperCollins");
    bookMgr.addBook(101, "1984", 1);
    bookMgr.addBook(102, "To Kill a Mockingbird", 2);

    std::cout << "Publishers:\n";
    pubMgr.displayPublishers();

    std::cout << "\nBooks:\n";
    bookMgr.displayBooks();

    return 0;
}