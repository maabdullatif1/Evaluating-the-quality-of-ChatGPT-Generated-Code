#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Publisher {
public:
    int id;
    string name;
    string address;

    Publisher(int i, string n, string a) : id(i), name(n), address(a) {}
};

class Book {
public:
    int id;
    string title;
    string author;
    int publisherId;

    Book(int i, string t, string a, int pId) : id(i), title(t), author(a), publisherId(pId) {}
};

class ManagementSystem {
    vector<Publisher> publishers;
    vector<Book> books;

public:
    void addPublisher(int id, string name, string address) {
        publishers.push_back(Publisher(id, name, address));
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, string name, string address) {
        for (auto& pub : publishers) {
            if (pub.id == id) {
                pub.name = name;
                pub.address = address;
                break;
            }
        }
    }

    Publisher* searchPublisher(int id) {
        for (auto& pub : publishers) {
            if (pub.id == id) return &pub;
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto& pub : publishers) {
            cout << "ID: " << pub.id << ", Name: " << pub.name << ", Address: " << pub.address << endl;
        }
    }

    void addBook(int id, string title, string author, int publisherId) {
        books.push_back(Book(id, title, author, publisherId));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string title, string author, int publisherId) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                book.publisherId = publisherId;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) return &book;
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "HarperCollins", "195 Broadway, New York, NY");
    system.addPublisher(2, "Penguin Books", "80 Strand, London");
    
    system.addBook(101, "1984", "George Orwell", 2);
    system.addBook(102, "To Kill a Mockingbird", "Harper Lee", 1);
    
    system.displayPublishers();
    system.displayBooks();
    
    return 0;
}