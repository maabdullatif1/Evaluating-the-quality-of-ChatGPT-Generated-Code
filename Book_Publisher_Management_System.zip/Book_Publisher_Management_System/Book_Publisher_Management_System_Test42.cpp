#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    std::string address;

    Publisher(int id, const std::string& name, const std::string& address)
        : id(id), name(name), address(address) {}
};

class Book {
public:
    int id;
    std::string title;
    int publisherId;

    Book(int id, const std::string& title, int publisherId)
        : id(id), title(title), publisherId(publisherId) {}
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;
    int nextPublisherId = 1;
    int nextBookId = 1;

    Publisher* findPublisherById(int id) {
        for (auto& publisher : publishers)
            if (publisher.id == id)
                return &publisher;
        return nullptr;
    }

    Book* findBookById(int id) {
        for (auto& book : books)
            if (book.id == id)
                return &book;
        return nullptr;
    }

public:
    void addPublisher(const std::string& name, const std::string& address) {
        publishers.push_back(Publisher(nextPublisherId++, name, address));
    }

    void deletePublisher(int publisherId) {
        publishers.erase(std::remove_if(publishers.begin(), publishers.end(),
            [publisherId](const Publisher& p) { return p.id == publisherId; }),
            publishers.end());
    }

    void updatePublisher(int publisherId, const std::string& name, const std::string& address) {
        Publisher* publisher = findPublisherById(publisherId);
        if (publisher) {
            publisher->name = name;
            publisher->address = address;
        }
    }

    void displayPublisher(int publisherId) {
        Publisher* publisher = findPublisherById(publisherId);
        if (publisher) {
            std::cout << "Publisher ID: " << publisher->id 
                      << " Name: " << publisher->name 
                      << " Address: " << publisher->address << std::endl;
        }
    }

    void addBook(const std::string& title, int publisherId) {
        books.push_back(Book(nextBookId++, title, publisherId));
    }

    void deleteBook(int bookId) {
        books.erase(std::remove_if(books.begin(), books.end(),
            [bookId](const Book& b) { return b.id == bookId; }),
            books.end());
    }

    void updateBook(int bookId, const std::string& title, int publisherId) {
        Book* book = findBookById(bookId);
        if (book) {
            book->title = title;
            book->publisherId = publisherId;
        }
    }

    void displayBook(int bookId) {
        Book* book = findBookById(bookId);
        if (book) {
            std::cout << "Book ID: " << book->id 
                      << " Title: " << book->title 
                      << " Publisher ID: " << book->publisherId << std::endl;
        }
    }

    void searchBooksByPublisher(int publisherId) {
        for (const auto& book : books) {
            if (book.publisherId == publisherId) {
                std::cout << "Book ID: " << book.id 
                          << " Title: " << book.title << std::endl;
            }
        }
    }

    void displayAllPublishers() {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id 
                      << " Name: " << publisher.name 
                      << " Address: " << publisher.address << std::endl;
        }
    }

    void displayAllBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id 
                      << " Title: " << book.title 
                      << " Publisher ID: " << book.publisherId << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("Publisher One", "123 Main St");
    system.addPublisher("Publisher Two", "456 Elm St");
    system.addBook("Book A", 1);
    system.addBook("Book B", 1);
    system.addBook("Book C", 2);
    system.updatePublisher(1, "Updated Publisher One", "789 Oak St");
    system.updateBook(2, "Updated Book B", 2);
    system.displayAllPublishers();
    system.displayAllBooks();
    system.deleteBook(1);
    system.deletePublisher(2);
    system.displayAllPublishers();
    system.displayAllBooks();
    system.searchBooksByPublisher(1);
    return 0;
}