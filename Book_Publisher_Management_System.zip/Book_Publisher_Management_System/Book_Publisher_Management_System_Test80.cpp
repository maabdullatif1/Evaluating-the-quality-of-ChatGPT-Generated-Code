#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Publisher {
    string name;
    string address;
    string phone;
};

struct Book {
    string title;
    string author;
    string isbn;
    Publisher publisher;
};

class ManagementSystem {
    vector<Book> books;
    
public:
    void addBook() {
        Book book;
        Publisher publisher;
        cout << "Enter Book Title: "; getline(cin, book.title);
        cout << "Enter Book Author: "; getline(cin, book.author);
        cout << "Enter Book ISBN: "; getline(cin, book.isbn);
        cout << "Enter Publisher Name: "; getline(cin, publisher.name);
        cout << "Enter Publisher Address: "; getline(cin, publisher.address);
        cout << "Enter Publisher Phone: "; getline(cin, publisher.phone);
        book.publisher = publisher;
        books.push_back(book);
    }

    void deleteBook() {
        string isbn;
        cout << "Enter ISBN of the book to delete: "; getline(cin, isbn);
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->isbn == isbn) {
                books.erase(it);
                cout << "Book deleted.\n";
                return;
            }
        }
        cout << "Book not found.\n";
    }

    void updateBook() {
        string isbn;
        cout << "Enter ISBN of the book to update: "; getline(cin, isbn);
        for (auto &book : books) {
            if (book.isbn == isbn) {
                cout << "Enter New Book Title: "; getline(cin, book.title);
                cout << "Enter New Book Author: "; getline(cin, book.author);
                cout << "Enter New Publisher Name: "; getline(cin, book.publisher.name);
                cout << "Enter New Publisher Address: "; getline(cin, book.publisher.address);
                cout << "Enter New Publisher Phone: "; getline(cin, book.publisher.phone);
                cout << "Book updated.\n";
                return;
            }
        }
        cout << "Book not found.\n";
    }

    void searchBook() {
        string isbn;
        cout << "Enter ISBN of the book to search: "; getline(cin, isbn);
        for (const auto &book : books) {
            if (book.isbn == isbn) {
                displayBook(book);
                return;
            }
        }
        cout << "Book not found.\n";
    }

    void displayBooks() const {
        if (books.empty()) {
            cout << "No books in the system.\n";
            return;
        }
        for (const auto &book : books) {
            displayBook(book);
        }
    }

private:
    void displayBook(const Book &book) const {
        cout << "Title: " << book.title << "\n";
        cout << "Author: " << book.author << "\n";
        cout << "ISBN: " << book.isbn << "\n";
        cout << "Publisher Name: " << book.publisher.name << "\n";
        cout << "Publisher Address: " << book.publisher.address << "\n";
        cout << "Publisher Phone: " << book.publisher.phone << "\n";
        cout << "---------------------------\n";
    }
};

int main() {
    ManagementSystem system;
    int choice;
    do {
        cout << "1. Add Book\n2. Delete Book\n3. Update Book\n4. Search Book\n5. Display All Books\n6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore();
        switch (choice) {
            case 1: system.addBook(); break;
            case 2: system.deleteBook(); break;
            case 3: system.updateBook(); break;
            case 4: system.searchBook(); break;
            case 5: system.displayBooks(); break;
            case 6: break;
            default: cout << "Invalid choice\n";
        }
    } while (choice != 6);
    return 0;
}