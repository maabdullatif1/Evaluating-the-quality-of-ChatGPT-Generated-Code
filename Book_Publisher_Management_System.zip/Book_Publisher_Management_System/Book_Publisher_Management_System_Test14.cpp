#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Book {
public:
    int id;
    string title;
    string author;
    int publisherId;
    Book(int id, string title, string author, int publisherId)
        : id(id), title(title), author(author), publisherId(publisherId) {}
};

class Publisher {
public:
    int id;
    string name;
    Publisher(int id, string name) : id(id), name(name) {}
};

class ManagementSystem {
private:
    vector<Book> books;
    vector<Publisher> publishers;

public:
    void addBook(int id, string title, string author, int publisherId) {
        books.emplace_back(id, title, author, publisherId);
    }

    void deleteBook(int id) {
        books.erase(remove_if(books.begin(), books.end(), [id](Book& b) { return b.id == id; }), books.end());
    }

    void updateBook(int id, string newTitle, string newAuthor, int newPublisherId) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = newTitle;
                book.author = newAuthor;
                book.publisherId = newPublisherId;
                return;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << endl;
                return;
            }
        }
        cout << "Book not found" << endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << endl;
        }
    }

    void addPublisher(int id, string name) {
        publishers.emplace_back(id, name);
    }

    void deletePublisher(int id) {
        publishers.erase(remove_if(publishers.begin(), publishers.end(), [id](Publisher& p) { return p.id == id; }), publishers.end());
    }

    void updatePublisher(int id, string newName) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = newName;
                return;
            }
        }
    }

    void searchPublisher(int id) {
        for (const auto& publisher : publishers) {
            if (publisher.id == id) {
                cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << endl;
                return;
            }
        }
        cout << "Publisher not found" << endl;
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << endl;
        }
    }
};

int main() {
    ManagementSystem ms;
    ms.addPublisher(1, "Penguin Random House");
    ms.addPublisher(2, "HarperCollins");
    ms.addBook(101, "1984", "George Orwell", 1);
    ms.addBook(102, "To Kill a Mockingbird", "Harper Lee", 2);
    ms.displayBooks();
    ms.displayPublishers();
    ms.searchBook(101);
    ms.searchPublisher(2);
    ms.updateBook(101, "Nineteen Eighty-Four", "George Orwell", 1);
    ms.updatePublisher(2, "HarperCollins Publishers");
    ms.displayBooks();
    ms.displayPublishers();
    ms.deleteBook(102);
    ms.deletePublisher(1);
    ms.displayBooks();
    ms.displayPublishers();
    return 0;
}