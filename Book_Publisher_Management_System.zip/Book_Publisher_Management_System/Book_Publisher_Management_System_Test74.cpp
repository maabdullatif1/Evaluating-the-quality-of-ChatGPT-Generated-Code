#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Publisher {
public:
    int id;
    string name;
    Publisher(int id, string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    string title;
    int publisherId;
    Book(int id, string title, int publisherId) : id(id), title(title), publisherId(publisherId) {}
};

class ManagementSystem {
    vector<Publisher> publishers;
    vector<Book> books;
public:
    void addPublisher(int id, string name) {
        publishers.push_back(Publisher(id, name));
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, string newName) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = newName;
                break;
            }
        }
    }

    void searchPublisher(int id) {
        for (const auto &publisher : publishers) {
            if (publisher.id == id) {
                cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << endl;
                return;
            }
        }
        cout << "Publisher not found." << endl;
    }

    void displayPublishers() {
        for (const auto &publisher : publishers) {
            cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << endl;
        }
    }

    void addBook(int id, string title, int publisherId) {
        books.push_back(Book(id, title, publisherId));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string newTitle) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = newTitle;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto &book : books) {
            if (book.id == id) {
                cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << endl;
                return;
            }
        }
        cout << "Book not found." << endl;
    }

    void displayBooks() {
        for (const auto &book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    
    system.addPublisher(1, "Publisher One");
    system.addPublisher(2, "Publisher Two");

    system.addBook(1, "Book A", 1);
    system.addBook(2, "Book B", 2);
    
    cout << "All Publishers:" << endl;
    system.displayPublishers();
    
    cout << "All Books:" << endl;
    system.displayBooks();
    
    return 0;
}