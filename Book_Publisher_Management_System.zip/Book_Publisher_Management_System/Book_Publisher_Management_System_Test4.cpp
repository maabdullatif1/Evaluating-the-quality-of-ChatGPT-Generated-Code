#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    std::string address;

    Publisher(int id, const std::string& name, const std::string& address)
        : id(id), name(name), address(address) {}
};

class Book {
public:
    int id;
    std::string title;
    int publisherId;

    Book(int id, const std::string& title, int publisherId)
        : id(id), title(title), publisherId(publisherId) {}
};

class ManagementSystem {
    std::vector<Publisher> publishers;
    std::vector<Book> books;

public:
    void addPublisher(int id, const std::string& name, const std::string& address) {
        publishers.push_back(Publisher(id, name, address));
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, const std::string& name, const std::string& address) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = name;
                publisher.address = address;
                break;
            }
        }
    }

    Publisher* searchPublisher(int id) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << ", Address: " << publisher.address << std::endl;
        }
    }

    void addBook(int id, const std::string& title, int publisherId) {
        books.push_back(Book(id, title, publisherId));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const std::string& title, int publisherId) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.publisherId = publisherId;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;

    system.addPublisher(1, "Publisher One", "Address One");
    system.addPublisher(2, "Publisher Two", "Address Two");

    system.addBook(101, "Book One", 1);
    system.addBook(102, "Book Two", 2);

    system.displayPublishers();
    system.displayBooks();

    system.updatePublisher(1, "Updated Publisher One", "New Address One");
    system.updateBook(101, "Updated Book One", 1);

    system.displayPublishers();
    system.displayBooks();

    Publisher* searchPub = system.searchPublisher(1);
    if (searchPub) {
        std::cout << "Found Publisher: " << searchPub->name << std::endl;
    }

    Book* searchBk = system.searchBook(101);
    if (searchBk) {
        std::cout << "Found Book: " << searchBk->title << std::endl;
    }

    system.deletePublisher(1);
    system.deleteBook(101);

    system.displayPublishers();
    system.displayBooks();

    return 0;
}