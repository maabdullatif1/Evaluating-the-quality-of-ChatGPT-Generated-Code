#include <iostream>
#include <string>
#include <vector>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    int publisherId;

    Book(int id, std::string title, std::string author, int publisherId)
        : id(id), title(title), author(author), publisherId(publisherId) {}
};

class Publisher {
public:
    int id;
    std::string name;

    Publisher(int id, std::string name) : id(id), name(name) {}
};

class PublisherManagementSystem {
    std::vector<Book> books;
    std::vector<Publisher> publishers;
    int bookIdCounter = 1;
    int publisherIdCounter = 1;

public:
    void addBook(std::string title, std::string author, int publisherId) {
        books.push_back(Book(bookIdCounter++, title, author, publisherId));
    }

    void addPublisher(std::string name) {
        publishers.push_back(Publisher(publisherIdCounter++, name));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                return;
            }
        }
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                return;
            }
        }
    }

    void updateBook(int id, std::string title, std::string author, int publisherId) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                book.publisherId = publisherId;
                return;
            }
        }
    }

    void updatePublisher(int id, std::string name) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = name;
                return;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    Publisher* searchPublisher(int id) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto &book : books) {
            std::cout << "Book ID: " << book.id
                      << ", Title: " << book.title
                      << ", Author: " << book.author
                      << ", Publisher ID: " << book.publisherId << '\n';
        }
    }

    void displayPublishers() {
        for (const auto &publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id
                      << ", Name: " << publisher.name << '\n';
        }
    }
};

int main() {
    PublisherManagementSystem pms;
    pms.addPublisher("Penguin Random House");
    pms.addPublisher("HarperCollins");
    pms.addBook("The Great Gatsby", "F. Scott Fitzgerald", 1);
    pms.addBook("To Kill a Mockingbird", "Harper Lee", 2);
    pms.displayPublishers();
    pms.displayBooks();
    pms.updateBook(1, "The Great Gatsby", "F. Scott Fitzgerald", 2);
    pms.displayBooks();
    pms.deleteBook(2);
    pms.displayBooks();
    return 0;
}