#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Publisher {
public:
    int id;
    string name;
    string address;
    
    Publisher(int id, string name, string address)
        : id(id), name(name), address(address) {}
};

class Book {
public:
    int id;
    string title;
    string author;
    int publisher_id;
    
    Book(int id, string title, string author, int publisher_id)
        : id(id), title(title), author(author), publisher_id(publisher_id) {}
};

class System {
    vector<Publisher> publishers;
    vector<Book> books;

    Publisher* findPublisherById(int id) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) return &publisher;
        }
        return nullptr;
    }

    Book* findBookById(int id) {
        for (auto& book : books) {
            if (book.id == id) return &book;
        }
        return nullptr;
    }

public:
    void addPublisher(int id, string name, string address) {
        publishers.push_back(Publisher(id, name, address));
    }
    
    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }
    
    void updatePublisher(int id, string name, string address) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            publisher->name = name;
            publisher->address = address;
        }
    }
    
    void searchPublisher(int id) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            cout << "Publisher ID: " << publisher->id << ", Name: " << publisher->name 
                 << ", Address: " << publisher->address << endl;
        } else {
            cout << "Publisher not found" << endl;
        }
    }
    
    void displayPublishers() {
        for (const auto& publisher : publishers) {
            cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name 
                 << ", Address: " << publisher.address << endl;
        }
    }
    
    void addBook(int id, string title, string author, int publisher_id) {
        books.push_back(Book(id, title, author, publisher_id));
    }
    
    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }
    
    void updateBook(int id, string title, string author, int publisher_id) {
        Book* book = findBookById(id);
        if (book) {
            book->title = title;
            book->author = author;
            book->publisher_id = publisher_id;
        }
    }
    
    void searchBook(int id) {
        Book* book = findBookById(id);
        if (book) {
            cout << "Book ID: " << book->id << ", Title: " << book->title 
                 << ", Author: " << book->author << ", Publisher ID: " << book->publisher_id << endl;
        } else {
            cout << "Book not found" << endl;
        }
    }
    
    void displayBooks() {
        for (const auto& book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title 
                 << ", Author: " << book.author << ", Publisher ID: " << book.publisher_id << endl;
        }
    }
};

int main() {
    System system;
    system.addPublisher(1, "Publisher One", "123 Street");
    system.addBook(1, "Book One", "Author One", 1);
    
    system.displayPublishers();
    system.displayBooks();
    
    system.updatePublisher(1, "Updated Publisher One", "456 Avenue");
    system.updateBook(1, "Updated Book One", "Updated Author One", 1);
    
    system.searchPublisher(1);
    system.searchBook(1);
    
    system.deletePublisher(1);
    system.deleteBook(1);
    
    system.displayPublishers();
    system.displayBooks();
    
    return 0;
}