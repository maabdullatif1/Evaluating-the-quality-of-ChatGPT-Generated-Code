#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Publisher {
public:
    string name;
    string address;
};

class Book {
public:
    string title;
    string author;
    Publisher publisher;
};

vector<Publisher> publishers;
vector<Book> books;

void addPublisher() {
    Publisher publisher;
    cout << "Enter publisher name: ";
    getline(cin, publisher.name);
    cout << "Enter publisher address: ";
    getline(cin, publisher.address);
    publishers.push_back(publisher);
}

void addBook() {
    Book book;
    cout << "Enter book title: ";
    getline(cin, book.title);
    cout << "Enter book author: ";
    getline(cin, book.author);

    cout << "Available publishers: " << endl;
    for (size_t i = 0; i < publishers.size(); ++i) {
        cout << i + 1 << ". " << publishers[i].name << " - " << publishers[i].address << endl;
    }
    int publisherIndex;
    cout << "Select publisher (by number): ";
    cin >> publisherIndex;
    cin.ignore();
    book.publisher = publishers[publisherIndex - 1];
    books.push_back(book);
}

void displayPublishers() {
    for (const auto& publisher : publishers) {
        cout << "Publisher Name: " << publisher.name 
             << ", Address: " << publisher.address << endl;
    }
}

void displayBooks() {
    for (const auto& book : books) {
        cout << "Book Title: " << book.title 
             << ", Author: " << book.author 
             << ", Publisher: " << book.publisher.name 
             << ", Address: " << book.publisher.address << endl;
    }
}

void searchBook() {
    string title;
    cout << "Enter book title to search: ";
    getline(cin, title);
    for (const auto& book : books) {
        if (book.title == title) {
            cout << "Book Title: " << book.title 
                 << ", Author: " << book.author 
                 << ", Publisher: " << book.publisher.name 
                 << ", Address: " << book.publisher.address << endl;
            return;
        }
    }
    cout << "Book not found!" << endl;
}

void updateBook() {
    string title;
    cout << "Enter book title to update: ";
    getline(cin, title);
    for (auto& book : books) {
        if (book.title == title) {
            cout << "Enter new book title: ";
            getline(cin, book.title);
            cout << "Enter new book author: ";
            getline(cin, book.author);

            cout << "Available publishers: " << endl;
            for (size_t i = 0; i < publishers.size(); ++i) {
                cout << i + 1 << ". " << publishers[i].name << " - " << publishers[i].address << endl;
            }
            int publisherIndex;
            cout << "Select new publisher (by number): ";
            cin >> publisherIndex;
            cin.ignore();
            book.publisher = publishers[publisherIndex - 1];
            return;
        }
    }
    cout << "Book not found!" << endl;
}

void deleteBook() {
    string title;
    cout << "Enter book title to delete: ";
    getline(cin, title);
    for (auto it = books.begin(); it != books.end(); ++it) {
        if (it->title == title) {
            books.erase(it);
            cout << "Book deleted!" << endl;
            return;
        }
    }
    cout << "Book not found!" << endl;
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Publisher" << endl;
        cout << "2. Add Book" << endl;
        cout << "3. Display Publishers" << endl;
        cout << "4. Display Books" << endl;
        cout << "5. Search Book" << endl;
        cout << "6. Update Book" << endl;
        cout << "7. Delete Book" << endl;
        cout << "8. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;
        cin.ignore();
        switch (choice) {
            case 1: addPublisher(); break;
            case 2: addBook(); break;
            case 3: displayPublishers(); break;
            case 4: displayBooks(); break;
            case 5: searchBook(); break;
            case 6: updateBook(); break;
            case 7: deleteBook(); break;
            case 8: return 0;
            default: cout << "Invalid choice!" << endl; break;
        }
    }
}