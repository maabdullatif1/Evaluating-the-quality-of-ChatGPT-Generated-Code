#include <iostream>
#include <string>
#include <vector>

class Publisher {
public:
    int id;
    std::string name;

    Publisher(int id, const std::string& name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;
    int publisherId;

    Book(int id, const std::string& title, int publisherId) : id(id), title(title), publisherId(publisherId) {}
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;

    Publisher* findPublisherById(int id) {
        for (auto &publisher : publishers)
            if (publisher.id == id)
                return &publisher;
        return nullptr;
    }

    Book* findBookById(int id) {
        for (auto &book : books)
            if (book.id == id)
                return &book;
        return nullptr;
    }

public:
    void addPublisher(int id, const std::string& name) {
        publishers.push_back(Publisher(id, name));
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, const std::string& newName) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            publisher->name = newName;
        }
    }

    void searchPublisher(int id) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            std::cout << "Publisher ID: " << publisher->id << ", Name: " << publisher->name << "\n";
        } else {
            std::cout << "Publisher not found\n";
        }
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << "\n";
        }
    }

    void addBook(int id, const std::string& title, int publisherId) {
        books.push_back(Book(id, title, publisherId));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const std::string& newTitle, int newPublisherId) {
        Book* book = findBookById(id);
        if (book) {
            book->title = newTitle;
            book->publisherId = newPublisherId;
        }
    }

    void searchBook(int id) {
        Book* book = findBookById(id);
        if (book) {
            std::cout << "Book ID: " << book->id << ", Title: " << book->title << ", Publisher ID: " << book->publisherId << "\n";
        } else {
            std::cout << "Book not found\n";
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << "\n";
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "Publisher One");
    system.addPublisher(2, "Publisher Two");

    system.addBook(101, "Book One", 1);
    system.addBook(102, "Book Two", 2);

    std::cout << "Displaying all publishers:\n";
    system.displayPublishers();
    std::cout << "\nDisplaying all books:\n";
    system.displayBooks();

    std::cout << "\nSearching for Publisher with ID 1:\n";
    system.searchPublisher(1);

    std::cout << "\nSearching for Book with ID 101:\n";
    system.searchBook(101);

    std::cout << "\nUpdating Publisher ID 1 to 'Updated Publisher One':\n";
    system.updatePublisher(1, "Updated Publisher One");
    system.displayPublishers();

    std::cout << "\nUpdating Book ID 101 to 'Updated Book One' with Publisher ID 2:\n";
    system.updateBook(101, "Updated Book One", 2);
    system.displayBooks();

    std::cout << "\nDeleting Publisher with ID 2:\n";
    system.deletePublisher(2);
    system.displayPublishers();

    std::cout << "\nDeleting Book with ID 102:\n";
    system.deleteBook(102);
    system.displayBooks();

    return 0;
}