#include <iostream>
#include <string>
#include <vector>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    int publisherId;

    Book(int id, std::string title, std::string author, int publisherId)
        : id(id), title(title), author(author), publisherId(publisherId) {}
};

class Publisher {
public:
    int id;
    std::string name;

    Publisher(int id, std::string name) : id(id), name(name) {}
};

class ManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Publisher> publishers;

public:
    void addBook(int id, std::string title, std::string author, int publisherId) {
        books.push_back(Book(id, title, author, publisherId));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string title, std::string author, int publisherId) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                book.publisherId = publisherId;
                break;
            }
        }
    }
    
    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }
    
    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title 
                      << ", Author: " << book.author << ", Publisher ID: " 
                      << book.publisherId << std::endl;
        }
    }

    void addPublisher(int id, std::string name) {
        publishers.push_back(Publisher(id, name));
    }
    
    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, std::string name) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = name;
                break;
            }
        }
    }

    Publisher* searchPublisher(int id) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;

    system.addPublisher(1, "Publisher A");
    system.addPublisher(2, "Publisher B");
    
    system.addBook(101, "Book 1", "Author A", 1);
    system.addBook(102, "Book 2", "Author B", 2);

    system.displayBooks();
    system.displayPublishers();
    
    system.updateBook(101, "Updated Book 1", "Author A", 1);
    system.updatePublisher(1, "Updated Publisher A");
    
    system.displayBooks();
    system.displayPublishers();

    system.deleteBook(102);
    system.deletePublisher(2);

    system.displayBooks();
    system.displayPublishers();

    return 0;
}