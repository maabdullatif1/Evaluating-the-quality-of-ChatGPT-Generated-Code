#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    float price;

    Book(int id, std::string title, std::string author, float price)
        : id(id), title(title), author(author), price(price) {}
};

class Publisher {
public:
    int id;
    std::string name;
    std::string address;
    std::vector<Book> books;

    Publisher(int id, std::string name, std::string address)
        : id(id), name(name), address(address) {}
};

class ManagementSystem {
    std::vector<Publisher> publishers;
    int bookIdCounter = 0;
    int publisherIdCounter = 0;

    Publisher* findPublisher(int id) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    Book* findBook(Publisher &publisher, int id) {
        for (auto &book : publisher.books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

public:
    void addPublisher(std::string name, std::string address) {
        publishers.push_back(Publisher(++publisherIdCounter, name, address));
    }

    void deletePublisher(int id) {
        publishers.erase(std::remove_if(publishers.begin(), publishers.end(),
                                        [id](Publisher &pub) { return pub.id == id; }),
                         publishers.end());
    }

    void updatePublisher(int id, std::string name, std::string address) {
        Publisher* publisher = findPublisher(id);
        if (publisher) {
            publisher->name = name;
            publisher->address = address;
        }
    }

    Publisher* searchPublisher(int id) {
        return findPublisher(id);
    }

    void displayPublishers() {
        for (auto &publisher : publishers) {
            std::cout << publisher.id << " " << publisher.name << " " << publisher.address << std::endl;
        }
    }

    void addBook(int publisherId, std::string title, std::string author, float price) {
        Publisher* publisher = findPublisher(publisherId);
        if (publisher) {
            publisher->books.push_back(Book(++bookIdCounter, title, author, price));
        }
    }

    void deleteBook(int publisherId, int bookId) {
        Publisher* publisher = findPublisher(publisherId);
        if (publisher) {
            publisher->books.erase(std::remove_if(publisher->books.begin(), publisher->books.end(),
                                                  [bookId](Book &book) { return book.id == bookId; }),
                                   publisher->books.end());
        }
    }

    void updateBook(int publisherId, int bookId, std::string title, std::string author, float price) {
        Publisher* publisher = findPublisher(publisherId);
        if (publisher) {
            Book* book = findBook(*publisher, bookId);
            if (book) {
                book->title = title;
                book->author = author;
                book->price = price;
            }
        }
    }

    Book* searchBook(int publisherId, int bookId) {
        Publisher* publisher = findPublisher(publisherId);
        if (publisher) {
            return findBook(*publisher, bookId);
        }
        return nullptr;
    }

    void displayBooks(int publisherId) {
        Publisher* publisher = findPublisher(publisherId);
        if (publisher) {
            for (auto &book : publisher->books) {
                std::cout << book.id << " " << book.title << " " << book.author << " " << book.price << std::endl;
            }
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("Publisher A", "Address A");
    system.addBook(1, "Book A1", "Author A1", 10.99);
    system.addBook(1, "Book A2", "Author A2", 15.99);
    system.displayPublishers();
    system.displayBooks(1);
    system.updateBook(1, 1, "Book A1 Updated", "Author A1", 12.99);
    system.displayBooks(1);
    system.deleteBook(1, 2);
    system.displayBooks(1);
    system.updatePublisher(1, "Publisher A Updated", "Address A");
    system.displayPublishers();
    return 0;
}