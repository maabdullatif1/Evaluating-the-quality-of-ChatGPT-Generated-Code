#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Publisher {
public:
    string name;
    string address;

    Publisher(string n, string a) : name(n), address(a) {}
};

class Book {
public:
    string title;
    string author;
    Publisher* publisher;

    Book(string t, string a, Publisher* p) : title(t), author(a), publisher(p) {}
};

class ManagementSystem {
private:
    vector<Publisher*> publishers;
    vector<Book*> books;

public:
    void addPublisher(const string& name, const string& address) {
        publishers.push_back(new Publisher(name, address));
    }

    void addBook(const string& title, const string& author, const string& publisherName) {
        for (auto& pub : publishers) {
            if (pub->name == publisherName) {
                books.push_back(new Book(title, author, pub));
                return;
            }
        }
    }

    void deleteBook(const string& title) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if ((*it)->title == title) {
                delete (*it);
                books.erase(it);
                break;
            }
        }
    }

    void deletePublisher(const string& name) {
        for (auto it = publishers.begin(); it != publishers.end(); ) {
            if ((*it)->name == name) {
                delete (*it);
                it = publishers.erase(it);
            } else {
                ++it;
            }
        }
        books.erase(remove_if(books.begin(), books.end(), [&](Book* book) {
            if (book->publisher->name == name) {
                delete book;
                return true;
            }
            return false;
        }), books.end());
    }

    void updatePublisher(const string& name, const string& newAddress) {
        for (auto& pub : publishers) {
            if (pub->name == name) {
                pub->address = newAddress;
            }
        }
    }

    void updateBook(const string& title, const string& newTitle, const string& newAuthor) {
        for (auto& book : books) {
            if (book->title == title) {
                book->title = newTitle;
                book->author = newAuthor;
            }
        }
    }

    void displayPublishers() const {
        for (const auto& pub : publishers) {
            cout << "Publisher Name: " << pub->name << ", Address: " << pub->address << endl;
        }
    }

    void displayBooks() const {
        for (const auto& book : books) {
            cout << "Book Title: " << book->title << ", Author: " << book->author
                 << ", Publisher: " << book->publisher->name << endl;
        }
    }

    void searchBooksByTitle(const string& title) const {
        for (const auto& book : books) {
            if (book->title == title) {
                cout << "Book Title: " << book->title << ", Author: " << book->author
                     << ", Publisher: " << book->publisher->name << endl;
            }
        }
    }

    void searchPublishersByName(const string& name) const {
        for (const auto& pub : publishers) {
            if (pub->name == name) {
                cout << "Publisher Name: " << pub->name << ", Address: " << pub->address << endl;
            }
        }
    }

    ~ManagementSystem() {
        for (auto& book : books) {
            delete book;
        }
        for (auto& pub : publishers) {
            delete pub;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("HarperCollins", "123 Publisher Lane");
    system.addBook("The Great Gatsby", "F. Scott Fitzgerald", "HarperCollins");
    system.displayPublishers();
    system.displayBooks();
    system.updateBook("The Great Gatsby", "Gatsby", "Fitzgerald");
    system.displayBooks();
    system.searchBooksByTitle("Gatsby");
    system.deleteBook("Gatsby");
    system.displayBooks();
    system.deletePublisher("HarperCollins");
    system.displayPublishers();
    return 0;
}