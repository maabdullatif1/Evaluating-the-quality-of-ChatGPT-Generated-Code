#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    Publisher(int id, std::string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;
    int publisherId;
    Book(int id, std::string title, int publisherId) : id(id), title(title), publisherId(publisherId) {}
};

class ManagementSystem {
    std::vector<Publisher> publishers;
    std::vector<Book> books;

public:
    void addPublisher(int id, std::string name) {
        publishers.push_back(Publisher(id, name));
    }

    void addBook(int id, std::string title, int publisherId) {
        books.push_back(Book(id, title, publisherId));
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
        for (auto it = books.begin(); it != books.end();) {
            if (it->publisherId == id) {
                it = books.erase(it);
            } else {
                ++it;
            }
        }
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, std::string newName) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = newName;
                break;
            }
        }
    }

    void updateBook(int id, std::string newTitle, int newPublisherId) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = newTitle;
                book.publisherId = newPublisherId;
                break;
            }
        }
    }

    Publisher* searchPublisher(int id) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id << " Name: " << publisher.name << std::endl;
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << " Title: " << book.title << " Publisher ID: " << book.publisherId << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    
    system.addPublisher(1, "HarperCollins");
    system.addPublisher(2, "Penguin Random House");
    
    system.addBook(101, "1984", 1);
    system.addBook(102, "To Kill a Mockingbird", 2);

    system.displayPublishers();
    system.displayBooks();

    system.updatePublisher(1, "Harper");
    system.updateBook(101, "Nineteen Eighty-Four", 1);
    
    system.displayPublishers();
    system.displayBooks();
    
    system.deleteBook(102);
    system.deletePublisher(2);

    system.displayPublishers();
    system.displayBooks();

    return 0;
}