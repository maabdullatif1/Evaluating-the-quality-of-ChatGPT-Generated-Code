#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int bookID;
    std::string title;
    std::string author;
    int publisherID;

    Book(int id, std::string t, std::string a, int pID) : bookID(id), title(t), author(a), publisherID(pID) {}
};

class Publisher {
public:
    int publisherID;
    std::string name;
    std::string address;

    Publisher(int id, std::string n, std::string a) : publisherID(id), name(n), address(a) {}
};

class ManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Publisher> publishers;

public:
    void addBook(int id, std::string title, std::string author, int publisherID) {
        books.push_back(Book(id, title, author, publisherID));
    }
    
    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->bookID == id) {
                books.erase(it);
                break;
            }
        }
    }
    
    void updateBook(int id, std::string title, std::string author, int publisherID) {
        for (auto &book : books) {
            if (book.bookID == id) {
                book.title = title;
                book.author = author;
                book.publisherID = publisherID;
            }
        }
    }
    
    void searchBook(int id) {
        for (const auto &book : books) {
            if (book.bookID == id) {
                std::cout << "Book ID: " << book.bookID << ", Title: " << book.title 
                          << ", Author: " << book.author << ", Publisher ID: " << book.publisherID << std::endl;
            }
        }
    }
    
    void displayBooks() {
        for (const auto &book : books) {
            std::cout << "Book ID: " << book.bookID << ", Title: " << book.title 
                      << ", Author: " << book.author << ", Publisher ID: " << book.publisherID << std::endl;
        }
    }

    void addPublisher(int id, std::string name, std::string address) {
        publishers.push_back(Publisher(id, name, address));
    }
    
    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->publisherID == id) {
                publishers.erase(it);
                break;
            }
        }
    }
    
    void updatePublisher(int id, std::string name, std::string address) {
        for (auto &publisher : publishers) {
            if (publisher.publisherID == id) {
                publisher.name = name;
                publisher.address = address;
            }
        }
    }
    
    void searchPublisher(int id) {
        for (const auto &publisher : publishers) {
            if (publisher.publisherID == id) {
                std::cout << "Publisher ID: " << publisher.publisherID << ", Name: " << publisher.name 
                          << ", Address: " << publisher.address << std::endl;
            }
        }
    }
    
    void displayPublishers() {
        for (const auto &publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.publisherID << ", Name: " << publisher.name 
                      << ", Address: " << publisher.address << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;

    system.addPublisher(1, "Publisher One", "123 Main Street");
    system.addPublisher(2, "Publisher Two", "456 Broad Avenue");

    system.addBook(101, "Book Title 1", "Author A", 1);
    system.addBook(102, "Book Title 2", "Author B", 2);

    system.displayPublishers();
    system.displayBooks();

    system.searchBook(101);
    system.searchPublisher(2);

    system.updateBook(102, "Updated Book Title 2", "Updated Author B", 1);
    system.updatePublisher(1, "Updated Publisher One", "789 New Street");

    system.displayBooks();
    system.displayPublishers();

    system.deleteBook(101);
    system.deletePublisher(2);

    system.displayBooks();
    system.displayPublishers();

    return 0;
}