#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Publisher {
    int id;
    string name;
    string address;
};

struct Book {
    int id;
    string title;
    string author;
    int publisherId;
};

vector<Publisher> publishers;
vector<Book> books;

void addPublisher() {
    Publisher publisher;
    cout << "Enter Publisher ID: ";
    cin >> publisher.id;
    cin.ignore();
    cout << "Enter Publisher Name: ";
    getline(cin, publisher.name);
    cout << "Enter Publisher Address: ";
    getline(cin, publisher.address);
    publishers.push_back(publisher);
}

void deletePublisher() {
    int id;
    cout << "Enter Publisher ID to Delete: ";
    cin >> id;
    for (auto it = publishers.begin(); it != publishers.end(); ++it) {
        if (it->id == id) {
            publishers.erase(it);
            break;
        }
    }
}

void updatePublisher() {
    int id;
    cout << "Enter Publisher ID to Update: ";
    cin >> id;
    for (auto& publisher : publishers) {
        if (publisher.id == id) {
            cout << "Enter New Publisher Name: ";
            cin.ignore();
            getline(cin, publisher.name);
            cout << "Enter New Publisher Address: ";
            getline(cin, publisher.address);
            break;
        }
    }
}

void searchPublisher() {
    int id;
    cout << "Enter Publisher ID to Search: ";
    cin >> id;
    for (const auto& publisher : publishers) {
        if (publisher.id == id) {
            cout << "Publisher Found: " << publisher.name << ", Address: " << publisher.address << endl;
            return;
        }
    }
    cout << "Publisher Not Found" << endl;
}

void displayPublishers() {
    for (const auto& publisher : publishers) {
        cout << "ID: " << publisher.id << ", Name: " << publisher.name << ", Address: " << publisher.address << endl;
    }
}

void addBook() {
    Book book;
    cout << "Enter Book ID: ";
    cin >> book.id;
    cin.ignore();
    cout << "Enter Book Title: ";
    getline(cin, book.title);
    cout << "Enter Book Author: ";
    getline(cin, book.author);
    cout << "Enter Publisher ID for this Book: ";
    cin >> book.publisherId;
    books.push_back(book);
}

void deleteBook() {
    int id;
    cout << "Enter Book ID to Delete: ";
    cin >> id;
    for (auto it = books.begin(); it != books.end(); ++it) {
        if (it->id == id) {
            books.erase(it);
            break;
        }
    }
}

void updateBook() {
    int id;
    cout << "Enter Book ID to Update: ";
    cin >> id;
    for (auto& book : books) {
        if (book.id == id) {
            cin.ignore();
            cout << "Enter New Book Title: ";
            getline(cin, book.title);
            cout << "Enter New Book Author: ";
            getline(cin, book.author);
            cout << "Enter New Publisher ID for this Book: ";
            cin >> book.publisherId;
            break;
        }
    }
}

void searchBook() {
    int id;
    cout << "Enter Book ID to Search: ";
    cin >> id;
    for (const auto& book : books) {
        if (book.id == id) {
            cout << "Book Found: " << book.title << " by " << book.author << ", Publisher ID: " << book.publisherId << endl;
            return;
        }
    }
    cout << "Book Not Found" << endl;
}

void displayBooks() {
    for (const auto& book : books) {
        cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Publisher\n2. Delete Publisher\n3. Update Publisher\n4. Search Publisher\n5. Display Publishers\n";
        cout << "6. Add Book\n7. Delete Book\n8. Update Book\n9. Search Book\n10. Display Books\n11. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addPublisher(); break;
            case 2: deletePublisher(); break;
            case 3: updatePublisher(); break;
            case 4: searchPublisher(); break;
            case 5: displayPublishers(); break;
            case 6: addBook(); break;
            case 7: deleteBook(); break;
            case 8: updateBook(); break;
            case 9: searchBook(); break;
            case 10: displayBooks(); break;
            case 11: return 0;
            default: cout << "Invalid choice" << endl;
        }
    }
}