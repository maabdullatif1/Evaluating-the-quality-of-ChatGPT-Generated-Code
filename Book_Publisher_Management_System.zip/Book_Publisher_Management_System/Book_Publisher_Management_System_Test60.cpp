#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Publisher {
    int id;
    string name;
public:
    Publisher(int id, string name) : id(id), name(name) {}
    int getId() const { return id; }
    string getName() const { return name; }
    void setName(string newName) { name = newName; }
};

class Book {
    int id;
    string title;
    Publisher* publisher;
public:
    Book(int id, string title, Publisher* publisher) : id(id), title(title), publisher(publisher) {}
    int getId() const { return id; }
    string getTitle() const { return title; }
    Publisher* getPublisher() const { return publisher; }
    void setTitle(string newTitle) { title = newTitle; }
    void setPublisher(Publisher* newPublisher) { publisher = newPublisher; }
};

class ManagementSystem {
    vector<Publisher> publishers;
    vector<Book> books;
public:
    void addPublisher(int id, string name) {
        publishers.push_back(Publisher(id, name));
    }

    void deletePublisher(int id) {
        for (size_t i = 0; i < publishers.size(); ++i) {
            if (publishers[i].getId() == id) {
                publishers.erase(publishers.begin() + i);
                break;
            }
        }
    }

    Publisher* searchPublisher(int id) {
        for (auto& publisher : publishers) {
            if (publisher.getId() == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void updatePublisher(int id, string name) {
        Publisher* publisher = searchPublisher(id);
        if (publisher != nullptr) {
            publisher->setName(name);
        }
    }

    void displayPublishers() const {
        for (const auto& publisher : publishers) {
            cout << "Publisher ID: " << publisher.getId() << ", Name: " << publisher.getName() << endl;
        }
    }

    void addBook(int id, string title, int publisherId) {
        Publisher* publisher = searchPublisher(publisherId);
        if (publisher) {
            books.push_back(Book(id, title, publisher));
        }
    }

    void deleteBook(int id) {
        for (size_t i = 0; i < books.size(); ++i) {
            if (books[i].getId() == id) {
                books.erase(books.begin() + i);
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.getId() == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void updateBook(int id, string title, int publisherId) {
        Book* book = searchBook(id);
        Publisher* publisher = searchPublisher(publisherId);
        if (book && publisher) {
            book->setTitle(title);
            book->setPublisher(publisher);
        }
    }

    void displayBooks() const {
        for (const auto& book : books) {
            cout << "Book ID: " << book.getId() << ", Title: " << book.getTitle() << ", Publisher: " << book.getPublisher()->getName() << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    
    system.addPublisher(1, "HarperCollins");
    system.addPublisher(2, "Penguin Random House");

    system.addBook(100, "1984", 2);
    system.addBook(101, "To Kill a Mockingbird", 1);

    cout << "Publishers:" << endl;
    system.displayPublishers();
    
    cout << "Books:" << endl;
    system.displayBooks();
    
    return 0;
}