#include <iostream>
#include <string>
#include <vector>

class Publisher {
public:
    std::string name;
    std::string address;
    std::string phone;

    Publisher(const std::string& n, const std::string& a, const std::string& p)
        : name(n), address(a), phone(p) {}
};

class Book {
public:
    std::string title;
    std::string author;
    std::string isbn;
    Publisher* publisher;

    Book(const std::string& t, const std::string& a, const std::string& i, Publisher* p)
        : title(t), author(a), isbn(i), publisher(p) {}
};

class ManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Publisher> publishers;

    Publisher* findPublisher(const std::string& name) {
        for (auto& publisher : publishers) {
            if (publisher.name == name) {
                return &publisher;
            }
        }
        return nullptr;
    }

public:
    void addPublisher(const std::string& name, const std::string& address, const std::string& phone) {
        publishers.push_back(Publisher(name, address, phone));
    }

    void deletePublisher(const std::string& name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->name == name) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(const std::string& name, const std::string& newAddress, const std::string& newPhone) {
        Publisher* publisher = findPublisher(name);
        if (publisher) {
            publisher->address = newAddress;
            publisher->phone = newPhone;
        }
    }

    void searchPublisher(const std::string& name) {
        Publisher* publisher = findPublisher(name);
        if (publisher) {
            std::cout << "Publisher found: " << publisher->name << ", " << publisher->address << ", " << publisher->phone << std::endl;
        } else {
            std::cout << "Publisher not found" << std::endl;
        }
    }

    void displayPublishers() {
        for (auto& publisher : publishers) {
            std::cout << publisher.name << ", " << publisher.address << ", " << publisher.phone << std::endl;
        }
    }

    void addBook(const std::string& title, const std::string& author, const std::string& isbn, const std::string& publisherName) {
        Publisher* publisher = findPublisher(publisherName);
        if (publisher) {
            books.push_back(Book(title, author, isbn, publisher));
        }
    }

    void deleteBook(const std::string& isbn) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->isbn == isbn) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(const std::string& isbn, const std::string& newTitle, const std::string& newAuthor) {
        for (auto& book : books) {
            if (book.isbn == isbn) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }

    void searchBook(const std::string& isbn) {
        for (auto& book : books) {
            if (book.isbn == isbn) {
                std::cout << "Book found: " << book.title << ", " << book.author << ", " << book.isbn << ", Publisher: " << book.publisher->name << std::endl;
                return;
            }
        }
        std::cout << "Book not found" << std::endl;
    }

    void displayBooks() {
        for (auto& book : books) {
            std::cout << book.title << ", " << book.author << ", " << book.isbn << ", Publisher: " << book.publisher->name << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("HarperCollins", "New York", "123456789");
    system.addBook("The Great Gatsby", "F. Scott Fitzgerald", "9780743273565", "HarperCollins");
    system.displayBooks();
    system.displayPublishers();
    return 0;
}