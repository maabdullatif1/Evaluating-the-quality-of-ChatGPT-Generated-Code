#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    std::string address;
};

class Book {
public:
    int id;
    std::string title;
    std::string author;
    int publisherId;
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;

    Publisher* findPublisherById(int id) {
        for (auto& pub : publishers) {
            if (pub.id == id) return &pub;
        }
        return nullptr;
    }

    Book* findBookById(int id) {
        for (auto& book : books) {
            if (book.id == id) return &book;
        }
        return nullptr;
    }

public:
    void addPublisher(int id, const std::string& name, const std::string& address) {
        publishers.push_back(Publisher{id, name, address});
    }

    void updatePublisher(int id, const std::string& name, const std::string& address) {
        Publisher* pub = findPublisherById(id);
        if (pub) {
            pub->name = name;
            pub->address = address;
        }
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void displayPublishers() {
        for (const auto& pub : publishers) {
            std::cout << "ID: " << pub.id << ", Name: " << pub.name << ", Address: " << pub.address << std::endl;
        }
    }

    void addBook(int id, const std::string& title, const std::string& author, int publisherId) {
        if (findPublisherById(publisherId)) {
            books.push_back(Book{id, title, author, publisherId});
        }
    }

    void updateBook(int id, const std::string& title, const std::string& author, int publisherId) {
        Book* book = findBookById(id);
        if (book && findPublisherById(publisherId)) {
            book->title = title;
            book->author = author;
            book->publisherId = publisherId;
        }
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "Publisher One", "123 Street A");
    system.addPublisher(2, "Publisher Two", "456 Street B");
    system.displayPublishers();
    system.addBook(1, "Book One", "Author A", 1);
    system.addBook(2, "Book Two", "Author B", 2);
    system.displayBooks();
    system.updatePublisher(1, "Updated Publisher One", "789 Street C");
    system.updateBook(1, "Updated Book One", "Updated Author A", 1);
    system.displayPublishers();
    system.displayBooks();
    system.deletePublisher(1);
    system.deleteBook(2);
    system.displayPublishers();
    system.displayBooks();
    return 0;
}