#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Publisher {
public:
    int id;
    string name;
    Publisher(int i, string n) : id(i), name(n) {}
};

class Book {
public:
    int id;
    string title;
    int publisherId;
    Book(int i, string t, int pId) : id(i), title(t), publisherId(pId) {}
};

class ManagementSystem {
    vector<Publisher> publishers;
    vector<Book> books;

    Publisher* findPublisherById(int id) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) return &publisher;
        }
        return nullptr;
    }

    Book* findBookById(int id) {
        for (auto &book : books) {
            if (book.id == id) return &book;
        }
        return nullptr;
    }

public:
    void addPublisher(int id, string name) {
        publishers.push_back(Publisher(id, name));
    }

    void removePublisher(int id) {
        for (size_t i = 0; i < publishers.size(); ++i) {
            if (publishers[i].id == id) {
                publishers.erase(publishers.begin() + i);
                break;
            }
        }
    }

    void updatePublisher(int id, string newName) {
        if (Publisher* publisher = findPublisherById(id)) {
            publisher->name = newName;
        }
    }

    void addBook(int id, string title, int publisherId) {
        if (findPublisherById(publisherId)) {
            books.push_back(Book(id, title, publisherId));
        }
    }

    void removeBook(int id) {
        for (size_t i = 0; i < books.size(); ++i) {
            if (books[i].id == id) {
                books.erase(books.begin() + i);
                break;
            }
        }
    }

    void updateBook(int id, string newTitle, int newPublisherId) {
        if (Book* book = findBookById(id)) {
            if (findPublisherById(newPublisherId)) {
                book->title = newTitle;
                book->publisherId = newPublisherId;
            }
        }
    }

    void searchPublisher(int id) {
        if (Publisher* publisher = findPublisherById(id)) {
            cout << "Publisher ID: " << publisher->id << ", Name: " << publisher->name << endl;
        } else {
            cout << "Publisher not found" << endl;
        }
    }

    void searchBook(int id) {
        if (Book* book = findBookById(id)) {
            cout << "Book ID: " << book->id << ", Title: " << book->title << ", Publisher ID: " << book->publisherId << endl;
        } else {
            cout << "Book not found" << endl;
        }
    }

    void displayPublishers() {
        for (const auto &publisher : publishers) {
            cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << endl;
        }
    }

    void displayBooks() {
        for (const auto &book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << endl;
        }
    }
};

int main() {
    ManagementSystem ms;
    ms.addPublisher(1, "Publisher One");
    ms.addPublisher(2, "Publisher Two");
    ms.addBook(1, "Book One", 1);
    ms.addBook(2, "Book Two", 2);

    cout << "All Publishers:" << endl;
    ms.displayPublishers();

    cout << "All Books:" << endl;
    ms.displayBooks();

    ms.searchPublisher(1);
    ms.searchBook(2);

    ms.updatePublisher(1, "Updated Publisher One");
    ms.updateBook(1, "Updated Book One", 2);

    cout << "Updated Publishers:" << endl;
    ms.displayPublishers();

    cout << "Updated Books:" << endl;
    ms.displayBooks();

    ms.removePublisher(1);
    ms.removeBook(1);

    cout << "After Deletion - Publishers:" << endl;
    ms.displayPublishers();

    cout << "After Deletion - Books:" << endl;
    ms.displayBooks();

    return 0;
}