#include <iostream>
#include <string>
#include <vector>

class Book {
public:
    Book(std::string t, std::string a, std::string p)
        : title(t), author(a), publisher(p) {}

    std::string title;
    std::string author;
    std::string publisher;
};

class Publisher {
public:
    Publisher(std::string n)
        : name(n) {}

    std::string name;
    std::vector<Book> books;
};

class PublisherManagementSystem {
public:
    void addPublisher(const std::string& name) {
        publishers.emplace_back(name);
    }

    void deletePublisher(const std::string& name) {
        publishers.erase(std::remove_if(publishers.begin(), publishers.end(), [&](Publisher& p) { return p.name == name; }), publishers.end());
    }

    void updatePublisher(const std::string& oldName, const std::string& newName) {
        for (auto& p : publishers) {
            if (p.name == oldName) {
                p.name = newName;
                break;
            }
        }
    }

    Publisher* searchPublisher(const std::string& name) {
        for (auto& p : publishers) {
            if (p.name == name) {
                return &p;
            }
        }
        return nullptr;
    }

    void addBook(const std::string& title, const std::string& author, const std::string& publisherName) {
        Publisher* publisher = searchPublisher(publisherName);
        if (publisher) {
            publisher->books.emplace_back(title, author, publisherName);
        }
    }

    void deleteBook(const std::string& title, const std::string& publisherName) {
        Publisher* publisher = searchPublisher(publisherName);
        if (publisher) {
            publisher->books.erase(std::remove_if(publisher->books.begin(), publisher->books.end(), [&](Book& b) { return b.title == title; }), publisher->books.end());
        }
    }

    void updateBook(const std::string& oldTitle, const std::string& newTitle, const std::string& newAuthor, const std::string& publisherName) {
        Publisher* publisher = searchPublisher(publisherName);
        if (publisher) {
            for (auto& b : publisher->books) {
                if (b.title == oldTitle) {
                    b.title = newTitle;
                    b.author = newAuthor;
                    break;
                }
            }
        }
    }

    Book* searchBook(const std::string& title, const std::string& publisherName) {
        Publisher* publisher = searchPublisher(publisherName);
        if (publisher) {
            for (auto& b : publisher->books) {
                if (b.title == title) {
                    return &b;
                }
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto& p : publishers) {
            std::cout << "Publisher Name: " << p.name << std::endl;
            for (const auto& b : p.books) {
                std::cout << "\tBook Title: " << b.title << ", Author: " << b.author << std::endl;
            }
        }
    }

private:
    std::vector<Publisher> publishers;
};

int main() {
    PublisherManagementSystem pms;
    pms.addPublisher("Penguin");
    pms.addBook("1984", "George Orwell", "Penguin");
    pms.addBook("Animal Farm", "George Orwell", "Penguin");
    pms.displayPublishers();
    pms.updateBook("1984", "Nineteen Eighty-Four", "George Orwell", "Penguin");
    pms.displayPublishers();
    pms.deleteBook("Animal Farm", "Penguin");
    pms.displayPublishers();
    pms.deletePublisher("Penguin");
    pms.displayPublishers();
    return 0;
}