#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Publisher {
public:
    string name;
    string address;

    Publisher(string n, string a) : name(n), address(a) {}
};

class Book {
public:
    string title;
    string author;
    Publisher* publisher;

    Book(string t, string a, Publisher* p) : title(t), author(a), publisher(p) {}
};

class ManagementSystem {
    vector<Publisher> publishers;
    vector<Book> books;

public:
    void addPublisher(string name, string address) {
        publishers.push_back(Publisher(name, address));
    }

    void addBook(string title, string author, string publisherName) {
        for (auto& pub : publishers) {
            if (pub.name == publisherName) {
                books.push_back(Book(title, author, &pub));
                return;
            }
        }
    }

    void deletePublisher(string name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->name == name) {
                publishers.erase(it);
                return;
            }
        }
    }

    void deleteBook(string title) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->title == title) {
                books.erase(it);
                return;
            }
        }
    }

    void updatePublisher(string oldName, string newName, string newAddress) {
        for (auto& pub : publishers) {
            if (pub.name == oldName) {
                pub.name = newName;
                pub.address = newAddress;
                return;
            }
        }
    }

    void updateBook(string oldTitle, string newTitle, string newAuthor, string newPublisherName) {
        for (auto& book : books) {
            if (book.title == oldTitle) {
                book.title = newTitle;
                book.author = newAuthor;
                for (auto& pub : publishers) {
                    if (pub.name == newPublisherName) {
                        book.publisher = &pub;
                        return;
                    }
                }
            }
        }
    }

    Book* searchBook(string title) {
        for (auto& book : books) {
            if (book.title == title) {
                return &book;
            }
        }
        return nullptr;
    }

    Publisher* searchPublisher(string name) {
        for (auto& pub : publishers) {
            if (pub.name == name) {
                return &pub;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (auto& book : books) {
            cout << "Title: " << book.title << ", Author: " << book.author 
                 << ", Publisher: " << book.publisher->name << endl;
        }
    }

    void displayPublishers() {
        for (auto& pub : publishers) {
            cout << "Name: " << pub.name << ", Address: " << pub.address << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("Penguin", "123 Penguin St");
    system.addPublisher("HarperCollins", "456 Harper Ave");
    system.addBook("1984", "George Orwell", "Penguin");
    system.addBook("To Kill a Mockingbird", "Harper Lee", "HarperCollins");
    system.displayBooks();
    system.displayPublishers();
    Book* foundBook = system.searchBook("1984");
    if (foundBook) {
        cout << "Found Book: " << foundBook->title << " by " << foundBook->author << endl;
    }
    Publisher* foundPublisher = system.searchPublisher("Penguin");
    if (foundPublisher) {
        cout << "Found Publisher: " << foundPublisher->name << endl;
    }
    system.updateBook("1984", "Nineteen Eighty-Four", "George Orwell", "Penguin");
    system.updatePublisher("HarperCollins", "Harper", "789 New Harper Ave");
    system.displayBooks();
    system.displayPublishers();
    system.deleteBook("To Kill a Mockingbird");
    system.deletePublisher("Penguin");
    system.displayBooks();
    system.displayPublishers();
    return 0;
}