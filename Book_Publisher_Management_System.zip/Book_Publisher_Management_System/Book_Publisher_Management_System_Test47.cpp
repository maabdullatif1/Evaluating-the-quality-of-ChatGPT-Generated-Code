#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Publisher {
public:
    int id;
    string name;

    Publisher(int i, string n) : id(i), name(n) {}
};

class Book {
public:
    int id;
    string title;
    int publisherId;

    Book(int i, string t, int pId) : id(i), title(t), publisherId(pId) {}
};

class ManagementSystem {
private:
    vector<Publisher> publishers;
    vector<Book> books;

    Publisher* findPublisherById(int id) {
        for (auto& pub : publishers) {
            if (pub.id == id)
                return &pub;
        }
        return nullptr;
    }

    Book* findBookById(int id) {
        for (auto& bk : books) {
            if (bk.id == id)
                return &bk;
        }
        return nullptr;
    }

public:
    void addPublisher(int id, string name) {
        if (findPublisherById(id) == nullptr)
            publishers.push_back(Publisher(id, name));
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                return;
            }
        }
    }

    void updatePublisher(int id, string newName) {
        Publisher* pub = findPublisherById(id);
        if (pub)
            pub->name = newName;
    }

    void searchPublisher(int id) {
        Publisher* pub = findPublisherById(id);
        if (pub)
            cout << "Publisher found: " << pub->name << endl;
        else
            cout << "Publisher not found" << endl;
    }

    void displayPublishers() {
        for (auto& pub : publishers) {
            cout << "Publisher ID: " << pub.id << ", Name: " << pub.name << endl;
        }
    }

    void addBook(int id, string title, int publisherId) {
        if (findBookById(id) == nullptr && findPublisherById(publisherId) != nullptr)
            books.push_back(Book(id, title, publisherId));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                return;
            }
        }
    }

    void updateBook(int id, string newTitle, int newPublisherId) {
        Book* bk = findBookById(id);
        if (bk && findPublisherById(newPublisherId) != nullptr) {
            bk->title = newTitle;
            bk->publisherId = newPublisherId;
        }
    }

    void searchBook(int id) {
        Book* bk = findBookById(id);
        if (bk) {
            cout << "Book found: " << bk->title << ", Publisher ID: " << bk->publisherId << endl;
        } else {
            cout << "Book not found" << endl;
        }
    }

    void displayBooks() {
        for (auto& bk : books) {
            cout << "Book ID: " << bk.id << ", Title: " << bk.title << ", Publisher ID: " << bk.publisherId << endl;
        }
    }
};

int main() {
    ManagementSystem ms;
    ms.addPublisher(1, "Publisher A");
    ms.addPublisher(2, "Publisher B");
    ms.addBook(1, "Book A", 1);
    ms.addBook(2, "Book B", 2);
    ms.displayPublishers();
    ms.displayBooks();
    ms.searchBook(1);
    ms.updateBook(1, "Updated Book A", 2);
    ms.displayBooks();
    ms.deleteBook(2);
    ms.displayBooks();
    ms.deletePublisher(1);
    ms.displayPublishers();
    return 0;
}