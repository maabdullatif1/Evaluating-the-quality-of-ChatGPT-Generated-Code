#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Book {
public:
    string title;
    string author;
    string publisher;
    int year;
    Book(string t, string a, string p, int y) : title(t), author(a), publisher(p), year(y) {}
};

class Publisher {
public:
    string name;
    string location;
    vector<Book> books;
    Publisher(string n, string l) : name(n), location(l) {}
};

class PublisherManagementSystem {
private:
    vector<Publisher> publishers;
public:
    void addPublisher(const string& name, const string& location) {
        publishers.push_back(Publisher(name, location));
    }

    void deletePublisher(const string& name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->name == name) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(const string& name, const string& newName, const string& location) {
        for (auto& publisher : publishers) {
            if (publisher.name == name) {
                publisher.name = newName;
                publisher.location = location;
                break;
            }
        }
    }

    Publisher* searchPublisher(const string& name) {
        for (auto& publisher : publishers) {
            if (publisher.name == name) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            cout << "Publisher: " << publisher.name << ", Location: " << publisher.location << endl;
        }
    }

    void addBook(const string& publisherName, const string& title, const string& author, const string& pubName, int year) {
        Publisher* publisher = searchPublisher(publisherName);
        if (publisher) {
            publisher->books.push_back(Book(title, author, pubName, year));
        }
    }

    void deleteBook(const string& publisherName, const string& title) {
        Publisher* publisher = searchPublisher(publisherName);
        if (publisher) {
            for (auto it = publisher->books.begin(); it != publisher->books.end(); ++it) {
                if (it->title == title) {
                    publisher->books.erase(it);
                    break;
                }
            }
        }
    }

    void updateBook(const string& publisherName, const string& title, const string& newTitle, const string& author, const string& pubName, int year) {
        Publisher* publisher = searchPublisher(publisherName);
        if (publisher) {
            for (auto& book : publisher->books) {
                if (book.title == title) {
                    book.title = newTitle;
                    book.author = author;
                    book.publisher = pubName;
                    book.year = year;
                    break;
                }
            }
        }
    }

    Book* searchBook(const string& publisherName, const string& title) {
        Publisher* publisher = searchPublisher(publisherName);
        if (publisher) {
            for (auto& book : publisher->books) {
                if (book.title == title) {
                    return &book;
                }
            }
        }
        return nullptr;
    }

    void displayBooks(const string& publisherName) {
        Publisher* publisher = searchPublisher(publisherName);
        if (publisher) {
            for (const auto& book : publisher->books) {
                cout << "Title: " << book.title << ", Author: " << book.author << ", Publisher: " << book.publisher << ", Year: " << book.year << endl;
            }
        }
    }
};

int main() {
    PublisherManagementSystem pms;
    pms.addPublisher("Penguin", "New York");
    pms.addBook("Penguin", "Book1", "Author1", "Penguin", 2021);
    pms.displayBooks("Penguin");
    pms.updateBook("Penguin", "Book1", "NewBook1", "NewAuthor1", "Penguin", 2023);
    pms.displayBooks("Penguin");
    pms.deleteBook("Penguin", "NewBook1");
    pms.displayBooks("Penguin");
    pms.deletePublisher("Penguin");
    pms.displayPublishers();
    return 0;
}