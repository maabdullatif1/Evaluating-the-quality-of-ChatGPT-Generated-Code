#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    int publisherId;

    Book(int id, const std::string &title, const std::string &author, int publisherId)
        : id(id), title(title), author(author), publisherId(publisherId) {}
};

class Publisher {
public:
    int id;
    std::string name;

    Publisher(int id, const std::string &name) : id(id), name(name) {}
};

class ManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Publisher> publishers;

public:
    void addBook(int id, const std::string &title, const std::string &author, int publisherId) {
        books.emplace_back(id, title, author, publisherId);
    }

    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(),
                                   [id](Book &book) { return book.id == id; }),
                    books.end());
    }

    void updateBook(int id, const std::string &newTitle, const std::string &newAuthor, int newPublisherId) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = newTitle;
                book.author = newAuthor;
                book.publisherId = newPublisherId;
                break;
            }
        }
    }

    Book *searchBook(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto &book : books) {
            std::cout << "Book ID: " << book.id
                      << ", Title: " << book.title
                      << ", Author: " << book.author
                      << ", Publisher ID: " << book.publisherId << std::endl;
        }
    }

    void addPublisher(int id, const std::string &name) {
        publishers.emplace_back(id, name);
    }

    void deletePublisher(int id) {
        publishers.erase(std::remove_if(publishers.begin(), publishers.end(),
                                        [id](Publisher &publisher) { return publisher.id == id; }),
                         publishers.end());
    }

    void updatePublisher(int id, const std::string &newName) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = newName;
                break;
            }
        }
    }

    Publisher *searchPublisher(int id) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto &publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id
                      << ", Name: " << publisher.name << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "Penguin Books");
    system.addBook(101, "1984", "George Orwell", 1);
    system.addBook(102, "To Kill a Mockingbird", "Harper Lee", 1);

    system.displayBooks();
    system.displayPublishers();

    Book *book = system.searchBook(101);
    if (book) {
        std::cout << "Found Book: " << book->title << std::endl;
    }

    system.updateBook(102, "To Kill a Mockingbird Updated", "Harper Lee", 1);
    system.displayBooks();

    system.deleteBook(101);
    system.displayBooks();

    return 0;
}