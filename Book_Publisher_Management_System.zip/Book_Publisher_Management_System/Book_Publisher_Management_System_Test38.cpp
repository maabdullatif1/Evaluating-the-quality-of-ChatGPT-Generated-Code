#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int id, const std::string& title, const std::string& author) 
        : id(id), title(title), author(author) {}
};

class Publisher {
public:
    int id;
    std::string name;
    std::vector<Book> books;

    Publisher(int id, const std::string& name)
        : id(id), name(name) {}
};

class ManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Publisher> publishers;

public:
    void addBook(int id, const std::string& title, const std::string& author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for(auto it = books.begin(); it != books.end(); ++it) {
            if(it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const std::string& title, const std::string& author) {
        for(auto& book : books) {
            if(book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for(auto& book : books) {
            if(book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for(const auto& book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }

    void addPublisher(int id, const std::string& name) {
        publishers.push_back(Publisher(id, name));
    }

    void deletePublisher(int id) {
        for(auto it = publishers.begin(); it != publishers.end(); ++it) {
            if(it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, const std::string& name) {
        for(auto& publisher : publishers) {
            if(publisher.id == id) {
                publisher.name = name;
                break;
            }
        }
    }

    Publisher* searchPublisher(int id) {
        for(auto& publisher : publishers) {
            if(publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for(const auto& publisher : publishers) {
            std::cout << "ID: " << publisher.id << ", Name: " << publisher.name << std::endl;
        }
    }

    void addBookToPublisher(int publisherId, int bookId) {
        Book* book = searchBook(bookId);
        Publisher* publisher = searchPublisher(publisherId);
        if(book && publisher) {
            publisher->books.push_back(*book);
        }
    }

    void displayPublisherBooks(int publisherId) {
        Publisher* publisher = searchPublisher(publisherId);
        if(publisher) {
            for(const auto& book : publisher->books) {
                std::cout << "Publisher ID: " << publisher->id << ", Book ID: " << book.id << ", Title: " << book.title << std::endl;
            }
        }
    }
};

int main() {
    ManagementSystem ms;
    ms.addBook(1, "The Catcher in the Rye", "J.D. Salinger");
    ms.addPublisher(1, "Penguin Books");
    ms.addBookToPublisher(1, 1);
    ms.displayBooks();
    ms.displayPublishers();
    ms.displayPublisherBooks(1);
    return 0;
}