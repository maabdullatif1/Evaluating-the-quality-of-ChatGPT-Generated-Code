#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Publisher {
    int id;
    string name;
};

struct Book {
    int id;
    string title;
    Publisher publisher;
};

class ManagementSystem {
    vector<Publisher> publishers;
    vector<Book> books;
    
public:
    void addPublisher(int id, const string &name) {
        publishers.push_back(Publisher{id, name});
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, const string &name) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = name;
                break;
            }
        }
    }

    Publisher searchPublisher(int id) {
        for (const auto &publisher : publishers) {
            if (publisher.id == id) {
                return publisher;
            }
        }
        return Publisher{-1, "Not Found"};
    }

    void displayPublishers() {
        for (const auto &publisher : publishers) {
            cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << endl;
        }
    }

    void addBook(int id, const string &title, const Publisher &publisher) {
        books.push_back(Book{id, title, publisher});
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const string &title, const Publisher &publisher) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                book.publisher = publisher;
                break;
            }
        }
    }

    Book searchBook(int id) {
        for (const auto &book : books) {
            if (book.id == id) {
                return book;
            }
        }
        return Book{-1, "Not Found", Publisher{-1, "Not Found"}};
    }

    void displayBooks() {
        for (const auto &book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title 
                 << ", Publisher: " << book.publisher.name << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "Publisher A");
    system.addPublisher(2, "Publisher B");
    Publisher p = system.searchPublisher(1);
    system.addBook(1, "Book A", p);
    p = system.searchPublisher(2);
    system.addBook(2, "Book B", p);

    cout << "Publishers:" << endl;
    system.displayPublishers();
    cout << "Books:" << endl;
    system.displayBooks();

    system.updatePublisher(1, "Updated Publisher A");
    system.updateBook(1, "Updated Book A", system.searchPublisher(1));
    
    cout << "Updated Publishers:" << endl;
    system.displayPublishers();
    cout << "Updated Books:" << endl;
    system.displayBooks();

    system.deleteBook(1);
    system.deletePublisher(2);
    
    cout << "Final Publishers:" << endl;
    system.displayPublishers();
    cout << "Final Books:" << endl;
    system.displayBooks();

    return 0;
}