#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    std::string address;
    std::string phone;
    Publisher(int id, std::string name, std::string address, std::string phone)
        : id(id), name(name), address(address), phone(phone) {}
};

class Book {
public:
    int id;
    std::string title;
    std::string author;
    int publisherId;
    Book(int id, std::string title, std::string author, int publisherId)
        : id(id), title(title), author(author), publisherId(publisherId) {}
};

class ManagementSystem {
    std::vector<Publisher> publishers;
    std::vector<Book> books;

    Publisher* findPublisher(int id) {
        for (auto& pub : publishers) 
            if (pub.id == id) return &pub;
        return nullptr;
    }

    Book* findBook(int id) {
        for (auto& book : books)
            if (book.id == id) return &book;
        return nullptr;
    }

public:
    void addPublisher(int id, const std::string& name, const std::string& address, const std::string& phone) {
        publishers.emplace_back(id, name, address, phone);
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, const std::string& name, const std::string& address, const std::string& phone) {
        Publisher* pub = findPublisher(id);
        if (pub) {
            pub->name = name;
            pub->address = address;
            pub->phone = phone;
        }
    }

    void addBook(int id, const std::string& title, const std::string& author, int publisherId) {
        books.emplace_back(id, title, author, publisherId);
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const std::string& title, const std::string& author, int publisherId) {
        Book* book = findBook(id);
        if (book) {
            book->title = title;
            book->author = author;
            book->publisherId = publisherId;
        }
    }

    void searchPublisher(int id) {
        Publisher* pub = findPublisher(id);
        if (pub) {
            std::cout << "Publisher found: " << pub->name << ", " << pub->address << ", " << pub->phone << "\n";
        } else {
            std::cout << "Publisher not found\n";
        }
    }

    void searchBook(int id) {
        Book* book = findBook(id);
        if (book) {
            std::cout << "Book found: " << book->title << ", " << book->author << "\n";
        } else {
            std::cout << "Book not found\n";
        }
    }

    void displayPublishers() {
        std::cout << "Publishers:\n";
        for (const auto& pub : publishers)
            std::cout << pub.id << ": " << pub.name << ", " << pub.address << ", " << pub.phone << "\n";
    }

    void displayBooks() {
        std::cout << "Books:\n";
        for (const auto& book : books)
            std::cout << book.id << ": " << book.title << ", " << book.author << ", Publisher ID: " << book.publisherId << "\n";
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "Publisher A", "Address A", "123456789");
    system.addPublisher(2, "Publisher B", "Address B", "987654321");

    system.addBook(1, "Book A", "Author A", 1);
    system.addBook(2, "Book B", "Author B", 2);

    system.displayPublishers();
    system.displayBooks();

    system.searchPublisher(1);
    system.searchBook(2);

    system.updatePublisher(1, "Publisher A Updated", "Address A Updated", "111111111");
    system.updateBook(1, "Book A Updated", "Author A Updated", 2);

    system.displayPublishers();
    system.displayBooks();

    system.deletePublisher(2);
    system.deleteBook(2);

    system.displayPublishers();
    system.displayBooks();

    return 0;
}