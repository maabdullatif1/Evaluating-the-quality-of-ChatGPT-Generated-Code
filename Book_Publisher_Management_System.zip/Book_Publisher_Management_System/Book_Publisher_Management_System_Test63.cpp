#include <iostream>
#include <vector>
#include <string>

class Publisher {
    std::string name;
    std::string address;
public:
    Publisher(const std::string& n, const std::string& a) : name(n), address(a) {}
    const std::string& getName() const { return name; }
    const std::string& getAddress() const { return address; }
    void setName(const std::string& n) { name = n; }
    void setAddress(const std::string& a) { address = a; }
    void display() const {
        std::cout << "Publisher Name: " << name << ", Address: " << address << std::endl;
    }
};

class Book {
    std::string title;
    std::string author;
    Publisher* publisher;
public:
    Book(const std::string& t, const std::string& a, Publisher* p) : title(t), author(a), publisher(p) {}
    const std::string& getTitle() const { return title; }
    const std::string& getAuthor() const { return author; }
    Publisher* getPublisher() const { return publisher; }
    void setTitle(const std::string& t) { title = t; }
    void setAuthor(const std::string& a) { author = a; }
    void setPublisher(Publisher* p) { publisher = p; }
    void display() const {
        std::cout << "Book Title: " << title << ", Author: " << author;
        if (publisher) {
            std::cout << ", Publisher: " << publisher->getName();
        }
        std::cout << std::endl;
    }
};

class System {
    std::vector<Publisher> publishers;
    std::vector<Book> books;
public:
    void addPublisher(const std::string& name, const std::string& address) {
        publishers.emplace_back(name, address);
    }
    void deletePublisher(const std::string& name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->getName() == name) {
                publishers.erase(it);
                break;
            }
        }
    }
    void updatePublisher(const std::string& name, const std::string& newName, const std::string& newAddress) {
        for (auto& p : publishers) {
            if (p.getName() == name) {
                p.setName(newName);
                p.setAddress(newAddress);
                break;
            }
        }
    }
    Publisher* searchPublisher(const std::string& name) {
        for (auto& p : publishers) {
            if (p.getName() == name) {
                return &p;
            }
        }
        return nullptr;
    }
    void displayPublishers() const {
        for (const auto& p : publishers) {
            p.display();
        }
    }
    void addBook(const std::string& title, const std::string& author, const std::string& publisherName) {
        Publisher* publisher = searchPublisher(publisherName);
        if (publisher) {
            books.emplace_back(title, author, publisher);
        }
    }
    void deleteBook(const std::string& title) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->getTitle() == title) {
                books.erase(it);
                break;
            }
        }
    }
    void updateBook(const std::string& title, const std::string& newTitle, const std::string& newAuthor, const std::string& publisherName) {
        for (auto& b : books) {
            if (b.getTitle() == title) {
                b.setTitle(newTitle);
                b.setAuthor(newAuthor);
                b.setPublisher(searchPublisher(publisherName));
                break;
            }
        }
    }
    Book* searchBook(const std::string& title) {
        for (auto& b : books) {
            if (b.getTitle() == title) {
                return &b;
            }
        }
        return nullptr;
    }
    void displayBooks() const {
        for (const auto& b : books) {
            b.display();
        }
    }
};

int main() {
    System sys;

    sys.addPublisher("Penguin Random House", "New York");
    sys.addPublisher("HarperCollins", "New York");
    
    sys.addBook("The Great Gatsby", "F. Scott Fitzgerald", "Scribner");
    sys.addBook("1984", "George Orwell", "Penguin Random House");
    
    sys.displayPublishers();
    sys.displayBooks();
    
    return 0;
}