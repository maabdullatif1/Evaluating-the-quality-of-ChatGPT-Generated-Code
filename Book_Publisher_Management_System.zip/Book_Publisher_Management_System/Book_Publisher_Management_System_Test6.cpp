#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;

    Publisher(int id, const std::string &name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;
    int publisherId;

    Book(int id, const std::string &title, int publisherId) : id(id), title(title), publisherId(publisherId) {}
};

class ManagementSystem {
    std::vector<Publisher> publishers;
    std::vector<Book> books;
    int bookIdCounter = 1;
    int publisherIdCounter = 1;

public:
    void addPublisher(const std::string &name) {
        publishers.push_back(Publisher(publisherIdCounter++, name));
    }

    void addBook(const std::string &title, int publisherId) {
        books.push_back(Book(bookIdCounter++, title, publisherId));
    }

    void deletePublisher(int publisherId) {
        publishers.erase(std::remove_if(publishers.begin(), publishers.end(), [publisherId](Publisher &p) {
            return p.id == publisherId;
        }), publishers.end());

        books.erase(std::remove_if(books.begin(), books.end(), [publisherId](Book &b) {
            return b.publisherId == publisherId;
        }), books.end());
    }

    void deleteBook(int bookId) {
        books.erase(std::remove_if(books.begin(), books.end(), [bookId](Book &b) {
            return b.id == bookId;
        }), books.end());
    }

    void updatePublisher(int publisherId, const std::string &newName) {
        for (auto &publisher : publishers) {
            if (publisher.id == publisherId) {
                publisher.name = newName;
            }
        }
    }

    void updateBook(int bookId, const std::string &newTitle, int newPublisherId) {
        for (auto &book : books) {
            if (book.id == bookId) {
                book.title = newTitle;
                book.publisherId = newPublisherId;
            }
        }
    }

    Publisher* searchPublisher(const std::string &name) {
        for (auto &publisher : publishers) {
            if (publisher.name == name) {
                return &publisher;
            }
        }
        return nullptr;
    }

    Book* searchBook(const std::string &title) {
        for (auto &book : books) {
            if (book.title == title) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto &publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << std::endl;
        }
    }

    void displayBooks() {
        for (const auto &book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("Penguin");
    system.addPublisher("HarperCollins");
    system.addBook("The Great Gatsby", 1);
    system.addBook("1984", 2);
    system.displayPublishers();
    system.displayBooks();
    return 0;
}