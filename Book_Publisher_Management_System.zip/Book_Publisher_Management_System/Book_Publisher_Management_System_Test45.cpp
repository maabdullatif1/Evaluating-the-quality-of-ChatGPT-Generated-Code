#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    std::string address;

    Publisher(int id, const std::string& name, const std::string& address)
        : id(id), name(name), address(address) {}
};

class Book {
public:
    int id;
    std::string title;
    std::string author;
    Publisher* publisher;
    
    Book(int id, const std::string& title, const std::string& author, Publisher* publisher)
        : id(id), title(title), author(author), publisher(publisher) {}
};

class ManagementSystem {
    std::vector<Publisher> publishers;
    std::vector<Book> books;

public:
    void addPublisher(int id, const std::string& name, const std::string& address) {
        publishers.emplace_back(id, name, address);
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, const std::string& name, const std::string& address) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = name;
                publisher.address = address;
                break;
            }
        }
    }

    Publisher* searchPublisher(int id) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id 
                      << ", Name: " << publisher.name 
                      << ", Address: " << publisher.address << std::endl;
        }
    }

    void addBook(int id, const std::string& title, const std::string& author, int publisherId) {
        Publisher* publisher = searchPublisher(publisherId);
        if (publisher) {
            books.emplace_back(id, title, author, publisher);
        }
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const std::string& title, const std::string& author, int publisherId) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                book.publisher = searchPublisher(publisherId);
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id 
                      << ", Title: " << book.title 
                      << ", Author: " << book.author 
                      << ", Publisher: " << (book.publisher ? book.publisher->name : "Unknown") << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    
    system.addPublisher(1, "HarperCollins", "New York");
    system.addPublisher(2, "Penguin Books", "London");
    
    system.addBook(1, "1984", "George Orwell", 2);
    system.addBook(2, "Brave New World", "Aldous Huxley", 2);
    
    system.displayPublishers();
    system.displayBooks();
    
    system.updateBook(2, "Brave New World", "Aldous Huxley", 1);
    
    system.displayBooks();
    
    system.deleteBook(1);
    system.deletePublisher(2);
    
    system.displayPublishers();
    system.displayBooks();

    return 0;
}