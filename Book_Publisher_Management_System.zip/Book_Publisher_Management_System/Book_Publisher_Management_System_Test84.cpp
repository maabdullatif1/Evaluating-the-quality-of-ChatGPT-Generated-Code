#include <iostream>
#include <vector>
#include <string>

class Book {
    int bookID;
    std::string title;
    std::string author;

public:
    Book(int id, const std::string& t, const std::string& a) : bookID(id), title(t), author(a) {}

    int getBookID() { return bookID; }
    std::string getTitle() { return title; }
    std::string getAuthor() { return author; }

    void updateTitle(const std::string& t) { title = t; }
    void updateAuthor(const std::string& a) { author = a; }

    void display() {
        std::cout << "Book ID: " << bookID << ", Title: " << title << ", Author: " << author << std::endl;
    }
};

class Publisher {
    int pubID;
    std::string name;
    std::vector<Book> books;

public:
    Publisher(int id, const std::string& n) : pubID(id), name(n) {}

    int getPubID() { return pubID; }
    std::string getName() { return name; }

    void updateName(const std::string& n) { name = n; }

    void addBook(int bookID, const std::string& title, const std::string& author) {
        books.emplace_back(bookID, title, author);
    }

    void deleteBook(int bookID) {
        for(auto it = books.begin(); it != books.end(); ++it) {
            if(it->getBookID() == bookID) {
                books.erase(it);
                return;
            }
        }
    }

    Book* searchBook(int bookID) {
        for(auto& book : books) {
            if(book.getBookID() == bookID) return &book;
        }
        return nullptr;
    }

    void displayBooks() {
        std::cout << "Publisher ID: " << pubID << ", Name: " << name << std::endl;
        for (const auto& book : books) {
            book.display();
        }
    }
};

class ManagementSystem {
    std::vector<Publisher> publishers;

public:
    void addPublisher(int pubID, const std::string& name) {
        publishers.emplace_back(pubID, name);
    }

    void deletePublisher(int pubID) {
        for(auto it = publishers.begin(); it != publishers.end(); ++it) {
            if(it->getPubID() == pubID) {
                publishers.erase(it);
                return;
            }
        }
    }

    Publisher* searchPublisher(int pubID) {
        for(auto& publisher : publishers) {
            if(publisher.getPubID() == pubID) return &publisher;
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            publisher.displayBooks();
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "HarperCollins");
    system.addPublisher(2, "Penguin Random House");

    Publisher* p = system.searchPublisher(1);
    if (p) {
        p->addBook(101, "To Kill a Mockingbird", "Harper Lee");
        p->addBook(102, "1984", "George Orwell");
    }

    p = system.searchPublisher(2);
    if (p) {
        p->addBook(201, "Moby Dick", "Herman Melville");
    }

    system.displayPublishers();

    p = system.searchPublisher(1);
    if (p) {
        p->deleteBook(102);
    }

    system.displayPublishers();

    return 0;
}