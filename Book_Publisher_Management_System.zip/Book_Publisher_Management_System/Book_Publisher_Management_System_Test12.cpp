#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    std::string title;
    std::string author;
    std::string isbn;

    Book(const std::string& t, const std::string& a, const std::string& i)
        : title(t), author(a), isbn(i) {}
};

class Publisher {
public:
    std::string name;
    std::string address;
    std::vector<Book> books;

    Publisher(const std::string& n, const std::string& a)
        : name(n), address(a) {}

    void addBook(const Book& book) {
        books.push_back(book);
    }

    bool removeBook(const std::string& isbn) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->isbn == isbn) {
                books.erase(it);
                return true;
            }
        }
        return false;
    }

    void updateBook(const std::string& isbn, const std::string& newTitle, const std::string& newAuthor) {
        for (auto& book : books) {
            if (book.isbn == isbn) {
                book.title = newTitle;
                book.author = newAuthor;
                return;
            }
        }
    }

    Book* searchBook(const std::string& isbn) {
        for (auto& book : books) {
            if (book.isbn == isbn) {
                return &book;
            }
        }
        return nullptr;
    }
};

class ManagementSystem {
public:
    std::vector<Publisher> publishers;

    void addPublisher(const Publisher& publisher) {
        publishers.push_back(publisher);
    }

    bool removePublisher(const std::string& name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->name == name) {
                publishers.erase(it);
                return true;
            }
        }
        return false;
    }

    void updatePublisher(const std::string& name, const std::string& newName, const std::string& newAddress) {
        for (auto& publisher : publishers) {
            if (publisher.name == name) {
                publisher.name = newName;
                publisher.address = newAddress;
                return;
            }
        }
    }

    Publisher* searchPublisher(const std::string& name) {
        for (auto& publisher : publishers) {
            if (publisher.name == name) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void display() const {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher: " << publisher.name << ", Address: " << publisher.address << "\n";
            for (const auto& book : publisher.books) {
                std::cout << "  - Book: " << book.title << ", Author: " << book.author << ", ISBN: " << book.isbn << "\n";
            }
        }
    }
};

int main() {
    ManagementSystem system;
    Publisher publisher1("Publisher1", "123 Main St");
    Publisher publisher2("Publisher2", "456 Elm St");

    publisher1.addBook(Book("Book1", "Author1", "123456789"));
    publisher1.addBook(Book("Book2", "Author2", "987654321"));

    system.addPublisher(publisher1);
    system.addPublisher(publisher2);

    system.display();

    system.updatePublisher("Publisher1", "UpdatedPublisher1", "789 Park Ave");
    if (Publisher* pub = system.searchPublisher("UpdatedPublisher1")) {
        pub->updateBook("123456789", "UpdatedBook1", "UpdatedAuthor1");
        pub->removeBook("987654321");
    }

    system.display();

    return 0;
}