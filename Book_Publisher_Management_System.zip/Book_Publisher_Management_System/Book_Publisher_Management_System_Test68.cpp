#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;

    Publisher(int pid, const std::string &pname) : id(pid), name(pname) {}
};

class Book {
public:
    int id;
    std::string title;
    int publisherId;

    Book(int bid, const std::string &btitle, int pubId) : id(bid), title(btitle), publisherId(pubId) {}
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;

public:
    void addPublisher(int id, const std::string &name) {
        publishers.emplace_back(id, name);
    }

    void addBook(int id, const std::string &title, int pubId) {
        books.emplace_back(id, title, pubId);
    }

    void deletePublisher(int id) {
        publishers.erase(std::remove_if(publishers.begin(), publishers.end(),
                       [id](Publisher &p) { return p.id == id; }), publishers.end());
    }

    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(),
                   [id](Book &b) { return b.id == id; }), books.end());
    }

    void updatePublisher(int id, const std::string &newName) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = newName;
                return;
            }
        }
    }

    void updateBook(int id, const std::string &newTitle, int newPubId) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = newTitle;
                book.publisherId = newPubId;
                return;
            }
        }
    }

    Publisher* searchPublisher(int id) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) return &publisher;
        }
        return nullptr;
    }

    Book* searchBook(int id) {
        for (auto &book : books) {
            if (book.id == id) return &book;
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto &publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << '\n';
        }
    }

    void displayBooks() {
        for (const auto &book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << '\n';
        }
    }
};

int main() {
    ManagementSystem system;
    
    system.addPublisher(1, "Publisher A");
    system.addPublisher(2, "Publisher B");
    system.addBook(1, "Book 1", 1);
    system.addBook(2, "Book 2", 2);
    
    system.displayPublishers();
    system.displayBooks();
    
    system.updatePublisher(1, "Updated Publisher A");
    system.updateBook(1, "Updated Book 1", 2);
    
    system.displayPublishers();
    system.displayBooks();

    system.deletePublisher(2);
    system.deleteBook(2);
    
    system.displayPublishers();
    system.displayBooks();

    return 0;
}