#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Publisher {
public:
    int id;
    string name;
    string address;
    Publisher(int id, string name, string address)
        : id(id), name(name), address(address) {}
};

class Book {
public:
    int id;
    string title;
    string author;
    int publisherId;
    Book(int id, string title, string author, int publisherId)
        : id(id), title(title), author(author), publisherId(publisherId) {}
};

class System {
    vector<Publisher> publishers;
    vector<Book> books;
public:
    void addPublisher(int id, string name, string address) {
        publishers.push_back(Publisher(id, name, address));
    }

    void addBook(int id, string title, string author, int publisherId) {
        books.push_back(Book(id, title, author, publisherId));
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, string name, string address) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = name;
                publisher.address = address;
                break;
            }
        }
    }

    void updateBook(int id, string title, string author, int publisherId) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                book.publisherId = publisherId;
                break;
            }
        }
    }

    void searchPublisher(int id) {
        for (const auto &publisher : publishers) {
            if (publisher.id == id) {
                cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << ", Address: " << publisher.address << endl;
                return;
            }
        }
        cout << "Publisher not found." << endl;
    }

    void searchBook(int id) {
        for (const auto &book : books) {
            if (book.id == id) {
                cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << endl;
                return;
            }
        }
        cout << "Book not found." << endl;
    }

    void displayPublishers() {
        for (const auto &publisher : publishers) {
            cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << ", Address: " << publisher.address << endl;
        }
    }

    void displayBooks() {
        for (const auto &book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << endl;
        }
    }
};

int main() {
    System system;

    system.addPublisher(1, "Publisher One", "123 Main St");
    system.addPublisher(2, "Publisher Two", "456 Second St");

    system.addBook(1, "Book One", "Author A", 1);
    system.addBook(2, "Book Two", "Author B", 2);

    system.displayPublishers();
    system.displayBooks();

    system.searchPublisher(1);
    system.searchBook(2);

    system.updatePublisher(1, "Updated Publisher One", "789 Updated St");
    system.updateBook(2, "Updated Book Two", "Author B Updated", 1);

    system.displayPublishers();
    system.displayBooks();

    system.deletePublisher(2);
    system.deleteBook(1);

    system.displayPublishers();
    system.displayBooks();

    return 0;
}