#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    std::string name;
    std::string address;
    
    Publisher(std::string n, std::string a) : name(n), address(a) {}
};

class Book {
public:
    std::string title;
    std::string author;
    Publisher* publisher;
    
    Book(std::string t, std::string a, Publisher* p) : title(t), author(a), publisher(p) {}
};

class ManagementSystem {
private:
    std::vector<Publisher*> publishers;
    std::vector<Book*> books;
    
public:
    void addPublisher(std::string name, std::string address) {
        publishers.push_back(new Publisher(name, address));
    }
    
    void deletePublisher(std::string name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if ((*it)->name == name) {
                delete *it;
                publishers.erase(it);
                break;
            }
        }
    }
    
    Publisher* searchPublisher(std::string name) {
        for (auto p : publishers) if (p->name == name) return p;
        return nullptr;
    }
    
    void updatePublisher(std::string oldName, std::string newName, std::string newAddress) {
        Publisher* p = searchPublisher(oldName);
        if (p) {
            p->name = newName;
            p->address = newAddress;
        }
    }
    
    void addBook(std::string title, std::string author, std::string publisherName) {
        Publisher* p = searchPublisher(publisherName);
        if (p)
            books.push_back(new Book(title, author, p));
    }
    
    void deleteBook(std::string title) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if ((*it)->title == title) {
                delete *it;
                books.erase(it);
                break;
            }
        }
    }
    
    Book* searchBook(std::string title) {
        for (auto b : books) if (b->title == title) return b;
        return nullptr;
    }
    
    void updateBook(std::string oldTitle, std::string newTitle, std::string newAuthor) {
        Book* b = searchBook(oldTitle);
        if (b) {
            b->title = newTitle;
            b->author = newAuthor;
        }
    }
    
    void displayPublishers() {
        for (auto p : publishers) {
            std::cout << "Publisher Name: " << p->name << ", Address: " << p->address << std::endl;
        }
    }
    
    void displayBooks() {
        for (auto b : books) {
            std::cout << "Book Title: " << b->title << ", Author: " << b->author 
                      << ", Publisher: " << b->publisher->name << std::endl;
        }
    }
    
    ~ManagementSystem() {
        for (auto b : books) delete b;
        for (auto p : publishers) delete p;
    }
};

int main() {
    ManagementSystem sys;
    
    sys.addPublisher("Penguin", "123 Penguin St.");
    sys.addPublisher("HarperCollins", "456 Harper Rd.");
    
    sys.addBook("1984", "George Orwell", "Penguin");
    sys.addBook("Brave New World", "Aldous Huxley", "HarperCollins");
    
    sys.displayPublishers();
    sys.displayBooks();
    
    sys.updatePublisher("Penguin", "Penguin Books", "123 New Penguin St.");
    sys.updateBook("1984", "Nineteen Eighty-Four", "George Orwell");
    
    sys.displayPublishers();
    sys.displayBooks();
    
    sys.deleteBook("Brave New World");
    sys.deletePublisher("HarperCollins");
    
    sys.displayPublishers();
    sys.displayBooks();
    
    return 0;
}