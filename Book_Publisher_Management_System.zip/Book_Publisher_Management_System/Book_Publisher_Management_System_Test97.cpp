#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Book {
    int bookId;
    string title;
    int publisherId;
};

struct Publisher {
    int publisherId;
    string name;
};

class ManagementSystem {
private:
    vector<Book> books;
    vector<Publisher> publishers;

    Book* findBookById(int id) {
        for (auto& book : books) {
            if (book.bookId == id) {
                return &book;
            }
        }
        return nullptr;
    }

    Publisher* findPublisherById(int id) {
        for (auto& publisher : publishers) {
            if (publisher.publisherId == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

public:
    void addBook(int id, string title, int publisherId) {
        Book book = {id, title, publisherId};
        books.push_back(book);
    }

    void deleteBook(int id) {
        books.erase(remove_if(books.begin(), books.end(), [&](Book& book) {
            return book.bookId == id;
        }), books.end());
    }

    void updateBook(int id, string newTitle, int newPublisherId) {
        Book* book = findBookById(id);
        if (book) {
            book->title = newTitle;
            book->publisherId = newPublisherId;
        }
    }

    Book* searchBook(int id) {
        return findBookById(id);
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "Book ID: " << book.bookId << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << endl;
        }
    }

    void addPublisher(int id, string name) {
        Publisher publisher = {id, name};
        publishers.push_back(publisher);
    }

    void deletePublisher(int id) {
        publishers.erase(remove_if(publishers.begin(), publishers.end(), [&](Publisher& publisher) {
            return publisher.publisherId == id;
        }), publishers.end());
    }

    void updatePublisher(int id, string newName) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            publisher->name = newName;
        }
    }

    Publisher* searchPublisher(int id) {
        return findPublisherById(id);
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            cout << "Publisher ID: " << publisher.publisherId << ", Name: " << publisher.name << endl;
        }
    }
};

int main() {
    ManagementSystem system;

    system.addPublisher(1, "Publisher A");
    system.addPublisher(2, "Publisher B");
    system.addBook(100, "Book A", 1);
    system.addBook(101, "Book B", 2);

    cout << "Books:" << endl;
    system.displayBooks();
    cout << "Publishers:" << endl;
    system.displayPublishers();

    system.updateBook(100, "Book A Updated", 2);
    system.updatePublisher(1, "Publisher A Updated");

    cout << "Updated Books:" << endl;
    system.displayBooks();
    cout << "Updated Publishers:" << endl;
    system.displayPublishers();

    system.deleteBook(101);
    system.deletePublisher(2);

    cout << "After Deletion Books:" << endl;
    system.displayBooks();
    cout << "After Deletion Publishers:" << endl;
    system.displayPublishers();

    return 0;
}