#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Publisher {
    int id;
    string name;
};

struct Book {
    int id;
    string title;
    int publisherId;
};

class ManagementSystem {
    vector<Publisher> publishers;
    vector<Book> books;
    int bookIdCounter = 1;
    int publisherIdCounter = 1;

public:
    void addPublisher(const string& name) {
        publishers.push_back({publisherIdCounter++, name});
    }

    void deletePublisher(int id) {
        publishers.erase(remove_if(publishers.begin(), publishers.end(), [id](Publisher& p) { return p.id == id; }), publishers.end());
        books.erase(remove_if(books.begin(), books.end(), [id](Book& b) { return b.publisherId == id; }), books.end());
    }

    void updatePublisher(int id, const string& newName) {
        for (auto& p : publishers) {
            if (p.id == id) {
                p.name = newName;
                return;
            }
        }
    }

    void addBook(const string& title, int publisherId) {
        for (const auto& p : publishers) {
            if (p.id == publisherId) {
                books.push_back({bookIdCounter++, title, publisherId});
                return;
            }
        }
    }

    void deleteBook(int id) {
        books.erase(remove_if(books.begin(), books.end(), [id](Book& b) { return b.id == id; }), books.end());
    }

    void updateBook(int id, const string& newTitle, int newPublisherId) {
        for (auto& b : books) {
            if (b.id == id) {
                for (const auto& p : publishers) {
                    if (p.id == newPublisherId) {
                        b.title = newTitle;
                        b.publisherId = newPublisherId;
                        return;
                    }
                }
            }
        }
    }

    Book* searchBook(int id) {
        for (auto& b : books) {
            if (b.id == id) {
                return &b;
            }
        }
        return nullptr;
    }

    Publisher* searchPublisher(int id) {
        for (auto& p : publishers) {
            if (p.id == id) {
                return &p;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& b : books) {
            cout << "Book ID: " << b.id << ", Title: " << b.title << ", Publisher ID: " << b.publisherId << endl;
        }
    }

    void displayPublishers() {
        for (const auto& p : publishers) {
            cout << "Publisher ID: " << p.id << ", Name: " << p.name << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("HarperCollins");
    system.addPublisher("Penguin Books");
    system.addBook("1984", 1);
    system.addBook("Animal Farm", 1);
    system.displayPublishers();
    system.displayBooks();
    system.updateBook(1, "Nineteen Eighty-Four", 2);
    system.deletePublisher(1);
    system.displayPublishers();
    system.displayBooks();
    return 0;
}