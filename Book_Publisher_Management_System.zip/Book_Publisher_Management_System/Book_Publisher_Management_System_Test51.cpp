#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Publisher {
public:
    int id;
    string name;
    string address;
    Publisher(int i, string n, string a) : id(i), name(n), address(a) {}
};

class Book {
public:
    int id;
    string title;
    string author;
    Publisher* publisher;
    Book(int i, string t, string a, Publisher* p) : id(i), title(t), author(a), publisher(p) {}
};

class ManagementSystem {
    vector<Publisher> publishers;
    vector<Book> books;
    
public:
    void addPublisher(int id, string name, string address) {
        publishers.push_back(Publisher(id, name, address));
    }
    
    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }
    
    void updatePublisher(int id, string name, string address) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = name;
                publisher.address = address;
                break;
            }
        }
    }
    
    Publisher* searchPublisher(int id) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }
    
    void displayPublishers() {
        for (const auto& publisher : publishers) {
            cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << ", Address: " << publisher.address << endl;
        }
    }
    
    void addBook(int id, string title, string author, int publisherId) {
        Publisher* publisher = searchPublisher(publisherId);
        if (publisher == nullptr) {
            cout << "Publisher not found!" << endl;
            return;
        }
        books.push_back(Book(id, title, author, publisher));
    }
    
    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }
    
    void updateBook(int id, string title, string author, int publisherId) {
        Publisher* publisher = searchPublisher(publisherId);
        if (publisher == nullptr) {
            cout << "Publisher not found!" << endl;
            return;
        }
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                book.publisher = publisher;
                break;
            }
        }
    }
    
    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }
    
    void displayBooks() {
        for (const auto& book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author
                 << ", Publisher: " << book.publisher->name << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "O'Reilly Media", "CA");
    system.addPublisher(2, "Penguin Random House", "NY");
    system.displayPublishers();
    
    system.addBook(1, "The C++ Programming Language", "Bjarne Stroustrup", 1);
    system.addBook(2, "Effective C++", "Scott Meyers", 1);
    system.displayBooks();
    
    system.updateBook(2, "Effective Modern C++", "Scott Meyers", 1);
    system.displayBooks();
    
    system.deleteBook(1);
    system.displayBooks();
    
    Publisher* publisher = system.searchPublisher(2);
    if (publisher) {
        cout << "Found Publisher: " << publisher->name << endl;
    }
    
    Book* book = system.searchBook(2);
    if (book) {
        cout << "Found Book: " << book->title << endl;
    }
    
    return 0;
}