#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    Publisher(int pid, std::string pname) : id(pid), name(pname) {}
};

class Book {
public:
    int id;
    std::string title;
    int publisherId;
    Book(int bid, std::string btitle, int pid) : id(bid), title(btitle), publisherId(pid) {}
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;

    Publisher* findPublisher(int id) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    Book* findBook(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

public:
    void addPublisher(int id, std::string name) {
        if (findPublisher(id)) return;
        publishers.push_back(Publisher(id, name));
    }

    void deletePublisher(int id) {
        for (size_t i = 0; i < publishers.size(); ++i) {
            if (publishers[i].id == id) {
                publishers.erase(publishers.begin() + i);
                break;
            }
        }
    }

    void updatePublisher(int id, std::string name) {
        Publisher *publisher = findPublisher(id);
        if (publisher) {
            publisher->name = name;
        }
    }

    Publisher* searchPublisher(int id) {
        return findPublisher(id);
    }

    void addBook(int id, std::string title, int pid) {
        if (findBook(id) || !findPublisher(pid)) return;
        books.push_back(Book(id, title, pid));
    }

    void deleteBook(int id) {
        for (size_t i = 0; i < books.size(); ++i) {
            if (books[i].id == id) {
                books.erase(books.begin() + i);
                break;
            }
        }
    }

    void updateBook(int id, std::string title, int pid) {
        Book *book = findBook(id);
        if (book && findPublisher(pid)) {
            book->title = title;
            book->publisherId = pid;
        }
    }

    Book* searchBook(int id) {
        return findBook(id);
    }

    void displayPublishers() {
        for (const auto &publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id << " Name: " << publisher.name << std::endl;
        }
    }

    void displayBooks() {
        for (const auto &book : books) {
            std::cout << "Book ID: " << book.id << " Title: " << book.title << " Publisher ID: " << book.publisherId << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "O'Reilly Media");
    system.addPublisher(2, "Penguin Books");
    system.addBook(101, "C++ Primer", 1);
    system.addBook(102, "Effective C++", 1);
    system.displayPublishers();
    system.displayBooks();
    system.updatePublisher(1, "O'Reilly");
    system.updateBook(101, "C++ Primer 5th Edition", 1);
    system.displayPublishers();
    system.displayBooks();
    system.deleteBook(102);
    system.deletePublisher(2);
    system.displayPublishers();
    system.displayBooks();
    return 0;
}