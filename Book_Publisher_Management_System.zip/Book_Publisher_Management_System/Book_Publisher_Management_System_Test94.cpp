#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Book {
public:
    string title;
    string author;
    string publisherID;
    int year;

    Book(string t, string a, string pID, int y) : title(t), author(a), publisherID(pID), year(y) {}
};

class Publisher {
public:
    string name;
    string id;

    Publisher(string n, string i) : name(n), id(i) {}
};

class ManagementSystem {
    vector<Book> books;
    vector<Publisher> publishers;

public:
    void addBook(string title, string author, string publisherID, int year) {
        books.push_back(Book(title, author, publisherID, year));
    }

    void deleteBook(string title) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->title == title) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(string title, string newAuthor, string newPublisherID, int newYear) {
        for (auto &book : books) {
            if (book.title == title) {
                book.author = newAuthor;
                book.publisherID = newPublisherID;
                book.year = newYear;
                break;
            }
        }
    }

    Book* searchBook(string title) {
        for (auto &book : books) {
            if (book.title == title) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (auto &book : books) {
            cout << "Title: " << book.title << ", Author: " << book.author
                 << ", Publisher ID: " << book.publisherID << ", Year: " << book.year << endl;
        }
    }

    void addPublisher(string name, string id) {
        publishers.push_back(Publisher(name, id));
    }

    void deletePublisher(string id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(string id, string newName) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = newName;
                break;
            }
        }
    }

    Publisher* searchPublisher(string id) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for (auto &publisher : publishers) {
            cout << "Publisher Name: " << publisher.name << ", ID: " << publisher.id << endl;
        }
    }
};

int main() {
    ManagementSystem system;

    system.addPublisher("Publisher A", "001");
    system.addPublisher("Publisher B", "002");
    
    system.addBook("C++ Programming", "Author A", "001", 2020);
    system.addBook("Data Structures", "Author B", "002", 2021);

    system.displayBooks();
    system.displayPublishers();

    Book* foundBook = system.searchBook("C++ Programming");
    if (foundBook) {
        cout << "Found Book: " << foundBook->title << endl;
    }

    Publisher* foundPublisher = system.searchPublisher("001");
    if (foundPublisher) {
        cout << "Found Publisher: " << foundPublisher->name << endl;
    }

    return 0;
}