#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    std::string title;
    std::string author;
    std::string isbn;
    std::string publisher;
    
    Book(std::string t, std::string a, std::string i, std::string p)
        : title(t), author(a), isbn(i), publisher(p) {}
};

class Publisher {
public:
    std::string name;
    std::string address;
    
    Publisher(std::string n, std::string a) : name(n), address(a) {}
};

class ManagementSystem {
    std::vector<Book> books;
    std::vector<Publisher> publishers;
    
    Book* findBookByISBN(const std::string& isbn) {
        for (auto& book : books) {
            if (book.isbn == isbn) {
                return &book;
            }
        }
        return nullptr;
    }
    
    Publisher* findPublisherByName(const std::string& name) {
        for (auto& publisher : publishers) {
            if (publisher.name == name) {
                return &publisher;
            }
        }
        return nullptr;
    }
    
public:
    void addBook(const std::string& title, const std::string& author, const std::string& isbn, const std::string& publisher) {
        books.push_back(Book(title, author, isbn, publisher));
    }
    
    void deleteBook(const std::string& isbn) {
        int index = -1;
        for (size_t i = 0; i < books.size(); ++i) {
            if (books[i].isbn == isbn) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            books.erase(books.begin() + index);
        }
    }
    
    void updateBook(const std::string& isbn, const std::string& title, const std::string& author, const std::string& publisher) {
        Book* book = findBookByISBN(isbn);
        if (book) {
            book->title = title;
            book->author = author;
            book->publisher = publisher;
        }
    }
    
    void searchBook(const std::string& isbn) {
        Book* book = findBookByISBN(isbn);
        if (book) {
            std::cout << "Book found: " << book->title << ", " << book->author << ", " << book->isbn << ", " << book->publisher << "\n";
        } else {
            std::cout << "Book not found\n";
        }
    }
    
    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book: " << book.title << ", " << book.author << ", " << book.isbn << ", " << book.publisher << "\n";
        }
    }
    
    void addPublisher(const std::string& name, const std::string& address) {
        publishers.push_back(Publisher(name, address));
    }
    
    void deletePublisher(const std::string& name) {
        int index = -1;
        for (size_t i = 0; i < publishers.size(); ++i) {
            if (publishers[i].name == name) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            publishers.erase(publishers.begin() + index);
        }
    }
    
    void updatePublisher(const std::string& name, const std::string& address) {
        Publisher* publisher = findPublisherByName(name);
        if (publisher) {
            publisher->address = address;
        }
    }
    
    void searchPublisher(const std::string& name) {
        Publisher* publisher = findPublisherByName(name);
        if (publisher) {
            std::cout << "Publisher found: " << publisher->name << ", " << publisher->address << "\n";
        } else {
            std::cout << "Publisher not found\n";
        }
    }
    
    void displayPublishers() {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher: " << publisher.name << ", " << publisher.address << "\n";
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("O'Reilly Media", "1005 Gravenstein Hwy N, Sebastopol, CA 95472");
    system.addBook("C++ Programming", "Bjarne Stroustrup", "9780134997834", "O'Reilly Media");
    system.displayBooks();
    system.displayPublishers();
    system.searchBook("9780134997834");
    system.updateBook("9780134997834", "Advanced C++ Programming", "Bjarne Stroustrup", "O'Reilly Media");
    system.displayBooks();
    system.deleteBook("9780134997834");
    system.displayBooks();
    return 0;
}