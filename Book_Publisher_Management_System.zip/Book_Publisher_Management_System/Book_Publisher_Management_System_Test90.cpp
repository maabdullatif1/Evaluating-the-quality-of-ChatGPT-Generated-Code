#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    std::string address;

    Publisher(int id, const std::string& name, const std::string& address)
        : id(id), name(name), address(address) {}
};

class Book {
public:
    int id;
    std::string title;
    std::string author;
    int publisherId;

    Book(int id, const std::string& title, const std::string& author, int publisherId)
        : id(id), title(title), author(author), publisherId(publisherId) {}
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;

    Publisher* findPublisher(int id) {
        for(auto& publisher : publishers) {
            if(publisher.id == id) return &publisher;
        }
        return nullptr;
    }

    Book* findBook(int id) {
        for(auto& book : books) {
            if(book.id == id) return &book;
        }
        return nullptr;
    }

public:
    void addPublisher(int id, const std::string& name, const std::string& address) {
        publishers.push_back(Publisher(id, name, address));
    }

    void deletePublisher(int id) {
        for(auto it = publishers.begin(); it != publishers.end(); ++it) {
            if(it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, const std::string& name, const std::string& address) {
        Publisher* publisher = findPublisher(id);
        if(publisher) {
            publisher->name = name;
            publisher->address = address;
        }
    }

    void searchPublisher(int id) {
        Publisher* publisher = findPublisher(id);
        if(publisher) {
            std::cout << "Publisher ID: " << publisher->id << ", Name: " << publisher->name 
                      << ", Address: " << publisher->address << std::endl;
        } else {
            std::cout << "Publisher not found." << std::endl;
        }
    }

    void displayPublishers() {
        for(const auto& publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name 
                      << ", Address: " << publisher.address << std::endl;
        }
    }

    void addBook(int id, const std::string& title, const std::string& author, int publisherId) {
        books.push_back(Book(id, title, author, publisherId));
    }

    void deleteBook(int id) {
        for(auto it = books.begin(); it != books.end(); ++it) {
            if(it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const std::string& title, const std::string& author, int publisherId) {
        Book* book = findBook(id);
        if(book) {
            book->title = title;
            book->author = author;
            book->publisherId = publisherId;
        }
    }

    void searchBook(int id) {
        Book* book = findBook(id);
        if(book) {
            std::cout << "Book ID: " << book->id << ", Title: " << book->title 
                      << ", Author: " << book->author << ", Publisher ID: " << book->publisherId << std::endl;
        } else {
            std::cout << "Book not found." << std::endl;
        }
    }

    void displayBooks() {
        for(const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title 
                      << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "Publisher A", "Address A");
    system.addPublisher(2, "Publisher B", "Address B");
    system.addBook(1, "Book A", "Author A", 1);
    system.addBook(2, "Book B", "Author B", 2);

    std::cout << "Publishers:" << std::endl;
    system.displayPublishers();

    std::cout << "Books:" << std::endl;
    system.displayBooks();

    return 0;
}