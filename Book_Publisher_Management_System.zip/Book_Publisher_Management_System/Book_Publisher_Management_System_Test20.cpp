#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    
    Publisher(int _id, const std::string& _name) : id(_id), name(_name) {}
};

class Book {
public:
    int id;
    std::string title;
    Publisher* publisher;
    
    Book(int _id, const std::string& _title, Publisher* _publisher) 
        : id(_id), title(_title), publisher(_publisher) {}
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;

public:
    void addPublisher(int id, const std::string& name) {
        publishers.emplace_back(id, name);
    }
    
    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
        books.erase(std::remove_if(books.begin(), books.end(), 
                   [id](const Book& book) { return book.publisher->id == id; }), books.end());
    }
    
    void updatePublisher(int id, const std::string& newName) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = newName;
                break;
            }
        }
    }
    
    Publisher* getPublisher(int id) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }
    
    void addBook(int id, const std::string& title, int publisherId) {
        Publisher* publisher = getPublisher(publisherId);
        if (publisher) {
            books.emplace_back(id, title, publisher);
        }
    }
    
    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(), 
                   [id](const Book& book) { return book.id == id; }), books.end());
    }
    
    void updateBook(int id, const std::string& newTitle, int newPublisherId) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = newTitle;
                book.publisher = getPublisher(newPublisherId);
                break;
            }
        }
    }
    
    Book* getBook(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }
    
    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title 
                      << ", Publisher: " << book.publisher->name << std::endl;
        }
    }
    
    void displayPublishers() {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    
    system.addPublisher(1, "Publisher A");
    system.addPublisher(2, "Publisher B");
    
    system.addBook(1, "Book One", 1);
    system.addBook(2, "Book Two", 2);
    
    system.displayPublishers();
    system.displayBooks();
    
    system.updatePublisher(1, "Updated Publisher A");
    system.updateBook(1, "Updated Book One", 2);
    
    system.displayPublishers();
    system.displayBooks();
    
    system.deleteBook(2);
    system.deletePublisher(1);
    
    system.displayPublishers();
    system.displayBooks();
    
    return 0;
}