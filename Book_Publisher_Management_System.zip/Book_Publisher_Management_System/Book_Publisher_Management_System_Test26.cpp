#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;

    Publisher(int id, std::string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;
    int publisherId;

    Book(int id, std::string title, int publisherId) : id(id), title(title), publisherId(publisherId) {}
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;

public:
    void addPublisher(int id, std::string name) {
        publishers.push_back(Publisher(id, name));
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, std::string name) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = name;
                break;
            }
        }
    }

    Publisher* searchPublisher(int id) {
        for (auto &publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for (auto &publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << std::endl;
        }
    }

    void addBook(int id, std::string title, int publisherId) {
        books.push_back(Book(id, title, publisherId));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string title, int publisherId) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                book.publisherId = publisherId;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (auto &book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "HarperCollins");
    system.addPublisher(2, "Penguin Random House");
    
    system.addBook(101, "Book1", 1);
    system.addBook(102, "Book2", 2);

    system.displayPublishers();
    system.displayBooks();

    system.updatePublisher(1, "HC");
    system.updateBook(101, "Updated Book1", 2);

    system.displayPublishers();
    system.displayBooks();

    Publisher* p = system.searchPublisher(2);
    if (p) {
        std::cout << "Found Publisher: " << p->name << std::endl;
    }

    Book* b = system.searchBook(102);
    if (b) {
        std::cout << "Found Book: " << b->title << std::endl;
    }

    system.deletePublisher(2);
    system.deleteBook(102);

    system.displayPublishers();
    system.displayBooks();

    return 0;
}