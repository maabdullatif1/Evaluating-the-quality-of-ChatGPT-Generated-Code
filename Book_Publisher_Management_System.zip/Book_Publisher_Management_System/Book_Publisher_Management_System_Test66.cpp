#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Publisher {
public:
    string name;
    string address;

    Publisher(string name, string address) : name(name), address(address) {}
};

class Book {
public:
    string title;
    string author;
    string isbn;
    Publisher* publisher;

    Book(string title, string author, string isbn, Publisher* publisher)
        : title(title), author(author), isbn(isbn), publisher(publisher) {}
};

class ManagementSystem {
private:
    vector<Publisher> publishers;
    vector<Book> books;

    Publisher* findPublisher(string name) {
        for (auto& publisher : publishers) {
            if (publisher.name == name) return &publisher;
        }
        return nullptr;
    }

    int findBookIndex(string isbn) {
        for (int i = 0; i < books.size(); ++i) {
            if (books[i].isbn == isbn) return i;
        }
        return -1;
    }

public:
    void addPublisher(string name, string address) {
        publishers.emplace_back(name, address);
    }

    void deletePublisher(string name) {
        publishers.erase(
            remove_if(publishers.begin(), publishers.end(), [&](Publisher& p) { return p.name == name; }),
            publishers.end());
    }

    void updatePublisher(string name, string newAddress) {
        Publisher* publisher = findPublisher(name);
        if (publisher) publisher->address = newAddress;
    }

    void addBook(string title, string author, string isbn, string publisherName) {
        Publisher* publisher = findPublisher(publisherName);
        if (publisher) books.emplace_back(title, author, isbn, publisher);
    }

    void deleteBook(string isbn) {
        int index = findBookIndex(isbn);
        if (index != -1) books.erase(books.begin() + index);
    }

    void updateBook(string isbn, string newTitle, string newAuthor, string newIsbn) {
        int index = findBookIndex(isbn);
        if (index != -1) {
            books[index].title = newTitle;
            books[index].author = newAuthor;
            books[index].isbn = newIsbn;
        }
    }

    Book* searchBook(string isbn) {
        int index = findBookIndex(isbn);
        if (index != -1) return &books[index];
        return nullptr;
    }

    vector<Book*> searchBooksByPublisher(string publisherName) {
        vector<Book*> result;
        for (auto& book : books) {
            if (book.publisher->name == publisherName) result.push_back(&book);
        }
        return result;
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "Title: " << book.title << ", Author: " << book.author
                 << ", ISBN: " << book.isbn << ", Publisher: " << book.publisher->name << endl;
        }
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            cout << "Publisher: " << publisher.name << ", Address: " << publisher.address << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("PubOne", "123 Elm St");
    system.addPublisher("PubTwo", "456 Maple St");
    system.addBook("BookOne", "AuthorOne", "ISBN123", "PubOne");
    system.addBook("BookTwo", "AuthorTwo", "ISBN456", "PubTwo");

    system.displayPublishers();
    system.displayBooks();

    system.updateBook("ISBN123", "BookOne Updated", "AuthorOne", "ISBN123U");
    system.displayBooks();

    system.deleteBook("ISBN456");
    system.displayBooks();

    return 0;
}