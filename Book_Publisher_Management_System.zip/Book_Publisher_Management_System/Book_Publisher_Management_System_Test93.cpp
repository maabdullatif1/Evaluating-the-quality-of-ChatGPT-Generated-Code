#include <iostream>
#include <vector>
#include <string>

struct Publisher {
    int id;
    std::string name;
};

struct Book {
    int id;
    std::string title;
    std::string author;
    int publisherId;
};

class ManagementSystem {
public:
    void addPublisher(int id, std::string name) {
        publishers.push_back({id, name});
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, std::string newName) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = newName;
                break;
            }
        }
    }

    void searchPublisher(int id) {
        for (const auto& publisher : publishers) {
            if (publisher.id == id) {
                std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << std::endl;
                return;
            }
        }
        std::cout << "Publisher not found" << std::endl;
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << std::endl;
        }
    }

    void addBook(int id, std::string title, std::string author, int publisherId) {
        books.push_back({id, title, author, publisherId});
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string newTitle, std::string newAuthor, int newPublisherId) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = newTitle;
                book.author = newAuthor;
                book.publisherId = newPublisherId;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << std::endl;
                return;
            }
        }
        std::cout << "Book not found" << std::endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << std::endl;
        }
    }

private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "HarperCollins");
    system.addPublisher(2, "Penguin Random House");

    system.addBook(101, "To Kill a Mockingbird", "Harper Lee", 1);
    system.addBook(102, "1984", "George Orwell", 2);

    system.displayPublishers();
    system.displayBooks();

    system.updatePublisher(1, "Harper Collins");
    system.searchPublisher(1);

    system.updateBook(101, "Go Set a Watchman", "Harper Lee", 1);
    system.searchBook(101);

    system.deletePublisher(2);
    system.deleteBook(102);

    system.displayPublishers();
    system.displayBooks();

    return 0;
}