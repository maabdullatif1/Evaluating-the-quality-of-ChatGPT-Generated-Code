#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    int id;
    std::string name;
    std::string address;

    Publisher(int id, std::string name, std::string address) 
        : id(id), name(name), address(address) {}
};

class Book {
public:
    int id;
    std::string title;
    std::string author;
    int publisherId;

    Book(int id, std::string title, std::string author, int publisherId) 
        : id(id), title(title), author(author), publisherId(publisherId) {}
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;

    Publisher* findPublisherById(int id) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }

    Book* findBookById(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

public:
    void addPublisher(int id, std::string name, std::string address) {
        publishers.push_back(Publisher(id, name, address));
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, std::string name, std::string address) {
        Publisher* publisher = findPublisherById(id);
        if (publisher) {
            publisher->name = name;
            publisher->address = address;
        }
    }

    void addBook(int id, std::string title, std::string author, int publisherId) {
        books.push_back(Book(id, title, author, publisherId));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string title, std::string author, int publisherId) {
        Book* book = findBookById(id);
        if (book) {
            book->title = title;
            book->author = author;
            book->publisherId = publisherId;
        }
    }

    void searchBook(int id) {
        Book* book = findBookById(id);
        if (book) {
            std::cout << "Book ID: " << book->id << ", Title: " << book->title 
                      << ", Author: " << book->author << ", Publisher ID: " << book->publisherId << "\n";
        } else {
            std::cout << "Book not found\n";
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title 
                      << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << "\n";
        }
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name 
                      << ", Address: " << publisher.address << "\n";
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "O'Reilly Media", "CA, USA");
    system.addPublisher(2, "Penguin Random House", "NY, USA");

    system.addBook(101, "The C++ Programming Language", "Bjarne Stroustrup", 1);
    system.addBook(102, "Clean Code", "Robert C. Martin", 2);

    std::cout << "Initial Publishers:\n";
    system.displayPublishers();

    std::cout << "Initial Books:\n";
    system.displayBooks();

    system.updatePublisher(1, "O'Reilly Media", "California, USA");
    system.updateBook(101, "The C++ Programming Language, 4th Edition", "Bjarne Stroustrup", 1);

    std::cout << "\nUpdated Publishers:\n";
    system.displayPublishers();

    std::cout << "Updated Books:\n";
    system.displayBooks();

    system.searchBook(101);

    system.deleteBook(101);
    system.deletePublisher(1);

    std::cout << "\nFinal Publishers:\n";
    system.displayPublishers();

    std::cout << "Final Books:\n";
    system.displayBooks();

    return 0;
}