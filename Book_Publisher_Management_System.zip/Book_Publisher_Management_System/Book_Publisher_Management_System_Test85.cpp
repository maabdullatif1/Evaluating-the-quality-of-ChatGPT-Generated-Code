#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Publisher {
public:
    string name;
    string address;
    Publisher(string n, string a) : name(n), address(a) {}
};

class Book {
public:
    string title;
    string author;
    string isbn;
    Publisher publisher;
    Book(string t, string a, string i, Publisher p) : title(t), author(a), isbn(i), publisher(p) {}
};

class ManagementSystem {
    vector<Publisher> publishers;
    vector<Book> books;

public:
    void addPublisher(string name, string address) {
        publishers.push_back(Publisher(name, address));
    }

    void addBook(string title, string author, string isbn, Publisher publisher) {
        books.push_back(Book(title, author, isbn, publisher));
    }

    void deletePublisher(string name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->name == name) {
                publishers.erase(it);
                break;
            }
        }
    }

    void deleteBook(string isbn) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->isbn == isbn) {
                books.erase(it);
                break;
            }
        }
    }

    void updatePublisher(string oldName, string newName, string newAddress) {
        for (auto& publisher : publishers) {
            if (publisher.name == oldName) {
                publisher.name = newName;
                publisher.address = newAddress;
                break;
            }
        }
    }

    void updateBook(string oldIsbn, string newTitle, string newAuthor, string newIsbn, Publisher newPublisher) {
        for (auto& book : books) {
            if (book.isbn == oldIsbn) {
                book.title = newTitle;
                book.author = newAuthor;
                book.isbn = newIsbn;
                book.publisher = newPublisher;
                break;
            }
        }
    }

    void searchPublisher(string name) {
        for (const auto& publisher : publishers) {
            if (publisher.name == name) {
                cout << "Publisher Found: " << publisher.name << ", " << publisher.address << endl;
                return;
            }
        }
        cout << "Publisher Not Found" << endl;
    }

    void searchBook(string isbn) {
        for (const auto& book : books) {
            if (book.isbn == isbn) {
                cout << "Book Found: " << book.title << ", " << book.author << ", " << book.isbn << ", " << book.publisher.name << endl;
                return;
            }
        }
        cout << "Book Not Found" << endl;
    }

    void displayPublishers() {
        cout << "Publishers List:" << endl;
        for (const auto& publisher : publishers) {
            cout << "Name: " << publisher.name << ", Address: " << publisher.address << endl;
        }
    }

    void displayBooks() {
        cout << "Books List:" << endl;
        for (const auto& book : books) {
            cout << "Title: " << book.title << ", Author: " << book.author << ", ISBN: " << book.isbn << ", Publisher: " << book.publisher.name << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("Publisher1", "123 Street");
    system.addPublisher("Publisher2", "456 Avenue");

    system.addBook("Book1", "Author1", "ISBN1", Publisher("Publisher1", "123 Street"));
    system.addBook("Book2", "Author2", "ISBN2", Publisher("Publisher2", "456 Avenue"));

    system.displayPublishers();
    system.displayBooks();

    system.searchPublisher("Publisher1");
    system.searchBook("ISBN1");

    system.updatePublisher("Publisher1", "Updated Publisher", "789 Boulevard");
    system.updateBook("ISBN1", "Updated Book1", "Updated Author1", "ISBN3", Publisher("Updated Publisher", "789 Boulevard"));

    system.displayPublishers();
    system.displayBooks();

    system.deletePublisher("Updated Publisher");
    system.deleteBook("ISBN3");

    system.displayPublishers();
    system.displayBooks();
    
    return 0;
}