#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Book {
public:
    int id;
    string title;
    string author;
    int publisherId;
    Book(int id, string title, string author, int publisherId)
        : id(id), title(title), author(author), publisherId(publisherId) {}
};

class Publisher {
public:
    int id;
    string name;
    Publisher(int id, string name) : id(id), name(name) {}
};

class ManagementSystem {
private:
    vector<Book> books;
    vector<Publisher> publishers;
    
public:
    void addPublisher(int id, string name) {
        publishers.push_back(Publisher(id, name));
    }
    
    void deletePublisher(int id) {
        for(auto it = publishers.begin(); it != publishers.end(); ++it) {
            if(it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }
    
    Publisher* searchPublisher(int id) {
        for(auto& publisher : publishers) {
            if(publisher.id == id) {
                return &publisher;
            }
        }
        return nullptr;
    }
    
    void updatePublisher(int id, string name) {
        for(auto& publisher : publishers) {
            if(publisher.id == id) {
                publisher.name = name;
                return;
            }
        }
    }
    
    void displayPublishers() {
        for(const auto& publisher : publishers) {
            cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << endl;
        }
    }
    
    void addBook(int id, string title, string author, int publisherId) {
        books.push_back(Book(id, title, author, publisherId));
    }

    void deleteBook(int id) {
        for(auto it = books.begin(); it != books.end(); ++it) {
            if(it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for(auto& book : books) {
            if(book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }
    
    void updateBook(int id, string title, string author, int publisherId) {
        for(auto& book : books) {
            if(book.id == id) {
                book.title = title;
                book.author = author;
                book.publisherId = publisherId;
                return;
            }
        }
    }

    void displayBooks() {
        for(const auto& book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title 
                 << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << endl;
        }
    }
};

int main() {
    ManagementSystem ms;
    ms.addPublisher(1, "Penguin");
    ms.addPublisher(2, "HarperCollins");
    ms.addBook(101, "1984", "George Orwell", 1);
    ms.addBook(102, "Brave New World", "Aldous Huxley", 1);
    ms.addBook(103, "To Kill a Mockingbird", "Harper Lee", 2);
    cout << "Publishers:" << endl;
    ms.displayPublishers();
    cout << endl << "Books:" << endl;
    ms.displayBooks();
    return 0;
}