#include <iostream>
#include <vector>
#include <string>

class Book {
private:
    std::string title;
    std::string author;
    std::string publisher;
    int year;
public:
    Book(std::string t, std::string a, std::string p, int y) : title(t), author(a), publisher(p), year(y) {}

    std::string getTitle() const { return title; }
    std::string getAuthor() const { return author; }
    std::string getPublisher() const { return publisher; }
    int getYear() const { return year; }

    void setTitle(const std::string &t) { title = t; }
    void setAuthor(const std::string &a) { author = a; }
    void setPublisher(const std::string &p) { publisher = p; }
    void setYear(int y) { year = y; }

    void display() const {
        std::cout << "Title: " << title << ", Author: " << author << ", Publisher: " << publisher << ", Year: " << year << std::endl;
    }
};

class Publisher {
private:
    std::string name;
public:
    Publisher(std::string n) : name(n) {}

    std::string getName() const { return name; }
    void setName(const std::string &n) { name = n; }

    void display() const {
        std::cout << "Publisher: " << name << std::endl;
    }
};

class BookPublisherManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Publisher> publishers;

    int findBookIndex(const std::string &title) {
        for (size_t i = 0; i < books.size(); ++i) {
            if (books[i].getTitle() == title) {
                return i;
            }
        }
        return -1;
    }

    int findPublisherIndex(const std::string &name) {
        for (size_t i = 0; i < publishers.size(); ++i) {
            if (publishers[i].getName() == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addBook(const Book &book) {
        books.push_back(book);
    }

    void deleteBook(const std::string &title) {
        int index = findBookIndex(title);
        if (index != -1) {
            books.erase(books.begin() + index);
        }
    }

    void updateBook(const std::string &title, const Book &newBook) {
        int index = findBookIndex(title);
        if (index != -1) {
            books[index] = newBook;
        }
    }

    void searchBook(const std::string &title) {
        int index = findBookIndex(title);
        if (index != -1) {
            books[index].display();
        } else {
            std::cout << "Book not found." << std::endl;
        }
    }

    void displayBooks() const {
        for (const auto &book : books) {
            book.display();
        }
    }

    void addPublisher(const Publisher &publisher) {
        publishers.push_back(publisher);
    }

    void deletePublisher(const std::string &name) {
        int index = findPublisherIndex(name);
        if (index != -1) {
            publishers.erase(publishers.begin() + index);
        }
    }

    void updatePublisher(const std::string &name, const Publisher &newPublisher) {
        int index = findPublisherIndex(name);
        if (index != -1) {
            publishers[index] = newPublisher;
        }
    }

    void searchPublisher(const std::string &name) {
        int index = findPublisherIndex(name);
        if (index != -1) {
            publishers[index].display();
        } else {
            std::cout << "Publisher not found." << std::endl;
        }
    }

    void displayPublishers() const {
        for (const auto &publisher : publishers) {
            publisher.display();
        }
    }
};

int main() {
    BookPublisherManagementSystem system;
    system.addBook(Book("C++ Programming", "Bjarne Stroustrup", "Addison-Wesley", 1991));
    system.addPublisher(Publisher("Addison-Wesley"));

    system.displayBooks();
    system.displayPublishers();

    system.searchBook("C++ Programming");
    system.searchPublisher("Addison-Wesley");

    system.deleteBook("C++ Programming");
    system.deletePublisher("Addison-Wesley");

    system.displayBooks();
    system.displayPublishers();

    return 0;
}