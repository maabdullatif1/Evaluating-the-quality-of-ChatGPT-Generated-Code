#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    std::string name;
    std::string address;
    Publisher(std::string n, std::string a) : name(n), address(a) {}
};

class Book {
public:
    std::string title;
    std::string author;
    Publisher* publisher;
    Book(std::string t, std::string a, Publisher* p) : title(t), author(a), publisher(p) {}
};

class ManagementSystem {
    std::vector<Publisher> publishers;
    std::vector<Book> books;
public:
    void addPublisher(std::string name, std::string address) {
        publishers.push_back(Publisher(name, address));
    }
    
    void deletePublisher(std::string name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->name == name) {
                publishers.erase(it);
                break;
            }
        }
    }
    
    void updatePublisher(std::string oldName, std::string newName, std::string newAddress) {
        for (auto& publisher : publishers) {
            if (publisher.name == oldName) {
                publisher.name = newName;
                publisher.address = newAddress;
                break;
            }
        }
    }
    
    Publisher* searchPublisher(std::string name) {
        for (auto& publisher : publishers) {
            if (publisher.name == name) return &publisher;
        }
        return nullptr;
    }
    
    void displayPublishers() {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher: " << publisher.name << ", Address: " << publisher.address << std::endl;
        }
    }
        
    void addBook(std::string title, std::string author, std::string publisherName) {
        Publisher* publisher = searchPublisher(publisherName);
        if (publisher) {
            books.push_back(Book(title, author, publisher));
        }
    }
    
    void deleteBook(std::string title) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->title == title) {
                books.erase(it);
                break;
            }
        }
    }
    
    void updateBook(std::string oldTitle, std::string newTitle, std::string newAuthor, std::string publisherName) {
        for (auto& book : books) {
            if (book.title == oldTitle) {
                book.title = newTitle;
                book.author = newAuthor;
                book.publisher = searchPublisher(publisherName);
                break;
            }
        }
    }
    
    Book* searchBook(std::string title) {
        for (auto& book : books) {
            if (book.title == title) return &book;
        }
        return nullptr;
    }
    
    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book: " << book.title << ", Author: " << book.author << ", Publisher: " << book.publisher->name << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("Penguin", "123 Main St");
    system.addPublisher("HarperCollins", "456 Elm St");
    system.addBook("The Great Gatsby", "F. Scott Fitzgerald", "Penguin");
    system.addBook("To Kill a Mockingbird", "Harper Lee", "HarperCollins");
    system.displayPublishers();
    system.displayBooks();
    system.updatePublisher("Penguin", "Penguin Books", "789 Oak St");
    system.updateBook("The Great Gatsby", "The Great Gatsby", "Fitzgerald", "Penguin Books");
    system.displayPublishers();
    system.displayBooks();
    system.deleteBook("To Kill a Mockingbird");
    system.deletePublisher("HarperCollins");
    system.displayBooks();
    system.displayPublishers();
    return 0;
}