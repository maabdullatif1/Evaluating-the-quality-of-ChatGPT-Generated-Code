#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    std::string name;
    std::string address;
    int yearEstablished;

    Publisher(std::string name, std::string address, int year)
        : name(name), address(address), yearEstablished(year) {}
};

class Book {
public:
    std::string title;
    std::string author;
    int yearPublished;
    Publisher* publisher;

    Book(std::string title, std::string author, int year, Publisher* publisher)
        : title(title), author(author), yearPublished(year), publisher(publisher) {}
};

class ManagementSystem {
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;

public:
    void addPublisher(const std::string& name, const std::string& address, int year) {
        publishers.push_back(Publisher(name, address, year));
    }

    void addBook(const std::string& title, const std::string& author, int year, const std::string& publisherName) {
        for (Publisher& publisher : publishers) {
            if (publisher.name == publisherName) {
                books.push_back(Book(title, author, year, &publisher));
                return;
            }
        }
    }

    void deletePublisher(const std::string& name) {
        publishers.erase(std::remove_if(publishers.begin(), publishers.end(),
                                        [name](Publisher& p) { return p.name == name; }),
                         publishers.end());
    }

    void deleteBook(const std::string& title) {
        books.erase(std::remove_if(books.begin(), books.end(),
                                   [title](Book& b) { return b.title == title; }),
                    books.end());
    }

    void updatePublisher(const std::string& name, const std::string& newAddress, int newYear) {
        for (Publisher& publisher : publishers) {
            if (publisher.name == name) {
                publisher.address = newAddress;
                publisher.yearEstablished = newYear;
                return;
            }
        }
    }

    void updateBook(const std::string& title, const std::string& newAuthor, int newYear, const std::string& newPublisherName) {
        for (Book& book : books) {
            if (book.title == title) {
                book.author = newAuthor;
                book.yearPublished = newYear;
                for (Publisher& publisher : publishers) {
                    if (publisher.name == newPublisherName) {
                        book.publisher = &publisher;
                        return;
                    }
                }
            }
        }
    }

    void searchPublisher(const std::string& name) {
        for (const Publisher& publisher : publishers) {
            if (publisher.name == name) {
                std::cout << "Publisher: " << publisher.name << ", Address: " << publisher.address
                          << ", Established: " << publisher.yearEstablished << std::endl;
                return;
            }
        }
    }

    void searchBook(const std::string& title) {
        for (const Book& book : books) {
            if (book.title == title) {
                std::cout << "Book: " << book.title << ", Author: " << book.author
                          << ", Year: " << book.yearPublished
                          << ", Publisher: " << book.publisher->name << std::endl;
                return;
            }
        }
    }

    void displayPublishers() {
        for (const Publisher& publisher : publishers) {
            std::cout << "Publisher: " << publisher.name << ", Address: " << publisher.address
                      << ", Established: " << publisher.yearEstablished << std::endl;
        }
    }

    void displayBooks() {
        for (const Book& book : books) {
            std::cout << "Book: " << book.title << ", Author: " << book.author
                      << ", Year: " << book.yearPublished
                      << ", Publisher: " << book.publisher->name << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("HarperCollins", "New York", 1989);
    system.addPublisher("Penguin Random House", "London", 1838);
      
    system.addBook("The Great Book", "John Doe", 2000, "HarperCollins");
    system.addBook("Another Book", "Jane Smith", 2010, "Penguin Random House");

    system.displayPublishers();
    system.displayBooks();

    system.searchPublisher("HarperCollins");
    system.searchBook("The Great Book");

    system.updatePublisher("HarperCollins", "California", 1990);
    system.updateBook("The Great Book", "John Doe", 2002, "Penguin Random House");

    system.deleteBook("Another Book");
    system.deletePublisher("Penguin Random House");

    system.displayPublishers();
    system.displayBooks();

    return 0;
}