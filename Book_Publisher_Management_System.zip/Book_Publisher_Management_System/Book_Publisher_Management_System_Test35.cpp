#include <iostream>
#include <string>
#include <vector>

class Publisher {
public:
    std::string name;
    std::string address;

    Publisher(std::string n, std::string a) : name(n), address(a) {}
};

class Book {
public:
    std::string title;
    std::string author;
    Publisher *publisher;

    Book(std::string t, std::string a, Publisher *p) : title(t), author(a), publisher(p) {}
};

class ManagementSystem {
private:
    std::vector<Publisher*> publishers;
    std::vector<Book*> books;

public:
    void addPublisher(std::string name, std::string address) {
        publishers.push_back(new Publisher(name, address));
    }

    void addBook(std::string title, std::string author, std::string publisherName) {
        Publisher *pub = findPublisher(publisherName);
        if (pub != nullptr) {
            books.push_back(new Book(title, author, pub));
        } else {
            std::cout << "Publisher not found\n";
        }
    }

    void deletePublisher(std::string name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if ((*it)->name == name) {
                delete *it;
                publishers.erase(it);
                break;
            }
        }
    }

    void deleteBook(std::string title) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if ((*it)->title == title) {
                delete *it;
                books.erase(it);
                break;
            }
        }
    }

    void updatePublisher(std::string name, std::string newName, std::string newAddress) {
        Publisher *pub = findPublisher(name);
        if (pub != nullptr) {
            pub->name = newName;
            pub->address = newAddress;
        } else {
            std::cout << "Publisher not found\n";
        }
    }

    void updateBook(std::string title, std::string newTitle, std::string newAuthor, std::string newPublisherName) {
        Book *book = findBook(title);
        Publisher *newPub = findPublisher(newPublisherName);
        if (book != nullptr && newPub != nullptr) {
            book->title = newTitle;
            book->author = newAuthor;
            book->publisher = newPub;
        } else {
            std::cout << "Book or Publisher not found\n";
        }
    }

    void searchPublisher(std::string name) {
        Publisher *pub = findPublisher(name);
        if (pub != nullptr) {
            std::cout << "Publisher: " << pub->name << ", Address: " << pub->address << "\n";
        } else {
            std::cout << "Publisher not found\n";
        }
    }

    void searchBook(std::string title) {
        Book *book = findBook(title);
        if (book != nullptr) {
            std::cout << "Title: " << book->title << ", Author: " << book->author << ", Publisher: " << book->publisher->name << "\n";
        } else {
            std::cout << "Book not found\n";
        }
    }

    void displayPublishers() {
        for (auto &pub : publishers) {
            std::cout << "Publisher: " << pub->name << ", Address: " << pub->address << "\n";
        }
    }

    void displayBooks() {
        for (auto &book : books) {
            std::cout << "Title: " << book->title << ", Author: " << book->author << ", Publisher: " << book->publisher->name << "\n";
        }
    }

private:
    Publisher* findPublisher(std::string name) {
        for (auto &pub : publishers) {
            if (pub->name == name) return pub;
        }
        return nullptr;
    }

    Book* findBook(std::string title) {
        for (auto &book : books) {
            if (book->title == title) return book;
        }
        return nullptr;
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("Publisher1", "Address1");
    system.addBook("Book1", "Author1", "Publisher1");
    system.displayPublishers();
    system.displayBooks();
    system.updateBook("Book1", "NewBook1", "NewAuthor1", "Publisher1");
    system.searchBook("NewBook1");
    system.deleteBook("NewBook1");
    system.deletePublisher("Publisher1");
    return 0;
}