#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    Publisher(int id, std::string name) : id(id), name(name) {}

    int getId() const { return id; }
    std::string getName() const { return name; }

    void updateName(const std::string& newName) { name = newName; }

private:
    int id;
    std::string name;
};

class Book {
public:
    Book(int id, std::string title, int publisherId) : id(id), title(title), publisherId(publisherId) {}

    int getId() const { return id; }
    std::string getTitle() const { return title; }
    int getPublisherId() const { return publisherId; }

    void updateTitle(const std::string& newTitle) { title = newTitle; }
    void updatePublisherId(int newPublisherId) { publisherId = newPublisherId; }

private:
    int id;
    std::string title;
    int publisherId;
};

class ManagementSystem {
public:
    void addPublisher(int id, const std::string& name) {
        publishers.emplace_back(id, name);
    }
    
    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->getId() == id) {
                publishers.erase(it);
                break;
            }
        }
    }
    
    Publisher* searchPublisher(int id) {
        for (auto& publisher : publishers) {
            if (publisher.getId() == id) {
                return &publisher;
            }
        }
        return nullptr;
    }
    
    void displayPublishers() {
        for (const auto& publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.getId() << ", Name: " << publisher.getName() << std::endl;
        }
    }
    
    void addBook(int id, const std::string& title, int publisherId) {
        books.emplace_back(id, title, publisherId);
    }
    
    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->getId() == id) {
                books.erase(it);
                break;
            }
        }
    }
    
    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.getId() == id) {
                return &book;
            }
        }
        return nullptr;
    }
    
    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.getId() << ", Title: " << book.getTitle() << ", Publisher ID: " << book.getPublisherId() << std::endl;
        }
    }
    
private:
    std::vector<Publisher> publishers;
    std::vector<Book> books;
};

int main() {
    ManagementSystem system;
    
    system.addPublisher(1, "Publisher1");
    system.addPublisher(2, "Publisher2");
    
    system.addBook(101, "Book1", 1);
    system.addBook(102, "Book2", 2);
    
    std::cout << "All Publishers:" << std::endl;
    system.displayPublishers();
    
    std::cout << "\nAll Books:" << std::endl;
    system.displayBooks();
    
    system.deleteBook(101);
    std::cout << "\nBooks after deletion:" << std::endl;
    system.displayBooks();
    
    Publisher* publisher = system.searchPublisher(2);
    if (publisher) {
        publisher->updateName("Updated Publisher2");
    }
    
    std::cout << "\nPublishers after update:" << std::endl;
    system.displayPublishers();
    
    return 0;
}