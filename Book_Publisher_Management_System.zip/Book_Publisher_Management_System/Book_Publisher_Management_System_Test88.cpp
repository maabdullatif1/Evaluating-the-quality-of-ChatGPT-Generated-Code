#include <iostream>
#include <vector>
#include <string>

class Publisher {
public:
    std::string name;
    std::string address;
    Publisher(const std::string &n, const std::string &a) : name(n), address(a) {}
};

class Book {
public:
    std::string title;
    std::string author;
    Publisher *publisher;
    Book(const std::string &t, const std::string &a, Publisher *p) : title(t), author(a), publisher(p) {}
};

class ManagementSystem {
    std::vector<Publisher> publishers;
    std::vector<Book> books;

public:
    void addPublisher(const Publisher &publisher) {
        publishers.push_back(publisher);
    }

    void updatePublisher(const std::string &name, const std::string &newAddress) {
        for (auto &pub : publishers) {
            if (pub.name == name) {
                pub.address = newAddress;
                break;
            }
        }
    }

    void deletePublisher(const std::string &name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->name == name) {
                publishers.erase(it);
                break;
            }
        }
    }

    Publisher* searchPublisher(const std::string &name) {
        for (auto &pub : publishers) {
            if (pub.name == name) {
                return &pub;
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto &pub : publishers) {
            std::cout << "Publisher Name: " << pub.name << ", Address: " << pub.address << std::endl;
        }
    }

    void addBook(const Book &book) {
        books.push_back(book);
    }

    void updateBook(const std::string &title, const std::string &newAuthor, Publisher *publisher) {
        for (auto &book : books) {
            if (book.title == title) {
                book.author = newAuthor;
                book.publisher = publisher;
                break;
            }
        }
    }

    void deleteBook(const std::string &title) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->title == title) {
                books.erase(it);
                break;
            }
        }
    }

    Book* searchBook(const std::string &title) {
        for (auto &book : books) {
            if (book.title == title) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto &book : books) {
            std::cout << "Book Title: " << book.title << ", Author: " << book.author;
            if (book.publisher) {
                std::cout << ", Publisher: " << book.publisher->name << std::endl;
            }
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(Publisher("O'Reilly", "CA, USA"));
    system.addPublisher(Publisher("Penguin", "NY, USA"));
    Publisher* p1 = system.searchPublisher("O'Reilly");
    system.addBook(Book("C++ Primer", "Lippman", p1));
    Publisher* p2 = system.searchPublisher("Penguin");
    system.addBook(Book("1984", "Orwell", p2));
    system.displayPublishers();
    system.displayBooks();
    system.updatePublisher("O'Reilly", "SF, USA");
    system.updateBook("1984", "George Orwell", p1);
    system.displayPublishers();
    system.displayBooks();
    system.deletePublisher("Penguin");
    system.deleteBook("C++ Primer");
    system.displayPublishers();
    system.displayBooks();
    return 0;
}