#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Book {
    int id;
    string title;
    string author;
    int publisherId;
};

struct Publisher {
    int id;
    string name;
};

class ManagementSystem {
    vector<Book> books;
    vector<Publisher> publishers;
    int bookIdCounter = 1;
    int publisherIdCounter = 1;

public:
    void addBook(const string& title, const string& author, int publisherId) {
        books.push_back({bookIdCounter++, title, author, publisherId});
    }

    void deleteBook(int id) {
        for (size_t i = 0; i < books.size(); ++i) {
            if (books[i].id == id) {
                books.erase(books.begin() + i);
                break;
            }
        }
    }

    void updateBook(int id, const string& title, const string& author, int publisherId) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                book.publisherId = publisherId;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                cout << "Book ID: " << book.id << ", Title: " << book.title
                     << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << endl;
                return;
            }
        }
        cout << "Book not found." << endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title
                 << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << endl;
        }
    }

    void addPublisher(const string& name) {
        publishers.push_back({publisherIdCounter++, name});
    }

    void deletePublisher(int id) {
        for (size_t i = 0; i < publishers.size(); ++i) {
            if (publishers[i].id == id) {
                for (auto& book : books) {
                    if (book.publisherId == id) {
                        book.publisherId = 0; 
                    }
                }
                publishers.erase(publishers.begin() + i);
                break;
            }
        }
    }

    void updatePublisher(int id, const string& name) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) {
                publisher.name = name;
                break;
            }
        }
    }

    void searchPublisher(int id) {
        for (const auto& publisher : publishers) {
            if (publisher.id == id) {
                cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << endl;
                return;
            }
        }
        cout << "Publisher not found." << endl;
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << endl;
        }
    }
};

int main() {
    ManagementSystem system;

    system.addPublisher("HarperCollins");
    system.addPublisher("Penguin");

    system.addBook("1984", "George Orwell", 1);
    system.addBook("To Kill a Mockingbird", "Harper Lee", 2);

    system.displayBooks();
    system.displayPublishers();

    system.searchBook(1);
    system.searchPublisher(2);

    system.updateBook(1, "1984", "George Orwell", 2);
    system.updatePublisher(2, "Penguin Random House");

    system.displayBooks();
    system.displayPublishers();

    system.deleteBook(2);
    system.deletePublisher(1);

    system.displayBooks();
    system.displayPublishers();

    return 0;
}