#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Publisher {
public:
    string name;
    string address;
    Publisher(string n, string a) : name(n), address(a) {}
};

class Book {
public:
    string title;
    string author;
    Publisher* publisher;
    Book(string t, string a, Publisher* p) : title(t), author(a), publisher(p) {}
};

class ManagementSystem {
    vector<Publisher> publishers;
    vector<Book> books;

    Publisher* findPublisher(string name) {
        for (auto& publisher : publishers)
            if (publisher.name == name)
                return &publisher;
        return nullptr;
    }

    Book* findBook(string title) {
        for (auto& book : books)
            if (book.title == title)
                return &book;
        return nullptr;
    }

public:
    void addPublisher(string name, string address) {
        publishers.emplace_back(name, address);
    }

    void removePublisher(string name) {
        publishers.erase(remove_if(publishers.begin(), publishers.end(),
                     [=](Publisher& pub) { return pub.name == name; }),
                     publishers.end());
    }

    void updatePublisher(string name, string newAddress) {
        Publisher* publisher = findPublisher(name);
        if (publisher) {
            publisher->address = newAddress;
        }
    }

    void addBook(string title, string author, string publisherName) {
        Publisher* publisher = findPublisher(publisherName);
        if (publisher) {
            books.emplace_back(title, author, publisher);
        }
    }

    void removeBook(string title) {
        books.erase(remove_if(books.begin(), books.end(),
                   [=](Book& book) { return book.title == title; }),
                   books.end());
    }

    void updateBook(string title, string newAuthor) {
        Book* book = findBook(title);
        if (book) {
            book->author = newAuthor;
        }
    }

    void searchBooksByTitle(string title) {
        Book* book = findBook(title);
        if (book) {
            cout << "Book Title: " << book->title 
                 << ", Author: " << book->author 
                 << ", Publisher: " << book->publisher->name 
                 << endl;
        }
    }

    void displayPublishers() {
        for (auto& publisher : publishers) {
            cout << "Publisher: " << publisher.name 
                 << ", Address: " << publisher.address 
                 << endl;
        }
    }

    void displayBooks() {
        for (auto& book : books) {
            cout << "Book Title: " << book.title 
                 << ", Author: " << book.author 
                 << ", Publisher: " << book.publisher->name 
                 << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher("Penguin Random House", "New York");
    system.addPublisher("HarperCollins", "London");
    system.addBook("1984", "George Orwell", "Penguin Random House");
    system.addBook("Brave New World", "Aldous Huxley", "HarperCollins");

    system.displayPublishers();
    system.displayBooks();

    system.updatePublisher("Penguin Random House", "New York, NY");
    system.updateBook("1984", "G. Orwell");
    
    system.searchBooksByTitle("1984");

    system.removeBook("1984");
    system.removePublisher("HarperCollins");

    system.displayPublishers();
    system.displayBooks();

    return 0;
}