#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Publisher {
public:
    int id;
    string name;

    Publisher(int id, string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    string title;
    int publisherId;

    Book(int id, string title, int publisherId) : id(id), title(title), publisherId(publisherId) {}
};

class ManagementSystem {
    vector<Publisher> publishers;
    vector<Book> books;

    Publisher* findPublisher(int id) {
        for (auto& publisher : publishers) {
            if (publisher.id == id) return &publisher;
        }
        return nullptr;
    }

    Book* findBook(int id) {
        for (auto& book : books) {
            if (book.id == id) return &book;
        }
        return nullptr;
    }

public:
    void addPublisher(int id, string name) {
        if (findPublisher(id) == nullptr) {
            publishers.push_back(Publisher(id, name));
        }
    }

    void deletePublisher(int id) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if (it->id == id) {
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(int id, string name) {
        Publisher* publisher = findPublisher(id);
        if (publisher) publisher->name = name;
    }

    void searchPublisher(int id) {
        Publisher* publisher = findPublisher(id);
        if (publisher) {
            cout << "Publisher ID: " << publisher->id << ", Name: " << publisher->name << endl;
        } else {
            cout << "Publisher not found." << endl;
        }
    }

    void displayPublishers() {
        for (auto& publisher : publishers) {
            cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name << endl;
        }
    }

    void addBook(int id, string title, int publisherId) {
        if (findBook(id) == nullptr && findPublisher(publisherId) != nullptr) {
            books.push_back(Book(id, title, publisherId));
        }
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string title, int publisherId) {
        Book* book = findBook(id);
        if (book && findPublisher(publisherId) != nullptr) {
            book->title = title;
            book->publisherId = publisherId;
        }
    }

    void searchBook(int id) {
        Book* book = findBook(id);
        if (book) {
            cout << "Book ID: " << book->id << ", Title: " << book->title << ", Publisher ID: " << book->publisherId << endl;
        } else {
            cout << "Book not found." << endl;
        }
    }

    void displayBooks() {
        for (auto& book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Publisher ID: " << book.publisherId << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "Publisher A");
    system.addPublisher(2, "Publisher B");
    system.addBook(101, "Book One", 1);
    system.addBook(102, "Book Two", 1);
    system.addBook(103, "Book Three", 2);
    system.displayPublishers();
    system.displayBooks();
    system.searchPublisher(1);
    system.searchBook(101);
    system.updatePublisher(1, "Publisher C");
    system.updateBook(101, "Updated Book One", 2);
    system.displayPublishers();
    system.displayBooks();
    system.deletePublisher(2);
    system.deleteBook(103);
    system.displayPublishers();
    system.displayBooks();
    return 0;
}