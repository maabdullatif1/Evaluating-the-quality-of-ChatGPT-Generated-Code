#include <iostream>
#include <vector>
#include <string>

class Book {
private:
    int bookId;
    std::string title;
    std::string author;
public:
    Book(int id, std::string t, std::string a) : bookId(id), title(t), author(a) {}
    int getId() const { return bookId; }
    std::string getTitle() const { return title; }
    std::string getAuthor() const { return author; }
    void updateTitle(std::string newTitle) { title = newTitle; }
    void updateAuthor(std::string newAuthor) { author = newAuthor; }
};

class Publisher {
private:
    int publisherId;
    std::string name;
    std::vector<Book> books;
public:
    Publisher(int id, std::string n) : publisherId(id), name(n) {}
    int getId() const { return publisherId; }
    std::string getName() const { return name; }
    void updateName(std::string newName) { name = newName; }
    void addBook(Book book) { books.push_back(book); }
    void deleteBook(int bookId) {
        books.erase(std::remove_if(books.begin(), books.end(), [bookId](Book& b) { return b.getId() == bookId; }), books.end());
    }
    Book* searchBook(int bookId) {
        for (auto& book : books) {
            if (book.getId() == bookId) return &book;
        }
        return nullptr;
    }
    void displayBooks() {
        for (auto& book : books) {
            std::cout << "ID: " << book.getId() << ", Title: " << book.getTitle() << ", Author: " << book.getAuthor() << "\n";
        }
    }
};

class BookPublisherManagementSystem {
private:
    std::vector<Publisher> publishers;
public:
    void addPublisher(Publisher publisher) { publishers.push_back(publisher); }
    void deletePublisher(int publisherId) {
        publishers.erase(std::remove_if(publishers.begin(), publishers.end(), [publisherId](Publisher& p) { return p.getId() == publisherId; }), publishers.end());
    }
    Publisher* searchPublisher(int publisherId) {
        for (auto& publisher : publishers) {
            if (publisher.getId() == publisherId) return &publisher;
        }
        return nullptr;
    }
    void displayPublishers() {
        for (auto& publisher : publishers) {
            std::cout << "Publisher ID: " << publisher.getId() << ", Name: " << publisher.getName() << "\n";
            publisher.displayBooks();
        }
    }
};

int main() {
    BookPublisherManagementSystem system;
    Publisher pub1(1, "Penguin");
    Publisher pub2(2, "HarperCollins");
    pub1.addBook(Book(101, "1984", "George Orwell"));
    pub1.addBook(Book(102, "Animal Farm", "George Orwell"));
    pub2.addBook(Book(201, "To Kill a Mockingbird", "Harper Lee"));
    system.addPublisher(pub1);
    system.addPublisher(pub2);
    system.displayPublishers();
    return 0;
}