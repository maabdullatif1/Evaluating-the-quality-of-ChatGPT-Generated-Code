#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Publisher {
    int id;
    string name;
    string address;
};

struct Book {
    int id;
    string title;
    string author;
    int publisherId;
};

class ManagementSystem {
private:
    vector<Publisher> publishers;
    vector<Book> books;

    Publisher* findPublisher(int id) {
        for (auto& publisher : publishers)
            if (publisher.id == id)
                return &publisher;
        return nullptr;
    }

    Book* findBook(int id) {
        for (auto& book : books)
            if (book.id == id)
                return &book;
        return nullptr;
    }

public:
    void addPublisher(int id, string name, string address) {
        if (!findPublisher(id))
            publishers.push_back({id, name, address});
    }

    void addBook(int id, string title, string author, int publisherId) {
        if (!findBook(id) && findPublisher(publisherId))
            books.push_back({id, title, author, publisherId});
    }

    void deletePublisher(int id) {
        publishers.erase(remove_if(publishers.begin(), publishers.end(),
                                   [id](Publisher& p) { return p.id == id; }),
                         publishers.end());
    }

    void deleteBook(int id) {
        books.erase(remove_if(books.begin(), books.end(),
                              [id](Book& b) { return b.id == id; }),
                    books.end());
    }

    void updatePublisher(int id, string name, string address) {
        Publisher* p = findPublisher(id);
        if (p) {
            p->name = name;
            p->address = address;
        }
    }

    void updateBook(int id, string title, string author, int publisherId) {
        Book* b = findBook(id);
        if (b && findPublisher(publisherId)) {
            b->title = title;
            b->author = author;
            b->publisherId = publisherId;
        }
    }

    Publisher* searchPublisherByName(string name) {
        for (auto& publisher : publishers)
            if (publisher.name == name)
                return &publisher;
        return nullptr;
    }

    Book* searchBookByTitle(string title) {
        for (auto& book : books)
            if (book.title == title)
                return &book;
        return nullptr;
    }

    void displayPublishers() {
        for (auto& publisher : publishers) {
            cout << "Publisher ID: " << publisher.id << ", Name: " << publisher.name
                 << ", Address: " << publisher.address << endl;
        }
    }

    void displayBooks() {
        for (auto& book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title 
                 << ", Author: " << book.author << ", Publisher ID: " << book.publisherId << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPublisher(1, "Penguin", "123 Penguin Lane");
    system.addPublisher(2, "HarperCollins", "456 Harper Road");
    system.addBook(1, "C++ Programming", "Bjarne Stroustrup", 1);
    system.addBook(2, "Effective C++", "Scott Meyers", 2);
    system.displayPublishers();
    system.displayBooks();
    system.updatePublisher(1, "Penguin Books", "123 New Penguin Lane");
    system.updateBook(1, "The C++ Programming Language", "Bjarne Stroustrup", 1);
    system.displayPublishers();
    system.displayBooks();
    return 0;
}