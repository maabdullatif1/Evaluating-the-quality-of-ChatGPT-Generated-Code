#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Publisher {
public:
    string name;
    string address;

    Publisher(string name, string address) : name(name), address(address) {}
};

class Book {
public:
    string title;
    string author;
    Publisher *publisher;

    Book(string title, string author, Publisher *publisher) : title(title), author(author), publisher(publisher) {}
};

class ManagementSystem {
private:
    vector<Publisher*> publishers;
    vector<Book*> books;

public:
    void addPublisher(string name, string address) {
        publishers.push_back(new Publisher(name, address));
    }

    void deletePublisher(string name) {
        for (auto it = publishers.begin(); it != publishers.end(); ++it) {
            if ((*it)->name == name) {
                delete *it;
                publishers.erase(it);
                break;
            }
        }
    }

    void updatePublisher(string oldName, string newName, string newAddress) {
        for (auto &publisher : publishers) {
            if (publisher->name == oldName) {
                publisher->name = newName;
                publisher->address = newAddress;
                break;
            }
        }
    }

    Publisher* searchPublisher(string name) {
        for (auto &publisher : publishers) {
            if (publisher->name == name) {
                return publisher;
            }
        }
        return nullptr;
    }

    void displayPublishers() {
        for (const auto& publisher : publishers) {
            cout << "Publisher Name: " << publisher->name << ", Address: " << publisher->address << endl;
        }
    }

    void addBook(string title, string author, Publisher* publisher) {
        books.push_back(new Book(title, author, publisher));
    }

    void deleteBook(string title) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if ((*it)->title == title) {
                delete *it;
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(string oldTitle, string newTitle, string newAuthor, Publisher* newPublisher) {
        for (auto &book : books) {
            if (book->title == oldTitle) {
                book->title = newTitle;
                book->author = newAuthor;
                book->publisher = newPublisher;
                break;
            }
        }
    }

    Book* searchBook(string title) {
        for (auto &book : books) {
            if (book->title == title) {
                return book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "Book Title: " << book->title << ", Author: " << book->author 
                 << ", Publisher: " << book->publisher->name << endl;
        }
    }

    ~ManagementSystem() {
        for (auto &publisher : publishers) {
            delete publisher;
        }
        for (auto &book : books) {
            delete book;
        }
    }
};

int main() {
    ManagementSystem system;
    Publisher *pub1 = new Publisher("Penguin", "123 Penguin Lane");
    Publisher *pub2 = new Publisher("HarperCollins", "456 Book Ave");

    system.addPublisher(pub1->name, pub1->address);
    system.addPublisher(pub2->name, pub2->address);

    system.addBook("Book One", "Author One", pub1);
    system.addBook("Book Two", "Author Two", pub2);

    system.displayPublishers();
    system.displayBooks();

    system.updatePublisher("Penguin", "Penguin Books", "789 New Lane");
    system.updateBook("Book One", "New Book One", "New Author One", pub2);

    system.displayPublishers();
    system.displayBooks();

    system.deletePublisher("HarperCollins");
    system.deleteBook("New Book One");

    system.displayPublishers();
    system.displayBooks();

    delete pub1;
    delete pub2;

    return 0;
}