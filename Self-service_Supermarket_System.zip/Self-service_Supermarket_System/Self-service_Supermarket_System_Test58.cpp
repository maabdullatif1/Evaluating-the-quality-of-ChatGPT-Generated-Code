#include <iostream>
#include <string>
using namespace std;

struct Product {
    int id;
    string name;
    double price;
    string location;
    Product* next;
};

class SupermarketSystem {
private:
    Product* head;

public:
    SupermarketSystem() : head(nullptr) {}

    void addProduct(int id, const string& name, double price, const string& location) {
        Product* newProduct = new Product{id, name, price, location, head};
        head = newProduct;
    }

    void deleteProduct(int id) {
        Product* curr = head;
        Product* prev = nullptr;
        while (curr != nullptr && curr->id != id) {
            prev = curr;
            curr = curr->next;
        }
        if (curr == nullptr) return;
        if (prev == nullptr) {
            head = head->next;
        } else {
            prev->next = curr->next;
        }
        delete curr;
    }

    void updateProduct(int id, const string& name, double price, const string& location) {
        Product* curr = head;
        while (curr != nullptr) {
            if (curr->id == id) {
                curr->name = name;
                curr->price = price;
                curr->location = location;
                return;
            }
            curr = curr->next;
        }
    }

    void searchProduct(int id) const {
        Product* curr = head;
        while (curr != nullptr) {
            if (curr->id == id) {
                cout << "Product Found: " << endl;
                cout << "ID: " << curr->id << ", Name: " << curr->name 
                     << ", Price: " << curr->price << ", Location: " << curr->location << endl;
                return;
            }
            curr = curr->next;
        }
        cout << "Product not found" << endl;
    }

    void displayProducts() const {
        Product* curr = head;
        while (curr != nullptr) {
            cout << "ID: " << curr->id << ", Name: " << curr->name 
                 << ", Price: " << curr->price << ", Location: " << curr->location << endl;
            curr = curr->next;
        }
    }

    ~SupermarketSystem() {
        Product* curr = head;
        while (curr != nullptr) {
            Product* next = curr->next;
            delete curr;
            curr = next;
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct(1, "Apple", 0.99, "Aisle 1");
    system.addProduct(2, "Banana", 0.59, "Aisle 1");
    system.addProduct(3, "Milk", 1.29, "Aisle 2");
    
    system.displayProducts();
    
    system.searchProduct(2);
    
    system.updateProduct(2, "Banana", 0.69, "Aisle 1A");
    
    system.searchProduct(2);
    
    system.deleteProduct(3);
    
    system.displayProducts();

    return 0;
}