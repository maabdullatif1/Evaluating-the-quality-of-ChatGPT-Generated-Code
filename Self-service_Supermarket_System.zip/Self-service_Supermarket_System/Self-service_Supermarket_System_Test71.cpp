#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Product {
public:
    int id;
    string name;
    double price;
    string location;
    
    Product(int id, const string &name, double price, const string &location)
        : id(id), name(name), price(price), location(location) {}
};

class Supermarket {
    vector<Product> products;

    int findProductIndexById(int id) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].id == id) return i;
        }
        return -1;
    }

public:
    void addProduct(int id, const string &name, double price, const string &location) {
        products.push_back(Product(id, name, price, location));
    }

    bool deleteProduct(int id) {
        int index = findProductIndexById(id);
        if (index != -1) {
            products.erase(products.begin() + index);
            return true;
        }
        return false;
    }

    bool updateProduct(int id, const string &name, double price, const string &location) {
        int index = findProductIndexById(id);
        if (index != -1) {
            products[index].name = name;
            products[index].price = price;
            products[index].location = location;
            return true;
        }
        return false;
    }

    Product* searchProduct(int id) {
        int index = findProductIndexById(id);
        if (index != -1) {
            return &products[index];
        }
        return nullptr;
    }

    void displayProducts() {
        for (const auto &product : products) {
            cout << "ID: " << product.id << ", Name: " << product.name 
                 << ", Price: $" << product.price << ", Location: " << product.location << endl;
        }
    }
};

int main() {
    Supermarket supermarket;
    int choice, id;
    double price;
    string name, location;

    while (true) {
        cout << "1. Add Product\n2. Delete Product\n3. Update Product\n4. Search Product\n5. Display Products\n6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter ID, Name, Price, Location: ";
                cin >> id >> name >> price >> location;
                supermarket.addProduct(id, name, price, location);
                break;
            case 2:
                cout << "Enter Product ID to delete: ";
                cin >> id;
                if (supermarket.deleteProduct(id)) {
                    cout << "Product deleted successfully.\n";
                } else {
                    cout << "Product not found.\n";
                }
                break;
            case 3:
                cout << "Enter ID, New Name, New Price, New Location: ";
                cin >> id >> name >> price >> location;
                if (supermarket.updateProduct(id, name, price, location)) {
                    cout << "Product updated successfully.\n";
                } else {
                    cout << "Product not found.\n";
                }
                break;
            case 4:
                cout << "Enter Product ID to search: ";
                cin >> id;
                Product* product;
                product = supermarket.searchProduct(id);
                if (product != nullptr) {
                    cout << "Product Found - ID: " << product->id << ", Name: " << product->name 
                         << ", Price: $" << product->price << ", Location: " << product->location << endl;
                } else {
                    cout << "Product not found.\n";
                }
                break;
            case 5:
                supermarket.displayProducts();
                break;
            case 6:
                return 0;
            default:
                cout << "Invalid choice! Please try again.\n";
                break;
        }
    }
    return 0;
}