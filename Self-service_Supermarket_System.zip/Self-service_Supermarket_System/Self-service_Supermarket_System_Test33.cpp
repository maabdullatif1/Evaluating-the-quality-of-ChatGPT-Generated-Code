#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Product {
public:
    int id;
    string name;
    string location;

    Product(int id, string name, string location) : id(id), name(name), location(location) {}
};

class Supermarket {
private:
    vector<Product> products;
    int nextId;

public:
    Supermarket() : nextId(1) {}

    void addProduct(string name, string location) {
        products.push_back(Product(nextId++, name, location));
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return;
            }
        }
    }

    void updateProduct(int id, string name, string location) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.location = location;
                return;
            }
        }
    }

    Product* searchProduct(int id) {
        for (auto& product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    void displayProducts() {
        for (const auto& product : products) {
            cout << "ID: " << product.id << ", Name: " << product.name << ", Location: " << product.location << endl;
        }
    }
};

int main() {
    Supermarket supermarket;
    supermarket.addProduct("Apple", "Aisle 1");
    supermarket.addProduct("Banana", "Aisle 1");
    supermarket.displayProducts();

    supermarket.updateProduct(1, "Green Apple", "Aisle 1");
    supermarket.displayProducts();

    supermarket.deleteProduct(2);
    supermarket.displayProducts();

    Product* product = supermarket.searchProduct(1);
    if (product) {
        cout << "Found product - ID: " << product->id << ", Name: " << product->name << ", Location: " << product->location << endl;
    } else {
        cout << "Product not found" << endl;
    }

    return 0;
}