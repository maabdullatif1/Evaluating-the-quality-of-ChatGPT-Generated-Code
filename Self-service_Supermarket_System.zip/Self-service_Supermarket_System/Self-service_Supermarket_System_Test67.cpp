#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Product {
    int id;
    string name;
    double price;
    int quantity;
    string location;
};

class SupermarketSystem {
private:
    vector<Product> products;
    int nextId = 1;

    Product* findProductById(int id) {
        for (auto& product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

public:
    void addProduct(const string& name, double price, int quantity, const string& location) {
        Product product = {nextId++, name, price, quantity, location};
        products.push_back(product);
    }

    bool deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateProduct(int id, const string& name, double price, int quantity, const string& location) {
        Product* product = findProductById(id);
        if (product != nullptr) {
            product->name = name;
            product->price = price;
            product->quantity = quantity;
            product->location = location;
            return true;
        }
        return false;
    }

    Product* searchProduct(int id) {
        return findProductById(id);
    }

    void displayProducts() const {
        for (const auto& product : products) {
            cout << "ID: " << product.id 
                 << ", Name: " << product.name 
                 << ", Price: " << product.price 
                 << ", Quantity: " << product.quantity 
                 << ", Location: " << product.location << endl;
        }
    }
};

int main() {
    SupermarketSystem system;

    system.addProduct("Apple", 0.5, 100, "Aisle 1");
    system.addProduct("Banana", 0.2, 150, "Aisle 1");

    system.displayProducts();

    system.updateProduct(1, "Green Apple", 0.6, 120, "Aisle 2");

    Product* apple = system.searchProduct(1);
    if (apple) {
        cout << "Found: " << apple->name << endl;
    }

    system.deleteProduct(2);

    system.displayProducts();

    return 0;
}