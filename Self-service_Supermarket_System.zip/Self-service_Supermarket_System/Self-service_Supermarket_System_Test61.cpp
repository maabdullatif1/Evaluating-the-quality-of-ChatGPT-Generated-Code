#include <iostream>
#include <vector>
#include <string>

struct Product {
    int id;
    std::string name;
    int quantity;
    double price;
    std::string location;
};

class Supermarket {
    std::vector<Product> products;
    int nextId;

public:
    Supermarket() : nextId(1) {}

    void addProduct(const std::string& name, int quantity, double price, const std::string& location) {
        Product product = {nextId++, name, quantity, price, location};
        products.push_back(product);
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return;
            }
        }
    }

    void updateProduct(int id, const std::string& name, int quantity, double price, const std::string& location) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.quantity = quantity;
                product.price = price;
                product.location = location;
                return;
            }
        }
    }

    void searchProduct(const std::string& name) {
        for (const auto& product : products) {
            if (product.name == name) {
                std::cout << "Found: [ID: " << product.id 
                          << ", Name: " << product.name 
                          << ", Quantity: " << product.quantity 
                          << ", Price: " << product.price 
                          << ", Location: " << product.location << "]\n";
                return;
            }
        }
        std::cout << "Product not found\n";
    }

    void displayProducts() {
        for (const auto& product : products) {
            std::cout << "Product ID: " << product.id 
                      << ", Name: " << product.name 
                      << ", Quantity: " << product.quantity 
                      << ", Price: " << product.price 
                      << ", Location: " << product.location << "\n";
        }
    }
};

int main() {
    Supermarket market;
    market.addProduct("Apples", 50, 0.99, "A1");
    market.addProduct("Bananas", 30, 0.59, "B2");
    market.displayProducts();
    market.updateProduct(1, "Green Apples", 60, 1.09, "A1");
    market.searchProduct("Bananas");
    market.deleteProduct(2);
    market.displayProducts();
    return 0;
}