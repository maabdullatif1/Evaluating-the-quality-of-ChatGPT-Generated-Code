#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Product {
public:
    int id;
    string name;
    double price;
    string location;

    Product(int id_, const string& name_, double price_, const string& location_)
        : id(id_), name(name_), price(price_), location(location_) {}
};

class SupermarketSystem {
private:
    vector<Product> products;
    int nextId = 1;

public:
    void addProduct(const string& name, double price, const string& location) {
        products.push_back(Product(nextId, name, price, location));
        ++nextId;
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, const string& name, double price, const string& location) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                break;
            }
        }
    }

    Product* searchProduct(int id) {
        for (auto& product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    void displayProducts() {
        for (const auto& product : products) {
            cout << "ID: " << product.id << ", Name: " << product.name
                 << ", Price: $" << product.price << ", Location: " << product.location << endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct("Apple", 0.99, "Aisle 1");
    system.addProduct("Bread", 2.49, "Aisle 2");
    system.displayProducts();
    system.updateProduct(1, "Green Apple", 1.09, "Aisle 1B");
    system.displayProducts();
    Product* p = system.searchProduct(2);
    if (p != nullptr) {
        cout << "Found: ID: " << p->id << ", Name: " << p->name
             << ", Price: $" << p->price << ", Location: " << p->location << endl;
    }
    system.deleteProduct(1);
    system.displayProducts();
    return 0;
}