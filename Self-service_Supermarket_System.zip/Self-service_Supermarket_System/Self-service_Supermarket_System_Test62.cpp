#include <iostream>
#include <vector>
#include <string>

struct Product {
    int id;
    std::string name;
    double price;
    std::string location;
};

class Supermarket {
private:
    std::vector<Product> inventory;
    int generateId() {
        return inventory.empty() ? 1 : inventory.back().id + 1;
    }

public:
    void addProduct(const std::string& name, double price, const std::string& location) {
        Product newProduct = { generateId(), name, price, location };
        inventory.push_back(newProduct);
    }

    bool deleteProduct(int id) {
        for (auto it = inventory.begin(); it != inventory.end(); ++it) {
            if (it->id == id) {
                inventory.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateProduct(int id, const std::string& name, double price, const std::string& location) {
        for (auto &product : inventory) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                return true;
            }
        }
        return false;
    }

    Product* searchProduct(int id) {
        for (auto &product : inventory) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    void displayProducts() {
        if (inventory.empty()) {
            std::cout << "No products available.\n";
            return;
        }
        for (const auto &product : inventory) {
            std::cout << "ID: " << product.id 
                      << " Name: " << product.name 
                      << " Price: " << product.price 
                      << " Location: " << product.location << '\n';
        }
    }
};

int main() {
    Supermarket market;
    market.addProduct("Apple", 0.99, "Aisle 1");
    market.addProduct("Milk", 1.49, "Aisle 5");
    market.displayProducts();

    Product* p = market.searchProduct(1);
    if (p) std::cout << "Found: " << p->name << '\n';

    market.updateProduct(1, "Green Apple", 1.09, "Aisle 1");
    market.displayProducts();

    market.deleteProduct(2);
    market.displayProducts();

    return 0;
}