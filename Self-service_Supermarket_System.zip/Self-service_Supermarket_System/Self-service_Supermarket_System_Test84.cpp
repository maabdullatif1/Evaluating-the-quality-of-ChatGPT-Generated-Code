#include <iostream>
#include <vector>
#include <string>

struct Product {
    int id;
    std::string name;
    std::string location;
    double price;
};

class SupermarketSystem {
private:
    std::vector<Product> products;

    Product* findProductById(int id) {
        for (auto& product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

public:
    void addProduct(int id, const std::string& name, const std::string& location, double price) {
        if (findProductById(id) == nullptr) {
            products.push_back({id, name, location, price});
        } else {
            std::cout << "Product ID already exists.\n";
        }
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return;
            }
        }
        std::cout << "Product not found.\n";
    }

    void updateProduct(int id, const std::string& name, const std::string& location, double price) {
        Product* product = findProductById(id);
        if (product) {
            product->name = name;
            product->location = location;
            product->price = price;
        } else {
            std::cout << "Product not found.\n";
        }
    }

    void searchProduct(int id) {
        Product* product = findProductById(id);
        if (product) {
            std::cout << "ID: " << product->id
                      << " Name: " << product->name
                      << " Location: " << product->location
                      << " Price: $" << product->price << "\n";
        } else {
            std::cout << "Product not found.\n";
        }
    }

    void displayProducts() {
        if (products.empty()) {
            std::cout << "No products available.\n";
        } else {
            for (const auto& product : products) {
                std::cout << "ID: " << product.id
                          << " Name: " << product.name
                          << " Location: " << product.location
                          << " Price: $" << product.price << "\n";
            }
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct(1, "Apple", "Aisle 1", 0.5);
    system.addProduct(2, "Bread", "Aisle 2", 1.2);
    system.displayProducts();
    system.updateProduct(1, "Red Apple", "Aisle 1", 0.6);
    system.searchProduct(1);
    system.deleteProduct(2);
    system.displayProducts();
    return 0;
}