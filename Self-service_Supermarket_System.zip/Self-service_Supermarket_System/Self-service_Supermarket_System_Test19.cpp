#include <iostream>
#include <vector>
#include <string>

struct Product {
    std::string name;
    std::string location;
    double price;
    int quantity;
};

class Supermarket {
    std::vector<Product> products;

public:
    void addProduct(const std::string &name, const std::string &location, double price, int quantity) {
        products.push_back({name, location, price, quantity});
    }

    void deleteProduct(const std::string &name) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->name == name) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(const std::string &name, const std::string &location, double price, int quantity) {
        for (auto &product : products) {
            if (product.name == name) {
                product.location = location;
                product.price = price;
                product.quantity = quantity;
            }
        }
    }

    bool searchProduct(const std::string &name, Product &prod) {
        for (const auto &product : products) {
            if (product.name == name) {
                prod = product;
                return true;
            }
        }
        return false;
    }

    void displayProducts() {
        for (const auto &product : products) {
            std::cout << "Name: " << product.name 
                      << ", Location: " << product.location 
                      << ", Price: " << product.price 
                      << ", Quantity: " << product.quantity << std::endl;
        }
    }
};

int main() {
    Supermarket market;
    
    market.addProduct("Apples", "Aisle 1", 0.99, 100);
    market.addProduct("Bananas", "Aisle 2", 0.49, 150);
    market.displayProducts();
    
    Product foundProduct;
    if (market.searchProduct("Bananas", foundProduct)) {
        std::cout << "Found - Name: " << foundProduct.name 
                  << ", Location: " << foundProduct.location 
                  << ", Price: " << foundProduct.price 
                  << ", Quantity: " << foundProduct.quantity << std::endl;
    }

    market.updateProduct("Apples", "Aisle 1", 1.49, 80);
    market.deleteProduct("Bananas");
    market.displayProducts();

    return 0;
}