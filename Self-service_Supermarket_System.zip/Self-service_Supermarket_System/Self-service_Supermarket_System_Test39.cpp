#include <iostream>
#include <string>

struct Product {
    int id;
    std::string name;
    float price;
    int quantity;
    std::string location;
    Product* next;
};

class Supermarket {
private:
    Product* head;

public:
    Supermarket() : head(nullptr) {}

    void addProduct(int id, const std::string& name, float price, int quantity, const std::string& location) {
        Product* newProduct = new Product{id, name, price, quantity, location, head};
        head = newProduct;
    }

    void deleteProduct(int id) {
        Product* temp = head;
        Product* prev = nullptr;
        while (temp != nullptr && temp->id != id) {
            prev = temp;
            temp = temp->next;
        }
        if (temp == nullptr) return;
        if (prev != nullptr) {
            prev->next = temp->next;
        } else {
            head = temp->next;
        }
        delete temp;
    }

    void updateProduct(int id, const std::string& name, float price, int quantity, const std::string& location) {
        Product* temp = head;
        while (temp != nullptr) {
            if (temp->id == id) {
                temp->name = name;
                temp->price = price;
                temp->quantity = quantity;
                temp->location = location;
                return;
            }
            temp = temp->next;
        }
    }

    Product* searchProduct(int id) {
        Product* temp = head;
        while (temp != nullptr) {
            if (temp->id == id) {
                return temp;
            }
            temp = temp->next;
        }
        return nullptr;
    }

    void displayProducts() {
        Product* temp = head;
        while (temp != nullptr) {
            std::cout << "ID: " << temp->id << ", Name: " << temp->name << ", Price: " << temp->price 
                      << ", Quantity: " << temp->quantity << ", Location: " << temp->location << std::endl;
            temp = temp->next;
        }
    }
};

int main() {
    Supermarket supermarket;
    supermarket.addProduct(1, "Milk", 1.99, 50, "Aisle 1");
    supermarket.addProduct(2, "Bread", 2.50, 30, "Aisle 2");
    
    std::cout << "Display all products:" << std::endl;
    supermarket.displayProducts();
    
    std::cout << "\nUpdate product ID 1:" << std::endl;
    supermarket.updateProduct(1, "Organic Milk", 2.50, 40, "Aisle 1");
    supermarket.displayProducts();
    
    std::cout << "\nDelete product ID 2:" << std::endl;
    supermarket.deleteProduct(2);
    supermarket.displayProducts();
    
    return 0;
}