#include <iostream>
#include <string>

using namespace std;

struct Product {
    int id;
    string name;
    float price;
    string location;
};

class Supermarket {
private:
    Product products[100];
    int productCount;

public:
    Supermarket() : productCount(0) {}

    void addProduct(int id, const string& name, float price, const string& location) {
        products[productCount].id = id;
        products[productCount].name = name;
        products[productCount].price = price;
        products[productCount].location = location;
        productCount++;
    }

    void deleteProduct(int id) {
        int index = -1;
        for (int i = 0; i < productCount; i++) {
            if (products[i].id == id) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            for (int i = index; i < productCount - 1; i++) {
                products[i] = products[i + 1];
            }
            productCount--;
        }
    }

    void updateProduct(int id, const string& name, float price, const string& location) {
        for (int i = 0; i < productCount; i++) {
            if (products[i].id == id) {
                products[i].name = name;
                products[i].price = price;
                products[i].location = location;
                break;
            }
        }
    }

    void searchProduct(int id) const {
        for (int i = 0; i < productCount; i++) {
            if (products[i].id == id) {
                cout << "ID: " << products[i].id << ", Name: " << products[i].name
                     << ", Price: " << products[i].price << ", Location: " << products[i].location << endl;
                return;
            }
        }
        cout << "Product not found." << endl;
    }

    void displayProducts() const {
        for (int i = 0; i < productCount; i++) {
            cout << "ID: " << products[i].id << ", Name: " << products[i].name
                 << ", Price: " << products[i].price << ", Location: " << products[i].location << endl;
        }
    }
};

int main() {
    Supermarket sm;
    sm.addProduct(1, "Apple", 0.5, "Aisle 1");
    sm.addProduct(2, "Banana", 0.3, "Aisle 1");
    sm.addProduct(3, "Cereal", 2.5, "Aisle 3");
    
    sm.displayProducts();
    
    sm.updateProduct(2, "Banana", 0.4, "Aisle 1");
    
    sm.displayProducts();

    sm.deleteProduct(1);

    sm.displayProducts();

    sm.searchProduct(3);

    sm.searchProduct(1);

    return 0;
}