#include <iostream>
#include <vector>
#include <string>

struct Product {
    int id;
    std::string name;
    double price;
    std::string location;
};

class Supermarket {
    std::vector<Product> products;
    
    public:
    void addProduct(int id, const std::string& name, double price, const std::string& location) {
        products.push_back({id, name, price, location});
    }
    
    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }
    
    void updateProduct(int id, const std::string& name, double price, const std::string& location) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                break;
            }
        }
    }
    
    void searchProduct(int id) {
        for (auto& product : products) {
            if (product.id == id) {
                std::cout << "Product ID: " << product.id << "\n"
                          << "Name: " << product.name << "\n"
                          << "Price: " << product.price << "\n"
                          << "Location: " << product.location << "\n";
                return;
            }
        }
        std::cout << "Product not found.\n";
    }
    
    void displayProducts() {
        for (auto& product : products) {
            std::cout << "Product ID: " << product.id << "\n"
                      << "Name: " << product.name << "\n"
                      << "Price: " << product.price << "\n"
                      << "Location: " << product.location << "\n\n";
        }
    }
};

int main() {
    Supermarket supermarket;
    supermarket.addProduct(1, "Apple", 0.99, "Aisle 1");
    supermarket.addProduct(2, "Milk", 1.49, "Aisle 2");
    supermarket.displayProducts();
    
    supermarket.updateProduct(2, "Milk", 1.59, "Aisle 3");
    supermarket.searchProduct(2);
    
    supermarket.deleteProduct(1);
    supermarket.displayProducts();
    
    return 0;
}