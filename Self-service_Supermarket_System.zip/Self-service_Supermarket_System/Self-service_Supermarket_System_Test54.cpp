#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    std::string name;
    int id;
    double price;
    std::string location;

    Product(int pid, std::string pname, double pprice, std::string plocation)
        : id(pid), name(pname), price(pprice), location(plocation) {}
};

class Supermarket {
private:
    std::vector<Product> products;
public:
    void addProduct(int id, std::string name, double price, std::string location) {
        products.emplace_back(id, name, price, location);
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, std::string name, double price, std::string location) {
        for (auto &product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                break;
            }
        }
    }

    void searchProduct(int id) {
        for (const auto &product : products) {
            if (product.id == id) {
                std::cout << "Product Found: " << product.name << ", Price: "
                          << product.price << ", Location: " << product.location << "\n";
                return;
            }
        }
        std::cout << "Product not found.\n";
    }

    void displayAllProducts() {
        for (const auto &product : products) {
            std::cout << "ID: " << product.id << ", Name: " << product.name
                      << ", Price: " << product.price << ", Location: " << product.location << "\n";
        }
    }
};

int main() {
    Supermarket market;
    market.addProduct(1, "Apple", 0.99, "Aisle 1");
    market.addProduct(2, "Banana", 0.59, "Aisle 1");
    market.displayAllProducts();
    market.updateProduct(2, "Banana", 0.79, "Aisle 2");
    market.searchProduct(2);
    market.deleteProduct(1);
    market.displayAllProducts();
    
    return 0;
}