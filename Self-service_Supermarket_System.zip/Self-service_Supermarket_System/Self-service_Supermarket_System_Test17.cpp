#include <iostream>
#include <string>
using namespace std;

struct Product {
    int id;
    string name;
    double price;
    string location;
};

class Supermarket {
    Product products[100];
    int count;

public:
    Supermarket() : count(0) {}

    void addProduct(int id, const string &name, double price, const string &location) {
        products[count++] = {id, name, price, location};
    }

    void deleteProduct(int id) {
        for (int i = 0; i < count; i++) {
            if (products[i].id == id) {
                products[i] = products[count - 1];
                count--;
                break;
            }
        }
    }

    void updateProduct(int id, const string &name, double price, const string &location) {
        for (int i = 0; i < count; i++) {
            if (products[i].id == id) {
                products[i] = {id, name, price, location};
                break;
            }
        }
    }

    void searchProduct(int id) {
        for (int i = 0; i < count; i++) {
            if (products[i].id == id) {
                displayProduct(products[i]);
                return;
            }
        }
        cout << "Product not found.\n";
    }

    void displayProducts() {
        for (int i = 0; i < count; i++) {
            displayProduct(products[i]);
        }
    }

private:
    void displayProduct(const Product &product) {
        cout << "ID: " << product.id << ", Name: " << product.name
             << ", Price: $" << product.price << ", Location: " << product.location << endl;
    }
};

int main() {
    Supermarket supermarket;
    supermarket.addProduct(1, "Apple", 0.99, "Aisle 1");
    supermarket.addProduct(2, "Bread", 2.49, "Aisle 2");
    supermarket.displayProducts();
    supermarket.updateProduct(1, "Apple", 0.89, "Aisle 1");
    supermarket.searchProduct(1);
    supermarket.deleteProduct(2);
    supermarket.displayProducts();
    return 0;
}