#include <iostream>
#include <map>

class Product {
public:
    std::string name;
    double price;
    std::string location;

    Product(std::string name, double price, std::string location)
        : name(name), price(price), location(location) {}
};

class SupermarketSystem {
private:
    std::map<int, Product> products;
    int nextProductId = 1;

public:
    void addProduct(const std::string &name, double price, const std::string &location) {
        products[nextProductId] = Product(name, price, location);
        std::cout << "Product added with ID: " << nextProductId << std::endl;
        nextProductId++;
    }

    void deleteProduct(int productId) {
        if (products.erase(productId)) {
            std::cout << "Product deleted successfully." << std::endl;
        } else {
            std::cout << "Product ID not found." << std::endl;
        }
    }

    void updateProduct(int productId, const std::string &name, double price, const std::string &location) {
        auto it = products.find(productId);
        if (it != products.end()) {
            it->second = Product(name, price, location);
            std::cout << "Product updated successfully." << std::endl;
        } else {
            std::cout << "Product ID not found." << std::endl;
        }
    }

    void searchProductByName(const std::string &name) {
        for (const auto &entry : products) {
            if (entry.second.name == name) {
                std::cout << "Product ID: " << entry.first
                          << " | Name: " << entry.second.name
                          << " | Price: " << entry.second.price
                          << " | Location: " << entry.second.location << std::endl;
            }
        }
    }

    void displayAllProducts() {
        for (const auto &entry : products) {
            std::cout << "Product ID: " << entry.first
                      << " | Name: " << entry.second.name
                      << " | Price: " << entry.second.price
                      << " | Location: " << entry.second.location << std::endl;
        }
    }
};

int main() {
    SupermarketSystem system;

    system.addProduct("Apple", 1.20, "Aisle 1");
    system.addProduct("Bread", 0.99, "Aisle 2");
    system.addProduct("Milk", 1.50, "Aisle 3");

    system.displayAllProducts();
    system.updateProduct(1, "Green Apple", 1.30, "Aisle 1");
    system.searchProductByName("Bread");
    system.deleteProduct(2);
    system.displayAllProducts();

    return 0;
}