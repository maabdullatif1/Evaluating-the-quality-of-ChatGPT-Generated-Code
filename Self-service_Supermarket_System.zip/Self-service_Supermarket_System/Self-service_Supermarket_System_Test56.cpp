#include <iostream>
#include <string>
#include <vector>

struct Product {
    std::string name;
    std::string location;
    double price;
    int quantity;
};

class Supermarket {
private:
    std::vector<Product> inventory;

    int searchProductIndex(const std::string& name) {
        for (size_t i = 0; i < inventory.size(); ++i) {
            if (inventory[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addProduct(const Product& product) {
        if (searchProductIndex(product.name) == -1) {
            inventory.push_back(product);
        } else {
            std::cout << "Product already exists." << std::endl;
        }
    }

    void deleteProduct(const std::string& name) {
        int index = searchProductIndex(name);
        if (index != -1) {
            inventory.erase(inventory.begin() + index);
        } else {
            std::cout << "Product not found." << std::endl;
        }
    }

    void updateProduct(const std::string& name, const Product& updatedProduct) {
        int index = searchProductIndex(name);
        if (index != -1) {
            inventory[index] = updatedProduct;
        } else {
            std::cout << "Product not found." << std::endl;
        }
    }

    void searchProduct(const std::string& name) {
        int index = searchProductIndex(name);
        if (index != -1) {
            std::cout << "Name: " << inventory[index].name 
                      << ", Location: " << inventory[index].location 
                      << ", Price: " << inventory[index].price 
                      << ", Quantity: " << inventory[index].quantity << std::endl;
        } else {
            std::cout << "Product not found." << std::endl;
        }
    }

    void displayProducts() {
        if (inventory.empty()) {
            std::cout << "No products available." << std::endl;
            return;
        }
        for (const auto& product : inventory) {
            std::cout << "Name: " << product.name 
                      << ", Location: " << product.location 
                      << ", Price: " << product.price 
                      << ", Quantity: " << product.quantity << std::endl;
        }
    }
};

int main() {
    Supermarket supermarket;
    char choice;
    do {
        std::cout << "1. Add Product\n2. Delete Product\n3. Update Product\n4. Search Product\n5. Display Products\n6. Exit" << std::endl;
        std::cin >> choice;
        if (choice == '1') {
            Product product;
            std::cout << "Enter name, location, price, and quantity: ";
            std::cin >> product.name >> product.location >> product.price >> product.quantity;
            supermarket.addProduct(product);
        } else if (choice == '2') {
            std::string name;
            std::cout << "Enter name of the product to delete: ";
            std::cin >> name;
            supermarket.deleteProduct(name);
        } else if (choice == '3') {
            std::string name;
            Product updatedProduct;
            std::cout << "Enter current name of the product to update: ";
            std::cin >> name;
            std::cout << "Enter new name, location, price, and quantity: ";
            std::cin >> updatedProduct.name >> updatedProduct.location >> updatedProduct.price >> updatedProduct.quantity;
            supermarket.updateProduct(name, updatedProduct);
        } else if (choice == '4') {
            std::string name;
            std::cout << "Enter name of the product to search: ";
            std::cin >> name;
            supermarket.searchProduct(name);
        } else if (choice == '5') {
            supermarket.displayProducts();
        }
    } while (choice != '6');
    return 0;
}