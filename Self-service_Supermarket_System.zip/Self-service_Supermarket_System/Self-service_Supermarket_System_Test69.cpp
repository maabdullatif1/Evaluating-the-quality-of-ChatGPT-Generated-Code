#include <iostream>
#include <string>

struct Product {
    int id;
    std::string name;
    double price;
    std::string location;
};

class SupermarketSystem {
    Product products[100];
    int productCount;

public:
    SupermarketSystem() : productCount(0) {}

    void addProduct(int id, std::string name, double price, std::string location) {
        products[productCount++] = {id, name, price, location};
    }

    void deleteProduct(int id) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                for (int j = i; j < productCount - 1; ++j) {
                    products[j] = products[j + 1];
                }
                productCount--;
                break;
            }
        }
    }

    void updateProduct(int id, std::string name, double price, std::string location) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                products[i].name = name;
                products[i].price = price;
                products[i].location = location;
                break;
            }
        }
    }

    void searchProduct(int id) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                std::cout << "Product ID: " << products[i].id << "\n"
                          << "Name: " << products[i].name << "\n"
                          << "Price: " << products[i].price << "\n"
                          << "Location: " << products[i].location << "\n";
                return;
            }
        }
        std::cout << "Product not found.\n";
    }

    void displayProducts() {
        if (productCount == 0) {
            std::cout << "No products available.\n";
            return;
        }
        for (int i = 0; i < productCount; ++i) {
            std::cout << "Product ID: " << products[i].id << "\n"
                      << "Name: " << products[i].name << "\n"
                      << "Price: " << products[i].price << "\n"
                      << "Location: " << products[i].location << "\n\n";
        }
    }
};

int main() {
    SupermarketSystem sms;
    sms.addProduct(1, "Apple", 0.99, "Aisle 1");
    sms.addProduct(2, "Bread", 1.99, "Aisle 2");
    sms.displayProducts();
    sms.searchProduct(1);
    sms.updateProduct(1, "Green Apple", 1.09, "Aisle 1");
    sms.searchProduct(1);
    sms.deleteProduct(2);
    sms.displayProducts();

    return 0;
}