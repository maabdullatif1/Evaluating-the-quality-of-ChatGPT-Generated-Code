#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    int id;
    std::string name;
    double price;
    int locationId;

    Product(int id, std::string name, double price, int locationId)
        : id(id), name(name), price(price), locationId(locationId) {}
};

class Location {
public:
    int id;
    std::string name;

    Location(int id, std::string name) : id(id), name(name) {}
};

class SupermarketSystem {
private:
    std::vector<Product> products;
    std::vector<Location> locations;

    Product* findProductById(int id) {
        for (auto& product : products)
            if (product.id == id)
                return &product;
        return nullptr;
    }

    Location* findLocationById(int id) {
        for (auto& location : locations)
            if (location.id == id)
                return &location;
        return nullptr;
    }

public:
    void addProduct(int id, std::string name, double price, int locationId) {
        if (!findLocationById(locationId)) {
            std::cout << "Location not found\n";
            return;
        }
        if (findProductById(id)) {
            std::cout << "Product already exists\n";
            return;
        }
        products.push_back(Product(id, name, price, locationId));
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return;
            }
        }
        std::cout << "Product not found\n";
    }

    void updateProduct(int id, std::string name, double price, int locationId) {
        Product* product = findProductById(id);
        if (!product) {
            std::cout << "Product not found\n";
            return;
        }
        if (!findLocationById(locationId)) {
            std::cout << "Location not found\n";
            return;
        }
        product->name = name;
        product->price = price;
        product->locationId = locationId;
    }

    void searchProduct(int id) {
        Product* product = findProductById(id);
        if (!product) {
            std::cout << "Product not found\n";
            return;
        }
        std::cout << "Product ID: " << product->id << " Name: " << product->name
                  << " Price: " << product->price << " Location ID: " << product->locationId << "\n";
    }

    void displayProducts() {
        for (const auto& product : products)
            std::cout << "ID: " << product.id << " Name: " << product.name << " Price: " << product.price
                      << " Location ID: " << product.locationId << "\n";
    }

    void addLocation(int id, std::string name) {
        if (findLocationById(id)) {
            std::cout << "Location already exists\n";
            return;
        }
        locations.push_back(Location(id, name));
    }

    void deleteLocation(int id) {
        for (auto it = locations.begin(); it != locations.end(); ++it) {
            if (it->id == id) {
                locations.erase(it);
                return;
            }
        }
        std::cout << "Location not found\n";
    }

    void updateLocation(int id, std::string name) {
        Location* location = findLocationById(id);
        if (!location) {
            std::cout << "Location not found\n";
            return;
        }
        location->name = name;
    }

    void searchLocation(int id) {
        Location* location = findLocationById(id);
        if (!location) {
            std::cout << "Location not found\n";
            return;
        }
        std::cout << "Location ID: " << location->id << " Name: " << location->name << "\n";
    }

    void displayLocations() {
        for (const auto& location : locations)
            std::cout << "ID: " << location.id << " Name: " << location.name << "\n";
    }
};

int main() {
    SupermarketSystem system;
    system.addLocation(1, "Aisle 1");
    system.addProduct(101, "Apple", 0.99, 1);
    system.displayProducts();
    system.displayLocations();
    system.updateProduct(101, "Red Apple", 1.29, 1);
    system.searchProduct(101);
    system.deleteProduct(101);
    system.deleteLocation(1);
    return 0;
}