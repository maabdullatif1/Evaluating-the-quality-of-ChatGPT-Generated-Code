#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    std::string name;
    double price;
    std::string location;
    
    Product(std::string n, double p, std::string l) : name(n), price(p), location(l) {}
};

class Supermarket {
    std::vector<Product> products;
    
    int findProductIndexByName(const std::string& name) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addProduct(const std::string& name, double price, const std::string& location) {
        products.emplace_back(name, price, location);
    }

    bool deleteProduct(const std::string& name) {
        int index = findProductIndexByName(name);
        if (index != -1) {
            products.erase(products.begin() + index);
            return true;
        }
        return false;
    }

    bool updateProduct(const std::string& name, double price, const std::string& location) {
        int index = findProductIndexByName(name);
        if (index != -1) {
            products[index].price = price;
            products[index].location = location;
            return true;
        }
        return false;
    }

    void searchProduct(const std::string& name) {
        int index = findProductIndexByName(name);
        if (index != -1) {
            std::cout << "Product Found: " << products[index].name << ", Price: " << products[index].price 
                      << ", Location: " << products[index].location << "\n";
        } else {
            std::cout << "Product not found\n";
        }
    }

    void displayProducts() {
        for (const auto& product : products) {
            std::cout << "Product: " << product.name << ", Price: " << product.price 
                      << ", Location: " << product.location << "\n";
        }
    }
};

int main() {
    Supermarket supermarket;
    supermarket.addProduct("Apple", 0.99, "Aisle 1");
    supermarket.addProduct("Banana", 0.59, "Aisle 1");
    supermarket.addProduct("Milk", 1.49, "Aisle 5");
    
    std::cout << "Displaying All Products:\n";
    supermarket.displayProducts();
    
    std::cout << "\nSearching for Banana:\n";
    supermarket.searchProduct("Banana");

    std::cout << "\nUpdating Banana Price and Location:\n";
    if (supermarket.updateProduct("Banana", 0.69, "Aisle 2")) {
        std::cout << "Banana updated successfully\n";
    } else {
        std::cout << "Banana update failed\n";
    }
    
    std::cout << "\nDeleting Apple:\n";
    if (supermarket.deleteProduct("Apple")) {
        std::cout << "Apple deleted successfully\n";
    } else {
        std::cout << "Apple deletion failed\n";
    }
    
    std::cout << "\nDisplaying All Products:\n";
    supermarket.displayProducts();

    return 0;
}