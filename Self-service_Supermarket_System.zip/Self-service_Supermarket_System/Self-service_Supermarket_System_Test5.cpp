#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Product {
public:
    int id;
    string name;
    string location;
    double price;

    Product(int id, string name, string location, double price) 
        : id(id), name(name), location(location), price(price) {}
};

class Supermarket {
private:
    vector<Product> inventory;
    int getNextId() {
        return inventory.empty() ? 1 : inventory.back().id + 1;
    }

public:
    void addProduct(string name, string location, double price) {
        int id = getNextId();
        inventory.push_back(Product(id, name, location, price));
        cout << "Product added: " << name << endl;
    }

    void deleteProduct(int id) {
        for (auto it = inventory.begin(); it != inventory.end(); ++it) {
            if (it->id == id) {
                cout << "Product deleted: " << it->name << endl;
                inventory.erase(it);
                return;
            }
        }
        cout << "Product not found.\n";
    }

    void updateProduct(int id, string name, string location, double price) {
        for (auto& prod : inventory) {
            if (prod.id == id) {
                prod.name = name;
                prod.location = location;
                prod.price = price;
                cout << "Product updated: " << name << endl;
                return;
            }
        }
        cout << "Product not found.\n";
    }

    void searchProduct(string name) {
        bool found = false;
        for (const auto& prod : inventory) {
            if (prod.name.find(name) != string::npos) {
                cout << "ID: " << prod.id << ", Name: " << prod.name 
                     << ", Location: " << prod.location << ", Price: " << prod.price << endl;
                found = true;
            }
        }
        if (!found) {
            cout << "No products found with name: " << name << endl;
        }
    }

    void displayProducts() {
        if (inventory.empty()) {
            cout << "No products in inventory.\n";
            return;
        }
        for (const auto& prod : inventory) {
            cout << "ID: " << prod.id << ", Name: " << prod.name 
                 << ", Location: " << prod.location << ", Price: " << prod.price << endl;
        }
    }
};

int main() {
    Supermarket supermarket;
    supermarket.addProduct("Apple", "Aisle 1", 0.5);
    supermarket.addProduct("Banana", "Aisle 1", 0.3);
    supermarket.displayProducts();
    supermarket.searchProduct("Apple");
    supermarket.updateProduct(1, "Green Apple", "Aisle 1", 0.55);
    supermarket.displayProducts();
    supermarket.deleteProduct(1);
    supermarket.displayProducts();
    return 0;
}