#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Product {
    int id;
    string name;
    double price;
    int quantity;
    string location;
};

class SupermarketSystem {
    vector<Product> products;
    int nextId;

public:
    SupermarketSystem() : nextId(1) {}

    void addProduct(string name, double price, int quantity, string location) {
        Product p = {nextId++, name, price, quantity, location};
        products.push_back(p);
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, string name, double price, int quantity, string location) {
        for (auto &product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.quantity = quantity;
                product.location = location;
                break;
            }
        }
    }

    Product* searchProduct(int id) {
        for (auto &product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    void displayProducts() {
        for (const auto &product : products) {
            cout << "ID: " << product.id << ", Name: " << product.name << ", Price: $" << product.price
                 << ", Quantity: " << product.quantity << ", Location: " << product.location << endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct("Milk", 1.99, 50, "Aisle 1");
    system.addProduct("Bread", 2.49, 30, "Aisle 2");
    system.displayProducts();

    system.updateProduct(1, "Milk", 1.89, 60, "Aisle 1");
    system.displayProducts();

    Product* p = system.searchProduct(1);
    if (p) {
        cout << "Found Product: " << p->name << endl;
    }

    system.deleteProduct(1);
    system.displayProducts();

    return 0;
}