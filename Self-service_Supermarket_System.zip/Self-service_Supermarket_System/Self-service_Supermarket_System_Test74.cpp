#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Product {
    int id;
    string name;
    double price;
    string location;
};

class Supermarket {
private:
    vector<Product> products;
    int generateId() {
        return products.empty() ? 1 : products.back().id + 1;
    }
public:
    void addProduct(const string& name, double price, const string& location) {
        Product newProduct;
        newProduct.id = generateId();
        newProduct.name = name;
        newProduct.price = price;
        newProduct.location = location;
        products.push_back(newProduct);
    }
    
    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, const string& newName, double newPrice, const string& newLocation) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = newName;
                product.price = newPrice;
                product.location = newLocation;
                break;
            }
        }
    }

    void searchProduct(const string& name) {
        for (const auto& product : products) {
            if (product.name == name) {
                cout << "Product Found: ID " << product.id
                     << ", Name: " << product.name 
                     << ", Price: $" << product.price 
                     << ", Location: " << product.location 
                     << endl;
                return;
            }
        }
        cout << "Product Not Found" << endl;
    }

    void displayProducts() {
        for (const auto& product : products) {
            cout << "ID: " << product.id 
                 << ", Name: " << product.name 
                 << ", Price: $" << product.price 
                 << ", Location: " << product.location 
                 << endl;
        }
    }
};

int main() {
    Supermarket sm;
    sm.addProduct("Apples", 1.99, "Aisle 1");
    sm.addProduct("Bananas", 0.99, "Aisle 1");
    sm.searchProduct("Apples");
    sm.updateProduct(1, "Organic Apples", 2.49, "Aisle 2");
    sm.displayProducts();
    sm.deleteProduct(2);
    sm.displayProducts();
    
    return 0;
}