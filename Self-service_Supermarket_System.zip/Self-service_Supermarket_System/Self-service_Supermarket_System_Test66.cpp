#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    int id;
    std::string name;
    double price;
    
    Product(int id, std::string name, double price)
        : id(id), name(name), price(price) {}
};

class Location {
public:
    int id;
    std::string description;
    
    Location(int id, std::string description)
        : id(id), description(description) {}
};

class SupermarketSystem {
private:
    std::vector<Product> products;
    std::vector<Location> locations;

public:
    void addProduct(int id, std::string name, double price) {
        products.push_back(Product(id, name, price));
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return;
            }
        }
    }

    void updateProduct(int id, std::string name, double price) {
        for (auto &product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                return;
            }
        }
    }

    void searchProduct(int id) {
        for (const auto &product : products) {
            if (product.id == id) {
                std::cout << "Product ID: " << product.id 
                          << ", Name: " << product.name 
                          << ", Price: " << product.price << std::endl;
                return;
            }
        }
        std::cout << "Product not found." << std::endl;
    }

    void displayProducts() {
        for (const auto &product : products) {
            std::cout << "Product ID: " << product.id 
                      << ", Name: " << product.name 
                      << ", Price: " << product.price << std::endl;
        }
    }

    void addLocation(int id, std::string description) {
        locations.push_back(Location(id, description));
    }

    void deleteLocation(int id) {
        for (auto it = locations.begin(); it != locations.end(); ++it) {
            if (it->id == id) {
                locations.erase(it);
                return;
            }
        }
    }

    void updateLocation(int id, std::string description) {
        for (auto &location : locations) {
            if (location.id == id) {
                location.description = description;
                return;
            }
        }
    }

    void searchLocation(int id) {
        for (const auto &location : locations) {
            if (location.id == id) {
                std::cout << "Location ID: " << location.id 
                          << ", Description: " << location.description << std::endl;
                return;
            }
        }
        std::cout << "Location not found." << std::endl;
    }

    void displayLocations() {
        for (const auto &location : locations) {
            std::cout << "Location ID: " << location.id 
                      << ", Description: " << location.description << std::endl;
        }
    }
};

int main() {
    SupermarketSystem sms;
    sms.addProduct(1, "Apple", 0.99);
    sms.addProduct(2, "Banana", 0.59);
    sms.displayProducts();
    sms.searchProduct(1);
    sms.updateProduct(1, "Green Apple", 1.29);
    sms.searchProduct(1);
    sms.deleteProduct(2);
    sms.displayProducts();
    sms.addLocation(100, "Aisle 1");
    sms.addLocation(200, "Aisle 2");
    sms.displayLocations();
    sms.searchLocation(100);
    sms.updateLocation(100, "Fresh Produce Aisle");
    sms.searchLocation(100);
    sms.deleteLocation(200);
    sms.displayLocations();

    return 0;
}