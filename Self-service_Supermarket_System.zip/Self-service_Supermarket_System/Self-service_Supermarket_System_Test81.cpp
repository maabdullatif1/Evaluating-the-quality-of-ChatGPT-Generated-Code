#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Product {
    int id;
    string name;
    double price;
    string location;
};

class SupermarketSystem {
private:
    vector<Product> products;
    int nextId;

    Product* findProductById(int id) {
        for(auto &product : products) {
            if(product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

public:
    SupermarketSystem() : nextId(1) {}

    void addProduct(const string& name, double price, const string& location) {
        Product product;
        product.id = nextId++;
        product.name = name;
        product.price = price;
        product.location = location;
        products.push_back(product);
    }

    void deleteProduct(int id) {
        for(auto it = products.begin(); it != products.end(); ++it) {
            if(it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, const string& name, double price, const string& location) {
        Product* product = findProductById(id);
        if(product != nullptr) {
            product->name = name;
            product->price = price;
            product->location = location;
        }
    }

    Product* searchProduct(int id) {
        return findProductById(id);
    }

    void displayProducts() {
        for(const auto &product : products) {
            cout << "ID: " << product.id << ", Name: " << product.name
                 << ", Price: " << product.price << ", Location: "
                 << product.location << endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    
    system.addProduct("Apple", 0.99, "Aisle 3");
    system.addProduct("Milk", 1.49, "Refrigerator Section");
    system.displayProducts();

    system.updateProduct(1, "Apple", 0.89, "Aisle 3");
    system.deleteProduct(2);
    
    Product* product = system.searchProduct(1);
    if(product) {
        cout << "Found Product: " << product->name << endl;
    }

    return 0;
}