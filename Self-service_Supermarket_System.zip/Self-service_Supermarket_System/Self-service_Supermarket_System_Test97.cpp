#include <iostream>
#include <string>
using namespace std;

struct Product {
    int id;
    string name;
    double price;
    string location;
};

class SupermarketSystem {
private:
    Product products[100];
    int productCount;

public:
    SupermarketSystem() : productCount(0) {}

    void addProduct(int id, const string& name, double price, const string& location) {
        products[productCount++] = { id, name, price, location };
    }

    void deleteProduct(int id) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                for (int j = i; j < productCount - 1; ++j) {
                    products[j] = products[j + 1];
                }
                productCount--;
                break;
            }
        }
    }

    void updateProduct(int id, const string& name, double price, const string& location) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                products[i] = { id, name, price, location };
                break;
            }
        }
    }

    Product* searchProduct(int id) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                return &products[i];
            }
        }
        return nullptr;
    }

    void displayProducts() {
        for (int i = 0; i < productCount; ++i) {
            cout << "ID: " << products[i].id 
                 << ", Name: " << products[i].name 
                 << ", Price: $" << products[i].price 
                 << ", Location: " << products[i].location << endl;
        }
    }
};

int main() {
    SupermarketSystem sms;
    sms.addProduct(1, "Apple", 0.5, "Aisle 1");
    sms.addProduct(2, "Bread", 1.2, "Aisle 2");
    
    sms.displayProducts();
    
    Product* p = sms.searchProduct(1);
    if (p) {
        cout << "Found Product - ID: " << p->id << ", Name: " << p->name << endl;
    }
    
    sms.updateProduct(1, "Green Apple", 0.6, "Aisle 1");
    sms.displayProducts();
    
    sms.deleteProduct(2);
    sms.displayProducts();

    return 0;
}