#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Product {
    int id;
    string name;
    double price;
    string location;
};

class SupermarketSystem {
    vector<Product> products;
    int nextId = 1;
    
public:
    void addProduct(const string& name, double price, const string& location) {
        products.push_back({nextId++, name, price, location});
    }
    
    bool deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return true;
            }
        }
        return false;
    }
    
    bool updateProduct(int id, const string& name, double price, const string& location) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                return true;
            }
        }
        return false;
    }
    
    Product* searchProduct(int id) {
        for (auto& product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }
    
    void displayProducts() {
        for (const auto& product : products) {
            cout << "ID: " << product.id << ", Name: " << product.name 
                 << ", Price: $" << product.price << ", Location: " << product.location << endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct("Apple", 0.99, "Aisle 1");
    system.addProduct("Milk", 2.50, "Aisle 2");
    system.displayProducts();
    
    Product* product = system.searchProduct(1);
    if (product) {
        cout << "Found: ID: " << product->id << ", Name: " << product->name << endl;
    }
    
    system.updateProduct(1, "Green Apple", 1.10, "Aisle 3");
    system.displayProducts();
    
    system.deleteProduct(2);
    system.displayProducts();
    
    return 0;
}