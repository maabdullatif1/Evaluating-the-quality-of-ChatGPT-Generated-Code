#include <iostream>
#include <string>

struct Product {
    int id;
    std::string name;
    std::string location;
    float price;
    
    Product() : id(-1), price(0.0f) {}
    
    Product(int id, std::string name, std::string location, float price)
        : id(id), name(name), location(location), price(price) {}
};

class Supermarket {
    Product products[100];
    int numberOfProducts;

public:
    Supermarket() : numberOfProducts(0) {}

    void addProduct(int id, std::string name, std::string location, float price) {
        products[numberOfProducts++] = Product(id, name, location, price);
    }

    void deleteProduct(int id) {
        for(int i = 0; i < numberOfProducts; i++) {
            if (products[i].id == id) {
                for(int j = i; j < numberOfProducts - 1; j++) {
                    products[j] = products[j + 1];
                }
                numberOfProducts--;
                return;
            }
        }
    }

    void updateProduct(int id, std::string name, std::string location, float price) {
        for(int i = 0; i < numberOfProducts; i++) {
            if (products[i].id == id) {
                products[i].name = name;
                products[i].location = location;
                products[i].price = price;
                return;
            }
        }
    }

    void searchProduct(int id) {
        for(int i = 0; i < numberOfProducts; i++) {
            if (products[i].id == id) {
                std::cout << "Product ID: " << products[i].id << std::endl;
                std::cout << "Name: " << products[i].name << std::endl;
                std::cout << "Location: " << products[i].location << std::endl;
                std::cout << "Price: " << products[i].price << std::endl;
                return;
            }
        }
        std::cout << "Product not found." << std::endl;
    }

    void displayProducts() {
        for(int i = 0; i < numberOfProducts; i++) {
            std::cout << "Product ID: " << products[i].id << std::endl;
            std::cout << "Name: " << products[i].name << std::endl;
            std::cout << "Location: " << products[i].location << std::endl;
            std::cout << "Price: " << products[i].price << std::endl;
            std::cout << "-------------------" << std::endl;
        }
    }
};

int main() {
    Supermarket market;
    market.addProduct(1, "Milk", "Aisle 1", 1.99);
    market.addProduct(2, "Bread", "Aisle 2", 0.99);
    market.displayProducts();
    market.updateProduct(1, "Almond Milk", "Aisle 1", 2.49);
    market.searchProduct(1);
    market.deleteProduct(2);
    market.displayProducts();
    return 0;
}