#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Product {
    int id;
    string name;
    float price;
    string location;
};

class Supermarket {
private:
    vector<Product> products;
    int nextId;

    int findProductIndexById(int id) {
        for (int i = 0; i < products.size(); ++i) {
            if (products[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    Supermarket() : nextId(1) {}

    void addProduct(const string& name, float price, const string& location) {
        Product product;
        product.id = nextId++;
        product.name = name;
        product.price = price;
        product.location = location;
        products.push_back(product);
    }

    void deleteProduct(int id) {
        int index = findProductIndexById(id);
        if (index != -1) {
            products.erase(products.begin() + index);
        }
    }

    void updateProduct(int id, const string& name, float price, const string& location) {
        int index = findProductIndexById(id);
        if (index != -1) {
            products[index].name = name;
            products[index].price = price;
            products[index].location = location;
        }
    }

    Product* searchProductById(int id) {
        int index = findProductIndexById(id);
        if (index != -1) {
            return &products[index];
        }
        return nullptr;
    }

    vector<Product> searchProductByName(const string& name) {
        vector<Product> results;
        for (const auto& product : products) {
            if (product.name == name) {
                results.push_back(product);
            }
        }
        return results;
    }

    void displayAllProducts() {
        for (const auto& product : products) {
            cout << "ID: " << product.id << ", Name: " << product.name 
                 << ", Price: " << product.price << ", Location: " << product.location << endl;
        }
    }
};

int main() {
    Supermarket supermarket;
    supermarket.addProduct("Apple", 0.99, "Aisle 1");
    supermarket.addProduct("Banana", 0.49, "Aisle 1");
    supermarket.addProduct("Milk", 1.99, "Fridge 2");
    
    cout << "Display all products:" << endl;
    supermarket.displayAllProducts();
    
    cout << endl << "Search for product by ID 1:" << endl;
    Product* product = supermarket.searchProductById(1);
    if (product) {
        cout << "Found: " << product->name << endl;
    }
    
    cout << endl << "Update product ID 1:" << endl;
    supermarket.updateProduct(1, "Green Apple", 1.09, "Aisle 1");
    supermarket.displayAllProducts();
    
    cout << endl << "Delete product ID 2:" << endl;
    supermarket.deleteProduct(2);
    supermarket.displayAllProducts();

    cout << endl << "Search for product by name 'Milk':" << endl;
    vector<Product> searchResults = supermarket.searchProductByName("Milk");
    for (const auto& p : searchResults) {
        cout << "ID: " << p.id << ", Name: " << p.name << endl;
    }

    return 0;
}