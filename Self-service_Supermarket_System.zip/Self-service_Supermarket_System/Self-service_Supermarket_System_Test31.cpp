#include <iostream>
#include <string>
#include <vector>

struct Product {
    int id;
    std::string name;
    double price;
    std::string location;
};

class SupermarketSystem {
private:
    std::vector<Product> products;
    
    int findProductIndexById(int id) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addProduct(int id, const std::string &name, double price, const std::string &location) {
        if (findProductIndexById(id) == -1) {
            products.push_back({id, name, price, location});
        }
    }

    void deleteProduct(int id) {
        int index = findProductIndexById(id);
        if (index != -1) {
            products.erase(products.begin() + index);
        }
    }

    void updateProduct(int id, const std::string &name, double price, const std::string &location) {
        int index = findProductIndexById(id);
        if (index != -1) {
            products[index] = {id, name, price, location};
        }
    }

    Product* searchProduct(int id) {
        int index = findProductIndexById(id);
        return index != -1 ? &products[index] : nullptr;
    }

    void displayProducts() {
        for (const auto &product : products) {
            std::cout << "ID: " << product.id
                      << ", Name: " << product.name
                      << ", Price: " << product.price
                      << ", Location: " << product.location
                      << std::endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    
    system.addProduct(1, "Apple", 0.99, "Aisle 1");
    system.addProduct(2, "Bread", 1.99, "Aisle 2");
    
    system.displayProducts();
    
    system.updateProduct(1, "Green Apple", 1.09, "Aisle 3");
    
    Product* foundProduct = system.searchProduct(1);
    if (foundProduct) {
        std::cout << "Found Product - ID: " << foundProduct->id
                  << ", Name: " << foundProduct->name
                  << ", Price: " << foundProduct->price
                  << ", Location: " << foundProduct->location
                  << std::endl;
    }
    
    system.deleteProduct(2);
    
    system.displayProducts();
    
    return 0;
}