#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    std::string name;
    std::string location;
    double price;
    int quantity;

    Product(std::string n, std::string loc, double p, int q) : name(n), location(loc), price(p), quantity(q) {}
};

class Supermarket {
private:
    std::vector<Product> products;
public:
    void addProduct(const std::string& name, const std::string& location, double price, int quantity) {
        products.push_back(Product(name, location, price, quantity));
    }

    void deleteProduct(const std::string& name) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->name == name) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(const std::string& name, const std::string& location, double price, int quantity) {
        for (auto& product : products) {
            if (product.name == name) {
                product.location = location;
                product.price = price;
                product.quantity = quantity;
                break;
            }
        }
    }

    void searchProduct(const std::string& name) {
        for (const auto& product : products) {
            if (product.name == name) {
                std::cout << "Found: " << product.name << " | " << product.location << " | $" << product.price << " | Qty: " << product.quantity << std::endl;
                return;
            }
        }
        std::cout << "Product not found\n";
    }

    void displayProducts() {
        for (const auto& product : products) {
            std::cout << product.name << " | " << product.location << " | $" << product.price << " | Qty: " << product.quantity << std::endl;
        }
    }
};

int main() {
    Supermarket market;
    int choice;
    std::string name, location;
    double price;
    int quantity;

    do {
        std::cout << "1. Add Product\n2. Delete Product\n3. Update Product\n4. Search Product\n5. Display Products\n6. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter product name: ";
                std::cin >> name;
                std::cout << "Enter location: ";
                std::cin >> location;
                std::cout << "Enter price: ";
                std::cin >> price;
                std::cout << "Enter quantity: ";
                std::cin >> quantity;
                market.addProduct(name, location, price, quantity);
                break;
            case 2:
                std::cout << "Enter product name to delete: ";
                std::cin >> name;
                market.deleteProduct(name);
                break;
            case 3:
                std::cout << "Enter product name to update: ";
                std::cin >> name;
                std::cout << "Enter new location: ";
                std::cin >> location;
                std::cout << "Enter new price: ";
                std::cin >> price;
                std::cout << "Enter new quantity: ";
                std::cin >> quantity;
                market.updateProduct(name, location, price, quantity);
                break;
            case 4:
                std::cout << "Enter product name to search: ";
                std::cin >> name;
                market.searchProduct(name);
                break;
            case 5:
                market.displayProducts();
                break;
            case 6:
                std::cout << "Exiting...\n";
                break;
            default:
                std::cout << "Invalid choice, try again.\n";
        }
    } while (choice != 6);

    return 0;
}