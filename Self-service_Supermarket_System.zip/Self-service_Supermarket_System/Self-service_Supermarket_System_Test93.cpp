#include <iostream>
#include <vector>
#include <string>

struct Product {
    int id;
    std::string name;
    std::string location;
    float price;
};

class SupermarketSystem {
    std::vector<Product> products;
    int nextId;

public:
    SupermarketSystem() : nextId(1) {}

    void addProduct(const std::string& name, const std::string& location, float price) {
        products.push_back({nextId++, name, location, price});
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, const std::string& name, const std::string& location, float price) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.location = location;
                product.price = price;
                break;
            }
        }
    }

    void searchProduct(const std::string& name) {
        for (const auto& product : products) {
            if (product.name == name) {
                displayProduct(product);
            }
        }
    }
    
    void searchLocation(const std::string& location) {
        for (const auto& product : products) {
            if (product.location == location) {
                displayProduct(product);
            }
        }
    }

    void displayProducts() {
        for (const auto& product : products) {
            displayProduct(product);
        }
    }

private:
    void displayProduct(const Product& product) {
        std::cout << "ID: " << product.id
                  << ", Name: " << product.name
                  << ", Location: " << product.location
                  << ", Price: $" << product.price << '\n';
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct("Apple", "Aisle 1", 0.5f);
    system.addProduct("Banana", "Aisle 1", 0.3f);
    system.addProduct("Detergent", "Aisle 3", 2.5f);
    system.displayProducts();
    std::cout << "Updating Banana...\n";
    system.updateProduct(2, "Banana", "Aisle 2", 0.35f);
    system.displayProducts();
    std::cout << "Searching for Banana...\n";
    system.searchProduct("Banana");
    std::cout << "Searching in Aisle 1...\n";
    system.searchLocation("Aisle 1");
    std::cout << "Deleting Apple...\n";
    system.deleteProduct(1);
    system.displayProducts();
    return 0;
}