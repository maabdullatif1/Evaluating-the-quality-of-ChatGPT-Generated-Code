#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    int id;
    std::string name;
    double price;
    std::string location;

    Product(int id, std::string name, double price, std::string location)
        : id(id), name(name), price(price), location(location) {}
};

class SupermarketSystem {
public:
    void addProduct(int id, const std::string& name, double price, const std::string& location) {
        products.push_back(Product(id, name, price, location));
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, const std::string& name, double price, const std::string& location) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                break;
            }
        }
    }

    Product* searchProduct(int id) {
        for (auto& product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    void displayProducts() {
        for (const auto& product : products) {
            std::cout << "ID: " << product.id 
                      << ", Name: " << product.name 
                      << ", Price: " << product.price 
                      << ", Location: " << product.location << std::endl;
        }
    }

private:
    std::vector<Product> products;
};

int main() {
    SupermarketSystem system;
    system.addProduct(1, "Apples", 1.99, "Aisle 1");
    system.addProduct(2, "Bananas", 0.99, "Aisle 1");
    system.displayProducts();

    system.updateProduct(1, "Red Apples", 2.49, "Aisle 1");
    system.displayProducts();

    system.deleteProduct(2);
    system.displayProducts();

    Product* product = system.searchProduct(1);
    if (product) {
        std::cout << "Found Product: " 
                  << product->id << ", " 
                  << product->name << ", " 
                  << product->price << ", " 
                  << product->location << std::endl;
    }

    return 0;
}