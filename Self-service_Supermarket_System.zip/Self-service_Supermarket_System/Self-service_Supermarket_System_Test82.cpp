#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Product {
    int id;
    string name;
    string location;
};

class Supermarket {
public:
    void addProduct(int id, const string& name, const string& location) {
        products.push_back({ id, name, location });
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, const string& name, const string& location) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.location = location;
                break;
            }
        }
    }

    Product* searchProduct(int id) {
        for (auto& product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    void displayAllProducts() const {
        for (const auto& product : products) {
            cout << "ID: " << product.id << ", Name: " << product.name 
                 << ", Location: " << product.location << endl;
        }
    }

private:
    vector<Product> products;
};

int main() {
    Supermarket supermarket;
    int choice, id;
    string name, location;

    while (true) {
        cout << "1. Add Product" << endl;
        cout << "2. Delete Product" << endl;
        cout << "3. Update Product" << endl;
        cout << "4. Search Product" << endl;
        cout << "5. Display All Products" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter Product ID: ";
            cin >> id;
            cout << "Enter Product Name: ";
            cin.ignore();
            getline(cin, name);
            cout << "Enter Product Location: ";
            getline(cin, location);
            supermarket.addProduct(id, name, location);
            break;
        case 2:
            cout << "Enter Product ID to delete: ";
            cin >> id;
            supermarket.deleteProduct(id);
            break;
        case 3:
            cout << "Enter Product ID to update: ";
            cin >> id;
            cout << "Enter new Product Name: ";
            cin.ignore();
            getline(cin, name);
            cout << "Enter new Product Location: ";
            getline(cin, location);
            supermarket.updateProduct(id, name, location);
            break;
        case 4:
            cout << "Enter Product ID to search: ";
            cin >> id;
            if (auto* product = supermarket.searchProduct(id)) {
                cout << "ID: " << product->id << ", Name: " << product->name 
                     << ", Location: " << product->location << endl;
            } else {
                cout << "Product not found." << endl;
            }
            break;
        case 5:
            supermarket.displayAllProducts();
            break;
        case 6:
            return 0;
        default:
            cout << "Invalid choice." << endl;
        }
    }
}