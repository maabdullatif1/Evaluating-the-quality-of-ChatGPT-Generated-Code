#include <iostream>
#include <vector>
#include <string>

struct Product {
    int id;
    std::string name;
    double price;
    std::string location;
};

class Supermarket {
private:
    std::vector<Product> products;

public:
    void addProduct(int id, const std::string& name, double price, const std::string& location) {
        products.push_back({id, name, price, location});
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return;
            }
        }
    }

    void updateProduct(int id, const std::string& name, double price, const std::string& location) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                return;
            }
        }
    }

    void searchProduct(int id) {
        for (const auto& product : products) {
            if (product.id == id) {
                std::cout << "ID: " << product.id << " Name: " << product.name
                          << " Price: " << product.price << " Location: " << product.location << std::endl;
                return;
            }
        }
        std::cout << "Product not found" << std::endl;
    }

    void displayProducts() {
        for (const auto& product : products) {
            std::cout << "ID: " << product.id << " Name: " << product.name
                      << " Price: " << product.price << " Location: " << product.location << std::endl;
        }
    }
};

int main() {
    Supermarket supermarket;
    supermarket.addProduct(1, "Apple", 0.99, "Aisle 1");
    supermarket.addProduct(2, "Milk", 1.49, "Aisle 2");
    supermarket.displayProducts();
    supermarket.searchProduct(1);
    supermarket.updateProduct(1, "Green Apple", 1.09, "Aisle 1");
    supermarket.deleteProduct(2);
    supermarket.displayProducts();
    return 0;
}