#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Product {
public:
    int id;
    string name;
    double price;
    string location;

    Product(int p_id, string p_name, double p_price, string p_location)
        : id(p_id), name(p_name), price(p_price), location(p_location) {}
};

class Supermarket {
private:
    vector<Product> products;

public:
    void addProduct(int id, string name, double price, string location) {
        products.push_back(Product(id, name, price, location));
    }

    bool deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateProduct(int id, string name, double price, string location) {
        for (auto &product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                return true;
            }
        }
        return false;
    }

    Product* searchProduct(int id) {
        for (auto &product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    void displayProducts() {
        for (const auto &product : products) {
            cout << "ID: " << product.id
                 << ", Name: " << product.name
                 << ", Price: " << product.price
                 << ", Location: " << product.location << endl;
        }
    }
};

int main() {
    Supermarket market;
    market.addProduct(1, "Apple", 0.5, "Aisle 1");
    market.addProduct(2, "Banana", 0.3, "Aisle 1");
    market.addProduct(3, "Cereal", 3.5, "Aisle 2");

    cout << "All Products:" << endl;
    market.displayProducts();

    market.updateProduct(2, "Banana", 0.35, "Aisle 2");
    cout << "\nAfter Update:" << endl;
    market.displayProducts();

    market.deleteProduct(1);
    cout << "\nAfter Deletion:" << endl;
    market.displayProducts();

    cout << "\nSearch Product with ID 3:" << endl;
    Product* product = market.searchProduct(3);
    if (product) {
        cout << "ID: " << product->id
             << ", Name: " << product->name
             << ", Price: " << product->price
             << ", Location: " << product->location << endl;
    } else {
        cout << "Product not found." << endl;
    }

    return 0;
}