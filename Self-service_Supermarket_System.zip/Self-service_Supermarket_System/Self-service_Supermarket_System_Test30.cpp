#include <iostream>
#include <vector>
#include <string>

struct Product {
    int id;
    std::string name;
    std::string location;
    double price;
};

class SupermarketSystem {
    std::vector<Product> products;
    int nextId = 1;

    public:
        void addProduct(const std::string& name, const std::string& location, double price) {
            products.push_back({ nextId++, name, location, price });
        }

        void deleteProduct(int id) {
            for (auto it = products.begin(); it != products.end(); ++it) {
                if (it->id == id) {
                    products.erase(it);
                    break;
                }
            }
        }

        void updateProduct(int id, const std::string& name, const std::string& location, double price) {
            for (auto& product : products) {
                if (product.id == id) {
                    product.name = name;
                    product.location = location;
                    product.price = price;
                    break;
                }
            }
        }

        void searchProduct(int id) {
            bool found = false;
            for (const auto& product : products) {
                if (product.id == id) {
                    std::cout << "ID: " << product.id << ", Name: " << product.name
                              << ", Location: " << product.location << ", Price: $" << product.price << "\n";
                    found = true;
                    break;
                }
            }
            if (!found) {
                std::cout << "Product not found.\n";
            }
        }

        void searchProduct(const std::string& name) {
            bool found = false;
            for (const auto& product : products) {
                if (product.name == name) {
                    std::cout << "ID: " << product.id << ", Name: " << product.name
                              << ", Location: " << product.location << ", Price: $" << product.price << "\n";
                    found = true;
                }
            }
            if (!found) {
                std::cout << "Product not found.\n";
            }
        }

        void displayProducts() {
            if (products.empty()) {
                std::cout << "No products available.\n";
                return;
            }
            for (const auto& product : products) {
                std::cout << "ID: " << product.id << ", Name: " << product.name
                          << ", Location: " << product.location << ", Price: $" << product.price << "\n";
            }
        }
};

int main() {
    SupermarketSystem supermarket;
    
    int choice;
    do {
        std::cout << "Supermarket System\n";
        std::cout << "1. Add Product\n2. Delete Product\n3. Update Product\n4. Search Product by ID\n";
        std::cout << "5. Search Product by Name\n6. Display All Products\n7. Exit\nSelect your choice: ";
        std::cin >> choice;
        
        if (choice == 1) {
            std::string name, location;
            double price;
            std::cout << "Enter product name: ";
            std::cin >> name;
            std::cout << "Enter product location: ";
            std::cin >> location;
            std::cout << "Enter product price: ";
            std::cin >> price;
            supermarket.addProduct(name, location, price);
        } else if (choice == 2) {
            int id;
            std::cout << "Enter product ID to delete: ";
            std::cin >> id;
            supermarket.deleteProduct(id);
        } else if (choice == 3) {
            int id;
            std::string name, location;
            double price;
            std::cout << "Enter product ID to update: ";
            std::cin >> id;
            std::cout << "Enter new product name: ";
            std::cin >> name;
            std::cout << "Enter new product location: ";
            std::cin >> location;
            std::cout << "Enter new product price: ";
            std::cin >> price;
            supermarket.updateProduct(id, name, location, price);
        } else if (choice == 4) {
            int id;
            std::cout << "Enter product ID to search: ";
            std::cin >> id;
            supermarket.searchProduct(id);
        } else if (choice == 5) {
            std::string name;
            std::cout << "Enter product name to search: ";
            std::cin >> name;
            supermarket.searchProduct(name);
        } else if (choice == 6) {
            supermarket.displayProducts();
        }
        
    } while (choice != 7);

    return 0;
}