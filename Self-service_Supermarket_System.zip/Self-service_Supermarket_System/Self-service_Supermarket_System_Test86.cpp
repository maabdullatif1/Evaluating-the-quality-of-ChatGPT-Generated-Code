#include <iostream>
#include <string>
#include <vector>

struct Product {
    int id;
    std::string name;
    float price;
};

struct Location {
    int id;
    std::string name;
};

std::vector<Product> products;
std::vector<Location> locations;

void addProduct(int id, std::string name, float price) {
    products.push_back({id, name, price});
}

void deleteProduct(int id) {
    for (auto it = products.begin(); it != products.end(); ++it) {
        if (it->id == id) {
            products.erase(it);
            return;
        }
    }
}

void updateProduct(int id, std::string name, float price) {
    for (auto &product : products) {
        if (product.id == id) {
            product.name = name;
            product.price = price;
            return;
        }
    }
}

Product* searchProduct(int id) {
    for (auto &product : products) {
        if (product.id == id) {
            return &product;
        }
    }
    return nullptr;
}

void displayProducts() {
    for (const auto &product : products) {
        std::cout << "ID: " << product.id << ", Name: " << product.name << ", Price: $" << product.price << std::endl;
    }
}

void addLocation(int id, std::string name) {
    locations.push_back({id, name});
}

void deleteLocation(int id) {
    for (auto it = locations.begin(); it != locations.end(); ++it) {
        if (it->id == id) {
            locations.erase(it);
            return;
        }
    }
}

void updateLocation(int id, std::string name) {
    for (auto &location : locations) {
        if (location.id == id) {
            location.name = name;
            return;
        }
    }
}

Location* searchLocation(int id) {
    for (auto &location : locations) {
        if (location.id == id) {
            return &location;
        }
    }
    return nullptr;
}

void displayLocations() {
    for (const auto &location : locations) {
        std::cout << "ID: " << location.id << ", Name: " << location.name << std::endl;
    }
}

int main() {
    addProduct(1, "Apples", 0.99);
    addProduct(2, "Bananas", 0.59);
    addLocation(1, "Fruit Section");
    addLocation(2, "Dairy Section");
    
    displayProducts();
    displayLocations();
    
    updateProduct(1, "Red Apples", 1.29);
    updateLocation(2, "Fresh Dairy Section");
    
    displayProducts();
    displayLocations();
    
    deleteProduct(2);
    deleteLocation(1);
    
    displayProducts();
    displayLocations();
    
    return 0;
}