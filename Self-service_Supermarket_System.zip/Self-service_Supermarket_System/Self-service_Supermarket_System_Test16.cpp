#include <iostream>
#include <string>

const int MAX_PRODUCTS = 100;

struct Product {
    int productID;
    std::string productName;
    std::string location;
    double price;
};

Product products[MAX_PRODUCTS];
int productCount = 0;

void addProduct(int productID, std::string productName, std::string location, double price) {
    if (productCount >= MAX_PRODUCTS) return;
    products[productCount].productID = productID;
    products[productCount].productName = productName;
    products[productCount].location = location;
    products[productCount].price = price;
    productCount++;
}

void updateProduct(int productID, std::string productName, std::string location, double price) {
    for (int i = 0; i < productCount; i++) {
        if (products[i].productID == productID) {
            products[i].productName = productName;
            products[i].location = location;
            products[i].price = price;
            break;
        }
    }
}

void deleteProduct(int productID) {
    int index = -1;
    for (int i = 0; i < productCount; i++) {
        if (products[i].productID == productID) {
            index = i;
            break;
        }
    }
    if (index != -1) {
        for (int i = index; i < productCount - 1; i++) {
            products[i] = products[i + 1];
        }
        productCount--;
    }
}

Product* searchProduct(int productID) {
    for (int i = 0; i < productCount; i++) {
        if (products[i].productID == productID) {
            return &products[i];
        }
    }
    return nullptr;
}

void displayProducts() {
    for (int i = 0; i < productCount; i++) {
        std::cout << "ID: " << products[i].productID 
                  << ", Name: " << products[i].productName
                  << ", Location: " << products[i].location
                  << ", Price: $" << products[i].price << std::endl;
    }
}

int main() {
    addProduct(1, "Apple", "Aisle 1", 0.99);
    addProduct(2, "Banana", "Aisle 1", 0.59);
    updateProduct(1, "Apple", "Aisle 2", 1.19);
    
    std::cout << "Products List:" << std::endl;
    displayProducts();
    
    deleteProduct(2);
    std::cout << "Products List after deletion:" << std::endl;
    displayProducts();

    Product* found = searchProduct(1);
    if (found) {
        std::cout << "Found Product: " << found->productName << " at " << found->location << std::endl;
    } else {
        std::cout << "Product not found." << std::endl;
    }

    return 0;
}