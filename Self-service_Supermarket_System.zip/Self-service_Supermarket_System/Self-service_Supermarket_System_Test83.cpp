#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Product {
    int id;
    string name;
    double price;
    string location;
};

class SupermarketSystem {
    vector<Product> products;
    int nextId = 1;

public:
    void addProduct(const string& name, double price, const string& location) {
        products.push_back({nextId++, name, price, location});
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, const string& name, double price, const string& location) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                break;
            }
        }
    }

    void searchProduct(const string& name) {
        for (const auto& product : products) {
            if (product.name == name) {
                cout << "Found: ID: " << product.id << ", Name: " << product.name 
                     << ", Price: " << product.price << ", Location: " << product.location << endl;
                return;
            }
        }
        cout << "Product not found." << endl;
    }

    void displayProducts() {
        for (const auto& product : products) {
            cout << "ID: " << product.id << ", Name: " << product.name 
                 << ", Price: " << product.price << ", Location: " << product.location << endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    int choice;
    string name, location;
    double price;
    int id;

    while (true) {
        cout << "1. Add Product\n2. Delete Product\n3. Update Product\n4. Search Product\n5. Display Products\n6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter product name: ";
                cin >> name;
                cout << "Enter product price: ";
                cin >> price;
                cout << "Enter product location: ";
                cin >> location;
                system.addProduct(name, price, location);
                break;
            case 2:
                cout << "Enter product ID to delete: ";
                cin >> id;
                system.deleteProduct(id);
                break;
            case 3:
                cout << "Enter product ID to update: ";
                cin >> id;
                cout << "Enter new product name: ";
                cin >> name;
                cout << "Enter new product price: ";
                cin >> price;
                cout << "Enter new product location: ";
                cin >> location;
                system.updateProduct(id, name, price, location);
                break;
            case 4:
                cout << "Enter product name to search: ";
                cin >> name;
                system.searchProduct(name);
                break;
            case 5:
                system.displayProducts();
                break;
            case 6:
                return 0;
            default:
                cout << "Invalid choice." << endl;
                break;
        }
    }

    return 0;
}