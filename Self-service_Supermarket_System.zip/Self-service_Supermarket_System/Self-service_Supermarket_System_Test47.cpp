#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    int id;
    std::string name;
    float price;
    
    Product(int id, const std::string& name, float price)
        : id(id), name(name), price(price) {}
};

class Location {
public:
    int id;
    std::string description;
    
    Location(int id, const std::string& description)
        : id(id), description(description) {}
};

class Supermarket {
    std::vector<Product> products;
    std::vector<Location> locations;
    
    Product* findProductById(int id) {
        for (auto& product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }
    
    Location* findLocationById(int id) {
        for (auto& location : locations) {
            if (location.id == id) {
                return &location;
            }
        }
        return nullptr;
    }
    
public:
    void addProduct(int id, const std::string& name, float price) {
        products.emplace_back(id, name, price);
    }
    
    void deleteProduct(int id) {
        products.erase(std::remove_if(products.begin(), products.end(), [id](Product& product) {
            return product.id == id;
        }), products.end());
    }
    
    void updateProduct(int id, const std::string& name, float price) {
        Product* product = findProductById(id);
        if (product) {
            product->name = name;
            product->price = price;
        }
    }
    
    void searchProduct(int id) {
        Product* product = findProductById(id);
        if (product) {
            std::cout << "Product found: " << product->id << ", " << product->name << ", " << product->price << std::endl;
        } else {
            std::cout << "Product not found" << std::endl;
        }
    }
    
    void displayProducts() {
        for (const auto& product : products) {
            std::cout << product.id << ", " << product.name << ", " << product.price << std::endl;
        }
    }
    
    void addLocation(int id, const std::string& description) {
        locations.emplace_back(id, description);
    }
    
    void deleteLocation(int id) {
        locations.erase(std::remove_if(locations.begin(), locations.end(), [id](Location& location) {
            return location.id == id;
        }), locations.end());
    }
    
    void updateLocation(int id, const std::string& description) {
        Location* location = findLocationById(id);
        if (location) {
            location->description = description;
        }
    }
    
    void searchLocation(int id) {
        Location* location = findLocationById(id);
        if (location) {
            std::cout << "Location found: " << location->id << ", " << location->description << std::endl;
        } else {
            std::cout << "Location not found" << std::endl;
        }
    }
    
    void displayLocations() {
        for (const auto& location : locations) {
            std::cout << location.id << ", " << location.description << std::endl;
        }
    }
};

int main() {
    Supermarket supermarket;
    
    supermarket.addProduct(1, "Apple", 0.99);
    supermarket.addProduct(2, "Banana", 0.59);
    supermarket.addLocation(1, "Aisle 1");
    supermarket.addLocation(2, "Aisle 2");
    
    supermarket.displayProducts();
    supermarket.displayLocations();
    
    supermarket.updateProduct(1, "Green Apple", 1.29);
    supermarket.searchProduct(1);
    
    supermarket.deleteProduct(2);
    supermarket.displayProducts();
    
    supermarket.updateLocation(1, "Fruit Section");
    supermarket.searchLocation(1);
    
    supermarket.deleteLocation(2);
    supermarket.displayLocations();
    
    return 0;
}