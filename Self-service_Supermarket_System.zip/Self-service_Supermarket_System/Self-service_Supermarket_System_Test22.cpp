#include <iostream>
#include <string>
#include <vector>

struct Product {
    int id;
    std::string name;
    double price;
    std::string location;
};

class SupermarketSystem {
    std::vector<Product> products;
    int next_id = 1;

    int findProductIndexById(int id) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addProduct(const std::string& name, double price, const std::string& location) {
        products.push_back({next_id++, name, price, location});
    }

    void deleteProduct(int id) {
        int index = findProductIndexById(id);
        if (index != -1) {
            products.erase(products.begin() + index);
        }
    }

    void updateProduct(int id, const std::string& newName, double newPrice, const std::string& newLocation) {
        int index = findProductIndexById(id);
        if (index != -1) {
            products[index].name = newName;
            products[index].price = newPrice;
            products[index].location = newLocation;
        }
    }

    Product* searchProduct(int id) {
        int index = findProductIndexById(id);
        return (index != -1) ? &products[index] : nullptr;
    }

    void displayProducts() {
        for (const auto& product : products) {
            std::cout << "ID: " << product.id << ", Name: " << product.name
                      << ", Price: " << product.price << ", Location: " << product.location << "\n";
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct("Apple", 0.5, "Aisle 1");
    system.addProduct("Banana", 0.3, "Aisle 1");
    system.displayProducts();

    system.updateProduct(1, "Apple", 0.55, "Aisle 2");
    system.displayProducts();

    Product* product = system.searchProduct(2);
    if (product) {
        std::cout << "Found Product - ID: " << product->id << ", Name: " << product->name << "\n";
    }

    system.deleteProduct(1);
    system.displayProducts();

    return 0;
}