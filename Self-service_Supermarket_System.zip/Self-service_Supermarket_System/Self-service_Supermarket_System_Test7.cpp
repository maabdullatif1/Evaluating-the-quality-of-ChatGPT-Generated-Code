#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Product {
public:
    int id;
    string name;
    double price;
    string location;

    Product(int p_id, string p_name, double p_price, string p_location)
        : id(p_id), name(p_name), price(p_price), location(p_location) {}
};

class Supermarket {
    vector<Product> products;

public:
    void addProduct(int id, string name, double price, string location) {
        products.push_back(Product(id, name, price, location));
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, string newName, double newPrice, string newLocation) {
        for (auto &product : products) {
            if (product.id == id) {
                product.name = newName;
                product.price = newPrice;
                product.location = newLocation;
                break;
            }
        }
    }

    Product* searchProduct(int id) {
        for (auto &product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    void displayProducts() {
        for (auto &product : products) {
            cout << "ID: " << product.id 
                 << ", Name: " << product.name 
                 << ", Price: " << product.price 
                 << ", Location: " << product.location << endl;
        }
    }
};

int main() {
    Supermarket supermarket;

    supermarket.addProduct(1, "Milk", 1.99, "Aisle 1");
    supermarket.addProduct(2, "Bread", 2.49, "Aisle 2");
    supermarket.addProduct(3, "Eggs", 3.49, "Aisle 1");

    cout << "Products after adding:" << endl;
    supermarket.displayProducts();

    supermarket.updateProduct(2, "Whole Grain Bread", 2.99, "Aisle 3");
    
    cout << "\nProducts after update:" << endl;
    supermarket.displayProducts();

    supermarket.deleteProduct(3);
    
    cout << "\nProducts after deletion:" << endl;
    supermarket.displayProducts();

    Product* product = supermarket.searchProduct(1);
    if (product) {
        cout << "\nProduct found - ID: " << product->id 
             << ", Name: " << product->name 
             << ", Price: " << product->price 
             << ", Location: " << product->location << endl;
    } else {
        cout << "\nProduct not found." << endl;
    }

    return 0;
}