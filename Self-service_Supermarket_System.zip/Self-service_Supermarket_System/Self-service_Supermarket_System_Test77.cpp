#include <iostream>
#include <string>

using namespace std;

const int MAX_PRODUCTS = 100;

struct Product {
    int id;
    string name;
    string location;
    double price;
    int quantity;
};

struct Supermarket {
    Product products[MAX_PRODUCTS];
    int productCount;
};

void addProduct(Supermarket &sm, int id, string name, string location, double price, int quantity) {
    if (sm.productCount < MAX_PRODUCTS) {
        sm.products[sm.productCount++] = { id, name, location, price, quantity };
    } else {
        cout << "Max product limit reached" << endl;
    }
}

void deleteProduct(Supermarket &sm, int id) {
    for (int i = 0; i < sm.productCount; ++i) {
        if (sm.products[i].id == id) {
            for (int j = i; j < sm.productCount - 1; ++j) {
                sm.products[j] = sm.products[j + 1];
            }
            sm.productCount--;
            return;
        }
    }
    cout << "Product not found" << endl;
}

void updateProduct(Supermarket &sm, int id, string name, string location, double price, int quantity) {
    for (int i = 0; i < sm.productCount; ++i) {
        if (sm.products[i].id == id) {
            sm.products[i].name = name;
            sm.products[i].location = location;
            sm.products[i].price = price;
            sm.products[i].quantity = quantity;
            return;
        }
    }
    cout << "Product not found" << endl;
}

Product* searchProduct(Supermarket &sm, int id) {
    for (int i = 0; i < sm.productCount; ++i) {
        if (sm.products[i].id == id) {
            return &sm.products[i];
        }
    }
    return nullptr;
}

void displayProducts(const Supermarket &sm) {
    for (int i = 0; i < sm.productCount; ++i) {
        cout << "ID: " << sm.products[i].id << ", Name: " << sm.products[i].name
             << ", Location: " << sm.products[i].location << ", Price: " << sm.products[i].price
             << ", Quantity: " << sm.products[i].quantity << endl;
    }
}

int main() {
    Supermarket sm = {};
    
    addProduct(sm, 1, "Apple", "Aisle 1", 0.99, 50);
    addProduct(sm, 2, "Milk", "Aisle 2", 1.50, 30);
    
    displayProducts(sm);
    
    updateProduct(sm, 1, "Green Apple", "Aisle 1", 1.10, 40);
    displayProducts(sm);
    
    deleteProduct(sm, 2);
    displayProducts(sm);
    
    Product *p = searchProduct(sm, 1);
    if (p) {
        cout << "Found product: " << p->name << endl;
    }

    return 0;
}