#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    int id;
    std::string name;
    double price;
    std::string location;

    Product(int id, const std::string& name, double price, const std::string& location)
        : id(id), name(name), price(price), location(location) {}
};

class Supermarket {
private:
    std::vector<Product> products;
    int nextId;

public:
    Supermarket() : nextId(1) {}

    void addProduct(const std::string& name, double price, const std::string& location) {
        products.emplace_back(nextId++, name, price, location);
        std::cout << "Product added successfully.\n";
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                std::cout << "Product deleted successfully.\n";
                return;
            }
        }
        std::cout << "Product not found.\n";
    }

    void updateProduct(int id, const std::string& name, double price, const std::string& location) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                std::cout << "Product updated successfully.\n";
                return;
            }
        }
        std::cout << "Product not found.\n";
    }

    void searchProduct(int id) const {
        for (const auto& product : products) {
            if (product.id == id) {
                std::cout << "Product ID: " << product.id
                          << ", Name: " << product.name
                          << ", Price: " << product.price
                          << ", Location: " << product.location << "\n";
                return;
            }
        }
        std::cout << "Product not found.\n";
    }

    void displayProducts() const {
        if (products.empty()) {
            std::cout << "No products found.\n";
            return;
        }
        for (const auto& product : products) {
            std::cout << "Product ID: " << product.id
                      << ", Name: " << product.name
                      << ", Price: " << product.price
                      << ", Location: " << product.location << "\n";
        }
    }
};

int main() {
    Supermarket supermarket;
    int choice, id;
    std::string name, location;
    double price;

    while (true) {
        std::cout << "1. Add Product\n"
                  << "2. Delete Product\n"
                  << "3. Update Product\n"
                  << "4. Search Product\n"
                  << "5. Display All Products\n"
                  << "6. Exit\n"
                  << "Enter choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter product name: ";
                std::cin >> name;
                std::cout << "Enter product price: ";
                std::cin >> price;
                std::cout << "Enter product location: ";
                std::cin >> location;
                supermarket.addProduct(name, price, location);
                break;
            case 2:
                std::cout << "Enter product ID to delete: ";
                std::cin >> id;
                supermarket.deleteProduct(id);
                break;
            case 3:
                std::cout << "Enter product ID to update: ";
                std::cin >> id;
                std::cout << "Enter new product name: ";
                std::cin >> name;
                std::cout << "Enter new product price: ";
                std::cin >> price;
                std::cout << "Enter new product location: ";
                std::cin >> location;
                supermarket.updateProduct(id, name, price, location);
                break;
            case 4:
                std::cout << "Enter product ID to search: ";
                std::cin >> id;
                supermarket.searchProduct(id);
                break;
            case 5:
                supermarket.displayProducts();
                break;
            case 6:
                return 0;
            default:
                std::cout << "Invalid choice. Please try again.\n";
        }
    }
}