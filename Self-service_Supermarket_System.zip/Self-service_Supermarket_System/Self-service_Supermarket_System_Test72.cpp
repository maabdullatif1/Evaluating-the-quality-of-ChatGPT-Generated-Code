#include <iostream>
#include <string>
#include <vector>

class Product {
public:
    int id;
    std::string name;
    float price;
    std::string location;

    Product(int id, std::string name, float price, std::string location)
        : id(id), name(name), price(price), location(location) {}
};

class SupermarketSystem {
private:
    std::vector<Product> products;
    int nextId;

public:
    SupermarketSystem() : nextId(1) {}

    void addProduct(std::string name, float price, std::string location) {
        products.push_back(Product(nextId++, name, price, location));
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return;
            }
        }
    }

    void updateProduct(int id, std::string name, float price, std::string location) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                return;
            }
        }
    }

    void searchProduct(std::string name) {
        for (const auto& product : products) {
            if (product.name == name) {
                std::cout << "ID: " << product.id << ", Name: " << product.name
                          << ", Price: " << product.price << ", Location: " << product.location << std::endl;
            }
        }
    }

    void displayProducts() {
        for (const auto& product : products) {
            std::cout << "ID: " << product.id << ", Name: " << product.name
                      << ", Price: " << product.price << ", Location: " << product.location << std::endl;
        }
    }
};

int main() {
    SupermarketSystem system;

    system.addProduct("Apple", 0.99, "Aisle 1");
    system.addProduct("Banana", 1.10, "Aisle 1");
    system.addProduct("Milk", 2.50, "Dairy");

    std::cout << "All Products:" << std::endl;
    system.displayProducts();

    system.deleteProduct(2);
    std::cout << "\nAfter Deleting Product 2:" << std::endl;
    system.displayProducts();

    system.updateProduct(3, "Almond Milk", 3.00, "Dairy");
    std::cout << "\nAfter Updating Product 3:" << std::endl;
    system.displayProducts();

    std::cout << "\nSearching for 'Apple':" << std::endl;
    system.searchProduct("Apple");

    return 0;
}