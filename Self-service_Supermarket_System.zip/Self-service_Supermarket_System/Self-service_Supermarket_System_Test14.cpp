#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Product {
    int id;
    string name;
    double price;
    int locationId;
};

struct Location {
    int id;
    string name;
};

class SupermarketSystem {
private:
    vector<Product> products;
    vector<Location> locations;

public:
    void addProduct(int id, string name, double price, int locationId) {
        products.push_back({id, name, price, locationId});
    }

    void deleteProduct(int id) {
        products.erase(remove_if(products.begin(), products.end(), [&](Product& p) { return p.id == id; }), products.end());
    }

    void updateProduct(int id, string name, double price, int locationId) {
        for (auto& p : products) {
            if (p.id == id) {
                p.name = name;
                p.price = price;
                p.locationId = locationId;
                break;
            }
        }
    }

    void searchProduct(int id) {
        for (const auto& p : products) {
            if (p.id == id) {
                cout << "Product Found: ID=" << p.id << ", Name=" << p.name << ", Price=" << p.price << ", LocationID=" << p.locationId << endl;
                return;
            }
        }
        cout << "Product not found" << endl;
    }

    void displayProducts() {
        for (const auto& p : products) {
            cout << "ID=" << p.id << ", Name=" << p.name << ", Price=" << p.price << ", LocationID=" << p.locationId << endl;
        }
    }

    void addLocation(int id, string name) {
        locations.push_back({id, name});
    }

    void deleteLocation(int id) {
        locations.erase(remove_if(locations.begin(), locations.end(), [&](Location& l) { return l.id == id; }), locations.end());
    }

    void updateLocation(int id, string name) {
        for (auto& l : locations) {
            if (l.id == id) {
                l.name = name;
                break;
            }
        }
    }

    void searchLocation(int id) {
        for (const auto& l : locations) {
            if (l.id == id) {
                cout << "Location Found: ID=" << l.id << ", Name=" << l.name << endl;
                return;
            }
        }
        cout << "Location not found" << endl;
    }

    void displayLocations() {
        for (const auto& l : locations) {
            cout << "ID=" << l.id << ", Name=" << l.name << endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    
    system.addProduct(1, "Apple", 0.99, 101);
    system.addProduct(2, "Banana", 1.09, 102);
    system.addLocation(101, "Aisle 1");
    system.addLocation(102, "Aisle 2");
    
    system.displayProducts();
    system.displayLocations();

    system.searchProduct(2);
    system.searchLocation(101);

    system.updateProduct(1, "Green Apple", 1.09, 101);
    system.updateLocation(101, "Fruits Aisle");

    system.displayProducts();
    system.displayLocations();
    
    system.deleteProduct(2);
    system.deleteLocation(102);

    system.displayProducts();
    system.displayLocations();

    return 0;
}