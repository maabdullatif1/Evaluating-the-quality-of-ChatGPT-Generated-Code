#include <iostream>
#include <string>

struct Product {
    int id;
    std::string name;
    std::string location;
    float price;
};

class SupermarketSystem {
private:
    Product products[100];
    int productCount;

public:
    SupermarketSystem() : productCount(0) {}

    void addProduct(int id, const std::string& name, const std::string& location, float price) {
        if (productCount < 100) {
            products[productCount++] = {id, name, location, price};
        }
    }
    
    void deleteProduct(int id) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                for (int j = i; j < productCount - 1; ++j) {
                    products[j] = products[j + 1];
                }
                --productCount;
                break;
            }
        }
    }
    
    void updateProduct(int id, const std::string& name, const std::string& location, float price) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                products[i].name = name;
                products[i].location = location;
                products[i].price = price;
                break;
            }
        }
    }

    Product* searchProduct(int id) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                return &products[i];
            }
        }
        return nullptr;
    }

    void displayProducts() {
        for (int i = 0; i < productCount; ++i) {
            std::cout << "ID: " << products[i].id
                      << ", Name: " << products[i].name
                      << ", Location: " << products[i].location
                      << ", Price: " << products[i].price << std::endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct(1, "Apple", "Aisle 1", 0.5);
    system.addProduct(2, "Banana", "Aisle 1", 0.3);
    system.displayProducts();

    system.updateProduct(1, "Apple", "Aisle 2", 0.6);
    system.displayProducts();

    Product* product = system.searchProduct(1);
    if (product) {
        std::cout << "Found product: " << product->name << std::endl;
    }

    system.deleteProduct(2);
    system.displayProducts();

    return 0;
}