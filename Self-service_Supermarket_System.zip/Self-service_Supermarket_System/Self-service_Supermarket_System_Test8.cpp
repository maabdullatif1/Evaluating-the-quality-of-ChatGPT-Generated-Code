#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    int id;
    std::string name;
    float price;

    Product(int id, std::string name, float price)
        : id(id), name(name), price(price) {}
};

class Location {
public:
    int id;
    std::string name;
    std::string address;

    Location(int id, std::string name, std::string address)
        : id(id), name(name), address(address) {}
};

class SupermarketSystem {
    std::vector<Product> products;
    std::vector<Location> locations;
    int productCounter = 1;
    int locationCounter = 1;

public:
    void addProduct(std::string name, float price) {
        products.push_back(Product(productCounter++, name, price));
    }

    void deleteProduct(int id) {
        products.erase(std::remove_if(products.begin(), products.end(),
                                      [id](Product &p) { return p.id == id; }),
                       products.end());
    }

    void updateProduct(int id, std::string name, float price) {
        for (auto &p : products) {
            if (p.id == id) {
                p.name = name;
                p.price = price;
                break;
            }
        }
    }

    void searchProduct(int id) {
        for (const auto &p : products) {
            if (p.id == id) {
                std::cout << "Product ID: " << p.id << ", Name: " << p.name
                          << ", Price: " << p.price << std::endl;
                return;
            }
        }
        std::cout << "Product not found" << std::endl;
    }

    void displayProducts() {
        for (const auto &p : products) {
            std::cout << "Product ID: " << p.id << ", Name: " << p.name
                      << ", Price: " << p.price << std::endl;
        }
    }

    void addLocation(std::string name, std::string address) {
        locations.push_back(Location(locationCounter++, name, address));
    }

    void deleteLocation(int id) {
        locations.erase(std::remove_if(locations.begin(), locations.end(),
                                       [id](Location &l) { return l.id == id; }),
                        locations.end());
    }

    void updateLocation(int id, std::string name, std::string address) {
        for (auto &l : locations) {
            if (l.id == id) {
                l.name = name;
                l.address = address;
                break;
            }
        }
    }

    void searchLocation(int id) {
        for (const auto &l : locations) {
            if (l.id == id) {
                std::cout << "Location ID: " << l.id << ", Name: " << l.name
                          << ", Address: " << l.address << std::endl;
                return;
            }
        }
        std::cout << "Location not found" << std::endl;
    }

    void displayLocations() {
        for (const auto &l : locations) {
            std::cout << "Location ID: " << l.id << ", Name: " << l.name
                      << ", Address: " << l.address << std::endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct("Milk", 1.99);
    system.addProduct("Bread", 2.49);
    system.addLocation("Main Store", "123 Main St");
    system.addLocation("Branch Store", "456 Branch St");

    std::cout << "All Products:" << std::endl;
    system.displayProducts();

    std::cout << "All Locations:" << std::endl;
    system.displayLocations();

    std::cout << "Searching for Product with ID 1:" << std::endl;
    system.searchProduct(1);

    std::cout << "Searching for Location with ID 2:" << std::endl;
    system.searchLocation(2);

    system.updateProduct(1, "Skimmed Milk", 1.89);
    system.updateLocation(2, "Branch Store Updated", "456 Updated Branch St");

    std::cout << "Updated Products:" << std::endl;
    system.displayProducts();

    std::cout << "Updated Locations:" << std::endl;
    system.displayLocations();

    system.deleteProduct(1);
    system.deleteLocation(1);

    std::cout << "After Deletion - Products:" << std::endl;
    system.displayProducts();
    
    std::cout << "After Deletion - Locations:" << std::endl;
    system.displayLocations();

    return 0;
}