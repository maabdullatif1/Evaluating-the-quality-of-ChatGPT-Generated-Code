#include <iostream>
#include <string>

using namespace std;

struct Product {
    string name;
    int quantity;
    double price;
    string location;
};

Product products[100];
int productCount = 0;

void addProduct() {
    if (productCount >= 100) {
        cout << "Max product limit reached." << endl;
        return;
    }
    Product p;
    cout << "Enter product name: ";
    cin >> p.name;
    cout << "Enter quantity: ";
    cin >> p.quantity;
    cout << "Enter price: ";
    cin >> p.price;
    cout << "Enter location: ";
    cin >> p.location;
    products[productCount++] = p;
}

void deleteProduct() {
    string name;
    cout << "Enter product name to delete: ";
    cin >> name;
    for (int i = 0; i < productCount; ++i) {
        if (products[i].name == name) {
            for (int j = i; j < productCount - 1; ++j) {
                products[j] = products[j + 1];
            }
            --productCount;
            cout << "Product deleted." << endl;
            return;
        }
    }
    cout << "Product not found." << endl;
}

void updateProduct() {
    string name;
    cout << "Enter product name to update: ";
    cin >> name;
    for (int i = 0; i < productCount; ++i) {
        if (products[i].name == name) {
            cout << "Enter new quantity: ";
            cin >> products[i].quantity;
            cout << "Enter new price: ";
            cin >> products[i].price;
            cout << "Enter new location: ";
            cin >> products[i].location;
            cout << "Product updated." << endl;
            return;
        }
    }
    cout << "Product not found." << endl;
}

void searchProduct() {
    string name;
    cout << "Enter product name to search: ";
    cin >> name;
    for (int i = 0; i < productCount; ++i) {
        if (products[i].name == name) {
            cout << "Product found: " << products[i].name << " Quantity: " 
                 << products[i].quantity << " Price: " << products[i].price 
                 << " Location: " << products[i].location << endl;
            return;
        }
    }
    cout << "Product not found." << endl;
}

void displayProducts() {
    for (int i = 0; i < productCount; ++i) {
        cout << "Name: " << products[i].name << " Quantity: " 
             << products[i].quantity << " Price: " 
             << products[i].price << " Location: " 
             << products[i].location << endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Product" << endl;
        cout << "2. Delete Product" << endl;
        cout << "3. Update Product" << endl;
        cout << "4. Search Product" << endl;
        cout << "5. Display Products" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;
        switch (choice) {
            case 1:
                addProduct();
                break;
            case 2:
                deleteProduct();
                break;
            case 3:
                updateProduct();
                break;
            case 4:
                searchProduct();
                break;
            case 5:
                displayProducts();
                break;
            case 6:
                return 0;
            default:
                cout << "Invalid choice." << endl;
        }
    }
}