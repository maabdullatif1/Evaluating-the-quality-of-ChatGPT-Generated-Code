#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    std::string name;
    std::string location;
    double price;
    int quantity;

    Product(std::string n, std::string loc, double p, int q) : name(n), location(loc), price(p), quantity(q) {}
};

class SupermarketSystem {
    std::vector<Product> products;
public:
    void addProduct(const std::string& name, const std::string& location, double price, int quantity) {
        products.push_back(Product(name, location, price, quantity));
    }

    void deleteProduct(const std::string& name) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->name == name) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(const std::string& name, const std::string& newLocation, double newPrice, int newQuantity) {
        for (auto& product : products) {
            if (product.name == name) {
                product.location = newLocation;
                product.price = newPrice;
                product.quantity = newQuantity;
                break;
            }
        }
    }

    void searchProduct(const std::string& name) const {
        for (const auto& product : products) {
            if (product.name == name) {
                std::cout << "Product found: " << product.name << ", Location: " << product.location
                          << ", Price: " << product.price << ", Quantity: " << product.quantity << std::endl;
                return;
            }
        }
        std::cout << "Product not found." << std::endl;
    }

    void displayProducts() const {
        if (products.empty()) {
            std::cout << "No products available." << std::endl;
            return;
        }
        for (const auto& product : products) {
            std::cout << "Name: " << product.name << ", Location: " << product.location
                      << ", Price: " << product.price << ", Quantity: " << product.quantity << std::endl;
        }
    }
};

int main() {
    SupermarketSystem sms;
    sms.addProduct("Apple", "Aisle 1", 0.99, 50);
    sms.addProduct("Banana", "Aisle 1", 0.59, 30);
    sms.displayProducts();
    sms.searchProduct("Apple");
    sms.updateProduct("Apple", "Aisle 2", 1.19, 45);
    sms.searchProduct("Apple");
    sms.deleteProduct("Banana");
    sms.displayProducts();
    return 0;
}