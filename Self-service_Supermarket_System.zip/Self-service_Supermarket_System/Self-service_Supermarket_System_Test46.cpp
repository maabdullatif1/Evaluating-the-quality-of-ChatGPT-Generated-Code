#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    int id;
    std::string name;
    double price;
    int quantity;
    std::string location;

    Product(int id, std::string name, double price, int quantity, std::string location) 
        : id(id), name(name), price(price), quantity(quantity), location(location) {}
};

class SupermarketSystem {
private:
    std::vector<Product> products;

public:
    void addProduct(int id, std::string name, double price, int quantity, std::string location) {
        products.push_back(Product(id, name, price, quantity, location));
    }

    bool deleteProduct(int id) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].id == id) {
                products.erase(products.begin() + i);
                return true;
            }
        }
        return false;
    }

    bool updateProduct(int id, std::string name, double price, int quantity, std::string location) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].id == id) {
                products[i] = Product(id, name, price, quantity, location);
                return true;
            }
        }
        return false;
    }

    Product* searchProduct(int id) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].id == id) {
                return &products[i];
            }
        }
        return nullptr;
    }

    void displayProducts() {
        for (const auto& product : products) {
            std::cout << "ID: " << product.id 
                      << ", Name: " << product.name 
                      << ", Price: " << product.price 
                      << ", Quantity: " << product.quantity 
                      << ", Location: " << product.location << std::endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct(1, "Apple", 0.5, 100, "Aisle 1");
    system.addProduct(2, "Banana", 0.2, 150, "Aisle 1");
    system.displayProducts();

    system.updateProduct(1, "Apple", 0.6, 90, "Aisle 1");
    system.displayProducts();

    system.deleteProduct(2);
    system.displayProducts();

    Product* product = system.searchProduct(1);
    if (product != nullptr) {
        std::cout << "Found Product: " << product->name << std::endl;
    } else {
        std::cout << "Product not found." << std::endl;
    }

    return 0;
}