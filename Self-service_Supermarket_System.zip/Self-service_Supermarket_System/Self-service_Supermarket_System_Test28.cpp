#include <iostream>
#include <string>
using namespace std;

struct Product {
    int id;
    string name;
    float price;
    string location;
};

class SupermarketSystem {
private:
    Product products[100];
    int productCount;

public:
    SupermarketSystem() : productCount(0) {}

    void addProduct(int id, const string& name, float price, const string& location) {
        products[productCount++] = {id, name, price, location};
    }

    void deleteProduct(int id) {
        int index = -1;
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            for (int i = index; i < productCount - 1; ++i) {
                products[i] = products[i + 1];
            }
            --productCount;
        }
    }

    void updateProduct(int id, const string& name, float price, const string& location) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                products[i].name = name;
                products[i].price = price;
                products[i].location = location;
                break;
            }
        }
    }

    void searchProduct(int id) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                cout << "Product ID: " << products[i].id << "\n";
                cout << "Name: " << products[i].name << "\n";
                cout << "Price: " << products[i].price << "\n";
                cout << "Location: " << products[i].location << "\n";
                return;
            }
        }
        cout << "Product not found.\n";
    }
    
    void displayProducts() {
        for (int i = 0; i < productCount; ++i) {
            cout << "Product ID: " << products[i].id << ", ";
            cout << "Name: " << products[i].name << ", ";
            cout << "Price: " << products[i].price << ", ";
            cout << "Location: " << products[i].location << "\n";
        }
    }
};

int main() {
    SupermarketSystem sms;
    sms.addProduct(1, "Apple", 0.5, "Aisle 1");
    sms.addProduct(2, "Banana", 0.3, "Aisle 1");
    
    cout << "Initial product list:\n";
    sms.displayProducts();
    
    sms.searchProduct(1);
    
    sms.updateProduct(1, "Green Apple", 0.6, "Aisle 2");
    cout << "After updating product 1:\n";
    sms.displayProducts();
    
    sms.deleteProduct(2);
    cout << "After deleting product 2:\n";
    sms.displayProducts();
    
    return 0;
}