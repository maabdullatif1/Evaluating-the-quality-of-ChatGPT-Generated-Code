#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Product {
    int id;
    string name;
    string location;
    double price;
    int quantity;
};

class SupermarketSystem {
private:
    vector<Product> products;
    int nextId = 1;

public:
    void addProduct(const string& name, const string& location, double price, int quantity) {
        Product product{ nextId++, name, location, price, quantity };
        products.push_back(product);
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return;
            }
        }
    }

    void updateProduct(int id, const string& name, const string& location, double price, int quantity) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.location = location;
                product.price = price;
                product.quantity = quantity;
                return;
            }
        }
    }

    void searchProduct(int id) {
        for (const auto& product : products) {
            if (product.id == id) {
                cout << "ID: " << product.id
                     << " Name: " << product.name
                     << " Location: " << product.location
                     << " Price: " << product.price
                     << " Quantity: " << product.quantity << endl;
                return;
            }
        }
    }

    void displayProducts() {
        for (const auto& product : products) {
            cout << "ID: " << product.id
                 << " Name: " << product.name
                 << " Location: " << product.location
                 << " Price: " << product.price
                 << " Quantity: " << product.quantity << endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct("Milk", "Aisle 1", 1.99, 50);
    system.addProduct("Bread", "Aisle 2", 0.99, 100);
    system.displayProducts();
    system.updateProduct(1, "Skim Milk", "Aisle 1", 1.49, 30);
    system.searchProduct(1);
    system.deleteProduct(2);
    system.displayProducts();
    return 0;
}