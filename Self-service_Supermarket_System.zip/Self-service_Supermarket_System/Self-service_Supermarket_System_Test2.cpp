#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Product {
public:
    int id;
    string name;
    double price;
    string location;

    Product(int id, string name, double price, string location)
        : id(id), name(name), price(price), location(location) {}
};

class SupermarketSystem {
    vector<Product> products;
    int nextId = 1;

public:
    void addProduct(string name, double price, string location) {
        products.push_back(Product(nextId++, name, price, location));
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return;
            }
        }
    }

    void updateProduct(int id, string name, double price, string location) {
        for (auto &product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
            }
        }
    }

    Product* searchProduct(int id) {
        for (auto &product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    void displayProducts() {
        for (const auto &product : products) {
            cout << "ID: " << product.id
                 << " | Name: " << product.name
                 << " | Price: " << product.price
                 << " | Location: " << product.location << endl;
        }
    }
};

int main() {
    SupermarketSystem supermarket;
    supermarket.addProduct("Apple", 0.5, "Aisle 1");
    supermarket.addProduct("Banana", 0.3, "Aisle 1");
    supermarket.displayProducts();

    supermarket.updateProduct(1, "Green Apple", 0.6, "Aisle 2");
    supermarket.displayProducts();

    supermarket.deleteProduct(2);
    supermarket.displayProducts();

    Product* product = supermarket.searchProduct(1);
    if (product) {
        cout << "Found product: " << product->name << " at " << product->location << endl;
    }

    return 0;
}