#include <iostream>
#include <string>

const int MAX_PRODUCTS = 100;

struct Product {
    int id;
    std::string name;
    double price;
    std::string location;
};

class Supermarket {
private:
    Product products[MAX_PRODUCTS];
    int productCount;

public:
    Supermarket() : productCount(0) {}

    void addProduct(int id, const std::string& name, double price, const std::string& location) {
        if (productCount < MAX_PRODUCTS) {
            products[productCount].id = id;
            products[productCount].name = name;
            products[productCount].price = price;
            products[productCount].location = location;
            productCount++;
        }
    }

    void deleteProduct(int id) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                for (int j = i; j < productCount - 1; ++j) {
                    products[j] = products[j + 1];
                }
                productCount--;
                break;
            }
        }
    }

    void updateProduct(int id, const std::string& name, double price, const std::string& location) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                products[i].name = name;
                products[i].price = price;
                products[i].location = location;
                break;
            }
        }
    }

    void searchProduct(int id) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                std::cout << "Product Found: ID=" << products[i].id 
                          << ", Name=" << products[i].name 
                          << ", Price=" << products[i].price 
                          << ", Location=" << products[i].location << "\n";
                return;
            }
        }
        std::cout << "Product not found.\n";
    }

    void displayProducts() {
        for (int i = 0; i < productCount; ++i) {
            std::cout << "ID: " << products[i].id 
                      << ", Name: " << products[i].name 
                      << ", Price: " << products[i].price 
                      << ", Location: " << products[i].location << "\n";
        }
    }
};

int main() {
    Supermarket supermarket;
    supermarket.addProduct(1, "Apples", 2.99, "Aisle 1");
    supermarket.addProduct(2, "Bananas", 1.49, "Aisle 1");
    supermarket.addProduct(3, "Carrots", 0.99, "Aisle 2");

    std::cout << "Products in supermarket:\n";
    supermarket.displayProducts();

    std::cout << "Searching for product ID 2:\n";
    supermarket.searchProduct(2);

    std::cout << "Updating product ID 3:\n";
    supermarket.updateProduct(3, "Organic Carrots", 1.19, "Aisle 2");
    supermarket.displayProducts();

    std::cout << "Deleting product ID 1:\n";
    supermarket.deleteProduct(1);
    supermarket.displayProducts();

    return 0;
}