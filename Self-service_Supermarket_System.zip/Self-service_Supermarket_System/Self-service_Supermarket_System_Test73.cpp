#include <iostream>
#include <string>

const int MAX_PRODUCTS = 100;

struct Product {
    int id;
    std::string name;
    std::string location;
    double price;
    int quantity;
};

class SupermarketSystem {
    Product products[MAX_PRODUCTS];
    int productCount;

public:
    SupermarketSystem() : productCount(0) {}

    void addProduct(int id, const std::string& name, const std::string& location, double price, int quantity) {
        if (productCount < MAX_PRODUCTS) {
            products[productCount++] = {id, name, location, price, quantity};
            std::cout << "Product added successfully.\n";
        } else {
            std::cout << "Cannot add more products.\n";
        }
    }

    void deleteProduct(int id) {
        bool found = false;
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                found = true;
                for (int j = i; j < productCount - 1; ++j)
                    products[j] = products[j + 1];
                --productCount;
                std::cout << "Product deleted successfully.\n";
                break;
            }
        }
        if (!found) std::cout << "Product not found.\n";
    }

    void updateProduct(int id, const std::string& name, const std::string& location, double price, int quantity) {
        bool found = false;
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                products[i] = {id, name, location, price, quantity};
                found = true;
                std::cout << "Product updated successfully.\n";
                break;
            }
        }
        if (!found) std::cout << "Product not found.\n";
    }

    void searchProduct(int id) {
        bool found = false;
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                found = true;
                std::cout << "Product ID: " << products[i].id << "\n";
                std::cout << "Name: " << products[i].name << "\n";
                std::cout << "Location: " << products[i].location << "\n";
                std::cout << "Price: $" << products[i].price << "\n";
                std::cout << "Quantity: " << products[i].quantity << "\n";
                break;
            }
        }
        if (!found) std::cout << "Product not found.\n";
    }

    void displayProducts() {
        if (productCount == 0) {
            std::cout << "No products available.\n";
            return;
        }
        for (int i = 0; i < productCount; ++i) {
            std::cout << "Product ID: " << products[i].id << "\n";
            std::cout << "Name: " << products[i].name << "\n";
            std::cout << "Location: " << products[i].location << "\n";
            std::cout << "Price: $" << products[i].price << "\n";
            std::cout << "Quantity: " << products[i].quantity << "\n\n";
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct(1, "Apple", "Aisle 1", 1.00, 100);
    system.addProduct(2, "Banana", "Aisle 1", 0.50, 150);
    system.displayProducts();
    system.searchProduct(1);
    system.updateProduct(1, "Green Apple", "Aisle 2", 1.20, 120);
    system.searchProduct(1);
    system.deleteProduct(2);
    system.displayProducts();
    return 0;
}