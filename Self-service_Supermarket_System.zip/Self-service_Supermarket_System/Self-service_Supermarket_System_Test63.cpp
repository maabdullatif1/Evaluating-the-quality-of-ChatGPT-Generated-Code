#include <iostream>
#include <string>
#include <vector>

struct Product {
    std::string name;
    double price;
    int quantity;
    std::string location;
};

class SupermarketSystem {
private:
    std::vector<Product> products;

public:
    void addProduct(const std::string& name, double price, int quantity, const std::string& location) {
        products.push_back({name, price, quantity, location});
    }

    void deleteProduct(const std::string& name) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->name == name) {
                products.erase(it);
                return;
            }
        }
        std::cout << "Product not found.\n";
    }

    void updateProduct(const std::string& name, double price, int quantity, const std::string& location) {
        for (auto& product : products) {
            if (product.name == name) {
                product.price = price;
                product.quantity = quantity;
                product.location = location;
                return;
            }
        }
        std::cout << "Product not found.\n";
    }

    void searchProduct(const std::string& name) const {
        for (const auto& product : products) {
            if (product.name == name) {
                std::cout << "Name: " << product.name
                          << ", Price: " << product.price
                          << ", Quantity: " << product.quantity
                          << ", Location: " << product.location << "\n";
                return;
            }
        }
        std::cout << "Product not found.\n";
    }

    void displayProducts() const {
        for (const auto& product : products) {
            std::cout << "Name: " << product.name
                      << ", Price: " << product.price
                      << ", Quantity: " << product.quantity
                      << ", Location: " << product.location << "\n";
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct("Apple", 0.5, 100, "Aisle 1");
    system.addProduct("Milk", 1.2, 50, "Aisle 2");
    system.displayProducts();
    system.searchProduct("Apple");
    system.updateProduct("Apple", 0.4, 120, "Aisle 1B");
    system.searchProduct("Apple");
    system.deleteProduct("Milk");
    system.displayProducts();
    return 0;
}