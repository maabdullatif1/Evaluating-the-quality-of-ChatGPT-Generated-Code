#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Product {
public:
    int id;
    string name;
    double price;
    int locationId;

    Product(int pId, string pName, double pPrice, int locId)
        : id(pId), name(pName), price(pPrice), locationId(locId) {}
};

class Location {
public:
    int id;
    string name;

    Location(int locId, string locName) : id(locId), name(locName) {}
};

class Supermarket {
private:
    vector<Product> products;
    vector<Location> locations;

public:
    void addProduct(int id, string name, double price, int locationId) {
        products.push_back(Product(id, name, price, locationId));
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return;
            }
        }
    }

    void updateProduct(int id, string name, double price, int locationId) {
        for (auto &product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.locationId = locationId;
                return;
            }
        }
    }

    void searchProduct(int id) {
        for (const auto &product : products) {
            if (product.id == id) {
                cout << "Product Found: " << product.id << ", " << product.name 
                     << ", $" << product.price << ", Location ID: " << product.locationId << endl;
                return;
            }
        }
        cout << "Product not found." << endl;
    }

    void displayProducts() {
        for (const auto &product : products) {
            cout << "ID: " << product.id << ", Name: " << product.name 
                 << ", Price: $" << product.price << ", Location ID: " << product.locationId << endl;
        }
    }

    void addLocation(int id, string name) {
        locations.push_back(Location(id, name));
    }

    void deleteLocation(int id) {
        for (auto it = locations.begin(); it != locations.end(); ++it) {
            if (it->id == id) {
                locations.erase(it);
                return;
            }
        }
    }

    void updateLocation(int id, string name) {
        for (auto &location : locations) {
            if (location.id == id) {
                location.name = name;
                return;
            }
        }
    }

    void searchLocation(int id) {
        for (const auto &location : locations) {
            if (location.id == id) {
                cout << "Location Found: " << location.id << ", " << location.name << endl;
                return;
            }
        }
        cout << "Location not found." << endl;
    }

    void displayLocations() {
        for (const auto &location : locations) {
            cout << "ID: " << location.id << ", Name: " << location.name << endl;
        }
    }
};

int main() {
    Supermarket supermarket;

    supermarket.addProduct(1, "Apple", 0.99, 101);
    supermarket.addProduct(2, "Banana", 1.29, 101);
    supermarket.addProduct(3, "Milk", 2.49, 102);

    supermarket.addLocation(101, "Fruit Section");
    supermarket.addLocation(102, "Dairy Section");

    cout << "Displaying Products:" << endl;
    supermarket.displayProducts();

    cout << "\nDisplaying Locations:" << endl;
    supermarket.displayLocations();

    cout << "\nSearching Product with ID 1:" << endl;
    supermarket.searchProduct(1);

    cout << "\nUpdating Product with ID 3:" << endl;
    supermarket.updateProduct(3, "Soy Milk", 2.89, 102);
    supermarket.searchProduct(3);

    cout << "\nDeleting Product with ID 2:" << endl;
    supermarket.deleteProduct(2);
    supermarket.displayProducts();

    return 0;
}