#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Product {
    int id;
    string name;
    double price;
    string location;
};

class Supermarket {
private:
    vector<Product> products;

    int findProductIndex(int id) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].id == id)
                return i;
        }
        return -1;
    }

public:
    void addProduct(int id, string name, double price, string location) {
        if (findProductIndex(id) == -1) {
            products.push_back({id, name, price, location});
        } else {
            cout << "Product with ID " << id << " already exists.\n";
        }
    }

    void deleteProduct(int id) {
        int index = findProductIndex(id);
        if (index != -1) {
            products.erase(products.begin() + index);
        } else {
            cout << "Product not found.\n";
        }
    }

    void updateProduct(int id, string name, double price, string location) {
        int index = findProductIndex(id);
        if (index != -1) {
            products[index] = {id, name, price, location};
        } else {
            cout << "Product not found.\n";
        }
    }

    void searchProduct(int id) {
        int index = findProductIndex(id);
        if (index != -1) {
            cout << "Product ID: " << products[index].id << "\n";
            cout << "Product Name: " << products[index].name << "\n";
            cout << "Product Price: " << products[index].price << "\n";
            cout << "Product Location: " << products[index].location << "\n";
        } else {
            cout << "Product not found.\n";
        }
    }

    void displayProducts() {
        for (const auto& product : products) {
            cout << "Product ID: " << product.id << "\n";
            cout << "Product Name: " << product.name << "\n";
            cout << "Product Price: " << product.price << "\n";
            cout << "Product Location: " << product.location << "\n\n";
        }
    }
};

int main() {
    Supermarket sm;
    sm.addProduct(1, "Apple", 0.5, "Aisle 1");
    sm.addProduct(2, "Bread", 1.5, "Aisle 2");
    sm.displayProducts();
    sm.searchProduct(1);
    sm.updateProduct(1, "Green Apple", 0.4, "Aisle 1");
    sm.displayProducts();
    sm.deleteProduct(2);
    sm.displayProducts();
    return 0;
}