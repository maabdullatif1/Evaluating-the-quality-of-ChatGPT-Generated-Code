#include <iostream>
#include <string>
using namespace std;

class Product {
public:
    int id;
    string name;
    float price;
    string location;
    Product* next;

    Product(int id, const string& name, float price, const string& location)
        : id(id), name(name), price(price), location(location), next(nullptr) {}
};

class Supermarket {
private:
    Product* head;
public:
    Supermarket() : head(nullptr) {}

    void addProduct(int id, const string& name, float price, const string& location) {
        Product* newProduct = new Product(id, name, price, location);
        newProduct->next = head;
        head = newProduct;
    }

    void deleteProduct(int id) {
        Product* temp = head;
        Product* prev = nullptr;
        while (temp != nullptr && temp->id != id) {
            prev = temp;
            temp = temp->next;
        }
        if (temp == nullptr) return;
        if (prev == nullptr) head = head->next;
        else prev->next = temp->next;
        delete temp;
    }

    void updateProduct(int id, const string& name, float price, const string& location) {
        Product* temp = head;
        while (temp != nullptr) {
            if (temp->id == id) {
                temp->name = name;
                temp->price = price;
                temp->location = location;
                return;
            }
            temp = temp->next;
        }
    }

    Product* searchProduct(int id) {
        Product* temp = head;
        while (temp != nullptr) {
            if (temp->id == id) return temp;
            temp = temp->next;
        }
        return nullptr;
    }

    void displayProducts() {
        Product* temp = head;
        while (temp != nullptr) {
            cout << "ID: " << temp->id << ", Name: " << temp->name
                 << ", Price: " << temp->price << ", Location: " << temp->location << endl;
            temp = temp->next;
        }
    }
};

int main() {
    Supermarket supermarket;
    supermarket.addProduct(1, "Milk", 2.50, "Aisle 1");
    supermarket.addProduct(2, "Bread", 1.50, "Aisle 2");
    supermarket.displayProducts();
    supermarket.updateProduct(1, "Organic Milk", 3.00, "Aisle 1");
    supermarket.displayProducts();
    supermarket.deleteProduct(2);
    supermarket.displayProducts();
    Product* found = supermarket.searchProduct(1);
    if (found != nullptr) {
        cout << "Found Product: " << found->name << endl;
    }
    return 0;
}