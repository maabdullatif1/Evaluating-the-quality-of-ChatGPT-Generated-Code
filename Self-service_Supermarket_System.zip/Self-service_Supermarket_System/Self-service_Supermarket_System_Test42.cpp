#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    int id;
    std::string name;
    double price;
    std::string location;

    Product(int id, std::string name, double price, std::string location)
        : id(id), name(name), price(price), location(location) {}
};

class Supermarket {
private:
    std::vector<Product> products;

public:
    void addProduct(int id, std::string name, double price, std::string location) {
        products.push_back(Product(id, name, price, location));
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return;
            }
        }
    }

    void updateProduct(int id, std::string newName, double newPrice, std::string newLocation) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = newName;
                product.price = newPrice;
                product.location = newLocation;
                return;
            }
        }
    }

    void searchProduct(int id) {
        for (const auto& product : products) {
            if (product.id == id) {
                std::cout << "Product ID: " << product.id << ", "
                          << "Name: " << product.name << ", "
                          << "Price: " << product.price << ", "
                          << "Location: " << product.location << std::endl;
                return;
            }
        }
        std::cout << "Product not found." << std::endl;
    }

    void displayProducts() {
        for (const auto& product : products) {
            std::cout << "Product ID: " << product.id << ", "
                      << "Name: " << product.name << ", "
                      << "Price: " << product.price << ", "
                      << "Location: " << product.location << std::endl;
        }
    }
};

int main() {
    Supermarket supermarket;

    supermarket.addProduct(1, "Milk", 1.99, "Aisle 1");
    supermarket.addProduct(2, "Bread", 2.49, "Aisle 2");
    supermarket.addProduct(3, "Eggs", 3.59, "Refrigerator");

    std::cout << "All Products:" << std::endl;
    supermarket.displayProducts();

    std::cout << "\nSearching for Product ID 2:" << std::endl;
    supermarket.searchProduct(2);

    std::cout << "\nUpdating Product ID 3:" << std::endl;
    supermarket.updateProduct(3, "Large Eggs", 3.99, "Aisle 5");

    std::cout << "\nAll Products after Update:" << std::endl;
    supermarket.displayProducts();

    std::cout << "\nDeleting Product ID 1:" << std::endl;
    supermarket.deleteProduct(1);

    std::cout << "\nAll Products after Deletion:" << std::endl;
    supermarket.displayProducts();

    return 0;
}