#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    int id;
    std::string name;
    double price;

    Product(int id, std::string name, double price) : id(id), name(name), price(price) {}
};

class Location {
public:
    int id;
    std::string name;

    Location(int id, std::string name) : id(id), name(name) {}
};

class Supermarket {
    std::vector<Product> products;
    std::vector<Location> locations;

public:
    void addProduct(int id, std::string name, double price) {
        products.push_back(Product(id, name, price));
    }

    void addLocation(int id, std::string name) {
        locations.push_back(Location(id, name));
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void deleteLocation(int id) {
        for (auto it = locations.begin(); it != locations.end(); ++it) {
            if (it->id == id) {
                locations.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, std::string name, double price) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                break;
            }
        }
    }

    void updateLocation(int id, std::string name) {
        for (auto& location : locations) {
            if (location.id == id) {
                location.name = name;
                break;
            }
        }
    }

    Product* searchProduct(int id) {
        for (auto& product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    Location* searchLocation(int id) {
        for (auto& location : locations) {
            if (location.id == id) {
                return &location;
            }
        }
        return nullptr;
    }

    void displayProducts() {
        for (const auto& product : products) {
            std::cout << "Product ID: " << product.id
                      << ", Name: " << product.name
                      << ", Price: " << product.price << std::endl;
        }
    }

    void displayLocations() {
        for (const auto& location : locations) {
            std::cout << "Location ID: " << location.id
                      << ", Name: " << location.name << std::endl;
        }
    }
};

int main() {
    Supermarket supermarket;
    supermarket.addProduct(1, "Milk", 1.50);
    supermarket.addProduct(2, "Bread", 1.00);
    supermarket.addLocation(101, "Aisle 1");
    supermarket.addLocation(102, "Aisle 2");

    supermarket.displayProducts();
    supermarket.displayLocations();

    supermarket.updateProduct(1, "Almond Milk", 2.00);
    supermarket.updateLocation(101, "Dairy Section");

    supermarket.displayProducts();
    supermarket.displayLocations();

    Product* product = supermarket.searchProduct(1);
    if (product) {
        std::cout << "Found product - ID: " << product->id << ", Name: " << product->name << std::endl;
    }

    supermarket.deleteProduct(2);
    supermarket.deleteLocation(102);

    supermarket.displayProducts();
    supermarket.displayLocations();

    return 0;
}