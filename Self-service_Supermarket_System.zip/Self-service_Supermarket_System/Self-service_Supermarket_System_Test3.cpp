#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Product {
    int id;
    string name;
    string location;
    double price;
    int quantity;
};

class SupermarketSystem {
private:
    vector<Product> products;
    int generateProductId() {
        return products.empty() ? 1 : products.back().id + 1;
    }
public:
    void addProduct(const string& name, const string& location, double price, int quantity) {
        Product product = {generateProductId(), name, location, price, quantity};
        products.push_back(product);
    }
    
    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }
    
    void updateProduct(int id, const string& name, const string& location, double price, int quantity) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.location = location;
                product.price = price;
                product.quantity = quantity;
                break;
            }
        }
    }
    
    Product* searchProduct(int id) {
        for (auto& product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }
    
    void displayProducts() {
        if (products.empty()) {
            cout << "No products available." << endl;
            return;
        }
        for (const auto& product : products) {
            cout << "ID: " << product.id 
                 << ", Name: " << product.name 
                 << ", Location: " << product.location 
                 << ", Price: $" << product.price 
                 << ", Quantity: " << product.quantity << endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct("Apple", "Aisle 1", 0.99, 100);
    system.addProduct("Banana", "Aisle 2", 1.29, 150);
    system.displayProducts();
    
    system.updateProduct(1, "Green Apple", "Aisle 1", 1.19, 120);
    system.displayProducts();
    
    Product* product = system.searchProduct(2);
    if (product) {
        cout << "Found Product - ID: " << product->id 
             << ", Name: " << product->name << endl;
    }
    
    system.deleteProduct(1);
    system.displayProducts();
    
    return 0;
}