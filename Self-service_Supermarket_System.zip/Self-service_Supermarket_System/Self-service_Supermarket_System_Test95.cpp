#include <iostream>
#include <string>
#include <vector>

class Product {
public:
    int id;
    std::string name;
    double price;

    Product(int i, const std::string& n, double p)
        : id(i), name(n), price(p) {}
};

class Location {
public:
    int id;
    std::string name;
    std::string address;

    Location(int i, const std::string& n, const std::string& a)
        : id(i), name(n), address(a) {}
};

class Supermarket {
private:
    std::vector<Product> products;
    std::vector<Location> locations;

public:
    void addProduct(int id, const std::string& name, double price) {
        products.emplace_back(id, name, price);
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, const std::string& name, double price) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                break;
            }
        }
    }

    Product* searchProduct(int id) {
        for (auto& product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    void displayProducts() {
        for (const auto& product : products) {
            std::cout << "Product ID: " << product.id << " Name: " << product.name << " Price: " << product.price << '\n';
        }
    }

    void addLocation(int id, const std::string& name, const std::string& address) {
        locations.emplace_back(id, name, address);
    }

    void deleteLocation(int id) {
        for (auto it = locations.begin(); it != locations.end(); ++it) {
            if (it->id == id) {
                locations.erase(it);
                break;
            }
        }
    }

    void updateLocation(int id, const std::string& name, const std::string& address) {
        for (auto& location : locations) {
            if (location.id == id) {
                location.name = name;
                location.address = address;
                break;
            }
        }
    }

    Location* searchLocation(int id) {
        for (auto& location : locations) {
            if (location.id == id) {
                return &location;
            }
        }
        return nullptr;
    }

    void displayLocations() {
        for (const auto& location : locations) {
            std::cout << "Location ID: " << location.id << " Name: " << location.name << " Address: " << location.address << '\n';
        }
    }
};

int main() {
    Supermarket supermarket;
    supermarket.addProduct(1, "Apple", 0.99);
    supermarket.addProduct(2, "Banana", 1.29);
    supermarket.addLocation(1, "Main Store", "1234 Elm Street");
    supermarket.addLocation(2, "Branch Store", "5678 Oak Street");

    std::cout << "Products:\n";
    supermarket.displayProducts();
    std::cout << "\nLocations:\n";
    supermarket.displayLocations();

    supermarket.updateProduct(1, "Red Apple", 1.09);
    supermarket.updateLocation(1, "Main Supermarket", "1234 Elm Street, Suite 1");

    std::cout << "\nUpdated Products:\n";
    supermarket.displayProducts();
    std::cout << "\nUpdated Locations:\n";
    supermarket.displayLocations();
    
    return 0;
}