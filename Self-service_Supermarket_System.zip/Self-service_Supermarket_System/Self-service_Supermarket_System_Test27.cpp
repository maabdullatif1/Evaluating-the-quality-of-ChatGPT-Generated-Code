#include <iostream>
#include <vector>
#include <string>

struct Product {
    int id;
    std::string name;
    int quantity;
    double price;
};

struct Location {
    int id;
    std::string name;
};

class Supermarket {
private:
    std::vector<Product> products;
    std::vector<Location> locations;

    Product* findProductById(int id) {
        for (auto& product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    Location* findLocationById(int id) {
        for (auto& location : locations) {
            if (location.id == id) {
                return &location;
            }
        }
        return nullptr;
    }

public:
    void addProduct(int id, const std::string& name, int quantity, double price) {
        if (findProductById(id)) return;
        products.push_back({id, name, quantity, price});
    }

    void deleteProduct(int id) {
        products.erase(std::remove_if(products.begin(), products.end(), [&](Product& p){ return p.id == id; }), products.end());
    }

    void updateProduct(int id, const std::string& name, int quantity, double price) {
        Product* product = findProductById(id);
        if (product) {
            product->name = name;
            product->quantity = quantity;
            product->price = price;
        }
    }

    Product* searchProduct(int id) {
        return findProductById(id);
    }

    void displayProducts() {
        for (const auto& product : products) {
            std::cout << "ID: " << product.id << ", Name: " << product.name << ", Quantity: " << product.quantity << ", Price: " << product.price << "\n";
        }
    }

    void addLocation(int id, const std::string& name) {
        if (findLocationById(id)) return;
        locations.push_back({id, name});
    }

    void deleteLocation(int id) {
        locations.erase(std::remove_if(locations.begin(), locations.end(), [&](Location& l){ return l.id == id; }), locations.end());
    }

    void updateLocation(int id, const std::string& name) {
        Location* location = findLocationById(id);
        if (location) {
            location->name = name;
        }
    }

    Location* searchLocation(int id) {
        return findLocationById(id);
    }

    void displayLocations() {
        for (const auto& location : locations) {
            std::cout << "ID: " << location.id << ", Name: " << location.name << "\n";
        }
    }
};

int main() {
    Supermarket sm;
    sm.addProduct(1, "Apple", 100, 0.5);
    sm.addProduct(2, "Banana", 150, 0.3);
    sm.displayProducts();

    sm.addLocation(1, "Aisle 1");
    sm.addLocation(2, "Aisle 2");
    sm.displayLocations();

    Product* p = sm.searchProduct(1);
    if (p) std::cout << "Found product: " << p->name << "\n";

    sm.updateProduct(1, "Green Apple", 120, 0.55);
    sm.displayProducts();

    sm.deleteProduct(2);
    sm.displayProducts();

    Location* l = sm.searchLocation(2);
    if (l) std::cout << "Found location: " << l->name << "\n";

    sm.updateLocation(1, "Aisle 1A");
    sm.displayLocations();

    sm.deleteLocation(2);
    sm.displayLocations();

    return 0;
}