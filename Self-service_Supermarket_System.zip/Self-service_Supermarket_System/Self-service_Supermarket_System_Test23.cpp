#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Product {
public:
    int id;
    string name;
    double price;
    
    Product(int id, string name, double price) : id(id), name(name), price(price) {}
};

class Location {
public:
    int id;
    string aisle;
    
    Location(int id, string aisle) : id(id), aisle(aisle) {}
};

class SupermarketSystem {
    vector<Product> products;
    vector<Location> locations;
    
public:
    void addProduct(int id, string name, double price) {
        products.push_back(Product(id, name, price));
    }
    
    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return;
            }
        }
    }
    
    void updateProduct(int id, string name, double price) {
        for (auto &product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                return;
            }
        }
    }
    
    Product* searchProduct(int id) {
        for (auto &product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }
    
    void displayProducts() {
        for (const auto &product : products) {
            cout << "Product ID: " << product.id << ", Name: " << product.name << ", Price: $" << product.price << endl;
        }
    }
    
    void addLocation(int id, string aisle) {
        locations.push_back(Location(id, aisle));
    }
    
    void deleteLocation(int id) {
        for (auto it = locations.begin(); it != locations.end(); ++it) {
            if (it->id == id) {
                locations.erase(it);
                return;
            }
        }
    }
    
    void updateLocation(int id, string aisle) {
        for (auto &location : locations) {
            if (location.id == id) {
                location.aisle = aisle;
                return;
            }
        }
    }
    
    Location* searchLocation(int id) {
        for (auto &location : locations) {
            if (location.id == id) {
                return &location;
            }
        }
        return nullptr;
    }
    
    void displayLocations() {
        for (const auto &location : locations) {
            cout << "Location ID: " << location.id << ", Aisle: " << location.aisle << endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct(1, "Apple", 0.99);
    system.addProduct(2, "Banana", 0.59);
    system.addLocation(101, "Aisle 1");
    system.addLocation(102, "Aisle 2");
    
    cout << "Products:" << endl;
    system.displayProducts();
    
    cout << "Locations:" << endl;
    system.displayLocations();
    
    return 0;
}