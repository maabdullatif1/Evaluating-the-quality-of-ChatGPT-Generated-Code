#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Product {
    int id;
    string name;
    float price;
    string location;
};

class SupermarketSystem {
    vector<Product> products;
    int findProductIndex(int id) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].id == id) return i;
        }
        return -1;
    }
public:
    void addProduct(int id, string name, float price, string location) {
        if (findProductIndex(id) != -1) {
            cout << "Product with given ID already exists." << endl;
            return;
        }
        products.push_back({id, name, price, location});
    }

    void deleteProduct(int id) {
        int index = findProductIndex(id);
        if (index == -1) {
            cout << "Product not found." << endl;
            return;
        }
        products.erase(products.begin() + index);
    }

    void updateProduct(int id, string name, float price, string location) {
        int index = findProductIndex(id);
        if (index == -1) {
            cout << "Product not found." << endl;
            return;
        }
        products[index] = {id, name, price, location};
    }

    void searchProduct(int id) {
        int index = findProductIndex(id);
        if (index == -1) {
            cout << "Product not found." << endl;
            return;
        }
        cout << "ID: " << products[index].id 
             << ", Name: " << products[index].name 
             << ", Price: " << products[index].price 
             << ", Location: " << products[index].location << endl;
    }

    void displayProducts() {
        if (products.empty()) {
            cout << "No products available." << endl;
            return;
        }
        for (const auto& product : products) {
            cout << "ID: " << product.id 
                 << ", Name: " << product.name 
                 << ", Price: " << product.price 
                 << ", Location: " << product.location << endl;
        }
    }
};

int main() {
    SupermarketSystem sys;
    sys.addProduct(1, "Apples", 1.99, "Aisle 1");
    sys.addProduct(2, "Bananas", 0.99, "Aisle 2");
    sys.updateProduct(1, "Green Apples", 2.49, "Aisle 1");
    sys.searchProduct(1);
    sys.searchProduct(3);
    sys.displayProducts();
    sys.deleteProduct(2);
    sys.displayProducts();
    return 0;
}