#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    int id;
    std::string name;
    float price;

    Product(int pid, std::string pname, float pprice)
        : id(pid), name(pname), price(pprice) {}
};

class Location {
public:
    std::string aisle;
    int shelf;

    Location(std::string p_aisle, int p_shelf)
        : aisle(p_aisle), shelf(p_shelf) {}
};

class SupermarketSystem {
private:
    std::vector<Product> products;
    std::vector<Location> locations;

public:
    void addProduct(int id, std::string name, float price, std::string aisle, int shelf) {
        products.push_back(Product(id, name, price));
        locations.push_back(Location(aisle, shelf));
    }

    void deleteProduct(int id) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].id == id) {
                products.erase(products.begin() + i);
                locations.erase(locations.begin() + i);
                return;
            }
        }
    }

    void updateProduct(int id, std::string name, float price, std::string aisle, int shelf) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].id == id) {
                products[i].name = name;
                products[i].price = price;
                locations[i].aisle = aisle;
                locations[i].shelf = shelf;
                return;
            }
        }
    }

    void searchProduct(int id) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].id == id) {
                std::cout << "Product ID: " << products[i].id
                          << ", Name: " << products[i].name
                          << ", Price: $" << products[i].price
                          << ", Location: Aisle - " << locations[i].aisle
                          << ", Shelf - " << locations[i].shelf << '\n';
                return;
            }
        }
        std::cout << "Product not found\n";
    }

    void displayProducts() {
        for (size_t i = 0; i < products.size(); ++i) {
            std::cout << "Product ID: " << products[i].id
                      << ", Name: " << products[i].name
                      << ", Price: $" << products[i].price
                      << ", Location: Aisle - " << locations[i].aisle
                      << ", Shelf - " << locations[i].shelf << '\n';
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct(1, "Apples", 2.5, "Fruits", 1);
    system.addProduct(2, "Bananas", 1.8, "Fruits", 1);
    system.displayProducts();
    system.searchProduct(2);
    system.updateProduct(2, "Bananas", 1.9, "Fruits", 2);
    system.displayProducts();
    system.deleteProduct(1);
    system.displayProducts();
    return 0;
}