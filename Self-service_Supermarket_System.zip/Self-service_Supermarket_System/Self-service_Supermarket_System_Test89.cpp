#include <iostream>
#include <vector>
#include <string>

struct Product {
    int id;
    std::string name;
    std::string location;
    double price;
};

class SupermarketSystem {
private:
    std::vector<Product> inventory;
    int nextId;

public:
    SupermarketSystem() : nextId(1) {}

    void addProduct(const std::string& name, const std::string& location, double price) {
        Product product = {nextId++, name, location, price};
        inventory.push_back(product);
    }

    void deleteProduct(int id) {
        for (auto it = inventory.begin(); it != inventory.end(); ++it) {
            if (it->id == id) {
                inventory.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, const std::string& name, const std::string& location, double price) {
        for (auto& product : inventory) {
            if (product.id == id) {
                product.name = name;
                product.location = location;
                product.price = price;
                break;
            }
        }
    }

    Product* searchProduct(int id) {
        for (auto& product : inventory) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    void displayProducts() {
        for (const auto& product : inventory) {
            std::cout << "ID: " << product.id 
                      << ", Name: " << product.name 
                      << ", Location: " << product.location 
                      << ", Price: $" << product.price << std::endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct("Apples", "Aisle 1", 1.99);
    system.addProduct("Bananas", "Aisle 2", 0.99);
    system.displayProducts();
    system.updateProduct(1, "Green Apples", "Aisle 1", 2.29);
    system.displayProducts();
    Product* product = system.searchProduct(2);
    if (product) {
        std::cout << "Found Product - ID: " << product->id << ", Name: " << product->name << std::endl;
    }
    system.deleteProduct(1);
    system.displayProducts();
    return 0;
}