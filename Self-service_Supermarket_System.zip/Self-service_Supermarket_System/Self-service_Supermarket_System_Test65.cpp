#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Product {
    int id;
    string name;
    double price;
};

struct Location {
    int id;
    string description;
};

class SupermarketSystem {
public:
    void addProduct(int id, const string &name, double price) {
        products.push_back({id, name, price});
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, const string &name, double price) {
        for (auto &product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                break;
            }
        }
    }

    Product* searchProduct(int id) {
        for (auto &product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    void displayProducts() const {
        for (const auto &product : products) {
            cout << "ID: " << product.id << ", Name: " << product.name 
                 << ", Price: " << product.price << endl;
        }
    }

    void addLocation(int id, const string &description) {
        locations.push_back({id, description});
    }

    void deleteLocation(int id) {
        for (auto it = locations.begin(); it != locations.end(); ++it) {
            if (it->id == id) {
                locations.erase(it);
                break;
            }
        }
    }

    void updateLocation(int id, const string &description) {
        for (auto &location : locations) {
            if (location.id == id) {
                location.description = description;
                break;
            }
        }
    }

    Location* searchLocation(int id) {
        for (auto &location : locations) {
            if (location.id == id) {
                return &location;
            }
        }
        return nullptr;
    }

    void displayLocations() const {
        for (const auto &location : locations) {
            cout << "ID: " << location.id << ", Description: " << location.description << endl;
        }
    }

private:
    vector<Product> products;
    vector<Location> locations;
};

int main() {
    SupermarketSystem system;

    system.addProduct(1, "Apple", 0.99);
    system.addProduct(2, "Bread", 1.99);

    system.displayProducts();

    system.addLocation(101, "Aisle 1");
    system.addLocation(102, "Aisle 2");

    system.displayLocations();

    Product* product = system.searchProduct(1);
    if (product) {
        cout << "Found Product - ID: " << product->id << ", Name: " << product->name 
             << ", Price: " << product->price << endl;
    }

    Location* location = system.searchLocation(102);
    if (location) {
        cout << "Found Location - ID: " << location->id << ", Description: " << location->description << endl;
    }

    system.updateProduct(2, "Whole Wheat Bread", 2.49);
    system.updateLocation(102, "Aisle 2B");

    system.displayProducts();
    system.displayLocations();

    system.deleteProduct(1);
    system.deleteLocation(101);

    system.displayProducts();
    system.displayLocations();

    return 0;
}