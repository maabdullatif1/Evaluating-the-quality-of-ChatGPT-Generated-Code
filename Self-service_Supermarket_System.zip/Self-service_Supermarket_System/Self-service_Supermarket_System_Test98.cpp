#include <iostream>
#include <string>
#include <vector>

struct Product {
    int id;
    std::string name;
    float price;
    std::string location;
};

class Supermarket {
private:
    std::vector<Product> products;
    int nextId;

public:
    Supermarket() : nextId(1) {}

    void addProduct(const std::string& name, float price, const std::string& location) {
        products.push_back({nextId++, name, price, location});
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return;
            }
        }
    }

    void updateProduct(int id, const std::string& name, float price, const std::string& location) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                return;
            }
        }
    }

    Product* searchProduct(int id) {
        for (auto& product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    void displayProducts() const {
        for (const auto& product : products) {
            std::cout << "ID: " << product.id
                      << ", Name: " << product.name
                      << ", Price: $" << product.price
                      << ", Location: " << product.location << std::endl;
        }
    }
};

int main() {
    Supermarket sm;
    sm.addProduct("Apple", 0.5, "Aisle 1");
    sm.addProduct("Banana", 0.3, "Aisle 1");
    sm.addProduct("Chicken", 5.0, "Aisle 2");
    sm.displayProducts();
    sm.updateProduct(2, "Banana", 0.35, "Aisle 1");
    sm.deleteProduct(3);
    std::cout << "After updates:" << std::endl;
    sm.displayProducts();
    return 0;
}