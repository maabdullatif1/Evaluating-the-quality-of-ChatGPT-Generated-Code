#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    std::string name;
    double price;
    int quantity;

    Product(std::string n, double p, int q) : name(n), price(p), quantity(q) {}
};

class Location {
public:
    std::string name;
    std::vector<Product> products;

    Location(std::string n) : name(n) {}

    void addProduct(const Product& p) {
        products.push_back(p);
    }

    void deleteProduct(const std::string& productName) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->name == productName) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(const std::string& productName, double price, int quantity) {
        for (auto& product : products) {
            if (product.name == productName) {
                product.price = price;
                product.quantity = quantity;
                break;
            }
        }
    }

    void searchProduct(const std::string& productName) {
        for (const auto& product : products) {
            if (product.name == productName) {
                std::cout << "Product found: " << product.name << ", Price: " << product.price << ", Quantity: " << product.quantity << std::endl;
                return;
            }
        }
        std::cout << "Product not found." << std::endl;
    }

    void displayProducts() {
        if (products.empty()) {
            std::cout << "No products available." << std::endl;
            return;
        }
        std::cout << "Products in " << name << ":" << std::endl;
        for (const auto& product : products) {
            std::cout << "Name: " << product.name << ", Price: " << product.price << ", Quantity: " << product.quantity << std::endl;
        }
    }
};

class SupermarketSystem {
public:
    std::vector<Location> locations;

    void addLocation(const std::string& locationName) {
        locations.push_back(Location(locationName));
    }

    void deleteLocation(const std::string& locationName) {
        for (auto it = locations.begin(); it != locations.end(); ++it) {
            if (it->name == locationName) {
                locations.erase(it);
                break;
            }
        }
    }

    Location* findLocation(const std::string& locationName) {
        for (auto& location : locations) {
            if (location.name == locationName) {
                return &location;
            }
        }
        return nullptr;
    }

    void addProductToLocation(const std::string& locationName, const Product& product) {
        Location* location = findLocation(locationName);
        if (location) {
            location->addProduct(product);
        }
    }

    void deleteProductFromLocation(const std::string& locationName, const std::string& productName) {
        Location* location = findLocation(locationName);
        if (location) {
            location->deleteProduct(productName);
        }
    }

    void updateProductInLocation(const std::string& locationName, const std::string& productName, double price, int quantity) {
        Location* location = findLocation(locationName);
        if (location) {
            location->updateProduct(productName, price, quantity);
        }
    }

    void searchProductInLocation(const std::string& locationName, const std::string& productName) {
        Location* location = findLocation(locationName);
        if (location) {
            location->searchProduct(productName);
        }
    }

    void displayProductsInLocation(const std::string& locationName) {
        Location* location = findLocation(locationName);
        if (location) {
            location->displayProducts();
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addLocation("Location1");
    system.addProductToLocation("Location1", Product("Apple", 0.5, 100));
    system.addProductToLocation("Location1", Product("Banana", 0.3, 150));
    system.displayProductsInLocation("Location1");

    system.updateProductInLocation("Location1", "Apple", 0.6, 120);
    system.searchProductInLocation("Location1", "Apple");

    system.deleteProductFromLocation("Location1", "Banana");
    system.displayProductsInLocation("Location1");

    return 0;
}