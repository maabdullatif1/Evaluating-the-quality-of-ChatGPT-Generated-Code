#include <iostream>
#include <string>
#include <vector>

struct Product {
    int id;
    std::string name;
    std::string location;
    double price;
};

class Supermarket {
private:
    std::vector<Product> products;
    int generateId() {
        static int id = 1;
        return id++;
    }

public:
    void addProduct(const std::string &name, const std::string &location, double price) {
        Product p = {generateId(), name, location, price};
        products.push_back(p);
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, const std::string &name, const std::string &location, double price) {
        for (auto &product : products) {
            if (product.id == id) {
                product.name = name;
                product.location = location;
                product.price = price;
                break;
            }
        }
    }

    void searchProduct(int id) {
        for (const auto &product : products) {
            if (product.id == id) {
                std::cout << "ID: " << product.id << " Name: " << product.name 
                          << " Location: " << product.location 
                          << " Price: " << product.price << std::endl;
                return;
            }
        }
        std::cout << "Product not found" << std::endl;
    }

    void displayProducts() {
        for (const auto &product : products) {
            std::cout << "ID: " << product.id << " Name: " << product.name 
                      << " Location: " << product.location 
                      << " Price: " << product.price << std::endl;
        }
    }
};

int main() {
    Supermarket sm;
    sm.addProduct("Apple", "Aisle 1", 0.5);
    sm.addProduct("Banana", "Aisle 1", 0.3);
    sm.displayProducts();
    sm.updateProduct(1, "Green Apple", "Aisle 2", 0.6);
    sm.searchProduct(1);
    sm.deleteProduct(2);
    sm.displayProducts();
    return 0;
}