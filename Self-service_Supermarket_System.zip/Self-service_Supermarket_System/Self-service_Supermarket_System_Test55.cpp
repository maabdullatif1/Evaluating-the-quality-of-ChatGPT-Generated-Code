#include <iostream>
#include <string>

struct Product {
    int id;
    std::string name;
    double price;
    int quantity;
    std::string location;
};

struct Node {
    Product product;
    Node* next;
};

class Supermarket {
private:
    Node* head;
    
    Node* findProductById(int id) {
        Node* current = head;
        while (current) {
            if (current->product.id == id) {
                return current;
            }
            current = current->next;
        }
        return nullptr;
    }

public:
    Supermarket() : head(nullptr) {}

    void addProduct(int id, const std::string& name, double price, int quantity, const std::string& location) {
        Node* newNode = new Node{{id, name, price, quantity, location}, head};
        head = newNode;
    }

    void deleteProduct(int id) {
        Node* current = head;
        Node* previous = nullptr;
        while (current) {
            if (current->product.id == id) {
                if (previous) {
                    previous->next = current->next;
                } else {
                    head = current->next;
                }
                delete current;
                return;
            }
            previous = current;
            current = current->next;
        }
    }

    void updateProduct(int id, const std::string& name, double price, int quantity, const std::string& location) {
        Node* productNode = findProductById(id);
        if (productNode) {
            productNode->product.name = name;
            productNode->product.price = price;
            productNode->product.quantity = quantity;
            productNode->product.location = location;
        }
    }

    Product* searchProduct(int id) {
        Node* productNode = findProductById(id);
        if (productNode) {
            return &productNode->product;
        }
        return nullptr;
    }

    void displayProducts() {
        Node* current = head;
        while (current) {
            std::cout << "ID: " << current->product.id
                      << ", Name: " << current->product.name
                      << ", Price: " << current->product.price
                      << ", Quantity: " << current->product.quantity
                      << ", Location: " << current->product.location << std::endl;
            current = current->next;
        }
    }
};

int main() {
    Supermarket market;
    market.addProduct(1, "Apple", 0.5, 50, "Aisle 1");
    market.addProduct(2, "Milk", 1.2, 30, "Aisle 2");

    market.displayProducts();

    market.updateProduct(1, "Green Apple", 0.6, 40, "Aisle 1");
    
    if (Product* product = market.searchProduct(1)) {
        std::cout << "Found: " << product->name << ", Price: " << product->price << std::endl;
    }

    market.deleteProduct(2);
    market.displayProducts();

    return 0;
}