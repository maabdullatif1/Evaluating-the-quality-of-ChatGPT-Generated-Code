#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    int id;
    std::string name;
    std::string location;

    Product(int i, const std::string &n, const std::string &l) : id(i), name(n), location(l) {}
};

class Supermarket {
    std::vector<Product> products;

    int findProductIndex(int id) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].id == id) return i;
        }
        return -1;
    }

public:
    void addProduct(int id, const std::string &name, const std::string &location) {
        if (findProductIndex(id) == -1) {
            products.emplace_back(id, name, location);
        }
    }

    void deleteProduct(int id) {
        int index = findProductIndex(id);
        if (index != -1) {
            products.erase(products.begin() + index);
        }
    }

    void updateProduct(int id, const std::string &name, const std::string &location) {
        int index = findProductIndex(id);
        if (index != -1) {
            products[index].name = name;
            products[index].location = location;
        }
    }

    Product* searchProduct(int id) {
        int index = findProductIndex(id);
        return index != -1 ? &products[index] : nullptr;
    }

    void displayProducts() {
        for (const auto &product : products) {
            std::cout << "ID: " << product.id << ", Name: " << product.name
                      << ", Location: " << product.location << std::endl;
        }
    }
};

int main() {
    Supermarket supermarket;
    
    supermarket.addProduct(1, "Apple", "Aisle 1");
    supermarket.addProduct(2, "Banana", "Aisle 1");

    supermarket.displayProducts();
    
    supermarket.updateProduct(1, "Green Apple", "Aisle 2");
    supermarket.deleteProduct(2);

    supermarket.displayProducts();

    Product* product = supermarket.searchProduct(1);
    if (product) {
        std::cout << "Found product: " << product->name << ", Location: " << product->location << std::endl;
    }

    return 0;
}