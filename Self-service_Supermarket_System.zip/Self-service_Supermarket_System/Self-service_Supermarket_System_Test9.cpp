#include <iostream>
#include <vector>
#include <string>

struct Product {
    int id;
    std::string name;
    double price;
    std::string location;
};

class Supermarket {
    std::vector<Product> products;
    int nextId = 1;

    int findProductIndexById(int id) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addProduct(const std::string& name, double price, const std::string& location) {
        products.push_back({ nextId++, name, price, location });
    }

    void deleteProduct(int id) {
        int index = findProductIndexById(id);
        if (index != -1) {
            products.erase(products.begin() + index);
        }
    }

    void updateProduct(int id, const std::string& name, double price, const std::string& location) {
        int index = findProductIndexById(id);
        if (index != -1) {
            products[index].name = name;
            products[index].price = price;
            products[index].location = location;
        }
    }

    Product* searchProduct(int id) {
        int index = findProductIndexById(id);
        if (index != -1) {
            return &products[index];
        }
        return nullptr;
    }

    void displayProducts() {
        for (const auto& product : products) {
            std::cout << "ID: " << product.id 
                      << ", Name: " << product.name 
                      << ", Price: " << product.price 
                      << ", Location: " << product.location 
                      << std::endl;
        }
    }
};

int main() {
    Supermarket market;
    market.addProduct("Apple", 0.50, "Aisle 1");
    market.addProduct("Banana", 0.30, "Aisle 1");
    market.addProduct("Shampoo", 2.99, "Aisle 5");
    
    std::cout << "Initial Products:" << std::endl;
    market.displayProducts();

    market.updateProduct(2, "Banana", 0.35, "Aisle 1");
    std::cout << "\nUpdated Banana Info:" << std::endl;
    market.displayProducts();

    market.deleteProduct(1);
    std::cout << "\nAfter Deleting Apple:" << std::endl;
    market.displayProducts();

    Product* found = market.searchProduct(3);
    if (found) {
        std::cout << "\nFound Product - ID: " << found->id << ", Name: " << found->name << std::endl;
    } else {
        std::cout << "\nProduct not found." << std::endl;
    }

    return 0;
}