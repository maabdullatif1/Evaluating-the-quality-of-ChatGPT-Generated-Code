#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    int id;
    std::string name;
    double price;
    std::string location;

    Product(int i, std::string n, double p, std::string l)
        : id(i), name(n), price(p), location(l) {}
};

class SupermarketSystem {
    std::vector<Product> products;

    int findProductIndex(int id) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addProduct(int id, std::string name, double price, std::string location) {
        if (findProductIndex(id) == -1) {
            products.push_back(Product(id, name, price, location));
        }
    }

    void deleteProduct(int id) {
        int index = findProductIndex(id);
        if (index != -1) {
            products.erase(products.begin() + index);
        }
    }

    void updateProduct(int id, std::string name, double price, std::string location) {
        int index = findProductIndex(id);
        if (index != -1) {
            products[index].name = name;
            products[index].price = price;
            products[index].location = location;
        }
    }

    Product* searchProduct(int id) {
        int index = findProductIndex(id);
        if (index != -1) {
            return &products[index];
        }
        return nullptr;
    }

    void displayProducts() {
        for (size_t i = 0; i < products.size(); ++i) {
            std::cout << "ID: " << products[i].id << "\n";
            std::cout << "Name: " << products[i].name << "\n";
            std::cout << "Price: " << products[i].price << "\n";
            std::cout << "Location: " << products[i].location << "\n";
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct(1, "Apple", 0.99, "Aisle 1");
    system.addProduct(2, "Banana", 0.59, "Aisle 1");
    system.displayProducts();
    system.updateProduct(1, "Green Apple", 1.29, "Aisle 2");
    system.displayProducts();
    system.deleteProduct(2);
    system.displayProducts();
    return 0;
}