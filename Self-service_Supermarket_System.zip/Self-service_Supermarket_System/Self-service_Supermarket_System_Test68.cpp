#include <iostream>
#include <string>

using namespace std;

struct Product {
    int id;
    string name;
    double price;
    string location;
};

class SupermarketSystem {
private:
    Product products[100];
    int productCount;

public:
    SupermarketSystem() : productCount(0) {}

    void addProduct(int id, const string& name, double price, const string& location) {
        products[productCount++] = {id, name, price, location};
    }

    void deleteProduct(int id) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                for (int j = i; j < productCount - 1; ++j) {
                    products[j] = products[j + 1];
                }
                --productCount;
                break;
            }
        }
    }

    void updateProduct(int id, const string& name, double price, const string& location) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                products[i] = {id, name, price, location};
                break;
            }
        }
    }

    void searchProduct(int id) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                cout << "Product ID: " << products[i].id << endl;
                cout << "Name: " << products[i].name << endl;
                cout << "Price: " << products[i].price << endl;
                cout << "Location: " << products[i].location << endl;
                return;
            }
        }
        cout << "Product not found." << endl;
    }

    void displayProducts() {
        for (int i = 0; i < productCount; ++i) {
            cout << "Product ID: " << products[i].id << ", ";
            cout << "Name: " << products[i].name << ", ";
            cout << "Price: " << products[i].price << ", ";
            cout << "Location: " << products[i].location << endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct(1, "Milk", 1.99, "Aisle 1");
    system.addProduct(2, "Bread", 0.99, "Aisle 2");
    system.displayProducts();
    system.deleteProduct(1);
    system.updateProduct(2, "Whole Wheat Bread", 1.49, "Aisle 3");
    system.displayProducts();
    system.searchProduct(2);
    return 0;
}