#include <iostream>
#include <string>
using namespace std;

struct Product {
    string name;
    string location;
    float price;
    int quantity;
};

class Supermarket {
private:
    Product products[100];
    int productCount;

public:
    Supermarket() : productCount(0) {}

    void addProduct(const string& name, const string& location, float price, int quantity) {
        products[productCount++] = {name, location, price, quantity};
    }

    void deleteProduct(const string& name) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].name == name) {
                for (int j = i; j < productCount - 1; ++j) {
                    products[j] = products[j + 1];
                }
                productCount--;
                break;
            }
        }
    }

    void updateProduct(const string& name, const string& newLocation, float newPrice, int newQuantity) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].name == name) {
                products[i].location = newLocation;
                products[i].price = newPrice;
                products[i].quantity = newQuantity;
                break;
            }
        }
    }

    void searchProduct(const string& name) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].name == name) {
                cout << "Product Found: ";
                displayProduct(products[i]);
                return;
            }
        }
        cout << "Product not found." << endl;
    }

    void displayProduct(const Product& product) {
        cout << "Name: " << product.name << ", Location: " << product.location
             << ", Price: " << product.price << ", Quantity: " << product.quantity << endl;
    }

    void displayAllProducts() {
        if (productCount == 0) {
            cout << "No products available." << endl;
            return;
        }
        for (int i = 0; i < productCount; ++i) {
            displayProduct(products[i]);
        }
    }
};

int main() {
    Supermarket market;
    market.addProduct("Apple", "Aisle 1", 0.5, 100);
    market.addProduct("Banana", "Aisle 2", 0.3, 150);
    market.displayAllProducts();
    market.searchProduct("Apple");
    market.updateProduct("Banana", "Aisle 3", 0.25, 200);
    market.displayAllProducts();
    market.deleteProduct("Apple");
    market.displayAllProducts();
    return 0;
}