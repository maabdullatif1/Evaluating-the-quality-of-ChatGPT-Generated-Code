#include <iostream>
#include <vector>
#include <string>

struct Product {
    int id;
    std::string name;
    double price;
};

struct Location {
    int id;
    std::string name;
    std::vector<Product> products;
};

class SupermarketSystem {
private:
    std::vector<Product> products;
    std::vector<Location> locations;
    int productCounter;
    int locationCounter;

public:
    SupermarketSystem() : productCounter(1), locationCounter(1) {}

    void addProduct(const std::string& name, double price) {
        products.push_back({productCounter++, name, price});
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, const std::string& name, double price) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                break;
            }
        }
    }

    Product* searchProduct(int id) {
        for (auto& product : products) {
            if (product.id == id) return &product;
        }
        return nullptr;
    }

    void displayProducts() {
        for (auto& product : products) {
            std::cout << "ID: " << product.id << ", Name: " << product.name << ", Price: $" << product.price << std::endl;
        }
    }

    void addLocation(const std::string& name) {
        locations.push_back({locationCounter++, name});
    }

    void deleteLocation(int id) {
        for (auto it = locations.begin(); it != locations.end(); ++it) {
            if (it->id == id) {
                locations.erase(it);
                break;
            }
        }
    }

    void updateLocation(int id, const std::string& name) {
        for (auto& location : locations) {
            if (location.id == id) {
                location.name = name;
                break;
            }
        }
    }

    Location* searchLocation(int id) {
        for (auto& location : locations) {
            if (location.id == id) return &location;
        }
        return nullptr;
    }

    void displayLocations() {
        for (auto& location : locations) {
            std::cout << "ID: " << location.id << ", Name: " << location.name << std::endl;
        }
    }
};

int main() {
    SupermarketSystem system;

    system.addProduct("Apple", 0.99);
    system.addProduct("Banana", 0.59);
    system.updateProduct(1, "Red Apple", 1.09);
    system.displayProducts();

    system.addLocation("Aisle 1");
    system.addLocation("Checkout");
    system.updateLocation(2, "Checkout Counter");
    system.displayLocations();

    Product* p = system.searchProduct(1);
    if (p) std::cout << "Found product: " << p->name << std::endl;

    Location* l = system.searchLocation(1);
    if (l) std::cout << "Found location: " << l->name << std::endl;

    system.deleteProduct(1);
    system.deleteLocation(1);

    system.displayProducts();
    system.displayLocations();

    return 0;
}