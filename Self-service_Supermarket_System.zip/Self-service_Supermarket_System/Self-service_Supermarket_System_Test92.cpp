#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    int id;
    std::string name;
    double price;
    std::string location;

    Product(int id, std::string name, double price, std::string location)
        : id(id), name(name), price(price), location(location) {}

    void display() {
        std::cout << "ID: " << id << ", Name: " << name << ", Price: " << price << ", Location: " << location << std::endl;
    }
};

class SupermarketSystem {
    std::vector<Product> products;

public:
    void addProduct(int id, std::string name, double price, std::string location) {
        products.push_back(Product(id, name, price, location));
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return;
            }
        }
    }

    void updateProduct(int id, std::string name, double price, std::string location) {
        for (auto &product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                return;
            }
        }
    }

    Product* searchProduct(int id) {
        for (auto &product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    void displayProducts() {
        for (auto &product : products) {
            product.display();
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct(1, "Apple", 0.5, "Aisle 1");
    system.addProduct(2, "Banana", 0.3, "Aisle 1");
    system.addProduct(3, "Milk", 1.5, "Refrigerator 2");

    std::cout << "All Products:" << std::endl;
    system.displayProducts();

    system.updateProduct(2, "Banana", 0.25, "Aisle 2");
    std::cout << "\nAfter Updating Banana:" << std::endl;
    system.displayProducts();

    system.deleteProduct(3);
    std::cout << "\nAfter Deleting Milk:" << std::endl;
    system.displayProducts();

    std::cout << "\nSearching for Apple:" << std::endl;
    Product* product = system.searchProduct(1);
    if (product) {
        product->display();
    } else {
        std::cout << "Product not found." << std::endl;
    }

    return 0;
}