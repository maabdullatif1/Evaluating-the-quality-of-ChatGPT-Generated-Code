#include <iostream>
#include <vector>
#include <string>

struct Product {
    int id;
    std::string name;
    float price;
    std::string location;
};

class SupermarketSystem {
private:
    std::vector<Product> products;

public:
    void addProduct(int id, const std::string &name, float price, const std::string &location) {
        products.push_back({id, name, price, location});
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return;
            }
        }
    }

    void updateProduct(int id, const std::string &name, float price, const std::string &location) {
        for (auto &product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                return;
            }
        }
    }

    void searchProduct(int id) {
        for (const auto &product : products) {
            if (product.id == id) {
                displayProduct(product);
                return;
            }
        }
        std::cout << "Product not found" << std::endl;
    }

    void displayProducts() {
        for (const auto &product : products) {
            displayProduct(product);
        }
    }

private:
    void displayProduct(const Product &product) {
        std::cout << "ID: " << product.id
                  << ", Name: " << product.name
                  << ", Price: " << product.price
                  << ", Location: " << product.location
                  << std::endl;
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct(1, "Apple", 0.99, "Aisle 1");
    system.addProduct(2, "Banana", 0.59, "Aisle 1");
    system.addProduct(3, "Milk", 1.49, "Aisle 3");
    
    system.displayProducts();
    std::cout << "Searching for product with ID 2:" << std::endl;
    system.searchProduct(2);
    
    std::cout << "Updating product with ID 3:" << std::endl;
    system.updateProduct(3, "Organic Milk", 1.99, "Aisle 3");
    system.displayProducts();
    
    std::cout << "Deleting product with ID 1:" << std::endl;
    system.deleteProduct(1);
    system.displayProducts();

    return 0;
}