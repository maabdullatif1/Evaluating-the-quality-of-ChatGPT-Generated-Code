#include <iostream>
#include <string>

using namespace std;

struct Product {
    int id;
    string name;
    double price;
    string location;
};

struct Supermarket {
    Product products[100];
    int productCount;

    Supermarket() : productCount(0) {}

    void addProduct(int id, const string& name, double price, const string& location) {
        products[productCount++] = {id, name, price, location};
    }

    void deleteProduct(int id) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                for (int j = i; j < productCount - 1; ++j) {
                    products[j] = products[j + 1];
                }
                --productCount;
                break;
            }
        }
    }

    void updateProduct(int id, const string& name, double price, const string& location) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                products[i] = {id, name, price, location};
                break;
            }
        }
    }

    void searchProduct(int id) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].id == id) {
                cout << "Product found: " << products[i].name << " at " << products[i].location << "\n";
                return;
            }
        }
        cout << "Product not found.\n";
    }

    void displayProducts() {
        for (int i = 0; i < productCount; ++i) {
            cout << "ID: " << products[i].id 
                 << ", Name: " << products[i].name
                 << ", Price: " << products[i].price 
                 << ", Location: " << products[i].location << "\n";
        }
    }
};

int main() {
    Supermarket market;
    market.addProduct(1, "Apple", 0.99, "Aisle 1");
    market.addProduct(2, "Bread", 1.99, "Aisle 2");
    market.displayProducts();
    market.updateProduct(1, "Red Apple", 1.09, "Aisle 1A");
    market.searchProduct(1);
    market.deleteProduct(2);
    market.displayProducts();

    return 0;
}