#include <iostream>
#include <vector>
#include <string>

struct Product {
    int id;
    std::string name;
    double price;
    std::string location;
};

class SupermarketSystem {
public:
    void addProduct(int id, const std::string& name, double price, const std::string& location) {
        products.push_back({id, name, price, location});
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, const std::string& name, double price, const std::string& location) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                break;
            }
        }
    }

    void searchProduct(int id) const {
        for (const auto& product : products) {
            if (product.id == id) {
                displayProduct(product);
                return;
            }
        }
        std::cout << "Product not found.\n";
    }

    void displayProducts() const {
        for (const auto& product : products) {
            displayProduct(product);
        }
    }

private:
    std::vector<Product> products;

    void displayProduct(const Product& product) const {
        std::cout << "ID: " << product.id << ", Name: " << product.name 
                  << ", Price: " << product.price << ", Location: " << product.location << "\n";
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct(1, "Apple", 0.5, "Aisle 1");
    system.addProduct(2, "Banana", 0.2, "Aisle 1");
    
    system.displayProducts();
    
    system.updateProduct(1, "Green Apple", 0.6, "Aisle 2");
    system.displayProducts();
    
    system.searchProduct(2);
    
    system.deleteProduct(1);
    system.displayProducts();

    return 0;
}