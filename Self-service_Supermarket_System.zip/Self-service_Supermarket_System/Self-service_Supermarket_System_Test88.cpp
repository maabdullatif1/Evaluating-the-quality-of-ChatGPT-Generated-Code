#include <iostream>
#include <vector>
#include <string>

struct Product {
    int id;
    std::string name;
    double price;
    std::string location;
};

class SupermarketSystem {
private:
    std::vector<Product> products;

    int findProductIndexById(int id) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addProduct(int id, const std::string& name, double price, const std::string& location) {
        if (findProductIndexById(id) == -1) {
            products.push_back({id, name, price, location});
        }
    }

    void deleteProduct(int id) {
        int index = findProductIndexById(id);
        if (index != -1) {
            products.erase(products.begin() + index);
        }
    }

    void updateProduct(int id, const std::string& name, double price, const std::string& location) {
        int index = findProductIndexById(id);
        if (index != -1) {
            products[index] = {id, name, price, location};
        }
    }

    Product* searchProduct(int id) {
        int index = findProductIndexById(id);
        if (index != -1) {
            return &products[index];
        }
        return nullptr;
    }

    void displayProducts() {
        for (const auto& product : products) {
            std::cout << "ID: " << product.id 
                      << ", Name: " << product.name 
                      << ", Price: " << product.price 
                      << ", Location: " << product.location << std::endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct(1, "Apple", 0.99, "Aisle 1");
    system.addProduct(2, "Banana", 0.59, "Aisle 1");
    system.displayProducts();
    system.updateProduct(1, "Apple", 1.09, "Aisle 1");
    auto product = system.searchProduct(1);
    if (product) {
        std::cout << "Found product: " << product->name << std::endl;
    }
    system.deleteProduct(2);
    system.displayProducts();
    return 0;
}