#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Product {
public:
    int id;
    string name;
    double price;
    string location;

    Product(int id, string name, double price, string location)
        : id(id), name(name), price(price), location(location) {}
};

class SupermarketSystem {
private:
    vector<Product> products;

    int findProductIndex(int id) {
        for (int i = 0; i < products.size(); i++) {
            if (products[i].id == id) return i;
        }
        return -1;
    }

public:
    void addProduct(int id, string name, double price, string location) {
        if (findProductIndex(id) == -1) {
            products.push_back(Product(id, name, price, location));
        }
    }

    void deleteProduct(int id) {
        int index = findProductIndex(id);
        if (index != -1) {
            products.erase(products.begin() + index);
        }
    }

    void updateProduct(int id, string name, double price, string location) {
        int index = findProductIndex(id);
        if (index != -1) {
            products[index].name = name;
            products[index].price = price;
            products[index].location = location;
        }
    }

    void searchProduct(int id) {
        int index = findProductIndex(id);
        if (index != -1) {
            cout << "Product ID: " << products[index].id
                 << ", Name: " << products[index].name
                 << ", Price: " << products[index].price
                 << ", Location: " << products[index].location << endl;
        } else {
            cout << "Product not found." << endl;
        }
    }

    void displayProducts() {
        for (int i = 0; i < products.size(); i++) {
            cout << "Product ID: " << products[i].id
                 << ", Name: " << products[i].name
                 << ", Price: " << products[i].price
                 << ", Location: " << products[i].location << endl;
        }
    }
};

int main() {
    SupermarketSystem system;

    system.addProduct(1, "Milk", 1.99, "Aisle 1");
    system.addProduct(2, "Bread", 2.49, "Aisle 2");

    system.displayProducts();

    system.updateProduct(1, "Milk", 2.19, "Aisle 3");
    system.searchProduct(1);

    system.deleteProduct(2);
    system.displayProducts();

    return 0;
}