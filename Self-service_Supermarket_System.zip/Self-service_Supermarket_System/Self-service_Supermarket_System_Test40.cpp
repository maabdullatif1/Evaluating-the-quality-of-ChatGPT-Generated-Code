#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Product {
    int id;
    string name;
    string location;
    double price;
};

class Supermarket {
    vector<Product> products;
    int nextId = 1;

public:
    void addProduct(const string& name, const string& location, double price) {
        Product product = {nextId++, name, location, price};
        products.push_back(product);
        cout << "Product added: ID = " << product.id << ", Name = " << name << endl;
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                cout << "Product with ID " << id << " deleted." << endl;
                return;
            }
        }
        cout << "Product with ID " << id << " not found." << endl;
    }

    void updateProduct(int id, const string& name, const string& location, double price) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.location = location;
                product.price = price;
                cout << "Product with ID " << id << " updated." << endl;
                return;
            }
        }
        cout << "Product with ID " << id << " not found." << endl;
    }

    void searchProduct(int id) {
        for (const auto& product : products) {
            if (product.id == id) {
                cout << "Product found: ID = " << product.id << ", Name = " << product.name
                     << ", Location = " << product.location << ", Price = " << product.price << endl;
                return;
            }
        }
        cout << "Product with ID " << id << " not found." << endl;
    }

    void displayProducts() {
        if (products.empty()) {
            cout << "No products available." << endl;
            return;
        }
        for (const auto& product : products) {
            cout << "ID: " << product.id << ", Name: " << product.name
                 << ", Location: " << product.location << ", Price: " << product.price << endl;
        }
    }
};

int main() {
    Supermarket supermarket;
    supermarket.addProduct("Apple", "Aisle 1", 0.99);
    supermarket.addProduct("Milk", "Aisle 2", 1.49);
    supermarket.displayProducts();
    supermarket.searchProduct(1);
    supermarket.updateProduct(1, "Green Apple", "Aisle 1", 1.29);
    supermarket.displayProducts();
    supermarket.deleteProduct(1);
    supermarket.displayProducts();
    return 0;
}