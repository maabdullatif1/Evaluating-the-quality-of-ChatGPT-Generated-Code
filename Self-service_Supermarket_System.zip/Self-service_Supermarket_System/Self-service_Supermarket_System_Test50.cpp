#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Product {
public:
    string name;
    string location;
    double price;
    int quantity;

    Product(string n, string l, double p, int q) : name(n), location(l), price(p), quantity(q) {}
};

class SupermarketSystem {
private:
    vector<Product> products;

public:
    void addProduct(string name, string location, double price, int quantity) {
        products.push_back(Product(name, location, price, quantity));
    }

    void deleteProduct(string name) {
        for (auto it = products.begin(); it != products.end();) {
            if (it->name == name) {
                it = products.erase(it);
            } else {
                ++it;
            }
        }
    }

    void updateProduct(string name, string newLocation, double newPrice, int newQuantity) {
        for (auto &product : products) {
            if (product.name == name) {
                product.location = newLocation;
                product.price = newPrice;
                product.quantity = newQuantity;
            }
        }
    }

    void searchProduct(string name) {
        for (auto &product : products) {
            if (product.name == name) {
                cout << "Product found: " << product.name << " - Location: " << product.location
                     << ", Price: $" << product.price << ", Quantity: " << product.quantity << endl;
                return;
            }
        }
        cout << "Product not found: " << name << endl;
    }

    void displayProducts() {
        if (products.empty()) {
            cout << "No products available." << endl;
        } else {
            for (auto &product : products) {
                cout << "Product: " << product.name << ", Location: " << product.location
                     << ", Price: $" << product.price << ", Quantity: " << product.quantity << endl;
            }
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct("Apple", "Aisle 1", 0.99, 100);
    system.addProduct("Bread", "Aisle 5", 1.49, 50);
    
    system.displayProducts();
    
    system.searchProduct("Apple");
    system.updateProduct("Apple", "Aisle 2", 0.89, 120);
    
    system.searchProduct("Apple");
    system.deleteProduct("Bread");
    
    system.displayProducts();
    
    return 0;
}