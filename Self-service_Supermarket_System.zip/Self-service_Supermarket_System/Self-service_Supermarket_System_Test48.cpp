#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Product {
    int id;
    string name;
    string location;
    double price;
};

class SupermarketSystem {
private:
    vector<Product> products;
    int generateProductId() {
        return products.empty() ? 1 : products.back().id + 1;
    }
    auto findProduct(int id) {
        return find_if(products.begin(), products.end(), [id](const Product& p) { return p.id == id; });
    }
public:
    void addProduct(const string& name, const string& location, double price) {
        products.push_back({generateProductId(), name, location, price});
    }
    void deleteProduct(int id) {
        auto it = findProduct(id);
        if (it != products.end())
            products.erase(it);
    }
    void updateProduct(int id, const string& name, const string& location, double price) {
        auto it = findProduct(id);
        if (it != products.end()) {
            it->name = name;
            it->location = location;
            it->price = price;
        }
    }
    void searchProduct(int id) {
        auto it = findProduct(id);
        if (it != products.end()) {
            displayProduct(*it);
        }
    }
    void displayProducts() {
        for (const auto& product : products) {
            displayProduct(product);
        }
    }
    void displayProduct(const Product& product) {
        cout << "ID: " << product.id << ", Name: " << product.name 
             << ", Location: " << product.location << ", Price: $" << product.price << endl;
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct("Apple", "Aisle 1", 0.99);
    system.addProduct("Bread", "Aisle 5", 1.99);
    system.displayProducts();
    system.updateProduct(1, "Apple", "Aisle 2", 1.09);
    system.searchProduct(1);
    system.deleteProduct(2);
    system.displayProducts();
    return 0;
}