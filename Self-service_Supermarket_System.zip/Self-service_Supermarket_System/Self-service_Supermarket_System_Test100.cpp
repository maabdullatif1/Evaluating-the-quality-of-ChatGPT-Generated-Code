#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Product {
    int id;
    string name;
    double price;
    string location;
};

class SupermarketSystem {
    vector<Product> products;

public:
    void addProduct(int id, string name, double price, string location) {
        products.push_back({id, name, price, location});
    }
    
    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                return;
            }
        }
        cout << "Product not found.\n";
    }
    
    void updateProduct(int id, string name, double price, string location) {
        for (auto &product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                return;
            }
        }
        cout << "Product not found.\n";
    }
    
    void searchProduct(int id) {
        for (auto &product : products) {
            if (product.id == id) {
                displayProduct(product);
                return;
            }
        }
        cout << "Product not found.\n";
    }
    
    void displayProduct(const Product &product) {
        cout << "ID: " << product.id << "\n";
        cout << "Name: " << product.name << "\n";
        cout << "Price: " << product.price << "\n";
        cout << "Location: " << product.location << "\n";
    }
    
    void displayAllProducts() {
        if (products.empty()) {
            cout << "No products available.\n";
        }
        for (auto &product : products) {
            displayProduct(product);
            cout << "----------------\n";
        }
    }
};

int main() {
    SupermarketSystem system;
    int choice, id;
    string name, location;
    double price;

    while (true) {
        cout << "1. Add Product\n";
        cout << "2. Delete Product\n";
        cout << "3. Update Product\n";
        cout << "4. Search Product\n";
        cout << "5. Display All Products\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter ID, Name, Price, Location: ";
            cin >> id >> name >> price >> location;
            system.addProduct(id, name, price, location);
            break;
        case 2:
            cout << "Enter Product ID to delete: ";
            cin >> id;
            system.deleteProduct(id);
            break;
        case 3:
            cout << "Enter ID, New Name, New Price, New Location: ";
            cin >> id >> name >> price >> location;
            system.updateProduct(id, name, price, location);
            break;
        case 4:
            cout << "Enter Product ID to search: ";
            cin >> id;
            system.searchProduct(id);
            break;
        case 5:
            system.displayAllProducts();
            break;
        case 6:
            return 0;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    }

    return 0;
}