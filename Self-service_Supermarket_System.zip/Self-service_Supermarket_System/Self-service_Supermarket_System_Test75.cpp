#include <iostream>
#include <string>

struct Product {
    int id;
    std::string name;
    float price;
    std::string location;
    Product* next;
};

class Supermarket {
private:
    Product* head;

public:
    Supermarket() : head(nullptr) {}

    void addProduct(int id, const std::string& name, float price, const std::string& location) {
        Product* newProduct = new Product{id, name, price, location, nullptr};
        if (!head) {
            head = newProduct;
        } else {
            Product* current = head;
            while (current->next) {
                current = current->next;
            }
            current->next = newProduct;
        }
    }

    void deleteProduct(int id) {
        Product* current = head;
        Product* previous = nullptr;
        while (current && current->id != id) {
            previous = current;
            current = current->next;
        }
        if (!current) return;
        if (!previous) {
            head = current->next;
        } else {
            previous->next = current->next;
        }
        delete current;
    }

    void updateProduct(int id, const std::string& name, float price, const std::string& location) {
        Product* current = head;
        while (current && current->id != id) {
            current = current->next;
        }
        if (current) {
            current->name = name;
            current->price = price;
            current->location = location;
        }
    }

    Product* searchProduct(int id) {
        Product* current = head;
        while (current && current->id != id) {
            current = current->next;
        }
        return current;
    }

    void displayProducts() {
        Product* current = head;
        while (current) {
            std::cout << "ID: " << current->id << ", Name: " << current->name
                      << ", Price: " << current->price << ", Location: " << current->location << std::endl;
            current = current->next;
        }
    }
};

int main() {
    Supermarket sm;
    sm.addProduct(1, "Apples", 1.5, "Aisle 1");
    sm.addProduct(2, "Bread", 1.0, "Aisle 2");
    sm.displayProducts();
    sm.updateProduct(2, "Whole Wheat Bread", 1.2, "Aisle 2");
    sm.displayProducts();
    sm.deleteProduct(1);
    sm.displayProducts();
    return 0;
}