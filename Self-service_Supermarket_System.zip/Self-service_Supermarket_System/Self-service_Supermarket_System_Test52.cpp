#include <iostream>
#include <string>
#include <vector>

struct Product {
    int id;
    std::string name;
    double price;
    std::string location;
};

class SupermarketSystem {
private:
    std::vector<Product> products;
    int nextId = 1;

public:
    void addProduct(const std::string& name, double price, const std::string& location) {
        products.push_back({nextId++, name, price, location});
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, const std::string& name, double price, const std::string& location) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
                break;
            }
        }
    }

    void displayProducts() {
        for (const auto& product : products) {
            std::cout << "ID: " << product.id 
                      << " Name: " << product.name 
                      << " Price: $" << product.price 
                      << " Location: " << product.location 
                      << std::endl;
        }
    }

    void searchProduct(const std::string& name) {
        for (const auto& product : products) {
            if (product.name == name) {
                std::cout << "ID: " << product.id 
                          << " Name: " << product.name 
                          << " Price: $" << product.price 
                          << " Location: " << product.location 
                          << std::endl;
                return;
            }
        }
        std::cout << "Product not found" << std::endl;
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct("Apple", 0.5, "Aisle 1");
    system.addProduct("Banana", 0.3, "Aisle 1");
    system.displayProducts();
    system.searchProduct("Banana");
    system.updateProduct(1, "Apple", 0.4, "Aisle 2");
    system.displayProducts();
    system.deleteProduct(2);
    system.displayProducts();
    return 0;
}