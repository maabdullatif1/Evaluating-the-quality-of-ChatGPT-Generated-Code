#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    int id;
    std::string name;
    double price;
    std::string location;

    Product(int id, std::string name, double price, std::string location)
        : id(id), name(name), price(price), location(location) {}
};

class SupermarketSystem {
    std::vector<Product> products;

public:
    void addProduct(int id, std::string name, double price, std::string location) {
        products.push_back(Product(id, name, price, location));
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, std::string name, double price, std::string location) {
        for (auto &product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                product.location = location;
            }
        }
    }

    Product* searchProduct(int id) {
        for (auto &product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    void displayProducts() {
        for (const auto &product : products) {
            std::cout << "ID: " << product.id
                      << ", Name: " << product.name
                      << ", Price: $" << product.price
                      << ", Location: " << product.location << std::endl;
        }
    }
};

int main() {
    SupermarketSystem s;
    s.addProduct(1, "Apple", 0.99, "Aisle 1");
    s.addProduct(2, "Banana", 0.59, "Aisle 1");
    s.addProduct(3, "Milk", 2.49, "Aisle 5");
    
    std::cout << "Current Product List:" << std::endl;
    s.displayProducts();

    std::cout << "\nUpdating Milk price to 2.99\n";
    s.updateProduct(3, "Milk", 2.99, "Aisle 5");
    
    std::cout << "\nNew Product List:" << std::endl;
    s.displayProducts();

    std::cout << "\nDeleting Banana\n";
    s.deleteProduct(2);

    std::cout << "\nNew Product List:" << std::endl;
    s.displayProducts();

    Product* p = s.searchProduct(1);
    if (p) {
        std::cout << "\nProduct Found - ID: " << p->id << ", Name: " << p->name << std::endl;
    } else {
        std::cout << "\nProduct not found" << std::endl;
    }

    return 0;
}