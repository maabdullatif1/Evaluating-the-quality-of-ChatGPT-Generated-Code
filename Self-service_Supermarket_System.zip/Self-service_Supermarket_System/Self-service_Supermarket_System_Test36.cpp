#include <iostream>
#include <string>
#include <vector>

struct Product {
    int id;
    std::string name;
    double price;
    std::string location;
};

class SupermarketSystem {
private:
    std::vector<Product> products;
    int nextId = 1;

    int findProductIndexById(int id) {
        for (size_t i = 0; i < products.size(); ++i) {
            if (products[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addProduct(const std::string& name, double price, const std::string& location) {
        products.push_back({nextId++, name, price, location});
    }

    void deleteProduct(int id) {
        int index = findProductIndexById(id);
        if (index != -1) {
            products.erase(products.begin() + index);
        } else {
            std::cout << "Product not found.\n";
        }
    }

    void updateProduct(int id, const std::string& newName, double newPrice, const std::string& newLocation) {
        int index = findProductIndexById(id);
        if (index != -1) {
            products[index].name = newName;
            products[index].price = newPrice;
            products[index].location = newLocation;
        } else {
            std::cout << "Product not found.\n";
        }
    }

    void searchProductById(int id) const {
        for (const auto& product : products) {
            if (product.id == id) {
                std::cout << "ID: " << id << ", Name: " << product.name
                          << ", Price: " << product.price << ", Location: " << product.location << std::endl;
                return;
            }
        }
        std::cout << "Product not found.\n";
    }

    void displayProducts() const {
        for (const auto& product : products) {
            std::cout << "ID: " << product.id << ", Name: " << product.name
                      << ", Price: " << product.price << ", Location: " << product.location << std::endl;
        }
    }
};

int main() {
    SupermarketSystem supermarket;
    supermarket.addProduct("Apple", 0.5, "Aisle 1");
    supermarket.addProduct("Banana", 0.2, "Aisle 1");
    supermarket.displayProducts();
    supermarket.updateProduct(1, "Green Apple", 0.6, "Aisle 1");
    supermarket.searchProductById(1);
    supermarket.deleteProduct(2);
    supermarket.displayProducts();
    return 0;
}