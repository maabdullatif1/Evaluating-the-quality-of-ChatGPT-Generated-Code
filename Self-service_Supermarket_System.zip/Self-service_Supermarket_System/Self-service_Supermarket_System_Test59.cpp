#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Product {
    string name;
    double price;
    string location;
};

class Supermarket {
private:
    vector<Product> products;

public:
    void addProduct(const string& name, double price, const string& location) {
        products.push_back({name, price, location});
    }

    void deleteProduct(const string& name) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->name == name) {
                products.erase(it);
                return;
            }
        }
    }

    void updateProduct(const string& name, double price, const string& location) {
        for (auto& product : products) {
            if (product.name == name) {
                product.price = price;
                product.location = location;
                return;
            }
        }
    }

    void searchProduct(const string& name) const {
        for (const auto& product : products) {
            if (product.name == name) {
                cout << "Product found: " << product.name << ", Price: " << product.price << ", Location: " << product.location << endl;
                return;
            }
        }
        cout << "Product not found" << endl;
    }

    void displayProducts() const {
        if (products.empty()) {
            cout << "No products available" << endl;
            return;
        }
        for (const auto& product : products) {
            cout << "Name: " << product.name << ", Price: " << product.price << ", Location: " << product.location << endl;
        }
    }
};

int main() {
    Supermarket sm;
    sm.addProduct("Milk", 1.99, "Aisle 1");
    sm.addProduct("Bread", 0.99, "Aisle 2");
    sm.displayProducts();
    sm.updateProduct("Milk", 2.49, "Aisle 3");
    sm.searchProduct("Milk");
    sm.deleteProduct("Bread");
    sm.displayProducts();
    return 0;
}