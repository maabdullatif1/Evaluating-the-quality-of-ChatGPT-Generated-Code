#include <iostream>
#include <vector>
#include <string>

class Product {
public:
    int id;
    std::string name;
    float price;

    Product(int id, std::string name, float price) : id(id), name(name), price(price) {}
};

class Location {
public:
    int id;
    std::string name;

    Location(int id, std::string name) : id(id), name(name) {}
};

class SupermarketSystem {
private:
    std::vector<Product> products;
    std::vector<Location> locations;

public:
    void addProduct(int id, std::string name, float price) {
        products.push_back(Product(id, name, price));
    }

    void deleteProduct(int id) {
        for (auto it = products.begin(); it != products.end(); ++it) {
            if (it->id == id) {
                products.erase(it);
                break;
            }
        }
    }

    void updateProduct(int id, std::string name, float price) {
        for (auto& product : products) {
            if (product.id == id) {
                product.name = name;
                product.price = price;
                break;
            }
        }
    }

    Product* searchProduct(int id) {
        for (auto& product : products) {
            if (product.id == id) {
                return &product;
            }
        }
        return nullptr;
    }

    void displayProducts() {
        for (const auto& product : products) {
            std::cout << "ID: " << product.id << ", Name: " << product.name << ", Price: " << product.price << std::endl;
        }
    }

    void addLocation(int id, std::string name) {
        locations.push_back(Location(id, name));
    }

    void deleteLocation(int id) {
        for (auto it = locations.begin(); it != locations.end(); ++it) {
            if (it->id == id) {
                locations.erase(it);
                break;
            }
        }
    }

    void updateLocation(int id, std::string name) {
        for (auto& location : locations) {
            if (location.id == id) {
                location.name = name;
                break;
            }
        }
    }

    Location* searchLocation(int id) {
        for (auto& location : locations) {
            if (location.id == id) {
                return &location;
            }
        }
        return nullptr;
    }

    void displayLocations() {
        for (const auto& location : locations) {
            std::cout << "ID: " << location.id << ", Name: " << location.name << std::endl;
        }
    }
};

int main() {
    SupermarketSystem system;
    system.addProduct(1, "Milk", 1.50);
    system.addProduct(2, "Bread", 0.99);
    system.displayProducts();
    Product* product = system.searchProduct(1);
    if (product) {
        std::cout << "Found: " << product->name << std::endl;
    }
    system.updateProduct(1, "Organic Milk", 2.00);
    system.displayProducts();
    system.deleteProduct(2);
    system.displayProducts();
    system.addLocation(101, "Aisle 1");
    system.addLocation(102, "Aisle 2");
    system.displayLocations();
    Location* location = system.searchLocation(101);
    if (location) {
        std::cout << "Found: " << location->name << std::endl;
    }
    system.updateLocation(101, "Beverage Aisle");
    system.displayLocations();
    system.deleteLocation(102);
    system.displayLocations();
    return 0;
}