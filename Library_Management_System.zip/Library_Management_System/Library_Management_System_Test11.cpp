#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int id, std::string title, std::string author)
        : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;

    Student(int id, std::string name)
        : id(id), name(name) {}
};

class LibrarySystem {
private:
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string title, std::string author) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << '\n';
                return;
            }
        }
        std::cout << "Book not found\n";
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << '\n';
        }
    }

    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << '\n';
                return;
            }
        }
        std::cout << "Student not found\n";
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << '\n';
        }
    }
};

int main() {
    LibrarySystem library;
    library.addBook(1, "C++ Programming", "Bjarne Stroustrup");
    library.addBook(2, "Effective C++", "Scott Meyers");
    library.addStudent(1, "Alice");
    library.addStudent(2, "Bob");

    std::cout << "Books in the library:\n";
    library.displayBooks();

    std::cout << "Students in the system:\n";
    library.displayStudents();

    library.searchBook(1);
    library.searchStudent(1);

    library.updateBook(1, "The C++ Programming Language", "Bjarne Stroustrup");
    library.updateStudent(1, "Alice Johnson");

    std::cout << "Updated books in the library:\n";
    library.displayBooks();

    std::cout << "Updated students in the system:\n";
    library.displayStudents();

    library.deleteBook(2);
    library.deleteStudent(2);

    std::cout << "Final books in the library:\n";
    library.displayBooks();
    
    std::cout << "Final students in the system:\n";
    library.displayStudents();

    return 0;
}