#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int bookID;
    std::string title;
    std::string author;

    Book(int id, const std::string& t, const std::string& a) :
        bookID(id), title(t), author(a) {}
};

class Student {
public:
    int studentID;
    std::string name;

    Student(int id, const std::string& n) : studentID(id), name(n) {}
};

class LibraryManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, const std::string& title, const std::string& author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->bookID == id) {
                books.erase(it);
                return;
            }
        }
    }

    void updateBook(int id, const std::string& title, const std::string& author) {
        for (auto& book : books) {
            if (book.bookID == id) {
                book.title = title;
                book.author = author;
                return;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.bookID == id) {
                std::cout << "BookID: " << book.bookID << ", Title: " << book.title << ", Author: " << book.author << std::endl;
                return;
            }
        }
        std::cout << "Book not found." << std::endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "BookID: " << book.bookID << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }

    void addStudent(int id, const std::string& name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == id) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(int id, const std::string& name) {
        for (auto& student : students) {
            if (student.studentID == id) {
                student.name = name;
                return;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.studentID == id) {
                std::cout << "StudentID: " << student.studentID << ", Name: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found." << std::endl;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "StudentID: " << student.studentID << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem libSys;
    libSys.addBook(1, "The Great Gatsby", "F. Scott Fitzgerald");
    libSys.addBook(2, "1984", "George Orwell");
    libSys.addStudent(1, "John Doe");
    libSys.addStudent(2, "Jane Smith");

    libSys.displayBooks();
    libSys.displayStudents();

    libSys.searchBook(1);
    libSys.searchStudent(2);

    libSys.updateBook(2, "Nineteen Eighty-Four", "George Orwell");
    libSys.updateStudent(1, "Jonathan Doe");

    libSys.displayBooks();
    libSys.displayStudents();

    libSys.deleteBook(1);
    libSys.deleteStudent(2);

    libSys.displayBooks();
    libSys.displayStudents();

    return 0;
}