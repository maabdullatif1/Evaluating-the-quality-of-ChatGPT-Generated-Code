#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int id, const std::string& title, const std::string& author)
        : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;

    Student(int id, const std::string& name)
        : id(id), name(name) {}
};

class Library {
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, const std::string& title, const std::string& author) {
        books.emplace_back(id, title, author);
    }

    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(),
                    [id](const Book& b) { return b.id == id; }),
                    books.end());
    }

    void updateBook(int id, const std::string& title, const std::string& author) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id
                          << ", Title: " << book.title
                          << ", Author: " << book.author << std::endl;
                return;
            }
        }
        std::cout << "Book not found" << std::endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id
                      << ", Title: " << book.title
                      << ", Author: " << book.author << std::endl;
        }
    }

    void addStudent(int id, const std::string& name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(int id) {
        students.erase(std::remove_if(students.begin(), students.end(),
                      [id](const Student& s) { return s.id == id; }),
                      students.end());
    }

    void updateStudent(int id, const std::string& name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id
                          << ", Name: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id
                      << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    Library library;
    library.addBook(1, "The Catcher in the Rye", "J.D. Salinger");
    library.addStudent(1, "John Doe");
    library.displayBooks();
    library.displayStudents();
    library.searchBook(1);
    library.searchStudent(1);
    library.updateBook(1, "The Great Gatsby", "F. Scott Fitzgerald");
    library.updateStudent(1, "Jane Doe");
    library.displayBooks();
    library.displayStudents();
    library.deleteBook(1);
    library.deleteStudent(1);
    library.displayBooks();
    library.displayStudents();

    return 0;
}