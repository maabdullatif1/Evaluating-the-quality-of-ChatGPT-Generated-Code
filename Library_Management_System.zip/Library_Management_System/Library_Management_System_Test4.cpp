#include <iostream>
#include <vector>
#include <string>

class Student {
public:
    int id;
    std::string name;
    Student(int id, const std::string &name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;
    Book(int id, const std::string &title) : id(id), title(title) {}
};

class Library {
private:
    std::vector<Student> students;
    std::vector<Book> books;

    template<typename T>
    void displayList(const std::vector<T> &list) {
        for (const auto &item : list) {
            std::cout << "ID: " << item.id << ", Name/Title: " << item.name << std::endl;
        }
    }

    template<typename T>
    typename std::vector<T>::iterator findById(std::vector<T> &list, int id) {
        for (auto it = list.begin(); it != list.end(); ++it) {
            if (it->id == id) return it;
        }
        return list.end();
    }

public:
    void addStudent(int id, const std::string &name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(int id) {
        auto it = findById(students, id);
        if (it != students.end()) students.erase(it);
    }

    void updateStudent(int id, const std::string &name) {
        auto it = findById(students, id);
        if (it != students.end()) it->name = name;
    }

    void searchStudent(int id) {
        auto it = findById(students, id);
        if (it != students.end())
            std::cout << "Student found: ID: " << it->id << ", Name: " << it->name << std::endl;
        else
            std::cout << "Student not found" << std::endl;
    }

    void displayStudents() {
        displayList(students);
    }

    void addBook(int id, const std::string &title) {
        books.emplace_back(id, title);
    }

    void deleteBook(int id) {
        auto it = findById(books, id);
        if (it != books.end()) books.erase(it);
    }

    void updateBook(int id, const std::string &title) {
        auto it = findById(books, id);
        if (it != books.end()) it->title = title;
    }

    void searchBook(int id) {
        auto it = findById(books, id);
        if (it != books.end())
            std::cout << "Book found: ID: " << it->id << ", Title: " << it->title << std::endl;
        else
            std::cout << "Book not found" << std::endl;
    }

    void displayBooks() {
        displayList(books);
    }
};

int main() {
    Library library;
    library.addStudent(1, "Alice");
    library.addStudent(2, "Bob");

    library.addBook(101, "C++ Programming");
    library.addBook(102, "Data Structures");

    library.displayStudents();
    library.displayBooks();

    library.searchStudent(1);
    library.searchBook(102);

    library.updateStudent(2, "Robert");
    library.updateBook(101, "Advanced C++ Programming");

    library.displayStudents();
    library.displayBooks();

    library.deleteStudent(1);
    library.deleteBook(102);

    library.displayStudents();
    library.displayBooks();

    return 0;
}