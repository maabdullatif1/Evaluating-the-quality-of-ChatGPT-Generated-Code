#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int id, std::string title, std::string author)
        : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;

    Student(int id, std::string name)
        : id(id), name(name) {}
};

class Library {
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string title, std::string author) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                std::cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
                return;
            }
        }
        std::cout << "Book not found" << std::endl;
    }

    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                std::cout << "ID: " << student.id << ", Name: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }
};

int main() {
    Library library;
    library.addBook(1, "The Catcher in the Rye", "J.D. Salinger");
    library.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    library.addStudent(1, "John Doe");
    library.addStudent(2, "Jane Smith");

    std::cout << "Books in the library:" << std::endl;
    library.displayBooks();

    std::cout << "\nStudents in the library:" << std::endl;
    library.displayStudents();

    std::cout << "\nSearching for book ID 1:" << std::endl;
    library.searchBook(1);

    std::cout << "\nSearching for student ID 2:" << std::endl;
    library.searchStudent(2);

    library.updateBook(1, "The Catcher in the Rye", "Jerome David Salinger");
    library.updateStudent(1, "Johnathan Doe");

    std::cout << "\nUpdated books in the library:" << std::endl;
    library.displayBooks();

    std::cout << "\nUpdated students in the library:" << std::endl;
    library.displayStudents();

    library.deleteBook(2);
    library.deleteStudent(2);

    std::cout << "\nBooks in the library after deletion:" << std::endl;
    library.displayBooks();

    std::cout << "\nStudents in the library after deletion:" << std::endl;
    library.displayStudents();

    return 0;
}