#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Book {
public:
    int id;
    string title;
    string author;

    Book(int bookId, string bookTitle, string bookAuthor)
        : id(bookId), title(bookTitle), author(bookAuthor) {}
};

class Student {
public:
    int id;
    string name;
    string major;

    Student(int studentId, string studentName, string studentMajor)
        : id(studentId), name(studentName), major(studentMajor) {}
};

class LibraryManagement {
    vector<Book> books;
    vector<Student> students;

public:
    void addBook(int id, string title, string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string title, string author) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (auto &book : books) {
            cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
        }
    }

    void addStudent(int id, string name, string major) {
        students.push_back(Student(id, name, major));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string name, string major) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = name;
                student.major = major;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto &student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (auto &student : students) {
            cout << "ID: " << student.id << ", Name: " << student.name << ", Major: " << student.major << endl;
        }
    }
};

int main() {
    LibraryManagement library;

    library.addBook(1, "The Great Gatsby", "F. Scott Fitzgerald");
    library.addBook(2, "To Kill a Mockingbird", "Harper Lee");

    library.addStudent(1, "John Doe", "Computer Science");
    library.addStudent(2, "Jane Doe", "Biology");

    cout << "Books in library:" << endl;
    library.displayBooks();

    cout << "Students in library system:" << endl;
    library.displayStudents();

    int bookId = 1;
    Book* book = library.searchBook(bookId);
    if (book) {
        cout << "Found book - ID: " << book->id << ", Title: " << book->title << ", Author: " << book->author << endl;
    } else {
        cout << "Book with ID " << bookId << " not found." << endl;
    }

    int studentId = 2;
    Student* student = library.searchStudent(studentId);
    if (student) {
        cout << "Found student - ID: " << student->id << ", Name: " << student->name << ", Major: " << student->major << endl;
    } else {
        cout << "Student with ID " << studentId << " not found." << endl;
    }

    return 0;
}