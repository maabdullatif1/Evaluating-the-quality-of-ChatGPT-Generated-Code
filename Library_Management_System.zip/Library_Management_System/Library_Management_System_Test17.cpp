#include <iostream>
#include <string>
#include <vector>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int id, const std::string &title, const std::string &author) 
        : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;

    Student(int id, const std::string &name) 
        : id(id), name(name) {}
};

class LibraryManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, const std::string &title, const std::string &author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for(auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const std::string &newTitle, const std::string &newAuthor) {
        for(auto &book : books) {
            if (book.id == id) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }

    void searchBook(int id) {
        for(const auto &book : books) {
            if (book.id == id) {
                std::cout << "Book Found - ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
                return;
            }
        }
        std::cout << "Book not found" << std::endl;
    }

    void displayBooks() {
        for(const auto &book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }

    void addStudent(int id, const std::string &name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for(auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string &newName) {
        for(auto &student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for(const auto &student : students) {
            if (student.id == id) {
                std::cout << "Student Found - ID: " << student.id << ", Name: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }

    void displayStudents() {
        for(const auto &student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;

    lms.addBook(1, "C++ Primer", "Stanley B. Lippman");
    lms.addBook(2, "Effective C++", "Scott Meyers");

    lms.addStudent(1, "Alice");
    lms.addStudent(2, "Bob");

    lms.displayBooks();
    lms.displayStudents();

    lms.searchBook(1);
    lms.searchStudent(1);

    lms.updateBook(1, "C++ Primer, 5th Edition", "Stanley B. Lippman");
    lms.updateStudent(1, "Alice Johnson");

    lms.deleteBook(2);
    lms.deleteStudent(2);

    lms.displayBooks();
    lms.displayStudents();

    return 0;
}