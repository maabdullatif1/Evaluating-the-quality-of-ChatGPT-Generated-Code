#include <iostream>
#include <vector>
#include <string>

class Student {
public:
    int id;
    std::string name;

    Student(int id, const std::string& name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;

    Book(int id, const std::string& title) : id(id), title(title) {}
};

class LibraryManagementSystem {
private:
    std::vector<Student> students;
    std::vector<Book> books;

public:
    void addStudent(int id, const std::string& name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string& name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                std::cout << "Student Found: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student Not Found" << std::endl;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "ID: " << student.id << " Name: " << student.name << std::endl;
        }
    }

    void addBook(int id, const std::string& title) {
        books.push_back(Book(id, title));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const std::string& title) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                std::cout << "Book Found: " << book.title << std::endl;
                return;
            }
        }
        std::cout << "Book Not Found" << std::endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "ID: " << book.id << " Title: " << book.title << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addStudent(1, "Alice");
    lms.addStudent(2, "Bob");
    lms.addBook(1, "C++ Programming");
    lms.addBook(2, "Data Structures");

    lms.displayStudents();
    lms.searchStudent(1);
    lms.updateStudent(2, "Charlie");
    lms.displayStudents();
    lms.deleteStudent(1);
    lms.displayStudents();

    lms.displayBooks();
    lms.searchBook(1);
    lms.updateBook(2, "Algorithms");
    lms.displayBooks();
    lms.deleteBook(1);
    lms.displayBooks();

    return 0;
}