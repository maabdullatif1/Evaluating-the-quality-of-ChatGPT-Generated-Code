#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Book {
public:
    int id;
    string title;
    string author;

    Book(int id, const string &title, const string &author) : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    string name;
    int age;

    Student(int id, const string &name, int age) : id(id), name(name), age(age) {}
};

class LibraryManagementSystem {
    vector<Book> books;
    vector<Student> students;

    Book* findBookById(int bookId) {
        for (auto &book : books) {
            if (book.id == bookId) return &book;
        }
        return nullptr;
    }

    Student* findStudentById(int studentId) {
        for (auto &student : students) {
            if (student.id == studentId) return &student;
        }
        return nullptr;
    }

public:
    void addBook(int id, const string &title, const string &author) {
        books.emplace_back(id, title, author);
    }

    void deleteBook(int id) {
        books.erase(remove_if(books.begin(), books.end(), [=](Book &book) { return book.id == id; }), books.end());
    }

    void updateBook(int id, const string &title, const string &author) {
        Book *book = findBookById(id);
        if (book) {
            book->title = title;
            book->author = author;
        }
    }

    void searchBook(int id) {
        Book *book = findBookById(id);
        if (book) {
            cout << "Book ID: " << book->id << ", Title: " << book->title << ", Author: " << book->author << endl;
        } else {
            cout << "Book not found." << endl;
        }
    }

    void displayBooks() {
        for (const auto &book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
        }
    }

    void addStudent(int id, const string &name, int age) {
        students.emplace_back(id, name, age);
    }

    void deleteStudent(int id) {
        students.erase(remove_if(students.begin(), students.end(), [=](Student &student) { return student.id == id; }), students.end());
    }

    void updateStudent(int id, const string &name, int age) {
        Student *student = findStudentById(id);
        if (student) {
            student->name = name;
            student->age = age;
        }
    }

    void searchStudent(int id) {
        Student *student = findStudentById(id);
        if (student) {
            cout << "Student ID: " << student->id << ", Name: " << student->name << ", Age: " << student->age << endl;
        } else {
            cout << "Student not found." << endl;
        }
    }

    void displayStudents() {
        for (const auto &student : students) {
            cout << "Student ID: " << student.id << ", Name: " << student.name << ", Age: " << student.age << endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addBook(1, "1984", "George Orwell");
    lms.addStudent(1, "Alice", 21);
    lms.displayBooks();
    lms.displayStudents();
    return 0;
}