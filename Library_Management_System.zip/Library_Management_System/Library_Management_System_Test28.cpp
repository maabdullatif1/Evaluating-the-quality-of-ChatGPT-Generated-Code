#include <iostream>
#include <string>
#include <vector>

class Student {
public:
    int id;
    std::string name;

    Student(int id, std::string name) : id(id), name(name) {}
};

class Book {
public:
    int isbn;
    std::string title;

    Book(int isbn, std::string title) : isbn(isbn), title(title) {}
};

class LibraryManagementSystem {
    std::vector<Student> students;
    std::vector<Book> books;

public:
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string newName) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto &student : students) {
            if (student.id == id) {
                std::cout << "Student found: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found." << std::endl;
    }

    void displayStudents() {
        for (const auto &student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }

    void addBook(int isbn, std::string title) {
        books.push_back(Book(isbn, title));
    }

    void deleteBook(int isbn) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->isbn == isbn) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int isbn, std::string newTitle) {
        for (auto &book : books) {
            if (book.isbn == isbn) {
                book.title = newTitle;
                break;
            }
        }
    }

    void searchBook(int isbn) {
        for (const auto &book : books) {
            if (book.isbn == isbn) {
                std::cout << "Book found: " << book.title << std::endl;
                return;
            }
        }
        std::cout << "Book not found." << std::endl;
    }

    void displayBooks() {
        for (const auto &book : books) {
            std::cout << "ISBN: " << book.isbn << ", Title: " << book.title << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;

    lms.addStudent(1, "Alice");
    lms.addStudent(2, "Bob");
    lms.displayStudents();

    lms.addBook(101, "1984");
    lms.addBook(102, "Brave New World");
    lms.displayBooks();

    lms.updateStudent(1, "Alice Smith");
    lms.searchStudent(1);

    lms.updateBook(101, "Nineteen Eighty-Four");
    lms.searchBook(101);

    lms.deleteStudent(2);
    lms.displayStudents();

    lms.deleteBook(102);
    lms.displayBooks();

    return 0;
}