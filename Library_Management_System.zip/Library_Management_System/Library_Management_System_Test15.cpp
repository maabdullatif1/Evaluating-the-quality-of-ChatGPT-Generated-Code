#include<iostream>
#include<string>
#include<vector>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    bool is_issued;

    Book(int id, std::string title, std::string author) {
        this->id = id;
        this->title = title;
        this->author = author;
        this->is_issued = false;
    }
};

class Student {
public:
    int id;
    std::string name;

    Student(int id, std::string name) {
        this->id = id;
        this->name = name;
    }
};

class Library {
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void updateBook(int id, std::string title, std::string author) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
            }
        }
    }

    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(), [&](Book &b) {
            return b.id == id;
        }), books.end());
    }

    void searchBook(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Issued: " << (book.is_issued ? "Yes" : "No") << std::endl;
            }
        }
    }

    void displayBooks() {
        for (auto &book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Issued: " << (book.is_issued ? "Yes" : "No") << std::endl;
        }
    }

    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void updateStudent(int id, std::string name) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = name;
            }
        }
    }

    void deleteStudent(int id) {
        students.erase(std::remove_if(students.begin(), students.end(), [&](Student &s) {
            return s.id == id;
        }), students.end());
    }

    void searchStudent(int id) {
        for (auto &student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
            }
        }
    }

    void displayStudents() {
        for (auto &student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    Library library;
    library.addBook(1, "1984", "George Orwell");
    library.addStudent(1, "John Doe");
    library.displayBooks();
    library.displayStudents();
    library.searchBook(1);
    library.searchStudent(1);
    library.updateBook(1, "Animal Farm", "George Orwell");
    library.updateStudent(1, "Jane Doe");
    library.displayBooks();
    library.displayStudents();
    library.deleteBook(1);
    library.deleteStudent(1);
    library.displayBooks();
    library.displayStudents();
    return 0;
}