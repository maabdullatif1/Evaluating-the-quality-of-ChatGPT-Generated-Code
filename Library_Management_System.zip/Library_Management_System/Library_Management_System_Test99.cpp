#include <iostream>
#include <vector>
#include <string>

struct Student {
    int id;
    std::string name;
};

struct Book {
    int id;
    std::string title;
};

class LibraryManagementSystem {
private:
    std::vector<Student> students;
    std::vector<Book> books;

public:
    void addStudent(int id, const std::string& name) {
        students.push_back(Student{id, name});
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string& name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    std::string searchStudent(int id) const {
        for (const auto& student : students) {
            if (student.id == id) {
                return student.name;
            }
        }
        return "Student not found";
    }

    void displayStudents() const {
        for (const auto& student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << "\n";
        }
    }

    void addBook(int id, const std::string& title) {
        books.push_back(Book{id, title});
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const std::string& title) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                break;
            }
        }
    }

    std::string searchBook(int id) const {
        for (const auto& book : books) {
            if (book.id == id) {
                return book.title;
            }
        }
        return "Book not found";
    }

    void displayBooks() const {
        for (const auto& book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title << "\n";
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    
    lms.addStudent(1, "Alice");
    lms.addStudent(2, "Bob");
    lms.addBook(101, "The Great Gatsby");
    lms.addBook(102, "1984");
    
    std::cout << "Students:\n";
    lms.displayStudents();
    
    std::cout << "\nBooks:\n";
    lms.displayBooks();
    
    lms.updateStudent(1, "Alicia");
    lms.updateBook(101, "The Greater Gatsby");
    
    std::cout << "\nUpdated Students:\n";
    lms.displayStudents();
    
    std::cout << "\nUpdated Books:\n";
    lms.displayBooks();
    
    std::cout << "\nSearching for Student 2: " << lms.searchStudent(2) << "\n";
    std::cout << "Searching for Book 102: " << lms.searchBook(102) << "\n";
    
    lms.deleteStudent(2);
    lms.deleteBook(102);
    
    std::cout << "\nAfter Deletion:\n";
    std::cout << "Students:\n";
    lms.displayStudents();
    
    std::cout << "\nBooks:\n";
    lms.displayBooks();

    return 0;
}