#include <iostream>
#include <string>
#include <vector>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    
    Book(int id, std::string title, std::string author) : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;
    
    Student(int id, std::string name) : id(id), name(name) {}
};

class LibraryManagement {
private:
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }
    
    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }
    
    void updateBook(int id, std::string title, std::string author) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
            }
        }
    }
    
    void searchBook(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id << " Title: " << book.title << " Author: " << book.author << std::endl;
                return;
            }
        }
        std::cout << "Book not found." << std::endl;
    }
    
    void displayBooks() {
        for (auto &book : books) {
            std::cout << "Book ID: " << book.id << " Title: " << book.title << " Author: " << book.author << std::endl;
        }
    }
    
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }
    
    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }
    
    void updateStudent(int id, std::string name) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = name;
            }
        }
    }
    
    void searchStudent(int id) {
        for (auto &student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << " Name: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found." << std::endl;
    }
    
    void displayStudents() {
        for (auto &student : students) {
            std::cout << "Student ID: " << student.id << " Name: " << student.name << std::endl;
        }
    }
};

int main() {
    LibraryManagement lib;

    lib.addBook(1, "1984", "George Orwell");
    lib.addBook(2, "The Catcher in the Rye", "J.D. Salinger");
    
    lib.addStudent(1, "Alice");
    lib.addStudent(2, "Bob");

    std::cout << "All Books:" << std::endl;
    lib.displayBooks();

    std::cout << "All Students:" << std::endl;
    lib.displayStudents();

    std::cout << "Searching Book with ID 1:" << std::endl;
    lib.searchBook(1);

    std::cout << "Searching Student with ID 2:" << std::endl;
    lib.searchStudent(2);

    lib.updateBook(1, "Animal Farm", "George Orwell");
    lib.updateStudent(2, "Robert");

    std::cout << "Updated Books:" << std::endl;
    lib.displayBooks();

    std::cout << "Updated Students:" << std::endl;
    lib.displayStudents();

    lib.deleteBook(2);
    lib.deleteStudent(1);

    std::cout << "After Deletion:" << std::endl;
    lib.displayBooks();
    lib.displayStudents();

    return 0;
}