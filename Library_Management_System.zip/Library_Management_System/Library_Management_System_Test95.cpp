#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Book {
public:
    int id;
    string title;
    string author;

    Book(int id, string title, string author) : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    string name;
    string department;

    Student(int id, string name, string department) : id(id), name(name), department(department) {}
};

class LibraryManagementSystem {
private:
    vector<Book> books;
    vector<Student> students;

    template<typename T>
    typename vector<T>::iterator findById(vector<T>& v, int id) {
        for (auto it = v.begin(); it != v.end(); ++it) {
            if (it->id == id) {
                return it;
            }
        }
        return v.end();
    }

public:
    void addBook(int id, string title, string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        auto it = findById(books, id);
        if (it != books.end()) {
            books.erase(it);
        }
    }

    void updateBook(int id, string newTitle, string newAuthor) {
        auto it = findById(books, id);
        if (it != books.end()) {
            it->title = newTitle;
            it->author = newAuthor;
        }
    }

    Book* searchBook(int id) {
        auto it = findById(books, id);
        if (it != books.end()) {
            return &(*it);
        }
        return nullptr;
    }

    void addStudent(int id, string name, string department) {
        students.push_back(Student(id, name, department));
    }

    void deleteStudent(int id) {
        auto it = findById(students, id);
        if (it != students.end()) {
            students.erase(it);
        }
    }

    void updateStudent(int id, string newName, string newDepartment) {
        auto it = findById(students, id);
        if (it != students.end()) {
            it->name = newName;
            it->department = newDepartment;
        }
    }

    Student* searchStudent(int id) {
        auto it = findById(students, id);
        if (it != students.end()) {
            return &(*it);
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
        }
    }

    void displayStudents() {
        for (const auto& student : students) {
            cout << "Student ID: " << student.id << ", Name: " << student.name << ", Department: " << student.department << endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addBook(1, "1984", "George Orwell");
    lms.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    lms.addStudent(1, "Alice", "Computer Science");
    lms.addStudent(2, "Bob", "Mechanical Engineering");

    cout << "Books in the Library:" << endl;
    lms.displayBooks();
    cout << endl;

    cout << "Students in the Library System:" << endl;
    lms.displayStudents();
    cout << endl;

    lms.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    lms.updateStudent(1, "Alice Smith", "Computer Science");

    cout << "Updated Books in the Library:" << endl;
    lms.displayBooks();
    cout << endl;

    cout << "Updated Students in the Library System:" << endl;
    lms.displayStudents();
    cout << endl;

    Book* foundBook = lms.searchBook(2);
    if (foundBook) {
        cout << "Found Book - ID: " << foundBook->id << ", Title: " << foundBook->title << ", Author: " << foundBook->author << endl;
    }

    Student* foundStudent = lms.searchStudent(2);
    if(foundStudent) {
        cout << "Found Student - ID: " << foundStudent->id << ", Name: " << foundStudent->name << ", Department: " << foundStudent->department << endl;
    }

    lms.deleteBook(2);
    lms.deleteStudent(2);

    cout << "After Deletion, Books in the Library:" << endl;
    lms.displayBooks();
    cout << endl;

    cout << "After Deletion, Students in the Library System:" << endl;
    lms.displayStudents();

    return 0;
}