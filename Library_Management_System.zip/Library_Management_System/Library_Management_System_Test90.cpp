#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Student {
    int id;
    string name;
};

struct Book {
    int id;
    string title;
};

class LibraryManagementSystem {
    vector<Student> students;
    vector<Book> books;

    int findStudentIndex(int id) {
        for (int i = 0; i < students.size(); ++i)
            if (students[i].id == id)
                return i;
        return -1;
    }

    int findBookIndex(int id) {
        for (int i = 0; i < books.size(); ++i)
            if (books[i].id == id)
                return i;
        return -1;
    }

public:
    void addStudent(int id, string name) {
        if (findStudentIndex(id) == -1) {
            students.push_back({id, name});
        }
    }

    void deleteStudent(int id) {
        int index = findStudentIndex(id);
        if (index != -1) {
            students.erase(students.begin() + index);
        }
    }

    void updateStudent(int id, string name) {
        int index = findStudentIndex(id);
        if (index != -1) {
            students[index].name = name;
        }
    }

    void searchStudent(int id) {
        int index = findStudentIndex(id);
        if (index != -1) {
            cout << "Student Found: ID = " << students[index].id << ", Name = " << students[index].name << endl;
        } else {
            cout << "Student not found" << endl;
        }
    }

    void displayStudents() {
        for (const auto& student : students) {
            cout << "ID: " << student.id << ", Name: " << student.name << endl;
        }
    }

    void addBook(int id, string title) {
        if (findBookIndex(id) == -1) {
            books.push_back({id, title});
        }
    }

    void deleteBook(int id) {
        int index = findBookIndex(id);
        if (index != -1) {
            books.erase(books.begin() + index);
        }
    }

    void updateBook(int id, string title) {
        int index = findBookIndex(id);
        if (index != -1) {
            books[index].title = title;
        }
    }

    void searchBook(int id) {
        int index = findBookIndex(id);
        if (index != -1) {
            cout << "Book Found: ID = " << books[index].id << ", Title = " << books[index].title << endl;
        } else {
            cout << "Book not found" << endl;
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "ID: " << book.id << ", Title: " << book.title << endl;
        }
    }
};

int main() {
    LibraryManagementSystem system;

    system.addStudent(1, "Alice");
    system.addStudent(2, "Bob");
    system.displayStudents();
    system.updateStudent(2, "Bob Updated");
    system.searchStudent(2);
    system.deleteStudent(1);
    system.displayStudents();

    system.addBook(101, "C++ Programming");
    system.addBook(102, "Data Structures");
    system.displayBooks();
    system.updateBook(102, "Advanced Data Structures");
    system.searchBook(102);
    system.deleteBook(101);
    system.displayBooks();

    return 0;
}