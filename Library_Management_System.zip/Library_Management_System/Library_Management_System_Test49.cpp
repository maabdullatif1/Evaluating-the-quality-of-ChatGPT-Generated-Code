#include <iostream>
#include <string>
#include <vector>

class Book {
    int id;
    std::string title;
    std::string author;

public:
    Book(int id, std::string title, std::string author) : id(id), title(title), author(author) {}

    int getId() const { return id; }
    std::string getTitle() const { return title; }
    std::string getAuthor() const { return author; }
    
    void updateBook(std::string title, std::string author) {
        this->title = title;
        this->author = author;
    }

    void display() const {
        std::cout << "Book ID: " << id << ", Title: " << title << ", Author: " << author << std::endl;
    }
};

class Student {
    int id;
    std::string name;

public:
    Student(int id, std::string name) : id(id), name(name) {}

    int getId() const { return id; }
    std::string getName() const { return name; }
    
    void updateStudent(std::string name) {
        this->name = name;
    }

    void display() const {
        std::cout << "Student ID: " << id << ", Name: " << name << std::endl;
    }
};

class LibrarySystem {
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(), [id](Book& book) { return book.getId() == id; }), books.end());
    }

    void updateBook(int id, std::string title, std::string author) {
        for (auto& book : books) {
            if (book.getId() == id) {
                book.updateBook(title, author);
                break;
            }
        }
    }

    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        students.erase(std::remove_if(students.begin(), students.end(), [id](Student& student) { return student.getId() == id; }), students.end());
    }

    void updateStudent(int id, std::string name) {
        for (auto& student : students) {
            if (student.getId() == id) {
                student.updateStudent(name);
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.getId() == id) {
                book.display();
                return;
            }
        }
        std::cout << "Book not found." << std::endl;
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.getId() == id) {
                student.display();
                return;
            }
        }
        std::cout << "Student not found." << std::endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            book.display();
        }
    }

    void displayStudents() {
        for (const auto& student : students) {
            student.display();
        }
    }
};

int main() {
    LibrarySystem library;
    
    library.addBook(1, "1984", "George Orwell");
    library.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    library.addStudent(1, "John Doe");
    library.addStudent(2, "Jane Smith");
    
    library.displayBooks();
    library.displayStudents();

    library.updateBook(1, "Animal Farm", "George Orwell");
    library.updateStudent(1, "Johnathan Doe");
    
    library.searchBook(1);
    library.searchStudent(1);

    library.deleteBook(2);
    library.deleteStudent(2);
    
    library.displayBooks();
    library.displayStudents();

    return 0;
}