#include <iostream>
#include <vector>
#include <string>

class Student {
private:
    int id;
    std::string name;
public:
    Student(int id, const std::string& name) : id(id), name(name) {}
    
    int getId() const { return id; }
    std::string getName() const { return name; }

    void setName(const std::string& newName) { name = newName; }
};

class Book {
private:
    int id;
    std::string title;
public:
    Book(int id, const std::string& title) : id(id), title(title) {}
    
    int getId() const { return id; }
    std::string getTitle() const { return title; }

    void setTitle(const std::string& newTitle) { title = newTitle; }
};

class Library {
private:
    std::vector<Student> students;
    std::vector<Book> books;

public:
    void addStudent(int id, const std::string& name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(int id) {
        for (size_t i = 0; i < students.size(); ++i) {
            if (students[i].getId() == id) {
                students.erase(students.begin() + i);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string& name) {
        for (auto& student : students) {
            if (student.getId() == id) {
                student.setName(name);
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.getId() == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.getId() << ", Name: " << student.getName() << std::endl;
        }
    }

    void addBook(int id, const std::string& title) {
        books.emplace_back(id, title);
    }

    void deleteBook(int id) {
        for (size_t i = 0; i < books.size(); ++i) {
            if (books[i].getId() == id) {
                books.erase(books.begin() + i);
                break;
            }
        }
    }

    void updateBook(int id, const std::string& title) {
        for (auto& book : books) {
            if (book.getId() == id) {
                book.setTitle(title);
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.getId() == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.getId() << ", Title: " << book.getTitle() << std::endl;
        }
    }
};

int main() {
    Library lib;
    lib.addStudent(1, "Alice");
    lib.addStudent(2, "Bob");
    lib.displayStudents();
    lib.addBook(101, "C++ Programming");
    lib.addBook(102, "Data Structures");
    lib.displayBooks();

    Student* student = lib.searchStudent(1);
    if (student) {
        std::cout << "Found student: " << student->getName() << std::endl;
    }

    Book* book = lib.searchBook(101);
    if (book) {
        std::cout << "Found book: " << book->getTitle() << std::endl;
    }

    lib.updateStudent(2, "Robert");
    lib.displayStudents();

    lib.updateBook(102, "Advanced Data Structures");
    lib.displayBooks();

    lib.deleteStudent(1);
    lib.displayStudents();

    lib.deleteBook(101);
    lib.displayBooks();

    return 0;
}