#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int id, std::string title, std::string author) : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;

    Student(int id, std::string name) : id(id), name(name) {}
};

class Library {
private:
    std::vector<Book> books;
    std::vector<Student> students;

    int findBookIndex(int id) {
        for (size_t i = 0; i < books.size(); ++i) {
            if (books[i].id == id) return i;
        }
        return -1;
    }

    int findStudentIndex(int id) {
        for (size_t i = 0; i < students.size(); ++i) {
            if (students[i].id == id) return i;
        }
        return -1;
    }

public:
    void addBook(int id, std::string title, std::string author) {
        if (findBookIndex(id) == -1) {
            books.push_back(Book(id, title, author));
        }
    }

    void deleteBook(int id) {
        int index = findBookIndex(id);
        if (index != -1) {
            books.erase(books.begin() + index);
        }
    }

    void updateBook(int id, std::string title, std::string author) {
        int index = findBookIndex(id);
        if (index != -1) {
            books[index].title = title;
            books[index].author = author;
        }
    }

    Book* searchBook(int id) {
        int index = findBookIndex(id);
        if (index != -1) {
            return &books[index];
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }

    void addStudent(int id, std::string name) {
        if (findStudentIndex(id) == -1) {
            students.push_back(Student(id, name));
        }
    }

    void deleteStudent(int id) {
        int index = findStudentIndex(id);
        if (index != -1) {
            students.erase(students.begin() + index);
        }
    }

    void updateStudent(int id, std::string name) {
        int index = findStudentIndex(id);
        if (index != -1) {
            students[index].name = name;
        }
    }

    Student* searchStudent(int id) {
        int index = findStudentIndex(id);
        if (index != -1) {
            return &students[index];
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    Library library;

    library.addBook(1, "The Great Gatsby", "F. Scott Fitzgerald");
    library.addBook(2, "1984", "George Orwell");
    library.updateBook(1, "The Great Gatsby", "Francis Scott Fitzgerald");
    library.displayBooks();

    library.addStudent(1, "Alice");
    library.addStudent(2, "Bob");
    library.updateStudent(1, "Alice Wonderland");
    library.displayStudents();

    return 0;
}