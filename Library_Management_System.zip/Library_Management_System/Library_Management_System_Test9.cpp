#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Student {
public:
    int id;
    string name;
    Student(int id, string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    string title;
    Book(int id, string title) : id(id), title(title) {}
};

class LibraryManagementSystem {
    vector<Student> students;
    vector<Book> books;

public:
    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string newName) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                cout << "Student Found: ID = " << student.id << ", Name = " << student.name << endl;
                return;
            }
        }
        cout << "Student Not Found" << endl;
    }

    void displayStudents() {
        cout << "Students List:" << endl;
        for (const auto& student : students) {
            cout << "ID = " << student.id << ", Name = " << student.name << endl;
        }
    }

    void addBook(int id, string title) {
        books.push_back(Book(id, title));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string newTitle) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = newTitle;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                cout << "Book Found: ID = " << book.id << ", Title = " << book.title << endl;
                return;
            }
        }
        cout << "Book Not Found" << endl;
    }

    void displayBooks() {
        cout << "Books List:" << endl;
        for (const auto& book : books) {
            cout << "ID = " << book.id << ", Title = " << book.title << endl;
        }
    }
};

int main() {
    LibraryManagementSystem library;
    library.addStudent(1, "Alice");
    library.updateStudent(1, "Alicia");
    library.addBook(101, "C++ Programming");
    library.displayStudents();
    library.searchStudent(1);
    library.displayBooks();
    library.searchBook(101);
    library.deleteStudent(1);
    library.deleteBook(101);
    library.displayStudents();
    library.displayBooks();
    return 0;
}