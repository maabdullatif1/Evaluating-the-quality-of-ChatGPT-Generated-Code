#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int bookId, std::string bookTitle, std::string bookAuthor) 
        : id(bookId), title(bookTitle), author(bookAuthor) {}
};

class Student {
public:
    int id;
    std::string name;

    Student(int studentId, std::string studentName) 
        : id(studentId), name(studentName) {}
};

class LibraryManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }
    
    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }
    
    void updateBook(int id, std::string title, std::string author) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }
    
    void searchBook(int id) {
        for (const auto &book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title 
                          << ", Author: " << book.author << std::endl;
            }
        }
    }
    
    void displayBooks() {
        for (const auto &book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title 
                      << ", Author: " << book.author << std::endl;
        }
    }

    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }
    
    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }
    
    void updateStudent(int id, std::string name) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }
    
    void searchStudent(int id) {
        for (const auto &student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
            }
        }
    }

    void displayStudents() {
        for (const auto &student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem libSys;
    libSys.addBook(1, "1984", "George Orwell");
    libSys.addStudent(101, "Alice Johnson");
    libSys.displayBooks();
    libSys.displayStudents();
    libSys.updateBook(1, "Animal Farm", "George Orwell");
    libSys.searchBook(1);
    libSys.deleteStudent(101);
    libSys.displayStudents();
    return 0;
}