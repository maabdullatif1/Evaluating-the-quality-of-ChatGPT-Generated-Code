#include <iostream>
#include <string>
#include <vector>

class Student {
public:
    int studentID;
    std::string name;

    Student(int id, const std::string& name) : studentID(id), name(name) {}
};

class Book {
public:
    int bookID;
    std::string title;

    Book(int id, const std::string& title) : bookID(id), title(title) {}
};

class LibraryManagementSystem {
    std::vector<Student> students;
    std::vector<Book> books;

public:
    void addStudent(int id, const std::string& name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string& newName) {
        for (auto& student : students) {
            if (student.studentID == id) {
                student.name = newName;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.studentID == id) {
                std::cout << "Student ID: " << student.studentID << ", Name: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found." << std::endl;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.studentID << ", Name: " << student.name << std::endl;
        }
    }

    void addBook(int id, const std::string& title) {
        books.push_back(Book(id, title));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->bookID == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const std::string& newTitle) {
        for (auto& book : books) {
            if (book.bookID == id) {
                book.title = newTitle;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.bookID == id) {
                std::cout << "Book ID: " << book.bookID << ", Title: " << book.title << std::endl;
                return;
            }
        }
        std::cout << "Book not found." << std::endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.bookID << ", Title: " << book.title << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem library;

    library.addStudent(1, "Alice");
    library.addStudent(2, "Bob");
    library.displayStudents();
    library.updateStudent(1, "Alicia");
    library.searchStudent(1);
    library.deleteStudent(2);
    library.displayStudents();

    library.addBook(101, "C++ Programming");
    library.addBook(102, "Data Structures");
    library.displayBooks();
    library.updateBook(101, "Advanced C++ Programming");
    library.searchBook(101);
    library.deleteBook(102);
    library.displayBooks();

    return 0;
}