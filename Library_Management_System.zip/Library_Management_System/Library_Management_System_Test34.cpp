#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Book {
public:
    int id;
    string title;
    string author;

    Book(int i, string t, string a) : id(i), title(t), author(a) {}
};

class Student {
public:
    int id;
    string name;

    Student(int i, string n) : id(i), name(n) {}
};

class LibraryManagementSystem {
private:
    vector<Book> books;
    vector<Student> students;

    Book* findBookById(int id) {
        for (auto &book : books) {
            if (book.id == id) return &book;
        }
        return nullptr;
    }

    Student* findStudentById(int id) {
        for (auto &student : students) {
            if (student.id == id) return &student;
        }
        return nullptr;
    }

public:
    void addBook(int id, string title, string author) {
        if (findBookById(id)) {
            cout << "Book with this ID already exists." << endl;
            return;
        }
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                return;
            }
        }
        cout << "Book not found." << endl;
    }

    void updateBook(int id, string newTitle, string newAuthor) {
        Book* book = findBookById(id);
        if (book) {
            book->title = newTitle;
            book->author = newAuthor;
        } else {
            cout << "Book not found." << endl;
        }
    }

    void searchBook(int id) {
        Book* book = findBookById(id);
        if (book) {
            cout << "Book ID: " << book->id << ", Title: " << book->title << ", Author: " << book->author << endl;
        } else {
            cout << "Book not found." << endl;
        }
    }

    void displayBooks() {
        for (const auto &book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
        }
    }

    void addStudent(int id, string name) {
        if (findStudentById(id)) {
            cout << "Student with this ID already exists." << endl;
            return;
        }
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                return;
            }
        }
        cout << "Student not found." << endl;
    }

    void updateStudent(int id, string newName) {
        Student* student = findStudentById(id);
        if (student) {
            student->name = newName;
        } else {
            cout << "Student not found." << endl;
        }
    }

    void searchStudent(int id) {
        Student* student = findStudentById(id);
        if (student) {
            cout << "Student ID: " << student->id << ", Name: " << student->name << endl;
        } else {
            cout << "Student not found." << endl;
        }
    }

    void displayStudents() {
        for (const auto &student : students) {
            cout << "Student ID: " << student.id << ", Name: " << student.name << endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;

    lms.addBook(1, "1984", "George Orwell");
    lms.addBook(2, "To Kill a Mockingbird", "Harper Lee");

    lms.addStudent(1, "Alice");
    lms.addStudent(2, "Bob");

    lms.displayBooks();
    lms.displayStudents();

    lms.searchBook(1);
    lms.searchStudent(2);

    lms.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    lms.updateStudent(2, "Robert");

    lms.deleteBook(2);
    lms.deleteStudent(1);

    lms.displayBooks();
    lms.displayStudents();

    return 0;
}