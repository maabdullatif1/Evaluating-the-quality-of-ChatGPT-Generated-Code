#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Student {
    int id;
    string name;
};

struct Book {
    int id;
    string title;
};

class LibraryManagementSystem {
    vector<Student> students;
    vector<Book> books;

public:
    void addStudent(int id, string name) {
        for (const auto& s : students) {
            if (s.id == id) {
                cout << "Student ID already exists.\n";
                return;
            }
        }
        students.push_back({id, name});
        cout << "Student added.\n";
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                cout << "Student deleted.\n";
                return;
            }
        }
        cout << "Student not found.\n";
    }

    void updateStudent(int id, string newName) {
        for (auto& s : students) {
            if (s.id == id) {
                s.name = newName;
                cout << "Student updated.\n";
                return;
            }
        }
        cout << "Student not found.\n";
    }

    void searchStudent(int id) {
        for (const auto& s : students) {
            if (s.id == id) {
                cout << "Student ID: " << s.id << ", Name: " << s.name << "\n";
                return;
            }
        }
        cout << "Student not found.\n";
    }

    void displayStudents() {
        for (const auto& s : students) {
            cout << "Student ID: " << s.id << ", Name: " << s.name << "\n";
        }
    }

    void addBook(int id, string title) {
        for (const auto& b : books) {
            if (b.id == id) {
                cout << "Book ID already exists.\n";
                return;
            }
        }
        books.push_back({id, title});
        cout << "Book added.\n";
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                cout << "Book deleted.\n";
                return;
            }
        }
        cout << "Book not found.\n";
    }

    void updateBook(int id, string newTitle) {
        for (auto& b : books) {
            if (b.id == id) {
                b.title = newTitle;
                cout << "Book updated.\n";
                return;
            }
        }
        cout << "Book not found.\n";
    }

    void searchBook(int id) {
        for (const auto& b : books) {
            if (b.id == id) {
                cout << "Book ID: " << b.id << ", Title: " << b.title << "\n";
                return;
            }
        }
        cout << "Book not found.\n";
    }

    void displayBooks() {
        for (const auto& b : books) {
            cout << "Book ID: " << b.id << ", Title: " << b.title << "\n";
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addStudent(1, "John Doe");
    lms.addBook(101, "C++ Programming");
    lms.displayStudents();
    lms.displayBooks();
    lms.searchStudent(1);
    lms.searchBook(101);
    lms.updateStudent(1, "Jane Doe");
    lms.updateBook(101, "Advanced C++ Programming");
    lms.deleteStudent(1);
    lms.deleteBook(101);
    lms.displayStudents();
    lms.displayBooks();
    return 0;
}