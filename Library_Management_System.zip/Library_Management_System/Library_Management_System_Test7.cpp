#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int i, std::string t, std::string a) : id(i), title(t), author(a) {}
};

class Student {
public:
    int id;
    std::string name;

    Student(int i, std::string n) : id(i), name(n) {}
};

class Library {
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string newTitle, std::string newAuthor) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                std::cout << "Book found: " << book.title << " by " << book.author << std::endl;
                return;
            }
        }
        std::cout << "Book not found" << std::endl;
    }

    void displayBooks() {
        if (books.empty()) {
            std::cout << "No books available" << std::endl;
            return;
        }

        for (auto &book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }

    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string newName) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (auto &student : students) {
            if (student.id == id) {
                std::cout << "Student found: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }

    void displayStudents() {
        if (students.empty()) {
            std::cout << "No students found" << std::endl;
            return;
        }

        for (auto &student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    Library lib;

    lib.addBook(1, "1984", "George Orwell");
    lib.addBook(2, "The Catcher in the Rye", "J.D. Salinger");
    lib.displayBooks();

    lib.addStudent(1, "Alice Johnson");
    lib.addStudent(2, "Bob Smith");
    lib.displayStudents();

    lib.searchBook(1);
    lib.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    lib.displayBooks();

    lib.searchStudent(1);
    lib.updateStudent(1, "Alice Brown");
    lib.displayStudents();

    lib.deleteBook(2);
    lib.displayBooks();

    lib.deleteStudent(2);
    lib.displayStudents();

    return 0;
}