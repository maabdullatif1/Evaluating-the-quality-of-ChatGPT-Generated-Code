#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int id, std::string title, std::string author) : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;

    Student(int id, std::string name) : id(id), name(name) {}
};

class Library {
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string title, std::string author) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                std::cout << "Book Found: " << book.title << " by " << book.author << std::endl;
                return;
            }
        }
        std::cout << "Book Not Found" << std::endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }

    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                std::cout << "Student Found: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student Not Found" << std::endl;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    Library library;

    library.addBook(1, "The Great Gatsby", "F. Scott Fitzgerald");
    library.addBook(2, "1984", "George Orwell");

    library.addStudent(1, "Alice Johnson");
    library.addStudent(2, "Bob Smith");

    std::cout << "Displaying Books:" << std::endl;
    library.displayBooks();
    std::cout << "Displaying Students:" << std::endl;
    library.displayStudents();

    library.searchBook(1);
    library.searchStudent(2);

    library.updateBook(2, "Nineteen Eighty-Four", "George Orwell");
    library.updateStudent(1, "Alice Williams");

    std::cout << "After Updates:" << std::endl;
    library.displayBooks();
    library.displayStudents();

    library.deleteBook(1);
    library.deleteStudent(2);

    std::cout << "After Deletions:" << std::endl;
    library.displayBooks();
    library.displayStudents();

    return 0;
}