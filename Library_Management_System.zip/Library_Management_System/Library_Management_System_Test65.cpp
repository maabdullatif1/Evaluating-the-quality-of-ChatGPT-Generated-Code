#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Book {
public:
    string title;
    string author;
    string ISBN;

    Book(string t, string a, string i) : title(t), author(a), ISBN(i) {}
};

class Student {
public:
    string name;
    int studentID;

    Student(string n, int id) : name(n), studentID(id) {}
};

class LibraryManagementSystem {
    vector<Book> books;
    vector<Student> students;

public:
    void addBook(const Book& book) {
        books.push_back(book);
    }

    void deleteBook(const string& isbn) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->ISBN == isbn) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(const string& isbn, const string& newTitle, const string& newAuthor) {
        for (auto& book : books) {
            if (book.ISBN == isbn) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }

    void searchBook(const string& isbn) {
        for (const auto& book : books) {
            if (book.ISBN == isbn) {
                cout << "Book Found: " << book.title << ", " << book.author << endl;
                return;
            }
        }
        cout << "Book not found" << endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "Title: " << book.title << ", Author: " << book.author << ", ISBN: " << book.ISBN << endl;
        }
    }

    void addStudent(const Student& student) {
        students.push_back(student);
    }

    void deleteStudent(int studentId) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentID == studentId) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int studentId, const string& newName) {
        for (auto& student : students) {
            if (student.studentID == studentId) {
                student.name = newName;
                break;
            }
        }
    }

    void searchStudent(int studentId) {
        for (const auto& student : students) {
            if (student.studentID == studentId) {
                cout << "Student Found: " << student.name << ", ID: " << student.studentID << endl;
                return;
            }
        }
        cout << "Student not found" << endl;
    }

    void displayStudents() {
        for (const auto& student : students) {
            cout << "Name: " << student.name << ", ID: " << student.studentID << endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addBook(Book("The Great Gatsby", "F. Scott Fitzgerald", "123456789"));
    lms.addBook(Book("To Kill a Mockingbird", "Harper Lee", "987654321"));

    lms.addStudent(Student("Alice", 101));
    lms.addStudent(Student("Bob", 102));

    lms.displayBooks();
    lms.displayStudents();

    lms.searchBook("123456789");
    lms.searchStudent(101);

    lms.updateBook("123456789", "The Great Gatsby", "Fitzgerald");
    lms.updateStudent(101, "Alice Smith");

    lms.displayBooks();
    lms.displayStudents();

    lms.deleteBook("987654321");
    lms.deleteStudent(102);

    lms.displayBooks();
    lms.displayStudents();

    return 0;
}