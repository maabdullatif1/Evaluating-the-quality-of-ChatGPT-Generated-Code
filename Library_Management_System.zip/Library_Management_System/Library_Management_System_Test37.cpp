#include <iostream>
#include <vector>
#include <string>

class Student {
public:
    int id;
    std::string name;
    Student(int i, const std::string& n) : id(i), name(n) {}
};

class Book {
public:
    int id;
    std::string title;
    Book(int i, const std::string& t) : id(i), title(t) {}
};

class LibraryManagementSystem {
    std::vector<Student> students;
    std::vector<Book> books;

public:
    void addStudent(int id, const std::string& name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        students.erase(std::remove_if(students.begin(), students.end(), [id](Student& s) { return s.id == id; }), students.end());
    }

    void updateStudent(int id, const std::string& newName) {
        for (auto& s : students) {
            if (s.id == id) {
                s.name = newName;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& s : students) {
            if (s.id == id) {
                std::cout << "Student found: ID=" << s.id << ", Name=" << s.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found." << std::endl;
    }

    void displayStudents() {
        if (students.empty()) {
            std::cout << "No students found." << std::endl;
            return;
        }
        for (const auto& s : students) {
            std::cout << "ID=" << s.id << ", Name=" << s.name << std::endl;
        }
    }

    void addBook(int id, const std::string& title) {
        books.push_back(Book(id, title));
    }

    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(), [id](Book& b) { return b.id == id; }), books.end());
    }

    void updateBook(int id, const std::string& newTitle) {
        for (auto& b : books) {
            if (b.id == id) {
                b.title = newTitle;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& b : books) {
            if (b.id == id) {
                std::cout << "Book found: ID=" << b.id << ", Title=" << b.title << std::endl;
                return;
            }
        }
        std::cout << "Book not found." << std::endl;
    }

    void displayBooks() {
        if (books.empty()) {
            std::cout << "No books found." << std::endl;
            return;
        }
        for (const auto& b : books) {
            std::cout << "ID=" << b.id << ", Title=" << b.title << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addStudent(1, "Alice");
    lms.addStudent(2, "Bob");
    lms.addBook(101, "C++ Programming");
    lms.addBook(102, "Data Structures");
    lms.displayStudents();
    lms.displayBooks();
    lms.updateStudent(1, "Alicia");
    lms.updateBook(101, "Advanced C++ Programming");
    lms.searchStudent(1);
    lms.searchBook(101);
    lms.deleteStudent(2);
    lms.deleteBook(102);
    lms.displayStudents();
    lms.displayBooks();
    return 0;
}