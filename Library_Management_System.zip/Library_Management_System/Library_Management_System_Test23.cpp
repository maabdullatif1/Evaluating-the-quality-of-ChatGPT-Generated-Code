#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int i, std::string t, std::string a) : id(i), title(t), author(a) {}
};

class Student {
public:
    int id;
    std::string name;

    Student(int i, std::string n) : id(i), name(n) {}
};

class LibraryManagementSystem {
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string title, std::string author) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto &book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
                return;
            }
        }
        std::cout << "Book not found" << std::endl;
    }

    void displayBooks() {
        for (const auto &book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }

    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string name) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto &student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }

    void displayStudents() {
        for (const auto &student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;

    lms.addBook(1, "1984", "George Orwell");
    lms.addBook(2, "To Kill a Mockingbird", "Harper Lee");

    lms.addStudent(1, "Alice");
    lms.addStudent(2, "Bob");

    lms.displayBooks();
    lms.displayStudents();

    lms.searchBook(1);
    lms.searchStudent(2);

    lms.updateBook(1, "Animal Farm", "George Orwell");
    lms.updateStudent(2, "Charlie");

    lms.displayBooks();
    lms.displayStudents();

    lms.deleteBook(1);
    lms.deleteStudent(1);

    lms.displayBooks();
    lms.displayStudents();

    return 0;
}