#include <iostream>
#include <vector>
#include <string>

class Student {
public:
    int id;
    std::string name;
    Student(int id, std::string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;
    Book(int id, std::string title) : id(id), title(title) {}
};

class Library {
    std::vector<Student> students;
    std::vector<Book> books;

public:
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for(auto it = students.begin(); it != students.end(); ++it) {
            if(it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string newName) {
        for(auto &student : students) {
            if(student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for(const auto &student : students) {
            if(student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found." << std::endl;
    }

    void displayStudents() {
        for(const auto &student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }

    void addBook(int id, std::string title) {
        books.push_back(Book(id, title));
    }

    void deleteBook(int id) {
        for(auto it = books.begin(); it != books.end(); ++it) {
            if(it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string newTitle) {
        for(auto &book : books) {
            if(book.id == id) {
                book.title = newTitle;
                break;
            }
        }
    }

    void searchBook(int id) {
        for(const auto &book : books) {
            if(book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << std::endl;
                return;
            }
        }
        std::cout << "Book not found." << std::endl;
    }

    void displayBooks() {
        for(const auto &book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << std::endl;
        }
    }
};

int main() {
    Library library;
    library.addStudent(1, "Alice");
    library.addStudent(2, "Bob");
    library.addBook(1, "C++ Programming");
    library.addBook(2, "Data Structures");

    std::cout << "Displaying all students:\n";
    library.displayStudents();

    std::cout << "Displaying all books:\n";
    library.displayBooks();

    std::cout << "Searching for Student ID 1:\n";
    library.searchStudent(1);

    std::cout << "Updating Student ID 1's name to 'Alicia':\n";
    library.updateStudent(1, "Alicia");
    library.displayStudents();

    std::cout << "Deleting Book ID 2:\n";
    library.deleteBook(2);
    library.displayBooks();

    return 0;
}