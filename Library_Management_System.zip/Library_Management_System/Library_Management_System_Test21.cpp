#include <iostream>
#include <vector>
#include <string>

struct Student {
    int id;
    std::string name;
};

struct Book {
    int id;
    std::string title;
    std::string author;
};

class Library {
    std::vector<Student> students;
    std::vector<Book> books;

public:
    void addStudent(int id, std::string name) {
        students.push_back({id, name});
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(int id, std::string name) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = name;
                return;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto &student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << "\n";
                return;
            }
        }
        std::cout << "Student not found\n";
    }

    void displayStudents() {
        for (const auto &student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << "\n";
        }
    }

    void addBook(int id, std::string title, std::string author) {
        books.push_back({id, title, author});
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                return;
            }
        }
    }

    void updateBook(int id, std::string title, std::string author) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                return;
            }
        }
    }

    void searchBook(int id) {
        for (const auto &book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << "\n";
                return;
            }
        }
        std::cout << "Book not found\n";
    }

    void displayBooks() {
        for (const auto &book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << "\n";
        }
    }
};

int main() {
    Library library;
    library.addStudent(1, "John Doe");
    library.addStudent(2, "Jane Smith");
    library.displayStudents();
    library.updateStudent(1, "Johnny Doe");
    library.searchStudent(1);
    library.deleteStudent(2);
    library.displayStudents();

    library.addBook(1, "1984", "George Orwell");
    library.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    library.displayBooks();
    library.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    library.searchBook(1);
    library.deleteBook(2);
    library.displayBooks();

    return 0;
}