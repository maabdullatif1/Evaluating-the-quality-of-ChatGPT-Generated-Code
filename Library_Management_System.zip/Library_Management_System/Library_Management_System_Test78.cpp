#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int bookId, std::string bookTitle, std::string bookAuthor)
        : id(bookId), title(bookTitle), author(bookAuthor) {}
};

class Student {
public:
    int id;
    std::string name;

    Student(int studentId, std::string studentName)
        : id(studentId), name(studentName) {}
};

class LibraryManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (size_t i = 0; i < books.size(); ++i) {
            if (books[i].id == id) {
                books.erase(books.begin() + i);
                break;
            }
        }
    }

    void updateBook(int id, std::string title, std::string author) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto &book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }

    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (size_t i = 0; i < students.size(); ++i) {
            if (students[i].id == id) {
                students.erase(students.begin() + i);
                break;
            }
        }
    }

    void updateStudent(int id, std::string name) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto &student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto &student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem library;

    library.addBook(1, "Harry Potter", "J.K. Rowling");
    library.addBook(2, "The Hobbit", "J.R.R. Tolkien");
    library.addStudent(1, "Alice");
    library.addStudent(2, "Bob");

    library.displayBooks();
    library.displayStudents();

    library.updateBook(1, "Harry Potter and the Philosopher's Stone", "J.K. Rowling");
    library.updateStudent(2, "Charlie");

    library.searchBook(2) ? std::cout << "Book Found\n" : std::cout << "Book Not Found\n";
    library.searchStudent(3) ? std::cout << "Student Found\n" : std::cout << "Student Not Found\n";

    library.deleteBook(2);
    library.deleteStudent(1);

    library.displayBooks();
    library.displayStudents();

    return 0;
}