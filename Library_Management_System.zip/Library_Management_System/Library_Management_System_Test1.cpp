#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Book {
    int id;
    string title;
    string author;
    bool isAvailable;
};

struct Student {
    int id;
    string name;
    vector<int> borrowedBooks;
};

class Library {
    vector<Book> books;
    vector<Student> students;

    Book* findBook(int bookId) {
        for (auto &book : books) {
            if (book.id == bookId) {
                return &book;
            }
        }
        return nullptr;
    }

    Student* findStudent(int studentId) {
        for (auto &student : students) {
            if (student.id == studentId) {
                return &student;
            }
        }
        return nullptr;
    }

public:
    void addBook(int id, const string& title, const string& author) {
        books.push_back({id, title, author, true});
    }

    void deleteBook(int bookId) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == bookId) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int bookId, const string& newTitle, const string& newAuthor) {
        Book* book = findBook(bookId);
        if (book) {
            book->title = newTitle;
            book->author = newAuthor;
        }
    }

    void searchBook(int bookId) {
        Book* book = findBook(bookId);
        if (book) {
            cout << "Book ID: " << book->id << ", Title: " << book->title 
                 << ", Author: " << book->author << ", Available: " 
                 << (book->isAvailable ? "Yes" : "No") << endl;
        } else {
            cout << "Book not found" << endl;
        }
    }

    void displayBooks() {
        for (const auto &book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title 
                 << ", Author: " << book.author << ", Available: " 
                 << (book.isAvailable ? "Yes" : "No") << endl;
        }
    }

    void addStudent(int id, const string& name) {
        students.push_back({id, name, {}});
    }

    void deleteStudent(int studentId) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == studentId) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int studentId, const string& newName) {
        Student* student = findStudent(studentId);
        if (student) {
            student->name = newName;
        }
    }

    void searchStudent(int studentId) {
        Student* student = findStudent(studentId);
        if (student) {
            cout << "Student ID: " << student->id << ", Name: " << student->name << endl;
            if (student->borrowedBooks.empty()) {
                cout << "No books borrowed" << endl;
            } else {
                cout << "Borrowed Books IDs: ";
                for (auto bookId : student->borrowedBooks) {
                    cout << bookId << " ";
                }
                cout << endl;
            }
        } else {
            cout << "Student not found" << endl;
        }
    }

    void displayStudents() {
        for (const auto &student : students) {
            cout << "Student ID: " << student.id << ", Name: " << student.name << endl;
            if (student.borrowedBooks.empty()) {
                cout << "No books borrowed" << endl;
            } else {
                cout << "Borrowed Books IDs: ";
                for (auto bookId : student.borrowedBooks) {
                    cout << bookId << " ";
                }
                cout << endl;
            }
        }
    }
};

int main() {
    Library library;

    library.addBook(1, "1984", "George Orwell");
    library.addBook(2, "To Kill a Mockingbird", "Harper Lee");

    library.addStudent(1, "John Doe");
    library.addStudent(2, "Jane Smith");

    library.displayBooks();
    library.displayStudents();

    library.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    library.updateStudent(1, "Johnathan Doe");

    library.displayBooks();
    library.displayStudents();

    library.searchBook(1);
    library.searchStudent(2);

    library.deleteBook(2);
    library.deleteStudent(1);

    library.displayBooks();
    library.displayStudents();

    return 0;
}