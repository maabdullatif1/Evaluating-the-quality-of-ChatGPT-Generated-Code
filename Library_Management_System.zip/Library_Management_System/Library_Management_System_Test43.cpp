#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Student {
    int id;
    string name;
};

struct Book {
    int id;
    string title;
    string author;
};

class LibraryManagementSystem {
    vector<Student> students;
    vector<Book> books;
    
    int findStudentIndex(int studentId) {
        for (int i = 0; i < students.size(); ++i) {
            if (students[i].id == studentId) return i;
        }
        return -1;
    }
    
    int findBookIndex(int bookId) {
        for (int i = 0; i < books.size(); ++i) {
            if (books[i].id == bookId) return i;
        }
        return -1;
    }
    
public:
    void addStudent(int id, const string& name) {
        if (findStudentIndex(id) == -1) {
            students.push_back(Student{id, name});
        }
    }
    
    void deleteStudent(int id) {
        int index = findStudentIndex(id);
        if (index != -1) {
            students.erase(students.begin() + index);
        }
    }
    
    void updateStudent(int id, const string& newName) {
        int index = findStudentIndex(id);
        if (index != -1) {
            students[index].name = newName;
        }
    }
    
    Student* searchStudent(int id) {
        int index = findStudentIndex(id);
        if (index != -1) {
            return &students[index];
        }
        return nullptr;
    }
    
    void displayStudents() {
        for (const auto& student : students) {
            cout << "Student ID: " << student.id << ", Name: " << student.name << endl;
        }
    }
    
    void addBook(int id, const string& title, const string& author) {
        if (findBookIndex(id) == -1) {
            books.push_back(Book{id, title, author});
        }
    }
    
    void deleteBook(int id) {
        int index = findBookIndex(id);
        if (index != -1) {
            books.erase(books.begin() + index);
        }
    }
    
    void updateBook(int id, const string& newTitle, const string& newAuthor) {
        int index = findBookIndex(id);
        if (index != -1) {
            books[index].title = newTitle;
            books[index].author = newAuthor;
        }
    }
    
    Book* searchBook(int id) {
        int index = findBookIndex(id);
        if (index != -1) {
            return &books[index];
        }
        return nullptr;
    }
    
    void displayBooks() {
        for (const auto& book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
        }
    }
};

int main() {
    LibraryManagementSystem library;

    library.addStudent(1, "Alice");
    library.addStudent(2, "Bob");
    library.updateStudent(1, "Alicia");
    library.displayStudents();
    
    library.addBook(100, "The Great Gatsby", "F. Scott Fitzgerald");
    library.addBook(101, "1984", "George Orwell");
    library.updateBook(100, "The Great Gatsby", "Francis Scott Fitzgerald");
    library.displayBooks();
    
    return 0;
}