#include <iostream>
#include <vector>
#include <string>

class Student {
public:
    int id;
    std::string name;
    std::string department;
    
    Student(int id, const std::string &name, const std::string &department)
        : id(id), name(name), department(department) {}
};

class Book {
public:
    int id;
    std::string title;
    std::string author;
    
    Book(int id, const std::string &title, const std::string &author)
        : id(id), title(title), author(author) {}
};

class LibraryManagementSystem {
private:
    std::vector<Student> students;
    std::vector<Book> books;

public:
    void addStudent(int id, const std::string &name, const std::string &department) {
        students.emplace_back(id, name, department);
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string &name, const std::string &department) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = name;
                student.department = department;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto &student : students) {
            if (student.id == id) {
                std::cout << "Student Found: ID: " << student.id << ", Name: " << student.name
                          << ", Department: " << student.department << "\n";
                return;
            }
        }
        std::cout << "Student not found\n";
    }

    void displayStudents() {
        for (const auto &student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name
                      << ", Department: " << student.department << "\n";
        }
    }

    void addBook(int id, const std::string &title, const std::string &author) {
        books.emplace_back(id, title, author);
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const std::string &title, const std::string &author) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto &book : books) {
            if (book.id == id) {
                std::cout << "Book Found: ID: " << book.id << ", Title: " << book.title
                          << ", Author: " << book.author << "\n";
                return;
            }
        }
        std::cout << "Book not found\n";
    }

    void displayBooks() {
        for (const auto &book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title
                      << ", Author: " << book.author << "\n";
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addStudent(1, "Alice", "Computer Science");
    lms.addStudent(2, "Bob", "Mathematics");
    lms.addBook(1, "C++ Programming", "Bjarne Stroustrup");
    lms.addBook(2, "Introduction to Algorithms", "Thomas H. Cormen");
    lms.displayStudents();
    lms.displayBooks();
    lms.searchStudent(1);
    lms.searchBook(2);
    lms.updateStudent(2, "Charlie", "Physics");
    lms.updateBook(1, "C++ Programming Language", "Bjarne Stroustrup");
    lms.displayStudents();
    lms.displayBooks();
    lms.deleteStudent(1);
    lms.deleteBook(2);
    lms.displayStudents();
    lms.displayBooks();
    return 0;
}