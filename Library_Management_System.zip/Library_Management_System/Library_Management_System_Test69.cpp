#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int id, std::string title, std::string author) 
        : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;
    std::string department;

    Student(int id, std::string name, std::string department) 
        : id(id), name(name), department(department) {}
};

class Library {
private:
    std::vector<Book> books;
    std::vector<Student> students;

    template<typename T>
    void display(const std::vector<T>& elements) {
        for (const auto& element : elements) {
            std::cout << "ID: " << element.id << "\nName: " << element.name 
                      << "\nOther: " << (std::is_same<T, Book>::value ? element.author : element.department) 
                      << "\n\n";
        }
    }

    template<typename T>
    typename std::vector<T>::iterator search(std::vector<T>& elements, int id) {
        return std::find_if(elements.begin(), elements.end(), [id](const T& element) {
            return element.id == id;
        });
    }

    template<typename T>
    void add(std::vector<T>& elements, const T& element) {
        if (search(elements, element.id) == elements.end()) {
            elements.push_back(element);
        }
    }

    template<typename T>
    void remove(std::vector<T>& elements, int id) {
        auto it = search(elements, id);
        if (it != elements.end()) {
            elements.erase(it);
        }
    }

    template<typename T>
    void update(std::vector<T>& elements, const T& element) {
        auto it = search(elements, element.id);
        if (it != elements.end()) {
            *it = element;
        }
    }

public:
    void addBook(int id, std::string title, std::string author) {
        add(books, Book(id, title, author));
    }

    void addStudent(int id, std::string name, std::string department) {
        add(students, Student(id, name, department));
    }

    void deleteBook(int id) {
        remove(books, id);
    }

    void deleteStudent(int id) {
        remove(students, id);
    }

    void updateBook(int id, std::string title, std::string author) {
        update(books, Book(id, title, author));
    }

    void updateStudent(int id, std::string name, std::string department) {
        update(students, Student(id, name, department));
    }

    Book* searchBook(int id) {
        auto it = search(books, id);
        return (it != books.end()) ? &(*it) : nullptr;
    }

    Student* searchStudent(int id) {
        auto it = search(students, id);
        return (it != students.end()) ? &(*it) : nullptr;
    }

    void displayBooks() {
        display(books);
    }

    void displayStudents() {
        display(students);
    }
};

int main() {
    Library library;
    library.addBook(1, "Book A", "Author A");
    library.addStudent(1, "Student A", "Dept A");
    library.displayBooks();
    library.displayStudents();
    library.updateBook(1, "Updated Book A", "Updated Author A");
    library.updateStudent(1, "Updated Student A", "Updated Dept A");
    library.displayBooks();
    library.displayStudents();
    library.deleteBook(1);
    library.deleteStudent(1);
    library.displayBooks();
    library.displayStudents();
    return 0;
}