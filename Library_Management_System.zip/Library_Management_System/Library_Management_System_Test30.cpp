#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int i, const std::string &t, const std::string &a) : id(i), title(t), author(a) {}
};

class Student {
public:
    int id;
    std::string name;

    Student(int i, const std::string &n) : id(i), name(n) {}
};

class LibraryManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Student> students;

    Book* findBook(int id) {
        for (auto &book : books) {
            if (book.id == id) return &book;
        }
        return nullptr;
    }

    Student* findStudent(int id) {
        for (auto &student : students) {
            if (student.id == id) return &student;
        }
        return nullptr;
    }

public:
    void addBook(int id, const std::string &title, const std::string &author) {
        if (findBook(id) == nullptr) {
            books.push_back(Book(id, title, author));
        }
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const std::string &title, const std::string &author) {
        Book* book = findBook(id);
        if (book) {
            book->title = title;
            book->author = author;
        }
    }

    void searchBook(int id) {
        Book* book = findBook(id);
        if (book) {
            std::cout << "Book Found: " << book->id << ", " << book->title << ", " << book->author << std::endl;
        } else {
            std::cout << "Book Not Found" << std::endl;
        }
    }

    void displayBooks() {
        for (auto &book : books) {
            std::cout << book.id << ", " << book.title << ", " << book.author << std::endl;
        }
    }

    void addStudent(int id, const std::string &name) {
        if (findStudent(id) == nullptr) {
            students.push_back(Student(id, name));
        }
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string &name) {
        Student* student = findStudent(id);
        if (student) {
            student->name = name;
        }
    }

    void searchStudent(int id) {
        Student* student = findStudent(id);
        if (student) {
            std::cout << "Student Found: " << student->id << ", " << student->name << std::endl;
        } else {
            std::cout << "Student Not Found" << std::endl;
        }
    }

    void displayStudents() {
        for (auto &student : students) {
            std::cout << student.id << ", " << student.name << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addBook(1, "C++ Programming", "Author A");
    lms.addBook(2, "Data Structures", "Author B");
    lms.displayBooks();
    lms.addStudent(1, "John Doe");
    lms.addStudent(2, "Jane Smith");
    lms.displayStudents();
    lms.searchBook(2);
    lms.searchStudent(1);
    lms.updateBook(1, "Advanced C++ Programming", "Author AA");
    lms.updateStudent(2, "Jane Doe");
    lms.displayBooks();
    lms.displayStudents();
    lms.deleteBook(1);
    lms.deleteStudent(1);
    lms.displayBooks();
    lms.displayStudents();
    return 0;
}