#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Student {
public:
    int id;
    string name;

    Student(int id, string name) : id(id), name(name) {}
};

class Book {
public:
    int isbn;
    string title;

    Book(int isbn, string title) : isbn(isbn), title(title) {}
};

class Library {
    vector<Student> students;
    vector<Book> books;

public:
    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string newName) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto &student : students) {
            if (student.id == id) {
                cout << "Student found: " << student.name << endl;
                return;
            }
        }
        cout << "Student not found" << endl;
    }

    void displayStudents() {
        for (const auto &student : students) {
            cout << "ID: " << student.id << ", Name: " << student.name << endl;
        }
    }

    void addBook(int isbn, string title) {
        books.push_back(Book(isbn, title));
    }

    void deleteBook(int isbn) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->isbn == isbn) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int isbn, string newTitle) {
        for (auto &book : books) {
            if (book.isbn == isbn) {
                book.title = newTitle;
                break;
            }
        }
    }

    void searchBook(int isbn) {
        for (const auto &book : books) {
            if (book.isbn == isbn) {
                cout << "Book found: " << book.title << endl;
                return;
            }
        }
        cout << "Book not found" << endl;
    }

    void displayBooks() {
        for (const auto &book : books) {
            cout << "ISBN: " << book.isbn << ", Title: " << book.title << endl;
        }
    }
};

int main() {
    Library library;

    library.addStudent(1, "John Doe");
    library.addStudent(2, "Jane Smith");
    
    library.addBook(101, "C++ Programming");
    library.addBook(102, "Data Structures");

    library.displayStudents();
    library.displayBooks();

    library.searchStudent(1);
    library.searchBook(101);

    library.updateStudent(1, "Johnathan Doe");
    library.updateBook(101, "Advanced C++ Programming");

    library.displayStudents();
    library.displayBooks();

    library.deleteStudent(2);
    library.deleteBook(102);

    library.displayStudents();
    library.displayBooks();

    return 0;
}