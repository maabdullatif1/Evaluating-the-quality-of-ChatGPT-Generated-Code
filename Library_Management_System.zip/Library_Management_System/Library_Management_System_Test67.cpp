#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    Book(int i, std::string t, std::string a) : id(i), title(t), author(a) {}
};

class Student {
public:
    int id;
    std::string name;
    Student(int i, std::string n) : id(i), name(n) {}
};

class LibraryManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Student> students;

    template<typename T>
    T* findById(std::vector<T>& vec, int id) {
        for (auto& item : vec) {
            if (item.id == id) return &item;
        }
        return nullptr;
    }

    template<typename T>
    void displayItems(const std::vector<T>& vec) {
        for (const auto& item : vec) {
            if constexpr (std::is_same<T, Book>::value) {
                std::cout << "Book ID: " << item.id << ", Title: " << item.title << ", Author: " << item.author << "\n";
            } else {
                std::cout << "Student ID: " << item.id << ", Name: " << item.name << "\n";
            }
        }
    }

public:
    void addBook(int id, std::string title, std::string author) {
        if (!findById(books, id)) {
            books.emplace_back(id, title, author);
        }
    }

    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(), [id](Book& b) { return b.id == id; }), books.end());
    }

    void updateBook(int id, std::string title, std::string author) {
        Book* book = findById(books, id);
        if (book) {
            book->title = title;
            book->author = author;
        }
    }

    void searchBook(int id) {
        Book* book = findById(books, id);
        if (book) {
            std::cout << "Book found - ID: " << book->id << ", Title: " << book->title << ", Author: " << book->author << "\n";
        } else {
            std::cout << "Book not found\n";
        }
    }

    void displayBooks() {
        displayItems(books);
    }

    void addStudent(int id, std::string name) {
        if (!findById(students, id)) {
            students.emplace_back(id, name);
        }
    }

    void deleteStudent(int id) {
        students.erase(std::remove_if(students.begin(), students.end(), [id](Student& s) { return s.id == id; }), students.end());
    }

    void updateStudent(int id, std::string name) {
        Student* student = findById(students, id);
        if (student) {
            student->name = name;
        }
    }

    void searchStudent(int id) {
        Student* student = findById(students, id);
        if (student) {
            std::cout << "Student found - ID: " << student->id << ", Name: " << student->name << "\n";
        } else {
            std::cout << "Student not found\n";
        }
    }

    void displayStudents() {
        displayItems(students);
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addBook(1, "1984", "George Orwell");
    lms.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    lms.addStudent(1, "Alice");
    lms.addStudent(2, "Bob");
    lms.displayBooks();
    lms.displayStudents();
    lms.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    lms.updateStudent(1, "Alice Smith");
    lms.displayBooks();
    lms.displayStudents();
    lms.searchBook(2);
    lms.searchStudent(3);
    lms.deleteBook(2);
    lms.deleteStudent(2);
    lms.displayBooks();
    lms.displayStudents();
    return 0;
}