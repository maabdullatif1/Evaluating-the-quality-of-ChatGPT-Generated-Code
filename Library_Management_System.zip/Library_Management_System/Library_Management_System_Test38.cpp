#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int id, std::string title, std::string author)
        : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;
    int age;

    Student(int id, std::string name, int age)
        : id(id), name(name), age(age) {}
};

class LibraryManagementSystem {
    std::vector<Book> books;
    std::vector<Student> students;
    
    template <typename T, typename U>
    void removeById(std::vector<T>& elements, U id) {
        for (auto it = elements.begin(); it != elements.end(); ++it) {
            if (it->id == id) {
                elements.erase(it);
                break;
            }
        }
    }

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void addStudent(int id, std::string name, int age) {
        students.push_back(Student(id, name, age));
    }

    void deleteBook(int id) {
        removeById(books, id);
    }

    void deleteStudent(int id) {
        removeById(students, id);
    }

    void updateBook(int id, std::string newTitle, std::string newAuthor) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }

    void updateStudent(int id, std::string newName, int newAge) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = newName;
                student.age = newAge;
                break;
            }
        }
    }

    Book* searchBookById(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    Student* searchStudentById(int id) {
        for (auto& student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayAllBooks() {
        for (const auto& book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title 
                      << ", Author: " << book.author << std::endl;
        }
    }

    void displayAllStudents() {
        for (const auto& student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name 
                      << ", Age: " << student.age << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addBook(1, "1984", "George Orwell");
    lms.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    lms.addStudent(1, "Alice", 20);
    lms.addStudent(2, "Bob", 22);
    lms.displayAllBooks();
    lms.displayAllStudents();
    Book* book = lms.searchBookById(1);
    if (book) std::cout << "Found Book: " << book->title << std::endl;
    Student* student = lms.searchStudentById(2);
    if (student) std::cout << "Found Student: " << student->name << std::endl;
    lms.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    lms.updateStudent(2, "Robert", 23);
    lms.deleteBook(2);
    lms.displayAllBooks();
    lms.displayAllStudents();
    return 0;
}