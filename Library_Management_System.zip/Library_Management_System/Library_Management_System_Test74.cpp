#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Student {
public:
    int id;
    string name;

    Student(int id, string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    string title;
    string author;

    Book(int id, string title, string author) : id(id), title(title), author(author) {}
};

class LibraryManagement {
private:
    vector<Student> students;
    vector<Book> books;

public:
    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(int id, string name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                return;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.id == id) return &student;
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            cout << "ID: " << student.id << ", Name: " << student.name << endl;
        }
    }

    void addBook(int id, string title, string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                return;
            }
        }
    }

    void updateBook(int id, string title, string author) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                return;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) return &book;
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
        }
    }
};

int main() {
    LibraryManagement libMgmt;

    libMgmt.addStudent(1, "Alice");
    libMgmt.addStudent(2, "Bob");

    libMgmt.addBook(101, "1984", "George Orwell");
    libMgmt.addBook(102, "To Kill a Mockingbird", "Harper Lee");

    cout << "Current Students:" << endl;
    libMgmt.displayStudents();

    cout << "Current Books:" << endl;
    libMgmt.displayBooks();

    libMgmt.updateStudent(1, "Alice Smith");
    libMgmt.updateBook(101, "1984", "G. Orwell");

    cout << "Updated Students:" << endl;
    libMgmt.displayStudents();

    cout << "Updated Books:" << endl;
    libMgmt.displayBooks();

    libMgmt.deleteStudent(2);
    libMgmt.deleteBook(102);

    cout << "Final Students:" << endl;
    libMgmt.displayStudents();

    cout << "Final Books:" << endl;
    libMgmt.displayBooks();

    Student* student = libMgmt.searchStudent(1);
    if (student != nullptr) {
        cout << "Found Student: ID: " << student->id << ", Name: " << student->name << endl;
    }

    Book* book = libMgmt.searchBook(101);
    if (book != nullptr) {
        cout << "Found Book: ID: " << book->id << ", Title: " << book->title << ", Author: " << book->author << endl;
    }

    return 0;
}