#include <iostream>
#include <string>
#include <vector>

class Book {
public:
    std::string title;
    std::string author;
    int id;
    Book(int id, std::string title, std::string author) : id(id), title(title), author(author) {}
};

class Student {
public:
    std::string name;
    int id;
    Student(int id, std::string name) : id(id), name(name) {}
};

class Library {
private:
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (size_t i = 0; i < books.size(); ++i) {
            if (books[i].id == id) {
                books.erase(books.begin() + i);
                break;
            }
        }
    }

    void updateBook(int id, std::string newTitle, std::string newAuthor) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
                break;
            }
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }

    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (size_t i = 0; i < students.size(); ++i) {
            if (students[i].id == id) {
                students.erase(students.begin() + i);
                break;
            }
        }
    }

    void updateStudent(int id, std::string newName) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
                break;
            }
        }
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    Library library;

    library.addBook(1, "1984", "George Orwell");
    library.addBook(2, "To Kill a Mockingbird", "Harper Lee");

    library.addStudent(1, "John Doe");
    library.addStudent(2, "Jane Smith");

    library.displayBooks();
    library.displayStudents();

    library.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    library.updateStudent(1, "John A. Doe");

    library.searchBook(1);
    library.searchStudent(1);

    library.deleteBook(2);
    library.deleteStudent(2);

    library.displayBooks();
    library.displayStudents();

    return 0;
}