#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Book {
private:
    string title;
    string author;
    string isbn;
public:
    Book(string t, string a, string i) : title(t), author(a), isbn(i) {}
    string getTitle() const { return title; }
    string getAuthor() const { return author; }
    string getISBN() const { return isbn; }
    void setTitle(string t) { title = t; }
    void setAuthor(string a) { author = a; }
    void setISBN(string i) { isbn = i; }
};

class Student {
private:
    string name;
    string id;
public:
    Student(string n, string i) : name(n), id(i) {}
    string getName() const { return name; }
    string getId() const { return id; }
    void setName(string n) { name = n; }
    void setId(string i) { id = i; }
};

class Library {
private:
    vector<Book> books;
    vector<Student> students;
public:
    void addBook(const Book& book) {
        books.push_back(book);
    }
    
    void deleteBook(const string& isbn) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->getISBN() == isbn) {
                books.erase(it);
                break;
            }
        }
    }
    
    void updateBook(const string& isbn, const Book& newBook) {
        for (auto& book : books) {
            if (book.getISBN() == isbn) {
                book = newBook;
                break;
            }
        }
    }

    Book* searchBook(const string& isbn) {
        for (auto& book : books) {
            if (book.getISBN() == isbn) {
                return &book;
            }
        }
        return nullptr;
    }
    
    void displayBooks() {
        for (const auto& book : books) {
            cout << "Title: " << book.getTitle() << ", Author: " << book.getAuthor() << ", ISBN: " << book.getISBN() << endl;
        }
    }
    
    void addStudent(const Student& student) {
        students.push_back(student);
    }
    
    void deleteStudent(const string& id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->getId() == id) {
                students.erase(it);
                break;
            }
        }
    }
    
    void updateStudent(const string& id, const Student& newStudent) {
        for (auto& student : students) {
            if (student.getId() == id) {
                student = newStudent;
                break;
            }
        }
    }

    Student* searchStudent(const string& id) {
        for (auto& student : students) {
            if (student.getId() == id) {
                return &student;
            }
        }
        return nullptr;
    }
    
    void displayStudents() {
        for (const auto& student : students) {
            cout << "Name: " << student.getName() << ", ID: " << student.getId() << endl;
        }
    }
};

int main() {
    Library library;
    library.addBook(Book("Book A", "Author A", "1111"));
    library.addBook(Book("Book B", "Author B", "2222"));
    library.displayBooks();
    library.addStudent(Student("Student A", "S1"));
    library.addStudent(Student("Student B", "S2"));
    library.displayStudents();
    library.deleteBook("1111");
    library.deleteStudent("S1");
    library.displayBooks();
    library.displayStudents();
    return 0;
}