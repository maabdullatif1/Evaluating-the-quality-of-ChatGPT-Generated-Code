#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Student {
public:
    int id;
    string name;
    Student(int id, string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    string title;
    Book(int id, string title) : id(id), title(title) {}
};

class LibraryManagementSystem {
private:
    vector<Student> students;
    vector<Book> books;

public:
    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string newName) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (auto &student : students) {
            if (student.id == id) {
                cout << "Student found: " << student.id << " " << student.name << endl;
                return;
            }
        }
        cout << "Student not found" << endl;
    }

    void displayStudents() {
        for (auto &student : students) {
            cout << student.id << " " << student.name << endl;
        }
    }

    void addBook(int id, string title) {
        books.push_back(Book(id, title));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string newTitle) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = newTitle;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                cout << "Book found: " << book.id << " " << book.title << endl;
                return;
            }
        }
        cout << "Book not found" << endl;
    }

    void displayBooks() {
        for (auto &book : books) {
            cout << book.id << " " << book.title << endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addStudent(1, "Alice");
    lms.addStudent(2, "Bob");
    lms.displayStudents();
    lms.searchStudent(1);
    lms.updateStudent(2, "Charlie");
    lms.displayStudents();
    lms.addBook(1, "C++ Programming");
    lms.addBook(2, "Data Structures");
    lms.displayBooks();
    lms.searchBook(2);
    lms.updateBook(1, "Advanced C++ Programming");
    lms.displayBooks();
    return 0;
}