#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Book {
public:
    int id;
    string title;
    string author;
    
    Book(int i, string t, string a) : id(i), title(t), author(a) {}
};

class Student {
public:
    int id;
    string name;
    
    Student(int i, string n) : id(i), name(n) {}
};

class LibraryManagementSystem {
private:
    vector<Book> books;
    vector<Student> students;

public:
    void addBook(int id, string title, string author) {
        books.push_back(Book(id, title, author));
    }
    
    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }
    
    void updateBook(int id, string newTitle, string newAuthor) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }
    
    void searchBook(int id) {
        for (const auto &book : books) {
            if (book.id == id) {
                cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
                return;
            }
        }
        cout << "Book not found" << endl;
    }
    
    void displayBooks() {
        for (const auto &book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
        }
    }
    
    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }
    
    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }
    
    void updateStudent(int id, string newName) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }
    
    void searchStudent(int id) {
        for (const auto &student : students) {
            if (student.id == id) {
                cout << "Student ID: " << student.id << ", Name: " << student.name << endl;
                return;
            }
        }
        cout << "Student not found" << endl;
    }
    
    void displayStudents() {
        for (const auto &student : students) {
            cout << "Student ID: " << student.id << ", Name: " << student.name << endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;

    lms.addBook(1, "The Great Gatsby", "F. Scott Fitzgerald");
    lms.addBook(2, "1984", "George Orwell");
    lms.addStudent(1, "John Doe");
    lms.addStudent(2, "Jane Smith");

    cout << "Books:" << endl;
    lms.displayBooks();
    cout << "Students:" << endl;
    lms.displayStudents();

    lms.updateBook(1, "The Great Gatsby Updated", "F. Scott Fitzgerald");
    lms.updateStudent(1, "John Doe Updated");

    cout << "After updates:" << endl;
    lms.displayBooks();
    lms.displayStudents();

    lms.deleteBook(2);
    lms.deleteStudent(2);

    cout << "After deletion:" << endl;
    lms.displayBooks();
    lms.displayStudents();

    lms.searchBook(1);
    lms.searchStudent(1);

    return 0;
}