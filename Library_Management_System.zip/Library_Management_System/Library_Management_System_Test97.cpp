#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Book {
public:
    int id;
    string title;
    string author;

    Book(int bookId, string bookTitle, string bookAuthor)
        : id(bookId), title(bookTitle), author(bookAuthor) {}

    void display() {
        cout << "Book ID: " << id << ", Title: " << title << ", Author: " << author << endl;
    }
};

class Student {
public:
    int id;
    string name;
    vector<int> borrowedBooks;

    Student(int studentId, string studentName)
        : id(studentId), name(studentName) {}

    void display() {
        cout << "Student ID: " << id << ", Name: " << name << ", Borrowed Books: ";
        for (int bookId : borrowedBooks)
            cout << bookId << " ";
        cout << endl;
    }
};

class Library {
    vector<Book> books;
    vector<Student> students;

public:
    void addBook(int id, string title, string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                return;
            }
        }
    }

    void updateBook(int id, string title, string author) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                book.display();
                return;
            }
        }
        cout << "Book not found" << endl;
    }

    void displayBooks() {
        for (const auto& book : books)
            book.display();
    }

    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(int id, string name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                student.display();
                return;
            }
        }
        cout << "Student not found" << endl;
    }

    void displayStudents() {
        for (const auto& student : students)
            student.display();
    }
};

int main() {
    Library library;

    library.addBook(1, "1984", "George Orwell");
    library.addBook(2, "To Kill a Mockingbird", "Harper Lee");
  
    library.addStudent(1, "Alice");
    library.addStudent(2, "Bob");

    library.displayBooks();
    library.displayStudents();

    library.updateBook(2, "To Kill a Mockingbird", "Harper Lee Revised");
    library.updateStudent(2, "Bob Smith");

    library.searchBook(2);
    library.searchStudent(2);

    library.deleteBook(1);
    library.deleteStudent(1);

    library.displayBooks();
    library.displayStudents();

    return 0;
}