#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Book {
public:
    int bookId;
    string title;
    string author;
    bool isAvailable;

    Book(int id, string t, string a, bool available = true)
        : bookId(id), title(t), author(a), isAvailable(available) {}
};

class Student {
public:
    int studentId;
    string name;
    vector<int> borrowedBooks;

    Student(int id, string n) : studentId(id), name(n) {}
};

class LibraryManagementSystem {
public:
    vector<Book> books;
    vector<Student> students;

    void addBook(int id, string title, string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int bookId) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->bookId == bookId) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int bookId, string title, string author) {
        for (auto &book : books) {
            if (book.bookId == bookId) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    void searchBook(int bookId) {
        for (const auto &book : books) {
            if (book.bookId == bookId) {
                cout << "Book ID: " << book.bookId << ", Title: " << book.title << ", Author: " << book.author << ", Available: " << (book.isAvailable ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Book not found" << endl;
    }

    void displayBooks() {
        for (const auto &book : books) {
            cout << "Book ID: " << book.bookId << ", Title: " << book.title << ", Author: " << book.author << ", Available: " << (book.isAvailable ? "Yes" : "No") << endl;
        }
    }

    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int studentId) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->studentId == studentId) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int studentId, string name) {
        for (auto &student : students) {
            if (student.studentId == studentId) {
                student.name = name;
                break;
            }
        }
    }

    void searchStudent(int studentId) {
        for (const auto &student : students) {
            if (student.studentId == studentId) {
                cout << "Student ID: " << student.studentId << ", Name: " << student.name << endl;
                return;
            }
        }
        cout << "Student not found" << endl;
    }

    void displayStudents() {
        for (const auto &student : students) {
            cout << "Student ID: " << student.studentId << ", Name: " << student.name << endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addBook(1, "1984", "George Orwell");
    lms.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    lms.addStudent(1, "John Doe");
    lms.addStudent(2, "Jane Smith");

    cout << "Books in library:" << endl;
    lms.displayBooks();

    cout << "Students registered:" << endl;
    lms.displayStudents();

    lms.searchBook(1);
    lms.searchStudent(2);

    lms.updateBook(1, "1984", "Orwell");
    lms.updateStudent(1, "Johnathan Doe");

    cout << "Updated book details:" << endl;
    lms.searchBook(1);

    cout << "Updated student details:" << endl;
    lms.searchStudent(1);

    lms.deleteBook(2);
    lms.deleteStudent(2);

    cout << "After deletions:" << endl;
    lms.displayBooks();
    lms.displayStudents();

    return 0;
}