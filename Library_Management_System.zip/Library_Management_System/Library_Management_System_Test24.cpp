#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Book {
public:
    int bookId;
    string title;
    string author;

    Book(int id, string t, string a) : bookId(id), title(t), author(a) {}
};

class Student {
public:
    int studentId;
    string name;
    string department;

    Student(int id, string n, string d) : studentId(id), name(n), department(d) {}
};

class Library {
private:
    vector<Book> books;
    vector<Student> students;

    template <typename T>
    void display(vector<T> items) {
        for (const auto& item : items) {
            cout << "ID: " << item.bookId << ", Title: " << item.title << ", Author: " << item.author << endl;
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "Book ID: " << book.bookId << ", Title: " << book.title << ", Author: " << book.author << endl;
        }
    }

    void displayStudents() {
        for (const auto& student : students) {
            cout << "Student ID: " << student.studentId << ", Name: " << student.name << ", Department: " << student.department << endl;
        }
    }

public:
    void addBook(int id, string title, string author) {
        books.push_back(Book(id, title, author));
    }

    void addStudent(int id, string name, string department) {
        students.push_back(Student(id, name, department));
    }

    void deleteBook(int id) {
        books.erase(remove_if(books.begin(), books.end(), [id](Book& b) { return b.bookId == id; }), books.end());
    }

    void deleteStudent(int id) {
        students.erase(remove_if(students.begin(), students.end(), [id](Student& s) { return s.studentId == id; }), students.end());
    }

    void updateBook(int id, string newTitle, string newAuthor) {
        for (auto& book : books) {
            if (book.bookId == id) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }

    void updateStudent(int id, string newName, string newDepartment) {
        for (auto& student : students) {
            if (student.studentId == id) {
                student.name = newName;
                student.department = newDepartment;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.bookId == id) {
                cout << "Book Found - ID: " << book.bookId << ", Title: " << book.title << ", Author: " << book.author << endl;
                return;
            }
        }
        cout << "Book Not Found" << endl;
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.studentId == id) {
                cout << "Student Found - ID: " << student.studentId << ", Name: " << student.name << ", Department: " << student.department << endl;
                return;
            }
        }
        cout << "Student Not Found" << endl;
    }

    void displayAllBooks() {
        displayBooks();
    }

    void displayAllStudents() {
        displayStudents();
    }
};

int main() {
    Library library;
    library.addBook(1, "The C++ Programming Language", "Bjarne Stroustrup");
    library.addStudent(1, "John Doe", "Computer Science");
    library.displayAllBooks();
    library.displayAllStudents();
    library.searchBook(1);
    library.searchStudent(1);
    library.updateBook(1, "C++ Primer", "Lippman");
    library.updateStudent(1, "Jane Doe", "Software Engineering");
    library.displayAllBooks();
    library.displayAllStudents();
    library.deleteBook(1);
    library.deleteStudent(1);
    library.displayAllBooks();
    library.displayAllStudents();
    return 0;
}