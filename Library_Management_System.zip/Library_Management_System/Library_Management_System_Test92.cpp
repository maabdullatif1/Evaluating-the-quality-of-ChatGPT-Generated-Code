#include <iostream>
#include <vector>
#include <string>

class Student {
public:
    int id;
    std::string name;
    Student(int id, std::string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;
    Book(int id, std::string title) : id(id), title(title) {}
};

class Library {
    std::vector<Student> students;
    std::vector<Book> books;

public:
    void addStudent(int id, std::string name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(int id) {
        for(auto it = students.begin(); it != students.end(); ++it) {
            if(it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string newName) {
        for(auto& student : students) {
            if(student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for(const auto& student : students) {
            if(student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << "\n";
                return;
            }
        }
        std::cout << "Student not found.\n";
    }

    void displayStudents() {
        for(const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << "\n";
        }
    }

    void addBook(int id, std::string title) {
        books.emplace_back(id, title);
    }

    void deleteBook(int id) {
        for(auto it = books.begin(); it != books.end(); ++it) {
            if(it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string newTitle) {
        for(auto& book : books) {
            if(book.id == id) {
                book.title = newTitle;
                break;
            }
        }
    }

    void searchBook(int id) {
        for(const auto& book : books) {
            if(book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << "\n";
                return;
            }
        }
        std::cout << "Book not found.\n";
    }

    void displayBooks() {
        for(const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << "\n";
        }
    }
};

int main() {
    Library lib;
    lib.addStudent(1, "Alice");
    lib.addStudent(2, "Bob");
    lib.addBook(101, "C++ Programming");
    lib.addBook(102, "Data Structures");

    std::cout << "All Students:\n";
    lib.displayStudents();
    std::cout << "All Books:\n";
    lib.displayBooks();

    std::cout << "Search for Student ID 1:\n";
    lib.searchStudent(1);
    std::cout << "Update Student ID 2's name to Charlie.\n";
    lib.updateStudent(2, "Charlie");
    std::cout << "Search for Book ID 101:\n";
    lib.searchBook(101);
    std::cout << "Delete Book ID 102.\n";
    lib.deleteBook(102);

    std::cout << "All Students after update:\n";
    lib.displayStudents();
    std::cout << "All Books after deletion:\n";
    lib.displayBooks();

    return 0;
}