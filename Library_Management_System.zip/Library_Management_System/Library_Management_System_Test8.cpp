#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Book {
public:
    int id;
    string title;
    string author;

    Book(int id, string title, string author) : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    string name;

    Student(int id, string name) : id(id), name(name) {}
};

class Library {
private:
    vector<Book> books;
    vector<Student> students;

public:
    void addBook(int id, string title, string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string title, string author) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
        }
    }

    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            cout << "ID: " << student.id << ", Name: " << student.name << endl;
        }
    }
};

int main() {
    Library lib;
    lib.addBook(1, "1984", "George Orwell");
    lib.addBook(2, "The Catcher in the Rye", "J.D. Salinger");
    lib.displayBooks();

    lib.addStudent(1, "Alice");
    lib.addStudent(2, "Bob");
    lib.displayStudents();

    lib.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    lib.displayBooks();

    lib.updateStudent(1, "Alice Smith");
    lib.displayStudents();

    Book* book = lib.searchBook(2);
    if (book) {
        cout << "Found Book - ID: " << book->id << ", Title: " << book->title << ", Author: " << book->author << endl;
    }

    Student* student = lib.searchStudent(2);
    if (student) {
        cout << "Found Student - ID: " << student->id << ", Name: " << student->name << endl;
    }

    lib.deleteBook(2);
    lib.displayBooks();

    lib.deleteStudent(2);
    lib.displayStudents();

    return 0;
}