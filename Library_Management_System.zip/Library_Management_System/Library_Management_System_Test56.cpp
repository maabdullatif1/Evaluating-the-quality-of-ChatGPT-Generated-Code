#include<iostream>
#include<string>
#include<vector>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    Book(int id, std::string title, std::string author) : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;
    std::string email;
    Student(int id, std::string name, std::string email) : id(id), name(name), email(email) {}
};

class Library {
    std::vector<Book> books;
    std::vector<Student> students;

    template <typename T>
    int findIndexById(const std::vector<T>& vec, int id) {
        for (size_t i = 0; i < vec.size(); ++i) {
            if (vec[i].id == id) return i;
        }
        return -1;
    }

public:
    void addBook(int id, std::string title, std::string author) {
        if (findIndexById(books, id) == -1)
            books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        int index = findIndexById(books, id);
        if (index != -1) books.erase(books.begin() + index);
    }

    void updateBook(int id, std::string title, std::string author) {
        int index = findIndexById(books, id);
        if (index != -1) {
            books[index].title = title;
            books[index].author = author;
        }
    }

    void searchBook(int id) {
        int index = findIndexById(books, id);
        if (index != -1) {
            std::cout << "Book ID: " << books[index].id << ", Title: " << books[index].title << ", Author: " << books[index].author << std::endl;
        } else {
            std::cout << "Book not found" << std::endl;
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }

    void addStudent(int id, std::string name, std::string email) {
        if (findIndexById(students, id) == -1)
            students.push_back(Student(id, name, email));
    }

    void deleteStudent(int id) {
        int index = findIndexById(students, id);
        if (index != -1) students.erase(students.begin() + index);
    }

    void updateStudent(int id, std::string name, std::string email) {
        int index = findIndexById(students, id);
        if (index != -1) {
            students[index].name = name;
            students[index].email = email;
        }
    }

    void searchStudent(int id) {
        int index = findIndexById(students, id);
        if (index != -1) {
            std::cout << "Student ID: " << students[index].id << ", Name: " << students[index].name << ", Email: " << students[index].email << std::endl;
        } else {
            std::cout << "Student not found" << std::endl;
        }
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << ", Email: " << student.email << std::endl;
        }
    }
};

int main() {
    Library library;
    library.addBook(1, "The Great Gatsby", "F. Scott Fitzgerald");
    library.addStudent(1, "John Doe", "john.doe@example.com");
    library.displayBooks();
    library.displayStudents();
    library.updateBook(1, "The Great Gatsby", "Francis Scott Fitzgerald");
    library.updateStudent(1, "John Smith", "john.smith@example.com");
    library.searchBook(1);
    library.searchStudent(1);
    library.deleteBook(1);
    library.deleteStudent(1);
    library.displayBooks();
    library.displayStudents();
    return 0;
}