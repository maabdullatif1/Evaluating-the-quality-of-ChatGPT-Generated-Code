#include <iostream>
#include <vector>
#include <string>

class Student {
public:
    int id;
    std::string name;
    Student(int id, std::string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;
    Book(int id, std::string title) : id(id), title(title) {}
};

class LibraryManagementSystem {
    std::vector<Student> students;
    std::vector<Book> books;
public:
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }
    
    void deleteStudent(int id) {
        students.erase(std::remove_if(students.begin(), students.end(), [id](Student s){ return s.id == id; }), students.end());
    }
    
    void updateStudent(int id, std::string newName) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }
    
    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found." << std::endl;
    }
    
    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
    
    void addBook(int id, std::string title) {
        books.push_back(Book(id, title));
    }
    
    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(), [id](Book b){ return b.id == id; }), books.end());
    }
    
    void updateBook(int id, std::string newTitle) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = newTitle;
                break;
            }
        }
    }
    
    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << std::endl;
                return;
            }
        }
        std::cout << "Book not found." << std::endl;
    }
    
    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addStudent(1, "Alice");
    lms.addStudent(2, "Bob");
    lms.displayStudents();
    lms.updateStudent(1, "Alicia");
    lms.searchStudent(1);
    lms.deleteStudent(2);
    lms.displayStudents();
    lms.addBook(1, "1984");
    lms.addBook(2, "Brave New World");
    lms.displayBooks();
    lms.updateBook(1, "Nineteen Eighty-Four");
    lms.searchBook(1);
    lms.deleteBook(2);
    lms.displayBooks();
    return 0;
}