#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    Book(int id, const std::string& title, const std::string& author)
        : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;
    Student(int id, const std::string& name)
        : id(id), name(name) {}
};

class LibraryManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Student> students;
    
    template <typename T>
    void displayList(const std::vector<T>& list) {
        for (const auto& item : list) {
            std::cout << "ID: " << item.id << ", ";
            std::cout << "Name: " << item.name << "\n";
        }
    }

public:
    void addBook(int id, const std::string& title, const std::string& author) {
        books.push_back(Book(id, title, author));
    }
    
    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(), [id](const Book& b) { return b.id == id; }), books.end());
    }
    
    void updateBook(int id, const std::string& title, const std::string& author) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }
    
    void searchBooksByTitle(const std::string& title) {
        for (const auto& book : books) {
            if (book.title.find(title) != std::string::npos) {
                std::cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << "\n";
            }
        }
    }
    
    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << "\n";
        }
    }
    
    void addStudent(int id, const std::string& name) {
        students.push_back(Student(id, name));
    }
    
    void deleteStudent(int id) {
        students.erase(std::remove_if(students.begin(), students.end(), [id](const Student& s) { return s.id == id; }), students.end());
    }

    void updateStudent(int id, const std::string& name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }
    
    void searchStudentByName(const std::string& name) {
        for (const auto& student : students) {
            if (student.name.find(name) != std::string::npos) {
                std::cout << "ID: " << student.id << ", Name: " << student.name << "\n";
            }
        }
    }
    
    void displayStudents() {
        displayList(students);
    }
};

int main() {
    LibraryManagementSystem lib;
    
    lib.addBook(1, "1984", "George Orwell");
    lib.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    lib.displayBooks();
    
    lib.addStudent(1, "Alice");
    lib.addStudent(2, "Bob");
    lib.displayStudents();
    
    lib.searchBooksByTitle("1984");
    lib.searchStudentByName("Alice");
    
    lib.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    lib.updateStudent(1, "Alicia");
    
    lib.displayBooks();
    lib.displayStudents();
    
    lib.deleteBook(1);
    lib.deleteStudent(1);
    
    lib.displayBooks();
    lib.displayStudents();
    
    return 0;
}