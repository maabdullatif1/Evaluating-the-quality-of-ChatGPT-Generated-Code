#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Book {
public:
    int id;
    string title;
    string author;

    Book(int id, string title, string author) : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    string name;
    string department;

    Student(int id, string name, string department) : id(id), name(name), department(department) {}
};

class LibraryManagementSystem {
private:
    vector<Book> books;
    vector<Student> students;

public:
    void addBook(int id, string title, string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string title, string author) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (auto& book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
        }
    }

    void addStudent(int id, string name, string department) {
        students.push_back(Student(id, name, department));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string name, string department) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                student.department = department;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (auto& student : students) {
            cout << "Student ID: " << student.id << ", Name: " << student.name << ", Department: " << student.department << endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addBook(1, "The Great Gatsby", "F. Scott Fitzgerald");
    lms.addBook(2, "1984", "George Orwell");
    lms.displayBooks();
    lms.updateBook(1, "The Great Gatsby", "Fitzgerald");
    lms.displayBooks();
    lms.deleteBook(2);
    lms.displayBooks();

    lms.addStudent(101, "John Doe", "CS");
    lms.addStudent(102, "Jane Smith", "Math");
    lms.displayStudents();
    lms.updateStudent(101, "John Doe", "Computer Science");
    lms.displayStudents();
    lms.deleteStudent(102);
    lms.displayStudents();

    return 0;
}