#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    bool isAvailable;

    Book(int id, std::string title, std::string author) 
        : id(id), title(title), author(author), isAvailable(true) {}
};

class Student {
public:
    int id;
    std::string name;
    std::string rollNo;

    Student(int id, std::string name, std::string rollNo) 
        : id(id), name(name), rollNo(rollNo) {}
};

class Library {
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string newTitle, std::string newAuthor) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id 
                          << ", Title: " << book.title 
                          << ", Author: " << book.author 
                          << ", Available: " << (book.isAvailable ? "Yes" : "No") << std::endl;
                return;
            }
        }
        std::cout << "Book not found" << std::endl;
    }

    void displayBooks() {
        for (auto &book : books) {
            std::cout << "Book ID: " << book.id 
                      << ", Title: " << book.title 
                      << ", Author: " << book.author 
                      << ", Available: " << (book.isAvailable ? "Yes" : "No") << std::endl;
        }
    }

    void addStudent(int id, std::string name, std::string rollNo) {
        students.push_back(Student(id, name, rollNo));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string newName, std::string newRollNo) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = newName;
                student.rollNo = newRollNo;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (auto &student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id 
                          << ", Name: " << student.name 
                          << ", Roll No: " << student.rollNo << std::endl;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }

    void displayStudents() {
        for (auto &student : students) {
            std::cout << "Student ID: " << student.id 
                      << ", Name: " << student.name 
                      << ", Roll No: " << student.rollNo << std::endl;
        }
    }
};

int main() {
    Library library;
    
    library.addBook(1, "The Great Gatsby", "F. Scott Fitzgerald");
    library.addBook(2, "1984", "George Orwell");
    library.displayBooks();
    
    library.addStudent(1, "Alice Johnson", "RJ123");
    library.addStudent(2, "Bob Smith", "RK456");
    library.displayStudents();

    library.searchBook(1);
    library.updateBook(2, "Animal Farm", "George Orwell");
    library.displayBooks();

    library.searchStudent(2);
    library.updateStudent(1, "Alice Brown", "RJ789");
    library.displayStudents();

    library.deleteBook(1);
    library.displayBooks();

    library.deleteStudent(2);
    library.displayStudents();

    return 0;
}