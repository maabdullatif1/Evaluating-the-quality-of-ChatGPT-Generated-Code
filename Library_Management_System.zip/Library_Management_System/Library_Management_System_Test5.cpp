#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Book {
public:
    string title, author;
    int id;

    Book(int id, string title, string author) : id(id), title(title), author(author) {}
};

class Student {
public:
    string name;
    int id;

    Student(int id, string name) : id(id), name(name) {}
};

class LibraryManagementSystem {
    vector<Book> books;
    vector<Student> students;

    Book* findBookById(int id) {
        for (auto& book : books)
            if (book.id == id)
                return &book;
        return nullptr;
    }

    Student* findStudentById(int id) {
        for (auto& student : students)
            if (student.id == id)
                return &student;
        return nullptr;
    }

public:
    void addBook(int id, string title, string author) {
        if (findBookById(id))
            return;
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it)
            if (it->id == id) {
                books.erase(it);
                return;
            }
    }

    void updateBook(int id, string title, string author) {
        Book* book = findBookById(id);
        if (book) {
            book->title = title;
            book->author = author;
        }
    }

    void searchBook(int id) {
        Book* book = findBookById(id);
        if (book)
            cout << "Book ID: " << book->id << ", Title: " << book->title << ", Author: " << book->author << endl;
        else
            cout << "Book not found" << endl;
    }

    void displayBooks() {
        for (const auto& book : books)
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
    }

    void addStudent(int id, string name) {
        if (findStudentById(id))
            return;
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it)
            if (it->id == id) {
                students.erase(it);
                return;
            }
    }

    void updateStudent(int id, string name) {
        Student* student = findStudentById(id);
        if (student)
            student->name = name;
    }

    void searchStudent(int id) {
        Student* student = findStudentById(id);
        if (student)
            cout << "Student ID: " << student->id << ", Name: " << student->name << endl;
        else
            cout << "Student not found" << endl;
    }

    void displayStudents() {
        for (const auto& student : students)
            cout << "Student ID: " << student.id << ", Name: " << student.name << endl;
    }
};

int main() {
    LibraryManagementSystem lms;

    lms.addBook(1, "1984", "George Orwell");
    lms.addBook(2, "To Kill a Mockingbird", "Harper Lee");

    lms.addStudent(1, "John Doe");
    lms.addStudent(2, "Jane Smith");

    cout << "Books:" << endl;
    lms.displayBooks();
    
    cout << "\nStudents:" << endl;
    lms.displayStudents();
    
    return 0;
}