#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    Book(int i, std::string t, std::string a) : id(i), title(t), author(a) {}
};

class Student {
public:
    int id;
    std::string name;
    Student(int i, std::string n) : id(i), name(n) {}
};

class LibraryManagementSystem {
    std::vector<Book> books;
    std::vector<Student> students;

    Book* findBook(int id) {
        for (auto& book : books) {
            if (book.id == id) return &book;
        }
        return nullptr;
    }

    Student* findStudent(int id) {
        for (auto& student : students) {
            if (student.id == id) return &student;
        }
        return nullptr;
    }

public:
    void addBook(int id, std::string title, std::string author) {
        if (!findBook(id)) {
            books.push_back(Book(id, title, author));
        }
    }

    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(), [&](Book& b) { return b.id == id; }), books.end());
    }

    void updateBook(int id, std::string newTitle, std::string newAuthor) {
        Book* book = findBook(id);
        if (book) {
            book->title = newTitle;
            book->author = newAuthor;
        }
    }

    Book* searchBook(int id) {
        return findBook(id);
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << "\n";
        }
    }

    void addStudent(int id, std::string name) {
        if (!findStudent(id)) {
            students.push_back(Student(id, name));
        }
    }

    void deleteStudent(int id) {
        students.erase(std::remove_if(students.begin(), students.end(), [&](Student& s) { return s.id == id; }), students.end());
    }

    void updateStudent(int id, std::string newName) {
        Student* student = findStudent(id);
        if (student) {
            student->name = newName;
        }
    }

    Student* searchStudent(int id) {
        return findStudent(id);
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << "\n";
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addBook(1, "1984", "George Orwell");
    lms.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    lms.addStudent(100, "John Doe");
    lms.addStudent(101, "Jane Smith");
    lms.displayBooks();
    lms.displayStudents();
    lms.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    lms.updateStudent(100, "Johnathan Doe");
    lms.displayBooks();
    lms.displayStudents();
    lms.deleteBook(2);
    lms.deleteStudent(101);
    lms.displayBooks();
    lms.displayStudents();
    return 0;
}