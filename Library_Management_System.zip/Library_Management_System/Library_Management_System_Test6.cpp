#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Book {
    int id;
    string title;
    string author;
};

struct Student {
    int id;
    string name;
};

class LibrarySystem {
private:
    vector<Book> books;
    vector<Student> students;

    Book* findBookById(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    Student* findStudentById(int id) {
        for (auto &student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

public:
    void addBook(int id, const string& title, const string& author) {
        books.push_back({id, title, author});
    }

    void deleteBook(int id) {
        books.erase(remove_if(books.begin(), books.end(), [id](Book &b) { return b.id == id; }), books.end());
    }

    void updateBook(int id, const string& title, const string& author) {
        Book* book = findBookById(id);
        if(book) {
            book->title = title;
            book->author = author;
        }
    }

    void searchBook(int id) {
        Book* book = findBookById(id);
        if(book) {
            cout << "Book ID: " << book->id << ", Title: " << book->title << ", Author: " << book->author << endl;
        } else {
            cout << "Book not found" << endl;
        }
    }

    void displayBooks() {
        for (const auto &book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
        }
    }

    void addStudent(int id, const string& name) {
        students.push_back({id, name});
    }

    void deleteStudent(int id) {
        students.erase(remove_if(students.begin(), students.end(), [id](Student &s) { return s.id == id; }), students.end());
    }

    void updateStudent(int id, const string& name) {
        Student* student = findStudentById(id);
        if(student) {
            student->name = name;
        }
    }

    void searchStudent(int id) {
        Student* student = findStudentById(id);
        if(student) {
            cout << "Student ID: " << student->id << ", Name: " << student->name << endl;
        } else {
            cout << "Student not found" << endl;
        }
    }

    void displayStudents() {
        for (const auto &student : students) {
            cout << "Student ID: " << student.id << ", Name: " << student.name << endl;
        }
    }
};

int main() {
    LibrarySystem lib;

    lib.addBook(1, "The Great Gatsby", "F. Scott Fitzgerald");
    lib.addBook(2, "1984", "George Orwell");
    lib.addStudent(1, "John Doe");
    lib.addStudent(2, "Jane Smith");

    cout << "Books in Library:" << endl;
    lib.displayBooks();

    cout << "\nStudents in Library:" << endl;
    lib.displayStudents();

    cout << "\nSearch for Book ID 1:" << endl;
    lib.searchBook(1);

    cout << "\nSearch for Student ID 1:" << endl;
    lib.searchStudent(1);

    lib.updateBook(1, "The Great Gatsby Updated", "F. Scott Fitzgerald Updated");
    lib.updateStudent(1, "John Doe Updated");

    cout << "\nUpdated Books in Library:" << endl;
    lib.displayBooks();

    cout << "\nUpdated Students in Library:" << endl;
    lib.displayStudents();

    lib.deleteBook(2);
    lib.deleteStudent(2);

    cout << "\nAfter Deletion, Books in Library:" << endl;
    lib.displayBooks();

    cout << "\nAfter Deletion, Students in Library:" << endl;
    lib.displayStudents();

    return 0;
}