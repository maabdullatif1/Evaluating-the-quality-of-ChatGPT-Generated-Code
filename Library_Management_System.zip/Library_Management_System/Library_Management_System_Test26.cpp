#include <iostream>
#include <vector>
#include <string>

class Student {
public:
    int id;
    std::string name;
};

class Book {
public:
    int id;
    std::string title;
};

class LibrarySystem {
    std::vector<Student> students;
    std::vector<Book> books;

public:
    void addStudent(int id, const std::string& name) {
        Student student = {id, name};
        students.push_back(student);
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string& name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }

    void addBook(int id, const std::string& title) {
        Book book = {id, title};
        books.push_back(book);
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const std::string& title) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << std::endl;
                return;
            }
        }
        std::cout << "Book not found" << std::endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << std::endl;
        }
    }
};

int main() {
    LibrarySystem libSys;

    libSys.addStudent(1, "John Doe");
    libSys.addStudent(2, "Jane Smith");
    libSys.displayStudents();

    libSys.updateStudent(1, "John D.");
    libSys.searchStudent(1);

    libSys.deleteStudent(1);
    libSys.displayStudents();

    libSys.addBook(101, "C++ Programming");
    libSys.addBook(102, "Data Structures");
    libSys.displayBooks();

    libSys.updateBook(101, "C++ Programming - Basics");
    libSys.searchBook(101);

    libSys.deleteBook(101);
    libSys.displayBooks();

    return 0;
}