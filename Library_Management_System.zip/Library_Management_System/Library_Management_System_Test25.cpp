#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Book {
public:
    int id;
    string title;
    string author;

    Book(int id, string title, string author) : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    string name;
    string department;

    Student(int id, string name, string department) : id(id), name(name), department(department) {}
};

class LibraryManagementSystem {
private:
    vector<Book> books;
    vector<Student> students;

public:
    void addBook(int id, string title, string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string newTitle, string newAuthor) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
        }
    }

    void addStudent(int id, string name, string department) {
        students.push_back(Student(id, name, department));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string newName, string newDepartment) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = newName;
                student.department = newDepartment;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            cout << "ID: " << student.id << ", Name: " << student.name << ", Department: " << student.department << endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addBook(1, "1984", "George Orwell");
    lms.addBook(2, "The Catcher in the Rye", "J.D. Salinger");
    lms.displayBooks();
    lms.addStudent(1, "John Doe", "Computer Science");
    lms.addStudent(2, "Jane Smith", "Biology");
    lms.displayStudents();
    return 0;
}