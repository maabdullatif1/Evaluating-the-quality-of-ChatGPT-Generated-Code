#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    
    Book(int id, std::string title, std::string author) 
        : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;
    
    Student(int id, std::string name) 
        : id(id), name(name) {}
};

class LibraryManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Student> students;
    
public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }
    
    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(),
                    [id](Book &b) { return b.id == id; }), books.end());
    }
    
    void updateBook(int id, std::string title, std::string author) {
        for (Book &book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }
    
    Book* searchBook(int id) {
        for (Book &book : books) {
            if (book.id == id) return &book;
        }
        return nullptr;
    }
    
    void displayBooks() {
        for (const Book &book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title
                      << ", Author: " << book.author << std::endl;
        }
    }
    
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }
    
    void deleteStudent(int id) {
        students.erase(std::remove_if(students.begin(), students.end(),
                    [id](Student &s) { return s.id == id; }), students.end());
    }
    
    void updateStudent(int id, std::string name) {
        for (Student &student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }
    
    Student* searchStudent(int id) {
        for (Student &student : students) {
            if (student.id == id) return &student;
        }
        return nullptr;
    }
    
    void displayStudents() {
        for (const Student &student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addBook(1, "1984", "George Orwell");
    lms.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    lms.addStudent(1, "Alice");
    lms.addStudent(2, "Bob");
    
    std::cout << "Books in library:" << std::endl;
    lms.displayBooks();
    
    std::cout << "Students in library:" << std::endl;
    lms.displayStudents();
    
    std::cout << "After deleting book ID 1 and student ID 1:" << std::endl;
    lms.deleteBook(1);
    lms.deleteStudent(1);
    
    std::cout << "Books in library:" << std::endl;
    lms.displayBooks();
    
    std::cout << "Students in library:" << std::endl;
    lms.displayStudents();
    
    return 0;
}