#include <iostream>
#include <vector>
#include <string>

class Student {
public:
    int id;
    std::string name;

    Student(int id, std::string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;

    Book(int id, std::string title) : id(id), title(title) {}
};

class LibraryManagementSystem {
    std::vector<Student> students;
    std::vector<Book> books;

public:
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(int id, std::string name) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = name;
                return;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto &student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }

    void displayStudents() {
        for (const auto &student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }

    void addBook(int id, std::string title) {
        books.push_back(Book(id, title));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                return;
            }
        }
    }

    void updateBook(int id, std::string title) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                return;
            }
        }
    }

    void searchBook(int id) {
        for (const auto &book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << std::endl;
                return;
            }
        }
        std::cout << "Book not found" << std::endl;
    }

    void displayBooks() {
        for (const auto &book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem library;
    
    library.addStudent(1, "John Doe");
    library.addStudent(2, "Jane Smith");
    
    library.addBook(101, "C++ Programming");
    library.addBook(102, "Data Structures");
    
    std::cout << "Student List:" << std::endl;
    library.displayStudents();
    
    std::cout << "Book List:" << std::endl;
    library.displayBooks();
    
    library.searchStudent(1);
    library.searchBook(101);
    
    library.updateStudent(1, "Johnathan Doe");
    library.updateBook(101, "Advanced C++ Programming");
    
    library.displayStudents();
    library.displayBooks();
    
    library.deleteStudent(2);
    library.deleteBook(102);
    
    library.displayStudents();
    library.displayBooks();
    
    return 0;
}