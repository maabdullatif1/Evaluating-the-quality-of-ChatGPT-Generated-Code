#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    
    Book(int id, std::string title, std::string author)
        : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;
    std::string course;
    
    Student(int id, std::string name, std::string course)
        : id(id), name(name), course(course) {}
};

class LibrarySystem {
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void addStudent(int id, std::string name, std::string course) {
        students.push_back(Student(id, name, course));
    }

    void deleteBook(int id) {
        for(size_t i = 0; i < books.size(); ++i) {
            if (books[i].id == id) {
                books.erase(books.begin() + i);
                break;
            }
        }
    }

    void deleteStudent(int id) {
        for(size_t i = 0; i < students.size(); ++i) {
            if (students[i].id == id) {
                students.erase(students.begin() + i);
                break;
            }
        }
    }

    void updateBook(int id, std::string title, std::string author) {
        for(size_t i = 0; i < books.size(); ++i) {
            if (books[i].id == id) {
                books[i].title = title;
                books[i].author = author;
                break;
            }
        }
    }

    void updateStudent(int id, std::string name, std::string course) {
        for(size_t i = 0; i < students.size(); ++i) {
            if (students[i].id == id) {
                students[i].name = name;
                students[i].course = course;
                break;
            }
        }
    }

    void searchBook(int id) {
        for(const auto& book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
                return;
            }
        }
        std::cout << "Book not found" << std::endl;
    }

    void searchStudent(int id) {
        for(const auto& student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << ", Course: " << student.course << std::endl;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }

    void displayBooks() {
        for(const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }

    void displayStudents() {
        for(const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << ", Course: " << student.course << std::endl;
        }
    }
};

int main() {
    LibrarySystem library;

    library.addBook(1, "C++ Programming", "Bjarne Stroustrup");
    library.addStudent(101, "Alice", "Computer Science");

    library.displayBooks();
    library.displayStudents();

    library.updateBook(1, "Advanced C++", "Bjarne Stroustrup");
    library.updateStudent(101, "Alice Johnson", "Software Engineering");

    library.searchBook(1);
    library.searchStudent(101);

    library.deleteBook(1);
    library.deleteStudent(101);

    library.displayBooks();
    library.displayStudents();

    return 0;
}