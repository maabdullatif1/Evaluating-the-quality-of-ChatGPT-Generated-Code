#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Book {
public:
    int id;
    string title;
    string author;
    bool isIssued;

    Book(int i, string t, string a) : id(i), title(t), author(a), isIssued(false) {}
};

class Student {
public:
    int id;
    string name;
    vector<int> borrowedBooks;

    Student(int i, string n) : id(i), name(n) {}
};

class Library {
    vector<Book> books;
    vector<Student> students;

public:
    void addBook(int id, string title, string author) {
        books.push_back(Book(id, title, author));
    }

    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string newTitle, string newAuthor) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }

    void updateStudent(int id, string newName) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto &book : books) {
            if (book.id == id) {
                cout << "Book found: " << book.title << " by " << book.author << endl;
                return;
            }
        }
        cout << "Book not found" << endl;
    }

    void searchStudent(int id) {
        for (const auto &student : students) {
            if (student.id == id) {
                cout << "Student found: " << student.name << endl;
                return;
            }
        }
        cout << "Student not found" << endl;
    }

    void displayBooks() {
        for (const auto &book : books) {
            cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Issued: " << (book.isIssued ? "Yes" : "No") << endl;
        }
    }

    void displayStudents() {
        for (const auto &student : students) {
            cout << "ID: " << student.id << ", Name: " << student.name << ", Borrowed Books: ";
            if (student.borrowedBooks.empty()) {
                cout << "None";
            } else {
                for (int bookID : student.borrowedBooks) {
                    cout << bookID << " ";
                }
            }
            cout << endl;
        }
    }
};

int main() {
    Library library;

    library.addBook(1, "1984", "George Orwell");
    library.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    library.addStudent(1, "John Doe");
    library.addStudent(2, "Jane Smith");

    library.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    library.searchBook(1);

    library.updateStudent(1, "Johnathan Doe");
    library.searchStudent(1);

    library.displayBooks();
    library.displayStudents();

    library.deleteBook(2);
    library.deleteStudent(2);

    library.displayBooks();
    library.displayStudents();

    return 0;
}