#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Book {
    int id;
    string title;
    string author;
};

struct Student {
    int id;
    string name;
};

class LibraryManagementSystem {
private:
    vector<Book> books;
    vector<Student> students;

    Book* findBookById(int id) {
        for (auto &book : books) {
            if (book.id == id) return &book;
        }
        return nullptr;
    }

    Student* findStudentById(int id) {
        for (auto &student : students) {
            if (student.id == id) return &student;
        }
        return nullptr;
    }

public:
    void addBook(int id, string title, string author) {
        books.push_back({id, title, author});
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string newTitle, string newAuthor) {
        Book* book = findBookById(id);
        if (book) {
            book->title = newTitle;
            book->author = newAuthor;
        }
    }

    void addStudent(int id, string name) {
        students.push_back({id, name});
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string newName) {
        Student* student = findStudentById(id);
        if (student) {
            student->name = newName;
        }
    }

    void searchBookById(int id) {
        Book* book = findBookById(id);
        if (book) {
            cout << "Book ID: " << book->id << ", Title: " << book->title << ", Author: " << book->author << endl;
        } else {
            cout << "Book not found." << endl;
        }
    }

    void searchStudentById(int id) {
        Student* student = findStudentById(id);
        if (student) {
            cout << "Student ID: " << student->id << ", Name: " << student->name << endl;
        } else {
            cout << "Student not found." << endl;
        }
    }

    void displayAllBooks() {
        for (const auto &book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
        }
    }

    void displayAllStudents() {
        for (const auto &student : students) {
            cout << "Student ID: " << student.id << ", Name: " << student.name << endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addBook(1, "The Great Gatsby", "F. Scott Fitzgerald");
    lms.addStudent(101, "John Doe");
    lms.displayAllBooks();
    lms.displayAllStudents();
    return 0;
}