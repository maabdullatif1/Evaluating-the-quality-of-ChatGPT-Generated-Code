#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Book {
public:
    int id;
    string title;
    string author;

    Book(int id, string title, string author) : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    string name;

    Student(int id, string name) : id(id), name(name) {}
};

class LibraryManagementSystem {
private:
    vector<Book> books;
    vector<Student> students;

public:
    void addBook(int id, string title, string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string title, string author) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
                return;
            }
        }
        cout << "Book not found" << endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
        }
    }

    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                cout << "Student ID: " << student.id << ", Name: " << student.name << endl;
                return;
            }
        }
        cout << "Student not found" << endl;
    }

    void displayStudents() {
        for (const auto& student : students) {
            cout << "Student ID: " << student.id << ", Name: " << student.name << endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;

    lms.addBook(1, "1984", "George Orwell");
    lms.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    lms.displayBooks();
    lms.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    lms.searchBook(1);
    lms.deleteBook(2);
    lms.displayBooks();

    lms.addStudent(1, "John Doe");
    lms.addStudent(2, "Jane Smith");
    lms.displayStudents();
    lms.updateStudent(2, "Jane Doe");
    lms.searchStudent(2);
    lms.deleteStudent(1);
    lms.displayStudents();

    return 0;
}