#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    bool is_issued;

    Book(int book_id, std::string book_title) : id(book_id), title(book_title), is_issued(false) {}
};

class Student {
public:
    int id;
    std::string name;

    Student(int student_id, std::string student_name) : id(student_id), name(student_name) {}
};

class Library {
private:
    std::vector<Book> books;
    std::vector<Student> students;

    Book* findBook(int id) {
        for (auto& book : books) {
            if (book.id == id) return &book;
        }
        return nullptr;
    }

    Student* findStudent(int id) {
        for (auto& student : students) {
            if (student.id == id) return &student;
        }
        return nullptr;
    }

public:
    void addBook(int book_id, std::string book_title) {
        books.push_back(Book(book_id, book_title));
    }

    void deleteBook(int book_id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == book_id) {
                books.erase(it);
                return;
            }
        }
    }

    void updateBook(int book_id, std::string new_title) {
        Book* book = findBook(book_id);
        if (book) book->title = new_title;
    }

    void searchBook(int book_id) {
        Book* book = findBook(book_id);
        if (book) {
            std::cout << "Book ID: " << book->id << ", Title: " << book->title 
                      << ", Issued: " << (book->is_issued ? "Yes" : "No") << std::endl;
        } else {
            std::cout << "Book not found" << std::endl;
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title 
                      << ", Issued: " << (book.is_issued ? "Yes" : "No") << std::endl;
        }
    }

    void addStudent(int student_id, std::string student_name) {
        students.push_back(Student(student_id, student_name));
    }

    void deleteStudent(int student_id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == student_id) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(int student_id, std::string new_name) {
        Student* student = findStudent(student_id);
        if (student) student->name = new_name;
    }

    void searchStudent(int student_id) {
        Student* student = findStudent(student_id);
        if (student) {
            std::cout << "Student ID: " << student->id << ", Name: " << student->name << std::endl;
        } else {
            std::cout << "Student not found" << std::endl;
        }
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    Library library;
    library.addBook(1, "1984");
    library.addBook(2, "Brave New World");
    
    library.addStudent(1, "Alice");
    library.addStudent(2, "Bob");
    
    library.displayBooks();
    library.displayStudents();
    
    library.searchBook(1);
    library.searchStudent(1);
    
    library.updateBook(1, "Animal Farm");
    library.updateStudent(1, "Alice Johnson");
    
    library.displayBooks();
    library.displayStudents();
    
    library.deleteBook(2);
    library.deleteStudent(2);
    
    library.displayBooks();
    library.displayStudents();
    
    return 0;
}