#include <iostream>
#include <string>
#include <vector>
using namespace std;

struct Book {
    int id;
    string title;
    string author;
    bool isAvailable;
};

struct Student {
    int id;
    string name;
    vector<int> borrowedBooks;
};

class LibrarySystem {
private:
    vector<Book> books;
    vector<Student> students;

public:
    void addBook(int id, string title, string author) {
        Book book = {id, title, author, true};
        books.push_back(book);
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string title, string author) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (auto &book : books) {
            cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << ", Available: " << book.isAvailable << endl;
        }
    }

    void addStudent(int id, string name) {
        Student student = {id, name, {}};
        students.push_back(student);
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string name) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto &student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (auto &student : students) {
            cout << "ID: " << student.id << ", Name: " << student.name << endl;
        }
    }
};

int main() {
    LibrarySystem library;
    library.addBook(1, "C++ Primer", "Lippman");
    library.addBook(2, "Effective C++", "Meyers");

    library.addStudent(1, "Alice");
    library.addStudent(2, "Bob");

    library.displayBooks();
    library.displayStudents();

    library.updateBook(1, "C++ Primer 5th Edition", "Lippman");
    library.updateStudent(1, "Alice Johnson");

    library.displayBooks();
    library.displayStudents();

    Book* book = library.searchBook(2);
    if (book) cout << "Found Book: " << book->title << endl;

    Student* student = library.searchStudent(2);
    if (student) cout << "Found Student: " << student->name << endl;

    library.deleteBook(2);
    library.deleteStudent(2);

    library.displayBooks();
    library.displayStudents();

    return 0;
}