#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    Book(int id, const std::string& title, const std::string& author) : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;
    Student(int id, const std::string& name) : id(id), name(name) {}
};

class LibraryManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Student> students;

    int findBookIndex(int id) {
        for (size_t i = 0; i < books.size(); ++i) {
            if (books[i].id == id) return i;
        }
        return -1;
    }

    int findStudentIndex(int id) {
        for (size_t i = 0; i < students.size(); ++i) {
            if (students[i].id == id) return i;
        }
        return -1;
    }

public:
    void addBook(int id, const std::string& title, const std::string& author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        int index = findBookIndex(id);
        if (index != -1) books.erase(books.begin() + index);
    }

    void updateBook(int id, const std::string& title, const std::string& author) {
        int index = findBookIndex(id);
        if (index != -1) {
            books[index].title = title;
            books[index].author = author;
        }
    }

    void searchBook(int id) {
        int index = findBookIndex(id);
        if (index != -1) std::cout << "Book ID: " << books[index].id << ", Title: " << books[index].title << ", Author: " << books[index].author << std::endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }

    void addStudent(int id, const std::string& name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        int index = findStudentIndex(id);
        if (index != -1) students.erase(students.begin() + index);
    }

    void updateStudent(int id, const std::string& name) {
        int index = findStudentIndex(id);
        if (index != -1) {
            students[index].name = name;
        }
    }

    void searchStudent(int id) {
        int index = findStudentIndex(id);
        if (index != -1) std::cout << "Student ID: " << students[index].id << ", Name: " << students[index].name << std::endl;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addBook(1, "1984", "George Orwell");
    lms.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    lms.addStudent(1, "Alice Smith");
    lms.addStudent(2, "Bob Jones");
    lms.displayBooks();
    lms.displayStudents();
    lms.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    lms.updateStudent(1, "Alice Johnson");
    lms.searchBook(1);
    lms.searchStudent(1);
    lms.deleteBook(2);
    lms.deleteStudent(2);
    lms.displayBooks();
    lms.displayStudents();
    return 0;
}