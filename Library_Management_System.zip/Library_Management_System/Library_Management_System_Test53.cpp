#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Student {
public:
    int id;
    string name;

    Student(int id, string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    string title;
    string author;

    Book(int id, string title, string author) : id(id), title(title), author(author) {}
};

class LibraryManagementSystem {
private:
    vector<Student> students;
    vector<Book> books;

public:
    void addStudent(int id, string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                return;
            }
        }
    }

    void updateStudent(int id, string name) {
        for (auto& s : students) {
            if (s.id == id) {
                s.name = name;
                return;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& s : students) {
            if (s.id == id) {
                return &s;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& s : students) {
            cout << "Student ID: " << s.id << ", Name: " << s.name << endl;
        }
    }

    void addBook(int id, string title, string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                return;
            }
        }
    }

    void updateBook(int id, string title, string author) {
        for (auto& b : books) {
            if (b.id == id) {
                b.title = title;
                b.author = author;
                return;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto& b : books) {
            if (b.id == id) {
                return &b;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& b : books) {
            cout << "Book ID: " << b.id << ", Title: " << b.title << ", Author: " << b.author << endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;

    lms.addStudent(1, "Alice");
    lms.addStudent(2, "Bob");
    lms.displayStudents();

    lms.addBook(101, "1984", "George Orwell");
    lms.addBook(102, "To Kill a Mockingbird", "Harper Lee");
    lms.displayBooks();

    lms.updateStudent(1, "Alicia");
    lms.updateBook(101, "Nineteen Eighty-Four", "George Orwell");

    Student* student = lms.searchStudent(1);
    if (student) {
        cout << "Found student: " << student->name << endl;
    } else {
        cout << "Student not found." << endl;
    }

    Book* book = lms.searchBook(101);
    if (book) {
        cout << "Found book: " << book->title << " by " << book->author << endl;
    } else {
        cout << "Book not found." << endl;
    }

    lms.deleteStudent(2);
    lms.deleteBook(102);

    lms.displayStudents();
    lms.displayBooks();

    return 0;
}