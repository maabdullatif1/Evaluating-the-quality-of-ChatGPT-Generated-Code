#include <iostream>
#include <vector>
#include <string>

class Student {
public:
    int id;
    std::string name;

    Student(int id, const std::string& name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int id, const std::string& title, const std::string& author)
        : id(id), title(title), author(author) {}
};

class Library {
private:
    std::vector<Student> students;
    std::vector<Book> books;

public:
    void addStudent(int id, const std::string& name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string& newName) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << '\n';
        }
    }

    void addBook(int id, const std::string& title, const std::string& author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const std::string& newTitle, const std::string& newAuthor) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << '\n';
        }
    }
};

int main() {
    Library library;
    library.addStudent(1, "Alice");
    library.addStudent(2, "Bob");
    library.displayStudents();
    library.addBook(101, "The Great Gatsby", "F. Scott Fitzgerald");
    library.addBook(102, "1984", "George Orwell");
    library.displayBooks();
    return 0;
}