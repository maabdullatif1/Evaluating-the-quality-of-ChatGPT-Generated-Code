#include <iostream>
#include <vector>
#include <string>

class Book {
    std::string title;
    std::string author;
    int bookID;
    
public:
    Book(const std::string& t, const std::string& a, int id) : title(t), author(a), bookID(id) {}
    
    int getBookID() const { return bookID; }
    std::string getTitle() const { return title; }
    std::string getAuthor() const { return author; }
    
    void display() const {
        std::cout << "Book ID: " << bookID << ", Title: " << title << ", Author: " << author << std::endl;
    }
};

class Student {
    std::string name;
    int studentID;
    
public:
    Student(const std::string& n, int id) : name(n), studentID(id) {}
    
    int getStudentID() const { return studentID; }
    std::string getName() const { return name; }
    
    void display() const {
        std::cout << "Student ID: " << studentID << ", Name: " << name << std::endl;
    }
};

class Library {
    std::vector<Book> books;
    std::vector<Student> students;
    
public:
    void addBook(const std::string& title, const std::string& author, int id) {
        books.emplace_back(title, author, id);
    }
    
    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(), [id](const Book& b) { return b.getBookID() == id; }), books.end());
    }
    
    void updateBook(int id, const std::string& title, const std::string& author) {
        for (Book& book : books) {
            if (book.getBookID() == id) {
                book = Book(title, author, id);
                break;
            }
        }
    }
    
    void searchBook(int id) const {
        for (const Book& book : books) {
            if (book.getBookID() == id) {
                book.display();
                return;
            }
        }
        std::cout << "Book not found" << std::endl;
    }
    
    void displayBooks() const {
        for (const Book& book : books) {
            book.display();
        }
    }
    
    void addStudent(const std::string& name, int id) {
        students.emplace_back(name, id);
    }

    void deleteStudent(int id) {
        students.erase(std::remove_if(students.begin(), students.end(), [id](const Student& s) { return s.getStudentID() == id; }), students.end());
    }
    
    void updateStudent(int id, const std::string& name) {
        for (Student& student : students) {
            if (student.getStudentID() == id) {
                student = Student(name, id);
                break;
            }
        }
    }
    
    void searchStudent(int id) const {
        for (const Student& student : students) {
            if (student.getStudentID() == id) {
                student.display();
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }
    
    void displayStudents() const {
        for (const Student& student : students) {
            student.display();
        }
    }
};

int main() {
    Library library;
    
    library.addBook("1984", "George Orwell", 1);
    library.addBook("To Kill a Mockingbird", "Harper Lee", 2);
    library.addStudent("Alice", 101);
    library.addStudent("Bob", 102);
    
    std::cout << "Books:" << std::endl;
    library.displayBooks();
    
    std::cout << "Students:" << std::endl;
    library.displayStudents();
    
    library.searchBook(1);
    library.searchStudent(101);
    
    library.updateBook(1, "Animal Farm", "George Orwell");
    library.updateStudent(101, "Alice Johnson");
    
    library.displayBooks();
    library.displayStudents();
    
    return 0;
}