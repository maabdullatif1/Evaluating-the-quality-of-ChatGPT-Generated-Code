#include <iostream>
#include <vector>
#include <string>

class Student {
public:
    int id;
    std::string name;

    Student(int id, const std::string& name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;

    Book(int id, const std::string& title) : id(id), title(title) {}
};

class LibraryManagementSystem {
private:
    std::vector<Student> students;
    std::vector<Book> books;

    Student* findStudentById(int id) {
        for (auto& student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    Book* findBookById(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

public:
    void addStudent(int id, const std::string& name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(int id) {
        students.erase(std::remove_if(students.begin(), students.end(), [id](Student& s) { return s.id == id; }), students.end());
    }

    void updateStudent(int id, const std::string& newName) {
        Student* student = findStudentById(id);
        if (student) {
            student->name = newName;
        }
    }

    void searchStudent(int id) {
        Student* student = findStudentById(id);
        if (student) {
            std::cout << "Student ID: " << student->id << ", Name: " << student->name << "\n";
        } else {
            std::cout << "Student not found.\n";
        }
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << "\n";
        }
    }

    void addBook(int id, const std::string& title) {
        books.emplace_back(id, title);
    }

    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(), [id](Book& b) { return b.id == id; }), books.end());
    }

    void updateBook(int id, const std::string& newTitle) {
        Book* book = findBookById(id);
        if (book) {
            book->title = newTitle;
        }
    }

    void searchBook(int id) {
        Book* book = findBookById(id);
        if (book) {
            std::cout << "Book ID: " << book->id << ", Title: " << book->title << "\n";
        } else {
            std::cout << "Book not found.\n";
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << "\n";
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addStudent(1, "John Doe");
    lms.addBook(101, "C++ Programming");
    lms.updateStudent(1, "Jane Doe");
    lms.updateBook(101, "Advanced C++ Programming");
    lms.searchStudent(1);
    lms.searchBook(101);
    lms.displayStudents();
    lms.displayBooks();
    lms.deleteStudent(1);
    lms.deleteBook(101);
    lms.displayStudents();
    lms.displayBooks();
    return 0;
}