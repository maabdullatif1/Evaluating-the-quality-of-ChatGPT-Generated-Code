#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int id, std::string title, std::string author)
        : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;
    
    Student(int id, std::string name)
        : id(id), name(name) {}
};

class LibraryManagementSystem {
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for(auto it = books.begin(); it != books.end(); ++it) {
            if(it->id == id) {
                books.erase(it);
                break;
            }
        }
    }
    
    void updateBook(int id, std::string newTitle, std::string newAuthor) {
        for(auto &book : books) {
            if(book.id == id) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }
    
    void displayBooks() const {
        for(const auto &book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << "\n";
        }
    }

    void searchBook(int id) const {
        for(const auto &book : books) {
            if(book.id == id) {
                std::cout << "Found Book - ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << "\n";
                return;
            }
        }
        std::cout << "Book not found\n";
    }
    
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for(auto it = students.begin(); it != students.end(); ++it) {
            if(it->id == id) {
                students.erase(it);
                break;
            }
        }
    }
    
    void updateStudent(int id, std::string newName) {
        for(auto &student : students) {
            if(student.id == id) {
                student.name = newName;
                break;
            }
        }
    }
   
    void displayStudents() const {
        for(const auto &student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << "\n";
        }
    }
    
    void searchStudent(int id) const {
        for(const auto &student : students) {
            if(student.id == id) {
                std::cout << "Found Student - ID: " << student.id << ", Name: " << student.name << "\n";
                return;
            }
        }
        std::cout << "Student not found\n";
    }
};

int main() {
    LibraryManagementSystem lib;
    lib.addBook(1, "1984", "George Orwell");
    lib.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    
    lib.addStudent(101, "Alice");
    lib.addStudent(102, "Bob");

    std::cout << "Books in library:\n";
    lib.displayBooks();
    
    std::cout << "Students in system:\n";
    lib.displayStudents();

    lib.searchBook(1);
    lib.searchStudent(102);

    lib.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    lib.updateStudent(101, "Alice Smith");

    lib.deleteBook(2);
    lib.deleteStudent(102);

    std::cout << "\nUpdated Books in library:\n";
    lib.displayBooks();

    std::cout << "Updated Students in system:\n";
    lib.displayStudents();

    return 0;
}