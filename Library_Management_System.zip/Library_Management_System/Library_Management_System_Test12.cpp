#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Book {
    int id;
    string title;
    string author;
};

struct Student {
    int id;
    string name;
    int borrowedBookId;
};

class Library {
private:
    vector<Book> books;
    vector<Student> students;
    
public:
    void addBook(int id, string title, string author) {
        Book newBook = {id, title, author};
        books.push_back(newBook);
    }

    void addStudent(int id, string name) {
        Student newStudent = {id, name, -1};
        students.push_back(newStudent);
    }
    
    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                return;
            }
        }
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                return;
            }
        }
    }

    void updateBook(int id, string title, string author) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                return;
            }
        }
    }

    void updateStudent(int id, string name) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = name;
                return;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    Student* searchStudent(int id) {
        for (auto &student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto &book : books) {
            cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
        }
    }

    void displayStudents() {
        for (const auto &student : students) {
            cout << "ID: " << student.id << ", Name: " << student.name << ", Borrowed Book ID: " << student.borrowedBookId << endl;
        }
    }
};

int main() {
    Library library;
    
    library.addBook(1, "1984", "George Orwell");
    library.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    library.addStudent(1, "Alice");
    library.addStudent(2, "Bob");
    
    cout << "Display Books:" << endl;
    library.displayBooks();
    
    cout << "Display Students:" << endl;
    library.displayStudents();
    
    Book* book = library.searchBook(1);
    if (book != nullptr) {
        cout << "Found Book: " << book->title << endl;
    }

    Student* student = library.searchStudent(1);
    if (student != nullptr) {
        cout << "Found Student: " << student->name << endl;
    }
    
    library.updateBook(2, "To Kill a Mockingbird", "Harper Lee Updated");
    library.updateStudent(2, "Bob Updated");
    
    library.deleteBook(1);
    library.deleteStudent(1);
    
    cout << "Display Books After Updates:" << endl;
    library.displayBooks();
    
    cout << "Display Students After Updates:" << endl;
    library.displayStudents();
    
    return 0;
}