#include <iostream>
#include <vector>
#include <string>

struct Book {
    int id;
    std::string title;
    std::string author;
};

struct Student {
    int id;
    std::string name;
};

class LibraryManagementSystem {
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, const std::string& title, const std::string& author) {
        books.push_back({id, title, author});
    }

    void deleteBook(int id) {
        for (size_t i = 0; i < books.size(); ++i) {
            if (books[i].id == id) {
                books.erase(books.begin() + i);
                break;
            }
        }
    }
    
    void updateBook(int id, const std::string& title, const std::string& author) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title 
                          << ", Author: " << book.author << std::endl;
                return;
            }
        }
        std::cout << "Book not found" << std::endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title 
                      << ", Author: " << book.author << std::endl;
        }
    }

    void addStudent(int id, const std::string& name) {
        students.push_back({id, name});
    }

    void deleteStudent(int id) {
        for (size_t i = 0; i < students.size(); ++i) {
            if (students[i].id == id) {
                students.erase(students.begin() + i);
                break;
            }
        }
    }

    void updateStudent(int id, const std::string& name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    
    lms.addBook(1, "C++ Programming", "Bjarne Stroustrup");
    lms.addBook(2, "Effective C++", "Scott Meyers");
    
    lms.addStudent(101, "Alice");
    lms.addStudent(102, "Bob");
    
    lms.displayBooks();
    lms.displayStudents();
    
    lms.updateBook(1, "C++ Programming Language", "Bjarne Stroustrup");
    lms.updateStudent(101, "Alice Johnson");
    
    lms.searchBook(1);
    lms.searchStudent(101);
    
    lms.deleteBook(2);
    lms.deleteStudent(102);
    
    lms.displayBooks();
    lms.displayStudents();
    
    return 0;
}