#include <iostream>
#include <vector>
#include <string>

struct Student {
    int id;
    std::string name;
};

struct Book {
    int id;
    std::string title;
};

class LibraryManagementSystem {
private:
    std::vector<Student> students;
    std::vector<Book> books;
    
public:
    void addStudent(int id, std::string name) {
        students.push_back({id, name});
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string newName) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = newName;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto &student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto &student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }

    void addBook(int id, std::string title) {
        books.push_back({id, title});
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string newTitle) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = newTitle;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto &book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto &book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;

    lms.addStudent(1, "Alice");
    lms.addStudent(2, "Bob");

    lms.addBook(101, "C++ Programming");
    lms.addBook(102, "Data Structures");

    lms.displayStudents();
    lms.displayBooks();

    lms.updateStudent(1, "Alice Smith");
    lms.updateBook(101, "Advanced C++");

    lms.displayStudents();
    lms.displayBooks();

    Student* student = lms.searchStudent(1);
    if (student) {
        std::cout << "Found Student - ID: " << student->id << ", Name: " << student->name << std::endl;
    }

    Book* book = lms.searchBook(101);
    if (book) {
        std::cout << "Found Book - ID: " << book->id << ", Title: " << book->title << std::endl;
    }

    lms.deleteStudent(2);
    lms.deleteBook(102);

    lms.displayStudents();
    lms.displayBooks();

    return 0;
}