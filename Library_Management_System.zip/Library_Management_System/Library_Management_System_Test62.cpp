#include <iostream>
#include <vector>
#include <string>

class Student {
public:
    int id;
    std::string name;
    Student(int id, std::string name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    std::string title;
    std::string author;
    Book(int id, std::string title, std::string author) : id(id), title(title), author(author) {}
};

class LibrarySystem {
private:
    std::vector<Student> students;
    std::vector<Book> books;

public:
    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found" << std::endl;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }

    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string title, std::string author) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
                return;
            }
        }
        std::cout << "Book not found" << std::endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }
};

int main() {
    LibrarySystem libSys;
    libSys.addStudent(1, "Alice");
    libSys.addStudent(2, "Bob");
    libSys.displayStudents();
    libSys.updateStudent(1, "Alice Smith");
    libSys.searchStudent(1);
    libSys.deleteStudent(2);
    libSys.displayStudents();

    libSys.addBook(101, "1984", "George Orwell");
    libSys.addBook(102, "To Kill a Mockingbird", "Harper Lee");
    libSys.displayBooks();
    libSys.updateBook(101, "Nineteen Eighty-Four", "George Orwell");
    libSys.searchBook(101);
    libSys.deleteBook(102);
    libSys.displayBooks();

    return 0;
}