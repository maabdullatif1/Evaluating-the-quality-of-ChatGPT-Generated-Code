#include <iostream>
#include <string>
#include <vector>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    
    Book(int id, std::string title, std::string author)
        : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;
    
    Student(int id, std::string name)
        : id(id), name(name) {}
};

class LibrarySystem {
private:
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if ((*it).id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string title, std::string author) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title 
                      << ", Author: " << book.author << std::endl;
        }
    }

    void addStudent(int id, std::string name) {
        students.push_back(Student(id, name));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if ((*it).id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    LibrarySystem library;

    library.addBook(1, "The Great Gatsby", "F. Scott Fitzgerald");
    library.addBook(2, "1984", "George Orwell");

    library.addStudent(1, "Alice");
    library.addStudent(2, "Bob");

    library.displayBooks();
    library.displayStudents();

    library.updateBook(2, "Animal Farm", "George Orwell");
    library.updateStudent(2, "Charlie");

    library.displayBooks();
    library.displayStudents();
    
    library.deleteBook(1);
    library.deleteStudent(1);

    library.displayBooks();
    library.displayStudents();

    return 0;
}