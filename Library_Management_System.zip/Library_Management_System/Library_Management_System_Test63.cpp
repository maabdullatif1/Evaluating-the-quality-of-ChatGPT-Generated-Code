#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Book {
    public:
        int id;
        string title;
        string author;

        Book(int bid, string btitle, string bauthor) {
            id = bid;
            title = btitle;
            author = bauthor;
        }
};

class Student {
    public:
        int id;
        string name;
        string course;

        Student(int sid, string sname, string scourse) {
            id = sid;
            name = sname;
            course = scourse;
        }
};

class Library {
    vector<Book> books;
    vector<Student> students;

    public:
        void addBook(int id, string title, string author) {
            books.push_back(Book(id, title, author));
        }

        void deleteBook(int id) {
            for (auto it = books.begin(); it != books.end(); ++it) {
                if (it->id == id) {
                    books.erase(it);
                    break;
                }
            }
        }

        void updateBook(int id, string title, string author) {
            for (auto &book : books) {
                if (book.id == id) {
                    book.title = title;
                    book.author = author;
                    break;
                }
            }
        }

        Book* searchBook(int id) {
            for (auto &book : books) {
                if (book.id == id) {
                    return &book;
                }
            }
            return nullptr;
        }

        void displayBooks() {
            for (auto &book : books) {
                cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
            }
        }

        void addStudent(int id, string name, string course) {
            students.push_back(Student(id, name, course));
        }

        void deleteStudent(int id) {
            for (auto it = students.begin(); it != students.end(); ++it) {
                if (it->id == id) {
                    students.erase(it);
                    break;
                }
            }
        }

        void updateStudent(int id, string name, string course) {
            for (auto &student : students) {
                if (student.id == id) {
                    student.name = name;
                    student.course = course;
                    break;
                }
            }
        }

        Student* searchStudent(int id) {
            for (auto &student : students) {
                if (student.id == id) {
                    return &student;
                }
            }
            return nullptr;
        }

        void displayStudents() {
            for (auto &student : students) {
                cout << "ID: " << student.id << ", Name: " << student.name << ", Course: " << student.course << endl;
            }
        }
};

int main() {
    Library lib;
    lib.addBook(1, "The Great Gatsby", "F. Scott Fitzgerald");
    lib.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    lib.displayBooks();
    lib.addStudent(1, "John Doe", "Computer Science");
    lib.addStudent(2, "Jane Smith", "Mathematics");
    lib.displayStudents();
    return 0;
}