#include <iostream>
#include <vector>
#include <string>

class Student {
public:
    int id;
    std::string name;
    std::string department;

    Student(int id, std::string name, std::string department)
        : id(id), name(name), department(department) {}
};

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int id, std::string title, std::string author)
        : id(id), title(title), author(author) {}
};

class LibraryManagementSystem {
private:
    std::vector<Student> students;
    std::vector<Book> books;

public:
    void addStudent(int id, std::string name, std::string department) {
        students.push_back(Student(id, name, department));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, std::string name, std::string department) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                student.department = department;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                std::cout << "Student ID: " << student.id << ", Name: " << student.name << ", Department: " << student.department << std::endl;
                return;
            }
        }
        std::cout << "Student not found!" << std::endl;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << ", Department: " << student.department << std::endl;
        }
    }

    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, std::string title, std::string author) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
                return;
            }
        }
        std::cout << "Book not found!" << std::endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addStudent(1, "Alice", "Physics");
    lms.addStudent(2, "Bob", "Chemistry");
    lms.addBook(1, "C++ Programming", "Bjarne Stroustrup");
    lms.addBook(2, "Introduction to Algorithms", "Thomas H. Cormen");

    std::cout << "Displaying All Students:" << std::endl;
    lms.displayStudents();
    
    std::cout << "Displaying All Books:" << std::endl;
    lms.displayBooks();

    lms.searchStudent(1);
    lms.searchBook(1);

    lms.updateStudent(1, "Alice Smith", "Mathematics");
    lms.updateBook(1, "The C++ Programming Language", "Bjarne Stroustrup");

    std::cout << "After Updating:" << std::endl;
    lms.displayStudents();
    lms.displayBooks();

    lms.deleteStudent(1);
    lms.deleteBook(1);

    std::cout << "After Deleting:" << std::endl;
    lms.displayStudents();
    lms.displayBooks();

    return 0;
}