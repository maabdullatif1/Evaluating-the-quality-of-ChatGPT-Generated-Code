#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    Book(int i, std::string t, std::string a) : id(i), title(t), author(a) {}
};

class Student {
public:
    int id;
    std::string name;
    Student(int i, std::string n) : id(i), name(n) {}
};

class LibraryManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Student> students;

    template<typename T>
    void display(const std::vector<T>& items) {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << "\n";
            if constexpr(std::is_same_v<T, Book>)
                std::cout << "Title: " << item.title << "\nAuthor: " << item.author << "\n";
            else if constexpr(std::is_same_v<T, Student>)
                std::cout << "Name: " << item.name << "\n";
            std::cout << "--------------\n";
        }
    }
    
    template<typename T>
    T* search(std::vector<T>& items, int id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

public:
    void addBook(int id, const std::string& title, const std::string& author) {
        books.emplace_back(id, title, author);
    }

    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(), [&](Book& book) { return book.id == id; }), books.end());
    }

    void updateBook(int id, const std::string& title, const std::string& author) {
        Book* book = search(books, id);
        if (book) {
            book->title = title;
            book->author = author;
        }
    }

    void addStudent(int id, const std::string& name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(int id) {
        students.erase(std::remove_if(students.begin(), students.end(), [&](Student& student) { return student.id == id; }), students.end());
    }

    void updateStudent(int id, const std::string& name) {
        Student* student = search(students, id);
        if (student) {
            student->name = name;
        }
    }

    void displayBooks() {
        display(books);
    }

    void displayStudents() {
        display(students);
    }

    Book* searchBook(int id) {
        return search(books, id);
    }

    Student* searchStudent(int id) {
        return search(students, id);
    }
};

int main() {
    LibraryManagementSystem library;

    library.addBook(1, "1984", "George Orwell");
    library.addBook(2, "To Kill a Mockingbird", "Harper Lee");

    library.addStudent(1, "Alice");
    library.addStudent(2, "Bob");

    std::cout << "Books:\n";
    library.displayBooks();

    std::cout << "\nStudents:\n";
    library.displayStudents();

    library.updateBook(1, "1984", "Eric Arthur Blair");
    library.updateStudent(1, "Alice Smith");

    std::cout << "\nUpdated Books:\n";
    library.displayBooks();

    std::cout << "\nUpdated Students:\n";
    library.displayStudents();

    library.deleteBook(2);
    library.deleteStudent(2);

    std::cout << "\nAfter Deletions - Books:\n";
    library.displayBooks();

    std::cout << "\nAfter Deletions - Students:\n";
    library.displayStudents();

    return 0;
}