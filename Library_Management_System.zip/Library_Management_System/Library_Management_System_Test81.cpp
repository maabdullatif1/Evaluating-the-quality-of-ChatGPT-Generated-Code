#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;
    Book(int id, std::string title, std::string author) : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;
    std::string major;
    Student(int id, std::string name, std::string major) : id(id), name(name), major(major) {}
};

class Library {
    std::vector<Book> books;
    std::vector<Student> students;

    template <typename T>
    typename std::vector<T>::iterator find_by_id(std::vector<T>& vec, int id) {
        return std::find_if(vec.begin(), vec.end(), [id](T& item) { return item.id == id; });
    }

public:
    void addBook(int id, std::string title, std::string author) {
        books.push_back(Book(id, title, author));
    }

    void addStudent(int id, std::string name, std::string major) {
        students.push_back(Student(id, name, major));
    }

    void deleteBook(int id) {
        auto it = find_by_id(books, id);
        if (it != books.end()) books.erase(it);
    }
    
    void deleteStudent(int id) {
        auto it = find_by_id(students, id);
        if (it != students.end()) students.erase(it);
    }

    void updateBook(int id, std::string title, std::string author) {
        auto it = find_by_id(books, id);
        if (it != books.end()) {
            it->title = title;
            it->author = author;
        }
    }

    void updateStudent(int id, std::string name, std::string major) {
        auto it = find_by_id(students, id);
        if (it != students.end()) {
            it->name = name;
            it->major = major;
        }
    }

    void searchBook(int id) {
        auto it = find_by_id(books, id);
        if (it != books.end()) {
            std::cout << "Book ID: " << it->id << ", Title: " << it->title << ", Author: " << it->author << "\n";
        } else {
            std::cout << "Book not found\n";
        }
    }

    void searchStudent(int id) {
        auto it = find_by_id(students, id);
        if (it != students.end()) {
            std::cout << "Student ID: " << it->id << ", Name: " << it->name << ", Major: " << it->major << "\n";
        } else {
            std::cout << "Student not found\n";
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << "\n";
        }
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << ", Major: " << student.major << "\n";
        }
    }
};

int main() {
    Library library;
    library.addBook(1, "1984", "George Orwell");
    library.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    library.addStudent(1, "John Doe", "Computer Science");
    library.addStudent(2, "Jane Smith", "Biology");
    library.displayBooks();
    library.displayStudents();
    library.searchBook(1);
    library.searchStudent(1);
    library.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    library.updateStudent(1, "John Doe", "Mathematics");
    library.deleteBook(2);
    library.deleteStudent(2);
    library.displayBooks();
    library.displayStudents();
    return 0;
}