#include <iostream>
#include <string>
#include <vector>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int bookId, const std::string &bookTitle, const std::string &bookAuthor)
        : id(bookId), title(bookTitle), author(bookAuthor) {}
};

class Student {
public:
    int id;
    std::string name;

    Student(int studentId, const std::string &studentName)
        : id(studentId), name(studentName) {}
};

class Library {
private:
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(const Book &book) {
        books.push_back(book);
    }

    void deleteBook(int bookId) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == bookId) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int bookId, const std::string &newTitle, const std::string &newAuthor) {
        for (auto &book : books) {
            if (book.id == bookId) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }

    void searchBook(int bookId) {
        for (const auto &book : books) {
            if (book.id == bookId) {
                std::cout << "Found Book: " << book.title << " by " << book.author << std::endl;
                return;
            }
        }
        std::cout << "Book not found." << std::endl;
    }

    void displayBooks() {
        if (books.empty()) {
            std::cout << "No books available." << std::endl;
            return;
        }
        for (const auto &book : books) {
            std::cout << book.id << ": " << book.title << " by " << book.author << std::endl;
        }
    }

    void addStudent(const Student &student) {
        students.push_back(student);
    }

    void deleteStudent(int studentId) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == studentId) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int studentId, const std::string &newName) {
        for (auto &student : students) {
            if (student.id == studentId) {
                student.name = newName;
                break;
            }
        }
    }

    void searchStudent(int studentId) {
        for (const auto &student : students) {
            if (student.id == studentId) {
                std::cout << "Found Student: " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student not found." << std::endl;
    }

    void displayStudents() {
        if (students.empty()) {
            std::cout << "No students enrolled." << std::endl;
            return;
        }
        for (const auto &student : students) {
            std::cout << student.id << ": " << student.name << std::endl;
        }
    }
};

int main() {
    Library library;
    library.addBook(Book(1, "1984", "George Orwell"));
    library.addBook(Book(2, "To Kill a Mockingbird", "Harper Lee"));
    library.displayBooks();
    library.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    library.searchBook(1);
    library.deleteBook(2);
    library.displayBooks();

    library.addStudent(Student(1, "Alice"));
    library.addStudent(Student(2, "Bob"));
    library.displayStudents();
    library.updateStudent(1, "Alicia");
    library.searchStudent(1);
    library.deleteStudent(2);
    library.displayStudents();

    return 0;
}