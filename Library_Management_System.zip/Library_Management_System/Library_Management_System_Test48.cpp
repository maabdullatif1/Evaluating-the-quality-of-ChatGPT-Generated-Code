#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Book {
    int id;
    string title;
    string author;
};

struct Student {
    int id;
    string name;
    string dept;
};

class LibraryManagementSystem {
    vector<Book> books;
    vector<Student> students;

public:
    void addBook(int id, const string& title, const string& author) {
        books.push_back({id, title, author});
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const string& title, const string& author) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << endl;
        }
    }

    void addStudent(int id, const string& name, const string& dept) {
        students.push_back({id, name, dept});
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const string& name, const string& dept) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                student.dept = dept;
                break;
            }
        }
    }

    void displayStudents() {
        for (const auto& student : students) {
            cout << "ID: " << student.id << ", Name: " << student.name << ", Department: " << student.dept << endl;
        }
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }
};

int main() {
    LibraryManagementSystem libSys;
    libSys.addBook(1, "1984", "George Orwell");
    libSys.addBook(2, "To Kill a Mockingbird", "Harper Lee");
    libSys.addStudent(1, "Alice", "Computer Science");
    libSys.addStudent(2, "Bob", "Mathematics");

    libSys.displayBooks();
    libSys.displayStudents();

    Book* foundBook = libSys.searchBook(1);
    if (foundBook) {
        cout << "Found Book - ID: " << foundBook->id << ", Title: " << foundBook->title << ", Author: " << foundBook->author << endl;
    }

    Student* foundStudent = libSys.searchStudent(2);
    if (foundStudent) {
        cout << "Found Student - ID: " << foundStudent->id << ", Name: " << foundStudent->name << ", Department: " << foundStudent->dept << endl;
    }

    libSys.updateBook(1, "Animal Farm", "George Orwell");
    libSys.updateStudent(1, "Alice Johnson", "Physics");

    libSys.displayBooks();
    libSys.displayStudents();

    libSys.deleteBook(2);
    libSys.deleteStudent(2);

    libSys.displayBooks();
    libSys.displayStudents();

    return 0;
}