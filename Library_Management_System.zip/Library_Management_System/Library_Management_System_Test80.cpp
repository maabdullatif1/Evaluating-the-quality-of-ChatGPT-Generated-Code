#include <iostream>
#include <string>
#include <vector>

class Book {
public:
    std::string ISBN;
    std::string title;
    std::string author;

    Book(std::string i, std::string t, std::string a) : ISBN(i), title(t), author(a) {}
};

class Student {
public:
    int id;
    std::string name;
    std::string department;

    Student(int i, std::string n, std::string d) : id(i), name(n), department(d) {}
};

class LibrarySystem {
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(Book b) {
        books.push_back(b);
    }

    void addStudent(Student s) {
        students.push_back(s);
    }

    void deleteBook(std::string isbn) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->ISBN == isbn) {
                books.erase(it);
                break;
            }
        }
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateBook(std::string isbn, std::string newTitle, std::string newAuthor) {
        for (auto& book : books) {
            if (book.ISBN == isbn) {
                book.title = newTitle;
                book.author = newAuthor;
                break;
            }
        }
    }

    void updateStudent(int id, std::string newName, std::string newDept) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = newName;
                student.department = newDept;
                break;
            }
        }
    }

    Book* searchBook(std::string isbn) {
        for (auto& book : books) {
            if (book.ISBN == isbn) {
                return &book;
            }
        }
        return nullptr;
    }

    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "ISBN: " << book.ISBN << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "ID: " << student.id << ", Name: " << student.name << ", Department: " << student.department << std::endl;
        }
    }
};

int main() {
    LibrarySystem lib;

    lib.addBook(Book("123", "C++ Programming", "Bjarne Stroustrup"));
    lib.addBook(Book("456", "Effective C++", "Scott Meyers"));

    lib.addStudent(Student(1, "John Doe", "Computer Science"));
    lib.addStudent(Student(2, "Jane Smith", "Mathematics"));

    lib.displayBooks();
    lib.displayStudents();

    Book* book = lib.searchBook("123");
    if (book) std::cout << "Found Book: " << book->title << std::endl;

    Student* student = lib.searchStudent(1);
    if (student) std::cout << "Found Student: " << student->name << std::endl;

    lib.updateBook("123", "The C++ Programming Language", "Bjarne Stroustrup");
    lib.updateStudent(1, "John Doe", "Software Engineering");

    lib.displayBooks();
    lib.displayStudents();

    lib.deleteBook("456");
    lib.deleteStudent(2);

    lib.displayBooks();
    lib.displayStudents();

    return 0;
}