#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    int id;
    std::string title;
    std::string author;

    Book(int id, const std::string& title, const std::string& author)
        : id(id), title(title), author(author) {}
};

class Student {
public:
    int id;
    std::string name;

    Student(int id, const std::string& name)
        : id(id), name(name) {}
};

class LibraryManagementSystem {
private:
    std::vector<Book> books;
    std::vector<Student> students;

public:
    void addBook(int id, const std::string& title, const std::string& author) {
        books.emplace_back(id, title, author);
    }

    void deleteBook(int id) {
        books.erase(std::remove_if(books.begin(), books.end(),
            [id](const Book& book) { return book.id == id; }), books.end());
    }

    void updateBook(int id, const std::string& title, const std::string& author) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                book.author = author;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto& book : books) {
            if (book.id == id) {
                std::cout << "Book Found: " << book.id << ", " << book.title << ", " << book.author << std::endl;
                return;
            }
        }
        std::cout << "Book Not Found" << std::endl;
    }

    void displayBooks() {
        for (const auto& book : books) {
            std::cout << "Book ID: " << book.id << ", Title: " << book.title << ", Author: " << book.author << std::endl;
        }
    }

    void addStudent(int id, const std::string& name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(int id) {
        students.erase(std::remove_if(students.begin(), students.end(),
            [id](const Student& student) { return student.id == id; }), students.end());
    }

    void updateStudent(int id, const std::string& name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto& student : students) {
            if (student.id == id) {
                std::cout << "Student Found: " << student.id << ", " << student.name << std::endl;
                return;
            }
        }
        std::cout << "Student Not Found" << std::endl;
    }

    void displayStudents() {
        for (const auto& student : students) {
            std::cout << "Student ID: " << student.id << ", Name: " << student.name << std::endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;
    lms.addBook(1, "1984", "George Orwell");
    lms.addBook(2, "Animal Farm", "George Orwell");
    lms.addStudent(1, "John Doe");
    lms.addStudent(2, "Jane Smith");
    lms.displayBooks();
    lms.searchBook(1);
    lms.updateBook(1, "Nineteen Eighty-Four", "George Orwell");
    lms.searchBook(1);
    lms.displayStudents();
    lms.searchStudent(1);
    lms.updateStudent(1, "Johnathan Doe");
    lms.searchStudent(1);
    lms.deleteBook(2);
    lms.displayBooks();
    lms.deleteStudent(2);
    lms.displayStudents();

    return 0;
}