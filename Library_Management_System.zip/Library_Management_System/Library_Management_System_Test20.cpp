#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Student {
    int id;
    string name;
};

struct Book {
    int id;
    string title;
};

class LibraryManagementSystem {
private:
    vector<Student> students;
    vector<Book> books;

public:
    void addStudent(int id, const string& name) {
        students.push_back({id, name});
    }
    
    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const string& name) {
        for (auto& student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }
    
    Student* searchStudent(int id) {
        for (auto& student : students) {
            if (student.id == id) {
                return &student;
            }
        }
        return nullptr;
    }

    void displayStudents() {
        for (const auto& student : students) {
            cout << "ID: " << student.id << ", Name: " << student.name << endl;
        }
    }

    void addBook(int id, const string& title) {
        books.push_back({id, title});
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const string& title) {
        for (auto& book : books) {
            if (book.id == id) {
                book.title = title;
                break;
            }
        }
    }

    Book* searchBook(int id) {
        for (auto& book : books) {
            if (book.id == id) {
                return &book;
            }
        }
        return nullptr;
    }

    void displayBooks() {
        for (const auto& book : books) {
            cout << "ID: " << book.id << ", Title: " << book.title << endl;
        }
    }
};

int main() {
    LibraryManagementSystem library;
    library.addStudent(1, "Alice");
    library.addStudent(2, "Bob");
    library.addBook(1001, "C++ Programming");
    library.addBook(1002, "Data Structures");
    
    library.displayStudents();
    library.displayBooks();
    
    library.updateStudent(1, "Alice Smith");
    library.updateBook(1001, "Advanced C++ Programming");
    
    library.displayStudents();
    library.displayBooks();
    
    library.deleteStudent(2);
    library.deleteBook(1002);
    
    library.displayStudents();
    library.displayBooks();
    
    Student* s = library.searchStudent(1);
    if (s) cout << "Found Student: " << s->name << endl;
    
    Book* b = library.searchBook(1001);
    if (b) cout << "Found Book: " << b->title << endl;

    return 0;
}