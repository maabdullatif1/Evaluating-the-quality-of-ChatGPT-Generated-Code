#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Student {
    int id;
    string name;
    string department;
public:
    Student(int i, string n, string d) : id(i), name(n), department(d) {}
    int getId() const { return id; }
    string getName() const { return name; }
    string getDepartment() const { return department; }
    void update(string n, string d) {
        name = n;
        department = d;
    }
    void display() const {
        cout << "ID: " << id << ", Name: " << name << ", Department: " << department << endl;
    }
};

class Book {
    int id;
    string title;
    string author;
public:
    Book(int i, string t, string a) : id(i), title(t), author(a) {}
    int getId() const { return id; }
    string getTitle() const { return title; }
    string getAuthor() const { return author; }
    void update(string t, string a) {
        title = t;
        author = a;
    }
    void display() const {
        cout << "ID: " << id << ", Title: " << title << ", Author: " << author << endl;
    }
};

class LibraryManagementSystem {
    vector<Student> students;
    vector<Book> books;
public:
    void addStudent(int id, string name, string department) {
        students.push_back(Student(id, name, department));
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->getId() == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, string name, string department) {
        for (auto& student : students) {
            if (student.getId() == id) {
                student.update(name, department);
                break;
            }
        }
    }

    void searchStudent(int id) const {
        for (const auto& student : students) {
            if (student.getId() == id) {
                student.display();
                return;
            }
        }
        cout << "Student not found." << endl;
    }

    void displayStudents() const {
        for (const auto& student : students)
            student.display();
    }

    void addBook(int id, string title, string author) {
        books.push_back(Book(id, title, author));
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->getId() == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, string title, string author) {
        for (auto& book : books) {
            if (book.getId() == id) {
                book.update(title, author);
                break;
            }
        }
    }

    void searchBook(int id) const {
        for (const auto& book : books) {
            if (book.getId() == id) {
                book.display();
                return;
            }
        }
        cout << "Book not found." << endl;
    }

    void displayBooks() const {
        for (const auto& book : books)
            book.display();
    }
};

int main() {
    LibraryManagementSystem lib;
    lib.addStudent(1, "Alice", "Computer Science");
    lib.addStudent(2, "Bob", "Mathematics");
    lib.displayStudents();
    lib.searchStudent(1);
    lib.updateStudent(2, "Robert", "Physics");
    lib.displayStudents();
    lib.deleteStudent(1);
    lib.displayStudents();

    lib.addBook(1, "C++ Programming", "Bjarne Stroustrup");
    lib.addBook(2, "Effective Java", "Joshua Bloch");
    lib.displayBooks();
    lib.searchBook(1);
    lib.updateBook(2, "Effective Java 3rd Edition", "Joshua Bloch");
    lib.displayBooks();
    lib.deleteBook(1);
    lib.displayBooks();

    return 0;
}