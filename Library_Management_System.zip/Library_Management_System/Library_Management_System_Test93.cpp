#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Student {
public:
    int id;
    string name;

    Student(int id, const string &name) : id(id), name(name) {}
};

class Book {
public:
    int id;
    string title;

    Book(int id, const string &title) : id(id), title(title) {}
};

class LibraryManagementSystem {
private:
    vector<Student> students;
    vector<Book> books;

public:
    void addStudent(int id, const string &name) {
        students.emplace_back(id, name);
    }

    void deleteStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                break;
            }
        }
    }

    void updateStudent(int id, const string &name) {
        for (auto &student : students) {
            if (student.id == id) {
                student.name = name;
                break;
            }
        }
    }

    void searchStudent(int id) {
        for (const auto &student : students) {
            if (student.id == id) {
                cout << "Student ID: " << student.id << ", Name: " << student.name << endl;
                return;
            }
        }
        cout << "Student not found" << endl;
    }

    void displayStudents() {
        for (const auto &student : students) {
            cout << "Student ID: " << student.id << ", Name: " << student.name << endl;
        }
    }

    void addBook(int id, const string &title) {
        books.emplace_back(id, title);
    }

    void deleteBook(int id) {
        for (auto it = books.begin(); it != books.end(); ++it) {
            if (it->id == id) {
                books.erase(it);
                break;
            }
        }
    }

    void updateBook(int id, const string &title) {
        for (auto &book : books) {
            if (book.id == id) {
                book.title = title;
                break;
            }
        }
    }

    void searchBook(int id) {
        for (const auto &book : books) {
            if (book.id == id) {
                cout << "Book ID: " << book.id << ", Title: " << book.title << endl;
                return;
            }
        }
        cout << "Book not found" << endl;
    }

    void displayBooks() {
        for (const auto &book : books) {
            cout << "Book ID: " << book.id << ", Title: " << book.title << endl;
        }
    }
};

int main() {
    LibraryManagementSystem lms;

    lms.addStudent(1, "Alice");
    lms.addStudent(2, "Bob");
    lms.displayStudents();

    lms.addBook(101, "C++ Programming");
    lms.addBook(102, "Data Structures");
    lms.displayBooks();

    lms.searchStudent(1);
    lms.searchBook(101);

    lms.updateStudent(2, "Robert");
    lms.updateBook(102, "Advanced Data Structures");

    lms.deleteStudent(1);
    lms.deleteBook(101);

    lms.displayStudents();
    lms.displayBooks();

    return 0;
}