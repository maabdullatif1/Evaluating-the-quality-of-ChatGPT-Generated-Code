#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    std::string phone;
    Person(const std::string& n, const std::string& p) : name(n), phone(p) {}
};

class Salon {
public:
    std::vector<Person> customers;
    std::vector<Person> hairstylists;

    void addPerson(std::vector<Person>& group, const std::string& name, const std::string& phone) {
        group.emplace_back(name, phone);
    }

    void deletePerson(std::vector<Person>& group, const std::string& name) {
        for (auto it = group.begin(); it != group.end(); ++it) {
            if (it->name == name) {
                group.erase(it);
                return;
            }
        }
    }

    void updatePerson(std::vector<Person>& group, const std::string& name, const std::string& newPhone) {
        for (auto& person : group) {
            if (person.name == name) {
                person.phone = newPhone;
                return;
            }
        }
    }

    void searchPerson(const std::vector<Person>& group, const std::string& name) {
        for (const auto& person : group) {
            if (person.name == name) {
                std::cout << "Found: " << person.name << ", Phone: " << person.phone << std::endl;
                return;
            }
        }
        std::cout << "Not found." << std::endl;
    }

    void displayGroup(const std::vector<Person>& group) {
        for (const auto& person : group) {
            std::cout << person.name << ", Phone: " << person.phone << std::endl;
        }
    }
};

int main() {
    Salon salon;

    salon.addPerson(salon.customers, "Alice", "123");
    salon.addPerson(salon.hairstylists, "Bob", "456");

    salon.displayGroup(salon.customers);
    salon.searchPerson(salon.customers, "Alice");
    
    salon.updatePerson(salon.customers, "Alice", "789");
    salon.searchPerson(salon.customers, "Alice");

    salon.deletePerson(salon.customers, "Alice");
    salon.displayGroup(salon.customers);

    return 0;
}