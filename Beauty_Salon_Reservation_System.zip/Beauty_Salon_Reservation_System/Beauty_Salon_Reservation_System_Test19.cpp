#include <iostream>
#include <string>
#include <vector>

class Person {
public:
    std::string name;
    std::string phone_number;
    Person(const std::string& n, const std::string& p) : name(n), phone_number(p) {}
};

class Customer : public Person {
public:
    Customer(const std::string& n, const std::string& p) : Person(n, p) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(const std::string& n, const std::string& p) : Person(n, p) {}
};

template <typename T>
class ManagementSystem {
private:
    std::vector<T> records;
public:
    void add(const T& person) {
        records.push_back(person);
    }
    
    void remove(const std::string& name) {
        for (auto it = records.begin(); it != records.end(); ++it) {
            if (it->name == name) {
                records.erase(it);
                break;
            }
        }
    }
    
    void update(const std::string& name, const std::string& new_phone) {
        for (auto& record : records) {
            if (record.name == name) {
                record.phone_number = new_phone;
                break;
            }
        }
    }
    
    T* search(const std::string& name) {
        for (auto& record : records) {
            if (record.name == name) {
                return &record;
            }
        }
        return nullptr;
    }
    
    void display() {
        for (const auto& record : records) {
            std::cout << "Name: " << record.name << ", Phone: " << record.phone_number << std::endl;
        }
    }
};

int main() {
    ManagementSystem<Customer> customerSystem;
    ManagementSystem<Hairstylist> stylistSystem;

    customerSystem.add(Customer("Alice Smith", "555-1234"));
    customerSystem.add(Customer("Bob Johnson", "555-5678"));

    stylistSystem.add(Hairstylist("Cindy Brown", "555-8765"));
    stylistSystem.add(Hairstylist("David Wilson", "555-4321"));

    customerSystem.display();
    stylistSystem.display();

    customerSystem.update("Alice Smith", "555-9999");
    stylistSystem.remove("Cindy Brown");

    std::cout << "\nAfter Updates:\n";
    customerSystem.display();
    stylistSystem.display();

    Customer* foundCustomer = customerSystem.search("Bob Johnson");
    if (foundCustomer) {
        std::cout << "\nFound Customer: " << foundCustomer->name << ", Phone: " << foundCustomer->phone_number << std::endl;
    }

    return 0;
}