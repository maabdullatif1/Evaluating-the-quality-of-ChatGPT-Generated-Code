#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    string phone;
};

struct Customer : Person {
    string email;
};

struct Hairstylist : Person {
    string specialty;
};

class Salon {
private:
    vector<Customer> customers;
    vector<Hairstylist> hairstylists;

public:
    void addCustomer(const string& name, const string& phone, const string& email) {
        customers.push_back({name, phone, email});
    }
    
    void addHairstylist(const string& name, const string& phone, const string& specialty) {
        hairstylists.push_back({name, phone, specialty});
    }
    
    void deleteCustomer(const string& name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                return;
            }
        }
    }
    
    void deleteHairstylist(const string& name) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->name == name) {
                hairstylists.erase(it);
                return;
            }
        }
    }
    
    void updateCustomer(const string& name, const string& newPhone, const string& newEmail) {
        for (auto& c : customers) {
            if (c.name == name) {
                c.phone = newPhone;
                c.email = newEmail;
                return;
            }
        }
    }

    void updateHairstylist(const string& name, const string& newPhone, const string& newSpecialty) {
        for (auto& h : hairstylists) {
            if (h.name == name) {
                h.phone = newPhone;
                h.specialty = newSpecialty;
                return;
            }
        }
    }

    Customer* searchCustomer(const string& name) {
        for (auto& c : customers) {
            if (c.name == name) {
                return &c;
            }
        }
        return nullptr;
    }

    Hairstylist* searchHairstylist(const string& name) {
        for (auto& h : hairstylists) {
            if (h.name == name) {
                return &h;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& c : customers) {
            cout << "Customer: " << c.name << ", Phone: " << c.phone << ", Email: " << c.email << "\n";
        }
    }

    void displayHairstylists() {
        for (const auto& h : hairstylists) {
            cout << "Hairstylist: " << h.name << ", Phone: " << h.phone << ", Specialty: " << h.specialty << "\n";
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("Alice", "123-456", "alice@example.com");
    salon.addHairstylist("Bob", "987-654", "Color Specialist");
    
    salon.updateCustomer("Alice", "321-654", "alice@newemail.com");
    salon.updateHairstylist("Bob", "789-123", "Stylist");
    
    Customer* customer = salon.searchCustomer("Alice");
    Hairstylist* hairstylist = salon.searchHairstylist("Bob");

    if (customer) {
        cout << "Found customer: " << customer->name << "\n";
    }

    if (hairstylist) {
        cout << "Found hairstylist: " << hairstylist->name << "\n";
    }

    salon.displayCustomers();
    salon.displayHairstylists();

    salon.deleteCustomer("Alice");
    salon.deleteHairstylist("Bob");

    salon.displayCustomers();
    salon.displayHairstylists();
    
    return 0;
}