#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct Hairstylist {
    int id;
    string name;
    string specialization;
};

class ReservationSystem {
    Customer customers[100];
    Hairstylist hairstylists[100];
    int customerCount;
    int hairstylistCount;

public:
    ReservationSystem() : customerCount(0), hairstylistCount(0) {}

    void addCustomer(int id, const string& name, const string& phone) {
        customers[customerCount++] = { id, name, phone };
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                for (int j = i; j < customerCount - 1; ++j) {
                    customers[j] = customers[j + 1];
                }
                customerCount--;
                break;
            }
        }
    }

    void updateCustomer(int id, const string& name, const string& phone) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i].name = name;
                customers[i].phone = phone;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << ", Phone: " << customers[i].phone << endl;
                return;
            }
        }
        cout << "Customer not found" << endl;
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; ++i) {
            cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << ", Phone: " << customers[i].phone << endl;
        }
    }

    void addHairstylist(int id, const string& name, const string& specialization) {
        hairstylists[hairstylistCount++] = { id, name, specialization };
    }

    void deleteHairstylist(int id) {
        for (int i = 0; i < hairstylistCount; ++i) {
            if (hairstylists[i].id == id) {
                for (int j = i; j < hairstylistCount - 1; ++j) {
                    hairstylists[j] = hairstylists[j + 1];
                }
                hairstylistCount--;
                break;
            }
        }
    }

    void updateHairstylist(int id, const string& name, const string& specialization) {
        for (int i = 0; i < hairstylistCount; ++i) {
            if (hairstylists[i].id == id) {
                hairstylists[i].name = name;
                hairstylists[i].specialization = specialization;
                break;
            }
        }
    }

    void searchHairstylist(int id) {
        for (int i = 0; i < hairstylistCount; ++i) {
            if (hairstylists[i].id == id) {
                cout << "Hairstylist ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name << ", Specialization: " << hairstylists[i].specialization << endl;
                return;
            }
        }
        cout << "Hairstylist not found" << endl;
    }

    void displayHairstylists() {
        for (int i = 0; i < hairstylistCount; ++i) {
            cout << "Hairstylist ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name << ", Specialization: " << hairstylists[i].specialization << endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "Alice Johnson", "123-456-7890");
    system.addCustomer(2, "Bob Smith", "234-567-8901");
    system.displayCustomers();
    system.updateCustomer(1, "Alice Brown", "555-555-5555");
    system.searchCustomer(1);
    system.deleteCustomer(2);
    system.displayCustomers();

    system.addHairstylist(1, "Sarah Lee", "Color Specialist");
    system.addHairstylist(2, "John Doe", "Men's Cuts");
    system.displayHairstylists();
    system.updateHairstylist(1, "Sarah Lee", "Hair Extension Specialist");
    system.searchHairstylist(1);
    system.deleteHairstylist(2);
    system.displayHairstylists();

    return 0;
}