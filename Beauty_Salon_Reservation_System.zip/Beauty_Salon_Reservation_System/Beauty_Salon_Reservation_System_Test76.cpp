#include <iostream>
#include <string>
#include <vector>

struct Customer {
    int id;
    std::string name;
    std::string phoneNumber;
};

struct Hairstylist {
    int id;
    std::string name;
    std::string specialization;
};

class BeautySalon {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;
    int customerIDCounter = 0;
    int hairstylistIDCounter = 0;

public:
    void addCustomer(const std::string& name, const std::string& phoneNumber) {
        Customer newCustomer{++customerIDCounter, name, phoneNumber};
        customers.push_back(newCustomer);
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& phoneNumber) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phoneNumber = phoneNumber;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name
                      << ", Phone: " << customer.phoneNumber << std::endl;
        }
    }

    void addHairstylist(const std::string& name, const std::string& specialization) {
        Hairstylist newHairstylist{++hairstylistIDCounter, name, specialization};
        hairstylists.push_back(newHairstylist);
    }

    void deleteHairstylist(int id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->id == id) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateHairstylist(int id, const std::string& name, const std::string& specialization) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                hairstylist.name = name;
                hairstylist.specialization = specialization;
                break;
            }
        }
    }

    Hairstylist* searchHairstylist(int id) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                return &hairstylist;
            }
        }
        return nullptr;
    }

    void displayHairstylists() {
        for (const auto& hairstylist : hairstylists) {
            std::cout << "ID: " << hairstylist.id << ", Name: " << hairstylist.name
                      << ", Specialization: " << hairstylist.specialization << std::endl;
        }
    }
};

int main() {
    BeautySalon salon;
    salon.addCustomer("Alice", "123-456-7890");
    salon.addCustomer("Bob", "098-765-4321");
    salon.addHairstylist("John", "Cutting");
    salon.addHairstylist("Jane", "Styling");

    salon.displayCustomers();
    salon.displayHairstylists();

    salon.updateCustomer(1, "Alice Smith", "123-000-7890");
    salon.updateHairstylist(1, "John Doe", "Coloring");

    salon.displayCustomers();
    salon.displayHairstylists();

    return 0;
}