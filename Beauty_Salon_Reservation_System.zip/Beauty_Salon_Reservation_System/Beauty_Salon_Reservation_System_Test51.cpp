#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
public:
    string name;
    string phone;
};

class Customer : public Person {
public:
    int customerID;
};

class Hairstylist : public Person {
public:
    int stylistID;
};

class Salon {
private:
    vector<Customer> customers;
    vector<Hairstylist> stylists;
    int customerCounter = 1;
    int stylistCounter = 1;

public:
    void addCustomer(string name, string phone) {
        Customer customer;
        customer.customerID = customerCounter++;
        customer.name = name;
        customer.phone = phone;
        customers.push_back(customer);
    }

    void addHairstylist(string name, string phone) {
        Hairstylist stylist;
        stylist.stylistID = stylistCounter++;
        stylist.name = name;
        stylist.phone = phone;
        stylists.push_back(stylist);
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->customerID == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void deleteHairstylist(int id) {
        for (auto it = stylists.begin(); it != stylists.end(); ++it) {
            if (it->stylistID == id) {
                stylists.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string phone) {
        for (auto &customer : customers) {
            if (customer.customerID == id) {
                customer.name = name;
                customer.phone = phone;
                break;
            }
        }
    }

    void updateHairstylist(int id, string name, string phone) {
        for (auto &stylist : stylists) {
            if (stylist.stylistID == id) {
                stylist.name = name;
                stylist.phone = phone;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto &customer : customers) {
            if (customer.customerID == id) {
                cout << "Customer ID: " << customer.customerID << ", Name: " << customer.name << ", Phone: " << customer.phone << endl;
                return;
            }
        }
        cout << "Customer not found." << endl;
    }

    void searchHairstylist(int id) {
        for (const auto &stylist : stylists) {
            if (stylist.stylistID == id) {
                cout << "Stylist ID: " << stylist.stylistID << ", Name: " << stylist.name << ", Phone: " << stylist.phone << endl;
                return;
            }
        }
        cout << "Hairstylist not found." << endl;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "Customer ID: " << customer.customerID << ", Name: " << customer.name << ", Phone: " << customer.phone << endl;
        }
    }

    void displayHairstylists() {
        for (const auto &stylist : stylists) {
            cout << "Stylist ID: " << stylist.stylistID << ", Name: " << stylist.name << ", Phone: " << stylist.phone << endl;
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("Alice", "123-456-7890");
    salon.addHairstylist("Bob", "098-765-4321");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.updateCustomer(1, "Alice Johnson", "111-111-1111");
    salon.searchCustomer(1);
    salon.deleteHairstylist(1);
    salon.displayHairstylists();
    return 0;
}