#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    int id;
    std::string name;
    std::string phone;

    Person(int id, std::string name, std::string phone) : id(id), name(name), phone(phone) {}
};

class Customer : public Person {
public:
    Customer(int id, std::string name, std::string phone) : Person(id, name, phone) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(int id, std::string name, std::string phone) : Person(id, name, phone) {}
};

class BeautySalonSystem {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

    template <typename T>
    T* findPerson(int id, std::vector<T>& list) {
        for (auto& person : list) {
            if (person.id == id) return &person;
        }
        return nullptr;
    }

    template <typename T>
    void addPerson(T& person, std::vector<T>& list) {
        list.push_back(person);
    }

    template <typename T>
    void deletePerson(int id, std::vector<T>& list) {
        list.erase(std::remove_if(list.begin(), list.end(), [id](T& person) {
            return person.id == id;
        }), list.end());
    }

public:
    void addCustomer(int id, std::string name, std::string phone) {
        customers.emplace_back(id, name, phone);
    }

    void updateCustomer(int id, std::string name, std::string phone) {
        Customer* customer = findPerson(id, customers);
        if (customer) {
            customer->name = name;
            customer->phone = phone;
        }
    }

    void deleteCustomer(int id) {
        deletePerson(id, customers);
    }

    Customer* searchCustomer(int id) {
        return findPerson(id, customers);
    }

    void listCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << '\n';
        }
    }

    void addHairstylist(int id, std::string name, std::string phone) {
        hairstylists.emplace_back(id, name, phone);
    }

    void updateHairstylist(int id, std::string name, std::string phone) {
        Hairstylist* hairstylist = findPerson(id, hairstylists);
        if (hairstylist) {
            hairstylist->name = name;
            hairstylist->phone = phone;
        }
    }

    void deleteHairstylist(int id) {
        deletePerson(id, hairstylists);
    }

    Hairstylist* searchHairstylist(int id) {
        return findPerson(id, hairstylists);
    }

    void listHairstylists() {
        for (const auto& hairstylist : hairstylists) {
            std::cout << "ID: " << hairstylist.id << ", Name: " << hairstylist.name << ", Phone: " << hairstylist.phone << '\n';
        }
    }
};

int main() {
    BeautySalonSystem salon;

    salon.addCustomer(1, "Alice", "123456");
    salon.addHairstylist(1, "Bob", "654321");

    salon.listCustomers();
    salon.listHairstylists();

    salon.updateCustomer(1, "Alice Smith", "123456789");
    salon.updateHairstylist(1, "Bob Johnson", "987654321");

    salon.listCustomers();
    salon.listHairstylists();

    salon.deleteCustomer(1);
    salon.deleteHairstylist(1);

    salon.listCustomers();
    salon.listHairstylists();

    return 0;
}