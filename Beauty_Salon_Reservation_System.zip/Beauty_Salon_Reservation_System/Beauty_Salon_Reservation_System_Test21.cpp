#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int id;
public:
    Person(std::string n, int i) : name(n), id(i) {}
    std::string getName() { return name; }
    int getId() { return id; }
};

class Customer : public Person {
public:
    Customer(std::string n, int i) : Person(n, i) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(std::string n, int i) : Person(n, i) {}
};

class Salon {
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

public:
    void addCustomer(std::string name, int id) {
        customers.push_back(Customer(name, id));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string newName) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                customer = Customer(newName, id);
                break;
            }
        }
    }

    Customer searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                return customer;
            }
        }
        return Customer("", -1);
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.getId() << ", Name: " << customer.getName() << std::endl;
        }
    }

    void addHairstylist(std::string name, int id) {
        hairstylists.push_back(Hairstylist(name, id));
    }

    void deleteHairstylist(int id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->getId() == id) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateHairstylist(int id, std::string newName) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.getId() == id) {
                hairstylist = Hairstylist(newName, id);
                break;
            }
        }
    }

    Hairstylist searchHairstylist(int id) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.getId() == id) {
                return hairstylist;
            }
        }
        return Hairstylist("", -1);
    }

    void displayHairstylists() {
        for (const auto& hairstylist : hairstylists) {
            std::cout << "Hairstylist ID: " << hairstylist.getId() << ", Name: " << hairstylist.getName() << std::endl;
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("John Doe", 1);
    salon.addCustomer("Jane Smith", 2);
    salon.addHairstylist("Emily Rose", 101);
    salon.addHairstylist("Chris Brown", 102);

    std::cout << "Customers:" << std::endl;
    salon.displayCustomers();

    std::cout << "Hairstylists:" << std::endl;
    salon.displayHairstylists();

    salon.updateCustomer(1, "Johnnie Doe");
    salon.deleteHairstylist(101);

    std::cout << "Updated Customers:" << std::endl;
    salon.displayCustomers();

    std::cout << "Updated Hairstylists:" << std::endl;
    salon.displayHairstylists();

    return 0;
}