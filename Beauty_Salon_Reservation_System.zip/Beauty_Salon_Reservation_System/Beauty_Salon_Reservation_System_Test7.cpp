#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Person {
protected:
    string name;
    string phone;
public:
    Person(string n, string p) : name(n), phone(p) {}
    string getName() { return name; }
    string getPhone() { return phone; }
    void setName(string n) { name = n; }
    void setPhone(string p) { phone = p; }
};

class Customer : public Person {
public:
    Customer(string n, string p) : Person(n, p) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(string n, string p) : Person(n, p) {}
};

class SalonSystem {
private:
    vector<Customer> customers;
    vector<Hairstylist> hairstylists;
public:
    void addCustomer(string name, string phone) {
        customers.push_back(Customer(name, phone));
    }

    void deleteCustomer(string name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getName() == name) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(string name, string newName, string newPhone) {
        for (auto &customer : customers) {
            if (customer.getName() == name) {
                customer.setName(newName);
                customer.setPhone(newPhone);
                break;
            }
        }
    }

    void searchCustomer(string name) {
        for (const auto &customer : customers) {
            if (customer.getName() == name) {
                cout << "Customer found: " << customer.getName() << ", " << customer.getPhone() << endl;
                return;
            }
        }
        cout << "Customer not found." << endl;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "Customer: " << customer.getName() << ", " << customer.getPhone() << endl;
        }
    }

    void addHairstylist(string name, string phone) {
        hairstylists.push_back(Hairstylist(name, phone));
    }

    void deleteHairstylist(string name) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->getName() == name) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateHairstylist(string name, string newName, string newPhone) {
        for (auto &hairstylist : hairstylists) {
            if (hairstylist.getName() == name) {
                hairstylist.setName(newName);
                hairstylist.setPhone(newPhone);
                break;
            }
        }
    }

    void searchHairstylist(string name) {
        for (const auto &hairstylist : hairstylists) {
            if (hairstylist.getName() == name) {
                cout << "Hairstylist found: " << hairstylist.getName() << ", " << hairstylist.getPhone() << endl;
                return;
            }
        }
        cout << "Hairstylist not found." << endl;
    }

    void displayHairstylists() {
        for (const auto &hairstylist : hairstylists) {
            cout << "Hairstylist: " << hairstylist.getName() << ", " << hairstylist.getPhone() << endl;
        }
    }
};

int main() {
    SalonSystem salon;
    salon.addCustomer("Alice", "123456789");
    salon.addCustomer("Bob", "987654321");
    salon.displayCustomers();
    salon.searchCustomer("Alice");
    salon.updateCustomer("Alice", "Alice Smith", "123123123");
    salon.deleteCustomer("Bob");
    salon.displayCustomers();
    
    salon.addHairstylist("John", "555555555");
    salon.addHairstylist("Doe", "666666666");
    salon.displayHairstylists();
    salon.searchHairstylist("John");
    salon.updateHairstylist("Doe", "Doe Junior", "777777777");
    salon.deleteHairstylist("John");
    salon.displayHairstylists();

    return 0;
}