#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int id;
public:
    Person(std::string n, int i) : name(n), id(i) {}
    int getId() const { return id; }
    std::string getName() const { return name; }
    void setName(std::string n) { name = n; }
};

class Customer : public Person {
public:
    Customer(std::string n, int i) : Person(n, i) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(std::string n, int i) : Person(n, i) {}
};

template <typename T>
class ManagementSystem {
    std::vector<T> people;
public:
    void addPerson(const T& person) {
        people.push_back(person);
    }

    void deletePerson(int id) {
        for (auto it = people.begin(); it != people.end(); ++it) {
            if (it->getId() == id) {
                people.erase(it);
                break;
            }
        }
    }

    void updatePerson(int id, std::string newName) {
        for (auto &person : people) {
            if (person.getId() == id) {
                person.setName(newName);
                break;
            }
        }
    }

    T* searchPerson(int id) {
        for (auto &person : people) {
            if (person.getId() == id) {
                return &person;
            }
        }
        return nullptr;
    }

    void displayPeople() const {
        for (const auto &person : people) {
            std::cout << "ID: " << person.getId() << ", Name: " << person.getName() << std::endl;
        }
    }
};

int main() {
    ManagementSystem<Customer> customerManagement;
    ManagementSystem<Hairstylist> hairstylistManagement;

    customerManagement.addPerson(Customer("Alice", 1));
    customerManagement.addPerson(Customer("Bob", 2));
    customerManagement.displayPeople();

    hairstylistManagement.addPerson(Hairstylist("John", 101));
    hairstylistManagement.addPerson(Hairstylist("Doe", 102));
    hairstylistManagement.displayPeople();

    Customer* customer = customerManagement.searchPerson(1);
    if (customer) {
        std::cout << "Found Customer: " << customer->getName() << std::endl;
    }

    hairstylistManagement.updatePerson(102, "Jane");
    hairstylistManagement.deletePerson(101);
    hairstylistManagement.displayPeople();

    return 0;
}