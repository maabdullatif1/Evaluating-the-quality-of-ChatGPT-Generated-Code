#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    string name;
    string phone;
    Customer(string n, string p) : name(n), phone(p) {}
};

class Hairstylist {
public:
    string name;
    string speciality;
    Hairstylist(string n, string s) : name(n), speciality(s) {}
};

class Salon {
private:
    vector<Customer> customers;
    vector<Hairstylist> hairstylists;

public:
    void addCustomer(string name, string phone) {
        customers.push_back(Customer(name, phone));
    }

    void deleteCustomer(string name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                return;
            }
        }
        cout << "Customer not found" << endl;
    }

    void updateCustomer(string name, string newPhone) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                customer.phone = newPhone;
                return;
            }
        }
        cout << "Customer not found" << endl;
    }

    void searchCustomer(string name) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                cout << "Customer Name: " << customer.name << ", Phone: " << customer.phone << endl;
                return;
            }
        }
        cout << "Customer not found" << endl;
    }

    void displayCustomers() {
        cout << "Customers List:" << endl;
        for (auto& customer : customers) {
            cout << "Name: " << customer.name << ", Phone: " << customer.phone << endl;
        }
    }

    void addHairstylist(string name, string speciality) {
        hairstylists.push_back(Hairstylist(name, speciality));
    }

    void deleteHairstylist(string name) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->name == name) {
                hairstylists.erase(it);
                return;
            }
        }
        cout << "Hairstylist not found" << endl;
    }

    void updateHairstylist(string name, string newSpeciality) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.name == name) {
                hairstylist.speciality = newSpeciality;
                return;
            }
        }
        cout << "Hairstylist not found" << endl;
    }

    void searchHairstylist(string name) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.name == name) {
                cout << "Hairstylist Name: " << hairstylist.name << ", Speciality: " << hairstylist.speciality << endl;
                return;
            }
        }
        cout << "Hairstylist not found" << endl;
    }

    void displayHairstylists() {
        cout << "Hairstylists List:" << endl;
        for (auto& hairstylist : hairstylists) {
            cout << "Name: " << hairstylist.name << ", Speciality: " << hairstylist.speciality << endl;
        }
    }
};

int main() {
    Salon salon;

    salon.addCustomer("Alice", "123-456-7890");
    salon.addCustomer("Bob", "987-654-3210");

    salon.addHairstylist("Charlie", "Curly Cuts");
    salon.addHairstylist("David", "Straight Styles");

    cout << "Initial data display:" << endl;
    salon.displayCustomers();
    salon.displayHairstylists();

    cout << endl;
    cout << "Updating phone for Alice and speciality for Charlie:" << endl;
    salon.updateCustomer("Alice", "111-222-3333");
    salon.updateHairstylist("Charlie", "Buzz Cuts");

    salon.displayCustomers();
    salon.displayHairstylists();

    cout << endl;
    cout << "Deleting Bob and David:" << endl;
    salon.deleteCustomer("Bob");
    salon.deleteHairstylist("David");

    salon.displayCustomers();
    salon.displayHairstylists();

    return 0;
}