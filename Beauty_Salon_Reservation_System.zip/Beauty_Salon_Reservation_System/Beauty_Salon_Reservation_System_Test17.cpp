#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Person {
public:
    string name;
    string contact;
    Person(const string& n, const string& c) : name(n), contact(c) {}
};

class Customer : public Person {
public:
    Customer(const string& n, const string& c) : Person(n, c) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(const string& n, const string& c) : Person(n, c) {}
};

class Salon {
    vector<Customer> customers;
    vector<Hairstylist> hairstylists;

    template<typename T>
    typename vector<T>::iterator findPerson(vector<T>& people, const string& name) {
        for(auto it = people.begin(); it != people.end(); ++it) {
            if(it->name == name) return it;
        }
        return people.end();
    }

public:
    void addCustomer(const string& name, const string& contact) {
        customers.emplace_back(name, contact);
    }

    void deleteCustomer(const string& name) {
        auto it = findPerson(customers, name);
        if(it != customers.end()) customers.erase(it);
    }

    void updateCustomer(const string& currentName, const string& newName, const string& newContact) {
        auto it = findPerson(customers, currentName);
        if(it != customers.end()) {
            it->name = newName;
            it->contact = newContact;
        }
    }

    void searchCustomer(const string& name) {
        auto it = findPerson(customers, name);
        if(it != customers.end()) {
            cout << "Customer found: " << it->name << ", Contact: " << it->contact << endl;
        } else {
            cout << "Customer not found." << endl;
        }
    }

    void displayCustomers() {
        cout << "Customers:" << endl;
        for(const auto& customer : customers) {
            cout << "Name: " << customer.name << ", Contact: " << customer.contact << endl;
        }
    }

    void addHairstylist(const string& name, const string& contact) {
        hairstylists.emplace_back(name, contact);
    }

    void deleteHairstylist(const string& name) {
        auto it = findPerson(hairstylists, name);
        if(it != hairstylists.end()) hairstylists.erase(it);
    }

    void updateHairstylist(const string& currentName, const string& newName, const string& newContact) {
        auto it = findPerson(hairstylists, currentName);
        if(it != hairstylists.end()) {
            it->name = newName;
            it->contact = newContact;
        }
    }

    void searchHairstylist(const string& name) {
        auto it = findPerson(hairstylists, name);
        if(it != hairstylists.end()) {
            cout << "Hairstylist found: " << it->name << ", Contact: " << it->contact << endl;
        } else {
            cout << "Hairstylist not found." << endl;
        }
    }

    void displayHairstylists() {
        cout << "Hairstylists:" << endl;
        for(const auto& hairstylist : hairstylists) {
            cout << "Name: " << hairstylist.name << ", Contact: " << hairstylist.contact << endl;
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("John Doe", "123-456-7890");
    salon.addHairstylist("Jane Smith", "098-765-4321");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.searchCustomer("John Doe");
    salon.updateCustomer("John Doe", "Johnny Doe", "222-333-4444");
    salon.displayCustomers();
    salon.deleteCustomer("Johnny Doe");
    salon.displayCustomers();
    return 0;
}