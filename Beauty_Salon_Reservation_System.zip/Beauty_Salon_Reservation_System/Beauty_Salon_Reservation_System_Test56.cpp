#include <iostream>
#include <string>
#include <vector>

struct Person {
    std::string name;
    std::string phone;
};

class SalonReservationSystem {
    std::vector<Person> customers;
    std::vector<Person> hairstylists;
public:
    void addCustomer(const std::string& name, const std::string& phone) {
        customers.push_back({name, phone});
    }

    void addHairstylist(const std::string& name, const std::string& phone) {
        hairstylists.push_back({name, phone});
    }

    void deleteCustomer(const std::string& name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                return;
            }
        }
    }

    void deleteHairstylist(const std::string& name) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->name == name) {
                hairstylists.erase(it);
                return;
            }
        }
    }

    void updateCustomer(const std::string& name, const std::string& newName, const std::string& newPhone) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                customer.name = newName;
                customer.phone = newPhone;
                return;
            }
        }
    }

    void updateHairstylist(const std::string& name, const std::string& newName, const std::string& newPhone) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.name == name) {
                hairstylist.name = newName;
                hairstylist.phone = newPhone;
                return;
            }
        }
    }

    void searchCustomer(const std::string& name) {
        for (const auto& customer : customers) {
            if (customer.name == name) {
                std::cout << "Customer found: " << customer.name << ", Phone: " << customer.phone << "\n";
                return;
            }
        }
        std::cout << "Customer not found\n";
    }

    void searchHairstylist(const std::string& name) {
        for (const auto& hairstylist : hairstylists) {
            if (hairstylist.name == name) {
                std::cout << "Hairstylist found: " << hairstylist.name << ", Phone: " << hairstylist.phone << "\n";
                return;
            }
        }
        std::cout << "Hairstylist not found\n";
    }

    void displayCustomers() {
        std::cout << "Customers List:\n";
        for (const auto& customer : customers) {
            std::cout << "Name: " << customer.name << ", Phone: " << customer.phone << "\n";
        }
    }

    void displayHairstylists() {
        std::cout << "Hairstylists List:\n";
        for (const auto& hairstylist : hairstylists) {
            std::cout << "Name: " << hairstylist.name << ", Phone: " << hairstylist.phone << "\n";
        }
    }
};

int main() {
    SalonReservationSystem srs;
    srs.addCustomer("Alice", "123456789");
    srs.addHairstylist("Bob", "987654321");
    srs.displayCustomers();
    srs.displayHairstylists();
    srs.searchCustomer("Alice");
    srs.searchHairstylist("Bob");
    srs.updateCustomer("Alice", "Alice Johnson", "123450987");
    srs.updateHairstylist("Bob", "Bob Smith", "987650123");
    srs.displayCustomers();
    srs.displayHairstylists();
    srs.deleteCustomer("Alice Johnson");
    srs.deleteHairstylist("Bob Smith");
    srs.displayCustomers();
    srs.displayHairstylists();
    return 0;
}