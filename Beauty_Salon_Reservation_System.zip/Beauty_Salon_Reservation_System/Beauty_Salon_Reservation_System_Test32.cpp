#include <iostream>
#include <string>

class Person {
public:
    std::string name;
    std::string phone;
    Person(std::string name, std::string phone) : name(name), phone(phone) {}
};

class Customer : public Person {
public:
    Customer(std::string name, std::string phone) : Person(name, phone) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(std::string name, std::string phone) : Person(name, phone) {}
};

template <typename T>
class List {
    struct Node {
        T data;
        Node* next;
        Node(T data) : data(data), next(nullptr) {}
    };
    Node* head;
public:
    List() : head(nullptr) {}
    
    void add(T data) {
        Node* newNode = new Node(data);
        if (!head) head = newNode;
        else {
            Node* temp = head;
            while (temp->next) temp = temp->next;
            temp->next = newNode;
        }
    }

    void remove(std::string name) {
        if (!head) return;
        if (head->data.name == name) {
            Node* temp = head;
            head = head->next;
            delete temp;
            return;
        }
        Node* current = head;
        while (current->next && current->next->data.name != name)
            current = current->next;
        if (current->next) {
            Node* temp = current->next;
            current->next = current->next->next;
            delete temp;
        }
    }
    
    void update(std::string name, std::string newName, std::string newPhone) {
        Node* current = head;
        while (current) {
            if (current->data.name == name) {
                current->data.name = newName;
                current->data.phone = newPhone;
                return;
            }
            current = current->next;
        }
    }

    T* search(std::string name) {
        Node* current = head;
        while (current) {
            if (current->data.name == name)
                return &current->data;
            current = current->next;
        }
        return nullptr;
    }

    void display() {
        Node* current = head;
        while (current) {
            std::cout << "Name: " << current->data.name << ", Phone: " << current->data.phone << "\n";
            current = current->next;
        }
    }
};

int main() {
    List<Customer> customers;
    List<Hairstylist> hairstylists;

    customers.add(Customer("Alice", "123456789"));
    customers.add(Customer("Bob", "987654321"));
    hairstylists.add(Hairstylist("Charlie", "555555555"));
    hairstylists.add(Hairstylist("Daisy", "444444444"));

    customers.update("Alice", "Alice Smith", "111111111");
    hairstylists.remove("Daisy");

    std::cout << "Customers:\n";
    customers.display();
    std::cout << "Hairstylists:\n";
    hairstylists.display();

    Customer* found = customers.search("Alice Smith");
    if (found) {
        std::cout << "Found Customer: " << found->name << " - " << found->phone << "\n";
    }

    return 0;
}