#include <iostream>
#include <string>
using namespace std;

const int MAX_CUSTOMERS = 100;
const int MAX_HAIRSTYLISTS = 10;

struct Customer {
    int id;
    string name;
    string phone;
};

struct Hairstylist {
    int id;
    string name;
    string specialty;
};

Customer customers[MAX_CUSTOMERS];
Hairstylist hairstylists[MAX_HAIRSTYLISTS];

int customerCount = 0;
int hairstylistCount = 0;

void addCustomer(int id, string name, string phone) {
    if (customerCount < MAX_CUSTOMERS) {
        customers[customerCount++] = {id, name, phone};
    }
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; j++) {
                customers[j] = customers[j + 1];
            }
            customerCount--;
            break;
        }
    }
}

void updateCustomer(int id, string name, string phone) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            customers[i].name = name;
            customers[i].phone = phone;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; i++) {
        cout << "ID: " << customers[i].id << ", Name: " << customers[i].name 
             << ", Phone: " << customers[i].phone << endl;
    }
}

void addHairstylist(int id, string name, string specialty) {
    if (hairstylistCount < MAX_HAIRSTYLISTS) {
        hairstylists[hairstylistCount++] = {id, name, specialty};
    }
}

void deleteHairstylist(int id) {
    for (int i = 0; i < hairstylistCount; i++) {
        if (hairstylists[i].id == id) {
            for (int j = i; j < hairstylistCount - 1; j++) {
                hairstylists[j] = hairstylists[j + 1];
            }
            hairstylistCount--;
            break;
        }
    }
}

void updateHairstylist(int id, string name, string specialty) {
    for (int i = 0; i < hairstylistCount; i++) {
        if (hairstylists[i].id == id) {
            hairstylists[i].name = name;
            hairstylists[i].specialty = specialty;
            break;
        }
    }
}

Hairstylist* searchHairstylist(int id) {
    for (int i = 0; i < hairstylistCount; i++) {
        if (hairstylists[i].id == id) {
            return &hairstylists[i];
        }
    }
    return nullptr;
}

void displayHairstylists() {
    for (int i = 0; i < hairstylistCount; i++) {
        cout << "ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name 
             << ", Specialty: " << hairstylists[i].specialty << endl;
    }
}

int main() {
    addCustomer(1, "Alice", "123-456-7890");
    addCustomer(2, "Bob", "098-765-4321");
    addHairstylist(1, "Charlie", "Coloring");
    addHairstylist(2, "David", "Cutting");

    displayCustomers();
    displayHairstylists();

    updateCustomer(1, "Alice A.", "111-222-3333");
    displayCustomers();

    deleteCustomer(2);
    displayCustomers();

    updateHairstylist(1, "Charlie C.", "Styling");
    displayHairstylists();

    deleteHairstylist(2);
    displayHairstylists();

    return 0;
}