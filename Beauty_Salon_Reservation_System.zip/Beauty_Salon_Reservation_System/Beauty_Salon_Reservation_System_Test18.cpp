#include <iostream>
#include <string>
using namespace std;

struct Person {
    string name;
    string contact;
};

struct Node {
    Person data;
    Node* next;
};

class BeautySalon {
    Node* customers;
    Node* stylists;
public:
    BeautySalon() : customers(nullptr), stylists(nullptr) {}

    void addCustomer(string name, string contact) {
        Node* newNode = new Node{{name, contact}, customers};
        customers = newNode;
    }

    void deleteCustomer(string name) {
        Node* curr = customers;
        Node* prev = nullptr;
        while (curr != nullptr && curr->data.name != name) {
            prev = curr;
            curr = curr->next;
        }
        if (curr != nullptr) {
            if (prev != nullptr) {
                prev->next = curr->next;
            } else {
                customers = curr->next;
            }
            delete curr;
        }
    }

    void updateCustomer(string oldName, string newName, string newContact) {
        Node* curr = customers;
        while (curr != nullptr && curr->data.name != oldName) {
            curr = curr->next;
        }
        if (curr != nullptr) {
            curr->data.name = newName;
            curr->data.contact = newContact;
        }
    }

    Person* searchCustomer(string name) {
        Node* curr = customers;
        while (curr != nullptr && curr->data.name != name) {
            curr = curr->next;
        }
        if (curr != nullptr) {
            return &curr->data;
        }
        return nullptr;
    }

    void displayCustomers() {
        Node* curr = customers;
        while (curr != nullptr) {
            cout << "Name: " << curr->data.name << ", Contact: " << curr->data.contact << endl;
            curr = curr->next;
        }
    }

    void addStylist(string name, string contact) {
        Node* newNode = new Node{{name, contact}, stylists};
        stylists = newNode;
    }

    void deleteStylist(string name) {
        Node* curr = stylists;
        Node* prev = nullptr;
        while (curr != nullptr && curr->data.name != name) {
            prev = curr;
            curr = curr->next;
        }
        if (curr != nullptr) {
            if (prev != nullptr) {
                prev->next = curr->next;
            } else {
                stylists = curr->next;
            }
            delete curr;
        }
    }

    void updateStylist(string oldName, string newName, string newContact) {
        Node* curr = stylists;
        while (curr != nullptr && curr->data.name != oldName) {
            curr = curr->next;
        }
        if (curr != nullptr) {
            curr->data.name = newName;
            curr->data.contact = newContact;
        }
    }

    Person* searchStylist(string name) {
        Node* curr = stylists;
        while (curr != nullptr && curr->data.name != name) {
            curr = curr->next;
        }
        if (curr != nullptr) {
            return &curr->data;
        }
        return nullptr;
    }

    void displayStylists() {
        Node* curr = stylists;
        while (curr != nullptr) {
            cout << "Name: " << curr->data.name << ", Contact: " << curr->data.contact << endl;
            curr = curr->next;
        }
    }

    ~BeautySalon() {
        while (customers != nullptr) {
            Node* temp = customers;
            customers = customers->next;
            delete temp;
        }
        while (stylists != nullptr) {
            Node* temp = stylists;
            stylists = stylists->next;
            delete temp;
        }
    }
};

int main() {
    BeautySalon salon;
    salon.addCustomer("Alice", "123-456-7890");
    salon.addStylist("Bob", "987-654-3210");
    salon.displayCustomers();
    salon.displayStylists();
    salon.updateCustomer("Alice", "Alice Smith", "999-888-7777");
    salon.displayCustomers();
    salon.searchStylist("Bob");
    salon.deleteCustomer("Alice Smith");
    salon.displayCustomers();
    return 0;
}