#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    std::string contact;

    Person(std::string n, std::string c) : name(n), contact(c) {}
};

class Customer : public Person {
public:
    Customer(std::string n, std::string c) : Person(n, c) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(std::string n, std::string c) : Person(n, c) {}
};

class Salon {
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

public:
    void addCustomer(const std::string &name, const std::string &contact) {
        customers.push_back(Customer(name, contact));
    }
    
    void deleteCustomer(const std::string &name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(const std::string &name, const std::string &newContact) {
        for (auto &customer : customers) {
            if (customer.name == name) {
                customer.contact = newContact;
                break;
            }
        }
    }
    
    void searchCustomer(const std::string &name) {
        for (const auto &customer : customers) {
            if (customer.name == name) {
                std::cout << "Customer found: " << customer.name << ", " << customer.contact << std::endl;
                return;
            }
        }
        std::cout << "Customer not found\n";
    }
    
    void displayCustomers() {
        std::cout << "Customers List:\n";
        for (const auto &customer : customers) {
            std::cout << customer.name << ", " << customer.contact << std::endl;
        }
    }
    
    void addHairstylist(const std::string &name, const std::string &contact) {
        hairstylists.push_back(Hairstylist(name, contact));
    }
    
    void deleteHairstylist(const std::string &name) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->name == name) {
                hairstylists.erase(it);
                break;
            }
        }
    }
    
    void updateHairstylist(const std::string &name, const std::string &newContact) {
        for (auto &hairstylist : hairstylists) {
            if (hairstylist.name == name) {
                hairstylist.contact = newContact;
                break;
            }
        }
    }
    
    void searchHairstylist(const std::string &name) {
        for (const auto &hairstylist : hairstylists) {
            if (hairstylist.name == name) {
                std::cout << "Hairstylist found: " << hairstylist.name << ", " << hairstylist.contact << std::endl;
                return;
            }
        }
        std::cout << "Hairstylist not found\n";
    }
    
    void displayHairstylists() {
        std::cout << "Hairstylists List:\n";
        for (const auto &hairstylist : hairstylists) {
            std::cout << hairstylist.name << ", " << hairstylist.contact << std::endl;
        }
    }
};

int main() {
    Salon salon;
    
    salon.addCustomer("Alice", "123-456");
    salon.addCustomer("Bob", "987-654");

    salon.addHairstylist("Charlie", "111-222");
    salon.addHairstylist("David", "333-444");

    salon.displayCustomers();
    salon.displayHairstylists();
    
    salon.searchCustomer("Alice");
    salon.searchHairstylist("Charlie");
    
    salon.updateCustomer("Alice", "555-555");
    salon.updateHairstylist("David", "444-333");
    
    salon.displayCustomers();
    salon.displayHairstylists();
    
    salon.deleteCustomer("Bob");
    salon.deleteHairstylist("Charlie");

    salon.displayCustomers();
    salon.displayHairstylists();

    return 0;
}