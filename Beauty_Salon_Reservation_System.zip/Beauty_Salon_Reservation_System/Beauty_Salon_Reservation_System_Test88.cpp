#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    std::string contact;

    Person(const std::string &n, const std::string &c) : name(n), contact(c) {}
};

class Customer : public Person {
public:
    Customer(const std::string &n, const std::string &c) : Person(n, c) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(const std::string &n, const std::string &c) : Person(n, c) {}
};

class Salon {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

    int findCustomerIndex(const std::string& name) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].name == name) return i;
        }
        return -1;
    }

    int findHairstylistIndex(const std::string& name) {
        for (size_t i = 0; i < hairstylists.size(); ++i) {
            if (hairstylists[i].name == name) return i;
        }
        return -1;
    }

public:
    void addCustomer(const std::string &name, const std::string &contact) {
        customers.emplace_back(name, contact);
    }

    void deleteCustomer(const std::string &name) {
        int index = findCustomerIndex(name);
        if (index != -1) customers.erase(customers.begin() + index);
    }

    void updateCustomer(const std::string &name, const std::string &newContact) {
        int index = findCustomerIndex(name);
        if (index != -1) customers[index].contact = newContact;
    }

    void searchCustomer(const std::string &name) {
        int index = findCustomerIndex(name);
        if (index != -1) {
            std::cout << "Customer found: " << customers[index].name << ", " << customers[index].contact << "\n";
        } else {
            std::cout << "Customer not found\n";
        }
    }

    void displayCustomers() {
        std::cout << "Customers List:\n";
        for (const auto &customer : customers) {
            std::cout << "Name: " << customer.name << ", Contact: " << customer.contact << "\n";
        }
    }

    void addHairstylist(const std::string &name, const std::string &contact) {
        hairstylists.emplace_back(name, contact);
    }

    void deleteHairstylist(const std::string &name) {
        int index = findHairstylistIndex(name);
        if (index != -1) hairstylists.erase(hairstylists.begin() + index);
    }

    void updateHairstylist(const std::string &name, const std::string &newContact) {
        int index = findHairstylistIndex(name);
        if (index != -1) hairstylists[index].contact = newContact;
    }

    void searchHairstylist(const std::string &name) {
        int index = findHairstylistIndex(name);
        if (index != -1) {
            std::cout << "Hairstylist found: " << hairstylists[index].name << ", " << hairstylists[index].contact << "\n";
        } else {
            std::cout << "Hairstylist not found\n";
        }
    }

    void displayHairstylists() {
        std::cout << "Hairstylists List:\n";
        for (const auto &hairstylist : hairstylists) {
            std::cout << "Name: " << hairstylist.name << ", Contact: " << hairstylist.contact << "\n";
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("Alice", "123456789");
    salon.addCustomer("Bob", "987654321");
    salon.addHairstylist("John", "1122334455");
    salon.addHairstylist("Jane", "5544332211");

    salon.displayCustomers();
    salon.searchCustomer("Alice");
    salon.updateCustomer("Alice", "111222333");
    salon.displayCustomers();

    salon.displayHairstylists();
    salon.searchHairstylist("John");
    salon.updateHairstylist("John", "9988776655");
    salon.displayHairstylists();

    salon.deleteCustomer("Bob");
    salon.displayCustomers();

    salon.deleteHairstylist("Jane");
    salon.displayHairstylists();

    return 0;
}