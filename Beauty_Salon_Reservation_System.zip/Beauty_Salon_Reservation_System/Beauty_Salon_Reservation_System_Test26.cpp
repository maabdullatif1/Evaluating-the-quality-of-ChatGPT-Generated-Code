#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    std::string phone;
    Person(std::string n, std::string p) : name(n), phone(p) {}
};

class Customer : public Person {
public:
    Customer(std::string n, std::string p) : Person(n, p) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(std::string n, std::string p) : Person(n, p) {}
};

class Salon {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;
public:
    void addCustomer(std::string name, std::string phone) {
        customers.push_back(Customer(name, phone));
    }

    void deleteCustomer(std::string name) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].name == name) {
                customers.erase(customers.begin() + i);
                break;
            }
        }
    }

    void updateCustomer(std::string oldName, std::string newName, std::string phone) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].name == oldName) {
                customers[i].name = newName;
                customers[i].phone = phone;
                break;
            }
        }
    }

    Customer* searchCustomer(std::string name) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].name == name) {
                return &customers[i];
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Name: " << customer.name << ", Phone: " << customer.phone << std::endl;
        }
    }

    void addHairstylist(std::string name, std::string phone) {
        hairstylists.push_back(Hairstylist(name, phone));
    }

    void deleteHairstylist(std::string name) {
        for (size_t i = 0; i < hairstylists.size(); ++i) {
            if (hairstylists[i].name == name) {
                hairstylists.erase(hairstylists.begin() + i);
                break;
            }
        }
    }

    void updateHairstylist(std::string oldName, std::string newName, std::string phone) {
        for (size_t i = 0; i < hairstylists.size(); ++i) {
            if (hairstylists[i].name == oldName) {
                hairstylists[i].name = newName;
                hairstylists[i].phone = phone;
                break;
            }
        }
    }

    Hairstylist* searchHairstylist(std::string name) {
        for (size_t i = 0; i < hairstylists.size(); ++i) {
            if (hairstylists[i].name == name) {
                return &hairstylists[i];
            }
        }
        return nullptr;
    }

    void displayHairstylists() {
        for (const auto& stylist : hairstylists) {
            std::cout << "Name: " << stylist.name << ", Phone: " << stylist.phone << std::endl;
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("Alice", "123456789");
    salon.addHairstylist("Bob", "987654321");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.updateCustomer("Alice", "Alice Smith", "111111111");
    salon.updateHairstylist("Bob", "Bob Brown", "222222222");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.deleteCustomer("Alice Smith");
    salon.deleteHairstylist("Bob Brown");
    salon.displayCustomers();
    salon.displayHairstylists();
    return 0;
}