#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string phone;
};

struct Hairstylist {
    int id;
    std::string name;
    std::string specialization;
};

class Salon {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;
    int nextCustomerId = 1;
    int nextHairstylistId = 1;

public:
    void addCustomer(const std::string& name, const std::string& phone) {
        customers.push_back({nextCustomerId++, name, phone});
    }
    
    void deleteCustomer(int id) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) {
                customers.erase(customers.begin() + i);
                return;
            }
        }
    }
    
    void updateCustomer(int id, const std::string& name, const std::string& phone) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phone = phone;
                return;
            }
        }
    }
    
    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }
    
    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << std::endl;
        }
    }
    
    void addHairstylist(const std::string& name, const std::string& specialization) {
        hairstylists.push_back({nextHairstylistId++, name, specialization});
    }
    
    void deleteHairstylist(int id) {
        for (size_t i = 0; i < hairstylists.size(); ++i) {
            if (hairstylists[i].id == id) {
                hairstylists.erase(hairstylists.begin() + i);
                return;
            }
        }
    }
    
    void updateHairstylist(int id, const std::string& name, const std::string& specialization) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                hairstylist.name = name;
                hairstylist.specialization = specialization;
                return;
            }
        }
    }
    
    Hairstylist* searchHairstylist(int id) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                return &hairstylist;
            }
        }
        return nullptr;
    }
    
    void displayHairstylists() {
        for (const auto& hairstylist : hairstylists) {
            std::cout << "ID: " << hairstylist.id << ", Name: " << hairstylist.name << ", Specialization: " << hairstylist.specialization << std::endl;
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("Alice Smith", "123-456-7890");
    salon.addCustomer("Bob Johnson", "987-654-3210");
    salon.addHairstylist("Charlie Brown", "Cuts and Styles");
    salon.addHairstylist("Diana Prince", "Coloring");

    salon.displayCustomers();
    salon.displayHairstylists();

    return 0;
}