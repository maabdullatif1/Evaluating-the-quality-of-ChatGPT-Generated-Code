#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    std::string phone;
    int id;
};

class Customer : public Person {
public:
    Customer(int id, std::string name, std::string phone) {
        this->id = id;
        this->name = name;
        this->phone = phone;
    }
};

class Hairstylist : public Person {
public:
    Hairstylist(int id, std::string name, std::string phone) {
        this->id = id;
        this->name = name;
        this->phone = phone;
    }
};

template<typename T>
class RecordSystem {
private:
    std::vector<T> records;

public:
    void addRecord(T record) {
        records.push_back(record);
    }

    void deleteRecord(int id) {
        for (auto it = records.begin(); it != records.end(); ++it) {
            if (it->id == id) {
                records.erase(it);
                return;
            }
        }
    }

    void updateRecord(int id, T newRecord) {
        for (auto &record : records) {
            if (record.id == id) {
                record = newRecord;
                return;
            }
        }
    }

    T* searchRecord(int id) {
        for (auto &record : records) {
            if (record.id == id) {
                return &record;
            }
        }
        return nullptr;
    }

    void displayRecords() {
        for (const auto &record : records) {
            std::cout << "ID: " << record.id << "\tName: " << record.name << "\tPhone: " << record.phone << "\n";
        }
    }
};

int main() {
    RecordSystem<Customer> customerSystem;
    RecordSystem<Hairstylist> hairstylistSystem;

    customerSystem.addRecord(Customer(1, "Alice", "123456789"));
    customerSystem.addRecord(Customer(2, "Bob", "987654321"));

    hairstylistSystem.addRecord(Hairstylist(1, "Charlie", "555666777"));
    hairstylistSystem.addRecord(Hairstylist(2, "Dana", "888999000"));

    customerSystem.displayRecords();
    hairstylistSystem.displayRecords();

    return 0;
}