#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    int id;
    std::string name;
    Person(int id, const std::string& name) : id(id), name(name) {}
};

class BeautySalon {
private:
    std::vector<Person> customers;
    std::vector<Person> hairstylists;

    int findPerson(std::vector<Person>& list, int id) {
        for (int i = 0; i < list.size(); ++i) {
            if (list[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addCustomer(int id, const std::string& name) {
        customers.push_back(Person(id, name));
    }

    void deleteCustomer(int id) {
        int index = findPerson(customers, id);
        if (index != -1) {
            customers.erase(customers.begin() + index);
        }
    }

    void updateCustomer(int id, const std::string& newName) {
        int index = findPerson(customers, id);
        if (index != -1) {
            customers[index].name = newName;
        }
    }

    Person* searchCustomer(int id) {
        int index = findPerson(customers, id);
        return index != -1 ? &customers[index] : nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << "\n";
        }
    }

    void addHairstylist(int id, const std::string& name) {
        hairstylists.push_back(Person(id, name));
    }

    void deleteHairstylist(int id) {
        int index = findPerson(hairstylists, id);
        if (index != -1) {
            hairstylists.erase(hairstylists.begin() + index);
        }
    }

    void updateHairstylist(int id, const std::string& newName) {
        int index = findPerson(hairstylists, id);
        if (index != -1) {
            hairstylists[index].name = newName;
        }
    }

    Person* searchHairstylist(int id) {
        int index = findPerson(hairstylists, id);
        return index != -1 ? &hairstylists[index] : nullptr;
    }

    void displayHairstylists() {
        for (const auto& stylist : hairstylists) {
            std::cout << "Hairstylist ID: " << stylist.id << ", Name: " << stylist.name << "\n";
        }
    }
};

int main() {
    BeautySalon salon;

    salon.addCustomer(1, "Alice");
    salon.addCustomer(2, "Bob");
    salon.displayCustomers();
    salon.updateCustomer(1, "Alicia");
    salon.displayCustomers();
    salon.deleteCustomer(2);
    salon.displayCustomers();

    salon.addHairstylist(101, "John");
    salon.addHairstylist(102, "Jane");
    salon.displayHairstylists();
    salon.updateHairstylist(101, "Johnny");
    salon.displayHairstylists();
    salon.deleteHairstylist(102);
    salon.displayHairstylists();

    if (Person* customer = salon.searchCustomer(1)) {
        std::cout << "Found customer ID: " << customer->id << ", Name: " << customer->name << "\n";
    }

    if (Person* stylist = salon.searchHairstylist(101)) {
        std::cout << "Found hairstylist ID: " << stylist->id << ", Name: " << stylist->name << "\n";
    }

    return 0;
}