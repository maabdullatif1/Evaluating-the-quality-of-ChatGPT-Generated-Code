#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct Hairstylist {
    int id;
    string name;
    string specialization;
};

const int MAX_CUSTOMERS = 100;
const int MAX_HAIRSTYLISTS = 50;

Customer customers[MAX_CUSTOMERS];
Hairstylist hairstylists[MAX_HAIRSTYLISTS];
int customerCount = 0;
int hairstylistCount = 0;

void addCustomer(int id, const string& name, const string& phone) {
    if (customerCount < MAX_CUSTOMERS) {
        customers[customerCount++] = {id, name, phone};
    }
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            customers[i] = customers[--customerCount];
            break;
        }
    }
}

void updateCustomer(int id, const string& name, const string& phone) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            customers[i].name = name;
            customers[i].phone = phone;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; ++i) {
        cout << "ID: " << customers[i].id << " Name: " << customers[i].name << " Phone: " << customers[i].phone << endl;
    }
}

void addHairstylist(int id, const string& name, const string& specialization) {
    if (hairstylistCount < MAX_HAIRSTYLISTS) {
        hairstylists[hairstylistCount++] = {id, name, specialization};
    }
}

void deleteHairstylist(int id) {
    for (int i = 0; i < hairstylistCount; ++i) {
        if (hairstylists[i].id == id) {
            hairstylists[i] = hairstylists[--hairstylistCount];
            break;
        }
    }
}

void updateHairstylist(int id, const string& name, const string& specialization) {
    for (int i = 0; i < hairstylistCount; ++i) {
        if (hairstylists[i].id == id) {
            hairstylists[i].name = name;
            hairstylists[i].specialization = specialization;
            break;
        }
    }
}

Hairstylist* searchHairstylist(int id) {
    for (int i = 0; i < hairstylistCount; ++i) {
        if (hairstylists[i].id == id) {
            return &hairstylists[i];
        }
    }
    return nullptr;
}

void displayHairstylists() {
    for (int i = 0; i < hairstylistCount; ++i) {
        cout << "ID: " << hairstylists[i].id << " Name: " << hairstylists[i].name << " Specialization: " << hairstylists[i].specialization << endl;
    }
}

int main() {
    addCustomer(1, "Alice", "123456789");
    addCustomer(2, "Bob", "987654321");
    addHairstylist(1, "Charlie", "Colorist");
    addHairstylist(2, "Dave", "Cutter");
    displayCustomers();
    displayHairstylists();

    Customer* c = searchCustomer(1);
    if (c != nullptr) {
        cout << "Found customer: " << c->name << endl;
    }

    Hairstylist* h = searchHairstylist(2);
    if (h != nullptr) {
        cout << "Found hairstylist: " << h->name << endl;
    }

    updateCustomer(1, "Alice Smith", "111222333");
    updateHairstylist(2, "Dave Brown", "Stylist");
    displayCustomers();
    displayHairstylists();

    deleteCustomer(2);
    deleteHairstylist(1);
    displayCustomers();
    displayHairstylists();

    return 0;
}