#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string phoneNumber;
};

struct Hairstylist {
    int id;
    string name;
    string specialty;
};

Customer customers[100];
Hairstylist hairstylists[100];
int customerCount = 0;
int hairstylistCount = 0;

void addCustomer(int id, string name, string phoneNumber) {
    customers[customerCount].id = id;
    customers[customerCount].name = name;
    customers[customerCount].phoneNumber = phoneNumber;
    customerCount++;
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; j++) {
                customers[j] = customers[j + 1];
            }
            customerCount--;
            break;
        }
    }
}

void updateCustomer(int id, string name, string phoneNumber) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            customers[i].name = name;
            customers[i].phoneNumber = phoneNumber;
            break;
        }
    }
}

int searchCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            return i;
        }
    }
    return -1;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; i++) {
        cout << "ID: " << customers[i].id << ", Name: " << customers[i].name 
             << ", Phone: " << customers[i].phoneNumber << endl;
    }
}

void addHairstylist(int id, string name, string specialty) {
    hairstylists[hairstylistCount].id = id;
    hairstylists[hairstylistCount].name = name;
    hairstylists[hairstylistCount].specialty = specialty;
    hairstylistCount++;
}

void deleteHairstylist(int id) {
    for (int i = 0; i < hairstylistCount; i++) {
        if (hairstylists[i].id == id) {
            for (int j = i; j < hairstylistCount - 1; j++) {
                hairstylists[j] = hairstylists[j + 1];
            }
            hairstylistCount--;
            break;
        }
    }
}

void updateHairstylist(int id, string name, string specialty) {
    for (int i = 0; i < hairstylistCount; i++) {
        if (hairstylists[i].id == id) {
            hairstylists[i].name = name;
            hairstylists[i].specialty = specialty;
            break;
        }
    }
}

int searchHairstylist(int id) {
    for (int i = 0; i < hairstylistCount; i++) {
        if (hairstylists[i].id == id) {
            return i;
        }
    }
    return -1;
}

void displayHairstylists() {
    for (int i = 0; i < hairstylistCount; i++) {
        cout << "ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name 
             << ", Specialty: " << hairstylists[i].specialty << endl;
    }
}

int main() {
    addCustomer(1, "Alice", "1234567890");
    addCustomer(2, "Bob", "0987654321");
    displayCustomers();
    updateCustomer(1, "Alice Smith", "1122334455");
    displayCustomers();
    deleteCustomer(2);
    displayCustomers();
    
    addHairstylist(1, "Charlie", "Curly Hair");
    addHairstylist(2, "David", "Straight Hair");
    displayHairstylists();
    updateHairstylist(1, "Charlie Brown", "Wave Hairstyles");
    displayHairstylists();
    deleteHairstylist(2);
    displayHairstylists();
    
    return 0;
}