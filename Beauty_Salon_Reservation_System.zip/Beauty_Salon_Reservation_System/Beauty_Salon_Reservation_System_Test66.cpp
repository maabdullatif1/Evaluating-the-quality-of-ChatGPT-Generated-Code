#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string service;
};

struct Hairstylist {
    int id;
    string name;
    string specialty;
};

const int MAX_CUSTOMERS = 100;
const int MAX_HAIRSTYLISTS = 10;
Customer customers[MAX_CUSTOMERS];
Hairstylist hairstylists[MAX_HAIRSTYLISTS];
int customerCount = 0;
int hairstylistCount = 0;

void addCustomer() {
    if (customerCount >= MAX_CUSTOMERS) return;
    Customer c;
    cout << "Enter Customer ID: ";
    cin >> c.id;
    cout << "Enter Customer Name: ";
    cin >> c.name;
    cout << "Enter Service: ";
    cin >> c.service;
    customers[customerCount++] = c;
}

void deleteCustomer() {
    int id;
    cout << "Enter Customer ID to delete: ";
    cin >> id;
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            customers[i] = customers[customerCount - 1];
            customerCount--;
            break;
        }
    }
}

void updateCustomer() {
    int id;
    cout << "Enter Customer ID to update: ";
    cin >> id;
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            cout << "Enter new Customer Name: ";
            cin >> customers[i].name;
            cout << "Enter new Service: ";
            cin >> customers[i].service;
            break;
        }
    }
}

void searchCustomer() {
    int id;
    cout << "Enter Customer ID to search: ";
    cin >> id;
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << ", Service: " << customers[i].service << endl;
            break;
        }
    }
}

void displayCustomers() {
    for (int i = 0; i < customerCount; ++i) {
        cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << ", Service: " << customers[i].service << endl;
    }
}

void addHairstylist() {
    if (hairstylistCount >= MAX_HAIRSTYLISTS) return;
    Hairstylist h;
    cout << "Enter Hairstylist ID: ";
    cin >> h.id;
    cout << "Enter Hairstylist Name: ";
    cin >> h.name;
    cout << "Enter Specialty: ";
    cin >> h.specialty;
    hairstylists[hairstylistCount++] = h;
}

void deleteHairstylist() {
    int id;
    cout << "Enter Hairstylist ID to delete: ";
    cin >> id;
    for (int i = 0; i < hairstylistCount; ++i) {
        if (hairstylists[i].id == id) {
            hairstylists[i] = hairstylists[hairstylistCount - 1];
            hairstylistCount--;
            break;
        }
    }
}

void updateHairstylist() {
    int id;
    cout << "Enter Hairstylist ID to update: ";
    cin >> id;
    for (int i = 0; i < hairstylistCount; ++i) {
        if (hairstylists[i].id == id) {
            cout << "Enter new Hairstylist Name: ";
            cin >> hairstylists[i].name;
            cout << "Enter new Specialty: ";
            cin >> hairstylists[i].specialty;
            break;
        }
    }
}

void searchHairstylist() {
    int id;
    cout << "Enter Hairstylist ID to search: ";
    cin >> id;
    for (int i = 0; i < hairstylistCount; ++i) {
        if (hairstylists[i].id == id) {
            cout << "Hairstylist ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name << ", Specialty: " << hairstylists[i].specialty << endl;
            break;
        }
    }
}

void displayHairstylists() {
    for (int i = 0; i < hairstylistCount; ++i) {
        cout << "Hairstylist ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name << ", Specialty: " << hairstylists[i].specialty << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "Menu:\n1. Add Customer\n2. Delete Customer\n3. Update Customer\n4. Search Customer\n5. Display Customers\n6. Add Hairstylist\n7. Delete Hairstylist\n8. Update Hairstylist\n9. Search Hairstylist\n10. Display Hairstylists\n0. Exit" << endl;
        cout << "Enter Choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addCustomer(); break;
            case 2: deleteCustomer(); break;
            case 3: updateCustomer(); break;
            case 4: searchCustomer(); break;
            case 5: displayCustomers(); break;
            case 6: addHairstylist(); break;
            case 7: deleteHairstylist(); break;
            case 8: updateHairstylist(); break;
            case 9: searchHairstylist(); break;
            case 10: displayHairstylists(); break;
        }
    } while (choice != 0);
    return 0;
}