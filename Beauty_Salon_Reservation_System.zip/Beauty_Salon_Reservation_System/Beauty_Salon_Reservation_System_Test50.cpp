#include <iostream>
#include <string>

struct Person {
    std::string name;
    std::string phone;
};

struct Customer : Person {
    int customerID;
};

struct Hairstylist : Person {
    int stylistID;
};

struct Node {
    Customer customer;
    Hairstylist hairstylist;
    Node* next;
};

class Salon {
private:
    Node* head;
    int customerCounter;
    int stylistCounter;

public:
    Salon() : head(nullptr), customerCounter(0), stylistCounter(0) {}

    void addCustomer(std::string name, std::string phone) {
        Node* newNode = new Node();
        newNode->customer.name = name;
        newNode->customer.phone = phone;
        newNode->customer.customerID = ++customerCounter;
        newNode->next = head;
        head = newNode;
    }

    void addHairstylist(std::string name, std::string phone) {
        Node* newNode = new Node();
        newNode->hairstylist.name = name;
        newNode->hairstylist.phone = phone;
        newNode->hairstylist.stylistID = ++stylistCounter;
        newNode->next = head;
        head = newNode;
    }

    void deleteCustomer(int id) {
        Node* temp = head;
        Node* prev = nullptr;
        while (temp != nullptr && temp->customer.customerID != id) {
            prev = temp;
            temp = temp->next;
        }
        if (temp == nullptr) return;
        if (prev == nullptr) head = temp->next;
        else prev->next = temp->next;
        delete temp;
    }

    void deleteHairstylist(int id) {
        Node* temp = head;
        Node* prev = nullptr;
        while (temp != nullptr && temp->hairstylist.stylistID != id) {
            prev = temp;
            temp = temp->next;
        }
        if (temp == nullptr) return;
        if (prev == nullptr) head = temp->next;
        else prev->next = temp->next;
        delete temp;
    }

    void updateCustomer(int id, std::string newName, std::string newPhone) {
        Node* temp = head;
        while (temp != nullptr && temp->customer.customerID != id) {
            temp = temp->next;
        }
        if (temp != nullptr) {
            temp->customer.name = newName;
            temp->customer.phone = newPhone;
        }
    }

    void updateHairstylist(int id, std::string newName, std::string newPhone) {
        Node* temp = head;
        while (temp != nullptr && temp->hairstylist.stylistID != id) {
            temp = temp->next;
        }
        if (temp != nullptr) {
            temp->hairstylist.name = newName;
            temp->hairstylist.phone = newPhone;
        }
    }

    void searchCustomer(int id) {
        Node* temp = head;
        while (temp != nullptr) {
            if (temp->customer.customerID == id) {
                std::cout << "Customer Found: " << temp->customer.name << ", " << temp->customer.phone << std::endl;
                return;
            }
            temp = temp->next;
        }
        std::cout << "Customer not found." << std::endl;
    }

    void searchHairstylist(int id) {
        Node* temp = head;
        while (temp != nullptr) {
            if (temp->hairstylist.stylistID == id) {
                std::cout << "Hairstylist Found: " << temp->hairstylist.name << ", " << temp->hairstylist.phone << std::endl;
                return;
            }
            temp = temp->next;
        }
        std::cout << "Hairstylist not found." << std::endl;
    }

    void displayCustomers() {
        Node* temp = head;
        while (temp != nullptr) {
            if (temp->customer.customerID != 0) {
                std::cout << "Customer ID: " << temp->customer.customerID << ", Name: " << temp->customer.name << ", Phone: " << temp->customer.phone << std::endl;
            }
            temp = temp->next;
        }
    }

    void displayHairstylists() {
        Node* temp = head;
        while (temp != nullptr) {
            if (temp->hairstylist.stylistID != 0) {
                std::cout << "Stylist ID: " << temp->hairstylist.stylistID << ", Name: " << temp->hairstylist.name << ", Phone: " << temp->hairstylist.phone << std::endl;
            }
            temp = temp->next;
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("Alice", "123456789");
    salon.addHairstylist("Bob", "987654321");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.updateCustomer(1, "Alice Smith", "111222333");
    salon.searchCustomer(1);
    salon.deleteCustomer(1);
    salon.displayCustomers();
    return 0;
}