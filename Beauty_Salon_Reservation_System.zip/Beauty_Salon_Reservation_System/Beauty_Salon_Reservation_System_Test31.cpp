#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    std::string phone;
    
    Person(const std::string& n, const std::string& p)
        : name(n), phone(p) {}
};

class Customer : public Person {
public:
    Customer(const std::string& n, const std::string& p)
        : Person(n, p) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(const std::string& n, const std::string& p)
        : Person(n, p) {}
};

class Salon {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;
    
    template<typename T>
    int findIndexByName(const std::vector<T>& list, const std::string& name) {
        for (size_t i = 0; i < list.size(); ++i) {
            if (list[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addCustomer(const std::string& name, const std::string& phone) {
        customers.emplace_back(name, phone);
    }

    void deleteCustomer(const std::string& name) {
        int index = findIndexByName(customers, name);
        if (index != -1) {
            customers.erase(customers.begin() + index);
        }
    }

    void updateCustomer(const std::string& oldName, const std::string& newName, const std::string& newPhone) {
        int index = findIndexByName(customers, oldName);
        if (index != -1) {
            customers[index].name = newName;
            customers[index].phone = newPhone;
        }
    }

    void searchCustomer(const std::string& name) {
        int index = findIndexByName(customers, name);
        if (index != -1) {
            std::cout << "Customer: " << customers[index].name << ", Phone: " << customers[index].phone << "\n";
        } else {
            std::cout << "Customer not found.\n";
        }
    }

    void displayCustomers() {
        std::cout << "Customers List:\n";
        for (const auto& customer : customers) {
            std::cout << "Name: " << customer.name << ", Phone: " << customer.phone << "\n";
        }
    }

    void addHairstylist(const std::string& name, const std::string& phone) {
        hairstylists.emplace_back(name, phone);
    }

    void deleteHairstylist(const std::string& name) {
        int index = findIndexByName(hairstylists, name);
        if (index != -1) {
            hairstylists.erase(hairstylists.begin() + index);
        }
    }

    void updateHairstylist(const std::string& oldName, const std::string& newName, const std::string& newPhone) {
        int index = findIndexByName(hairstylists, oldName);
        if (index != -1) {
            hairstylists[index].name = newName;
            hairstylists[index].phone = newPhone;
        }
    }

    void searchHairstylist(const std::string& name) {
        int index = findIndexByName(hairstylists, name);
        if (index != -1) {
            std::cout << "Hairstylist: " << hairstylists[index].name << ", Phone: " << hairstylists[index].phone << "\n";
        } else {
            std::cout << "Hairstylist not found.\n";
        }
    }

    void displayHairstylists() {
        std::cout << "Hairstylists List:\n";
        for (const auto& hairstylist : hairstylists) {
            std::cout << "Name: " << hairstylist.name << ", Phone: " << hairstylist.phone << "\n";
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("Alice", "123-456");
    salon.addCustomer("Bob", "789-012");
    salon.addHairstylist("Charlie", "345-678");
    salon.addHairstylist("Dave", "901-234");
    
    salon.displayCustomers();
    salon.displayHairstylists();
    
    salon.searchCustomer("Alice");
    salon.searchHairstylist("Charlie");
    
    salon.updateCustomer("Alice", "Alice Cooper", "000-999");
    salon.updateHairstylist("Charlie", "Charles", "555-555");
    
    salon.displayCustomers();
    salon.displayHairstylists();
    
    salon.deleteCustomer("Bob");
    salon.deleteHairstylist("Dave");
    
    salon.displayCustomers();
    salon.displayHairstylists();
    
    return 0;
}