#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    std::string contact;
public:
    Person() {}
    Person(const std::string &n, const std::string &c) : name(n), contact(c) {}
    void setName(const std::string &n) { name = n; }
    void setContact(const std::string &c) { contact = c; }
    std::string getName() const { return name; }
    std::string getContact() const { return contact; }
};

class Customer : public Person {
    std::string customerID;
public:
    Customer() {}
    Customer(const std::string &id, const std::string &n, const std::string &c)
        : Person(n, c), customerID(id) {}
    void setCustomerID(const std::string &id) { customerID = id; }
    std::string getCustomerID() const { return customerID; }
};

class Hairstylist : public Person {
    std::string stylistID;
public:
    Hairstylist() {}
    Hairstylist(const std::string &id, const std::string &n, const std::string &c)
        : Person(n, c), stylistID(id) {}
    void setStylistID(const std::string &id) { stylistID = id; }
    std::string getStylistID() const { return stylistID; }
};

class SalonReservationSystem {
    std::vector<Customer> customers;
    std::vector<Hairstylist> stylists;
public:
    void addCustomer(const Customer &customer) { customers.push_back(customer); }
    void deleteCustomer(const std::string &customerID) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getCustomerID() == customerID) {
                customers.erase(it);
                break;
            }
        }
    }
    void updateCustomer(const std::string &customerID, const std::string &newName, const std::string &newContact) {
        for (auto &customer : customers) {
            if (customer.getCustomerID() == customerID) {
                customer.setName(newName);
                customer.setContact(newContact);
            }
        }
    }
    void displayCustomers() const {
        for (const auto &customer : customers) {
            std::cout << "Customer ID: " << customer.getCustomerID() << ", Name: " << customer.getName()
                      << ", Contact: " << customer.getContact() << std::endl;
        }
    }
    void searchCustomer(const std::string &customerID) const {
        for (const auto &customer : customers) {
            if (customer.getCustomerID() == customerID) {
                std::cout << "Customer ID: " << customer.getCustomerID() << ", Name: " << customer.getName()
                          << ", Contact: " << customer.getContact() << std::endl;
                return;
            }
        }
        std::cout << "Customer not found." << std::endl;
    }
    void addHairstylist(const Hairstylist &stylist) { stylists.push_back(stylist); }
    void deleteHairstylist(const std::string &stylistID) {
        for (auto it = stylists.begin(); it != stylists.end(); ++it) {
            if (it->getStylistID() == stylistID) {
                stylists.erase(it);
                break;
            }
        }
    }
    void updateHairstylist(const std::string &stylistID, const std::string &newName, const std::string &newContact) {
        for (auto &stylist : stylists) {
            if (stylist.getStylistID() == stylistID) {
                stylist.setName(newName);
                stylist.setContact(newContact);
            }
        }
    }
    void displayHairstylists() const {
        for (const auto &stylist : stylists) {
            std::cout << "Stylist ID: " << stylist.getStylistID() << ", Name: " << stylist.getName()
                      << ", Contact: " << stylist.getContact() << std::endl;
        }
    }
    void searchHairstylist(const std::string &stylistID) const {
        for (const auto &stylist : stylists) {
            if (stylist.getStylistID() == stylistID) {
                std::cout << "Stylist ID: " << stylist.getStylistID() << ", Name: " << stylist.getName()
                          << ", Contact: " << stylist.getContact() << std::endl;
                return;
            }
        }
        std::cout << "Hairstylist not found." << std::endl;
    }
};

int main() {
    SalonReservationSystem system;
    system.addCustomer(Customer("C001", "Alice", "123456789"));
    system.addCustomer(Customer("C002", "Bob", "987654321"));
    system.displayCustomers();
    system.searchCustomer("C001");
    system.updateCustomer("C001", "Alice Smith", "111222333");
    system.searchCustomer("C001");
    system.deleteCustomer("C002");
    system.displayCustomers();

    system.addHairstylist(Hairstylist("H001", "John", "456789123"));
    system.addHairstylist(Hairstylist("H002", "Doe", "654321987"));
    system.displayHairstylists();
    system.searchHairstylist("H001");
    system.updateHairstylist("H001", "John Doe", "333444555");
    system.searchHairstylist("H001");
    system.deleteHairstylist("H002");
    system.displayHairstylists();

    return 0;
}