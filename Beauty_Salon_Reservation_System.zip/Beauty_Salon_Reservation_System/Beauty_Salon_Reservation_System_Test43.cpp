#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct Hairstylist {
    int id;
    string name;
    string specialty;
};

Customer customers[100];
Hairstylist hairstylists[100];

int customerCount = 0;
int hairstylistCount = 0;

void addCustomer(int id, string name, string phone) {
    customers[customerCount++] = {id, name, phone};
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; j++) {
                customers[j] = customers[j + 1];
            }
            customerCount--;
            break;
        }
    }
}

void updateCustomer(int id, string name, string phone) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            customers[i].name = name;
            customers[i].phone = phone;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return NULL;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; i++) {
        cout << "ID: " << customers[i].id << ", Name: " << customers[i].name << ", Phone: " << customers[i].phone << endl;
    }
}

void addHairstylist(int id, string name, string specialty) {
    hairstylists[hairstylistCount++] = {id, name, specialty};
}

void deleteHairstylist(int id) {
    for (int i = 0; i < hairstylistCount; i++) {
        if (hairstylists[i].id == id) {
            for (int j = i; j < hairstylistCount - 1; j++) {
                hairstylists[j] = hairstylists[j + 1];
            }
            hairstylistCount--;
            break;
        }
    }
}

void updateHairstylist(int id, string name, string specialty) {
    for (int i = 0; i < hairstylistCount; i++) {
        if (hairstylists[i].id == id) {
            hairstylists[i].name = name;
            hairstylists[i].specialty = specialty;
            break;
        }
    }
}

Hairstylist* searchHairstylist(int id) {
    for (int i = 0; i < hairstylistCount; i++) {
        if (hairstylists[i].id == id) {
            return &hairstylists[i];
        }
    }
    return NULL;
}

void displayHairstylists() {
    for (int i = 0; i < hairstylistCount; i++) {
        cout << "ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name << ", Specialty: " << hairstylists[i].specialty << endl;
    }
}

int main() {
    addCustomer(1, "Alice", "123-456-7890");
    addCustomer(2, "Bob", "987-654-3210");
    displayCustomers();

    addHairstylist(1, "Eve", "Curly");
    addHairstylist(2, "Mallory", "Straight");
    displayHairstylists();

    updateCustomer(1, "Alice Johnson", "111-222-3333");
    updateHairstylist(2, "Mallory Chen", "Coloring");
    displayCustomers();
    displayHairstylists();

    return 0;
}