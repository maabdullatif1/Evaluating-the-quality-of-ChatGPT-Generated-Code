#include <iostream>
#include <vector>
#include <string>

struct Person {
    std::string name;
    std::string contact;
};

struct Customer : public Person {
    std::string appointmentTime;
};

struct Hairstylist : public Person {
    std::string speciality;
};

class Salon {
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;
    
public:
    void addCustomer(const std::string& name, const std::string& contact, const std::string& appointmentTime) {
        Customer customer = {name, contact, appointmentTime};
        customers.push_back(customer);
    }
    
    void deleteCustomer(const std::string& name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(const std::string& name, const std::string& contact, const std::string& appointmentTime) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                customer.contact = contact;
                customer.appointmentTime = appointmentTime;
                break;
            }
        }
    }
    
    Customer* searchCustomer(const std::string& name) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                return &customer;
            }
        }
        return nullptr;
    }
    
    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer Name: " << customer.name 
                      << ", Contact: " << customer.contact 
                      << ", Appointment Time: " << customer.appointmentTime << std::endl;
        }
    }
    
    void addHairstylist(const std::string& name, const std::string& contact, const std::string& speciality) {
        Hairstylist hairstylist = {name, contact, speciality};
        hairstylists.push_back(hairstylist);
    }
    
    void deleteHairstylist(const std::string& name) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->name == name) {
                hairstylists.erase(it);
                break;
            }
        }
    }
    
    void updateHairstylist(const std::string& name, const std::string& contact, const std::string& speciality) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.name == name) {
                hairstylist.contact = contact;
                hairstylist.speciality = speciality;
                break;
            }
        }
    }
    
    Hairstylist* searchHairstylist(const std::string& name) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.name == name) {
                return &hairstylist;
            }
        }
        return nullptr;
    }
    
    void displayHairstylists() {
        for (const auto& hairstylist : hairstylists) {
            std::cout << "Hairstylist Name: " << hairstylist.name 
                      << ", Contact: " << hairstylist.contact 
                      << ", Speciality: " << hairstylist.speciality << std::endl;
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("Alice", "1234567890", "10:00 AM");
    salon.addHairstylist("Bob", "0987654321", "Cuts and Color");
    salon.displayCustomers();
    salon.displayHairstylists();
    return 0;
}