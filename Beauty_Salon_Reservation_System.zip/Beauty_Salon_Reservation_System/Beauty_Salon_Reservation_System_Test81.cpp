#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string contact;
};

struct Hairstylist {
    int id;
    std::string name;
    std::string specialization;
};

class BeautySalon {
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

    int findCustomerIndexById(int id) {
        for (int i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id)
                return i;
        }
        return -1;
    }

    int findHairstylistIndexById(int id) {
        for (int i = 0; i < hairstylists.size(); ++i) {
            if (hairstylists[i].id == id)
                return i;
        }
        return -1;
    }

public:
    void addCustomer(int id, const std::string& name, const std::string& contact) {
        customers.push_back({id, name, contact});
    }

    void deleteCustomer(int id) {
        int index = findCustomerIndexById(id);
        if (index != -1) customers.erase(customers.begin() + index);
    }

    void updateCustomer(int id, const std::string& name, const std::string& contact) {
        int index = findCustomerIndexById(id);
        if (index != -1) {
            customers[index].name = name;
            customers[index].contact = contact;
        }
    }

    void searchCustomer(int id) {
        int index = findCustomerIndexById(id);
        if (index != -1) {
            std::cout << "Customer ID: " << customers[index].id
                      << ", Name: " << customers[index].name
                      << ", Contact: " << customers[index].contact << std::endl;
        } else {
            std::cout << "Customer not found." << std::endl;
        }
    }

    void displayCustomers() {
        for (const auto& c : customers) {
            std::cout << "Customer ID: " << c.id
                      << ", Name: " << c.name
                      << ", Contact: " << c.contact << std::endl;
        }
    }

    void addHairstylist(int id, const std::string& name, const std::string& specialization) {
        hairstylists.push_back({id, name, specialization});
    }

    void deleteHairstylist(int id) {
        int index = findHairstylistIndexById(id);
        if (index != -1) hairstylists.erase(hairstylists.begin() + index);
    }

    void updateHairstylist(int id, const std::string& name, const std::string& specialization) {
        int index = findHairstylistIndexById(id);
        if (index != -1) {
            hairstylists[index].name = name;
            hairstylists[index].specialization = specialization;
        }
    }

    void searchHairstylist(int id) {
        int index = findHairstylistIndexById(id);
        if (index != -1) {
            std::cout << "Hairstylist ID: " << hairstylists[index].id
                      << ", Name: " << hairstylists[index].name
                      << ", Specialization: " << hairstylists[index].specialization << std::endl;
        } else {
            std::cout << "Hairstylist not found." << std::endl;
        }
    }

    void displayHairstylists() {
        for (const auto& h : hairstylists) {
            std::cout << "Hairstylist ID: " << h.id
                      << ", Name: " << h.name
                      << ", Specialization: " << h.specialization << std::endl;
        }
    }
};

int main() {
    BeautySalon salon;
    salon.addCustomer(1, "Alice", "123456789");
    salon.addHairstylist(1, "Bob", "Curls");
    salon.displayCustomers();
    salon.displayHairstylists();
    return 0;
}