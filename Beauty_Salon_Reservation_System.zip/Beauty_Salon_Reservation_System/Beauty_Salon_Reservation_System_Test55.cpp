#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    int id;
    string name;
    string contact;
};

class SalonSystem {
    vector<Person> customers;
    vector<Person> stylists;
    int customerCount = 0;
    int stylistCount = 0;

public:
    void addCustomer(const string& name, const string& contact) {
        customers.push_back({++customerCount, name, contact});
    }

    void deleteCustomer(int id) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) {
                customers.erase(customers.begin() + i);
                break;
            }
        }
    }

    void updateCustomer(int id, const string& name, const string& contact) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                cout << "Customer ID: " << customer.id << " Name: " << customer.name << " Contact: " << customer.contact << endl;
                return;
            }
        }
        cout << "Customer not found" << endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Customer ID: " << customer.id << " Name: " << customer.name << " Contact: " << customer.contact << endl;
        }
    }

    void addStylist(const string& name, const string& contact) {
        stylists.push_back({++stylistCount, name, contact});
    }

    void deleteStylist(int id) {
        for (size_t i = 0; i < stylists.size(); ++i) {
            if (stylists[i].id == id) {
                stylists.erase(stylists.begin() + i);
                break;
            }
        }
    }

    void updateStylist(int id, const string& name, const string& contact) {
        for (auto& stylist : stylists) {
            if (stylist.id == id) {
                stylist.name = name;
                stylist.contact = contact;
                break;
            }
        }
    }

    void searchStylist(int id) {
        for (const auto& stylist : stylists) {
            if (stylist.id == id) {
                cout << "Stylist ID: " << stylist.id << " Name: " << stylist.name << " Contact: " << stylist.contact << endl;
                return;
            }
        }
        cout << "Stylist not found" << endl;
    }

    void displayStylists() {
        for (const auto& stylist : stylists) {
            cout << "Stylist ID: " << stylist.id << " Name: " << stylist.name << " Contact: " << stylist.contact << endl;
        }
    }
};

int main() {
    SalonSystem salon;
    
    salon.addCustomer("Alice", "123-456-7890");
    salon.addCustomer("Bob", "987-654-3210");
    salon.addStylist("Charlie", "111-222-3333");
    
    salon.displayCustomers();
    salon.displayStylists();
    
    salon.searchCustomer(1);
    salon.searchStylist(1);
    
    salon.updateCustomer(1, "Alice A.", "123-456-7891");
    salon.updateStylist(1, "Charlie C.", "111-222-3334");
    
    salon.displayCustomers();
    salon.displayStylists();
    
    salon.deleteCustomer(2);
    salon.deleteStylist(1);
    
    salon.displayCustomers();
    salon.displayStylists();

    return 0;
}