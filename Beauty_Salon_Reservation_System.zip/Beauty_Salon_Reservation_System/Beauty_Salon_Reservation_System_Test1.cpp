#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string contact;
};

struct Hairstylist {
    int id;
    string name;
    string specialty;
};

class BeautySalon {
    Customer customers[100];
    int customerCount;
    Hairstylist stylists[100];
    int stylistCount;

public:
    BeautySalon() : customerCount(0), stylistCount(0) {}

    void addCustomer(int id, string name, string contact) {
        customers[customerCount++] = {id, name, contact};
    }

    void deleteCustomer(int id) {
        bool found = false;
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                for (int j = i; j < customerCount - 1; ++j) {
                    customers[j] = customers[j + 1];
                }
                customerCount--;
                found = true;
                break;
            }
        }
        if (!found) {
            cout << "Customer not found." << endl;
        }
    }

    void updateCustomer(int id, string name, string contact) {
        bool found = false;
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i].name = name;
                customers[i].contact = contact;
                found = true;
                break;
            }
        }
        if (!found) {
            cout << "Customer not found." << endl;
        }
    }

    void searchCustomer(int id) {
        bool found = false;
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                cout << "ID: " << customers[i].id << ", Name: " << customers[i].name << ", Contact: " << customers[i].contact << endl;
                found = true;
                break;
            }
        }
        if (!found) {
            cout << "Customer not found." << endl;
        }
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; ++i) {
            cout << "ID: " << customers[i].id << ", Name: " << customers[i].name << ", Contact: " << customers[i].contact << endl;
        }
    }

    void addHairstylist(int id, string name, string specialty) {
        stylists[stylistCount++] = {id, name, specialty};
    }

    void deleteHairstylist(int id) {
        bool found = false;
        for (int i = 0; i < stylistCount; ++i) {
            if (stylists[i].id == id) {
                for (int j = i; j < stylistCount - 1; ++j) {
                    stylists[j] = stylists[j + 1];
                }
                stylistCount--;
                found = true;
                break;
            }
        }
        if (!found) {
            cout << "Hairstylist not found." << endl;
        }
    }

    void updateHairstylist(int id, string name, string specialty) {
        bool found = false;
        for (int i = 0; i < stylistCount; ++i) {
            if (stylists[i].id == id) {
                stylists[i].name = name;
                stylists[i].specialty = specialty;
                found = true;
                break;
            }
        }
        if (!found) {
            cout << "Hairstylist not found." << endl;
        }
    }

    void searchHairstylist(int id) {
        bool found = false;
        for (int i = 0; i < stylistCount; ++i) {
            if (stylists[i].id == id) {
                cout << "ID: " << stylists[i].id << ", Name: " << stylists[i].name << ", Specialty: " << stylists[i].specialty << endl;
                found = true;
                break;
            }
        }
        if (!found) {
            cout << "Hairstylist not found." << endl;
        }
    }

    void displayHairstylists() {
        for (int i = 0; i < stylistCount; ++i) {
            cout << "ID: " << stylists[i].id << ", Name: " << stylists[i].name << ", Specialty: " << stylists[i].specialty << endl;
        }
    }
};

int main() {
    BeautySalon salon;
    salon.addCustomer(1, "Alice", "123-456-7890");
    salon.addHairstylist(1, "Bob", "Curly Hair");
    salon.displayCustomers();
    salon.displayHairstylists();
    return 0;
}