#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    int id;
public:
    Person(std::string n, int i) : name(n), id(i) {}
    int getId() const { return id; }
    std::string getName() const { return name; }
    void setName(const std::string& n) { name = n; }
};

class Customer : public Person {
public:
    Customer(std::string n, int i) : Person(n, i) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(std::string n, int i) : Person(n, i) {}
};

template <typename T>
class SalonSystem {
    std::vector<T> records;
public:
    void addRecord(const T& record) {
        records.push_back(record);
    }

    void deleteRecord(int id) {
        for (auto it = records.begin(); it != records.end(); ++it) {
            if (it->getId() == id) {
                records.erase(it);
                break;
            }
        }
    }

    void updateRecord(int id, const std::string& newName) {
        for (auto& record : records) {
            if (record.getId() == id) {
                record.setName(newName);
                break;
            }
        }
    }

    T* searchRecord(int id) {
        for (auto& record : records) {
            if (record.getId() == id) {
                return &record;
            }
        }
        return nullptr;
    }

    void displayRecords() const {
        for (const auto& record : records) {
            std::cout << "ID: " << record.getId() << ", Name: " << record.getName() << std::endl;
        }
    }
};

int main() {
    SalonSystem<Customer> customerSystem;
    SalonSystem<Hairstylist> hairstylistSystem;

    Customer c1("Alice", 1);
    Customer c2("Bob", 2);
    Hairstylist h1("Charlie", 1);
    Hairstylist h2("Diane", 2);

    customerSystem.addRecord(c1);
    customerSystem.addRecord(c2);
    hairstylistSystem.addRecord(h1);
    hairstylistSystem.addRecord(h2);

    customerSystem.displayRecords();
    hairstylistSystem.displayRecords();

    customerSystem.updateRecord(1, "Alicia");
    hairstylistSystem.deleteRecord(2);

    customerSystem.displayRecords();
    hairstylistSystem.displayRecords();

    Customer* foundCustomer = customerSystem.searchRecord(2);
    if (foundCustomer) std::cout << "Found customer: " << foundCustomer->getName() << std::endl;

    return 0;
}