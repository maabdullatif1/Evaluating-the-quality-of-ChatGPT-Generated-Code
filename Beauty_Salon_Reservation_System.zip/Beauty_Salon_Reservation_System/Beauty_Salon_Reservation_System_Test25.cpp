#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    std::string phone;
public:
    Person(const std::string &name, const std::string &phone) : name(name), phone(phone) {}
    std::string getName() const { return name; }
    std::string getPhone() const { return phone; }
    void setName(const std::string &newName) { name = newName; }
    void setPhone(const std::string &newPhone) { phone = newPhone; }
};

class Customer : public Person {
public:
    Customer(const std::string &name, const std::string &phone) : Person(name, phone) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(const std::string &name, const std::string &phone) : Person(name, phone) {}
};

class BeautySalon {
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;
public:
    void addCustomer(const std::string &name, const std::string &phone) {
        customers.emplace_back(name, phone);
    }
    
    void addHairstylist(const std::string &name, const std::string &phone) {
        hairstylists.emplace_back(name, phone);
    }
    
    void deleteCustomer(const std::string &name) {
        for(auto it = customers.begin(); it != customers.end(); ++it) {
            if(it->getName() == name) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void deleteHairstylist(const std::string &name) {
        for(auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if(it->getName() == name) {
                hairstylists.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(const std::string &name, const std::string &newName, const std::string &newPhone) {
        for(auto &customer : customers) {
            if(customer.getName() == name) {
                customer.setName(newName);
                customer.setPhone(newPhone);
                break;
            }
        }
    }
    
    void updateHairstylist(const std::string &name, const std::string &newName, const std::string &newPhone) {
        for(auto &hairstylist : hairstylists) {
            if(hairstylist.getName() == name) {
                hairstylist.setName(newName);
                hairstylist.setPhone(newPhone);
                break;
            }
        }
    }
    
    Customer* searchCustomer(const std::string &name) {
        for(auto &customer : customers) {
            if(customer.getName() == name) {
                return &customer;
            }
        }
        return nullptr;
    }
    
    Hairstylist* searchHairstylist(const std::string &name) {
        for(auto &hairstylist : hairstylists) {
            if(hairstylist.getName() == name) {
                return &hairstylist;
            }
        }
        return nullptr;
    }
    
    void displayCustomers() const {
        for(const auto &customer : customers) {
            std::cout << "Customer Name: " << customer.getName() << ", Phone: " << customer.getPhone() << "\n";
        }
    }
    
    void displayHairstylists() const {
        for(const auto &hairstylist : hairstylists) {
            std::cout << "Hairstylist Name: " << hairstylist.getName() << ", Phone: " << hairstylist.getPhone() << "\n";
        }
    }
};

int main() {
    BeautySalon salon;
    salon.addCustomer("Alice", "123-456-7890");
    salon.addHairstylist("Bob", "321-654-0987");
    salon.displayCustomers();
    salon.displayHairstylists();
    beautysalon.addCustomer("Charlie", "987-654-3210");
    beautysalon.displayCustomers();
    beautysalon.updateCustomer("Alice", "Alice A.", "123-000-0000");
    beautysalon.displayCustomers();
    beautysalon.deleteCustomer("Charlie");
    beautysalon.displayCustomers();
    return 0;
}