#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string phone;

    Customer(int id, std::string name, std::string phone)
        : id(id), name(name), phone(phone) {}
};

class Hairstylist {
public:
    int id;
    std::string name;
    std::string specialty;

    Hairstylist(int id, std::string name, std::string specialty)
        : id(id), name(name), specialty(specialty) {}
};

class SalonReservationSystem {
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;
    int customerIdCounter;
    int hairstylistIdCounter;

public:
    SalonReservationSystem() : customerIdCounter(0), hairstylistIdCounter(0) {}

    void addCustomer(const std::string& name, const std::string& phone) {
        customers.push_back(Customer(customerIdCounter++, name, phone));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& phone) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phone = phone;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id 
                      << ", Name: " << customer.name 
                      << ", Phone: " << customer.phone << std::endl;
        }
    }

    void addHairstylist(const std::string& name, const std::string& specialty) {
        hairstylists.push_back(Hairstylist(hairstylistIdCounter++, name, specialty));
    }

    void deleteHairstylist(int id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->id == id) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateHairstylist(int id, const std::string& name, const std::string& specialty) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                hairstylist.name = name;
                hairstylist.specialty = specialty;
                break;
            }
        }
    }

    Hairstylist* searchHairstylist(int id) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                return &hairstylist;
            }
        }
        return nullptr;
    }

    void displayHairstylists() {
        for (const auto& hairstylist : hairstylists) {
            std::cout << "Hairstylist ID: " << hairstylist.id 
                      << ", Name: " << hairstylist.name 
                      << ", Specialty: " << hairstylist.specialty << std::endl;
        }
    }
};

int main() {
    SalonReservationSystem system;

    system.addCustomer("Alice Johnson", "123456789");
    system.addCustomer("Bob Smith", "987654321");

    system.addHairstylist("Cathy Lee", "Coloring");
    system.addHairstylist("Daniel Wu", "Cuts");

    std::cout << "Customers:" << std::endl;
    system.displayCustomers();

    std::cout << "\nHairstylists:" << std::endl;
    system.displayHairstylists();

    system.updateCustomer(0, "Alice Williams", "111222333");
    system.updateHairstylist(1, "Daniel Wu", "Styling");

    std::cout << "\nUpdated Customers:" << std::endl;
    system.displayCustomers();

    std::cout << "\nUpdated Hairstylists:" << std::endl;
    system.displayHairstylists();

    system.deleteCustomer(1);
    system.deleteHairstylist(0);

    std::cout << "\nAfter Deletion - Customers:" << std::endl;
    system.displayCustomers();

    std::cout << "\nAfter Deletion - Hairstylists:" << std::endl;
    system.displayHairstylists();

    return 0;
}