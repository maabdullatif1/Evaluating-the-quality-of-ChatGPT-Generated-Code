#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct Hairstylist {
    int id;
    string name;
    string specialty;
};

class BeautySalon {
    vector<Customer> customers;
    vector<Hairstylist> hairstylists;

    int findCustomerIndex(int id) {
        for (int i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) {
                return i;
            }
        }
        return -1;
    }
    
    int findHairstylistIndex(int id) {
        for (int i = 0; i < hairstylists.size(); ++i) {
            if (hairstylists[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addCustomer(int id, string name, string phone) {
        if (findCustomerIndex(id) == -1) {
            customers.push_back({id, name, phone});
        }
    }
    
    void deleteCustomer(int id) {
        int index = findCustomerIndex(id);
        if (index != -1) {
            customers.erase(customers.begin() + index);
        }
    }

    void updateCustomer(int id, string name, string phone) {
        int index = findCustomerIndex(id);
        if (index != -1) {
            customers[index].name = name;
            customers[index].phone = phone;
        }
    }

    Customer* searchCustomer(int id) {
        int index = findCustomerIndex(id);
        return (index != -1) ? &customers[index] : nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "ID: " << customer.id
                 << ", Name: " << customer.name
                 << ", Phone: " << customer.phone << endl;
        }
    }

    void addHairstylist(int id, string name, string specialty) {
        if (findHairstylistIndex(id) == -1) {
            hairstylists.push_back({id, name, specialty});
        }
    }
    
    void deleteHairstylist(int id) {
        int index = findHairstylistIndex(id);
        if (index != -1) {
            hairstylists.erase(hairstylists.begin() + index);
        }
    }

    void updateHairstylist(int id, string name, string specialty) {
        int index = findHairstylistIndex(id);
        if (index != -1) {
            hairstylists[index].name = name;
            hairstylists[index].specialty = specialty;
        }
    }
    
    Hairstylist* searchHairstylist(int id) {
        int index = findHairstylistIndex(id);
        return (index != -1) ? &hairstylists[index] : nullptr;
    }

    void displayHairstylists() {
        for (const auto& stylist : hairstylists) {
            cout << "ID: " << stylist.id
                 << ", Name: " << stylist.name
                 << ", Specialty: " << stylist.specialty << endl;
        }
    }
};

int main() {
    BeautySalon salon;
    salon.addCustomer(1, "Alice", "123456789");
    salon.addCustomer(2, "Bob", "987654321");
    salon.updateCustomer(1, "Alice Smith", "111222333");
    salon.displayCustomers();
    salon.addHairstylist(1, "John", "Cut and Color");
    salon.addHairstylist(2, "Emma", "Styling");
    salon.updateHairstylist(2, "Emma Brown", "Advanced Styling");
    salon.displayHairstylists();
    return 0;
}