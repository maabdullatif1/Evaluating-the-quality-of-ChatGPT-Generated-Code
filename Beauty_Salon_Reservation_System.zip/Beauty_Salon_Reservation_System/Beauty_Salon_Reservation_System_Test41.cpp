#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct Hairstylist {
    int id;
    string name;
    string specialty;
};

template<typename T>
class SalonSystem {
    vector<T> records;
    int nextId;

public:
    SalonSystem() : nextId(1) {}

    void add(const string& name, const string& detail) {
        records.push_back({nextId++, name, detail});
    }

    void del(int id) {
        for (auto it = records.begin(); it != records.end(); ++it) {
            if (it->id == id) {
                records.erase(it);
                break;
            }
        }
    }

    void update(int id, const string& name, const string& detail) {
        for (auto& record : records) {
            if (record.id == id) {
                record.name = name;
                record.detail = detail;
                break;
            }
        }
    }

    T* search(int id) {
        for (auto& record : records) {
            if (record.id == id) {
                return &record;
            }
        }
        return nullptr;
    }

    void display() {
        for (const auto& record : records) {
            cout << "ID: " << record.id 
                 << " Name: " << record.name 
                 << " Detail: " << record.detail << endl;
        }
    }
};

int main() {
    SalonSystem<Customer> customerSystem;
    SalonSystem<Hairstylist> stylistSystem;

    customerSystem.add("Alice", "555-1234");
    customerSystem.add("Bob", "555-5678");
    stylistSystem.add("John", "Coloring");
    stylistSystem.add("Jane", "Cutting");

    cout << "All Customers:" << endl;
    customerSystem.display();

    cout << "\nAll Hairstylists:" << endl;
    stylistSystem.display();

    Customer* foundCustomer = customerSystem.search(1);
    if (foundCustomer) {
        cout << "\nFound Customer with ID 1: "
             << "Name: " << foundCustomer->name 
             << " Phone: " << foundCustomer->phone << endl;
    }

    Hairstylist* foundStylist = stylistSystem.search(2);
    if (foundStylist) {
        cout << "Found Hairstylist with ID 2: "
             << "Name: " << foundStylist->name 
             << " Specialty: " << foundStylist->specialty << endl;
    }

    customerSystem.update(1, "Alice Cooper", "555-0000");
    cout << "\nUpdated Customer with ID 1:" << endl;
    customerSystem.display();

    stylistSystem.del(1);
    cout << "\nHairstylists after deleting ID 1:" << endl;
    stylistSystem.display();

    return 0;
}