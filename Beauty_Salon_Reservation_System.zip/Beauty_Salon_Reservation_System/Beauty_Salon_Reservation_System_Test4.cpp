#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct Hairstylist {
    int id;
    string name;
    string specialty;
};

const int MAX_CUSTOMERS = 100;
const int MAX_HAIRSTYLISTS = 50;

Customer customers[MAX_CUSTOMERS];
Hairstylist hairstylists[MAX_HAIRSTYLISTS];
int customerCount = 0;
int hairstylistCount = 0;

void addCustomer() {
    if (customerCount >= MAX_CUSTOMERS) return;
    cout << "Enter customer ID: ";
    cin >> customers[customerCount].id;
    cout << "Enter customer name: ";
    cin.ignore();
    getline(cin, customers[customerCount].name);
    cout << "Enter customer phone: ";
    getline(cin, customers[customerCount].phone);
    customerCount++;
}

void addHairstylist() {
    if (hairstylistCount >= MAX_HAIRSTYLISTS) return;
    cout << "Enter hairstylist ID: ";
    cin >> hairstylists[hairstylistCount].id;
    cout << "Enter hairstylist name: ";
    cin.ignore();
    getline(cin, hairstylists[hairstylistCount].name);
    cout << "Enter hairstylist specialty: ";
    getline(cin, hairstylists[hairstylistCount].specialty);
    hairstylistCount++;
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            customers[i] = customers[customerCount - 1];
            customerCount--;
            return;
        }
    }
}

void deleteHairstylist(int id) {
    for (int i = 0; i < hairstylistCount; i++) {
        if (hairstylists[i].id == id) {
            hairstylists[i] = hairstylists[hairstylistCount - 1];
            hairstylistCount--;
            return;
        }
    }
}

void updateCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            cout << "Enter new name: ";
            cin.ignore();
            getline(cin, customers[i].name);
            cout << "Enter new phone: ";
            getline(cin, customers[i].phone);
            return;
        }
    }
}

void updateHairstylist(int id) {
    for (int i = 0; i < hairstylistCount; i++) {
        if (hairstylists[i].id == id) {
            cout << "Enter new name: ";
            cin.ignore();
            getline(cin, hairstylists[i].name);
            cout << "Enter new specialty: ";
            getline(cin, hairstylists[i].specialty);
            return;
        }
    }
}

void searchCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << ", Phone: " << customers[i].phone << endl;
            return;
        }
    }
    cout << "Customer not found." << endl;
}

void searchHairstylist(int id) {
    for (int i = 0; i < hairstylistCount; i++) {
        if (hairstylists[i].id == id) {
            cout << "Hairstylist ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name << ", Specialty: " << hairstylists[i].specialty << endl;
            return;
        }
    }
    cout << "Hairstylist not found." << endl;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; i++) {
        cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << ", Phone: " << customers[i].phone << endl;
    }
}

void displayHairstylists() {
    for (int i = 0; i < hairstylistCount; i++) {
        cout << "Hairstylist ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name << ", Specialty: " << hairstylists[i].specialty << endl;
    }
}

int main() {
    int choice, id;
    while (true) {
        cout << "1. Add Customer" << endl;
        cout << "2. Add Hairstylist" << endl;
        cout << "3. Delete Customer" << endl;
        cout << "4. Delete Hairstylist" << endl;
        cout << "5. Update Customer" << endl;
        cout << "6. Update Hairstylist" << endl;
        cout << "7. Search Customer" << endl;
        cout << "8. Search Hairstylist" << endl;
        cout << "9. Display Customers" << endl;
        cout << "10. Display Hairstylists" << endl;
        cout << "11. Exit" << endl;
        cin >> choice;

        switch (choice) {
            case 1:
                addCustomer();
                break;
            case 2:
                addHairstylist();
                break;
            case 3:
                cout << "Enter Customer ID to delete: ";
                cin >> id;
                deleteCustomer(id);
                break;
            case 4:
                cout << "Enter Hairstylist ID to delete: ";
                cin >> id;
                deleteHairstylist(id);
                break;
            case 5:
                cout << "Enter Customer ID to update: ";
                cin >> id;
                updateCustomer(id);
                break;
            case 6:
                cout << "Enter Hairstylist ID to update: ";
                cin >> id;
                updateHairstylist(id);
                break;
            case 7:
                cout << "Enter Customer ID to search: ";
                cin >> id;
                searchCustomer(id);
                break;
            case 8:
                cout << "Enter Hairstylist ID to search: ";
                cin >> id;
                searchHairstylist(id);
                break;
            case 9:
                displayCustomers();
                break;
            case 10:
                displayHairstylists();
                break;
            case 11:
                return 0;
            default:
                cout << "Invalid choice." << endl;
                break;
        }
    }
    return 0;
}