#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    std::string phone;
    Person(std::string n, std::string p) : name(n), phone(p) {}
};

class Customer : public Person {
public:
    Customer(std::string n, std::string p) : Person(n, p) {}
};

class Hairstylist : public Person {
public:
    std::string specialty;
    Hairstylist(std::string n, std::string p, std::string s) : Person(n, p), specialty(s) {}
};

class SalonSystem {
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;
public:
    void addCustomer(std::string name, std::string phone) {
        customers.push_back(Customer(name, phone));
    }

    void deleteCustomer(std::string name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                return;
            }
        }
    }

    void updateCustomer(std::string oldName, std::string newName, std::string newPhone) {
        for (auto &customer : customers) {
            if (customer.name == oldName) {
                customer.name = newName;
                customer.phone = newPhone;
                return;
            }
        }
    }

    Customer* searchCustomer(std::string name) {
        for (auto &customer : customers) {
            if (customer.name == name) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "Customer: " << customer.name << ", Phone: " << customer.phone << std::endl;
        }
    }

    void addHairstylist(std::string name, std::string phone, std::string specialty) {
        hairstylists.push_back(Hairstylist(name, phone, specialty));
    }

    void deleteHairstylist(std::string name) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->name == name) {
                hairstylists.erase(it);
                return;
            }
        }
    }

    void updateHairstylist(std::string oldName, std::string newName, std::string newPhone, std::string newSpecialty) {
        for (auto &hairstylist : hairstylists) {
            if (hairstylist.name == oldName) {
                hairstylist.name = newName;
                hairstylist.phone = newPhone;
                hairstylist.specialty = newSpecialty;
                return;
            }
        }
    }

    Hairstylist* searchHairstylist(std::string name) {
        for (auto &hairstylist : hairstylists) {
            if (hairstylist.name == name) {
                return &hairstylist;
            }
        }
        return nullptr;
    }

    void displayHairstylists() {
        for (const auto &hairstylist : hairstylists) {
            std::cout << "Hairstylist: " << hairstylist.name << ", Phone: " << hairstylist.phone << ", Specialty: " << hairstylist.specialty << std::endl;
        }
    }
};

int main() {
    SalonSystem salon;
    salon.addCustomer("Alice", "123456789");
    salon.addCustomer("Bob", "987654321");
    salon.displayCustomers();

    salon.addHairstylist("Charlie", "112233445", "Cut & Color");
    salon.addHairstylist("Diana", "556677889", "Styling");
    salon.displayHairstylists();

    Customer* customer = salon.searchCustomer("Alice");
    if (customer) {
        std::cout << "Found customer: " << customer->name << std::endl;
    }

    Hairstylist* hairstylist = salon.searchHairstylist("Charlie");
    if (hairstylist) {
        std::cout << "Found hairstylist: " << hairstylist->name << ", Specialty: " << hairstylist->specialty << std::endl;
    }

    salon.updateCustomer("Alice", "Alice Cooper", "911911911");
    salon.updateHairstylist("Charlie", "Charlie Brown", "667788990", "Perms");

    salon.displayCustomers();
    salon.displayHairstylists();

    salon.deleteCustomer("Bob");
    salon.deleteHairstylist("Diana");
    salon.displayCustomers();
    salon.displayHairstylists();

    return 0;
}