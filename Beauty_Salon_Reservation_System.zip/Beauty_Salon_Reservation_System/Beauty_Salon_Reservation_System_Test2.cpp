#include <iostream>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct Hairstylist {
    int id;
    string name;
    string specialization;
};

class BeautySalon {
private:
    Customer customers[100];
    Hairstylist hairstylists[100];
    int customerCount;
    int hairstylistCount;

public:
    BeautySalon() : customerCount(0), hairstylistCount(0) {}

    void addCustomer(int id, string name, string phone) {
        customers[customerCount++] = {id, name, phone};
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i] = customers[--customerCount];
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string phone) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i].name = name;
                customers[i].phone = phone;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name 
                     << ", Phone: " << customers[i].phone << endl;
                return;
            }
        }
        cout << "Customer not found" << endl;
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; ++i) {
            cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name 
                 << ", Phone: " << customers[i].phone << endl;
        }
    }

    void addHairstylist(int id, string name, string specialization) {
        hairstylists[hairstylistCount++] = {id, name, specialization};
    }

    void deleteHairstylist(int id) {
        for (int i = 0; i < hairstylistCount; ++i) {
            if (hairstylists[i].id == id) {
                hairstylists[i] = hairstylists[--hairstylistCount];
                break;
            }
        }
    }

    void updateHairstylist(int id, string name, string specialization) {
        for (int i = 0; i < hairstylistCount; ++i) {
            if (hairstylists[i].id == id) {
                hairstylists[i].name = name;
                hairstylists[i].specialization = specialization;
                break;
            }
        }
    }

    void searchHairstylist(int id) {
        for (int i = 0; i < hairstylistCount; ++i) {
            if (hairstylists[i].id == id) {
                cout << "Hairstylist ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name 
                     << ", Specialization: " << hairstylists[i].specialization << endl;
                return;
            }
        }
        cout << "Hairstylist not found" << endl;
    }

    void displayHairstylists() {
        for (int i = 0; i < hairstylistCount; ++i) {
            cout << "Hairstylist ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name 
                 << ", Specialization: " << hairstylists[i].specialization << endl;
        }
    }
};

int main() {
    BeautySalon salon;
    salon.addCustomer(1, "Alice", "123-456-7890");
    salon.addCustomer(2, "Bob", "234-567-8901");
    salon.displayCustomers();
    salon.updateCustomer(1, "Alicia", "123-456-7899");
    salon.searchCustomer(1);
    salon.deleteCustomer(2);
    salon.displayCustomers();

    salon.addHairstylist(1, "John", "Cuts");
    salon.addHairstylist(2, "Jane", "Coloring");
    salon.displayHairstylists();
    salon.updateHairstylist(1, "Johnny", "Cuts and Styles");
    salon.searchHairstylist(1);
    salon.deleteHairstylist(2);
    salon.displayHairstylists();

    return 0;
}