#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    std::string phoneNumber;
};

class Customer : public Person {
public:
    int customerID;

    Customer(int id, std::string name, std::string phone) {
        customerID = id;
        this->name = name;
        this->phoneNumber = phone;
    }
};

class Hairstylist : public Person {
public:
    int stylistID;

    Hairstylist(int id, std::string name, std::string phone) {
        stylistID = id;
        this->name = name;
        this->phoneNumber = phone;
    }
};

class BeautySalon {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

    template<typename T>
    int findIndexByID(const std::vector<T>& vec, int id) {
        for (int i = 0; i < vec.size(); ++i) {
            if ((vec[i].stylistID == id) || (vec[i].customerID == id)) {
                return i;
            }
        }
        return -1;
    }

public:
    void addCustomer(int id, std::string name, std::string phone) {
        customers.push_back(Customer(id, name, phone));
    }

    void deleteCustomer(int id) {
        int index = findIndexByID(customers, id);
        if (index != -1) {
            customers.erase(customers.begin() + index);
        }
    }

    void updateCustomer(int id, std::string name, std::string phone) {
        int index = findIndexByID(customers, id);
        if (index != -1) {
            customers[index].name = name;
            customers[index].phoneNumber = phone;
        }
    }

    void searchCustomer(int id) {
        int index = findIndexByID(customers, id);
        if (index != -1) {
            std::cout << "Customer Found: " << customers[index].name << ", " << customers[index].phoneNumber << std::endl;
        } else {
            std::cout << "Customer Not Found" << std::endl;
        }
    }

    void displayCustomers() {
        for (const Customer& c : customers) {
            std::cout << "ID: " << c.customerID << ", Name: " << c.name << ", Phone: " << c.phoneNumber << std::endl;
        }
    }

    void addHairstylist(int id, std::string name, std::string phone) {
        hairstylists.push_back(Hairstylist(id, name, phone));
    }

    void deleteHairstylist(int id) {
        int index = findIndexByID(hairstylists, id);
        if (index != -1) {
            hairstylists.erase(hairstylists.begin() + index);
        }
    }

    void updateHairstylist(int id, std::string name, std::string phone) {
        int index = findIndexByID(hairstylists, id);
        if (index != -1) {
            hairstylists[index].name = name;
            hairstylists[index].phoneNumber = phone;
        }
    }

    void searchHairstylist(int id) {
        int index = findIndexByID(hairstylists, id);
        if (index != -1) {
            std::cout << "Hairstylist Found: " << hairstylists[index].name << ", " << hairstylists[index].phoneNumber << std::endl;
        } else {
            std::cout << "Hairstylist Not Found" << std::endl;
        }
    }

    void displayHairstylists() {
        for (const Hairstylist& h : hairstylists) {
            std::cout << "ID: " << h.stylistID << ", Name: " << h.name << ", Phone: " << h.phoneNumber << std::endl;
        }
    }
};

int main() {
    BeautySalon salon;
    
    salon.addCustomer(1, "Alice Johnson", "555-1234");
    salon.addCustomer(2, "Bob Smith", "555-5678");
    salon.addHairstylist(1, "Carol Adams", "555-8765");
    salon.addHairstylist(2, "Dave Brown", "555-4321");
    
    std::cout << "Customers:" << std::endl;
    salon.displayCustomers();
    
    std::cout << "\nHairstylists:" << std::endl;
    salon.displayHairstylists();
    
    salon.updateCustomer(1, "Alice Johnson Updated", "555-0000");
    salon.searchCustomer(1);
    
    salon.deleteHairstylist(2);
    salon.displayHairstylists();
    
    return 0;
}