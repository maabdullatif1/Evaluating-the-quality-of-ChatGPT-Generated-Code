#include <iostream>
#include <vector>
#include <string>

struct Person {
    int id;
    std::string name;
    std::string phone;
};

class SalonSystem {
private:
    std::vector<Person> customers;
    std::vector<Person> hairstylists;

    void displayPersons(const std::vector<Person>& persons) {
        for (const auto& person : persons) {
            std::cout << "ID: " << person.id << ", Name: " << person.name
                      << ", Phone: " << person.phone << std::endl;
        }
    }

    Person* searchById(std::vector<Person>& persons, int id) {
        for (auto& person : persons) {
            if (person.id == id) {
                return &person;
            }
        }
        return nullptr;
    }

    void removeById(std::vector<Person>& persons, int id) {
        auto it = persons.begin();
        while (it != persons.end()) {
            if (it->id == id) {
                persons.erase(it);
                break;
            }
            ++it;
        }
    }

    void addPerson(std::vector<Person>& persons) {
        Person newPerson;
        std::cout << "Enter ID: "; std::cin >> newPerson.id;
        std::cin.ignore();
        std::cout << "Enter Name: "; std::getline(std::cin, newPerson.name);
        std::cout << "Enter Phone: "; std::getline(std::cin, newPerson.phone);
        persons.push_back(newPerson);
    }

    void updatePerson(Person* person) {
        std::cout << "Enter new Name: "; std::getline(std::cin, person->name);
        std::cout << "Enter new Phone: "; std::getline(std::cin, person->phone);
    }

    void handleSearch(std::vector<Person>& persons) {
        int id;
        std::cout << "Enter ID to search: ";
        std::cin >> id;
        Person* person = searchById(persons, id);
        if (person) {
            std::cout << "Found - ID: " << person->id << ", Name: " << person->name 
                      << ", Phone: " << person->phone << std::endl;
        } else {
            std::cout << "Not Found" << std::endl;
        }
    }

    void handleUpdate(std::vector<Person>& persons) {
        int id;
        std::cout << "Enter ID to update: ";
        std::cin >> id;
        std::cin.ignore();
        Person* person = searchById(persons, id);
        if (person) {
            updatePerson(person);
        } else {
            std::cout << "Not Found" << std::endl;
        }
    }

    void handleDelete(std::vector<Person>& persons) {
        int id;
        std::cout << "Enter ID to delete: ";
        std::cin >> id;
        removeById(persons, id);
    }

public:
    void addCustomer() {
        addPerson(customers);
    }

    void updateCustomer() {
        handleUpdate(customers);
    }

    void deleteCustomer() {
        handleDelete(customers);
    }

    void searchCustomer() {
        handleSearch(customers);
    }

    void displayCustomers() {
        displayPersons(customers);
    }

    void addHairstylist() {
        addPerson(hairstylists);
    }

    void updateHairstylist() {
        handleUpdate(hairstylists);
    }

    void deleteHairstylist() {
        handleDelete(hairstylists);
    }

    void searchHairstylist() {
        handleSearch(hairstylists);
    }

    void displayHairstylists() {
        displayPersons(hairstylists);
    }
};

int main() {
    SalonSystem system;
    int choice;
    do {
        std::cout << "1. Add Customer\n2. Update Customer\n3. Delete Customer\n4. Search Customer\n5. Display Customers\n"
                  << "6. Add Hairstylist\n7. Update Hairstylist\n8. Delete Hairstylist\n9. Search Hairstylist\n10. Display Hairstylists\n"
                  << "0. Exit\n";
        std::cin >> choice;
        std::cin.ignore();

        switch (choice) {
            case 1: system.addCustomer(); break;
            case 2: system.updateCustomer(); break;
            case 3: system.deleteCustomer(); break;
            case 4: system.searchCustomer(); break;
            case 5: system.displayCustomers(); break;
            case 6: system.addHairstylist(); break;
            case 7: system.updateHairstylist(); break;
            case 8: system.deleteHairstylist(); break;
            case 9: system.searchHairstylist(); break;
            case 10: system.displayHairstylists(); break;
            case 0: break;
            default: std::cout << "Invalid choice" << std::endl;
        }
    } while (choice != 0);

    return 0;
}