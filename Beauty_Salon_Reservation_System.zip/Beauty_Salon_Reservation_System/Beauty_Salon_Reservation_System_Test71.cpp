#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct Hairstylist {
    int id;
    string name;
    string specialty;
};

class BeautySalon {
    vector<Customer> customers;
    vector<Hairstylist> hairstylists;
    int customerIdCounter;
    int hairstylistIdCounter;

public:
    BeautySalon() : customerIdCounter(0), hairstylistIdCounter(0) {}

    void addCustomer(const string& name, const string& phone) {
        customers.push_back({++customerIdCounter, name, phone});
    }

    void addHairstylist(const string& name, const string& specialty) {
        hairstylists.push_back({++hairstylistIdCounter, name, specialty});
    }
    
    bool deleteCustomer(int id) {
        for (int i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) {
                customers.erase(customers.begin() + i);
                return true;
            }
        }
        return false;
    }
    
    bool deleteHairstylist(int id) {
        for (int i = 0; i < hairstylists.size(); ++i) {
            if (hairstylists[i].id == id) {
                hairstylists.erase(hairstylists.begin() + i);
                return true;
            }
        }
        return false;
    }

    bool updateCustomer(int id, const string& name, const string& phone) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.phone = phone;
                return true;
            }
        }
        return false;
    }

    bool updateHairstylist(int id, const string& name, const string& specialty) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                hairstylist.name = name;
                hairstylist.specialty = specialty;
                return true;
            }
        }
        return false;
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Hairstylist* searchHairstylist(int id) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                return &hairstylist;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "ID: " << customer.id << ", Name: " << customer.name << ", Phone: " << customer.phone << endl;
        }
    }

    void displayHairstylists() {
        for (const auto& hairstylist : hairstylists) {
            cout << "ID: " << hairstylist.id << ", Name: " << hairstylist.name << ", Specialty: " << hairstylist.specialty << endl;
        }
    }
};

int main() {
    BeautySalon salon;
    
    salon.addCustomer("Jane Doe", "123-456-7890");
    salon.addCustomer("John Smith", "098-765-4321");
    salon.displayCustomers();

    salon.addHairstylist("Eli Brown", "Curly Hair");
    salon.addHairstylist("Lily Green", "Color Specialist");
    salon.displayHairstylists();

    if (salon.updateCustomer(1, "Jane Doe", "111-222-3333")) {
        cout << "Customer updated." << endl;
    }

    if (salon.deleteHairstylist(1)) {
        cout << "Hairstylist deleted." << endl;
    }

    Customer* customer = salon.searchCustomer(2);
    if (customer) {
        cout << "Found customer: " << customer->name << endl;
    }

    salon.displayCustomers();
    salon.displayHairstylists();

    return 0;
}