#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string contact;

    Customer(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class Hairstylist {
public:
    int id;
    std::string name;
    std::string specialty;

    Hairstylist(int id, std::string name, std::string specialty)
        : id(id), name(name), specialty(specialty) {}
};

class SalonReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

public:
    void addCustomer(int id, std::string name, std::string contact) {
        customers.push_back(Customer(id, name, contact));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string newName, std::string newContact) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = newName;
                customer.contact = newContact;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto &customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << std::endl;
                return;
            }
        }
        std::cout << "Customer not found" << std::endl;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << std::endl;
        }
    }

    void addHairstylist(int id, std::string name, std::string specialty) {
        hairstylists.push_back(Hairstylist(id, name, specialty));
    }

    void deleteHairstylist(int id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->id == id) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateHairstylist(int id, std::string newName, std::string newSpecialty) {
        for (auto &hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                hairstylist.name = newName;
                hairstylist.specialty = newSpecialty;
                break;
            }
        }
    }

    void searchHairstylist(int id) {
        for (const auto &hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                std::cout << "Hairstylist ID: " << hairstylist.id << ", Name: " << hairstylist.name << ", Specialty: " << hairstylist.specialty << std::endl;
                return;
            }
        }
        std::cout << "Hairstylist not found" << std::endl;
    }

    void displayHairstylists() {
        for (const auto &hairstylist : hairstylists) {
            std::cout << "Hairstylist ID: " << hairstylist.id << ", Name: " << hairstylist.name << ", Specialty: " << hairstylist.specialty << std::endl;
        }
    }
};

int main() {
    SalonReservationSystem system;
    
    system.addCustomer(1, "Alice", "123-456-7890");
    system.addCustomer(2, "Bob", "098-765-4321");
    system.displayCustomers();
    
    system.addHairstylist(1, "Sam", "Coloring");
    system.addHairstylist(2, "Jill", "Cutting");
    system.displayHairstylists();
    
    system.updateCustomer(1, "Alicia", "123-000-7890");
    system.searchCustomer(1);
    
    system.deleteHairstylist(2);
    system.displayHairstylists();

    return 0;
}