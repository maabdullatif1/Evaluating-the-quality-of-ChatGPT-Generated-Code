#include <iostream>
#include <string>
#include <vector>

class Person {
protected:
    std::string name;
    std::string phone;
public:
    Person(const std::string& name, const std::string& phone) : name(name), phone(phone) {}
    std::string getName() const { return name; }
    std::string getPhone() const { return phone; }
    void setName(const std::string& newName) { name = newName; }
    void setPhone(const std::string& newPhone) { phone = newPhone; }
};

class Customer : public Person {
public:
    Customer(const std::string& name, const std::string& phone) : Person(name, phone) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(const std::string& name, const std::string& phone) : Person(name, phone) {}
};

class Salon {
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;
public:
    void addCustomer(const std::string& name, const std::string& phone) {
        customers.emplace_back(name, phone);
    }
    
    void deleteCustomer(const std::string& name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getName() == name) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(const std::string& name, const std::string& newName, const std::string& newPhone) {
        for (auto& customer : customers) {
            if (customer.getName() == name) {
                customer.setName(newName);
                customer.setPhone(newPhone);
                break;
            }
        }
    }

    Customer* searchCustomer(const std::string& name) {
        for (auto& customer : customers) {
            if (customer.getName() == name) {
                return &customer;
            }
        }
        return nullptr;
    }

    void addHairstylist(const std::string& name, const std::string& phone) {
        hairstylists.emplace_back(name, phone);
    }

    void deleteHairstylist(const std::string& name) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->getName() == name) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateHairstylist(const std::string& name, const std::string& newName, const std::string& newPhone) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.getName() == name) {
                hairstylist.setName(newName);
                hairstylist.setPhone(newPhone);
                break;
            }
        }
    }

    Hairstylist* searchHairstylist(const std::string& name) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.getName() == name) {
                return &hairstylist;
            }
        }
        return nullptr;
    }

    void displayCustomers() const {
        for (const auto& customer : customers) {
            std::cout << "Customer: " << customer.getName() << ", Phone: " << customer.getPhone() << std::endl;
        }
    }

    void displayHairstylists() const {
        for (const auto& hairstylist : hairstylists) {
            std::cout << "Hairstylist: " << hairstylist.getName() << ", Phone: " << hairstylist.getPhone() << std::endl;
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("Alice", "1234567890");
    salon.addHairstylist("Bob", "0987654321");

    salon.displayCustomers();
    salon.displayHairstylists();

    Customer* foundCustomer = salon.searchCustomer("Alice");
    if (foundCustomer) {
        std::cout << "Found Customer: " << foundCustomer->getName() << std::endl;
    }

    Hairstylist* foundHairstylist = salon.searchHairstylist("Bob");
    if (foundHairstylist) {
        std::cout << "Found Hairstylist: " << foundHairstylist->getName() << std::endl;
    }

    return 0;
}