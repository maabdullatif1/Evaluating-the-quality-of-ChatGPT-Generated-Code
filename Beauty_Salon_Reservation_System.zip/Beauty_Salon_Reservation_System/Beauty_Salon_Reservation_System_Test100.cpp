#include <iostream>
#include <vector>
#include <string>

struct Person {
    int id;
    std::string name;
    std::string contact;
};

class Salon {
    std::vector<Person> customers;
    std::vector<Person> stylists;
    int customerIdCounter;
    int stylistIdCounter;
    
public:
    Salon() : customerIdCounter(0), stylistIdCounter(0) {}

    void addCustomer(const std::string& name, const std::string& contact) {
        customers.push_back({++customerIdCounter, name, contact});
    }

    void addStylist(const std::string& name, const std::string& contact) {
        stylists.push_back({++stylistIdCounter, name, contact});
    }

    bool deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return true;
            }
        }
        return false;
    }

    bool deleteStylist(int id) {
        for (auto it = stylists.begin(); it != stylists.end(); ++it) {
            if (it->id == id) {
                stylists.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateCustomer(int id, const std::string& name, const std::string& contact) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                return true;
            }
        }
        return false;
    }

    bool updateStylist(int id, const std::string& name, const std::string& contact) {
        for (auto& stylist : stylists) {
            if (stylist.id == id) {
                stylist.name = name;
                stylist.contact = contact;
                return true;
            }
        }
        return false;
    }

    Person* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Person* searchStylist(int id) {
        for (auto& stylist : stylists) {
            if (stylist.id == id) {
                return &stylist;
            }
        }
        return nullptr;
    }

    void displayCustomers() const {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name
                      << ", Contact: " << customer.contact << std::endl;
        }
    }

    void displayStylists() const {
        for (const auto& stylist : stylists) {
            std::cout << "ID: " << stylist.id << ", Name: " << stylist.name
                      << ", Contact: " << stylist.contact << std::endl;
        }
    }
};

int main() {
    Salon salon;

    salon.addCustomer("Alice", "123456789");
    salon.addCustomer("Bob", "987654321");

    salon.addStylist("Charlie", "456123789");
    salon.addStylist("David", "789321654");

    salon.displayCustomers();
    salon.displayStylists();

    salon.updateCustomer(1, "Alice Smith", "111111111");
    salon.updateStylist(2, "David Black", "999999999");

    salon.displayCustomers();
    salon.displayStylists();

    salon.deleteCustomer(2);
    salon.deleteStylist(1);

    salon.displayCustomers();
    salon.displayStylists();

    return 0;
}