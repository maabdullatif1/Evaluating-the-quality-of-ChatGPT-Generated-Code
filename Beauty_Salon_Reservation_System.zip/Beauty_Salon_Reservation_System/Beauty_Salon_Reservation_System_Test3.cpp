#include <iostream>
#include <vector>
#include <string>

struct Person {
    int id;
    std::string name;
    std::string phone;
};

class BeautySalon {
    std::vector<Person> customers;
    std::vector<Person> hairstylists;
    int nextCustomerId = 1;
    int nextHairstylistId = 1;

    void displayPersons(const std::vector<Person>& persons) {
        for (const auto& person : persons) {
            std::cout << "ID: " << person.id
                      << ", Name: " << person.name
                      << ", Phone: " << person.phone << std::endl;
        }
    }

    Person* findPersonById(std::vector<Person>& persons, int id) {
        for (auto& person : persons) {
            if (person.id == id) {
                return &person;
            }
        }
        return nullptr;
    }

    void deletePersonById(std::vector<Person>& persons, int id) {
        for (auto it = persons.begin(); it != persons.end(); ++it) {
            if (it->id == id) {
                persons.erase(it);
                break;
            }
        }
    }

public:
    void addCustomer(const std::string& name, const std::string& phone) {
        customers.push_back({nextCustomerId++, name, phone});
    }

    void addHairstylist(const std::string& name, const std::string& phone) {
        hairstylists.push_back({nextHairstylistId++, name, phone});
    }

    void updateCustomer(int id, const std::string& name, const std::string& phone) {
        Person* customer = findPersonById(customers, id);
        if (customer) {
            customer->name = name;
            customer->phone = phone;
        }
    }

    void updateHairstylist(int id, const std::string& name, const std::string& phone) {
        Person* hairstylist = findPersonById(hairstylists, id);
        if (hairstylist) {
            hairstylist->name = name;
            hairstylist->phone = phone;
        }
    }

    void deleteCustomer(int id) {
        deletePersonById(customers, id);
    }

    void deleteHairstylist(int id) {
        deletePersonById(hairstylists, id);
    }

    Person* searchCustomer(int id) {
        return findPersonById(customers, id);
    }

    Person* searchHairstylist(int id) {
        return findPersonById(hairstylists, id);
    }

    void displayCustomers() {
        displayPersons(customers);
    }

    void displayHairstylists() {
        displayPersons(hairstylists);
    }
};

int main() {
    BeautySalon salon;
    salon.addCustomer("Alice", "1234567890");
    salon.addHairstylist("Bob", "0987654321");
    salon.displayCustomers();
    salon.displayHairstylists();
    
    Person* customer = salon.searchCustomer(1);
    if (customer) {
        std::cout << "Found Customer: " << customer->name << std::endl;
    }

    salon.updateCustomer(1, "Alicia", "1112223333");
    salon.displayCustomers();

    salon.deleteCustomer(1);
    salon.displayCustomers();

    return 0;
}