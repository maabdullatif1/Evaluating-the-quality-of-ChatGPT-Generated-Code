#include <iostream>
#include <string>

using namespace std;

struct Person {
    int id;
    string name;
    string phone;
};

class SalonSystem {
private:
    Person customers[100];
    Person hairstylists[50];
    int customerCount, hairstylistCount;

public:
    SalonSystem() : customerCount(0), hairstylistCount(0) {}

    void addCustomer(int id, const string& name, const string& phone) {
        customers[customerCount++] = {id, name, phone};
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i] = customers[--customerCount];
                break;
            }
        }
    }

    void updateCustomer(int id, const string& name, const string& phone) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i].name = name;
                customers[i].phone = phone;
                break;
            }
        }
    }

    Person* searchCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                return &customers[i];
            }
        }
        return nullptr;
    }

    void displayCustomers() const {
        for (int i = 0; i < customerCount; ++i) {
            cout << "Customer ID: " << customers[i].id 
                 << ", Name: " << customers[i].name
                 << ", Phone: " << customers[i].phone << endl;
        }
    }

    void addHairstylist(int id, const string& name, const string& phone) {
        hairstylists[hairstylistCount++] = {id, name, phone};
    }

    void deleteHairstylist(int id) {
        for (int i = 0; i < hairstylistCount; ++i) {
            if (hairstylists[i].id == id) {
                hairstylists[i] = hairstylists[--hairstylistCount];
                break;
            }
        }
    }

    void updateHairstylist(int id, const string& name, const string& phone) {
        for (int i = 0; i < hairstylistCount; ++i) {
            if (hairstylists[i].id == id) {
                hairstylists[i].name = name;
                hairstylists[i].phone = phone;
                break;
            }
        }
    }

    Person* searchHairstylist(int id) {
        for (int i = 0; i < hairstylistCount; ++i) {
            if (hairstylists[i].id == id) {
                return &hairstylists[i];
            }
        }
        return nullptr;
    }

    void displayHairstylists() const {
        for (int i = 0; i < hairstylistCount; ++i) {
            cout << "Hairstylist ID: " << hairstylists[i].id 
                 << ", Name: " << hairstylists[i].name
                 << ", Phone: " << hairstylists[i].phone << endl;
        }
    }
};

int main() {
    SalonSystem salon;

    salon.addCustomer(1, "Alice", "1234567890");
    salon.addCustomer(2, "Bob", "0987654321");
    salon.displayCustomers();

    salon.updateCustomer(1, "Alice A.", "1112223333");
    salon.displayCustomers();

    Person* customer = salon.searchCustomer(2);
    if (customer) {
        cout << "Found Customer: " << customer->name << endl;
    }

    salon.deleteCustomer(1);
    salon.displayCustomers();

    salon.addHairstylist(101, "Jane", "5556667777");
    salon.addHairstylist(102, "John", "8889990000");
    salon.displayHairstylists();

    salon.updateHairstylist(101, "Jane D.", "2223334444");
    salon.displayHairstylists();

    Person* stylist = salon.searchHairstylist(102);
    if (stylist) {
        cout << "Found Hairstylist: " << stylist->name << endl;
    }

    salon.deleteHairstylist(101);
    salon.displayHairstylists();

    return 0;
}