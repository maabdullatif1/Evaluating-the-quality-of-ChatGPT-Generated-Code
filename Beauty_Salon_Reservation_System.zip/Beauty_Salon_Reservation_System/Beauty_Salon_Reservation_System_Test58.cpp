#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
public:
    string name;
    string phone;

    Person(string n, string p) : name(n), phone(p) {}
};

class Customer : public Person {
public:
    Customer(string n, string p) : Person(n, p) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(string n, string p) : Person(n, p) {}
};

class Salon {
    vector<Customer> customers;
    vector<Hairstylist> hairstylists;

public:
    void addCustomer(string name, string phone) {
        customers.emplace_back(name, phone);
    }

    void deleteCustomer(int index) {
        if (index >= 0 && index < customers.size()) {
            customers.erase(customers.begin() + index);
        }
    }

    void updateCustomer(int index, string name, string phone) {
        if (index >= 0 && index < customers.size()) {
            customers[index].name = name;
            customers[index].phone = phone;
        }
    }

    int searchCustomer(string name) {
        for (int i = 0; i < customers.size(); ++i) {
            if (customers[i].name == name) return i;
        }
        return -1;
    }

    void displayCustomers() {
        for (int i = 0; i < customers.size(); ++i) {
            cout << "Customer " << i << ": " << customers[i].name
                 << ", Phone: " << customers[i].phone << endl;
        }
    }

    void addHairstylist(string name, string phone) {
        hairstylists.emplace_back(name, phone);
    }

    void deleteHairstylist(int index) {
        if (index >= 0 && index < hairstylists.size()) {
            hairstylists.erase(hairstylists.begin() + index);
        }
    }

    void updateHairstylist(int index, string name, string phone) {
        if (index >= 0 && index < hairstylists.size()) {
            hairstylists[index].name = name;
            hairstylists[index].phone = phone;
        }
    }

    int searchHairstylist(string name) {
        for (int i = 0; i < hairstylists.size(); ++i) {
            if (hairstylists[i].name == name) return i;
        }
        return -1;
    }

    void displayHairstylists() {
        for (int i = 0; i < hairstylists.size(); ++i) {
            cout << "Hairstylist " << i << ": " << hairstylists[i].name
                 << ", Phone: " << hairstylists[i].phone << endl;
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("Alice", "123");
    salon.addHairstylist("Bob", "456");
    
    salon.displayCustomers();
    salon.displayHairstylists();
    
    int customerIndex = salon.searchCustomer("Alice");
    int hairstylistIndex = salon.searchHairstylist("Bob");
    
    if (customerIndex != -1) {
        salon.updateCustomer(customerIndex, "Alice Updated", "789");
    }
    
    if (hairstylistIndex != -1) {
        salon.updateHairstylist(hairstylistIndex, "Bob Updated", "012");
    }
    
    salon.displayCustomers();
    salon.displayHairstylists();
    
    salon.deleteCustomer(customerIndex);
    salon.deleteHairstylist(hairstylistIndex);
    
    salon.displayCustomers();
    salon.displayHairstylists();
    
    return 0;
}