#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    std::string name;
    std::string phone;
public:
    Person(std::string n, std::string p) : name(n), phone(p) {}
    std::string getName() const { return name; }
    std::string getPhone() const { return phone; }
    virtual void display() const = 0;
};

class Customer : public Person {
public:
    Customer(std::string n, std::string p) : Person(n, p) {}
    void display() const override {
        std::cout << "Customer Name: " << name << ", Phone: " << phone << std::endl;
    }
};

class Hairstylist : public Person {
public:
    Hairstylist(std::string n, std::string p) : Person(n, p) {}
    void display() const override {
        std::cout << "Hairstylist Name: " << name << ", Phone: " << phone << std::endl;
    }
};

template<typename T>
class SalonManager {
    std::vector<T> records;
public:
    void add(const T &record) {
        records.push_back(record);
    }

    void remove(const std::string &name) {
        records.erase(std::remove_if(records.begin(), records.end(),
                     [&](const T& r) { return r.getName() == name; }), records.end());
    }

    T* search(const std::string &name) {
        for (auto &r : records) {
            if (r.getName() == name) return &r;
        }
        return nullptr;
    }
    
    void update(const std::string &name, const std::string &newPhone) {
        for (auto &r : records) {
            if (r.getName() == name) {
                r = T(name, newPhone);
                break;
            }
        }
    }

    void displayAll() const {
        for (const auto &r : records) {
            r.display();
        }
    }
};

int main() {
    SalonManager<Customer> customerManager;
    SalonManager<Hairstylist> hairstylistManager;

    customerManager.add(Customer("Alice", "123456789"));
    customerManager.add(Customer("Bob", "987654321"));
    
    hairstylistManager.add(Hairstylist("Jill", "555444333"));
    hairstylistManager.add(Hairstylist("Jack", "666555444"));

    std::cout << "Customers:" << std::endl;
    customerManager.displayAll();
    
    std::cout << "Hairstylists:" << std::endl;
    hairstylistManager.displayAll();

    customerManager.update("Alice", "111222333");
    customerManager.remove("Bob");

    std::cout << "Updated Customers:" << std::endl;
    customerManager.displayAll();
    
    return 0;
}