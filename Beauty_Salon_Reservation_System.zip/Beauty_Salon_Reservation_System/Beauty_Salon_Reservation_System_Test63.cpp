#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
public:
    int id;
    string name;
};

class Customer : public Person {
public:
    string phoneNumber;
};

class Hairstylist : public Person {
public:
    string specialty;
};

class SalonReservationSystem {
    vector<Customer> customers;
    vector<Hairstylist> hairstylists;
    int customerIdCounter = 1;
    int stylistIdCounter = 1;

public:
    void addCustomer(const string& name, const string& phoneNumber) {
        Customer customer;
        customer.id = customerIdCounter++;
        customer.name = name;
        customer.phoneNumber = phoneNumber;
        customers.push_back(customer);
    }

    void addHairstylist(const string& name, const string& specialty) {
        Hairstylist stylist;
        stylist.id = stylistIdCounter++;
        stylist.name = name;
        stylist.specialty = specialty;
        hairstylists.push_back(stylist);
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void deleteHairstylist(int id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->id == id) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const string& newName, const string& newPhoneNumber) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = newName;
                customer.phoneNumber = newPhoneNumber;
                break;
            }
        }
    }

    void updateHairstylist(int id, const string& newName, const string& newSpecialty) {
        for (auto& stylist : hairstylists) {
            if (stylist.id == id) {
                stylist.name = newName;
                stylist.specialty = newSpecialty;
                break;
            }
        }
    }

    void searchCustomer(int id) const {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                cout << "Customer ID: " << customer.id << ", Name: " << customer.name 
                     << ", Phone: " << customer.phoneNumber << endl;
                return;
            }
        }
        cout << "Customer not found" << endl;
    }

    void searchHairstylist(int id) const {
        for (const auto& stylist : hairstylists) {
            if (stylist.id == id) {
                cout << "Hairstylist ID: " << stylist.id << ", Name: " << stylist.name 
                     << ", Specialty: " << stylist.specialty << endl;
                return;
            }
        }
        cout << "Hairstylist not found" << endl;
    }

    void displayCustomers() const {
        for (const auto& customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name 
                 << ", Phone: " << customer.phoneNumber << endl;
        }
    }

    void displayHairstylists() const {
        for (const auto& stylist : hairstylists) {
            cout << "Hairstylist ID: " << stylist.id << ", Name: " << stylist.name 
                 << ", Specialty: " << stylist.specialty << endl;
        }
    }
};

int main() {
    SalonReservationSystem system;
    system.addCustomer("Alice", "123456789");
    system.addHairstylist("Bob", "Curly Hair");
    system.displayCustomers();
    system.displayHairstylists();
    system.updateCustomer(1, "Alice Johnson", "987654321");
    system.searchCustomer(1);
    system.deleteHairstylist(1);
    system.displayHairstylists();
}