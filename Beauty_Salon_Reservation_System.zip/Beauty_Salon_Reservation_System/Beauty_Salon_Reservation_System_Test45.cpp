#include <iostream>
#include <string>

using namespace std;

struct Person {
    int id;
    string name;
    string contact;
};

class SalonReservationSystem {
    Person customers[100];
    Person stylists[100];
    int customerCount;
    int stylistCount;

public:
    SalonReservationSystem() : customerCount(0), stylistCount(0) {}

    void addCustomer(int id, const string& name, const string& contact) {
        customers[customerCount++] = {id, name, contact};
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                for (int j = i; j < customerCount - 1; ++j) {
                    customers[j] = customers[j + 1];
                }
                customerCount--;
                break;
            }
        }
    }

    void updateCustomer(int id, const string& name, const string& contact) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i].name = name;
                customers[i].contact = contact;
                break;
            }
        }
    }

    Person* searchCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                return &customers[i];
            }
        }
        return nullptr;
    }

    void displayCustomers() const {
        for (int i = 0; i < customerCount; ++i) {
            cout << "ID: " << customers[i].id
                 << ", Name: " << customers[i].name
                 << ", Contact: " << customers[i].contact << endl;
        }
    }

    void addStylist(int id, const string& name, const string& contact) {
        stylists[stylistCount++] = {id, name, contact};
    }

    void deleteStylist(int id) {
        for (int i = 0; i < stylistCount; ++i) {
            if (stylists[i].id == id) {
                for (int j = i; j < stylistCount - 1; ++j) {
                    stylists[j] = stylists[j + 1];
                }
                stylistCount--;
                break;
            }
        }
    }

    void updateStylist(int id, const string& name, const string& contact) {
        for (int i = 0; i < stylistCount; ++i) {
            if (stylists[i].id == id) {
                stylists[i].name = name;
                stylists[i].contact = contact;
                break;
            }
        }
    }

    Person* searchStylist(int id) {
        for (int i = 0; i < stylistCount; ++i) {
            if (stylists[i].id == id) {
                return &stylists[i];
            }
        }
        return nullptr;
    }

    void displayStylists() const {
        for (int i = 0; i < stylistCount; ++i) {
            cout << "ID: " << stylists[i].id
                 << ", Name: " << stylists[i].name
                 << ", Contact: " << stylists[i].contact << endl;
        }
    }
};

int main() {
    SalonReservationSystem system;

    system.addCustomer(1, "Alice", "123-456-7890");
    system.addCustomer(2, "Bob", "234-567-8901");
    system.displayCustomers();

    system.addStylist(101, "John", "345-678-9012");
    system.addStylist(102, "Jane", "456-789-0123");
    system.displayStylists();

    system.updateCustomer(1, "Alice Smith", "123-456-7899");
    system.displayCustomers();

    system.deleteCustomer(2);
    system.displayCustomers();

    return 0;
}