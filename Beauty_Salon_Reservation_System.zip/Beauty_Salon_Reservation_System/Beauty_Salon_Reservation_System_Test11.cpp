#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
};

struct Hairstylist {
    int id;
    string name;
};

class BeautySalon {
    Customer customers[100];
    int customerCount;
    Hairstylist stylists[100];
    int stylistCount;

public:
    BeautySalon() : customerCount(0), stylistCount(0) {}

    void addCustomer(int id, string name) {
        customers[customerCount++] = {id, name};
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                for (int j = i; j < customerCount - 1; ++j) {
                    customers[j] = customers[j + 1];
                }
                --customerCount;
                break;
            }
        }
    }

    void updateCustomer(int id, string name) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i].name = name;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                return &customers[i];
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; ++i) {
            cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << endl;
        }
    }

    void addHairstylist(int id, string name) {
        stylists[stylistCount++] = {id, name};
    }

    void deleteHairstylist(int id) {
        for (int i = 0; i < stylistCount; ++i) {
            if (stylists[i].id == id) {
                for (int j = i; j < stylistCount - 1; ++j) {
                    stylists[j] = stylists[j + 1];
                }
                --stylistCount;
                break;
            }
        }
    }

    void updateHairstylist(int id, string name) {
        for (int i = 0; i < stylistCount; ++i) {
            if (stylists[i].id == id) {
                stylists[i].name = name;
                break;
            }
        }
    }

    Hairstylist* searchHairstylist(int id) {
        for (int i = 0; i < stylistCount; ++i) {
            if (stylists[i].id == id) {
                return &stylists[i];
            }
        }
        return nullptr;
    }

    void displayHairstylists() {
        for (int i = 0; i < stylistCount; ++i) {
            cout << "Hairstylist ID: " << stylists[i].id << ", Name: " << stylists[i].name << endl;
        }
    }
};

int main() {
    BeautySalon salon;

    salon.addCustomer(1, "Alice");
    salon.addCustomer(2, "Bob");

    salon.addHairstylist(1, "Charlie");
    salon.addHairstylist(2, "Dana");

    cout << "Customers:" << endl;
    salon.displayCustomers();

    cout << "Hairstylists:" << endl;
    salon.displayHairstylists();

    return 0;
}