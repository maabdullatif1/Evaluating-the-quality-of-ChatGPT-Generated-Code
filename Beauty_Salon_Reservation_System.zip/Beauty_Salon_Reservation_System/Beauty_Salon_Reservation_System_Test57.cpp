#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
public:
    string name;
    string phone;
};

class Customer : public Person {
public:
    int id;
};

class Hairstylist : public Person {
public:
    int id;
};

class Salon {
    vector<Customer> customers;
    vector<Hairstylist> hairstylists;
    
    int findCustomerIndex(int id) {
        for (int i = 0; i < customers.size(); ++i)
            if (customers[i].id == id) return i;
        return -1;
    }
    
    int findHairstylistIndex(int id) {
        for (int i = 0; i < hairstylists.size(); ++i)
            if (hairstylists[i].id == id) return i;
        return -1;
    }
    
public:
    void addCustomer(string name, string phone, int id) {
        if (findCustomerIndex(id) != -1) return;
        Customer c;
        c.name = name;
        c.phone = phone;
        c.id = id;
        customers.push_back(c);
    }
    
    void deleteCustomer(int id) {
        int index = findCustomerIndex(id);
        if (index == -1) return;
        customers.erase(customers.begin() + index);
    }
    
    void updateCustomer(int id, string name, string phone) {
        int index = findCustomerIndex(id);
        if (index == -1) return;
        customers[index].name = name;
        customers[index].phone = phone;
    }
    
    Customer* searchCustomer(int id) {
        int index = findCustomerIndex(id);
        return index == -1 ? nullptr : &customers[index];
    }
    
    void displayCustomers() {
        for (auto &c : customers) {
            cout << "ID: " << c.id << ", Name: " << c.name << ", Phone: " << c.phone << endl;
        }
    }
    
    void addHairstylist(string name, string phone, int id) {
        if (findHairstylistIndex(id) != -1) return;
        Hairstylist h;
        h.name = name;
        h.phone = phone;
        h.id = id;
        hairstylists.push_back(h);
    }
    
    void deleteHairstylist(int id) {
        int index = findHairstylistIndex(id);
        if (index == -1) return;
        hairstylists.erase(hairstylists.begin() + index);
    }
    
    void updateHairstylist(int id, string name, string phone) {
        int index = findHairstylistIndex(id);
        if (index == -1) return;
        hairstylists[index].name = name;
        hairstylists[index].phone = phone;
    }
    
    Hairstylist* searchHairstylist(int id) {
        int index = findHairstylistIndex(id);
        return index == -1 ? nullptr : &hairstylists[index];
    }
    
    void displayHairstylists() {
        for (auto &h : hairstylists) {
            cout << "ID: " << h.id << ", Name: " << h.name << ", Phone: " << h.phone << endl;
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("Alice", "12345", 1);
    salon.addHairstylist("Bob", "67890", 101);
    salon.displayCustomers();
    salon.displayHairstylists();
    return 0;
}