#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string phone;
};

struct Hairstylist {
    int id;
    string name;
    string specialty;
};

Customer customers[100];
Hairstylist hairstylists[50];
int customerCount = 0;
int hairstylistCount = 0;

void addCustomer() {
    cout << "Enter Customer ID: ";
    cin >> customers[customerCount].id;
    cout << "Enter Customer Name: ";
    cin.ignore();
    getline(cin, customers[customerCount].name);
    cout << "Enter Customer Phone: ";
    getline(cin, customers[customerCount].phone);
    customerCount++;
}

void deleteCustomer() {
    int id;
    cout << "Enter Customer ID to delete: ";
    cin >> id;
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; j++) {
                customers[j] = customers[j + 1];
            }
            customerCount--;
            break;
        }
    }
}

void updateCustomer() {
    int id;
    cout << "Enter Customer ID to update: ";
    cin >> id;
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            cout << "Enter new Customer Name: ";
            cin.ignore();
            getline(cin, customers[i].name);
            cout << "Enter new Customer Phone: ";
            getline(cin, customers[i].phone);
            break;
        }
    }
}

void searchCustomer() {
    int id;
    cout << "Enter Customer ID to search: ";
    cin >> id;
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << ", Phone: " << customers[i].phone << endl;
            return;
        }
    }
    cout << "Customer not found." << endl;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; i++) {
        cout << "ID: " << customers[i].id << ", Name: " << customers[i].name << ", Phone: " << customers[i].phone << endl;
    }
}

void addHairstylist() {
    cout << "Enter Hairstylist ID: ";
    cin >> hairstylists[hairstylistCount].id;
    cout << "Enter Hairstylist Name: ";
    cin.ignore();
    getline(cin, hairstylists[hairstylistCount].name);
    cout << "Enter Hairstylist Specialty: ";
    getline(cin, hairstylists[hairstylistCount].specialty);
    hairstylistCount++;
}

void deleteHairstylist() {
    int id;
    cout << "Enter Hairstylist ID to delete: ";
    cin >> id;
    for (int i = 0; i < hairstylistCount; i++) {
        if (hairstylists[i].id == id) {
            for (int j = i; j < hairstylistCount - 1; j++) {
                hairstylists[j] = hairstylists[j + 1];
            }
            hairstylistCount--;
            break;
        }
    }
}

void updateHairstylist() {
    int id;
    cout << "Enter Hairstylist ID to update: ";
    cin >> id;
    for (int i = 0; i < hairstylistCount; i++) {
        if (hairstylists[i].id == id) {
            cout << "Enter new Hairstylist Name: ";
            cin.ignore();
            getline(cin, hairstylists[i].name);
            cout << "Enter new Hairstylist Specialty: ";
            getline(cin, hairstylists[i].specialty);
            break;
        }
    }
}

void searchHairstylist() {
    int id;
    cout << "Enter Hairstylist ID to search: ";
    cin >> id;
    for (int i = 0; i < hairstylistCount; i++) {
        if (hairstylists[i].id == id) {
            cout << "Hairstylist ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name << ", Specialty: " << hairstylists[i].specialty << endl;
            return;
        }
    }
    cout << "Hairstylist not found." << endl;
}

void displayHairstylists() {
    for (int i = 0; i < hairstylistCount; i++) {
        cout << "ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name << ", Specialty: " << hairstylists[i].specialty << endl;
    }
}

int main() {
    int option;
    do {
        cout << "1. Add Customer\n2. Delete Customer\n3. Update Customer\n4. Search Customer\n5. Display Customers\n";
        cout << "6. Add Hairstylist\n7. Delete Hairstylist\n8. Update Hairstylist\n9. Search Hairstylist\n10. Display Hairstylists\n0. Exit\n";
        cin >> option;
        switch (option) {
            case 1: addCustomer(); break;
            case 2: deleteCustomer(); break;
            case 3: updateCustomer(); break;
            case 4: searchCustomer(); break;
            case 5: displayCustomers(); break;
            case 6: addHairstylist(); break;
            case 7: deleteHairstylist(); break;
            case 8: updateHairstylist(); break;
            case 9: searchHairstylist(); break;
            case 10: displayHairstylists(); break;
        }
    } while (option != 0);
    return 0;
}