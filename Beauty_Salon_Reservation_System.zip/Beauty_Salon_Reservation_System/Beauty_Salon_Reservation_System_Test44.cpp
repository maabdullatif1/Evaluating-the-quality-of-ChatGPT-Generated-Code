#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    int id;
    string name;
};

class SalonManagementSystem {
    vector<Person> customers;
    vector<Person> hairstylists;
    int customerCounter;
    int hairstylistCounter;

public:
    SalonManagementSystem() : customerCounter(0), hairstylistCounter(0) {}

    void addCustomer(const string &name) {
        customers.push_back({++customerCounter, name});
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void updateCustomer(int id, const string &name) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                return;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto &customer : customers) {
            if (customer.id == id) {
                cout << "Customer ID: " << customer.id << ", Name: " << customer.name << endl;
                return;
            }
        }
        cout << "Customer not found" << endl;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << endl;
        }
    }

    void addHairstylist(const string &name) {
        hairstylists.push_back({++hairstylistCounter, name});
    }

    void deleteHairstylist(int id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->id == id) {
                hairstylists.erase(it);
                return;
            }
        }
    }

    void updateHairstylist(int id, const string &name) {
        for (auto &hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                hairstylist.name = name;
                return;
            }
        }
    }

    void searchHairstylist(int id) {
        for (const auto &hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                cout << "Hairstylist ID: " << hairstylist.id << ", Name: " << hairstylist.name << endl;
                return;
            }
        }
        cout << "Hairstylist not found" << endl;
    }

    void displayHairstylists() {
        for (const auto &hairstylist : hairstylists) {
            cout << "Hairstylist ID: " << hairstylist.id << ", Name: " << hairstylist.name << endl;
        }
    }
};

int main() {
    SalonManagementSystem system;
    system.addCustomer("Alice");
    system.addCustomer("Bob");
    system.displayCustomers();
    system.updateCustomer(1, "Alice Johnson");
    system.displayCustomers();
    system.deleteCustomer(2);
    system.displayCustomers();
    system.addHairstylist("Carol");
    system.addHairstylist("Dave");
    system.displayHairstylists();
    system.updateHairstylist(1, "Carol Smith");
    system.displayHairstylists();
    system.deleteHairstylist(2);
    system.displayHairstylists();
    return 0;
}