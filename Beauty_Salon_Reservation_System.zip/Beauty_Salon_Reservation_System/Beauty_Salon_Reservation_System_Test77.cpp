#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string contact;
};

struct Hairstylist {
    int id;
    string name;
    string expertise;
};

class SalonReservationSystem {
    vector<Customer> customers;
    vector<Hairstylist> hairstylists;
    int customerIDCounter;
    int hairstylistIDCounter;

public:
    SalonReservationSystem() : customerIDCounter(0), hairstylistIDCounter(0) {}

    void addCustomer(string name, string contact) {
        customers.push_back({customerIDCounter++, name, contact});
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, string name, string contact) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }
    
    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
                return;
            }
        }
        cout << "Customer not found." << endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
        }
    }

    void addHairstylist(string name, string expertise) {
        hairstylists.push_back({hairstylistIDCounter++, name, expertise});
    }
    
    void deleteHairstylist(int id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->id == id) {
                hairstylists.erase(it);
                break;
            }
        }
    }
    
    void updateHairstylist(int id, string name, string expertise) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                hairstylist.name = name;
                hairstylist.expertise = expertise;
                break;
            }
        }
    }
    
    void searchHairstylist(int id) {
        for (const auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                cout << "Hairstylist ID: " << hairstylist.id << ", Name: " << hairstylist.name << ", Expertise: " << hairstylist.expertise << endl;
                return;
            }
        }
        cout << "Hairstylist not found." << endl;
    }

    void displayHairstylists() {
        for (const auto& hairstylist : hairstylists) {
            cout << "Hairstylist ID: " << hairstylist.id << ", Name: " << hairstylist.name << ", Expertise: " << hairstylist.expertise << endl;
        }
    }
};

int main() {
    SalonReservationSystem system;

    system.addCustomer("Alice", "123-456-7890");
    system.addCustomer("Bob", "234-567-8901");
    system.addHairstylist("Charlie", "Cuts");
    system.addHairstylist("Daisy", "Coloring");

    cout << "Initial Customers:" << endl;
    system.displayCustomers();

    cout << "Initial Hairstylists:" << endl;
    system.displayHairstylists();

    system.updateCustomer(0, "Alice Smith", "123-456-7890");
    system.updateHairstylist(1, "Daisy Mae", "Coloring & Styling");

    cout << "Updated Customers:" << endl;
    system.displayCustomers();

    cout << "Updated Hairstylists:" << endl;
    system.displayHairstylists();

    system.searchCustomer(0);
    system.searchHairstylist(1);

    system.deleteCustomer(1);
    system.deleteHairstylist(0);

    cout << "Final Customers:" << endl;
    system.displayCustomers();

    cout << "Final Hairstylists:" << endl;
    system.displayHairstylists();

    return 0;
}