#include <iostream>
#include <string>
#include <vector>

class Person {
public:
    std::string id;
    std::string name;
    std::string phone;
};

class Customer : public Person {
};

class Hairstylist : public Person {
};

class Salon {
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

    template<typename T>
    T* search(std::vector<T> &collection, const std::string &id) {
        for (auto &item : collection) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

public:
    void addCustomer(const std::string &id, const std::string &name, const std::string &phone) {
        customers.push_back({id, name, phone});
    }

    void addHairstylist(const std::string &id, const std::string &name, const std::string &phone) {
        hairstylists.push_back({id, name, phone});
    }

    void deleteCustomer(const std::string &id) {
        customers.erase(
            std::remove_if(customers.begin(), customers.end(), [&](Customer &c) { return c.id == id; }),
            customers.end());
    }

    void deleteHairstylist(const std::string &id) {
        hairstylists.erase(
            std::remove_if(hairstylists.begin(), hairstylists.end(), [&](Hairstylist &h) { return h.id == id; }),
            hairstylists.end());
    }

    void updateCustomer(const std::string &id, const std::string &name, const std::string &phone) {
        Customer *customer = search(customers, id);
        if (customer) {
            customer->name = name;
            customer->phone = phone;
        }
    }

    void updateHairstylist(const std::string &id, const std::string &name, const std::string &phone) {
        Hairstylist *hairstylist = search(hairstylists, id);
        if (hairstylist) {
            hairstylist->name = name;
            hairstylist->phone = phone;
        }
    }

    void searchCustomer(const std::string &id) {
        Customer *customer = search(customers, id);
        if (customer) {
            std::cout << "Customer found: ID=" << customer->id << ", Name=" << customer->name << ", Phone=" << customer->phone << std::endl;
        } else {
            std::cout << "Customer not found" << std::endl;
        }
    }

    void searchHairstylist(const std::string &id) {
        Hairstylist *hairstylist = search(hairstylists, id);
        if (hairstylist) {
            std::cout << "Hairstylist found: ID=" << hairstylist->id << ", Name=" << hairstylist->name << ", Phone=" << hairstylist->phone << std::endl;
        } else {
            std::cout << "Hairstylist not found" << std::endl;
        }
    }

    void displayCustomers() {
        std::cout << "Customers List:" << std::endl;
        for (const auto &customer : customers) {
            std::cout << "ID=" << customer.id << ", Name=" << customer.name << ", Phone=" << customer.phone << std::endl;
        }
    }

    void displayHairstylists() {
        std::cout << "Hairstylists List:" << std::endl;
        for (const auto &hairstylist : hairstylists) {
            std::cout << "ID=" << hairstylist.id << ", Name=" << hairstylist.name << ", Phone=" << hairstylist.phone << std::endl;
        }
    }
};

int main() {
    Salon salon;
    salon.addCustomer("C001", "Alice", "123-456-7890");
    salon.addCustomer("C002", "Bob", "234-567-8901");
    salon.addHairstylist("H001", "Eve", "345-678-9012");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.searchCustomer("C001");
    salon.updateCustomer("C001", "Alice Smith", "987-654-3210");
    salon.searchCustomer("C001");
    salon.deleteCustomer("C002");
    salon.displayCustomers();

    return 0;
}