#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    int id;
    string name;
    string contact;
};

class SalonReservationSystem {
    vector<Person> customers;
    vector<Person> hairstylists;
    int customerIdCounter = 1;
    int hairstylistIdCounter = 1;

public:
    void addCustomer(const string& name, const string& contact) {
        customers.push_back({customerIdCounter++, name, contact});
    }

    void addHairstylist(const string& name, const string& contact) {
        hairstylists.push_back({hairstylistIdCounter++, name, contact});
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void deleteHairstylist(int id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->id == id) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const string& name, const string& contact) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.contact = contact;
                break;
            }
        }
    }

    void updateHairstylist(int id, const string& name, const string& contact) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                hairstylist.name = name;
                hairstylist.contact = contact;
                break;
            }
        }
    }

    Person* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Person* searchHairstylist(int id) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                return &hairstylist;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        cout << "Customers: " << endl;
        for (const auto& customer : customers) {
            cout << "ID: " << customer.id << ", Name: " << customer.name << ", Contact: " << customer.contact << endl;
        }
    }

    void displayHairstylists() {
        cout << "Hairstylists: " << endl;
        for (const auto& hairstylist : hairstylists) {
            cout << "ID: " << hairstylist.id << ", Name: " << hairstylist.name << ", Contact: " << hairstylist.contact << endl;
        }
    }
};

int main() {
    SalonReservationSystem salon;
    salon.addCustomer("Alice", "1234567890");
    salon.addHairstylist("Bob", "0987654321");
    salon.displayCustomers();
    salon.displayHairstylists();
    salon.updateCustomer(1, "Alice Smith", "1234567899");
    salon.deleteHairstylist(1);
    salon.displayCustomers();
    salon.displayHairstylists();
    return 0;
}