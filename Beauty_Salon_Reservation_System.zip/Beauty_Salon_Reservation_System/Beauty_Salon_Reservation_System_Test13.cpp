#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    int id;
    std::string name;
    Person(int id, std::string name) : id(id), name(name) {}
};

class Customer : public Person {
public:
    Customer(int id, std::string name) : Person(id, name) {}
};

class Hairstylist : public Person {
public:
    Hairstylist(int id, std::string name) : Person(id, name) {}
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;

public:
    void addCustomer(int id, std::string name) {
        customers.push_back(Customer(id, name));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string newName) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = newName;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << std::endl;
                return;
            }
        }
        std::cout << "Customer not found." << std::endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name << std::endl;
        }
    }

    void addHairstylist(int id, std::string name) {
        hairstylists.push_back(Hairstylist(id, name));
    }

    void deleteHairstylist(int id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->id == id) {
                hairstylists.erase(it);
                break;
            }
        }
    }

    void updateHairstylist(int id, std::string newName) {
        for (auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                hairstylist.name = newName;
                break;
            }
        }
    }

    void searchHairstylist(int id) {
        for (const auto& hairstylist : hairstylists) {
            if (hairstylist.id == id) {
                std::cout << "Hairstylist ID: " << hairstylist.id << ", Name: " << hairstylist.name << std::endl;
                return;
            }
        }
        std::cout << "Hairstylist not found." << std::endl;
    }

    void displayHairstylists() {
        for (const auto& hairstylist : hairstylists) {
            std::cout << "Hairstylist ID: " << hairstylist.id << ", Name: " << hairstylist.name << std::endl;
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "Alice");
    system.addCustomer(2, "Bob");
    system.displayCustomers();
    system.updateCustomer(1, "Alicia");
    system.searchCustomer(1);
    system.deleteCustomer(2);
    system.displayCustomers();

    system.addHairstylist(1, "Charles");
    system.addHairstylist(2, "Dana");
    system.displayHairstylists();
    system.updateHairstylist(1, "Chuck");
    system.searchHairstylist(1);
    system.deleteHairstylist(2);
    system.displayHairstylists();

    return 0;
}