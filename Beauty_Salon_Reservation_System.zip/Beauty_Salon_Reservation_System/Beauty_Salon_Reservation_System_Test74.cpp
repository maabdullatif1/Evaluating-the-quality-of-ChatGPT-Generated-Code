#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string phone;

    Customer(int i, std::string n, std::string p) : id(i), name(n), phone(p) {}

    void display() {
        std::cout << "Customer ID: " << id << ", Name: " << name << ", Phone: " << phone << std::endl;
    }
};

class Hairstylist {
public:
    int id;
    std::string name;
    std::string expertise;

    Hairstylist(int i, std::string n, std::string e) : id(i), name(n), expertise(e) {}

    void display() {
        std::cout << "Hairstylist ID: " << id << ", Name: " << name << ", Expertise: " << expertise << std::endl;
    }
};

class ReservationSystem {
private:
    std::vector<Customer> customers;
    std::vector<Hairstylist> hairstylists;
    
public:
    void addCustomer(int id, std::string name, std::string phone) {
        customers.push_back(Customer(id, name, phone));
    }

    void updateCustomer(int id, std::string name, std::string phone) {
        for (auto &cus : customers) {
            if (cus.id == id) {
                cus.name = name;
                cus.phone = phone;
                return;
            }
        }
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto &cus : customers) {
            if (cus.id == id) {
                cus.display();
                return;
            }
        }
    }

    void displayCustomers() {
        for (const auto &cus : customers) {
            cus.display();
        }
    }
    
    void addHairstylist(int id, std::string name, std::string expertise) {
        hairstylists.push_back(Hairstylist(id, name, expertise));
    }

    void updateHairstylist(int id, std::string name, std::string expertise) {
        for (auto &hs : hairstylists) {
            if (hs.id == id) {
                hs.name = name;
                hs.expertise = expertise;
                return;
            }
        }
    }

    void deleteHairstylist(int id) {
        for (auto it = hairstylists.begin(); it != hairstylists.end(); ++it) {
            if (it->id == id) {
                hairstylists.erase(it);
                return;
            }
        }
    }

    void searchHairstylist(int id) {
        for (const auto &hs : hairstylists) {
            if (hs.id == id) {
                hs.display();
                return;
            }
        }
    }

    void displayHairstylists() {
        for (const auto &hs : hairstylists) {
            hs.display();
        }
    }
};

int main() {
    ReservationSystem system;
    system.addCustomer(1, "Alice", "123456789");
    system.addCustomer(2, "Bob", "987654321");
    system.addHairstylist(1, "Charlie", "Coloring");
    system.addHairstylist(2, "Dave", "Cutting");
    system.displayCustomers();
    system.displayHairstylists();
    system.updateCustomer(1, "Alice Johnson", "123123123");
    system.searchCustomer(1);
    system.deleteCustomer(2);
    system.displayCustomers();
    system.updateHairstylist(1, "Charlie Brown", "Styling");
    system.searchHairstylist(1);
    system.deleteHairstylist(2);
    system.displayHairstylists();
    return 0;
}