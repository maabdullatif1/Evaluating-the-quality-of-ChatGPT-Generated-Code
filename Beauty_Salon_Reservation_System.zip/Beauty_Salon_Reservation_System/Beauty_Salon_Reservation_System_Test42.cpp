#include <iostream>
#include <string>

class Person {
public:
    std::string name;
    std::string phone;
};

class Customer : public Person {
public:
    void input() {
        std::cout << "Enter customer's name: ";
        std::cin >> name;
        std::cout << "Enter customer's phone: ";
        std::cin >> phone;
    }

    void display() {
        std::cout << "Customer Name: " << name << ", Phone: " << phone << std::endl;
    }
};

class Hairstylist : public Person {
public:
    void input() {
        std::cout << "Enter hairstylist's name: ";
        std::cin >> name;
        std::cout << "Enter hairstylist's phone: ";
        std::cin >> phone;
    }

    void display() {
        std::cout << "Hairstylist Name: " << name << ", Phone: " << phone << std::endl;
    }
};

class SalonReservationSystem {
    Customer customers[100];
    Hairstylist stylists[100];
    int customerCount = 0;
    int stylistCount = 0;

public:
    void addCustomer() {
        customers[customerCount++].input();
    }

    void addHairstylist() {
        stylists[stylistCount++].input();
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; ++i) {
            customers[i].display();
        }
    }

    void displayHairstylists() {
        for (int i = 0; i < stylistCount; ++i) {
            stylists[i].display();
        }
    }

    void deleteCustomer() {
        std::string name;
        std::cout << "Enter customer's name to delete: ";
        std::cin >> name;
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].name == name) {
                for (int j = i; j < customerCount - 1; ++j) {
                    customers[j] = customers[j + 1];
                }
                --customerCount;
                break;
            }
        }
    }

    void deleteHairstylist() {
        std::string name;
        std::cout << "Enter hairstylist's name to delete: ";
        std::cin >> name;
        for (int i = 0; i < stylistCount; ++i) {
            if (stylists[i].name == name) {
                for (int j = i; j < stylistCount - 1; ++j) {
                    stylists[j] = stylists[j + 1];
                }
                --stylistCount;
                break;
            }
        }
    }

    void updateCustomer() {
        std::string name;
        std::cout << "Enter customer's name to update: ";
        std::cin >> name;
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].name == name) {
                customers[i].input();
                break;
            }
        }
    }

    void updateHairstylist() {
        std::string name;
        std::cout << "Enter hairstylist's name to update: ";
        std::cin >> name;
        for (int i = 0; i < stylistCount; ++i) {
            if (stylists[i].name == name) {
                stylists[i].input();
                break;
            }
        }
    }

    void searchCustomer() {
        std::string name;
        std::cout << "Enter customer's name to search: ";
        std::cin >> name;
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].name == name) {
                customers[i].display();
                break;
            }
        }
    }

    void searchHairstylist() {
        std::string name;
        std::cout << "Enter hairstylist's name to search: ";
        std::cin >> name;
        for (int i = 0; i < stylistCount; ++i) {
            if (stylists[i].name == name) {
                stylists[i].display();
                break;
            }
        }
    }
};

int main() {
    SalonReservationSystem system;
    int choice;
    do {
        std::cout << "1. Add Customer\n2. Add Hairstylist\n3. Display Customers\n4. Display Hairstylists\n5. Delete Customer\n6. Delete Hairstylist\n7. Update Customer\n8. Update Hairstylist\n9. Search Customer\n10. Search Hairstylist\n0. Exit\n";
        std::cin >> choice;
        switch (choice) {
        case 1: system.addCustomer(); break;
        case 2: system.addHairstylist(); break;
        case 3: system.displayCustomers(); break;
        case 4: system.displayHairstylists(); break;
        case 5: system.deleteCustomer(); break;
        case 6: system.deleteHairstylist(); break;
        case 7: system.updateCustomer(); break;
        case 8: system.updateHairstylist(); break;
        case 9: system.searchCustomer(); break;
        case 10: system.searchHairstylist(); break;
        }
    } while (choice != 0);
    return 0;
}