#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string contact;
};

struct Hairstylist {
    int id;
    string name;
    string specialty;
};

const int MAX_ENTRIES = 100;
Customer customers[MAX_ENTRIES];
Hairstylist hairstylists[MAX_ENTRIES];
int customer_count = 0;
int hairstylist_count = 0;

void addCustomer(int id, string name, string contact) {
    if (customer_count < MAX_ENTRIES) {
        customers[customer_count] = {id, name, contact};
        customer_count++;
    }
}

void deleteCustomer(int id) {
    for (int i = 0; i < customer_count; i++) {
        if (customers[i].id == id) {
            for (int j = i; j < customer_count - 1; j++) {
                customers[j] = customers[j + 1];
            }
            customer_count--;
            break;
        }
    }
}

void updateCustomer(int id, string name, string contact) {
    for (int i = 0; i < customer_count; i++) {
        if (customers[i].id == id) {
            customers[i].name = name;
            customers[i].contact = contact;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customer_count; i++) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customer_count; i++) {
        cout << "ID: " << customers[i].id << ", Name: " << customers[i].name
             << ", Contact: " << customers[i].contact << endl;
    }
}

void addHairstylist(int id, string name, string specialty) {
    if (hairstylist_count < MAX_ENTRIES) {
        hairstylists[hairstylist_count] = {id, name, specialty};
        hairstylist_count++;
    }
}

void deleteHairstylist(int id) {
    for (int i = 0; i < hairstylist_count; i++) {
        if (hairstylists[i].id == id) {
            for (int j = i; j < hairstylist_count - 1; j++) {
                hairstylists[j] = hairstylists[j + 1];
            }
            hairstylist_count--;
            break;
        }
    }
}

void updateHairstylist(int id, string name, string specialty) {
    for (int i = 0; i < hairstylist_count; i++) {
        if (hairstylists[i].id == id) {
            hairstylists[i].name = name;
            hairstylists[i].specialty = specialty;
            break;
        }
    }
}

Hairstylist* searchHairstylist(int id) {
    for (int i = 0; i < hairstylist_count; i++) {
        if (hairstylists[i].id == id) {
            return &hairstylists[i];
        }
    }
    return nullptr;
}

void displayHairstylists() {
    for (int i = 0; i < hairstylist_count; i++) {
        cout << "ID: " << hairstylists[i].id << ", Name: " << hairstylists[i].name
             << ", Specialty: " << hairstylists[i].specialty << endl;
    }
}

int main() {
    addCustomer(1, "Alice", "123-456-7890");
    addCustomer(2, "Bob", "234-567-8901");
    addHairstylist(1, "Charlie", "Cuts");
    addHairstylist(2, "Daisy", "Coloring");

    displayCustomers();
    displayHairstylists();

    updateCustomer(1, "Alice Smith", "123-456-7890");
    updateHairstylist(1, "Charlie Brown", "Cuts and Styling");

    displayCustomers();
    displayHairstylists();

    deleteCustomer(2);
    deleteHairstylist(2);

    displayCustomers();
    displayHairstylists();

    return 0;
}