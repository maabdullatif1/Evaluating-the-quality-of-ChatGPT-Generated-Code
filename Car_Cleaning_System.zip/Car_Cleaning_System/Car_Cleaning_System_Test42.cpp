#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Car {
    int id;
    string model;
    string color;
};

struct Cleaner {
    int id;
    string name;
    int age;
};

class CarCleaningSystem {
    vector<Car> cars;
    vector<Cleaner> cleaners;

    public:
    void addCar(int id, const string &model, const string &color) {
        cars.push_back({id, model, color});
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, const string &model, const string &color) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.model = model;
                car.color = color;
            }
        }
    }

    Car *searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "Car ID: " << car.id << ", Model: " << car.model << ", Color: " << car.color << endl;
        }
    }

    void addCleaner(int id, const string &name, int age) {
        cleaners.push_back({id, name, age});
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, const string &name, int age) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                cleaner.age = age;
            }
        }
    }

    Cleaner *searchCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << ", Age: " << cleaner.age << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    
    system.addCar(1, "Toyota", "Red");
    system.addCar(2, "Honda", "Blue");
    system.updateCar(1, "Toyota", "Green");

    Car *car = system.searchCar(1);
    if (car) cout << "Found Car - ID: " << car->id << ", Model: " << car->model << ", Color: " << car->color << endl;    
    
    system.displayCars();

    system.addCleaner(1, "John", 30);
    system.addCleaner(2, "Alice", 25);
    system.updateCleaner(1, "John", 31);

    Cleaner *cleaner = system.searchCleaner(2);
    if (cleaner) cout << "Found Cleaner - ID: " << cleaner->id << ", Name: " << cleaner->name << ", Age: " << cleaner->age << endl;

    system.displayCleaners();

    system.deleteCar(2);
    system.deleteCleaner(1);

    system.displayCars();
    system.displayCleaners();

    return 0;
}