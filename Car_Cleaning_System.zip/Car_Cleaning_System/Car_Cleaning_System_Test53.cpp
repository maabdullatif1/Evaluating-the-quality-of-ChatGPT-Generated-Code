#include <iostream>
#include <string>

using namespace std;

struct Car {
    int id;
    string brand;
    string model;
    string licensePlate;
};

struct Cleaner {
    int id;
    string name;
    string phone;
};

Car cars[100];
Cleaner cleaners[100];
int carCount = 0;
int cleanerCount = 0;

void addCar() {
    Car newCar;
    cout << "Enter Car ID: ";
    cin >> newCar.id;
    cout << "Enter Car Brand: ";
    cin >> newCar.brand;
    cout << "Enter Car Model: ";
    cin >> newCar.model;
    cout << "Enter License Plate: ";
    cin >> newCar.licensePlate;
    cars[carCount++] = newCar;
}

void deleteCar() {
    int id;
    cout << "Enter Car ID to delete: ";
    cin >> id;
    for (int i = 0; i < carCount; i++) {
        if (cars[i].id == id) {
            for (int j = i; j < carCount - 1; j++)
                cars[j] = cars[j + 1];
            carCount--;
            break;
        }
    }
}

void updateCar() {
    int id;
    cout << "Enter Car ID to update: ";
    cin >> id;
    for (int i = 0; i < carCount; i++) {
        if (cars[i].id == id) {
            cout << "Enter New Car Brand: ";
            cin >> cars[i].brand;
            cout << "Enter New Car Model: ";
            cin >> cars[i].model;
            cout << "Enter New License Plate: ";
            cin >> cars[i].licensePlate;
            break;
        }
    }
}

void searchCar() {
    int id;
    cout << "Enter Car ID to search: ";
    cin >> id;
    for (int i = 0; i < carCount; i++) {
        if (cars[i].id == id) {
            cout << "Car ID: " << cars[i].id << ", Brand: " << cars[i].brand << ", Model: " << cars[i].model << ", License Plate: " << cars[i].licensePlate << endl;
            return;
        }
    }
    cout << "Car not found." << endl;
}

void displayCars() {
    for (int i = 0; i < carCount; i++) {
        cout << "Car ID: " << cars[i].id << ", Brand: " << cars[i].brand << ", Model: " << cars[i].model << ", License Plate: " << cars[i].licensePlate << endl;
    }
}

void addCleaner() {
    Cleaner newCleaner;
    cout << "Enter Cleaner ID: ";
    cin >> newCleaner.id;
    cout << "Enter Cleaner Name: ";
    cin >> newCleaner.name;
    cout << "Enter Cleaner Phone: ";
    cin >> newCleaner.phone;
    cleaners[cleanerCount++] = newCleaner;
}

void deleteCleaner() {
    int id;
    cout << "Enter Cleaner ID to delete: ";
    cin >> id;
    for (int i = 0; i < cleanerCount; i++) {
        if (cleaners[i].id == id) {
            for (int j = i; j < cleanerCount - 1; j++)
                cleaners[j] = cleaners[j + 1];
            cleanerCount--;
            break;
        }
    }
}

void updateCleaner() {
    int id;
    cout << "Enter Cleaner ID to update: ";
    cin >> id;
    for (int i = 0; i < cleanerCount; i++) {
        if (cleaners[i].id == id) {
            cout << "Enter New Cleaner Name: ";
            cin >> cleaners[i].name;
            cout << "Enter New Cleaner Phone: ";
            cin >> cleaners[i].phone;
            break;
        }
    }
}

void searchCleaner() {
    int id;
    cout << "Enter Cleaner ID to search: ";
    cin >> id;
    for (int i = 0; i < cleanerCount; i++) {
        if (cleaners[i].id == id) {
            cout << "Cleaner ID: " << cleaners[i].id << ", Name: " << cleaners[i].name << ", Phone: " << cleaners[i].phone << endl;
            return;
        }
    }
    cout << "Cleaner not found." << endl;
}

void displayCleaners() {
    for (int i = 0; i < cleanerCount; i++) {
        cout << "Cleaner ID: " << cleaners[i].id << ", Name: " << cleaners[i].name << ", Phone: " << cleaners[i].phone << endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Car\n2. Delete Car\n3. Update Car\n4. Search Car\n5. Display Cars\n6. Add Cleaner\n7. Delete Cleaner\n8. Update Cleaner\n9. Search Cleaner\n10. Display Cleaners\n11. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addCar(); break;
            case 2: deleteCar(); break;
            case 3: updateCar(); break;
            case 4: searchCar(); break;
            case 5: displayCars(); break;
            case 6: addCleaner(); break;
            case 7: deleteCleaner(); break;
            case 8: updateCleaner(); break;
            case 9: searchCleaner(); break;
            case 10: displayCleaners(); break;
            case 11: return 0;
            default: cout << "Invalid choice." << endl;
        }
    }
}