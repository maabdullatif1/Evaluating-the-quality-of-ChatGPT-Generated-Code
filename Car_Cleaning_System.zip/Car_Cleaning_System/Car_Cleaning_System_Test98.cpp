#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    string licensePlate;
    string model;
    string ownerName;

    Car(string lp, string m, string on) : licensePlate(lp), model(m), ownerName(on) {}
};

class Cleaner {
public:
    string name;
    int id;

    Cleaner(string n, int i) : name(n), id(i) {}
};

class CarCleaningSystem {
private:
    vector<Car> cars;
    vector<Cleaner> cleaners;

    int findCarIndex(string licensePlate) {
        for (int i = 0; i < cars.size(); i++) {
            if (cars[i].licensePlate == licensePlate) return i;
        }
        return -1;
    }

    int findCleanerIndex(int id) {
        for (int i = 0; i < cleaners.size(); i++) {
            if (cleaners[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCar(string lp, string m, string on) {
        cars.push_back(Car(lp, m, on));
    }

    void deleteCar(string licensePlate) {
        int index = findCarIndex(licensePlate);
        if (index != -1) cars.erase(cars.begin() + index);
    }

    void updateCar(string lp, string newModel, string newOwner) {
        int index = findCarIndex(lp);
        if (index != -1) {
            cars[index].model = newModel;
            cars[index].ownerName = newOwner;
        }
    }

    Car* searchCar(string licensePlate) {
        int index = findCarIndex(licensePlate);
        if (index != -1) return &cars[index];
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            cout << "License Plate: " << car.licensePlate << ", Model: " << car.model << ", Owner: " << car.ownerName << endl;
        }
    }

    void addCleaner(string name, int id) {
        cleaners.push_back(Cleaner(name, id));
    }

    void deleteCleaner(int id) {
        int index = findCleanerIndex(id);
        if (index != -1) cleaners.erase(cleaners.begin() + index);
    }

    void updateCleaner(int id, string newName) {
        int index = findCleanerIndex(id);
        if (index != -1) {
            cleaners[index].name = newName;
        }
    }

    Cleaner* searchCleaner(int id) {
        int index = findCleanerIndex(id);
        if (index != -1) return &cleaners[index];
        return nullptr;
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("ABC123", "Toyota", "John Doe");
    system.addCar("XYZ789", "Honda", "Jane Smith");
    system.addCleaner("Tom", 1);
    system.addCleaner("Jerry", 2);
    system.displayCars();
    system.displayCleaners();
    return 0;
}