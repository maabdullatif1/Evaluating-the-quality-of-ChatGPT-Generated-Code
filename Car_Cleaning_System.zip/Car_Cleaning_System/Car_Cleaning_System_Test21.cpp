#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string model;
    string licensePlate;

    Car(int id, string model, string licensePlate) : id(id), model(model), licensePlate(licensePlate) {}
};

class Cleaner {
public:
    int id;
    string name;

    Cleaner(int id, string name) : id(id), name(name) {}
};

class CleaningSystem {
private:
    vector<Car> cars;
    vector<Cleaner> cleaners;

    int findCarIndexById(int id) {
        for (int i = 0; i < cars.size(); i++) {
            if (cars[i].id == id) return i;
        }
        return -1;
    }

    int findCleanerIndexById(int id) {
        for (int i = 0; i < cleaners.size(); i++) {
            if (cleaners[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCar(int id, string model, string licensePlate) {
        if (findCarIndexById(id) != -1) {
            cout << "Car with this ID already exists" << endl;
            return;
        }
        cars.push_back(Car(id, model, licensePlate));
    }

    void deleteCar(int id) {
        int index = findCarIndexById(id);
        if (index != -1) {
            cars.erase(cars.begin() + index);
        } else {
            cout << "Car not found" << endl;
        }
    }

    void updateCar(int id, string model, string licensePlate) {
        int index = findCarIndexById(id);
        if (index != -1) {
            cars[index].model = model;
            cars[index].licensePlate = licensePlate;
        } else {
            cout << "Car not found" << endl;
        }
    }

    void displayCars() {
        for (const auto& car : cars) {
            cout << "ID: " << car.id << ", Model: " << car.model << ", License Plate: " << car.licensePlate << endl;
        }
    }

    void addCleaner(int id, string name) {
        if (findCleanerIndexById(id) != -1) {
            cout << "Cleaner with this ID already exists" << endl;
            return;
        }
        cleaners.push_back(Cleaner(id, name));
    }

    void deleteCleaner(int id) {
        int index = findCleanerIndexById(id);
        if (index != -1) {
            cleaners.erase(cleaners.begin() + index);
        } else {
            cout << "Cleaner not found" << endl;
        }
    }

    void updateCleaner(int id, string name) {
        int index = findCleanerIndexById(id);
        if (index != -1) {
            cleaners[index].name = name;
        } else {
            cout << "Cleaner not found" << endl;
        }
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << endl;
        }
    }

    void searchCar(int id) {
        int index = findCarIndexById(id);
        if (index != -1) {
            cout << "Car found: ID: " << cars[index].id << ", Model: " << cars[index].model << ", License Plate: " << cars[index].licensePlate << endl;
        } else {
            cout << "Car not found" << endl;
        }
    }

    void searchCleaner(int id) {
        int index = findCleanerIndexById(id);
        if (index != -1) {
            cout << "Cleaner found: ID: " << cleaners[index].id << ", Name: " << cleaners[index].name << endl;
        } else {
            cout << "Cleaner not found" << endl;
        }
    }
};

int main() {
    CleaningSystem system;
    system.addCar(101, "Toyota", "ABC123");
    system.addCar(102, "Honda", "XYZ789");
    system.addCleaner(1, "John Doe");
    system.addCleaner(2, "Jane Smith");

    system.displayCars();
    system.displayCleaners();

    system.searchCar(101);
    system.searchCleaner(2);

    system.updateCar(101, "Toyota Corolla", "ABC321");
    system.updateCleaner(1, "John A. Doe");

    system.displayCars();
    system.displayCleaners();

    system.deleteCar(102);
    system.deleteCleaner(2);

    system.displayCars();
    system.displayCleaners();

    return 0;
}