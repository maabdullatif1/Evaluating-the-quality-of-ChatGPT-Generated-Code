#include <iostream>
#include <string>

using namespace std;

struct Car {
    int id;
    string model;
    string owner;
};

struct Cleaner {
    int id;
    string name;
    string contact;
};

const int MAX_CARS = 100;
const int MAX_CLEANERS = 50;
Car cars[MAX_CARS];
Cleaner cleaners[MAX_CLEANERS];
int carCount = 0;
int cleanerCount = 0;

void addCar(int id, string model, string owner) {
    if (carCount < MAX_CARS) {
        cars[carCount++] = {id, model, owner};
    }
}

void deleteCar(int id) {
    for (int i = 0; i < carCount; ++i) {
        if (cars[i].id == id) {
            for (int j = i; j < carCount - 1; ++j) {
                cars[j] = cars[j + 1];
            }
            --carCount;
            break;
        }
    }
}

void updateCar(int id, string model, string owner) {
    for (int i = 0; i < carCount; ++i) {
        if (cars[i].id == id) {
            cars[i].model = model;
            cars[i].owner = owner;
            break;
        }
    }
}

Car* searchCar(int id) {
    for (int i = 0; i < carCount; ++i) {
        if (cars[i].id == id) {
            return &cars[i];
        }
    }
    return nullptr;
}

void displayCars() {
    for (int i = 0; i < carCount; ++i) {
        cout << "ID: " << cars[i].id << ", Model: " << cars[i].model << ", Owner: " << cars[i].owner << endl;
    }
}

void addCleaner(int id, string name, string contact) {
    if (cleanerCount < MAX_CLEANERS) {
        cleaners[cleanerCount++] = {id, name, contact};
    }
}

void deleteCleaner(int id) {
    for (int i = 0; i < cleanerCount; ++i) {
        if (cleaners[i].id == id) {
            for (int j = i; j < cleanerCount - 1; ++j) {
                cleaners[j] = cleaners[j + 1];
            }
            --cleanerCount;
            break;
        }
    }
}

void updateCleaner(int id, string name, string contact) {
    for (int i = 0; i < cleanerCount; ++i) {
        if (cleaners[i].id == id) {
            cleaners[i].name = name;
            cleaners[i].contact = contact;
            break;
        }
    }
}

Cleaner* searchCleaner(int id) {
    for (int i = 0; i < cleanerCount; ++i) {
        if (cleaners[i].id == id) {
            return &cleaners[i];
        }
    }
    return nullptr;
}

void displayCleaners() {
    for (int i = 0; i < cleanerCount; ++i) {
        cout << "ID: " << cleaners[i].id << ", Name: " << cleaners[i].name << ", Contact: " << cleaners[i].contact << endl;
    }
}

int main() {
    addCar(1, "Toyota Corolla", "John Doe");
    addCar(2, "Honda Civic", "Jane Smith");
    displayCars();
    Car* car = searchCar(1);
    if (car) {
        cout << "Found Car: ID: " << car->id << ", Model: " << car->model << ", Owner: " << car->owner << endl;
    }
    updateCar(2, "Honda Accord", "Jane Smith");
    displayCars();
    deleteCar(1);
    displayCars();

    addCleaner(1, "Mike Johnson", "555-1234");
    addCleaner(2, "Sara Brown", "555-5678");
    displayCleaners();
    Cleaner* cleaner = searchCleaner(1);
    if (cleaner) {
        cout << "Found Cleaner: ID: " << cleaner->id << ", Name: " << cleaner->name << ", Contact: " << cleaner->contact << endl;
    }
    updateCleaner(2, "Sara Smith", "555-8765");
    displayCleaners();
    deleteCleaner(1);
    displayCleaners();

    return 0;
}