#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    int id;
    string model;
    string owner;
};

struct Cleaner {
    int id;
    string name;
    int experience;
};

class CarCleaningSystem {
    vector<Car> cars;
    vector<Cleaner> cleaners;

    Car* findCar(int id) {
        for (auto& car : cars) {
            if (car.id == id)
                return &car;
        }
        return nullptr;
    }

    Cleaner* findCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id)
                return &cleaner;
        }
        return nullptr;
    }

public:
    void addCar(int id, string model, string owner) {
        cars.push_back({id, model, owner});
    }

    void addCleaner(int id, string name, int experience) {
        cleaners.push_back({id, name, experience});
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string model, string owner) {
        Car* car = findCar(id);
        if (car) {
            car->model = model;
            car->owner = owner;
        }
    }

    void updateCleaner(int id, string name, int experience) {
        Cleaner* cleaner = findCleaner(id);
        if (cleaner) {
            cleaner->name = name;
            cleaner->experience = experience;
        }
    }

    Car* searchCar(int id) {
        return findCar(id);
    }

    Cleaner* searchCleaner(int id) {
        return findCleaner(id);
    }

    void displayCars() {
        for (const auto& car : cars) {
            cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << endl;
        }
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << ", Experience: " << cleaner.experience << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Alice");
    system.addCleaner(1, "Bob", 5);
    system.displayCars();
    system.displayCleaners();
    system.updateCar(1, "Honda", "Alice");
    system.updateCleaner(1, "Bob", 10);
    system.displayCars();
    system.displayCleaners();
    system.deleteCar(1);
    system.deleteCleaner(1);
    system.displayCars();
    system.displayCleaners();
    return 0;
}