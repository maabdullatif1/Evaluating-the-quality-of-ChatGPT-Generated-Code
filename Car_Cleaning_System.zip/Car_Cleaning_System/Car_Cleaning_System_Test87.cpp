#include <iostream>
#include <vector>
#include <string>

struct Car {
    int id;
    std::string make;
    std::string model;
};

struct Cleaner {
    int id;
    std::string name;
};

std::vector<Car> cars;
std::vector<Cleaner> cleaners;

int findCarIndex(int id) {
    for (size_t i = 0; i < cars.size(); ++i) {
        if (cars[i].id == id) return i;
    }
    return -1;
}

int findCleanerIndex(int id) {
    for (size_t i = 0; i < cleaners.size(); ++i) {
        if (cleaners[i].id == id) return i;
    }
    return -1;
}

void addCar(int id, const std::string& make, const std::string& model) {
    cars.push_back(Car{id, make, model});
}

void addCleaner(int id, const std::string& name) {
    cleaners.push_back(Cleaner{id, name});
}

void deleteCar(int id) {
    int index = findCarIndex(id);
    if (index != -1) {
        cars.erase(cars.begin() + index);
    }
}

void deleteCleaner(int id) {
    int index = findCleanerIndex(id);
    if (index != -1) {
        cleaners.erase(cleaners.begin() + index);
    }
}

void updateCar(int id, const std::string& make, const std::string& model) {
    int index = findCarIndex(id);
    if (index != -1) {
        cars[index].make = make;
        cars[index].model = model;
    }
}

void updateCleaner(int id, const std::string& name) {
    int index = findCleanerIndex(id);
    if (index != -1) {
        cleaners[index].name = name;
    }
}

void searchCar(int id) {
    int index = findCarIndex(id);
    if (index != -1) {
        std::cout << "Car ID: " << cars[index].id << ", Make: " << cars[index].make << ", Model: " << cars[index].model << "\n";
    } else {
        std::cout << "Car not found.\n";
    }
}

void searchCleaner(int id) {
    int index = findCleanerIndex(id);
    if (index != -1) {
        std::cout << "Cleaner ID: " << cleaners[index].id << ", Name: " << cleaners[index].name << "\n";
    } else {
        std::cout << "Cleaner not found.\n";
    }
}

void displayCars() {
    for (const auto& car : cars) {
        std::cout << "Car ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << "\n";
    }
}

void displayCleaners() {
    for (const auto& cleaner : cleaners) {
        std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << "\n";
    }
}

void menu() {
    int choice, id;
    std::string make, model, name;
    while (true) {
        std::cout << "\n1. Add Car\n2. Add Cleaner\n3. Delete Car\n4. Delete Cleaner\n5. Update Car\n6. Update Cleaner"
                  << "\n7. Search Car\n8. Search Cleaner\n9. Display Cars\n10. Display Cleaners\n11. Exit\nChoose an option: ";
        std::cin >> choice;
        switch (choice) {
        case 1:
            std::cout << "Enter Car ID, Make, Model: ";
            std::cin >> id >> make >> model;
            addCar(id, make, model);
            break;
        case 2:
            std::cout << "Enter Cleaner ID and Name: ";
            std::cin >> id >> name;
            addCleaner(id, name);
            break;
        case 3:
            std::cout << "Enter Car ID to delete: ";
            std::cin >> id;
            deleteCar(id);
            break;
        case 4:
            std::cout << "Enter Cleaner ID to delete: ";
            std::cin >> id;
            deleteCleaner(id);
            break;
        case 5:
            std::cout << "Enter Car ID, New Make, New Model: ";
            std::cin >> id >> make >> model;
            updateCar(id, make, model);
            break;
        case 6:
            std::cout << "Enter Cleaner ID and New Name: ";
            std::cin >> id >> name;
            updateCleaner(id, name);
            break;
        case 7:
            std::cout << "Enter Car ID to search: ";
            std::cin >> id;
            searchCar(id);
            break;
        case 8:
            std::cout << "Enter Cleaner ID to search: ";
            std::cin >> id;
            searchCleaner(id);
            break;
        case 9:
            displayCars();
            break;
        case 10:
            displayCleaners();
            break;
        case 11:
            return;
        default:
            std::cout << "Invalid option.";
        }
    }
}

int main() {
    menu();
    return 0;
}