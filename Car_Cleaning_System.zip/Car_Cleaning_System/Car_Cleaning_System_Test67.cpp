#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string model;

    Car(std::string licensePlate, std::string model) 
        : licensePlate(licensePlate), model(model) {}
};

class Cleaner {
public:
    std::string id;
    std::string name;

    Cleaner(std::string id, std::string name) 
        : id(id), name(name) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(const std::string &licensePlate, const std::string &model) {
        cars.emplace_back(licensePlate, model);
    }

    void deleteCar(const std::string &licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string &licensePlate, const std::string &newModel) {
        for (auto &car : cars) {
            if (car.licensePlate == licensePlate) {
                car.model = newModel;
                break;
            }
        }
    }

    Car* searchCar(const std::string &licensePlate) {
        for (auto &car : cars) {
            if (car.licensePlate == licensePlate) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "License Plate: " << car.licensePlate << ", Model: " << car.model << std::endl;
        }
    }

    void addCleaner(const std::string &id, const std::string &name) {
        cleaners.emplace_back(id, name);
    }

    void deleteCleaner(const std::string &id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(const std::string &id, const std::string &newName) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = newName;
                break;
            }
        }
    }

    Cleaner* searchCleaner(const std::string &id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            std::cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("ABC123", "Toyota");
    system.addCar("XYZ987", "Honda");
    system.displayCars();
    
    system.addCleaner("C001", "John");
    system.addCleaner("C002", "Mike");
    system.displayCleaners();

    return 0;
}