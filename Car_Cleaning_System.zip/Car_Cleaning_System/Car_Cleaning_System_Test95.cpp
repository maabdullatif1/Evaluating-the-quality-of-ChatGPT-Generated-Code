#include <iostream>
#include <string>
#include <vector>

struct Car {
    int id;
    std::string model;
    std::string licensePlate;
};

struct Cleaner {
    int id;
    std::string name;
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

    Car* findCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) return &car;
        }
        return nullptr;
    }

    Cleaner* findCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) return &cleaner;
        }
        return nullptr;
    }

public:
    void addCar(int id, const std::string& model, const std::string& licensePlate) {
        cars.push_back({id, model, licensePlate});
    }

    void addCleaner(int id, const std::string& name) {
        cleaners.push_back({id, name});
    }

    void deleteCar(int id) {
        cars.erase(std::remove_if(cars.begin(), cars.end(), [&id](Car& car) { return car.id == id; }), cars.end());
    }

    void deleteCleaner(int id) {
        cleaners.erase(std::remove_if(cleaners.begin(), cleaners.end(), [&id](Cleaner& cleaner) { return cleaner.id == id; }), cleaners.end());
    }

    void updateCar(int id, const std::string& model, const std::string& licensePlate) {
        Car* car = findCar(id);
        if (car) {
            car->model = model;
            car->licensePlate = licensePlate;
        }
    }

    void updateCleaner(int id, const std::string& name) {
        Cleaner* cleaner = findCleaner(id);
        if (cleaner) {
            cleaner->name = name;
        }
    }

    void searchCar(int id) {
        Car* car = findCar(id);
        if (car) {
            std::cout << "Car Found: ID=" << car->id << " Model=" << car->model << " License Plate=" << car->licensePlate << "\n";
        } else {
            std::cout << "Car not found\n";
        }
    }

    void searchCleaner(int id) {
        Cleaner* cleaner = findCleaner(id);
        if (cleaner) {
            std::cout << "Cleaner Found: ID=" << cleaner->id << " Name=" << cleaner->name << "\n";
        } else {
            std::cout << "Cleaner not found\n";
        }
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Car ID=" << car.id << " Model=" << car.model << " License Plate=" << car.licensePlate << "\n";
        }
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "Cleaner ID=" << cleaner.id << " Name=" << cleaner.name << "\n";
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "ABC123");
    system.addCar(2, "Honda", "XYZ789");
    system.addCleaner(1, "John Doe");
    system.addCleaner(2, "Jane Doe");

    std::cout << "Displaying all cars:\n";
    system.displayCars();

    std::cout << "\nDisplaying all cleaners:\n";
    system.displayCleaners();

    std::cout << "\nSearching for car ID 1:\n";
    system.searchCar(1);

    std::cout << "\nUpdating car ID 1:\n";
    system.updateCar(1, "Nissan", "DEF456");
    system.displayCars();

    std::cout << "\nDeleting car ID 2:\n";
    system.deleteCar(2);
    system.displayCars();

    std::cout << "\nSearching for cleaner ID 2:\n";
    system.searchCleaner(2);

    std::cout << "\nUpdating cleaner ID 2:\n";
    system.updateCleaner(2, "Janet Doe");
    system.displayCleaners();

    std::cout << "\nDeleting cleaner ID 1:\n";
    system.deleteCleaner(1);
    system.displayCleaners();

    return 0;
}