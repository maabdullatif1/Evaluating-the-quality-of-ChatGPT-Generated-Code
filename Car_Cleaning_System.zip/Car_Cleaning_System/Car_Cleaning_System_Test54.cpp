#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int carID;
    std::string carModel;
    std::string licensePlate;
    
    Car(int id, std::string model, std::string license) : carID(id), carModel(model), licensePlate(license) {}
};

class Cleaner {
public:
    int cleanerID;
    std::string cleanerName;

    Cleaner(int id, std::string name) : cleanerID(id), cleanerName(name) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

    int findCarIndexById(int id) {
        for (size_t i = 0; i < cars.size(); ++i) {
            if (cars[i].carID == id) {
                return i;
            }
        }
        return -1;
    }

    int findCleanerIndexById(int id) {
        for (size_t i = 0; i < cleaners.size(); ++i) {
            if (cleaners[i].cleanerID == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addCar(int id, std::string model, std::string license) {
        if (findCarIndexById(id) == -1) {
            cars.push_back(Car(id, model, license));
        }
    }

    void addCleaner(int id, std::string name) {
        if (findCleanerIndexById(id) == -1) {
            cleaners.push_back(Cleaner(id, name));
        }
    }

    void deleteCar(int id) {
        int index = findCarIndexById(id);
        if (index != -1) {
            cars.erase(cars.begin() + index);
        }
    }

    void deleteCleaner(int id) {
        int index = findCleanerIndexById(id);
        if (index != -1) {
            cleaners.erase(cleaners.begin() + index);
        }
    }

    void updateCar(int id, std::string newModel, std::string newLicense) {
        int index = findCarIndexById(id);
        if (index != -1) {
            cars[index].carModel = newModel;
            cars[index].licensePlate = newLicense;
        }
    }

    void updateCleaner(int id, std::string newName) {
        int index = findCleanerIndexById(id);
        if (index != -1) {
            cleaners[index].cleanerName = newName;
        }
    }

    Car* searchCar(int id) {
        int index = findCarIndexById(id);
        if (index != -1) {
            return &cars[index];
        }
        return nullptr;
    }

    Cleaner* searchCleaner(int id) {
        int index = findCleanerIndexById(id);
        if (index != -1) {
            return &cleaners[index];
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Car ID: " << car.carID << ", Model: " << car.carModel << ", License Plate: " << car.licensePlate << std::endl;
        }
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "Cleaner ID: " << cleaner.cleanerID << ", Name: " << cleaner.cleanerName << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "ABC123");
    system.addCar(2, "Honda", "XYZ789");
    system.addCleaner(1, "John");
    system.addCleaner(2, "Anna");
    system.displayCars();
    system.displayCleaners();
    return 0;
}