#include <iostream>
#include <string>

class Car {
public:
    int car_id;
    std::string car_model;
    std::string car_owner;

    Car(int id, const std::string& model, const std::string& owner) 
        : car_id(id), car_model(model), car_owner(owner) {}
};

class Cleaner {
public:
    int cleaner_id;
    std::string cleaner_name;
    std::string cleaner_contact;

    Cleaner(int id, const std::string& name, const std::string& contact) 
        : cleaner_id(id), cleaner_name(name), cleaner_contact(contact) {}
};

template <typename T>
class Node {
public:
    T data;
    Node* next;
    Node(const T& data) : data(data), next(nullptr) {}
};

template <typename T>
class LinkedList {
public:
    Node<T>* head;
    LinkedList() : head(nullptr) {}

    void add(const T& data) {
        Node<T>* newNode = new Node<T>(data);
        if (head == nullptr) {
            head = newNode;
        } else {
            Node<T>* temp = head;
            while (temp->next != nullptr) temp = temp->next;
            temp->next = newNode;
        }
    }

    void remove(int id) {
        if (head == nullptr) return;
        if (head->data.car_id == id || head->data.cleaner_id == id) {
            Node<T>* temp = head;
            head = head->next;
            delete temp;
            return;
        }
        Node<T>* current = head;
        while (current->next != nullptr && (current->next->data.car_id != id && current->next->data.cleaner_id != id)) {
            current = current->next;
        }
        if (current->next != nullptr) {
            Node<T>* toDelete = current->next;
            current->next = current->next->next;
            delete toDelete;
        }
    }

    Node<T>* search(int id) {
        Node<T>* current = head;
        while (current != nullptr) {
            if (current->data.car_id == id || current->data.cleaner_id == id) return current;
            current = current->next;
        }
        return nullptr;
    }

    void update(int id, const T& newData) {
        Node<T>* node = search(id);
        if (node) node->data = newData;
    }

    void display() {
        Node<T>* current = head;
        while (current != nullptr) {
            if constexpr (std::is_same<T, Car>::value) {
                std::cout << "Car ID: " << current->data.car_id << ", Model: " << current->data.car_model << ", Owner: " << current->data.car_owner << "\n";
            } else {
                std::cout << "Cleaner ID: " << current->data.cleaner_id << ", Name: " << current->data.cleaner_name << ", Contact: " << current->data.cleaner_contact << "\n";
            }
            current = current->next;
        }
    }
};

int main() {
    LinkedList<Car> cars;
    LinkedList<Cleaner> cleaners;

    cars.add(Car(1, "Toyota", "Alice"));
    cars.add(Car(2, "Honda", "Bob"));

    cleaners.add(Cleaner(1, "Charlie", "555-1234"));
    cleaners.add(Cleaner(2, "Dave", "555-5678"));

    std::cout << "Cars:\n";
    cars.display();
    std::cout << "\nCleaners:\n";
    cleaners.display();

    cars.update(2, Car(2, "Honda Civic", "Bob"));
    cleaners.remove(1);

    std::cout << "\nUpdated Cars:\n";
    cars.display();
    std::cout << "\nUpdated Cleaners:\n";
    cleaners.display();

    return 0;
}