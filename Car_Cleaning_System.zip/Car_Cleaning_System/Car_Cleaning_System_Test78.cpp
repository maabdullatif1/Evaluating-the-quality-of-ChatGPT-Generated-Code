#include <iostream>
#include <string>

using namespace std;

struct Car {
    int id;
    string brand;
    string model;
};

struct Cleaner {
    int id;
    string name;
    string expertise;
};

class CarCleaningSystem {
    Car cars[100];
    Cleaner cleaners[100];
    int carCount = 0;
    int cleanerCount = 0;
    
public:
    void addCar(int id, string brand, string model) {
        cars[carCount] = {id, brand, model};
        carCount++;
    }
    
    void deleteCar(int id) {
        for (int i = 0; i < carCount; i++) {
            if (cars[i].id == id) {
                for (int j = i; j < carCount - 1; j++) {
                    cars[j] = cars[j + 1];
                }
                carCount--;
                break;
            }
        }
    }
    
    void updateCar(int id, string brand, string model) {
        for (int i = 0; i < carCount; i++) {
            if (cars[i].id == id) {
                cars[i].brand = brand;
                cars[i].model = model;
                break;
            }
        }
    }
    
    void searchCar(int id) {
        for (int i = 0; i < carCount; i++) {
            if (cars[i].id == id) {
                cout << "Car ID: " << cars[i].id << ", Brand: " 
                     << cars[i].brand << ", Model: " << cars[i].model << endl;
                return;
            }
        }
        cout << "Car not found." << endl;
    }

    void displayCars() {
        for (int i = 0; i < carCount; i++) {
            cout << "Car ID: " << cars[i].id << ", Brand: " 
                 << cars[i].brand << ", Model: " << cars[i].model << endl;
        }
    }

    void addCleaner(int id, string name, string expertise) {
        cleaners[cleanerCount] = {id, name, expertise};
        cleanerCount++;
    }
    
    void deleteCleaner(int id) {
        for (int i = 0; i < cleanerCount; i++) {
            if (cleaners[i].id == id) {
                for (int j = i; j < cleanerCount - 1; j++) {
                    cleaners[j] = cleaners[j + 1];
                }
                cleanerCount--;
                break;
            }
        }
    }
    
    void updateCleaner(int id, string name, string expertise) {
        for (int i = 0; i < cleanerCount; i++) {
            if (cleaners[i].id == id) {
                cleaners[i].name = name;
                cleaners[i].expertise = expertise;
                break;
            }
        }
    }
    
    void searchCleaner(int id) {
        for (int i = 0; i < cleanerCount; i++) {
            if (cleaners[i].id == id) {
                cout << "Cleaner ID: " << cleaners[i].id << ", Name: " 
                     << cleaners[i].name << ", Expertise: " << cleaners[i].expertise << endl;
                return;
            }
        }
        cout << "Cleaner not found." << endl;
    }
    
    void displayCleaners() {
        for (int i = 0; i < cleanerCount; i++) {
            cout << "Cleaner ID: " << cleaners[i].id << ", Name: " 
                 << cleaners[i].name << ", Expertise: " << cleaners[i].expertise << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Camry");
    system.addCar(2, "Honda", "Civic");
    system.displayCars();

    system.addCleaner(1, "John Doe", "Interior Cleaning");
    system.addCleaner(2, "Jane Smith", "Exterior Wax");
    system.displayCleaners();

    system.updateCar(1, "Toyota", "Corolla");
    system.searchCar(1);

    system.updateCleaner(1, "John Doe", "Full Service");
    system.searchCleaner(1);

    system.deleteCar(2);
    system.displayCars();

    system.deleteCleaner(2);
    system.displayCleaners();

    return 0;
}