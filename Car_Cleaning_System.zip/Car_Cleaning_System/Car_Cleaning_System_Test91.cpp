#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string make;
    std::string model;
    std::string licensePlate;

    Car(int id, std::string make, std::string model, std::string licensePlate)
        : id(id), make(make), model(model), licensePlate(licensePlate) {}
};

class Cleaner {
public:
    int id;
    std::string name;
    std::string phoneNumber;

    Cleaner(int id, std::string name, std::string phoneNumber)
        : id(id), name(name), phoneNumber(phoneNumber) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;
    int carNextId = 1;
    int cleanerNextId = 1;

public:
    void addCar(std::string make, std::string model, std::string licensePlate) {
        cars.push_back(Car(carNextId++, make, model, licensePlate));
    }

    void addCleaner(std::string name, std::string phoneNumber) {
        cleaners.push_back(Cleaner(cleanerNextId++, name, phoneNumber));
    }

    void deleteCar(int carId) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == carId) {
                cars.erase(it);
                break;
            }
        }
    }

    void deleteCleaner(int cleanerId) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == cleanerId) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCar(int carId, std::string make, std::string model, std::string licensePlate) {
        for (auto& car : cars) {
            if (car.id == carId) {
                car.make = make;
                car.model = model;
                car.licensePlate = licensePlate;
                break;
            }
        }
    }

    void updateCleaner(int cleanerId, std::string name, std::string phoneNumber) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == cleanerId) {
                cleaner.name = name;
                cleaner.phoneNumber = phoneNumber;
                break;
            }
        }
    }

    Car* searchCar(int carId) {
        for (auto& car : cars) {
            if (car.id == carId) {
                return &car;
            }
        }
        return nullptr;
    }

    Cleaner* searchCleaner(int cleanerId) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == cleanerId) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Car ID: " << car.id << " Make: " << car.make 
                      << " Model: " << car.model 
                      << " License Plate: " << car.licensePlate << std::endl;
        }
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "Cleaner ID: " << cleaner.id 
                      << " Name: " << cleaner.name 
                      << " Phone Number: " << cleaner.phoneNumber << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;

    system.addCar("Toyota", "Camry", "XYZ123");
    system.addCar("Honda", "Civic", "ABC456");

    system.addCleaner("John Doe", "123-456-7890");
    system.addCleaner("Jane Smith", "987-654-3210");

    system.displayCars();
    system.displayCleaners();

    system.updateCar(1, "Toyota", "Corolla", "XYZ999");
    system.updateCleaner(1, "John Smith", "321-654-0987");

    system.displayCars();
    system.displayCleaners();

    Car* car = system.searchCar(2);
    if (car) {
        std::cout << "Found Car ID: " << car->id << std::endl;
    }

    Cleaner* cleaner = system.searchCleaner(2);
    if (cleaner) {
        std::cout << "Found Cleaner ID: " << cleaner->id << std::endl;
    }

    system.deleteCar(2);
    system.deleteCleaner(2);

    system.displayCars();
    system.displayCleaners();

    return 0;
}