#include <iostream>
#include <vector>
#include <string>

struct Car {
    int id;
    std::string make;
    std::string model;
};

struct Cleaner {
    int id;
    std::string name;
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

    int findCarIndex(int id) {
        for (size_t i = 0; i < cars.size(); ++i) {
            if (cars[i].id == id) return i;
        }
        return -1;
    }

    int findCleanerIndex(int id) {
        for (size_t i = 0; i < cleaners.size(); ++i) {
            if (cleaners[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCar(int id, std::string make, std::string model) {
        cars.push_back({id, make, model});
    }

    void deleteCar(int id) {
        int index = findCarIndex(id);
        if (index != -1) cars.erase(cars.begin() + index);
    }

    void updateCar(int id, std::string make, std::string model) {
        int index = findCarIndex(id);
        if (index != -1) {
            cars[index].make = make;
            cars[index].model = model;
        }
    }

    void addCleaner(int id, std::string name) {
        cleaners.push_back({id, name});
    }

    void deleteCleaner(int id) {
        int index = findCleanerIndex(id);
        if (index != -1) cleaners.erase(cleaners.begin() + index);
    }

    void updateCleaner(int id, std::string name) {
        int index = findCleanerIndex(id);
        if (index != -1) {
            cleaners[index].name = name;
        }
    }

    Car* searchCar(int id) {
        int index = findCarIndex(id);
        if (index != -1) return &cars[index];
        return nullptr;
    }

    Cleaner* searchCleaner(int id) {
        int index = findCleanerIndex(id);
        if (index != -1) return &cleaners[index];
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Car ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << std::endl;
        }
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Camry");
    system.addCar(2, "Honda", "Civic");
    system.updateCar(2, "Honda", "Accord");
    system.addCleaner(1, "John");
    system.addCleaner(2, "Doe");
    system.updateCleaner(2, "Jane");

    system.displayCars();
    system.displayCleaners();

    system.deleteCar(1);
    system.deleteCleaner(1);

    system.displayCars();
    system.displayCleaners();

    return 0;
}