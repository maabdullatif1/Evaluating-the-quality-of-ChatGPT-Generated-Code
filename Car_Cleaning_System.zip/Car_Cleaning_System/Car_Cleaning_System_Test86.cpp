#include <iostream>
#include <vector>
#include <string>

struct Car {
    int id;
    std::string make;
    std::string model;
    int year;
};

struct Cleaner {
    int id;
    std::string name;
    int age;
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;
    int carIdCounter = 1;
    int cleanerIdCounter = 1;

public:
    void addCar(const std::string& make, const std::string& model, int year) {
        cars.push_back({carIdCounter++, make, model, year});
    }

    void addCleaner(const std::string& name, int age) {
        cleaners.push_back({cleanerIdCounter++, name, age});
    }

    bool deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                return true;
            }
        }
        return false;
    }

    bool deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateCar(int id, const std::string& make, const std::string& model, int year) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.year = year;
                return true;
            }
        }
        return false;
    }

    bool updateCleaner(int id, const std::string& name, int age) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                cleaner.age = age;
                return true;
            }
        }
        return false;
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    Cleaner* searchCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << ", Year: " << car.year << std::endl;
        }
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << ", Age: " << cleaner.age << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("Toyota", "Corolla", 2020);
    system.addCleaner("John Doe", 30);
    system.displayCars();
    system.displayCleaners();
    system.updateCar(1, "Honda", "Civic", 2021);
    system.updateCleaner(1, "Jane Smith", 25);
    system.displayCars();
    system.displayCleaners();
    system.deleteCar(1);
    system.deleteCleaner(1);
    system.displayCars();
    system.displayCleaners();
    return 0;
}