#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string make;
    std::string model;

    Car(int i, const std::string &m, const std::string &mo) : id(i), make(m), model(mo) {}
};

class Cleaner {
public:
    int id;
    std::string name;

    Cleaner(int i, const std::string &n) : id(i), name(n) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(int id, const std::string &make, const std::string &model) {
        cars.emplace_back(id, make, model);
    }

    void addCleaner(int id, const std::string &name) {
        cleaners.emplace_back(id, name);
    }

    void deleteCar(int id) {
        cars.erase(remove_if(cars.begin(), cars.end(), [id](const Car &c) {
            return c.id == id;
        }), cars.end());
    }

    void deleteCleaner(int id) {
        cleaners.erase(remove_if(cleaners.begin(), cleaners.end(), [id](const Cleaner &cr) {
            return cr.id == id;
        }), cleaners.end());
    }

    void updateCar(int id, const std::string &newMake, const std::string &newModel) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.make = newMake;
                car.model = newModel;
                break;
            }
        }
    }

    void updateCleaner(int id, const std::string &newName) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = newName;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    Cleaner* searchCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "Car ID: " << car.id << " Make: " << car.make << " Model: " << car.model << std::endl;
        }
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            std::cout << "Cleaner ID: " << cleaner.id << " Name: " << cleaner.name << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Camry");
    system.addCar(2, "Honda", "Civic");
    system.addCleaner(1, "John Doe");
    system.addCleaner(2, "Jane Smith");

    system.displayCars();
    system.displayCleaners();

    system.updateCar(1, "Toyota", "Corolla");
    system.updateCleaner(1, "John Smith");

    system.displayCars();
    system.displayCleaners();

    system.deleteCar(2);
    system.deleteCleaner(2);

    system.displayCars();
    system.displayCleaners();

    return 0;
}