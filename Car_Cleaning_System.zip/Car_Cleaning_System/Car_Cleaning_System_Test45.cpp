#include <iostream>
#include <string>

using namespace std;

struct Car {
    int id;
    string make;
    string model;
};

struct Cleaner {
    int id;
    string name;
};

class CarCleanerManagementSystem {
    Car cars[100];
    Cleaner cleaners[100];
    int carCount;
    int cleanerCount;

public:
    CarCleanerManagementSystem() : carCount(0), cleanerCount(0) {}

    void addCar(int id, const string &make, const string &model) {
        cars[carCount++] = {id, make, model};
    }

    void deleteCar(int id) {
        for (int i = 0; i < carCount; ++i) {
            if (cars[i].id == id) {
                for (int j = i; j < carCount - 1; ++j) {
                    cars[j] = cars[j + 1];
                }
                --carCount;
                break;
            }
        }
    }

    void updateCar(int id, const string &make, const string &model) {
        for (int i = 0; i < carCount; ++i) {
            if (cars[i].id == id) {
                cars[i].make = make;
                cars[i].model = model;
                break;
            }
        }
    }

    void searchCar(int id) {
        for (int i = 0; i < carCount; ++i) {
            if (cars[i].id == id) {
                cout << "Car ID: " << cars[i].id << " Make: " << cars[i].make << " Model: " << cars[i].model << endl;
                return;
            }
        }
        cout << "Car not found" << endl;
    }

    void displayCars() {
        for (int i = 0; i < carCount; ++i) {
            cout << "Car ID: " << cars[i].id << " Make: " << cars[i].make << " Model: " << cars[i].model << endl;
        }
    }

    void addCleaner(int id, const string &name) {
        cleaners[cleanerCount++] = {id, name};
    }

    void deleteCleaner(int id) {
        for (int i = 0; i < cleanerCount; ++i) {
            if (cleaners[i].id == id) {
                for (int j = i; j < cleanerCount - 1; ++j) {
                    cleaners[j] = cleaners[j + 1];
                }
                --cleanerCount;
                break;
            }
        }
    }

    void updateCleaner(int id, const string &name) {
        for (int i = 0; i < cleanerCount; ++i) {
            if (cleaners[i].id == id) {
                cleaners[i].name = name;
                break;
            }
        }
    }

    void searchCleaner(int id) {
        for (int i = 0; i < cleanerCount; ++i) {
            if (cleaners[i].id == id) {
                cout << "Cleaner ID: " << cleaners[i].id << " Name: " << cleaners[i].name << endl;
                return;
            }
        }
        cout << "Cleaner not found" << endl;
    }

    void displayCleaners() {
        for (int i = 0; i < cleanerCount; ++i) {
            cout << "Cleaner ID: " << cleaners[i].id << " Name: " << cleaners[i].name << endl;
        }
    }
};

int main() {
    CarCleanerManagementSystem system;

    system.addCar(1, "Toyota", "Corolla");
    system.addCar(2, "Honda", "Civic");
    system.displayCars();

    system.addCleaner(1, "John Doe");
    system.addCleaner(2, "Jane Smith");
    system.displayCleaners();

    system.updateCar(1, "Toyota", "Camry");
    system.searchCar(1);

    system.updateCleaner(2, "Jane Doe");
    system.searchCleaner(2);

    system.deleteCar(2);
    system.displayCars();

    system.deleteCleaner(1);
    system.displayCleaners();

    return 0;
}