#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    int id;
    string model;
    string ownerName;
};

struct Cleaner {
    int id;
    string name;
    int yearsOfExperience;
};

vector<Car> cars;
vector<Cleaner> cleaners;

int carIdCounter = 1;
int cleanerIdCounter = 1;

void addCar(string model, string ownerName) {
    Car newCar = {carIdCounter++, model, ownerName};
    cars.push_back(newCar);
}

void addCleaner(string name, int yearsOfExperience) {
    Cleaner newCleaner = {cleanerIdCounter++, name, yearsOfExperience};
    cleaners.push_back(newCleaner);
}

void deleteCar(int id) {
    for (auto it = cars.begin(); it != cars.end(); ++it) {
        if (it->id == id) {
            cars.erase(it);
            break;
        }
    }
}

void deleteCleaner(int id) {
    for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
        if (it->id == id) {
            cleaners.erase(it);
            break;
        }
    }
}

void updateCar(int id, string model, string ownerName) {
    for (auto &car : cars) {
        if (car.id == id) {
            car.model = model;
            car.ownerName = ownerName;
            break;
        }
    }
}

void updateCleaner(int id, string name, int yearsOfExperience) {
    for (auto &cleaner : cleaners) {
        if (cleaner.id == id) {
            cleaner.name = name;
            cleaner.yearsOfExperience = yearsOfExperience;
            break;
        }
    }
}

Car* searchCar(int id) {
    for (auto &car : cars) {
        if (car.id == id) {
            return &car;
        }
    }
    return nullptr;
}

Cleaner* searchCleaner(int id) {
    for (auto &cleaner : cleaners) {
        if (cleaner.id == id) {
            return &cleaner;
        }
    }
    return nullptr;
}

void displayCars() {
    for (const auto &car : cars) {
        cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner Name: " << car.ownerName << endl;
    }
}

void displayCleaners() {
    for (const auto &cleaner : cleaners) {
        cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << ", Years of Experience: " << cleaner.yearsOfExperience << endl;
    }
}

int main() {
    int choice, id, years;
    string model, owner, name;

    while (true) {
        cout << "1. Add Car\n2. Add Cleaner\n3. Delete Car\n4. Delete Cleaner\n5. Update Car\n6. Update Cleaner\n7. Search Car\n8. Search Cleaner\n9. Display Cars\n10. Display Cleaners\n11. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter car model: ";
                cin >> model;
                cout << "Enter owner name: ";
                cin >> owner;
                addCar(model, owner);
                break;
            case 2:
                cout << "Enter cleaner name: ";
                cin >> name;
                cout << "Enter years of experience: ";
                cin >> years;
                addCleaner(name, years);
                break;
            case 3:
                cout << "Enter car ID to delete: ";
                cin >> id;
                deleteCar(id);
                break;
            case 4:
                cout << "Enter cleaner ID to delete: ";
                cin >> id;
                deleteCleaner(id);
                break;
            case 5:
                cout << "Enter car ID to update: ";
                cin >> id;
                cout << "Enter new car model: ";
                cin >> model;
                cout << "Enter new owner name: ";
                cin >> owner;
                updateCar(id, model, owner);
                break;
            case 6:
                cout << "Enter cleaner ID to update: ";
                cin >> id;
                cout << "Enter new cleaner name: ";
                cin >> name;
                cout << "Enter new years of experience: ";
                cin >> years;
                updateCleaner(id, name, years);
                break;
            case 7:
                cout << "Enter car ID to search: ";
                cin >> id;
                if (auto *car = searchCar(id)) {
                    cout << "Car found: ID = " << car->id << ", Model = " << car->model << ", Owner Name = " << car->ownerName << endl;
                } else {
                    cout << "Car not found\n";
                }
                break;
            case 8:
                cout << "Enter cleaner ID to search: ";
                cin >> id;
                if (auto *cleaner = searchCleaner(id)) {
                    cout << "Cleaner found: ID = " << cleaner->id << ", Name = " << cleaner->name << ", Years of Experience = " << cleaner->yearsOfExperience << endl;
                } else {
                    cout << "Cleaner not found\n";
                }
                break;
            case 9:
                displayCars();
                break;
            case 10:
                displayCleaners();
                break;
            case 11:
                return 0;
        }
    }
}