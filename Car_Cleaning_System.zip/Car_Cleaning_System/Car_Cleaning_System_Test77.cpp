#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    int carId;
    string model;
    string ownerName;
};

struct Cleaner {
    int cleanerId;
    string name;
    int age;
};

class CarCleaningSystem {
    vector<Car> cars;
    vector<Cleaner> cleaners;
    
public:
    void addCar(int carId, const string& model, const string& ownerName) {
        Car newCar = { carId, model, ownerName };
        cars.push_back(newCar);
    }
    
    void deleteCar(int carId) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->carId == carId) {
                cars.erase(it);
                return;
            }
        }
    }
    
    void updateCar(int carId, const string& model, const string& ownerName) {
        for (auto& car : cars) {
            if (car.carId == carId) {
                car.model = model;
                car.ownerName = ownerName;
                return;
            }
        }
    }
    
    Car* searchCar(int carId) {
        for (auto& car : cars) {
            if (car.carId == carId) {
                return &car;
            }
        }
        return nullptr;
    }
    
    void displayCars() {
        for (const auto& car : cars) {
            cout << "Car ID: " << car.carId << ", Model: " << car.model 
                 << ", Owner Name: " << car.ownerName << endl;
        }
    }

    void addCleaner(int cleanerId, const string& name, int age) {
        Cleaner newCleaner = { cleanerId, name, age };
        cleaners.push_back(newCleaner);
    }
    
    void deleteCleaner(int cleanerId) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->cleanerId == cleanerId) {
                cleaners.erase(it);
                return;
            }
        }
    }
    
    void updateCleaner(int cleanerId, const string& name, int age) {
        for (auto& cleaner : cleaners) {
            if (cleaner.cleanerId == cleanerId) {
                cleaner.name = name;
                cleaner.age = age;
                return;
            }
        }
    }
    
    Cleaner* searchCleaner(int cleanerId) {
        for (auto& cleaner : cleaners) {
            if (cleaner.cleanerId == cleanerId) {
                return &cleaner;
            }
        }
        return nullptr;
    }
    
    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            cout << "Cleaner ID: " << cleaner.cleanerId << ", Name: " << cleaner.name 
                 << ", Age: " << cleaner.age << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota Camry", "John Doe");
    system.addCar(2, "Honda Accord", "Jane Smith");
    system.displayCars();
    
    system.addCleaner(1, "Mike Johnson", 28);
    system.addCleaner(2, "Emma Watson", 30);
    system.displayCleaners();
    
    return 0;
}