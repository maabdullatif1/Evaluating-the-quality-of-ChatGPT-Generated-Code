#include <iostream>
#include <string>

class Car {
public:
    std::string plateNumber;
    std::string model;
};

class Cleaner {
public:
    std::string name;
    int id;
};

class CarCleaningSystem {
public:
    Car cars[100];
    Cleaner cleaners[100];
    int carCount;
    int cleanerCount;

    CarCleaningSystem() : carCount(0), cleanerCount(0) {}

    void addCar(const std::string& plate, const std::string& model) {
        cars[carCount].plateNumber = plate;
        cars[carCount].model = model;
        carCount++;
    }

    void deleteCar(const std::string& plate) {
        for (int i = 0; i < carCount; i++) {
            if (cars[i].plateNumber == plate) {
                cars[i] = cars[carCount - 1];
                carCount--;
                break;
            }
        }
    }

    void updateCar(const std::string& plate, const std::string& newModel) {
        for (int i = 0; i < carCount; i++) {
            if (cars[i].plateNumber == plate) {
                cars[i].model = newModel;
                break;
            }
        }
    }

    void searchCar(const std::string& plate) {
        for (int i = 0; i < carCount; i++) {
            if (cars[i].plateNumber == plate) {
                std::cout << "Car found: " << cars[i].plateNumber << " " << cars[i].model << std::endl;
                return;
            }
        }
        std::cout << "Car not found." << std::endl;
    }

    void displayCars() {
        for (int i = 0; i < carCount; i++) {
            std::cout << cars[i].plateNumber << " " << cars[i].model << std::endl;
        }
    }

    void addCleaner(const std::string& name, int id) {
        cleaners[cleanerCount].name = name;
        cleaners[cleanerCount].id = id;
        cleanerCount++;
    }

    void deleteCleaner(int id) {
        for (int i = 0; i < cleanerCount; i++) {
            if (cleaners[i].id == id) {
                cleaners[i] = cleaners[cleanerCount - 1];
                cleanerCount--;
                break;
            }
        }
    }

    void updateCleaner(int id, const std::string& newName) {
        for (int i = 0; i < cleanerCount; i++) {
            if (cleaners[i].id == id) {
                cleaners[i].name = newName;
                break;
            }
        }
    }

    void searchCleaner(int id) {
        for (int i = 0; i < cleanerCount; i++) {
            if (cleaners[i].id == id) {
                std::cout << "Cleaner found: " << cleaners[i].name << " ID: " << cleaners[i].id << std::endl;
                return;
            }
        }
        std::cout << "Cleaner not found." << std::endl;
    }

    void displayCleaners() {
        for (int i = 0; i < cleanerCount; i++) {
            std::cout << cleaners[i].name << " ID: " << cleaners[i].id << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("ABC123", "Toyota");
    system.addCar("XYZ789", "Honda");
    system.addCleaner("John", 1);
    system.addCleaner("Alice", 2);
    system.displayCars();
    system.displayCleaners();
    system.searchCar("XYZ789");
    system.searchCleaner(1);
    system.updateCar("ABC123", "Ford");
    system.updateCleaner(2, "Bob");
    system.displayCars();
    system.displayCleaners();
    system.deleteCar("XYZ789");
    system.deleteCleaner(1);
    system.displayCars();
    system.displayCleaners();
    return 0;
}