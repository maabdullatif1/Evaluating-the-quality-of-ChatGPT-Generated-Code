#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Car {
    int id;
    string make;
    string model;
    int year;
};

struct Cleaner {
    int id;
    string name;
    string shift;
};

class CarCleaningSystem {
public:
    void addCar(int id, const string& make, const string& model, int year) {
        cars.push_back({id, make, model, year});
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, const string& make, const string& model, int year) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.year = year;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            cout << "ID: " << car.id << " Make: " << car.make
                 << " Model: " << car.model << " Year: " << car.year << endl;
        }
    }

    void addCleaner(int id, const string& name, const string& shift) {
        cleaners.push_back({id, name, shift});
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, const string& name, const string& shift) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                cleaner.shift = shift;
                break;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            cout << "ID: " << cleaner.id << " Name: " << cleaner.name
                 << " Shift: " << cleaner.shift << endl;
        }
    }

private:
    vector<Car> cars;
    vector<Cleaner> cleaners;
};

int main() {
    CarCleaningSystem ccs;
    ccs.addCar(1, "Toyota", "Camry", 2021);
    ccs.addCar(2, "Tesla", "Model 3", 2022);
    ccs.displayCars();
    ccs.addCleaner(1, "John Doe", "Morning");
    ccs.addCleaner(2, "Jane Smith", "Evening");
    ccs.displayCleaners();
    return 0;
}