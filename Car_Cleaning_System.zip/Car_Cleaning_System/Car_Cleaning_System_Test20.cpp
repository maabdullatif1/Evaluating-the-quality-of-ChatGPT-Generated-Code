#include <iostream>
#include <string>

struct Car {
    int id;
    std::string model;
    std::string color;
};

struct Cleaner {
    int id;
    std::string name;
};

class CleaningSystem {
private:
    Car cars[100];
    Cleaner cleaners[50];
    int carCount = 0;
    int cleanerCount = 0;

public:
    void addCar(int id, std::string model, std::string color) {
        cars[carCount++] = { id, model, color };
    }

    void deleteCar(int id) {
        for (int i = 0; i < carCount; ++i) {
            if (cars[i].id == id) {
                for (int j = i; j < carCount - 1; ++j) {
                    cars[j] = cars[j + 1];
                }
                --carCount;
                break;
            }
        }
    }

    void updateCar(int id, std::string model, std::string color) {
        for (int i = 0; i < carCount; ++i) {
            if (cars[i].id == id) {
                cars[i].model = model;
                cars[i].color = color;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (int i = 0; i < carCount; ++i) {
            if (cars[i].id == id) {
                return &cars[i];
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (int i = 0; i < carCount; ++i) {
            std::cout << "ID: " << cars[i].id << ", Model: " << cars[i].model << ", Color: " << cars[i].color << std::endl;
        }
    }

    void addCleaner(int id, std::string name) {
        cleaners[cleanerCount++] = { id, name };
    }

    void deleteCleaner(int id) {
        for (int i = 0; i < cleanerCount; ++i) {
            if (cleaners[i].id == id) {
                for (int j = i; j < cleanerCount - 1; ++j) {
                    cleaners[j] = cleaners[j + 1];
                }
                --cleanerCount;
                break;
            }
        }
    }

    void updateCleaner(int id, std::string name) {
        for (int i = 0; i < cleanerCount; ++i) {
            if (cleaners[i].id == id) {
                cleaners[i].name = name;
                break;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for (int i = 0; i < cleanerCount; ++i) {
            if (cleaners[i].id == id) {
                return &cleaners[i];
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (int i = 0; i < cleanerCount; ++i) {
            std::cout << "ID: " << cleaners[i].id << ", Name: " << cleaners[i].name << std::endl;
        }
    }
};

int main() {
    CleaningSystem system;
    system.addCar(1, "Tesla Model S", "Red");
    system.addCleaner(1, "Alice");
    system.displayCars();
    system.displayCleaners();
    return 0;
}