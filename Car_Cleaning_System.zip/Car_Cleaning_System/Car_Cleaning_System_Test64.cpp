#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string model;
    string owner;
    Car(int i, string m, string o) : id(i), model(m), owner(o) {}
};

class Cleaner {
public:
    int id;
    string name;
    Cleaner(int i, string n) : id(i), name(n) {}
};

class CarCleaningSystem {
private:
    vector<Car> cars;
    vector<Cleaner> cleaners;

    Car* findCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    Cleaner* findCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

public:
    void addCar(int id, string model, string owner) {
        if (findCar(id)) return;
        cars.push_back(Car(id, model, owner));
    }

    void deleteCar(int id) {
        for (size_t i = 0; i < cars.size(); ++i) {
            if (cars[i].id == id) {
                cars.erase(cars.begin() + i);
                break;
            }
        }
    }

    void updateCar(int id, string model, string owner) {
        Car* car = findCar(id);
        if (car) {
            car->model = model;
            car->owner = owner;
        }
    }

    Car* searchCar(int id) {
        return findCar(id);
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << endl;
        }
    }

    void addCleaner(int id, string name) {
        if (findCleaner(id)) return;
        cleaners.push_back(Cleaner(id, name));
    }

    void deleteCleaner(int id) {
        for (size_t i = 0; i < cleaners.size(); ++i) {
            if (cleaners[i].id == id) {
                cleaners.erase(cleaners.begin() + i);
                break;
            }
        }
    }

    void updateCleaner(int id, string name) {
        Cleaner* cleaner = findCleaner(id);
        if (cleaner) {
            cleaner->name = name;
        }
    }

    Cleaner* searchCleaner(int id) {
        return findCleaner(id);
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Tesla Model S", "Alice");
    system.addCar(2, "Toyota Corolla", "Bob");
    system.addCleaner(1, "John");
    system.addCleaner(2, "Sarah");
    
    system.displayCars();
    system.displayCleaners();

    system.updateCar(1, "Tesla Model X", "Alice");
    system.updateCleaner(1, "Johnny");

    Car* car = system.searchCar(1);
    if (car) {
        cout << "Found Car: ID " << car->id << ", Model: " << car->model << ", Owner: " << car->owner << endl;
    }

    Cleaner* cleaner = system.searchCleaner(1);
    if (cleaner) {
        cout << "Found Cleaner: ID " << cleaner->id << ", Name: " << cleaner->name << endl;
    }

    system.deleteCar(2);
    system.deleteCleaner(2);
    
    system.displayCars();
    system.displayCleaners();

    return 0;
}