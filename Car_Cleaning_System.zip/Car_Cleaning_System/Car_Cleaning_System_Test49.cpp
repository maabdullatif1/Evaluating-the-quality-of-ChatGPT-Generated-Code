#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string make;
    std::string model;

    Car(int id, const std::string &make, const std::string &model) 
        : id(id), make(make), model(model) {}
};

class Cleaner {
public:
    int id;
    std::string name;
    std::string shift;

    Cleaner(int id, const std::string &name, const std::string &shift) 
        : id(id), name(name), shift(shift) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(int id, const std::string &make, const std::string &model) {
        cars.push_back(Car(id, make, model));
    }

    void addCleaner(int id, const std::string &name, const std::string &shift) {
        cleaners.push_back(Cleaner(id, name, shift));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                return;
            }
        }
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                return;
            }
        }
    }

    void updateCar(int id, const std::string &make, const std::string &model) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                return;
            }
        }
    }

    void updateCleaner(int id, const std::string &name, const std::string &shift) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                cleaner.shift = shift;
                return;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    Cleaner* searchCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "Car ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << std::endl;
        }
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << ", Shift: " << cleaner.shift << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Corolla");
    system.addCar(2, "Honda", "Civic");
    system.addCleaner(1, "Alice", "Morning");
    system.addCleaner(2, "Bob", "Evening");

    system.displayCars();
    system.displayCleaners();

    system.updateCar(1, "Toyota", "Camry");
    system.updateCleaner(1, "Alice", "Afternoon");

    system.displayCars();
    system.displayCleaners();

    system.deleteCar(2);
    system.deleteCleaner(2);

    system.displayCars();
    system.displayCleaners();

    return 0;
}