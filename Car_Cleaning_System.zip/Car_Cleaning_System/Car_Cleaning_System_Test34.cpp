#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string model;
    std::string ownerName;

    Car(std::string license, std::string mdl, std::string owner) 
        : licensePlate(license), model(mdl), ownerName(owner) {}

    void display() const {
        std::cout << "License Plate: " << licensePlate 
                  << ", Model: " << model 
                  << ", Owner: " << ownerName << std::endl;
    }
};

class Cleaner {
public:
    std::string name;
    int id;

    Cleaner(std::string nm, int idNum) : name(nm), id(idNum) {}

    void display() const {
        std::cout << "Cleaner ID: " << id 
                  << ", Name: " << name << std::endl;
    }
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;
    
public:
    void addCar(const Car& car) {
        cars.push_back(car);
    }

    void deleteCar(const std::string& licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                return;
            }
        }
    }

    void updateCar(const std::string& licensePlate, const std::string& newModel, const std::string& newOwner) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                car.model = newModel;
                car.ownerName = newOwner;
                return;
            }
        }
    }

    void displayCars() const {
        for (const auto& car : cars) {
            car.display();
        }
    }

    Car* searchCar(const std::string& licensePlate) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                return &car;
            }
        }
        return nullptr;
    }

    void addCleaner(const Cleaner& cleaner) {
        cleaners.push_back(cleaner);
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                return;
            }
        }
    }

    void updateCleaner(int id, const std::string& newName) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = newName;
                return;
            }
        }
    }

    void displayCleaners() const {
        for (const auto& cleaner : cleaners) {
            cleaner.display();
        }
    }

    Cleaner* searchCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }
};

int main() {
    CarCleaningSystem system;
    
    system.addCar(Car("ABC123", "Toyota", "John Doe"));
    system.addCar(Car("XYZ789", "Honda", "Jane Smith"));
    system.addCleaner(Cleaner("Alex Johnson", 1));
    system.addCleaner(Cleaner("Samantha Brown", 2));

    system.displayCars();
    system.displayCleaners();

    system.updateCar("ABC123", "BMW", "John Doe Jr.");
    system.updateCleaner(1, "Alexander Johnson");

    system.displayCars();
    system.displayCleaners();

    Car* car = system.searchCar("XYZ789");
    Cleaner* cleaner = system.searchCleaner(2);

    if (car != nullptr) car->display();
    if (cleaner != nullptr) cleaner->display();

    system.deleteCar("XYZ789");
    system.deleteCleaner(2);

    system.displayCars();
    system.displayCleaners();

    return 0;
}