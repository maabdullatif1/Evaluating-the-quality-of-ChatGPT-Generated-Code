#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string regNumber;
    std::string model;
    std::string color;

    Car(std::string rn, std::string m, std::string c) : regNumber(rn), model(m), color(c) {}
};

class Cleaner {
public:
    std::string name;
    int id;

    Cleaner(std::string n, int i) : name(n), id(i) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(std::string regNumber, std::string model, std::string color) {
        cars.emplace_back(regNumber, model, color);
    }

    void addCleaner(std::string name, int id) {
        cleaners.emplace_back(name, id);
    }

    void deleteCar(std::string regNumber) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->regNumber == regNumber) {
                cars.erase(it);
                return;
            }
        }
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                return;
            }
        }
    }

    void updateCar(std::string regNumber, std::string newModel, std::string newColor) {
        for (auto& car : cars) {
            if (car.regNumber == regNumber) {
                car.model = newModel;
                car.color = newColor;
                return;
            }
        }
    }

    void updateCleaner(int id, std::string newName) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = newName;
                return;
            }
        }
    }

    Car* searchCar(std::string regNumber) {
        for (auto& car : cars) {
            if (car.regNumber == regNumber) {
                return &car;
            }
        }
        return nullptr;
    }

    Cleaner* searchCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (auto& car : cars) {
            std::cout << "RegNumber: " << car.regNumber << ", Model: " << car.model << ", Color: " << car.color << std::endl;
        }
    }

    void displayCleaners() {
        for (auto& cleaner : cleaners) {
            std::cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("123ABC", "Toyota", "Red");
    system.addCleaner("John Doe", 1);
    system.displayCars();
    system.displayCleaners();
    system.updateCar("123ABC", "Honda", "Blue");
    system.updateCleaner(1, "Jane Doe");
    system.displayCars();
    system.displayCleaners();
    system.deleteCar("123ABC");
    system.deleteCleaner(1);
    system.displayCars();
    system.displayCleaners();
    return 0;
}