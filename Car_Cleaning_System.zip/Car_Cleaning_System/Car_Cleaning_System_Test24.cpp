#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string make;
    std::string model;
    std::string licensePlate;

    Car(int id, const std::string& make, const std::string& model, const std::string& licensePlate)
        : id(id), make(make), model(model), licensePlate(licensePlate) {}
};

class Cleaner {
public:
    int id;
    std::string name;
    std::string phoneNumber;

    Cleaner(int id, const std::string& name, const std::string& phoneNumber)
        : id(id), name(name), phoneNumber(phoneNumber) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;
    int carCounter;
    int cleanerCounter;

public:
    CarCleaningSystem() : carCounter(0), cleanerCounter(0) {}

    void addCar(const std::string& make, const std::string& model, const std::string& licensePlate) {
        cars.push_back(Car(++carCounter, make, model, licensePlate));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                return;
            }
        }
    }

    void updateCar(int id, const std::string& make, const std::string& model, const std::string& licensePlate) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.licensePlate = licensePlate;
                return;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "ID: " << car.id << ", Make: " << car.make
                      << ", Model: " << car.model << ", License Plate: " << car.licensePlate << "\n";
        }
    }

    void addCleaner(const std::string& name, const std::string& phoneNumber) {
        cleaners.push_back(Cleaner(++cleanerCounter, name, phoneNumber));
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                return;
            }
        }
    }

    void updateCleaner(int id, const std::string& name, const std::string& phoneNumber) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                cleaner.phoneNumber = phoneNumber;
                return;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "ID: " << cleaner.id << ", Name: " << cleaner.name
                      << ", Phone: " << cleaner.phoneNumber << "\n";
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("Toyota", "Camry", "ABC123");
    system.addCar("Honda", "Accord", "XYZ789");
    system.displayCars();

    system.addCleaner("John Doe", "555-1234");
    system.addCleaner("Jane Smith", "555-5678");
    system.displayCleaners();

    return 0;
}