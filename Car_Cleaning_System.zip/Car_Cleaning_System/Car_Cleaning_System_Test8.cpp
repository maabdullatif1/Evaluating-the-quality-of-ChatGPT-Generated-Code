#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string make;
    std::string model;
    
    Car(std::string license, std::string make, std::string model)
        : licensePlate(license), make(make), model(model) {}
};

class Cleaner {
public:
    int id;
    std::string name;

    Cleaner(int id, std::string name) : id(id), name(name) {}
};

class CarCleaningSystem {
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;
    
public:
    void addCar(std::string license, std::string make, std::string model) {
        cars.push_back(Car(license, make, model));
    }

    void deleteCar(std::string license) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == license) {
                cars.erase(it);
                break;
            }
        }
    }
    
    void updateCar(std::string license, std::string newMake, std::string newModel) {
        for (auto &car : cars) {
            if (car.licensePlate == license) {
                car.make = newMake;
                car.model = newModel;
                break;
            }
        }
    }

    void searchCar(std::string license) {
        for (const auto &car : cars) {
            if (car.licensePlate == license) {
                std::cout << "License Plate: " << car.licensePlate << ", Make: " << car.make 
                          << ", Model: " << car.model << "\n";
                return;
            }
        }
        std::cout << "Car not found\n";
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "License Plate: " << car.licensePlate << ", Make: " << car.make 
                      << ", Model: " << car.model << "\n";
        }
    }

    void addCleaner(int id, std::string name) {
        cleaners.push_back(Cleaner(id, name));
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }
    
    void updateCleaner(int id, std::string newName) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = newName;
                break;
            }
        }
    }

    void searchCleaner(int id) {
        for (const auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                std::cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << "\n";
                return;
            }
        }
        std::cout << "Cleaner not found\n";
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            std::cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << "\n";
        }
    }
};

int main() {
    CarCleaningSystem ccs;

    ccs.addCar("ABC123", "Toyota", "Corolla");
    ccs.addCar("DEF456", "Honda", "Civic");
    ccs.displayCars();

    ccs.addCleaner(1, "John Doe");
    ccs.addCleaner(2, "Jane Smith");
    ccs.displayCleaners();

    ccs.searchCar("ABC123");
    ccs.updateCar("ABC123", "Toyota", "Camry");
    ccs.searchCar("ABC123");

    ccs.searchCleaner(1);
    ccs.updateCleaner(1, "Johnathan Doe");
    ccs.searchCleaner(1);

    ccs.deleteCar("DEF456");
    ccs.displayCars();

    ccs.deleteCleaner(2);
    ccs.displayCleaners();

    return 0;
}