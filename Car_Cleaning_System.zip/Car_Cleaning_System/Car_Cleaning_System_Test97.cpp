#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string model;
    std::string license_plate;

    Car(int i, const std::string& m, const std::string& lp)
        : id(i), model(m), license_plate(lp) {}
};

class Cleaner {
public:
    int id;
    std::string name;
    int experience;

    Cleaner(int i, const std::string& n, int e)
        : id(i), name(n), experience(e) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(int id, const std::string& model, const std::string& license_plate) {
        cars.push_back(Car(id, model, license_plate));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, const std::string& model, const std::string& license_plate) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.model = model;
                car.license_plate = license_plate;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Car ID: " << car.id << ", Model: " << car.model
                      << ", License Plate: " << car.license_plate << '\n';
        }
    }

    void addCleaner(int id, const std::string& name, int experience) {
        cleaners.push_back(Cleaner(id, name, experience));
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, const std::string& name, int experience) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                cleaner.experience = experience;
                break;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name
                      << ", Experience: " << cleaner.experience << " years\n";
        }
    }
};

int main() {
    CarCleaningSystem system;

    system.addCar(1, "Toyota Camry", "ABC123");
    system.addCar(2, "Honda Accord", "XYZ789");
    system.addCleaner(1, "John Doe", 5);
    system.addCleaner(2, "Jane Smith", 3);

    system.displayCars();
    system.displayCleaners();

    system.updateCar(1, "Toyota Corolla", "DEF456");
    system.updateCleaner(2, "Jane Smith", 4);

    system.displayCars();
    system.displayCleaners();

    Car* car = system.searchCar(1);
    if (car) std::cout << "Found Car: " << car->model << '\n';

    Cleaner* cleaner = system.searchCleaner(2);
    if (cleaner) std::cout << "Found Cleaner: " << cleaner->name << '\n';

    system.deleteCar(2);
    system.deleteCleaner(1);

    system.displayCars();
    system.displayCleaners();

    return 0;
}