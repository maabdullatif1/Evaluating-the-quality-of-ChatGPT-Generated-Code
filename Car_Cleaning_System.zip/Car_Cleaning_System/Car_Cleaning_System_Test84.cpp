#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

struct Car {
    int id;
    std::string ownerName;
    std::string model;
};

struct Cleaner {
    int id;
    std::string name;
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;
    int carIdCounter = 0;
    int cleanerIdCounter = 0;

    template<typename T>
    T* searchById(std::vector<T>& items, int id) {
        for (auto &item : items) {
            if (item.id == id)
                return &item;
        }
        return nullptr;
    }

    template<typename T>
    void displayItems(const std::vector<T>& items) {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << ", ";
            if constexpr (std::is_same<T, Car>::value)
                std::cout << "Owner Name: " << item.ownerName << ", Model: " << item.model;
            else
                std::cout << "Name: " << item.name;
            std::cout << std::endl;
        }
    }

public:
    void addCar(const std::string& ownerName, const std::string& model) {
        cars.push_back({++carIdCounter, ownerName, model});
    }

    void deleteCar(int carId) {
        cars.erase(std::remove_if(cars.begin(), cars.end(),
                                  [=](Car& c) { return c.id == carId; }),
                   cars.end());
    }

    void updateCar(int carId, const std::string& ownerName, const std::string& model) {
        Car* car = searchById(cars, carId);
        if (car) {
            car->ownerName = ownerName;
            car->model = model;
        }
    }

    void searchCar(int carId) {
        Car* car = searchById(cars, carId);
        if (car) {
            std::cout << "Car found: ID: " << car->id << ", Owner: " << car->ownerName 
                      << ", Model: " << car->model << std::endl;
        } else {
            std::cout << "Car not found." << std::endl;
        }
    }

    void displayCars() {
        displayItems(cars);
    }

    void addCleaner(const std::string& name) {
        cleaners.push_back({++cleanerIdCounter, name});
    }

    void deleteCleaner(int cleanerId) {
        cleaners.erase(std::remove_if(cleaners.begin(), cleaners.end(),
                                      [=](Cleaner& cl) { return cl.id == cleanerId; }),
                       cleaners.end());
    }

    void updateCleaner(int cleanerId, const std::string& name) {
        Cleaner* cleaner = searchById(cleaners, cleanerId);
        if (cleaner) {
            cleaner->name = name;
        }
    }

    void searchCleaner(int cleanerId) {
        Cleaner* cleaner = searchById(cleaners, cleanerId);
        if (cleaner) {
            std::cout << "Cleaner found: ID: " << cleaner->id << ", Name: " << cleaner->name << std::endl;
        } else {
            std::cout << "Cleaner not found." << std::endl;
        }
    }

    void displayCleaners() {
        displayItems(cleaners);
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("John Doe", "Toyota Corolla");
    system.addCar("Jane Smith", "Honda Civic");
    system.displayCars();
    system.addCleaner("Mike Johnson");
    system.addCleaner("Emily Brown");
    system.displayCleaners();

    system.updateCar(1, "Johnathan Doe", "Tesla Model S");
    system.displayCars();

    system.searchCar(2);
    system.deleteCar(2);
    system.displayCars();

    system.searchCleaner(1);
    system.updateCleaner(1, "Michael Johnson");
    system.displayCleaners();

    system.deleteCleaner(2);
    system.displayCleaners();

    return 0;
}