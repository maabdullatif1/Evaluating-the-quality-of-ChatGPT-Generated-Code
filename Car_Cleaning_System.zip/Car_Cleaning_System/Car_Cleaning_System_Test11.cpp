#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string model;
    std::string owner;

    Car(std::string lp, std::string mod, std::string own) : licensePlate(lp), model(mod), owner(own) {}
};

class Cleaner {
public:
    std::string name;
    int age;
    std::string contactNumber;

    Cleaner(std::string n, int a, std::string cn) : name(n), age(a), contactNumber(cn) {}
};

class CarCleaningSystem {
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(const std::string& licensePlate, const std::string& model, const std::string& owner) {
        cars.emplace_back(licensePlate, model, owner);
    }

    void deleteCar(const std::string& licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string& licensePlate, const std::string& model, const std::string& owner) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                car.model = model;
                car.owner = owner;
                break;
            }
        }
    }

    Car* searchCar(const std::string& licensePlate) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "License Plate: " << car.licensePlate << ", Model: " << car.model << ", Owner: " << car.owner << std::endl;
        }
    }

    void addCleaner(const std::string& name, int age, const std::string& contactNumber) {
        cleaners.emplace_back(name, age, contactNumber);
    }

    void deleteCleaner(const std::string& name) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->name == name) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(const std::string& name, int age, const std::string& contactNumber) {
        for (auto& cleaner : cleaners) {
            if (cleaner.name == name) {
                cleaner.age = age;
                cleaner.contactNumber = contactNumber;
                break;
            }
        }
    }

    Cleaner* searchCleaner(const std::string& name) {
        for (auto& cleaner : cleaners) {
            if (cleaner.name == name) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "Name: " << cleaner.name << ", Age: " << cleaner.age << ", Contact: " << cleaner.contactNumber << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("ABC123", "Toyota Corolla", "John Doe");
    system.addCleaner("Alice Smith", 30, "555-0199");
    system.displayCars();
    system.displayCleaners();
    return 0;
}