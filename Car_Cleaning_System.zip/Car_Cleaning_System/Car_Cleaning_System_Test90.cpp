#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Car {
    int id;
    string make;
    string model;
    string license;
};

struct Cleaner {
    int id;
    string name;
};

class CarCleaningSystem {
    vector<Car> cars;
    vector<Cleaner> cleaners;

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id)
                return &car;
        }
        return nullptr;
    }

    Cleaner* searchCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id)
                return &cleaner;
        }
        return nullptr;
    }

public:
    void addCar(int id, string make, string model, string license) {
        if (searchCar(id) == nullptr) {
            cars.push_back({id, make, model, license});
        }
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string make, string model, string license) {
        Car* car = searchCar(id);
        if (car != nullptr) {
            car->make = make;
            car->model = model;
            car->license = license;
        }
    }

    void displayCar(int id) {
        Car* car = searchCar(id);
        if (car != nullptr) {
            cout << "Car ID: " << car->id << " Make: " << car->make
                 << " Model: " << car->model << " License: " << car->license << endl;
        }
    }

    void displayAllCars() {
        for (auto &car : cars) {
            cout << "Car ID: " << car.id << " Make: " << car.make
                 << " Model: " << car.model << " License: " << car.license << endl;
        }
    }

    void addCleaner(int id, string name) {
        if (searchCleaner(id) == nullptr) {
            cleaners.push_back({id, name});
        }
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, string name) {
        Cleaner* cleaner = searchCleaner(id);
        if (cleaner != nullptr) {
            cleaner->name = name;
        }
    }

    void displayCleaner(int id) {
        Cleaner* cleaner = searchCleaner(id);
        if (cleaner != nullptr) {
            cout << "Cleaner ID: " << cleaner->id << " Name: " << cleaner->name << endl;
        }
    }

    void displayAllCleaners() {
        for (auto &cleaner : cleaners) {
            cout << "Cleaner ID: " << cleaner.id << " Name: " << cleaner.name << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Corolla", "XYZ123");
    system.addCar(2, "Honda", "Civic", "ABC456");
    system.displayAllCars();
    system.addCleaner(1, "John Doe");
    system.addCleaner(2, "Jane Smith");
    system.displayAllCleaners();
    return 0;
}