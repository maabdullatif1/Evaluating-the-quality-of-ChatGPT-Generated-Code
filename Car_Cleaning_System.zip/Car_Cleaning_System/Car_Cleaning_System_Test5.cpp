#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    int id;
    string make;
    string model;
};

struct Cleaner {
    int id;
    string name;
};

vector<Car> cars;
vector<Cleaner> cleaners;

void addCar(int id, const string& make, const string& model) {
    cars.push_back({id, make, model});
}

void addCleaner(int id, const string& name) {
    cleaners.push_back({id, name});
}

void updateCar(int id, const string& newMake, const string& newModel) {
    for (auto& car : cars) {
        if (car.id == id) {
            car.make = newMake;
            car.model = newModel;
            return;
        }
    }
}

void updateCleaner(int id, const string& newName) {
    for (auto& cleaner : cleaners) {
        if (cleaner.id == id) {
            cleaner.name = newName;
            return;
        }
    }
}

void deleteCar(int id) {
    cars.erase(remove_if(cars.begin(), cars.end(), [id](Car& car) { return car.id == id; }), cars.end());
}

void deleteCleaner(int id) {
    cleaners.erase(remove_if(cleaners.begin(), cleaners.end(), [id](Cleaner& cleaner) { return cleaner.id == id; }), cleaners.end());
}

Car* searchCar(int id) {
    for (auto& car : cars) {
        if (car.id == id) {
            return &car;
        }
    }
    return nullptr;
}

Cleaner* searchCleaner(int id) {
    for (auto& cleaner : cleaners) {
        if (cleaner.id == id) {
            return &cleaner;
        }
    }
    return nullptr;
}

void displayCars() {
    for (const auto& car : cars) {
        cout << "Car ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << endl;
    }
}

void displayCleaners() {
    for (const auto& cleaner : cleaners) {
        cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << endl;
    }
}

int main() {
    addCar(1, "Toyota", "Camry");
    addCar(2, "Honda", "Civic");
    addCleaner(1, "John Doe");
    addCleaner(2, "Jane Smith");
    
    updateCar(1, "Toyota", "Corolla");
    updateCleaner(2, "Jane Doe");
    
    displayCars();
    displayCleaners();
    
    deleteCar(2);
    deleteCleaner(1);
    
    displayCars();
    displayCleaners();
    
    Car* car = searchCar(1);
    Cleaner* cleaner = searchCleaner(2);
    
    if (car) {
        cout << "Found Car: " << car->make << " " << car->model << endl;
    }
    
    if (cleaner) {
        cout << "Found Cleaner: " << cleaner->name << endl;
    }
    
    return 0;
}