#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string model;
    std::string owner;

    Car(int id, std::string model, std::string owner) : id(id), model(model), owner(owner) {}
};

class Cleaner {
public:
    int id;
    std::string name;
    int age;

    Cleaner(int id, std::string name, int age) : id(id), name(name), age(age) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

    int findCar(int id) {
        for (size_t i = 0; i < cars.size(); i++) {
            if (cars[i].id == id)
                return i;
        }
        return -1;
    }

    int findCleaner(int id) {
        for (size_t i = 0; i < cleaners.size(); i++) {
            if (cleaners[i].id == id)
                return i;
        }
        return -1;
    }

public:
    void addCar(int id, std::string model, std::string owner) {
        cars.push_back(Car(id, model, owner));
    }

    void deleteCar(int id) {
        int index = findCar(id);
        if (index != -1)
            cars.erase(cars.begin() + index);
    }

    void updateCar(int id, std::string model, std::string owner) {
        int index = findCar(id);
        if (index != -1) {
            cars[index].model = model;
            cars[index].owner = owner;
        }
    }

    Car* searchCar(int id) {
        int index = findCar(id);
        if (index != -1)
            return &cars[index];
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << std::endl;
        }
    }

    void addCleaner(int id, std::string name, int age) {
        cleaners.push_back(Cleaner(id, name, age));
    }

    void deleteCleaner(int id) {
        int index = findCleaner(id);
        if (index != -1)
            cleaners.erase(cleaners.begin() + index);
    }

    void updateCleaner(int id, std::string name, int age) {
        int index = findCleaner(id);
        if (index != -1) {
            cleaners[index].name = name;
            cleaners[index].age = age;
        }
    }

    Cleaner* searchCleaner(int id) {
        int index = findCleaner(id);
        if (index != -1)
            return &cleaners[index];
        return nullptr;
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << ", Age: " << cleaner.age << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    
    system.addCar(1, "Toyota Camry", "John Doe");
    system.addCar(2, "Honda Accord", "Jane Smith");
    
    system.addCleaner(1, "Mike", 25);
    system.addCleaner(2, "Anna", 30);
    
    system.displayCars();
    system.displayCleaners();

    system.updateCar(1, "Toyota Corolla", "John Doe");
    system.updateCleaner(1, "Michael", 26);

    system.displayCars();
    system.displayCleaners();

    Car* car = system.searchCar(2);
    if (car) {
        std::cout << "Found Car - ID: " << car->id << ", Model: " << car->model << ", Owner: " << car->owner << std::endl;
    }

    Cleaner* cleaner = system.searchCleaner(2);
    if (cleaner) {
        std::cout << "Found Cleaner - ID: " << cleaner->id << ", Name: " << cleaner->name << ", Age: " << cleaner->age << std::endl;
    }

    system.deleteCar(2);
    system.deleteCleaner(2);

    system.displayCars();
    system.displayCleaners();

    return 0;
}