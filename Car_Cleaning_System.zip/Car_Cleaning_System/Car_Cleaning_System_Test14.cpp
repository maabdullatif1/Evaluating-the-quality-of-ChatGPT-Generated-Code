#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string make;
    std::string model;

    Car(int id, std::string make, std::string model) : id(id), make(make), model(model) {}
};

class Cleaner {
public:
    int id;
    std::string name;
    int experience;

    Cleaner(int id, std::string name, int experience) : id(id), name(name), experience(experience) {}
};

class CarCleaningSystem {
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;
public:
    void addCar(int id, std::string make, std::string model) {
        cars.push_back(Car(id, make, model));
    }

    void addCleaner(int id, std::string name, int experience) {
        cleaners.push_back(Cleaner(id, name, experience));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, std::string newMake, std::string newModel) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.make = newMake;
                car.model = newModel;
                break;
            }
        }
    }

    void updateCleaner(int id, std::string newName, int newExperience) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = newName;
                cleaner.experience = newExperience;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    Cleaner* searchCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << std::endl;
        }
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            std::cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << ", Experience: " << cleaner.experience << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Camry");
    system.addCar(2, "Honda", "Accord");
    system.addCleaner(1, "John Doe", 5);
    system.addCleaner(2, "Jane Smith", 3);
    
    std::cout << "Cars:" << std::endl;
    system.displayCars();
    system.updateCar(1, "Toyota", "Corolla");
    std::cout << "Updated Car:" << std::endl;
    system.displayCars();

    std::cout << "Cleaners:" << std::endl;
    system.displayCleaners();
    system.updateCleaner(2, "Jane Doe", 4);
    std::cout << "Updated Cleaners:" << std::endl;
    system.displayCleaners();
    
    return 0;
}