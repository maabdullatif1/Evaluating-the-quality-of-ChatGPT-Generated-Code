#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    int id;
    string model;
    string owner;
};

struct Cleaner {
    int id;
    string name;
    string phone;
};

class CarCleaningSystem {
    vector<Car> cars;
    vector<Cleaner> cleaners;

public:
    void addCar(int id, string model, string owner) {
        cars.push_back({id, model, owner});
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string model, string owner) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.model = model;
                car.owner = owner;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << endl;
        }
    }

    void addCleaner(int id, string name, string phone) {
        cleaners.push_back({id, name, phone});
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, string name, string phone) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                cleaner.phone = phone;
                break;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << ", Phone: " << cleaner.phone << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Alice");
    system.addCar(2, "Ford", "Bob");
    system.addCleaner(1, "John", "555-1234");
    system.addCleaner(2, "Jane", "555-5678");
    cout << "Cars: " << endl;
    system.displayCars();
    cout << "Cleaners: " << endl;
    system.displayCleaners();
    system.updateCar(1, "Honda", "Alice");
    system.updateCleaner(1, "Johnny", "555-9999");
    cout << "Updated Cars: " << endl;
    system.displayCars();
    cout << "Updated Cleaners: " << endl;
    system.displayCleaners();
    system.deleteCar(2);
    system.deleteCleaner(2);
    cout << "After Deletion Cars: " << endl;
    system.displayCars();
    cout << "After Deletion Cleaners: " << endl;
    system.displayCleaners();
    return 0;
}