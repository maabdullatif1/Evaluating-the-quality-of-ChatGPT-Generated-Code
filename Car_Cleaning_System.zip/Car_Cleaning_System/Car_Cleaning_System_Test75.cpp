#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string plateNumber;
    std::string model;

    Car(std::string p, std::string m) : plateNumber(p), model(m) {}
};

class Cleaner {
public:
    std::string name;
    int id;

    Cleaner(std::string n, int i) : name(n), id(i) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(const std::string& plate, const std::string& model) {
        cars.push_back(Car(plate, model));
    }

    void deleteCar(const std::string& plate) {
        for(auto it = cars.begin(); it != cars.end(); ++it) {
            if(it->plateNumber == plate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string& plate, const std::string& newModel) {
        for(auto& car : cars) {
            if(car.plateNumber == plate) {
                car.model = newModel;
                break;
            }
        }
    }

    Car* searchCar(const std::string& plate) {
        for(auto& car : cars) {
            if(car.plateNumber == plate) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for(const auto& car : cars) {
            std::cout << "Plate: " << car.plateNumber << ", Model: " << car.model << std::endl;
        }
    }

    void addCleaner(const std::string& name, int id) {
        cleaners.push_back(Cleaner(name, id));
    }

    void deleteCleaner(int id) {
        for(auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if(it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, const std::string& newName) {
        for(auto& cleaner : cleaners) {
            if(cleaner.id == id) {
                cleaner.name = newName;
                break;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for(auto& cleaner : cleaners) {
            if(cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for(const auto& cleaner : cleaners) {
            std::cout << "Name: " << cleaner.name << ", ID: " << cleaner.id << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("ABC123", "Toyota");
    system.addCar("XYZ456", "Honda");
    system.addCleaner("John Doe", 1);
    system.addCleaner("Jane Smith", 2);
    system.displayCars();
    system.displayCleaners();
    Car* car = system.searchCar("ABC123");
    if(car) {
        std::cout << "Found Car: " << car->plateNumber << ", " << car->model << std::endl;
    }
    Cleaner* cleaner = system.searchCleaner(1);
    if(cleaner) {
        std::cout << "Found Cleaner: " << cleaner->name << ", ID: " << cleaner->id << std::endl;
    }
    system.updateCar("XYZ456", "Nissan");
    system.updateCleaner(2, "Janet Smith");
    system.displayCars();
    system.displayCleaners();
    system.deleteCar("ABC123");
    system.deleteCleaner(1);
    system.displayCars();
    system.displayCleaners();
    return 0;
}