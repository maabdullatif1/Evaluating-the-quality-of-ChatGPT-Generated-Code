#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string model;
    string owner;

    Car(int id, string model, string owner) : id(id), model(model), owner(owner) {}
};

class Cleaner {
public:
    int id;
    string name;
    string phone;

    Cleaner(int id, string name, string phone) : id(id), name(name), phone(phone) {}
};

class CarCleaningSystem {
    vector<Car> cars;
    vector<Cleaner> cleaners;

    Car* searchCarById(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    Cleaner* searchCleanerById(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

public:
    void addCar(int id, string model, string owner) {
        cars.push_back(Car(id, model, owner));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                return;
            }
        }
    }

    void updateCar(int id, string model, string owner) {
        Car* car = searchCarById(id);
        if (car) {
            car->model = model;
            car->owner = owner;
        }
    }

    void searchCar(int id) {
        Car* car = searchCarById(id);
        if (car) {
            cout << "Car: " << car->id << " " << car->model << " " << car->owner << endl;
        } else {
            cout << "Car not found." << endl;
        }
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "Car: " << car.id << " " << car.model << " " << car.owner << endl;
        }
    }

    void addCleaner(int id, string name, string phone) {
        cleaners.push_back(Cleaner(id, name, phone));
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                return;
            }
        }
    }

    void updateCleaner(int id, string name, string phone) {
        Cleaner* cleaner = searchCleanerById(id);
        if (cleaner) {
            cleaner->name = name;
            cleaner->phone = phone;
        }
    }

    void searchCleaner(int id) {
        Cleaner* cleaner = searchCleanerById(id);
        if (cleaner) {
            cout << "Cleaner: " << cleaner->id << " " << cleaner->name << " " << cleaner->phone << endl;
        } else {
            cout << "Cleaner not found." << endl;
        }
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            cout << "Cleaner: " << cleaner.id << " " << cleaner.name << " " << cleaner.phone << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Alice");
    system.addCleaner(1, "Bob", "123456789");
    system.displayCars();
    system.displayCleaners();
    system.updateCar(1, "Honda", "Alice");
    system.updateCleaner(1, "Bob", "987654321");
    system.searchCar(1);
    system.searchCleaner(1);
    system.deleteCar(1);
    system.deleteCleaner(1);
    system.displayCars();
    system.displayCleaners();
    return 0;
}