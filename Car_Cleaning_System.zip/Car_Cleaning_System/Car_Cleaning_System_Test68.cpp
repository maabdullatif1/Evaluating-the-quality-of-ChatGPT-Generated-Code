#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string model;
    string licensePlate;

    Car(int id, string model, string licensePlate)
        : id(id), model(model), licensePlate(licensePlate) {}
};

class Cleaner {
public:
    int id;
    string name;
    string phoneNumber;

    Cleaner(int id, string name, string phoneNumber)
        : id(id), name(name), phoneNumber(phoneNumber) {}
};

class CarCleaningSystem {
private:
    vector<Car> cars;
    vector<Cleaner> cleaners;

public:
    void addCar(int id, string model, string licensePlate) {
        cars.push_back(Car(id, model, licensePlate));
    }

    void addCleaner(int id, string name, string phoneNumber) {
        cleaners.push_back(Cleaner(id, name, phoneNumber));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string model, string licensePlate) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.model = model;
                car.licensePlate = licensePlate;
                break;
            }
        }
    }

    void updateCleaner(int id, string name, string phoneNumber) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                cleaner.phoneNumber = phoneNumber;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    Cleaner* searchCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            cout << "Car ID: " << car.id << ", Model: " << car.model << ", License Plate: " << car.licensePlate << endl;
        }
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << ", Phone Number: " << cleaner.phoneNumber << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "XYZ123");
    system.addCleaner(1, "John Doe", "555-0123");
    system.displayCars();
    system.displayCleaners();
    Car* car = system.searchCar(1);
    if (car) {
        cout << "Found Car: " << car->model << endl;
    }
    Cleaner* cleaner = system.searchCleaner(1);
    if (cleaner) {
        cout << "Found Cleaner: " << cleaner->name << endl;
    }
    system.updateCar(1, "Honda", "ABC789");
    system.updateCleaner(1, "Jane Doe", "555-9876");
    system.displayCars();
    system.displayCleaners();
    system.deleteCar(1);
    system.deleteCleaner(1);
    system.displayCars();
    system.displayCleaners();
    return 0;
}