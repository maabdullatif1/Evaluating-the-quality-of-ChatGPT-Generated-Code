#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string model;
    std::string color;

    Car(std::string lp, std::string m, std::string c) : licensePlate(lp), model(m), color(c) {}
};

class Cleaner {
public:
    std::string name;
    std::string id;

    Cleaner(std::string n, std::string i) : name(n), id(i) {}
};

class CarCleaningSystem {
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(std::string lp, std::string m, std::string c) {
        cars.push_back(Car(lp, m, c));
    }

    void deleteCar(std::string lp) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == lp) {
                cars.erase(it);
                return;
            }
        }
    }

    void updateCar(std::string lp, std::string newModel, std::string newColor) {
        for (auto& car : cars) {
            if (car.licensePlate == lp) {
                car.model = newModel;
                car.color = newColor;
                return;
            }
        }
    }

    Car* searchCar(std::string lp) {
        for (auto& car : cars) {
            if (car.licensePlate == lp) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "License Plate: " << car.licensePlate << ", Model: " << car.model << ", Color: " << car.color << std::endl;
        }
    }

    void addCleaner(std::string n, std::string i) {
        cleaners.push_back(Cleaner(n, i));
    }

    void deleteCleaner(std::string i) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == i) {
                cleaners.erase(it);
                return;
            }
        }
    }

    void updateCleaner(std::string i, std::string newName) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == i) {
                cleaner.name = newName;
                return;
            }
        }
    }

    Cleaner* searchCleaner(std::string i) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == i) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "Name: " << cleaner.name << ", ID: " << cleaner.id << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("123ABC", "Toyota", "Red");
    system.addCleaner("John Doe", "C001");
    system.displayCars();
    system.displayCleaners();
    return 0;
}