#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string make;
    string model;
    string licensePlate;

    Car(int i, string ma, string mo, string lp) {
        id = i;
        make = ma;
        model = mo;
        licensePlate = lp;
    }
};

class Cleaner {
public:
    int id;
    string name;

    Cleaner(int i, string n) {
        id = i;
        name = n;
    }
};

class CarCleaningSystem {
    vector<Car> cars;
    vector<Cleaner> cleaners;
    int carIdCounter = 1;
    int cleanerIdCounter = 1;

public:
    void addCar(string make, string model, string licensePlate) {
        cars.push_back(Car(carIdCounter++, make, model, licensePlate));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string make, string model, string licensePlate) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.licensePlate = licensePlate;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    vector<Car> getAllCars() {
        return cars;
    }

    void addCleaner(string name) {
        cleaners.push_back(Cleaner(cleanerIdCounter++, name));
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, string name) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                break;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    vector<Cleaner> getAllCleaners() {
        return cleaners;
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("Toyota", "Corolla", "ABC123");
    system.addCar("Honda", "Civic", "XYZ789");

    system.addCleaner("John Doe");
    system.addCleaner("Jane Smith");

    for (auto car : system.getAllCars()) {
        cout << "Car ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << ", License: " << car.licensePlate << endl;
    }

    for (auto cleaner : system.getAllCleaners()) {
        cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << endl;
    }

    return 0;
}