#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    int id;
    string brand;
    string model;
    string licensePlate;
};

struct Cleaner {
    int id;
    string name;
    int experience;
};

class CarCleaningSystem {
private:
    vector<Car> cars;
    vector<Cleaner> cleaners;
    int carIdCounter;
    int cleanerIdCounter;

    Car* findCarById(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    Cleaner* findCleanerById(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

public:
    CarCleaningSystem() : carIdCounter(0), cleanerIdCounter(0) {}

    void addCar(const string& brand, const string& model, const string& licensePlate) {
        cars.push_back({carIdCounter++, brand, model, licensePlate});
    }

    void addCleaner(const string& name, int experience) {
        cleaners.push_back({cleanerIdCounter++, name, experience});
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                return;
            }
        }
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                return;
            }
        }
    }

    void updateCar(int id, const string& brand, const string& model, const string& licensePlate) {
        Car* car = findCarById(id);
        if (car) {
            car->brand = brand;
            car->model = model;
            car->licensePlate = licensePlate;
        }
    }

    void updateCleaner(int id, const string& name, int experience) {
        Cleaner* cleaner = findCleanerById(id);
        if (cleaner) {
            cleaner->name = name;
            cleaner->experience = experience;
        }
    }

    void searchCarById(int id) {
        Car* car = findCarById(id);
        if (car) {
            cout << "Car ID: " << car->id << " Brand: " << car->brand << " Model: " << car->model << " License Plate: " << car->licensePlate << endl;
        } else {
            cout << "Car not found." << endl;
        }
    }

    void searchCleanerById(int id) {
        Cleaner* cleaner = findCleanerById(id);
        if (cleaner) {
            cout << "Cleaner ID: " << cleaner->id << " Name: " << cleaner->name << " Experience: " << cleaner->experience << " years" << endl;
        } else {
            cout << "Cleaner not found." << endl;
        }
    }

    void displayCars() {
        for (const auto& car : cars) {
            cout << "Car ID: " << car.id << " Brand: " << car.brand << " Model: " << car.model << " License Plate: " << car.licensePlate << endl;
        }
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            cout << "Cleaner ID: " << cleaner.id << " Name: " << cleaner.name << " Experience: " << cleaner.experience << " years" << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("Toyota", "Corolla", "ABC123");
    system.addCleaner("John Doe", 5);
    system.displayCars();
    system.displayCleaners();
    system.updateCar(0, "Honda", "Civic", "XYZ789");
    system.searchCarById(0);
    system.deleteCleaner(0);
    system.displayCleaners();
    return 0;
}