#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Car {
public:
    int id;
    string model;
    string owner;
    Car(int id, string model, string owner) : id(id), model(model), owner(owner) {}
};

class Cleaner {
public:
    int id;
    string name;
    Cleaner(int id, string name) : id(id), name(name) {}
};

class CarCleaningSystem {
private:
    vector<Car> cars;
    vector<Cleaner> cleaners;

public:
    void addCar(int id, string model, string owner) {
        cars.push_back(Car(id, model, owner));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string model, string owner) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.model = model;
                car.owner = owner;
                break;
            }
        }
    }

    void searchCar(int id) {
        for (const auto &car : cars) {
            if (car.id == id) {
                cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << endl;
                return;
            }
        }
        cout << "Car not found" << endl;
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << endl;
        }
    }

    void addCleaner(int id, string name) {
        cleaners.push_back(Cleaner(id, name));
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, string name) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                break;
            }
        }
    }

    void searchCleaner(int id) {
        for (const auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << endl;
                return;
            }
        }
        cout << "Cleaner not found" << endl;
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    
    system.addCar(1, "Toyota", "John");
    system.addCar(2, "Honda", "Alice");
    
    system.addCleaner(1, "Michael");
    system.addCleaner(2, "Sarah");
    
    system.displayCars();
    system.displayCleaners();
    
    system.searchCar(1);
    system.searchCleaner(2);
    
    system.updateCar(2, "Honda Accord", "Alice");
    system.updateCleaner(1, "Mike");
    
    system.displayCars();
    system.displayCleaners();
    
    system.deleteCar(1);
    system.deleteCleaner(2);
    
    system.displayCars();
    system.displayCleaners();
    
    return 0;
}