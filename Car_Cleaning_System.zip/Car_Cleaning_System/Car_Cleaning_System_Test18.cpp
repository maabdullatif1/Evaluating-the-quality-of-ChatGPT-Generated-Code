#include <iostream>
#include <vector>
#include <string>

struct Car {
    int id;
    std::string make;
    std::string model;
    int year;
};

struct Cleaner {
    int id;
    std::string name;
    int experience;
};

std::vector<Car> cars;
std::vector<Cleaner> cleaners;

int findCarIndex(int id) {
    for (size_t i = 0; i < cars.size(); i++) {
        if (cars[i].id == id) {
            return i;
        }
    }
    return -1;
}

int findCleanerIndex(int id) {
    for (size_t i = 0; i < cleaners.size(); i++) {
        if (cleaners[i].id == id) {
            return i;
        }
    }
    return -1;
}

void addCar() {
    Car car;
    std::cout << "Enter Car ID: ";
    std::cin >> car.id;
    std::cout << "Enter Car Make: ";
    std::cin >> car.make;
    std::cout << "Enter Car Model: ";
    std::cin >> car.model;
    std::cout << "Enter Car Year: ";
    std::cin >> car.year;
    cars.push_back(car);
}

void deleteCar() {
    int id;
    std::cout << "Enter Car ID to delete: ";
    std::cin >> id;
    int index = findCarIndex(id);
    if (index != -1) {
        cars.erase(cars.begin() + index);
        std::cout << "Car deleted.\n";
    } else {
        std::cout << "Car not found.\n";
    }
}

void updateCar() {
    int id;
    std::cout << "Enter Car ID to update: ";
    std::cin >> id;
    int index = findCarIndex(id);
    if (index != -1) {
        std::cout << "Enter new Make: ";
        std::cin >> cars[index].make;
        std::cout << "Enter new Model: ";
        std::cin >> cars[index].model;
        std::cout << "Enter new Year: ";
        std::cin >> cars[index].year;
        std::cout << "Car updated.\n";
    } else {
        std::cout << "Car not found.\n";
    }
}

void searchCar() {
    int id;
    std::cout << "Enter Car ID to search: ";
    std::cin >> id;
    int index = findCarIndex(id);
    if (index != -1) {
        std::cout << "Car ID: " << cars[index].id << ", Make: " << cars[index].make
                  << ", Model: " << cars[index].model << ", Year: " << cars[index].year << '\n';
    } else {
        std::cout << "Car not found.\n";
    }
}

void displayCars() {
    for (const auto& car : cars) {
        std::cout << "Car ID: " << car.id << ", Make: " << car.make
                  << ", Model: " << car.model << ", Year: " << car.year << '\n';
    }
}

void addCleaner() {
    Cleaner cleaner;
    std::cout << "Enter Cleaner ID: ";
    std::cin >> cleaner.id;
    std::cout << "Enter Cleaner Name: ";
    std::cin >> cleaner.name;
    std::cout << "Enter Cleaner Experience: ";
    std::cin >> cleaner.experience;
    cleaners.push_back(cleaner);
}

void deleteCleaner() {
    int id;
    std::cout << "Enter Cleaner ID to delete: ";
    std::cin >> id;
    int index = findCleanerIndex(id);
    if (index != -1) {
        cleaners.erase(cleaners.begin() + index);
        std::cout << "Cleaner deleted.\n";
    } else {
        std::cout << "Cleaner not found.\n";
    }
}

void updateCleaner() {
    int id;
    std::cout << "Enter Cleaner ID to update: ";
    std::cin >> id;
    int index = findCleanerIndex(id);
    if (index != -1) {
        std::cout << "Enter new Name: ";
        std::cin >> cleaners[index].name;
        std::cout << "Enter new Experience: ";
        std::cin >> cleaners[index].experience;
        std::cout << "Cleaner updated.\n";
    } else {
        std::cout << "Cleaner not found.\n";
    }
}

void searchCleaner() {
    int id;
    std::cout << "Enter Cleaner ID to search: ";
    std::cin >> id;
    int index = findCleanerIndex(id);
    if (index != -1) {
        std::cout << "Cleaner ID: " << cleaners[index].id << ", Name: " << cleaners[index].name
                  << ", Experience: " << cleaners[index].experience << '\n';
    } else {
        std::cout << "Cleaner not found.\n";
    }
}

void displayCleaners() {
    for (const auto& cleaner : cleaners) {
        std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name
                  << ", Experience: " << cleaner.experience << " years\n";
    }
}

int main() {
    int choice;
    do {
        std::cout << "1. Add Car\n2. Delete Car\n3. Update Car\n4. Search Car\n5. Display Cars\n";
        std::cout << "6. Add Cleaner\n7. Delete Cleaner\n8. Update Cleaner\n9. Search Cleaner\n10. Display Cleaners\n0. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;
        switch (choice) {
            case 1: addCar(); break;
            case 2: deleteCar(); break;
            case 3: updateCar(); break;
            case 4: searchCar(); break;
            case 5: displayCars(); break;
            case 6: addCleaner(); break;
            case 7: deleteCleaner(); break;
            case 8: updateCleaner(); break;
            case 9: searchCleaner(); break;
            case 10: displayCleaners(); break;
            case 0: break;
            default: std::cout << "Invalid choice.\n"; break;
        }
    } while (choice != 0);
    return 0;
}