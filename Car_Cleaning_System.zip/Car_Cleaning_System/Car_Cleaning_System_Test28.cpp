#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    string licensePlate;
    string model;
    string owner;
};

struct Cleaner {
    string name;
    int id;
};

class CarCleaningSystem {
private:
    vector<Car> cars;
    vector<Cleaner> cleaners;

public:
    void addCar(const string& licensePlate, const string& model, const string& owner) {
        cars.push_back({licensePlate, model, owner});
    }

    void deleteCar(const string& licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                return;
            }
        }
    }

    void updateCar(const string& licensePlate, const string& newModel, const string& newOwner) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                car.model = newModel;
                car.owner = newOwner;
                return;
            }
        }
    }

    Car* searchCar(const string& licensePlate) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            cout << "License Plate: " << car.licensePlate
                 << ", Model: " << car.model
                 << ", Owner: " << car.owner << endl;
        }
    }

    void addCleaner(const string& name, int id) {
        cleaners.push_back({name, id});
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                return;
            }
        }
    }

    void updateCleaner(int id, const string& newName) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = newName;
                return;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            cout << "ID: " << cleaner.id
                 << ", Name: " << cleaner.name << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("ABC123", "Toyota", "Alice");
    system.addCar("XYZ789", "Honda", "Bob");
    system.displayCars();

    system.addCleaner("John", 1);
    system.addCleaner("Jane", 2);
    system.displayCleaners();

    system.updateCar("ABC123", "Lexus", "Alice Cooper");
    system.updateCleaner(1, "John Doe");

    system.displayCars();
    system.displayCleaners();

    system.deleteCar("XYZ789");
    system.deleteCleaner(2);

    system.displayCars();
    system.displayCleaners();

    Car* car = system.searchCar("ABC123");
    if (car) {
        cout << "Found car: " << car->licensePlate << endl;
    }

    Cleaner* cleaner = system.searchCleaner(1);
    if (cleaner) {
        cout << "Found cleaner: " << cleaner->name << endl;
    }

    return 0;
}