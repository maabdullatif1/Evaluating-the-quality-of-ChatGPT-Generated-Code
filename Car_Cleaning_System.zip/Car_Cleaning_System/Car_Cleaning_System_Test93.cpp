#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string model;
    std::string owner;

    Car(int id, std::string model, std::string owner) 
        : id(id), model(model), owner(owner) {}
};

class Cleaner {
public:
    int id;
    std::string name;

    Cleaner(int id, std::string name)
        : id(id), name(name) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(int id, std::string model, std::string owner) {
        cars.push_back(Car(id, model, owner));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, std::string model, std::string owner) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.model = model;
                car.owner = owner;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << std::endl;
        }
    }

    void addCleaner(int id, std::string name) {
        cleaners.push_back(Cleaner(id, name));
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, std::string name) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                break;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota Camry", "Alice");
    system.addCar(2, "Honda Accord", "Bob");
    system.displayCars();
    
    system.addCleaner(1, "Charlie");
    system.addCleaner(2, "Dave");
    system.displayCleaners();
    
    system.updateCar(1, "Toyota Corolla", "Alice");
    system.displayCars();
    
    system.deleteCleaner(2);
    system.displayCleaners();
    
    return 0;
}