#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string model;
    std::string license_plate;

    Car(int id, const std::string& model, const std::string& license_plate)
        : id(id), model(model), license_plate(license_plate) {}
};

class Cleaner {
public:
    int id;
    std::string name;
    int experience;

    Cleaner(int id, const std::string& name, int experience)
        : id(id), name(name), experience(experience) {}
};

class CleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

    template<typename T>
    void displayItems(const std::vector<T>& items) {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << "; ";
            if constexpr (std::is_same<T, Car>::value) {
                std::cout << "Model: " << item.model << "; License: " << item.license_plate << std::endl;
            } else if constexpr (std::is_same<T, Cleaner>::value) {
                std::cout << "Name: " << item.name << "; Experience: " << item.experience << " years" << std::endl;
            }
        }
    }

public:
    void addCar(int id, const std::string& model, const std::string& license_plate) {
        cars.emplace_back(id, model, license_plate);
    }

    void deleteCar(int id) {
        cars.erase(std::remove_if(cars.begin(), cars.end(), [id](const Car& car) {
            return car.id == id;
        }), cars.end());
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id)
                return &car;
        }
        return nullptr;
    }

    void updateCar(int id, const std::string& new_model, const std::string& new_license_plate) {
        Car* car = searchCar(id);
        if (car) {
            car->model = new_model;
            car->license_plate = new_license_plate;
        }
    }

    void displayCars() {
        displayItems(cars);
    }

    void addCleaner(int id, const std::string& name, int experience) {
        cleaners.emplace_back(id, name, experience);
    }

    void deleteCleaner(int id) {
        cleaners.erase(std::remove_if(cleaners.begin(), cleaners.end(), [id](const Cleaner& cleaner) {
            return cleaner.id == id;
        }), cleaners.end());
    }

    Cleaner* searchCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id)
                return &cleaner;
        }
        return nullptr;
    }

    void updateCleaner(int id, const std::string& new_name, int new_experience) {
        Cleaner* cleaner = searchCleaner(id);
        if (cleaner) {
            cleaner->name = new_name;
            cleaner->experience = new_experience;
        }
    }

    void displayCleaners() {
        displayItems(cleaners);
    }
};

int main() {
    CleaningSystem system;
    system.addCar(1, "Toyota Corolla", "XYZ 1234");
    system.addCar(2, "Ford Focus", "ABC 5678");
    system.addCleaner(1, "John Doe", 5);
    system.addCleaner(2, "Jane Smith", 3);

    std::cout << "Cars:\n";
    system.displayCars();

    std::cout << "\nCleaners:\n";
    system.displayCleaners();

    system.updateCar(1, "Toyota Camry", "XYZ 9876");
    system.updateCleaner(1, "Johnathan Doe", 6);

    std::cout << "\nUpdated Cars and Cleaners:\n";
    system.displayCars();
    system.displayCleaners();

    system.deleteCar(2);
    system.deleteCleaner(2);

    std::cout << "\nAfter Deletions:\n";
    system.displayCars();
    system.displayCleaners();

    return 0;
}