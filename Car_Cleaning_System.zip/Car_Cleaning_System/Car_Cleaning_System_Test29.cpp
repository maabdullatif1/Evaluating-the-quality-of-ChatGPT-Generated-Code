#include <iostream>
#include <vector>
#include <string>

struct Car {
    int id;
    std::string model;
    std::string licensePlate;
};

struct Cleaner {
    int id;
    std::string name;
};

class CarCleaningSystem {
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

    int findCarIndex(int id) {
        for (size_t i = 0; i < cars.size(); i++) {
            if (cars[i].id == id)
                return i;
        }
        return -1;
    }

    int findCleanerIndex(int id) {
        for (size_t i = 0; i < cleaners.size(); i++) {
            if (cleaners[i].id == id)
                return i;
        }
        return -1;
    }

public:
    void addCar(int id, const std::string &model, const std::string &licensePlate) {
        if (findCarIndex(id) == -1) {
            cars.push_back({id, model, licensePlate});
        }
    }

    void deleteCar(int id) {
        int index = findCarIndex(id);
        if (index != -1) {
            cars.erase(cars.begin() + index);
        }
    }

    void updateCar(int id, const std::string &model, const std::string &licensePlate) {
        int index = findCarIndex(id);
        if (index != -1) {
            cars[index].model = model;
            cars[index].licensePlate = licensePlate;
        }
    }

    Car* searchCar(int id) {
        int index = findCarIndex(id);
        if (index != -1) {
            return &cars[index];
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "ID: " << car.id << ", Model: " << car.model << ", License Plate: " << car.licensePlate << "\n";
        }
    }

    void addCleaner(int id, const std::string &name) {
        if (findCleanerIndex(id) == -1) {
            cleaners.push_back({id, name});
        }
    }

    void deleteCleaner(int id) {
        int index = findCleanerIndex(id);
        if (index != -1) {
            cleaners.erase(cleaners.begin() + index);
        }
    }

    void updateCleaner(int id, const std::string &name) {
        int index = findCleanerIndex(id);
        if (index != -1) {
            cleaners[index].name = name;
        }
    }

    Cleaner* searchCleaner(int id) {
        int index = findCleanerIndex(id);
        if (index != -1) {
            return &cleaners[index];
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            std::cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << "\n";
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota Camry", "ABC123");
    system.addCleaner(1, "John Doe");
    system.displayCars();
    system.displayCleaners();

    return 0;
}