#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string ownerName;
    std::string model;

    Car(int id, std::string owner, std::string model) : id(id), ownerName(owner), model(model) {}
};

class Cleaner {
public:
    int id;
    std::string name;
    int experience;

    Cleaner(int id, std::string name, int experience) : id(id), name(name), experience(experience) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(int id, std::string owner, std::string model) {
        cars.push_back(Car(id, owner, model));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, std::string newOwner, std::string newModel) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.ownerName = newOwner;
                car.model = newModel;
                break;
            }
        }
    }

    void searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                std::cout << "Car found: " << car.ownerName << ", " << car.model << std::endl;
                return;
            }
        }
        std::cout << "Car not found" << std::endl;
    }

    void displayCars() {
        for (auto &car : cars) {
            std::cout << car.id << ": " << car.ownerName << ", " << car.model << std::endl;
        }
    }

    void addCleaner(int id, std::string name, int experience) {
        cleaners.push_back(Cleaner(id, name, experience));
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, std::string newName, int newExperience) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = newName;
                cleaner.experience = newExperience;
                break;
            }
        }
    }

    void searchCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                std::cout << "Cleaner found: " << cleaner.name << ", " << cleaner.experience << " years experience" << std::endl;
                return;
            }
        }
        std::cout << "Cleaner not found" << std::endl;
    }

    void displayCleaners() {
        for (auto &cleaner : cleaners) {
            std::cout << cleaner.id << ": " << cleaner.name << ", " << cleaner.experience << " years experience" << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "John Doe", "Toyota Camry");
    system.addCar(2, "Jane Smith", "Honda Civic");
    system.displayCars();
    
    system.addCleaner(1, "Alice", 5);
    system.addCleaner(2, "Bob", 3);
    system.displayCleaners();
    
    system.searchCar(1);
    system.searchCleaner(2);
    
    system.updateCar(1, "John Doe", "Toyota Corolla");
    system.updateCleaner(1, "Alice Johnson", 6);
    
    system.displayCars();
    system.displayCleaners();
    
    system.deleteCar(2);
    system.deleteCleaner(2);

    system.displayCars();
    system.displayCleaners();

    return 0;
}