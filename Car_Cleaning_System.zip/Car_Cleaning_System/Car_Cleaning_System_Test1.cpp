#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Car {
    int id;
    string model;
    string ownerName;
};

struct Cleaner {
    int id;
    string name;
    int age;
};

vector<Car> cars;
vector<Cleaner> cleaners;

int findCarIndex(int carId) {
    for (size_t i = 0; i < cars.size(); ++i) {
        if (cars[i].id == carId) return i;
    }
    return -1;
}

int findCleanerIndex(int cleanerId) {
    for (size_t i = 0; i < cleaners.size(); ++i) {
        if (cleaners[i].id == cleanerId) return i;
    }
    return -1;
}

void addCar() {
    Car car;
    cout << "Enter Car ID: "; cin >> car.id;
    cout << "Enter Model: "; cin >> car.model;
    cout << "Enter Owner Name: "; cin >> car.ownerName;
    cars.push_back(car);
}

void deleteCar() {
    int carId;
    cout << "Enter Car ID to delete: "; cin >> carId;
    int index = findCarIndex(carId);
    if (index != -1)
        cars.erase(cars.begin() + index);
    else
        cout << "Car not found\n";
}

void updateCar() {
    int carId;
    cout << "Enter Car ID to update: "; cin >> carId;
    int index = findCarIndex(carId);
    if (index != -1) {
        cout << "Enter New Model: "; cin >> cars[index].model;
        cout << "Enter New Owner Name: "; cin >> cars[index].ownerName;
    } else
        cout << "Car not found\n";
}

void searchCar() {
    int carId;
    cout << "Enter Car ID to search: "; cin >> carId;
    int index = findCarIndex(carId);
    if (index != -1)
        cout << "Car found - ID: " << cars[index].id << ", Model: " << cars[index].model << ", Owner: " << cars[index].ownerName << endl;
    else
        cout << "Car not found\n";
}

void displayCars() {
    for (const auto& car : cars)
        cout << "ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.ownerName << endl;
}

void addCleaner() {
    Cleaner cleaner;
    cout << "Enter Cleaner ID: "; cin >> cleaner.id;
    cout << "Enter Name: "; cin >> cleaner.name;
    cout << "Enter Age: "; cin >> cleaner.age;
    cleaners.push_back(cleaner);
}

void deleteCleaner() {
    int cleanerId;
    cout << "Enter Cleaner ID to delete: "; cin >> cleanerId;
    int index = findCleanerIndex(cleanerId);
    if (index != -1)
        cleaners.erase(cleaners.begin() + index);
    else
        cout << "Cleaner not found\n";
}

void updateCleaner() {
    int cleanerId;
    cout << "Enter Cleaner ID to update: "; cin >> cleanerId;
    int index = findCleanerIndex(cleanerId);
    if (index != -1) {
        cout << "Enter New Name: "; cin >> cleaners[index].name;
        cout << "Enter New Age: "; cin >> cleaners[index].age;
    } else
        cout << "Cleaner not found\n";
}

void searchCleaner() {
    int cleanerId;
    cout << "Enter Cleaner ID to search: "; cin >> cleanerId;
    int index = findCleanerIndex(cleanerId);
    if (index != -1)
        cout << "Cleaner found - ID: " << cleaners[index].id << ", Name: " << cleaners[index].name << ", Age: " << cleaners[index].age << endl;
    else
        cout << "Cleaner not found\n";
}

void displayCleaners() {
    for (const auto& cleaner : cleaners)
        cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << ", Age: " << cleaner.age << endl;
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Car\n2. Delete Car\n3. Update Car\n4. Search Car\n5. Display Cars\n";
        cout << "6. Add Cleaner\n7. Delete Cleaner\n8. Update Cleaner\n9. Search Cleaner\n10. Display Cleaners\n0. Exit\n";
        cout << "Enter choice: "; cin >> choice;
        switch (choice) {
            case 1: addCar(); break;
            case 2: deleteCar(); break;
            case 3: updateCar(); break;
            case 4: searchCar(); break;
            case 5: displayCars(); break;
            case 6: addCleaner(); break;
            case 7: deleteCleaner(); break;
            case 8: updateCleaner(); break;
            case 9: searchCleaner(); break;
            case 10: displayCleaners(); break;
            case 0: return 0;
            default: cout << "Invalid choice\n";
        }
    }
}