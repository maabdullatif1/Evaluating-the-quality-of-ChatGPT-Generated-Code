#include <iostream>
#include <string>
#include <vector>

struct Car {
    int id;
    std::string model;
    std::string owner;
    bool operator==(const Car& other) const {
        return id == other.id;
    }
};

struct Cleaner {
    int id;
    std::string name;
    std::string contact;
    bool operator==(const Cleaner& other) const {
        return id == other.id;
    }
};

std::vector<Car> cars;
std::vector<Cleaner> cleaners;

void addCar(int id, const std::string& model, const std::string& owner) {
    cars.push_back({id, model, owner});
}

void deleteCar(int id) {
    cars.erase(std::remove_if(cars.begin(), cars.end(), [id](Car& c){ return c.id == id; }), cars.end());
}

void updateCar(int id, const std::string& model, const std::string& owner) {
    for (auto& c : cars) {
        if (c.id == id) {
            c.model = model;
            c.owner = owner;
        }
    }
}

Car* searchCar(int id) {
    for (auto& c : cars) {
        if (c.id == id) return &c;
    }
    return nullptr;
}

void displayCars() {
    for (const auto& c : cars) {
        std::cout << "Car ID: " << c.id << ", Model: " << c.model << ", Owner: " << c.owner << std::endl;
    }
}

void addCleaner(int id, const std::string& name, const std::string& contact) {
    cleaners.push_back({id, name, contact});
}

void deleteCleaner(int id) {
    cleaners.erase(std::remove_if(cleaners.begin(), cleaners.end(), [id](Cleaner& cl){ return cl.id == id; }), cleaners.end());
}

void updateCleaner(int id, const std::string& name, const std::string& contact) {
    for (auto& cl : cleaners) {
        if (cl.id == id) {
            cl.name = name;
            cl.contact = contact;
        }
    }
}

Cleaner* searchCleaner(int id) {
    for (auto& cl : cleaners) {
        if (cl.id == id) return &cl;
    }
    return nullptr;
}

void displayCleaners() {
    for (const auto& cl : cleaners) {
        std::cout << "Cleaner ID: " << cl.id << ", Name: " << cl.name << ", Contact: " << cl.contact << std::endl;
    }
}

int main() {
    addCar(1, "Toyota", "Alice");
    addCar(2, "Honda", "Bob");
    updateCar(1, "Toyota", "Charlie");
    displayCars();
    deleteCar(2);
    displayCars();
    
    addCleaner(1, "David", "12345");
    addCleaner(2, "Eva", "67890");
    updateCleaner(1, "Dan", "54321");
    displayCleaners();
    deleteCleaner(2);
    displayCleaners();
    
    return 0;
}