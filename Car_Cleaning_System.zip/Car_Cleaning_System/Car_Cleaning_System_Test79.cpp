#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string model;
    std::string owner;

    Car(std::string lp, std::string m, std::string o) : licensePlate(lp), model(m), owner(o) {}
};

class Cleaner {
public:
    std::string name;
    int experience;

    Cleaner(std::string n, int e) : name(n), experience(e) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(std::string licensePlate, std::string model, std::string owner) {
        cars.emplace_back(licensePlate, model, owner);
    }

    void deleteCar(std::string licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(std::string licensePlate, std::string newModel, std::string newOwner) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                car.model = newModel;
                car.owner = newOwner;
                break;
            }
        }
    }

    Car* searchCar(std::string licensePlate) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "License Plate: " << car.licensePlate
                      << ", Model: " << car.model
                      << ", Owner: " << car.owner << std::endl;
        }
    }

    void addCleaner(std::string name, int experience) {
        cleaners.emplace_back(name, experience);
    }

    void deleteCleaner(std::string name) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->name == name) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(std::string name, int newExperience) {
        for (auto& cleaner : cleaners) {
            if (cleaner.name == name) {
                cleaner.experience = newExperience;
                break;
            }
        }
    }

    Cleaner* searchCleaner(std::string name) {
        for (auto& cleaner : cleaners) {
            if (cleaner.name == name) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "Name: " << cleaner.name
                      << ", Experience: " << cleaner.experience << " years" << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;

    system.addCar("123ABC", "Toyota Camry", "Alice");
    system.addCar("456DEF", "Honda Accord", "Bob");
    system.addCleaner("Charlie", 5);
    system.addCleaner("David", 7);

    system.displayCars();
    system.displayCleaners();

    system.updateCar("123ABC", "Toyota Corolla", "Alice Smith");
    system.updateCleaner("Charlie", 6);

    Car* car = system.searchCar("123ABC");
    if (car) {
        std::cout << "Found Car: " << car->licensePlate << std::endl;
    }

    Cleaner* cleaner = system.searchCleaner("David");
    if (cleaner) {
        std::cout << "Found Cleaner: " << cleaner->name << std::endl;
    }

    system.deleteCar("456DEF");
    system.deleteCleaner("Charlie");

    system.displayCars();
    system.displayCleaners();

    return 0;
}