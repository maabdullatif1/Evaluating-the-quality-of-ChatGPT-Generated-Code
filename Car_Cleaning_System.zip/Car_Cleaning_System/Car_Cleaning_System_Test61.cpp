#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    int id;
    string brand;
    string model;
};

struct Cleaner {
    int id;
    string name;
    int experience; // in years
};

class CarCleaningSystem {
private:
    vector<Car> cars;
    vector<Cleaner> cleaners;
    int carIdCounter = 1;
    int cleanerIdCounter = 1;

public:
    void addCar(string brand, string model) {
        Car newCar = {carIdCounter++, brand, model};
        cars.push_back(newCar);
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string brand, string model) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.brand = brand;
                car.model = model;
                break;
            }
        }
    }

    void addCleaner(string name, int experience) {
        Cleaner newCleaner = {cleanerIdCounter++, name, experience};
        cleaners.push_back(newCleaner);
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, string name, int experience) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                cleaner.experience = experience;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    Cleaner* searchCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            cout << "ID: " << car.id << ", Brand: " << car.brand << ", Model: " << car.model << endl;
        }
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << ", Experience: " << cleaner.experience << " years" << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;

    system.addCar("Toyota", "Camry");
    system.addCar("Honda", "Civic");
    
    system.addCleaner("John Doe", 5);
    system.addCleaner("Jane Smith", 3);

    system.displayCars();
    system.displayCleaners();
    
    system.updateCar(1, "Toyota", "Corolla");
    system.updateCleaner(2, "Jane Doe", 4);

    Car* foundCar = system.searchCar(1);
    if (foundCar != nullptr) {
        cout << "Found Car - ID: " << foundCar->id << ", Brand: " << foundCar->brand << ", Model: " << foundCar->model << endl;
    }
    
    Cleaner* foundCleaner = system.searchCleaner(2);
    if (foundCleaner != nullptr) {
        cout << "Found Cleaner - ID: " << foundCleaner->id << ", Name: " << foundCleaner->name << ", Experience: " << foundCleaner->experience << " years" << endl;
    }

    system.deleteCar(2);
    system.deleteCleaner(1);
    
    system.displayCars();
    system.displayCleaners();

    return 0;
}