#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string model;
    std::string owner;
    
    Car(int id, std::string model, std::string owner)
        : id(id), model(model), owner(owner) {}
};

class Cleaner {
public:
    int id;
    std::string name;
    std::string contact;
    
    Cleaner(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

    template<typename T>
    int findIndexById(const std::vector<T>& list, int id) {
        for(size_t i = 0; i < list.size(); i++)
            if(list[i].id == id)
                return i;
        return -1;
    }

public:
    void addCar(int id, std::string model, std::string owner) {
        cars.push_back(Car(id, model, owner));
    }
    
    void addCleaner(int id, std::string name, std::string contact) {
        cleaners.push_back(Cleaner(id, name, contact));
    }

    void deleteCar(int id) {
        int index = findIndexById(cars, id);
        if (index != -1) {
            cars.erase(cars.begin() + index);
        }
    }

    void deleteCleaner(int id) {
        int index = findIndexById(cleaners, id);
        if (index != -1) {
            cleaners.erase(cleaners.begin() + index);
        }
    }

    void updateCar(int id, std::string newModel, std::string newOwner) {
        int index = findIndexById(cars, id);
        if (index != -1) {
            cars[index].model = newModel;
            cars[index].owner = newOwner;
        }
    }

    void updateCleaner(int id, std::string newName, std::string newContact) {
        int index = findIndexById(cleaners, id);
        if (index != -1) {
            cleaners[index].name = newName;
            cleaners[index].contact = newContact;
        }
    }

    Car* searchCar(int id) {
        int index = findIndexById(cars, id);
        if (index != -1) {
            return &cars[index];
        }
        return nullptr;
    }

    Cleaner* searchCleaner(int id) {
        int index = findIndexById(cleaners, id);
        if (index != -1) {
            return &cleaners[index];
        }
        return nullptr;
    }

    void displayCars() {
        for(const auto& car : cars) {
            std::cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << std::endl;
        }
    }

    void displayCleaners() {
        for(const auto& cleaner : cleaners) {
            std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << ", Contact: " << cleaner.contact << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Alice");
    system.addCleaner(1, "John", "123456789");
    system.displayCars();
    system.displayCleaners();
    system.updateCar(1, "Honda", "Alice");
    system.deleteCleaner(1);
    system.displayCars();
    system.displayCleaners();
    return 0;
}