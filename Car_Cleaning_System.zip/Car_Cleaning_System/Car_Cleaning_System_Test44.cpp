#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string model;
    string owner;
};

class Cleaner {
public:
    int id;
    string name;
    string shift;
};

class CarCleaningSystem {
    vector<Car> cars;
    vector<Cleaner> cleaners;
    int carIdCounter = 0;
    int cleanerIdCounter = 0;

    int findCarIndex(int id) {
        for (int i = 0; i < cars.size(); ++i) {
            if (cars[i].id == id) return i;
        }
        return -1;
    }

    int findCleanerIndex(int id) {
        for (int i = 0; i < cleaners.size(); ++i) {
            if (cleaners[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCar(string model, string owner) {
        Car car;
        car.id = ++carIdCounter;
        car.model = model;
        car.owner = owner;
        cars.push_back(car);
    }

    void deleteCar(int id) {
        int index = findCarIndex(id);
        if (index != -1) cars.erase(cars.begin() + index);
    }

    void updateCar(int id, string model, string owner) {
        int index = findCarIndex(id);
        if (index != -1) {
            cars[index].model = model;
            cars[index].owner = owner;
        }
    }

    Car* searchCar(int id) {
        int index = findCarIndex(id);
        if (index != -1) return &cars[index];
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            cout << "ID: " << car.id << " Model: " << car.model << " Owner: " << car.owner << endl;
        }
    }

    void addCleaner(string name, string shift) {
        Cleaner cleaner;
        cleaner.id = ++cleanerIdCounter;
        cleaner.name = name;
        cleaner.shift = shift;
        cleaners.push_back(cleaner);
    }

    void deleteCleaner(int id) {
        int index = findCleanerIndex(id);
        if (index != -1) cleaners.erase(cleaners.begin() + index);
    }

    void updateCleaner(int id, string name, string shift) {
        int index = findCleanerIndex(id);
        if (index != -1) {
            cleaners[index].name = name;
            cleaners[index].shift = shift;
        }
    }

    Cleaner* searchCleaner(int id) {
        int index = findCleanerIndex(id);
        if (index != -1) return &cleaners[index];
        return nullptr;
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            cout << "ID: " << cleaner.id << " Name: " << cleaner.name << " Shift: " << cleaner.shift << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;

    system.addCar("Toyota Corolla", "Alice");
    system.addCar("Honda Civic", "Bob");
    system.displayCars();

    system.addCleaner("John", "Morning");
    system.addCleaner("Doe", "Evening");
    system.displayCleaners();

    system.updateCar(1, "Toyota Corolla", "Charlie");
    system.updateCleaner(1, "John Smith", "Morning");
    system.displayCars();
    system.displayCleaners();

    Car* car = system.searchCar(2);
    if (car) cout << "Found Car - ID: " << car->id << " Model: " << car->model << " Owner: " << car->owner << endl;

    Cleaner* cleaner = system.searchCleaner(2);
    if (cleaner) cout << "Found Cleaner - ID: " << cleaner->id << " Name: " << cleaner->name << " Shift: " << cleaner->shift << endl;

    system.deleteCar(1);
    system.deleteCleaner(1);
    system.displayCars();
    system.displayCleaners();

    return 0;
}