#include <iostream>
#include <string>

struct Car {
    int id;
    std::string make;
    std::string model;
};

struct Cleaner {
    int id;
    std::string name;
};

class CarCleaningSystem {
private:
    Car cars[100];
    Cleaner cleaners[100];
    int totalCars;
    int totalCleaners;

public:
    CarCleaningSystem() : totalCars(0), totalCleaners(0) {}

    void addCar(int id, const std::string& make, const std::string& model) {
        cars[totalCars++] = {id, make, model};
    }

    void deleteCar(int id) {
        for (int i = 0; i < totalCars; ++i) {
            if (cars[i].id == id) {
                for (int j = i; j < totalCars - 1; ++j) {
                    cars[j] = cars[j + 1];
                }
                --totalCars;
                break;
            }
        }
    }

    void updateCar(int id, const std::string& make, const std::string& model) {
        for (int i = 0; i < totalCars; ++i) {
            if (cars[i].id == id) {
                cars[i].make = make;
                cars[i].model = model;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (int i = 0; i < totalCars; ++i) {
            if (cars[i].id == id) return &cars[i];
        }
        return nullptr;
    }

    void displayCars() {
        for (int i = 0; i < totalCars; ++i) {
            std::cout << "Car ID: " << cars[i].id << ", Make: " << cars[i].make << ", Model: " << cars[i].model << "\n";
        }
    }

    void addCleaner(int id, const std::string& name) {
        cleaners[totalCleaners++] = {id, name};
    }

    void deleteCleaner(int id) {
        for (int i = 0; i < totalCleaners; ++i) {
            if (cleaners[i].id == id) {
                for (int j = i; j < totalCleaners - 1; ++j) {
                    cleaners[j] = cleaners[j + 1];
                }
                --totalCleaners;
                break;
            }
        }
    }

    void updateCleaner(int id, const std::string& name) {
        for (int i = 0; i < totalCleaners; ++i) {
            if (cleaners[i].id == id) {
                cleaners[i].name = name;
                break;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for (int i = 0; i < totalCleaners; ++i) {
            if (cleaners[i].id == id) return &cleaners[i];
        }
        return nullptr;
    }

    void displayCleaners() {
        for (int i = 0; i < totalCleaners; ++i) {
            std::cout << "Cleaner ID: " << cleaners[i].id << ", Name: " << cleaners[i].name << "\n";
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Camry");
    system.addCar(2, "Honda", "Civic");
    system.addCleaner(1, "John Doe");
    system.displayCars();
    system.displayCleaners();
    Car* foundCar = system.searchCar(1);
    if (foundCar) {
        std::cout << "Found car: " << foundCar->make << " " << foundCar->model << "\n";
    }
    Cleaner* foundCleaner = system.searchCleaner(1);
    if (foundCleaner) {
        std::cout << "Found cleaner: " << foundCleaner->name << "\n";
    }
    return 0;
}