#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    int id;
    string make;
    string model;
};

struct Cleaner {
    int id;
    string name;
};

vector<Car> cars;
vector<Cleaner> cleaners;

void addCar() {
    Car car;
    cout << "Enter car ID, make, and model: ";
    cin >> car.id >> car.make >> car.model;
    cars.push_back(car);
}

void deleteCar() {
    int id;
    cout << "Enter car ID to delete: ";
    cin >> id;
    for (auto it = cars.begin(); it != cars.end(); ++it) {
        if (it->id == id) {
            cars.erase(it);
            cout << "Car deleted.\n";
            return;
        }
    }
    cout << "Car not found.\n";
}

void updateCar() {
    int id;
    cout << "Enter car ID to update: ";
    cin >> id;
    for (auto &car : cars) {
        if (car.id == id) {
            cout << "Enter new make and model: ";
            cin >> car.make >> car.model;
            cout << "Car updated.\n";
            return;
        }
    }
    cout << "Car not found.\n";
}

void searchCar() {
    int id;
    cout << "Enter car ID to search: ";
    cin >> id;
    for (const auto &car : cars) {
        if (car.id == id) {
            cout << "Car found: ID=" << car.id << " Make=" << car.make << " Model=" << car.model << endl;
            return;
        }
    }
    cout << "Car not found.\n";
}

void displayCars() {
    cout << "Cars:\n";
    for (const auto &car : cars) {
        cout << "ID=" << car.id << " Make=" << car.make << " Model=" << car.model << endl;
    }
}

void addCleaner() {
    Cleaner cleaner;
    cout << "Enter cleaner ID and name: ";
    cin >> cleaner.id >> cleaner.name;
    cleaners.push_back(cleaner);
}

void deleteCleaner() {
    int id;
    cout << "Enter cleaner ID to delete: ";
    cin >> id;
    for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
        if (it->id == id) {
            cleaners.erase(it);
            cout << "Cleaner deleted.\n";
            return;
        }
    }
    cout << "Cleaner not found.\n";
}

void updateCleaner() {
    int id;
    cout << "Enter cleaner ID to update: ";
    cin >> id;
    for (auto &cleaner : cleaners) {
        if (cleaner.id == id) {
            cout << "Enter new name: ";
            cin >> cleaner.name;
            cout << "Cleaner updated.\n";
            return;
        }
    }
    cout << "Cleaner not found.\n";
}

void searchCleaner() {
    int id;
    cout << "Enter cleaner ID to search: ";
    cin >> id;
    for (const auto &cleaner : cleaners) {
        if (cleaner.id == id) {
            cout << "Cleaner found: ID=" << cleaner.id << " Name=" << cleaner.name << endl;
            return;
        }
    }
    cout << "Cleaner not found.\n";
}

void displayCleaners() {
    cout << "Cleaners:\n";
    for (const auto &cleaner : cleaners) {
        cout << "ID=" << cleaner.id << " Name=" << cleaner.name << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "\n1. Add Car\n2. Delete Car\n3. Update Car\n4. Search Car\n5. Display Cars\n";
        cout << "6. Add Cleaner\n7. Delete Cleaner\n8. Update Cleaner\n9. Search Cleaner\n10. Display Cleaners\n0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addCar(); break;
            case 2: deleteCar(); break;
            case 3: updateCar(); break;
            case 4: searchCar(); break;
            case 5: displayCars(); break;
            case 6: addCleaner(); break;
            case 7: deleteCleaner(); break;
            case 8: updateCleaner(); break;
            case 9: searchCleaner(); break;
            case 10: displayCleaners(); break;
        }
    } while (choice != 0);
    return 0;
}