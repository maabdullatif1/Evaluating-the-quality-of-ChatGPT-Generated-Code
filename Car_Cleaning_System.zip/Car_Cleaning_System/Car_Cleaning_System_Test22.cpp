#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    string licensePlate;
    string model;
    string ownerName;

    Car(string lp, string m, string o) : licensePlate(lp), model(m), ownerName(o) {}
};

class Cleaner {
public:
    string name;
    int id;

    Cleaner(string n, int i) : name(n), id(i) {}
};

class CarCleaningSystem {
    vector<Car> cars;
    vector<Cleaner> cleaners;

public:
    void addCar(string licensePlate, string model, string ownerName) {
        cars.push_back(Car(licensePlate, model, ownerName));
    }

    void deleteCar(string licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(string licensePlate, string newModel, string newOwnerName) {
        for (auto &car : cars) {
            if (car.licensePlate == licensePlate) {
                car.model = newModel;
                car.ownerName = newOwnerName;
                break;
            }
        }
    }

    void addCleaner(string name, int id) {
        cleaners.push_back(Cleaner(name, id));
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, string newName) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = newName;
                break;
            }
        }
    }

    Car* searchCar(string licensePlate) {
        for (auto &car : cars) {
            if (car.licensePlate == licensePlate) {
                return &car;
            }
        }
        return nullptr;
    }

    Cleaner* searchCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "License Plate: " << car.licensePlate << ", Model: " << car.model << ", Owner Name: " << car.ownerName << endl;
        }
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            cout << "Name: " << cleaner.name << ", ID: " << cleaner.id << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    
    system.addCar("ABC123", "Toyota", "Alice");
    system.addCar("XYZ789", "Honda", "Bob");

    system.addCleaner("John", 1);
    system.addCleaner("Doe", 2);

    system.displayCars();
    system.displayCleaners();

    Car* foundCar = system.searchCar("ABC123");
    if (foundCar) {
        cout << "Found Car: " << foundCar->model << ", Owned by: " << foundCar->ownerName << endl;
    }

    system.updateCar("XYZ789", "Nissan", "Charlie");
    system.displayCars();

    system.deleteCar("ABC123");
    system.displayCars();

    Cleaner* foundCleaner = system.searchCleaner(1);
    if (foundCleaner) {
        cout << "Found Cleaner: " << foundCleaner->name << endl;
    }

    system.updateCleaner(2, "Jane");
    system.displayCleaners();

    system.deleteCleaner(1);
    system.displayCleaners();

    return 0;
}