#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string model;
    std::string ownerName;

    Car(std::string lp, std::string m, std::string on) : licensePlate(lp), model(m), ownerName(on) {}
};

class Cleaner {
public:
    std::string name;
    int id;

    Cleaner(int i, std::string n) : id(i), name(n) {}
};

class CarCleaningSystem {
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(std::string licensePlate, std::string model, std::string ownerName) {
        cars.push_back(Car(licensePlate, model, ownerName));
    }

    void deleteCar(std::string licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(std::string licensePlate, std::string newModel, std::string newOwnerName) {
        for (auto &car : cars) {
            if (car.licensePlate == licensePlate) {
                car.model = newModel;
                car.ownerName = newOwnerName;
                break;
            }
        }
    }

    void searchCar(std::string licensePlate) {
        for (const auto &car : cars) {
            if (car.licensePlate == licensePlate) {
                std::cout << "Car found: " << car.licensePlate << ", " << car.model << ", " << car.ownerName << std::endl;
                return;
            }
        }
        std::cout << "Car not found" << std::endl;
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "Car: " << car.licensePlate << ", " << car.model << ", " << car.ownerName << std::endl;
        }
    }

    void addCleaner(int id, std::string name) {
        cleaners.push_back(Cleaner(id, name));
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, std::string newName) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = newName;
                break;
            }
        }
    }

    void searchCleaner(int id) {
        for (const auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                std::cout << "Cleaner found: " << cleaner.id << ", " << cleaner.name << std::endl;
                return;
            }
        }
        std::cout << "Cleaner not found" << std::endl;
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            std::cout << "Cleaner: " << cleaner.id << ", " << cleaner.name << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("ABC123", "Toyota", "John Doe");
    system.addCar("DEF456", "Honda", "Jane Smith");
    system.addCleaner(1, "Cleaner A");
    system.addCleaner(2, "Cleaner B");

    system.displayCars();
    system.searchCar("ABC123");
    system.updateCar("ABC123", "Ford", "Johnny Doe");
    system.searchCar("ABC123");

    system.displayCleaners();
    system.searchCleaner(1);
    system.updateCleaner(1, "Cleaner A Updated");
    system.searchCleaner(1);

    return 0;
}