#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Car {
    string id;
    string model;
    string owner;
};

struct Cleaner {
    string id;
    string name;
    int experience;
};

class CarCleaningSystem {
    vector<Car> cars;
    vector<Cleaner> cleaners;

    int findCarIndex(const string& id) {
        for (int i = 0; i < cars.size(); ++i) {
            if (cars[i].id == id) return i;
        }
        return -1;
    }

    int findCleanerIndex(const string& id) {
        for (int i = 0; i < cleaners.size(); ++i) {
            if (cleaners[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCar(const string& id, const string& model, const string& owner) {
        if (findCarIndex(id) == -1) {
            cars.push_back({id, model, owner});
        } else {
            cout << "Car with this ID already exists.\n";
        }
    }

    void deleteCar(const string& id) {
        int index = findCarIndex(id);
        if (index != -1) {
            cars.erase(cars.begin() + index);
        } else {
            cout << "Car not found.\n";
        }
    }

    void updateCar(const string& id, const string& model, const string& owner) {
        int index = findCarIndex(id);
        if (index != -1) {
            cars[index].model = model;
            cars[index].owner = owner;
        } else {
            cout << "Car not found.\n";
        }
    }

    void searchCar(const string& id) {
        int index = findCarIndex(id);
        if (index != -1) {
            cout << "Car ID: " << cars[index].id << ", Model: " << cars[index].model << ", Owner: " << cars[index].owner << "\n";
        } else {
            cout << "Car not found.\n";
        }
    }

    void displayCars() {
        for (const Car& car : cars) {
            cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << "\n";
        }
    }

    void addCleaner(const string& id, const string& name, int experience) {
        if (findCleanerIndex(id) == -1) {
            cleaners.push_back({id, name, experience});
        } else {
            cout << "Cleaner with this ID already exists.\n";
        }
    }

    void deleteCleaner(const string& id) {
        int index = findCleanerIndex(id);
        if (index != -1) {
            cleaners.erase(cleaners.begin() + index);
        } else {
            cout << "Cleaner not found.\n";
        }
    }

    void updateCleaner(const string& id, const string& name, int experience) {
        int index = findCleanerIndex(id);
        if (index != -1) {
            cleaners[index].name = name;
            cleaners[index].experience = experience;
        } else {
            cout << "Cleaner not found.\n";
        }
    }

    void searchCleaner(const string& id) {
        int index = findCleanerIndex(id);
        if (index != -1) {
            cout << "Cleaner ID: " << cleaners[index].id << ", Name: " << cleaners[index].name << ", Experience: " << cleaners[index].experience << "\n";
        } else {
            cout << "Cleaner not found.\n";
        }
    }

    void displayCleaners() {
        for (const Cleaner& cleaner : cleaners) {
            cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << ", Experience: " << cleaner.experience << "\n";
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("C001", "Toyota Camry", "John Doe");
    system.addCar("C002", "Honda Accord", "Jane Smith");
    system.displayCars();
    system.addCleaner("CL001", "Mike Johnson", 5);
    system.addCleaner("CL002", "Sue Wang", 8);
    system.displayCleaners();
    system.updateCar("C002", "Honda Civic", "Jane Smith");
    system.displayCars();
    system.deleteCar("C001");
    system.displayCars();
    system.searchCleaner("CL002");
    system.deleteCleaner("CL001");
    system.displayCleaners();
    return 0;
}