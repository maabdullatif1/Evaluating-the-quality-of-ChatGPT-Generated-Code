#include <iostream>
#include <vector>
#include <string>

struct Car {
    int id;
    std::string model;
    std::string owner;
};

struct Cleaner {
    int id;
    std::string name;
};

class CarCleaningSystem {
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

    int findCarIndex(int id) {
        for (size_t i = 0; i < cars.size(); ++i)
            if (cars[i].id == id) return i;
        return -1;
    }

    int findCleanerIndex(int id) {
        for (size_t i = 0; i < cleaners.size(); ++i)
            if (cleaners[i].id == id) return i;
        return -1;
    }

public:
    void addCar(int id, std::string model, std::string owner) {
        if (findCarIndex(id) == -1)
            cars.push_back({id, model, owner});
    }

    void deleteCar(int id) {
        int index = findCarIndex(id);
        if (index != -1)
            cars.erase(cars.begin() + index);
    }

    void updateCar(int id, std::string model, std::string owner) {
        int index = findCarIndex(id);
        if (index != -1) {
            cars[index].model = model;
            cars[index].owner = owner;
        }
    }

    Car* searchCar(int id) {
        int index = findCarIndex(id);
        return index != -1 ? &cars[index] : nullptr;
    }

    void displayCars() {
        for (const auto& car : cars)
            std::cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << "\n";
    }

    void addCleaner(int id, std::string name) {
        if (findCleanerIndex(id) == -1)
            cleaners.push_back({id, name});
    }

    void deleteCleaner(int id) {
        int index = findCleanerIndex(id);
        if (index != -1)
            cleaners.erase(cleaners.begin() + index);
    }

    void updateCleaner(int id, std::string name) {
        int index = findCleanerIndex(id);
        if (index != -1)
            cleaners[index].name = name;
    }

    Cleaner* searchCleaner(int id) {
        int index = findCleanerIndex(id);
        return index != -1 ? &cleaners[index] : nullptr;
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners)
            std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << "\n";
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Alice");
    system.addCar(2, "Honda", "Bob");
    system.displayCars();
    
    system.addCleaner(1, "John");
    system.addCleaner(2, "Doe");
    system.displayCleaners();
    
    system.updateCar(1, "Toyota", "Charlie");
    system.updateCleaner(1, "Johnny");
    system.displayCars();
    system.displayCleaners();

    system.deleteCar(2);
    system.deleteCleaner(2);
    system.displayCars();
    system.displayCleaners();

    return 0;
}