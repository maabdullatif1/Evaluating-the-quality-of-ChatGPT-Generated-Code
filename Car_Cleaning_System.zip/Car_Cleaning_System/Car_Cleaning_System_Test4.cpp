#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string make;
    std::string model;
    int year;

    Car(int id, std::string make, std::string model, int year)
        : id(id), make(make), model(model), year(year) {}
};

class Cleaner {
public:
    int id;
    std::string name;
    int experience;

    Cleaner(int id, std::string name, int experience)
        : id(id), name(name), experience(experience) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(int id, const std::string& make, const std::string& model, int year) {
        cars.push_back(Car(id, make, model, year));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                return;
            }
        }
    }

    void updateCar(int id, const std::string& make, const std::string& model, int year) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.year = year;
                return;
            }
        }
    }
    
    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "ID: " << car.id << " Make: " << car.make
                      << " Model: " << car.model << " Year: " << car.year << '\n';
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void addCleaner(int id, const std::string& name, int experience) {
        cleaners.push_back(Cleaner(id, name, experience));
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                return;
            }
        }
    }

    void updateCleaner(int id, const std::string& name, int experience) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                cleaner.experience = experience;
                return;
            }
        }
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "ID: " << cleaner.id << " Name: " << cleaner.name
                      << " Experience: " << cleaner.experience << " years\n";
        }
    }

    Cleaner* searchCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Corolla", 2020);
    system.addCar(2, "Honda", "Civic", 2019);
    system.displayCars();
    system.updateCar(1, "Toyota", "Camry", 2021);
    system.displayCars();
    system.deleteCar(2);
    system.displayCars();

    system.addCleaner(1, "John Doe", 5);
    system.addCleaner(2, "Jane Smith", 3);
    system.displayCleaners();
    system.updateCleaner(1, "John Doe", 6);
    system.displayCleaners();
    system.deleteCleaner(2);
    system.displayCleaners();

    return 0;
}