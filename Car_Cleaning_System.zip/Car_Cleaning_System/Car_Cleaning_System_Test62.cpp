#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    int id;
    string model;
    string owner;
};

struct Cleaner {
    int id;
    string name;
    string shift;
};

class CarCleaningSystem {
    vector<Car> cars;
    vector<Cleaner> cleaners;

public:
    void addCar(int id, const string &model, const string &owner) {
        cars.push_back({id, model, owner});
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, const string &newModel, const string &newOwner) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.model = newModel;
                car.owner = newOwner;
                break;
            }
        }
    }

    void searchCar(int id) {
        for (const auto &car : cars) {
            if (car.id == id) {
                cout << "Car ID: " << car.id << ", Model: " << car.model 
                     << ", Owner: " << car.owner << endl;
                return;
            }
        }
        cout << "Car not found" << endl;
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "Car ID: " << car.id << ", Model: " << car.model 
                 << ", Owner: " << car.owner << endl;
        }
    }

    void addCleaner(int id, const string &name, const string &shift) {
        cleaners.push_back({id, name, shift});
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, const string &newName, const string &newShift) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = newName;
                cleaner.shift = newShift;
                break;
            }
        }
    }

    void searchCleaner(int id) {
        for (const auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name 
                     << ", Shift: " << cleaner.shift << endl;
                return;
            }
        }
        cout << "Cleaner not found" << endl;
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name 
                 << ", Shift: " << cleaner.shift << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;

    system.addCar(1, "Toyota", "Alice");
    system.addCar(2, "Honda", "Bob");
    system.displayCars();

    system.addCleaner(1, "John", "Morning");
    system.addCleaner(2, "Jane", "Evening");
    system.displayCleaners();

    system.updateCar(1, "Toyota Vios", "Alice Smith");
    system.searchCar(1);

    system.updateCleaner(2, "Jane Doe", "Night");
    system.searchCleaner(2);

    system.deleteCar(2);
    system.displayCars();

    system.deleteCleaner(1);
    system.displayCleaners();

    return 0;
}