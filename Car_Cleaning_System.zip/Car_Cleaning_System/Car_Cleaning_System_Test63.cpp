#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    int id;
    string brand;
    string model;
};

struct Cleaner {
    int id;
    string name;
};

class CarCleaningSystem {
private:
    vector<Car> cars;
    vector<Cleaner> cleaners;

public:
    void addCar(int id, const string& brand, const string& model) {
        cars.push_back({id, brand, model});
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                return;
            }
        }
    }

    void updateCar(int id, const string& brand, const string& model) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.brand = brand;
                car.model = model;
                return;
            }
        }
    }

    void searchCar(int id) {
        for (const auto &car : cars) {
            if (car.id == id) {
                cout << "Car ID: " << car.id << " Brand: " << car.brand << " Model: " << car.model << endl;
                return;
            }
        }
        cout << "Car not found." << endl;
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "Car ID: " << car.id << " Brand: " << car.brand << " Model: " << car.model << endl;
        }
    }

    void addCleaner(int id, const string& name) {
        cleaners.push_back({id, name});
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                return;
            }
        }
    }

    void updateCleaner(int id, const string& name) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                return;
            }
        }
    }

    void searchCleaner(int id) {
        for (const auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cout << "Cleaner ID: " << cleaner.id << " Name: " << cleaner.name << endl;
                return;
            }
        }
        cout << "Cleaner not found." << endl;
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            cout << "Cleaner ID: " << cleaner.id << " Name: " << cleaner.name << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Corolla");
    system.addCar(2, "Ford", "Mustang");
    system.displayCars();
    system.addCleaner(1, "John Doe");
    system.addCleaner(2, "Jane Doe");
    system.displayCleaners();
    system.searchCar(1);
    system.updateCar(1, "Toyota", "Camry");
    system.displayCars();
    system.deleteCar(2);
    system.displayCars();
    system.searchCleaner(1);
    system.updateCleaner(1, "Jonathan Doe");
    system.displayCleaners();
    system.deleteCleaner(2);
    system.displayCleaners();
    return 0;
}