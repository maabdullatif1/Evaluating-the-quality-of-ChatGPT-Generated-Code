#include <iostream>
#include <vector>
#include <string>

struct Car {
    int id;
    std::string model;
    std::string registration;
};

struct Cleaner {
    int id;
    std::string name;
    std::string phone;
};

class CarCleaningSystem {
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;
    int carIdCounter = 1;
    int cleanerIdCounter = 1;

public:
    void addCar(const std::string& model, const std::string& registration) {
        cars.push_back({carIdCounter++, model, registration});
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                return;
            }
        }
    }

    void updateCar(int id, const std::string& model, const std::string& registration) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.model = model;
                car.registration = registration;
                return;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) return &car;
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "ID: " << car.id << ", Model: " << car.model << ", Registration: " << car.registration << std::endl;
        }
    }

    void addCleaner(const std::string& name, const std::string& phone) {
        cleaners.push_back({cleanerIdCounter++, name, phone});
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                return;
            }
        }
    }

    void updateCleaner(int id, const std::string& name, const std::string& phone) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                cleaner.phone = phone;
                return;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) return &cleaner;
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << ", Phone: " << cleaner.phone << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("Toyota", "ABC123");
    system.addCleaner("John", "555-1234");

    system.displayCars();
    system.displayCleaners();

    return 0;
}