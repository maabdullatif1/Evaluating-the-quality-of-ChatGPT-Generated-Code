#include <iostream>
#include <string>
#include <vector>

class Car {
public:
    int id;
    std::string owner;
    std::string model;

    Car(int id, const std::string &owner, const std::string &model)
        : id(id), owner(owner), model(model) {}
};

class Cleaner {
public:
    int id;
    std::string name;

    Cleaner(int id, const std::string &name) : id(id), name(name) {}
};

class CarCleaningSystem {
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) return &car;
        }
        return nullptr;
    }

    Cleaner* searchCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) return &cleaner;
        }
        return nullptr;
    }

public:
    void addCar(int id, const std::string &owner, const std::string &model) {
        cars.push_back(Car(id, owner, model));
    }

    void deleteCar(int id) {
        cars.erase(std::remove_if(cars.begin(), cars.end(),
                   [id](const Car &c) { return c.id == id; }),
                   cars.end());
    }

    void updateCar(int id, const std::string &owner, const std::string &model) {
        Car* car = searchCar(id);
        if (car) {
            car->owner = owner;
            car->model = model;
        }
    }

    void addCleaner(int id, const std::string &name) {
        cleaners.push_back(Cleaner(id, name));
    }

    void deleteCleaner(int id) {
        cleaners.erase(std::remove_if(cleaners.begin(), cleaners.end(),
                     [id](const Cleaner &c) { return c.id == id; }),
                     cleaners.end());
    }

    void updateCleaner(int id, const std::string &name) {
        Cleaner* cleaner = searchCleaner(id);
        if (cleaner) {
            cleaner->name = name;
        }
    }

    void displayCars() const {
        for (const auto &car : cars) {
            std::cout << "ID: " << car.id << ", Owner: " << car.owner << ", Model: " << car.model << "\n";
        }
    }

    void displayCleaners() const {
        for (const auto &cleaner : cleaners) {
            std::cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << "\n";
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Alice", "Tesla Model 3");
    system.addCar(2, "Bob", "Ford Mustang");
    system.addCleaner(1, "John");
    system.addCleaner(2, "Doe");

    std::cout << "Cars:\n";
    system.displayCars();

    std::cout << "Cleaners:\n";
    system.displayCleaners();

    system.updateCar(1, "Alice", "Tesla Model S");
    system.updateCleaner(1, "Johnny");

    std::cout << "Updated Cars:\n";
    system.displayCars();

    std::cout << "Updated Cleaners:\n";
    system.displayCleaners();

    system.deleteCar(2);
    system.deleteCleaner(2);

    std::cout << "After Deletion - Cars:\n";
    system.displayCars();

    std::cout << "After Deletion - Cleaners:\n";
    system.displayCleaners();

    return 0;
}