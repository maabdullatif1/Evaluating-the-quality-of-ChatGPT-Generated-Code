#include <iostream>
#include <string>
#include <vector>

struct Car {
    int id;
    std::string brand;
    std::string model;
};

struct Cleaner {
    int id;
    std::string name;
    std::string shift;
};

std::vector<Car> cars;
std::vector<Cleaner> cleaners;

void addCar() {
    Car car;
    std::cout << "Enter Car ID: ";
    std::cin >> car.id;
    std::cout << "Enter Car Brand: ";
    std::cin >> car.brand;
    std::cout << "Enter Car Model: ";
    std::cin >> car.model;
    cars.push_back(car);
}

void deleteCar() {
    int id;
    std::cout << "Enter Car ID to delete: ";
    std::cin >> id;
    for (auto it = cars.begin(); it != cars.end(); ++it) {
        if (it->id == id) {
            cars.erase(it);
            return;
        }
    }
    std::cout << "Car not found.\n";
}

void updateCar() {
    int id;
    std::cout << "Enter Car ID to update: ";
    std::cin >> id;
    for (auto& car : cars) {
        if (car.id == id) {
            std::cout << "Enter new Car Brand: ";
            std::cin >> car.brand;
            std::cout << "Enter new Car Model: ";
            std::cin >> car.model;
            return;
        }
    }
    std::cout << "Car not found.\n";
}

void searchCar() {
    int id;
    std::cout << "Enter Car ID to search: ";
    std::cin >> id;
    for (const auto& car : cars) {
        if (car.id == id) {
            std::cout << "Car ID: " << car.id << ", Brand: " << car.brand << ", Model: " << car.model << "\n";
            return;
        }
    }
    std::cout << "Car not found.\n";
}

void displayCars() {
    for (const auto& car : cars) {
        std::cout << "Car ID: " << car.id << ", Brand: " << car.brand << ", Model: " << car.model << "\n";
    }
}

void addCleaner() {
    Cleaner cleaner;
    std::cout << "Enter Cleaner ID: ";
    std::cin >> cleaner.id;
    std::cout << "Enter Cleaner Name: ";
    std::cin >> cleaner.name;
    std::cout << "Enter Cleaner Shift: ";
    std::cin >> cleaner.shift;
    cleaners.push_back(cleaner);
}

void deleteCleaner() {
    int id;
    std::cout << "Enter Cleaner ID to delete: ";
    std::cin >> id;
    for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
        if (it->id == id) {
            cleaners.erase(it);
            return;
        }
    }
    std::cout << "Cleaner not found.\n";
}

void updateCleaner() {
    int id;
    std::cout << "Enter Cleaner ID to update: ";
    std::cin >> id;
    for (auto& cleaner : cleaners) {
        if (cleaner.id == id) {
            std::cout << "Enter new Cleaner Name: ";
            std::cin >> cleaner.name;
            std::cout << "Enter new Cleaner Shift: ";
            std::cin >> cleaner.shift;
            return;
        }
    }
    std::cout << "Cleaner not found.\n";
}

void searchCleaner() {
    int id;
    std::cout << "Enter Cleaner ID to search: ";
    std::cin >> id;
    for (const auto& cleaner : cleaners) {
        if (cleaner.id == id) {
            std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << ", Shift: " << cleaner.shift << "\n";
            return;
        }
    }
    std::cout << "Cleaner not found.\n";
}

void displayCleaners() {
    for (const auto& cleaner : cleaners) {
        std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << ", Shift: " << cleaner.shift << "\n";
    }
}

int main() {
    int choice;
    do {
        std::cout << "1. Add Car\n2. Delete Car\n3. Update Car\n4. Search Car\n5. Display Cars\n";
        std::cout << "6. Add Cleaner\n7. Delete Cleaner\n8. Update Cleaner\n9. Search Cleaner\n10. Display Cleaners\n11. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;
        switch (choice) {
            case 1:
                addCar();
                break;
            case 2:
                deleteCar();
                break;
            case 3:
                updateCar();
                break;
            case 4:
                searchCar();
                break;
            case 5:
                displayCars();
                break;
            case 6:
                addCleaner();
                break;
            case 7:
                deleteCleaner();
                break;
            case 8:
                updateCleaner();
                break;
            case 9:
                searchCleaner();
                break;
            case 10:
                displayCleaners();
                break;
            case 11:
                break;
            default:
                std::cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 11);

    return 0;
}