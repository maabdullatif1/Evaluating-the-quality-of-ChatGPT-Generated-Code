#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    string licensePlate;
    string model;
    string color;

    Car(string lp, string m, string c) : licensePlate(lp), model(m), color(c) {}
};

class Cleaner {
public:
    string name;
    int id;

    Cleaner(string n, int i) : name(n), id(i) {}
};

vector<Car> cars;
vector<Cleaner> cleaners;

void addCar(string lp, string model, string color) {
    cars.push_back(Car(lp, model, color));
}

void deleteCar(string lp) {
    for (auto it = cars.begin(); it != cars.end(); ++it) {
        if (it->licensePlate == lp) {
            cars.erase(it);
            break;
        }
    }
}

void updateCar(string lp, string newModel, string newColor) {
    for (auto &car : cars) {
        if (car.licensePlate == lp) {
            car.model = newModel;
            car.color = newColor;
            break;
        }
    }
}

Car* searchCar(string lp) {
    for (auto &car : cars) {
        if (car.licensePlate == lp) {
            return &car;
        }
    }
    return nullptr;
}

void displayCars() {
    for (const auto &car : cars) {
        cout << "License Plate: " << car.licensePlate 
             << ", Model: " << car.model 
             << ", Color: " << car.color << endl;
    }
}

void addCleaner(string name, int id) {
    cleaners.push_back(Cleaner(name, id));
}

void deleteCleaner(int id) {
    for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
        if (it->id == id) {
            cleaners.erase(it);
            break;
        }
    }
}

void updateCleaner(int id, string newName) {
    for (auto &cleaner : cleaners) {
        if (cleaner.id == id) {
            cleaner.name = newName;
            break;
        }
    }
}

Cleaner* searchCleaner(int id) {
    for (auto &cleaner : cleaners) {
        if (cleaner.id == id) {
            return &cleaner;
        }
    }
    return nullptr;
}

void displayCleaners() {
    for (const auto &cleaner : cleaners) {
        cout << "Cleaner Name: " << cleaner.name 
             << ", ID: " << cleaner.id << endl;
    }
}

int main() {
    addCar("ABC123", "Toyota Camry", "Red");
    addCar("XYZ789", "Honda Accord", "Blue");
    addCleaner("John", 1);
    addCleaner("Anna", 2);
    
    cout << "All Cars:" << endl;
    displayCars();
    
    cout << "\nAll Cleaners:" << endl;
    displayCleaners();
    
    updateCar("ABC123", "Toyota Corolla", "Black");
    updateCleaner(1, "Johnny");
    
    cout << "\nUpdated Cars:" << endl;
    displayCars();
    
    cout << "\nUpdated Cleaners:" << endl;
    displayCleaners();
    
    deleteCar("XYZ789");
    deleteCleaner(2);
    
    cout << "\nCars after deletion:" << endl;
    displayCars();
    
    cout << "\nCleaners after deletion:" << endl;
    displayCleaners();
    
    return 0;
}