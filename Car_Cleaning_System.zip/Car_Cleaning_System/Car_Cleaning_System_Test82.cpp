#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string model;
    std::string color;

    Car(std::string lp, std::string m, std::string c) : licensePlate(lp), model(m), color(c) {}
};

class Cleaner {
public:
    std::string name;
    int experience;

    Cleaner(std::string n, int e) : name(n), experience(e) {}
};

class CleaningSystem {
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(const std::string& lp, const std::string& model, const std::string& color) {
        cars.push_back(Car(lp, model, color));
    }

    void deleteCar(const std::string& lp) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == lp) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string& lp, const std::string& newModel, const std::string& newColor) {
        for (auto &car : cars) {
            if (car.licensePlate == lp) {
                car.model = newModel;
                car.color = newColor;
                break;
            }
        }
    }

    Car* searchCar(const std::string& lp) {
        for (auto &car : cars) {
            if (car.licensePlate == lp) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() const {
        for (const auto &car : cars) {
            std::cout << "License Plate: " << car.licensePlate << ", Model: " << car.model << ", Color: " << car.color << "\n";
        }
    }

    void addCleaner(const std::string& name, int experience) {
        cleaners.push_back(Cleaner(name, experience));
    }

    void deleteCleaner(const std::string& name) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->name == name) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(const std::string& name, int newExperience) {
        for (auto &cleaner : cleaners) {
            if (cleaner.name == name) {
                cleaner.experience = newExperience;
                break;
            }
        }
    }

    Cleaner* searchCleaner(const std::string& name) {
        for (auto &cleaner : cleaners) {
            if (cleaner.name == name) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() const {
        for (const auto &cleaner : cleaners) {
            std::cout << "Name: " << cleaner.name << ", Experience: " << cleaner.experience << " years\n";
        }
    }
};

int main() {
    CleaningSystem system;
    system.addCar("ABC123", "Toyota Corolla", "Red");
    system.addCar("XYZ789", "Honda Civic", "Blue");
    system.displayCars();
    system.addCleaner("John Doe", 5);
    system.addCleaner("Jane Smith", 3);
    system.displayCleaners();
    return 0;
}