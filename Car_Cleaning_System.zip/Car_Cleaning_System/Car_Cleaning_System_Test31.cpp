#include <iostream>
#include <string>

const int MAX_ENTRIES = 100;

struct Car {
    int id;
    std::string licensePlate;
    std::string ownerName;
};

struct Cleaner {
    int id;
    std::string name;
};

Car cars[MAX_ENTRIES];
Cleaner cleaners[MAX_ENTRIES];

int carCount = 0;
int cleanerCount = 0;

void addCar(int id, const std::string& licensePlate, const std::string& ownerName) {
    if (carCount < MAX_ENTRIES) {
        cars[carCount++] = {id, licensePlate, ownerName};
    }
}

void addCleaner(int id, const std::string& name) {
    if (cleanerCount < MAX_ENTRIES) {
        cleaners[cleanerCount++] = {id, name};
    }
}

void deleteCar(int id) {
    for (int i = 0; i < carCount; ++i) {
        if (cars[i].id == id) {
            cars[i] = cars[--carCount];
            break;
        }
    }
}

void deleteCleaner(int id) {
    for (int i = 0; i < cleanerCount; ++i) {
        if (cleaners[i].id == id) {
            cleaners[i] = cleaners[--cleanerCount];
            break;
        }
    }
}

void updateCar(int id, const std::string& licensePlate, const std::string& ownerName) {
    for (int i = 0; i < carCount; ++i) {
        if (cars[i].id == id) {
            cars[i].licensePlate = licensePlate;
            cars[i].ownerName = ownerName;
            break;
        }
    }
}

void updateCleaner(int id, const std::string& name) {
    for (int i = 0; i < cleanerCount; ++i) {
        if (cleaners[i].id == id) {
            cleaners[i].name = name;
            break;
        }
    }
}

void searchCar(int id) {
    for (int i = 0; i < carCount; ++i) {
        if (cars[i].id == id) {
            std::cout << "Car found: ID = " << cars[i].id << ", License Plate = " << cars[i].licensePlate << ", Owner Name = " << cars[i].ownerName << "\n";
            return;
        }
    }
    std::cout << "Car not found\n";
}

void searchCleaner(int id) {
    for (int i = 0; i < cleanerCount; ++i) {
        if (cleaners[i].id == id) {
            std::cout << "Cleaner found: ID = " << cleaners[i].id << ", Name = " << cleaners[i].name << "\n";
            return;
        }
    }
    std::cout << "Cleaner not found\n";
}

void displayCars() {
    for (int i = 0; i < carCount; ++i) {
        std::cout << "Car ID: " << cars[i].id << ", License Plate: " << cars[i].licensePlate << ", Owner Name: " << cars[i].ownerName << "\n";
    }
}

void displayCleaners() {
    for (int i = 0; i < cleanerCount; ++i) {
        std::cout << "Cleaner ID: " << cleaners[i].id << ", Name: " << cleaners[i].name << "\n";
    }
}

int main() {
    addCar(1, "ABC123", "John Doe");
    addCar(2, "XYZ987", "Jane Smith");
    addCleaner(1, "John Cleaner");
    addCleaner(2, "Anna Cleaner");

    displayCars();
    displayCleaners();

    updateCar(1, "DEF456", "Johnathan Doe");
    updateCleaner(1, "Johnny Cleaner");

    searchCar(1);
    searchCleaner(1);

    deleteCar(2);
    deleteCleaner(2);

    displayCars();
    displayCleaners();

    return 0;
}