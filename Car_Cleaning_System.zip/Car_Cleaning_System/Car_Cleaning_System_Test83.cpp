#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string make;
    std::string model;
    std::string licensePlate;

    Car(int _id, std::string _make, std::string _model, std::string _licensePlate)
        : id(_id), make(_make), model(_model), licensePlate(_licensePlate) {}
};

class Cleaner {
public:
    int id;
    std::string name;
    std::string phoneNumber;

    Cleaner(int _id, std::string _name, std::string _phoneNumber)
        : id(_id), name(_name), phoneNumber(_phoneNumber) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(int id, std::string make, std::string model, std::string licensePlate) {
        cars.emplace_back(id, make, model, licensePlate);
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, std::string make, std::string model, std::string licensePlate) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.licensePlate = licensePlate;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id)
                return &car;
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "ID: " << car.id << ", Make: " << car.make
                      << ", Model: " << car.model
                      << ", License Plate: " << car.licensePlate << std::endl;
        }
    }

    void addCleaner(int id, std::string name, std::string phoneNumber) {
        cleaners.emplace_back(id, name, phoneNumber);
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, std::string name, std::string phoneNumber) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                cleaner.phoneNumber = phoneNumber;
                break;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id)
                return &cleaner;
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "ID: " << cleaner.id << ", Name: " << cleaner.name
                      << ", Phone: " << cleaner.phoneNumber << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Corolla", "ABC123");
    system.addCar(2, "Honda", "Civic", "XYZ789");
    system.addCleaner(1, "John Doe", "1234567890");
    system.addCleaner(2, "Jane Smith", "0987654321");
    
    std::cout << "Cars:\n";
    system.displayCars();
    
    std::cout << "\nCleaners:\n";
    system.displayCleaners();
    
    system.updateCar(1, "Toyota", "Camry", "ZZZ111");
    system.updateCleaner(2, "Jane Smith", "1122334455");
    
    std::cout << "\nUpdated Cars:\n";
    system.displayCars();
    
    std::cout << "\nUpdated Cleaners:\n";
    system.displayCleaners();

    return 0;
}