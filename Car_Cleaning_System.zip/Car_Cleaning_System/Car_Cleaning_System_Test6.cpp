#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    string licensePlate;
    string model;
    string ownerName;
    Car(string lp, string m, string on) : licensePlate(lp), model(m), ownerName(on) {}
};

class Cleaner {
public:
    int id;
    string name;
    int age;
    Cleaner(int i, string n, int a) : id(i), name(n), age(a) {}
};

class CarCleaningSystem {
private:
    vector<Car> cars;
    vector<Cleaner> cleaners;

public:
    void addCar(string licensePlate, string model, string ownerName) {
        cars.emplace_back(licensePlate, model, ownerName);
    }
    
    void deleteCar(string licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                return;
            }
        }
    }
    
    void updateCar(string licensePlate, string newModel, string newOwnerName) {
        for (auto &car : cars) {
            if (car.licensePlate == licensePlate) {
                car.model = newModel;
                car.ownerName = newOwnerName;
                return;
            }
        }
    }
    
    Car* searchCar(string licensePlate) {
        for (auto &car : cars) {
            if (car.licensePlate == licensePlate) {
                return &car;
            }
        }
        return nullptr;
    }
    
    void displayCars() {
        for (const auto &car : cars) {
            cout << "License Plate: " << car.licensePlate << ", Model: " << car.model << ", Owner Name: " << car.ownerName << endl;
        }
    }
    
    void addCleaner(int id, string name, int age) {
        cleaners.emplace_back(id, name, age);
    }
    
    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                return;
            }
        }
    }
    
    void updateCleaner(int id, string newName, int newAge) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = newName;
                cleaner.age = newAge;
                return;
            }
        }
    }
    
    Cleaner* searchCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }
    
    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << ", Age: " << cleaner.age << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("ABC123", "Toyota", "John Doe");
    system.addCar("XYZ789", "Honda", "Jane Smith");
    system.displayCars();
    system.updateCar("ABC123", "Tesla", "Mike Johnson");
    system.displayCars();
    system.addCleaner(1, "Tom", 25);
    system.addCleaner(2, "Jerry", 30);
    system.displayCleaners();
    system.updateCleaner(1, "Tommy", 26);
    system.displayCleaners();
    return 0;
}