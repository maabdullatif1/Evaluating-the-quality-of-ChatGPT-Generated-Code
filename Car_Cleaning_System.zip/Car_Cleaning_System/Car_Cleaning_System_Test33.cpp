#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string brand;
    string model;
    Car(int id, string brand, string model) : id(id), brand(brand), model(model) {}
};

class Cleaner {
public:
    int id;
    string name;
    Cleaner(int id, string name) : id(id), name(name) {}
};

class CarCleaningSystem {
public:
    vector<Car> cars;
    vector<Cleaner> cleaners;
    
    void addCar(int id, string brand, string model) {
        cars.push_back(Car(id, brand, model));
    }
    
    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string newBrand, string newModel) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.brand = newBrand;
                car.model = newModel;
                break;
            }
        }
    }

    void displayCars() {
        for (const auto& car : cars) {
            cout << "ID: " << car.id << ", Brand: " << car.brand << ", Model: " << car.model << endl;
        }
    }
    
    void addCleaner(int id, string name) {
        cleaners.push_back(Cleaner(id, name));
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, string newName) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = newName;
                break;
            }
        }
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;

    system.addCar(1, "Toyota", "Corolla");
    system.addCar(2, "Ford", "Focus");
    system.updateCar(2, "Ford", "Fiesta");
    system.displayCars();
    system.deleteCar(1);
    system.displayCars();

    system.addCleaner(1, "John");
    system.addCleaner(2, "Doe");
    system.updateCleaner(2, "Jane");
    system.displayCleaners();
    system.deleteCleaner(1);
    system.displayCleaners();

    return 0;
}