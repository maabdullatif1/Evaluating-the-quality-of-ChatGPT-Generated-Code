#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    int id;
    string model;
    string color;
};

struct Cleaner {
    int id;
    string name;
    int experience;
};

vector<Car> cars;
vector<Cleaner> cleaners;

void addCar(int id, const string& model, const string& color) {
    cars.push_back({id, model, color});
}

void deleteCar(int id) {
    for (auto it = cars.begin(); it != cars.end(); ++it) {
        if (it->id == id) {
            cars.erase(it);
            return;
        }
    }
}

void updateCar(int id, const string& model, const string& color) {
    for (auto& car : cars) {
        if (car.id == id) {
            car.model = model;
            car.color = color;
            return;
        }
    }
}

Car* searchCar(int id) {
    for (auto& car : cars) {
        if (car.id == id) {
            return &car;
        }
    }
    return nullptr;
}

void displayCars() {
    for (const auto& car : cars) {
        cout << "Car ID: " << car.id << ", Model: " << car.model << ", Color: " << car.color << endl;
    }
}

void addCleaner(int id, const string& name, int experience) {
    cleaners.push_back({id, name, experience});
}

void deleteCleaner(int id) {
    for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
        if (it->id == id) {
            cleaners.erase(it);
            return;
        }
    }
}

void updateCleaner(int id, const string& name, int experience) {
    for (auto& cleaner : cleaners) {
        if (cleaner.id == id) {
            cleaner.name = name;
            cleaner.experience = experience;
            return;
        }
    }
}

Cleaner* searchCleaner(int id) {
    for (auto& cleaner : cleaners) {
        if (cleaner.id == id) {
            return &cleaner;
        }
    }
    return nullptr;
}

void displayCleaners() {
    for (const auto& cleaner : cleaners) {
        cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << ", Experience: " << cleaner.experience << " years" << endl;
    }
}

int main() {
    addCar(1, "Toyota", "Red");
    addCar(2, "Honda", "Blue");
    addCleaner(1, "John", 5);
    addCleaner(2, "Alice", 3);
    updateCar(1, "Toyota", "Green");
    deleteCar(2);
    updateCleaner(1, "John Doe", 6);
    displayCars();
    displayCleaners();
    
    Car* car = searchCar(1);
    if (car != nullptr) {
        cout << "Found Car: ID: " << car->id << ", Model: " << car->model << ", Color: " << car->color << endl;
    }
    
    Cleaner* cleaner = searchCleaner(2);
    if (cleaner != nullptr) {
        cout << "Found Cleaner: ID: " << cleaner->id << ", Name: " << cleaner->name << ", Experience: " << cleaner->experience << " years" << endl;
    }

    return 0;
}