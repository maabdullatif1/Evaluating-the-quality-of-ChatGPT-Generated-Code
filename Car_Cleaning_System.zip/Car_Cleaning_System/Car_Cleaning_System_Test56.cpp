#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string ownerName;
    std::string carModel;
    
    Car(int id, const std::string &ownerName, const std::string &carModel)
        : id(id), ownerName(ownerName), carModel(carModel) {}
};

class Cleaner {
public:
    int id;
    std::string name;
    int experience;
    
    Cleaner(int id, const std::string &name, int experience)
        : id(id), name(name), experience(experience) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(int id, const std::string &ownerName, const std::string &carModel) {
        cars.push_back(Car(id, ownerName, carModel));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, const std::string &ownerName, const std::string &carModel) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.ownerName = ownerName;
                car.carModel = carModel;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "Car ID: " << car.id << ", Owner: " << car.ownerName << ", Model: " << car.carModel << std::endl;
        }
    }

    void addCleaner(int id, const std::string &name, int experience) {
        cleaners.push_back(Cleaner(id, name, experience));
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, const std::string &name, int experience) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                cleaner.experience = experience;
                break;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << ", Experience: " << cleaner.experience << " years" << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    
    system.addCar(1, "John Doe", "Toyota Camry");
    system.addCar(2, "Jane Smith", "Honda Accord");
    system.displayCars();
    
    system.addCleaner(1, "Mike Johnson", 5);
    system.addCleaner(2, "Lucy Brown", 3);
    system.displayCleaners();

    Car* car = system.searchCar(1);
    if (car) {
        std::cout << "Found Car: ID " << car->id << ", Owner " << car->ownerName << ", Model " << car->carModel << std::endl;
    }

    Cleaner* cleaner = system.searchCleaner(2);
    if (cleaner) {
        std::cout << "Found Cleaner: ID " << cleaner->id << ", Name " << cleaner->name << ", Experience " << cleaner->experience << std::endl;
    }

    system.updateCar(2, "Jane Smith", "Honda Civic");
    system.updateCleaner(2, "Lucy Brown", 4);
    
    system.deleteCar(1);
    system.deleteCleaner(1);
    
    system.displayCars();
    system.displayCleaners();
    
    return 0;
}