#include <iostream>
#include <string>

struct Car {
    int id;
    std::string model;
    std::string owner;
};

struct Cleaner {
    int id;
    std::string name;
    int age;
};

struct NodeCar {
    Car car;
    NodeCar* next;
};

struct NodeCleaner {
    Cleaner cleaner;
    NodeCleaner* next;
};

class CarCleaningSystem {
private:
    NodeCar* carHead;
    NodeCleaner* cleanerHead;

    NodeCar* findCarNode(int id) {
        NodeCar* current = carHead;
        while (current) {
            if (current->car.id == id)
                return current;
            current = current->next;
        }
        return nullptr;
    }

    NodeCleaner* findCleanerNode(int id) {
        NodeCleaner* current = cleanerHead;
        while (current) {
            if (current->cleaner.id == id)
                return current;
            current = current->next;
        }
        return nullptr;
    }

public:
    CarCleaningSystem() : carHead(nullptr), cleanerHead(nullptr) {}

    void addCar(int id, const std::string& model, const std::string& owner) {
        NodeCar* newNode = new NodeCar{{id, model, owner}, carHead};
        carHead = newNode;
    }

    void deleteCar(int id) {
        NodeCar *current = carHead, *prev = nullptr;
        while (current) {
            if (current->car.id == id) {
                if (prev)
                    prev->next = current->next;
                else
                    carHead = current->next;
                delete current;
                return;
            }
            prev = current;
            current = current->next;
        }
    }

    void updateCar(int id, const std::string& model, const std::string& owner) {
        NodeCar* carNode = findCarNode(id);
        if (carNode) {
            carNode->car.model = model;
            carNode->car.owner = owner;
        }
    }

    Car* searchCar(int id) {
        NodeCar* carNode = findCarNode(id);
        return carNode ? &carNode->car : nullptr;
    }

    void displayCars() {
        NodeCar* current = carHead;
        while (current) {
            std::cout << "ID: " << current->car.id
                      << ", Model: " << current->car.model
                      << ", Owner: " << current->car.owner << std::endl;
            current = current->next;
        }
    }

    void addCleaner(int id, const std::string& name, int age) {
        NodeCleaner* newNode = new NodeCleaner{{id, name, age}, cleanerHead};
        cleanerHead = newNode;
    }

    void deleteCleaner(int id) {
        NodeCleaner *current = cleanerHead, *prev = nullptr;
        while (current) {
            if (current->cleaner.id == id) {
                if (prev)
                    prev->next = current->next;
                else
                    cleanerHead = current->next;
                delete current;
                return;
            }
            prev = current;
            current = current->next;
        }
    }

    void updateCleaner(int id, const std::string& name, int age) {
        NodeCleaner* cleanerNode = findCleanerNode(id);
        if (cleanerNode) {
            cleanerNode->cleaner.name = name;
            cleanerNode->cleaner.age = age;
        }
    }

    Cleaner* searchCleaner(int id) {
        NodeCleaner* cleanerNode = findCleanerNode(id);
        return cleanerNode ? &cleanerNode->cleaner : nullptr;
    }

    void displayCleaners() {
        NodeCleaner* current = cleanerHead;
        while (current) {
            std::cout << "ID: " << current->cleaner.id
                      << ", Name: " << current->cleaner.name
                      << ", Age: " << current->cleaner.age << std::endl;
            current = current->next;
        }
    }

    ~CarCleaningSystem() {
        while (carHead) {
            NodeCar* temp = carHead;
            carHead = carHead->next;
            delete temp;
        }
        while (cleanerHead) {
            NodeCleaner* temp = cleanerHead;
            cleanerHead = cleanerHead->next;
            delete temp;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Alice");
    system.addCar(2, "Honda", "Bob");
    system.displayCars();
    system.updateCar(1, "Toyota Camry", "Alice Smith");
    system.displayCars();
    system.deleteCar(2);
    system.displayCars();

    system.addCleaner(1, "John Doe", 30);
    system.displayCleaners();
    system.updateCleaner(1, "John Smith", 31);
    system.displayCleaners();
    system.deleteCleaner(1);
    system.displayCleaners();

    return 0;
}