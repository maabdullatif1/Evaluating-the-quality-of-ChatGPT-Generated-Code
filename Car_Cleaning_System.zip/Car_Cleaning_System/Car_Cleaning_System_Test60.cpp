#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    string registrationNumber;
    string model;
    string owner;

    Car(string regNum, string mdl, string own) : registrationNumber(regNum), model(mdl), owner(own) {}
};

class Cleaner {
public:
    string id;
    string name;
    int age;

    Cleaner(string i, string n, int a) : id(i), name(n), age(a) {}
};

class CleaningSystem {
    vector<Car> cars;
    vector<Cleaner> cleaners;

public:
    void addCar(Car car) {
        cars.push_back(car);
    }

    void deleteCar(string regNum) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->registrationNumber == regNum) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(string regNum, string model, string owner) {
        for (auto &car : cars) {
            if (car.registrationNumber == regNum) {
                car.model = model;
                car.owner = owner;
                break;
            }
        }
    }

    Car* searchCar(string regNum) {
        for (auto &car : cars) {
            if (car.registrationNumber == regNum) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "Registration Number: " << car.registrationNumber << ", Model: " << car.model << ", Owner: " << car.owner << endl;
        }
    }

    void addCleaner(Cleaner cleaner) {
        cleaners.push_back(cleaner);
    }

    void deleteCleaner(string id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(string id, string name, int age) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                cleaner.age = age;
                break;
            }
        }
    }

    Cleaner* searchCleaner(string id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << ", Age: " << cleaner.age << endl;
        }
    }
};

int main() {
    CleaningSystem system;

    system.addCar(Car("ABC123", "Toyota", "John Doe"));
    system.addCar(Car("XYZ789", "Honda", "Jane Smith"));

    system.addCleaner(Cleaner("C1", "Mike", 30));
    system.addCleaner(Cleaner("C2", "Sara", 25));

    cout << "Cars:" << endl;
    system.displayCars();
    cout << "Cleaners:" << endl;
    system.displayCleaners();

    Car* car = system.searchCar("ABC123");
    if (car) {
        cout << "Found Car - Registration Number: " << car->registrationNumber << ", Model: " << car->model << ", Owner: " << car->owner << endl;
    }

    Cleaner* cleaner = system.searchCleaner("C1");
    if (cleaner) {
        cout << "Found Cleaner - ID: " << cleaner->id << ", Name: " << cleaner->name << ", Age: " << cleaner->age << endl;
    }

    system.updateCar("XYZ789", "Honda Civic", "Alice Johnson");
    system.updateCleaner("C2", "Sara Lee", 26);

    cout << "Updated Cars:" << endl;
    system.displayCars();
    cout << "Updated Cleaners:" << endl;
    system.displayCleaners();

    system.deleteCar("ABC123");
    system.deleteCleaner("C1");

    cout << "After Deletion:" << endl;
    cout << "Cars:" << endl;
    system.displayCars();
    cout << "Cleaners:" << endl;
    system.displayCleaners();

    return 0;
}