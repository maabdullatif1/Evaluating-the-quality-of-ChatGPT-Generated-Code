#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string plateNumber;
    std::string model;
    std::string ownerName;

    Car(std::string plate, std::string model, std::string owner) 
        : plateNumber(plate), model(model), ownerName(owner) {}
};

class Cleaner {
public:
    int cleanerID;
    std::string cleanerName;

    Cleaner(int id, std::string name) : cleanerID(id), cleanerName(name) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(const std::string &plate, const std::string &model, const std::string &owner) {
        cars.push_back(Car(plate, model, owner));
    }
    
    void deleteCar(const std::string &plate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->plateNumber == plate) {
                cars.erase(it);
                return;
            }
        }
    }

    void updateCar(const std::string &plate, const std::string &model, const std::string &owner) {
        for (auto &car : cars) {
            if (car.plateNumber == plate) {
                car.model = model;
                car.ownerName = owner;
                return;
            }
        }
    }

    void searchCar(const std::string &plate) {
        for (const auto &car : cars) {
            if (car.plateNumber == plate) {
                std::cout << "Car Model: " << car.model << ", Owner: " << car.ownerName << "\n";
                return;
            }
        }
        std::cout << "Car not found.\n";
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "Plate: " << car.plateNumber << ", Model: " << car.model << ", Owner: " << car.ownerName << "\n";
        }
    }

    void addCleaner(int id, const std::string &name) {
        cleaners.push_back(Cleaner(id, name));
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->cleanerID == id) {
                cleaners.erase(it);
                return;
            }
        }
    }

    void updateCleaner(int id, const std::string &name) {
        for (auto &cleaner : cleaners) {
            if (cleaner.cleanerID == id) {
                cleaner.cleanerName = name;
                return;
            }
        }
    }

    void searchCleaner(int id) {
        for (const auto &cleaner : cleaners) {
            if (cleaner.cleanerID == id) {
                std::cout << "Cleaner Name: " << cleaner.cleanerName << "\n";
                return;
            }
        }
        std::cout << "Cleaner not found.\n";
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            std::cout << "Cleaner ID: " << cleaner.cleanerID << ", Name: " << cleaner.cleanerName << "\n";
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("ABC123", "Toyota", "John Doe");
    system.addCleaner(1, "Mike");

    system.displayCars();
    system.displayCleaners();

    system.updateCar("ABC123", "Honda", "Jane Doe");
    system.updateCleaner(1, "Michael");

    system.searchCar("ABC123");
    system.searchCleaner(1);
    
    system.deleteCar("ABC123");
    system.deleteCleaner(1);

    system.displayCars();
    system.displayCleaners();

    return 0;
}