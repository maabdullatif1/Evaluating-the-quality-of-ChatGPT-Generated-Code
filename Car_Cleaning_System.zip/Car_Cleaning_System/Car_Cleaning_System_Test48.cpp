#include <iostream>
#include <string>

using namespace std;

#define MAX 100

struct Car {
    int id;
    string model;
    string owner;
};

struct Cleaner {
    int id;
    string name;
    int experience;
};

Car cars[MAX];
Cleaner cleaners[MAX];
int carCount = 0;
int cleanerCount = 0;

void addCar() {
    if (carCount < MAX) {
        cout << "Enter Car ID: ";
        cin >> cars[carCount].id;
        cout << "Enter Car Model: ";
        cin >> cars[carCount].model;
        cout << "Enter Car Owner: ";
        cin >> cars[carCount].owner;
        carCount++;
    } else {
        cout << "Car list is full.\n";
    }
}

void addCleaner() {
    if (cleanerCount < MAX) {
        cout << "Enter Cleaner ID: ";
        cin >> cleaners[cleanerCount].id;
        cout << "Enter Cleaner Name: ";
        cin >> cleaners[cleanerCount].name;
        cout << "Enter Cleaner Experience: ";
        cin >> cleaners[cleanerCount].experience;
        cleanerCount++;
    } else {
        cout << "Cleaner list is full.\n";
    }
}

void deleteCar() {
    int id;
    cout << "Enter Car ID to delete: ";
    cin >> id;
    bool found = false;
    for (int i = 0; i < carCount; i++) {
        if (cars[i].id == id) {
            for (int j = i; j < carCount - 1; j++) {
                cars[j] = cars[j + 1];
            }
            carCount--;
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "Car not found.\n";
    }
}

void deleteCleaner() {
    int id;
    cout << "Enter Cleaner ID to delete: ";
    cin >> id;
    bool found = false;
    for (int i = 0; i < cleanerCount; i++) {
        if (cleaners[i].id == id) {
            for (int j = i; j < cleanerCount - 1; j++) {
                cleaners[j] = cleaners[j + 1];
            }
            cleanerCount--;
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "Cleaner not found.\n";
    }
}

void updateCar() {
    int id;
    cout << "Enter Car ID to update: ";
    cin >> id;
    for (int i = 0; i < carCount; i++) {
        if (cars[i].id == id) {
            cout << "Enter new Car Model: ";
            cin >> cars[i].model;
            cout << "Enter new Car Owner: ";
            cin >> cars[i].owner;
            return;
        }
    }
    cout << "Car not found.\n";
}

void updateCleaner() {
    int id;
    cout << "Enter Cleaner ID to update: ";
    cin >> id;
    for (int i = 0; i < cleanerCount; i++) {
        if (cleaners[i].id == id) {
            cout << "Enter new Cleaner Name: ";
            cin >> cleaners[i].name;
            cout << "Enter new Cleaner Experience: ";
            cin >> cleaners[i].experience;
            return;
        }
    }
    cout << "Cleaner not found.\n";
}

void searchCar() {
    int id;
    cout << "Enter Car ID to search: ";
    cin >> id;
    for (int i = 0; i < carCount; i++) {
        if (cars[i].id == id) {
            cout << "Car ID: " << cars[i].id << ", Model: " << cars[i].model << ", Owner: " << cars[i].owner << "\n";
            return;
        }
    }
    cout << "Car not found.\n";
}

void searchCleaner() {
    int id;
    cout << "Enter Cleaner ID to search: ";
    cin >> id;
    for (int i = 0; i < cleanerCount; i++) {
        if (cleaners[i].id == id) {
            cout << "Cleaner ID: " << cleaners[i].id << ", Name: " << cleaners[i].name << ", Experience: " << cleaners[i].experience << "\n";
            return;
        }
    }
    cout << "Cleaner not found.\n";
}

void displayCars() {
    for (int i = 0; i < carCount; i++) {
        cout << "Car ID: " << cars[i].id << ", Model: " << cars[i].model << ", Owner: " << cars[i].owner << "\n";
    }
}

void displayCleaners() {
    for (int i = 0; i < cleanerCount; i++) {
        cout << "Cleaner ID: " << cleaners[i].id << ", Name: " << cleaners[i].name << ", Experience: " << cleaners[i].experience << "\n";
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Car\n2. Add Cleaner\n3. Delete Car\n4. Delete Cleaner\n5. Update Car\n6. Update Cleaner\n7. Search Car\n8. Search Cleaner\n9. Display Cars\n10. Display Cleaners\n11. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addCar(); break;
            case 2: addCleaner(); break;
            case 3: deleteCar(); break;
            case 4: deleteCleaner(); break;
            case 5: updateCar(); break;
            case 6: updateCleaner(); break;
            case 7: searchCar(); break;
            case 8: searchCleaner(); break;
            case 9: displayCars(); break;
            case 10: displayCleaners(); break;
            case 11: return 0;
            default: cout << "Invalid choice.\n";
        }
    }
}