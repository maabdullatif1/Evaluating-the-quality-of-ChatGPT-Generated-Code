#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    int id;
    string model;
    string owner;
};

struct Cleaner {
    int id;
    string name;
    string experience;
};

class CleaningSystem {
private:
    vector<Car> cars;
    vector<Cleaner> cleaners;

    int findCar(int id) {
        for (size_t i = 0; i < cars.size(); ++i) {
            if (cars[i].id == id)
                return i;
        }
        return -1;
    }

    int findCleaner(int id) {
        for (size_t i = 0; i < cleaners.size(); ++i) {
            if (cleaners[i].id == id)
                return i;
        }
        return -1;
    }

public:
    void addCar(int id, const string& model, const string& owner) {
        Car car = {id, model, owner};
        cars.push_back(car);
    }

    void deleteCar(int id) {
        int index = findCar(id);
        if (index != -1) {
            cars.erase(cars.begin() + index);
        }
    }

    void updateCar(int id, const string& model, const string& owner) {
        int index = findCar(id);
        if (index != -1) {
            cars[index].model = model;
            cars[index].owner = owner;
        }
    }

    void searchCar(int id) {
        int index = findCar(id);
        if (index != -1) {
            cout << "Car ID: " << cars[index].id 
                 << ", Model: " << cars[index].model 
                 << ", Owner: " << cars[index].owner << endl;
        } else {
            cout << "Car not found" << endl;
        }
    }

    void displayCars() {
        for (const auto& car : cars) {
            cout << "Car ID: " << car.id 
                 << ", Model: " << car.model 
                 << ", Owner: " << car.owner << endl;
        }
    }

    void addCleaner(int id, const string& name, const string& experience) {
        Cleaner cleaner = {id, name, experience};
        cleaners.push_back(cleaner);
    }

    void deleteCleaner(int id) {
        int index = findCleaner(id);
        if (index != -1) {
            cleaners.erase(cleaners.begin() + index);
        }
    }

    void updateCleaner(int id, const string& name, const string& experience) {
        int index = findCleaner(id);
        if (index != -1) {
            cleaners[index].name = name;
            cleaners[index].experience = experience;
        }
    }

    void searchCleaner(int id) {
        int index = findCleaner(id);
        if (index != -1) {
            cout << "Cleaner ID: " << cleaners[index].id 
                 << ", Name: " << cleaners[index].name 
                 << ", Experience: " << cleaners[index].experience << endl;
        } else {
            cout << "Cleaner not found" << endl;
        }
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            cout << "Cleaner ID: " << cleaner.id 
                 << ", Name: " << cleaner.name 
                 << ", Experience: " << cleaner.experience << endl;
        }
    }
};

int main() {
    CleaningSystem system;
    
    system.addCar(1, "Toyota", "John Doe");
    system.addCar(2, "Honda", "Jane Smith");

    system.displayCars();

    system.addCleaner(1, "Mike", "5 years");
    system.addCleaner(2, "Sara", "2 years");

    system.displayCleaners();

    system.searchCar(1);
    system.searchCleaner(2);

    system.updateCar(1, "Ford", "Alice Doe");
    system.updateCleaner(1, "Michael", "6 years");

    system.displayCars();
    system.displayCleaners();

    system.deleteCar(2);
    system.deleteCleaner(2);

    system.displayCars();
    system.displayCleaners();

    return 0;
}