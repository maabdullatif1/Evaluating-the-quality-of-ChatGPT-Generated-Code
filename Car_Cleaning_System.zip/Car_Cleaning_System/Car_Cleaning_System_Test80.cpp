#include <iostream>
#include <string>
#include <vector>

struct Car {
    int id;
    std::string model;
    std::string owner;
};

struct Cleaner {
    int id;
    std::string name;
};

std::vector<Car> cars;
std::vector<Cleaner> cleaners;

void addCar() {
    Car car;
    std::cout << "Enter car ID: ";
    std::cin >> car.id;
    std::cout << "Enter car model: ";
    std::cin >> car.model;
    std::cout << "Enter car owner: ";
    std::cin >> car.owner;
    cars.push_back(car);
}

void deleteCar() {
    int id;
    std::cout << "Enter car ID to delete: ";
    std::cin >> id;
    for (auto it = cars.begin(); it != cars.end(); ++it) {
        if (it->id == id) {
            cars.erase(it);
            break;
        }
    }
}

void updateCar() {
    int id;
    std::cout << "Enter car ID to update: ";
    std::cin >> id;
    for (auto &car : cars) {
        if (car.id == id) {
            std::cout << "Enter new car model: ";
            std::cin >> car.model;
            std::cout << "Enter new car owner: ";
            std::cin >> car.owner;
            break;
        }
    }
}

void searchCar() {
    int id;
    std::cout << "Enter car ID to search: ";
    std::cin >> id;
    for (auto &car : cars) {
        if (car.id == id) {
            std::cout << "Car ID: " << car.id 
                      << ", Model: " << car.model 
                      << ", Owner: " << car.owner << std::endl;
            return;
        }
    }
    std::cout << "Car not found.\n";
}

void displayCars() {
    for (auto &car : cars) {
        std::cout << "Car ID: " << car.id 
                  << ", Model: " << car.model 
                  << ", Owner: " << car.owner << std::endl;
    }
}

void addCleaner() {
    Cleaner cleaner;
    std::cout << "Enter cleaner ID: ";
    std::cin >> cleaner.id;
    std::cout << "Enter cleaner name: ";
    std::cin >> cleaner.name;
    cleaners.push_back(cleaner);
}

void deleteCleaner() {
    int id;
    std::cout << "Enter cleaner ID to delete: ";
    std::cin >> id;
    for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
        if (it->id == id) {
            cleaners.erase(it);
            break;
        }
    }
}

void updateCleaner() {
    int id;
    std::cout << "Enter cleaner ID to update: ";
    std::cin >> id;
    for (auto &cleaner : cleaners) {
        if (cleaner.id == id) {
            std::cout << "Enter new cleaner name: ";
            std::cin >> cleaner.name;
            break;
        }
    }
}

void searchCleaner() {
    int id;
    std::cout << "Enter cleaner ID to search: ";
    std::cin >> id;
    for (auto &cleaner : cleaners) {
        if (cleaner.id == id) {
            std::cout << "Cleaner ID: " << cleaner.id 
                      << ", Name: " << cleaner.name << std::endl;
            return;
        }
    }
    std::cout << "Cleaner not found.\n";
}

void displayCleaners() {
    for (auto &cleaner : cleaners) {
        std::cout << "Cleaner ID: " << cleaner.id 
                  << ", Name: " << cleaner.name << std::endl;
    }
}

int main() {
    int choice;
    while (true) {
        std::cout << "1. Add Car\n2. Delete Car\n3. Update Car\n4. Search Car\n5. Display Cars\n"
                  << "6. Add Cleaner\n7. Delete Cleaner\n8. Update Cleaner\n9. Search Cleaner\n10. Display Cleaners\n11. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1: addCar(); break;
            case 2: deleteCar(); break;
            case 3: updateCar(); break;
            case 4: searchCar(); break;
            case 5: displayCars(); break;
            case 6: addCleaner(); break;
            case 7: deleteCleaner(); break;
            case 8: updateCleaner(); break;
            case 9: searchCleaner(); break;
            case 10: displayCleaners(); break;
            case 11: return 0;
            default: std::cout << "Invalid choice.\n"; break;
        }
    }
}