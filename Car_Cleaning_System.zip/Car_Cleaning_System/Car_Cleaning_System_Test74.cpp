#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string model;
    std::string owner;
    Car(int i, std::string m, std::string o) : id(i), model(m), owner(o) {}
};

class Cleaner {
public:
    int id;
    std::string name;
    Cleaner(int i, std::string n) : id(i), name(n) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;
    
    int findCarById(int id) {
        for (size_t i = 0; i < cars.size(); ++i)
            if (cars[i].id == id) return i;
        return -1;
    }
    
    int findCleanerById(int id) {
        for (size_t i = 0; i < cleaners.size(); ++i)
            if (cleaners[i].id == id) return i;
        return -1;
    }

public:
    void addCar(int id, std::string model, std::string owner) {
        if (findCarById(id) == -1)
            cars.push_back(Car(id, model, owner));
    }
    
    void deleteCar(int id) {
        int index = findCarById(id);
        if (index != -1)
            cars.erase(cars.begin() + index);
    }
    
    void updateCar(int id, std::string model, std::string owner) {
        int index = findCarById(id);
        if (index != -1) {
            cars[index].model = model;
            cars[index].owner = owner;
        }
    }
    
    void searchCar(int id) {
        int index = findCarById(id);
        if (index != -1)
            std::cout << "Car ID: " << cars[index].id << ", Model: " << cars[index].model 
                      << ", Owner: " << cars[index].owner << std::endl;
    }
    
    void displayCars() {
        for (const auto& car : cars)
            std::cout << "Car ID: " << car.id << ", Model: " << car.model 
                      << ", Owner: " << car.owner << std::endl;
    }
    
    void addCleaner(int id, std::string name) {
        if (findCleanerById(id) == -1)
            cleaners.push_back(Cleaner(id, name));
    }
    
    void deleteCleaner(int id) {
        int index = findCleanerById(id);
        if (index != -1)
            cleaners.erase(cleaners.begin() + index);
    }
    
    void updateCleaner(int id, std::string name) {
        int index = findCleanerById(id);
        if (index != -1)
            cleaners[index].name = name;
    }
    
    void searchCleaner(int id) {
        int index = findCleanerById(id);
        if (index != -1)
            std::cout << "Cleaner ID: " << cleaners[index].id << ", Name: " << cleaners[index].name << std::endl;
    }
    
    void displayCleaners() {
        for (const auto& cleaner : cleaners)
            std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << std::endl;
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Tesla Model S", "John Doe");
    system.addCleaner(1, "Alice");
    system.searchCar(1);
    system.searchCleaner(1);
    system.updateCar(1, "Tesla Model 3", "John Doe");
    system.updateCleaner(1, "Alice Smith");
    system.displayCars();
    system.displayCleaners();
    system.deleteCar(1);
    system.deleteCleaner(1);
    system.displayCars();
    system.displayCleaners();
    return 0;
}