#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string model;
    string owner;
    
    Car(int i, string m, string o) : id(i), model(m), owner(o) {}
};

class Cleaner {
public:
    int id;
    string name;
    
    Cleaner(int i, string n) : id(i), name(n) {}
};

class CleaningSystem {
private:
    vector<Car> cars;
    vector<Cleaner> cleaners;

public:
    void addCar(int id, string model, string owner) {
        cars.push_back(Car(id, model, owner));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string model, string owner) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.model = model;
                car.owner = owner;
                break;
            }
        }
    }

    void searchCar(int id) {
        for (const auto &car : cars) {
            if (car.id == id) {
                cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << endl;
                return;
            }
        }
        cout << "Car not found" << endl;
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << endl;
        }
    }

    void addCleaner(int id, string name) {
        cleaners.push_back(Cleaner(id, name));
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, string name) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                break;
            }
        }
    }

    void searchCleaner(int id) {
        for (const auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << endl;
                return;
            }
        }
        cout << "Cleaner not found" << endl;
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << endl;
        }
    }
};

int main() {
    CleaningSystem system;

    system.addCar(1, "Toyota", "Alice");
    system.addCar(2, "Honda", "Bob");
    system.displayCars();

    system.addCleaner(1, "John");
    system.addCleaner(2, "Mark");
    system.displayCleaners();

    system.updateCar(1, "Ford", "Charlie");
    system.searchCar(1);
    system.deleteCar(2);
    system.displayCars();

    system.updateCleaner(1, "Tom");
    system.searchCleaner(1);
    system.deleteCleaner(2);
    system.displayCleaners();

    return 0;
}