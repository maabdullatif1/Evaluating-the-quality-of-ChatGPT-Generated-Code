#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string model;
    std::string color;

    Car(int id, std::string model, std::string color) : id(id), model(model), color(color) {}
};

class Cleaner {
public:
    int id;
    std::string name;
    int experience;

    Cleaner(int id, std::string name, int experience) : id(id), name(name), experience(experience) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

    template <typename T>
    T* findItemById(std::vector<T>& list, int id) {
        for(auto& item : list) {
            if(item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

public:
    void addCar(int id, std::string model, std::string color) {
        cars.emplace_back(id, model, color);
    }

    void deleteCar(int id) {
        for(auto it = cars.begin(); it != cars.end(); ++it) {
            if(it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, std::string newModel, std::string newColor) {
        Car* car = findItemById(cars, id);
        if(car) {
            car->model = newModel;
            car->color = newColor;
        }
    }

    void searchCar(int id) {
        Car* car = findItemById(cars, id);
        if(car) {
            std::cout << "Car ID: " << car->id << ", Model: " << car->model << ", Color: " << car->color << "\n";
        } else {
            std::cout << "Car not found\n";
        }
    }

    void displayCars() {
        for(const auto& car : cars) {
            std::cout << "Car ID: " << car.id << ", Model: " << car.model << ", Color: " << car.color << "\n";
        }
    }

    void addCleaner(int id, std::string name, int experience) {
        cleaners.emplace_back(id, name, experience);
    }

    void deleteCleaner(int id) {
        for(auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if(it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, std::string newName, int newExperience) {
        Cleaner* cleaner = findItemById(cleaners, id);
        if(cleaner) {
            cleaner->name = newName;
            cleaner->experience = newExperience;
        }
    }

    void searchCleaner(int id) {
        Cleaner* cleaner = findItemById(cleaners, id);
        if(cleaner) {
            std::cout << "Cleaner ID: " << cleaner->id << ", Name: " << cleaner->name << ", Experience: " << cleaner->experience << " years\n";
        } else {
            std::cout << "Cleaner not found\n";
        }
    }

    void displayCleaners() {
        for(const auto& cleaner : cleaners) {
            std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << ", Experience: " << cleaner.experience << " years\n";
        }
    }
};

int main() {
    CarCleaningSystem system;

    system.addCar(1, "Toyota", "Red");
    system.addCar(2, "Ford", "Blue");
    system.addCleaner(1, "John", 5);
    system.addCleaner(2, "Jane", 3);

    std::cout << "Displaying Cars:\n";
    system.displayCars();

    std::cout << "\nDisplaying Cleaners:\n";
    system.displayCleaners();
    
    std::cout << "\nSearching for Car ID 1:\n";
    system.searchCar(1);

    std::cout << "\nSearching for Cleaner ID 2:\n";
    system.searchCleaner(2);

    std::cout << "\nUpdating Car ID 2:\n";
    system.updateCar(2, "Honda", "Green");

    std::cout << "\nDeleting Cleaner ID 1:\n";
    system.deleteCleaner(1);

    std::cout << "\nDisplaying Cars After Update:\n";
    system.displayCars();

    std::cout << "\nDisplaying Cleaners After Deletion:\n";
    system.displayCleaners();

    return 0;
}