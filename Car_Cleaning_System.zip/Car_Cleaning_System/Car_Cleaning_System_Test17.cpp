#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string make;
    std::string model;
    Car(int i, std::string m, std::string mo) : id(i), make(m), model(mo) {}
};

class Cleaner {
public:
    int id;
    std::string name;
    Cleaner(int i, std::string n) : id(i), name(n) {}
};

class CarCleanSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(int id, std::string make, std::string model) {
        cars.push_back(Car(id, make, model));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, std::string make, std::string model) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Car ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << std::endl;
        }
    }

    void addCleaner(int id, std::string name) {
        cleaners.push_back(Cleaner(id, name));
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, std::string name) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << std::endl;
        }
    }
};

int main() {
    CarCleanSystem system;
    system.addCar(1, "Toyota", "Camry");
    system.addCar(2, "Honda", "Civic");
    system.displayCars();
    system.updateCar(1, "Toyota", "Corolla");
    system.displayCars();
    system.deleteCar(2);
    system.displayCars();
    system.addCleaner(1, "John");
    system.addCleaner(2, "Jane");
    system.displayCleaners();
    system.updateCleaner(1, "Johnny");
    system.displayCleaners();
    system.deleteCleaner(2);
    system.displayCleaners();
    return 0;
}