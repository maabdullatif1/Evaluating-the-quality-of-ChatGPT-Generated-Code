#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string model;
    string owner;

    Car(int id, string model, string owner) : id(id), model(model), owner(owner) {}
};

class Cleaner {
public:
    int id;
    string name;
    int experience;

    Cleaner(int id, string name, int experience) : id(id), name(name), experience(experience) {}
};

class CarCleaningSystem {
    vector<Car> cars;
    vector<Cleaner> cleaners;

    int findCarIndex(int id) {
        for (size_t i = 0; i < cars.size(); ++i) {
            if (cars[i].id == id) return i;
        }
        return -1;
    }

    int findCleanerIndex(int id) {
        for (size_t i = 0; i < cleaners.size(); ++i) {
            if (cleaners[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCar(int id, string model, string owner) {
        cars.emplace_back(id, model, owner);
    }

    void addCleaner(int id, string name, int experience) {
        cleaners.emplace_back(id, name, experience);
    }

    void deleteCar(int id) {
        int index = findCarIndex(id);
        if (index != -1) cars.erase(cars.begin() + index);
    }

    void deleteCleaner(int id) {
        int index = findCleanerIndex(id);
        if (index != -1) cleaners.erase(cleaners.begin() + index);
    }

    void updateCar(int id, string model, string owner) {
        int index = findCarIndex(id);
        if (index != -1) {
            cars[index].model = model;
            cars[index].owner = owner;
        }
    }

    void updateCleaner(int id, string name, int experience) {
        int index = findCleanerIndex(id);
        if (index != -1) {
            cleaners[index].name = name;
            cleaners[index].experience = experience;
        }
    }

    Car* searchCar(int id) {
        int index = findCarIndex(id);
        if (index != -1) return &cars[index];
        return nullptr;
    }

    Cleaner* searchCleaner(int id) {
        int index = findCleanerIndex(id);
        if (index != -1) return &cleaners[index];
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            cout << "ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << endl;
        }
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << ", Experience: " << cleaner.experience << " years" << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Alice");
    system.addCleaner(1, "Bob", 5);
    system.displayCars();
    system.displayCleaners();
    return 0;
}