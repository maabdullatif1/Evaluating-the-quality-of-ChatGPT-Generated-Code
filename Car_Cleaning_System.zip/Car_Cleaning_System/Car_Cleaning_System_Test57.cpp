#include <iostream>
#include <vector>
#include <string>

struct Car {
    int id;
    std::string model;
    std::string plateNumber;
};

struct Cleaner {
    int id;
    std::string name;
    int age;
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

    int findCarIndex(int carId) {
        for (size_t i = 0; i < cars.size(); ++i) {
            if (cars[i].id == carId) return i;
        }
        return -1;
    }

    int findCleanerIndex(int cleanerId) {
        for (size_t i = 0; i < cleaners.size(); ++i) {
            if (cleaners[i].id == cleanerId) return i;
        }
        return -1;
    }

public:
    void addCar(int id, const std::string &model, const std::string &plateNumber) {
        cars.push_back({id, model, plateNumber});
    }
    
    void deleteCar(int id) {
        int index = findCarIndex(id);
        if (index != -1) cars.erase(cars.begin() + index);
    }
    
    void updateCar(int id, const std::string &newModel, const std::string &newPlateNumber) {
        int index = findCarIndex(id);
        if (index != -1) {
            cars[index].model = newModel;
            cars[index].plateNumber = newPlateNumber;
        }
    }
    
    void searchCar(int id) {
        int index = findCarIndex(id);
        if (index != -1) {
            std::cout << "Car found: " << cars[index].id << ", " << cars[index].model << ", " << cars[index].plateNumber << std::endl;
        } else {
            std::cout << "Car not found" << std::endl;
        }
    }
    
    void displayCars() {
        for (const auto &car : cars) {
            std::cout << car.id << ", " << car.model << ", " << car.plateNumber << std::endl;
        }
    }
    
    void addCleaner(int id, const std::string &name, int age) {
        cleaners.push_back({id, name, age});
    }
    
    void deleteCleaner(int id) {
        int index = findCleanerIndex(id);
        if (index != -1) cleaners.erase(cleaners.begin() + index);
    }
    
    void updateCleaner(int id, const std::string &newName, int newAge) {
        int index = findCleanerIndex(id);
        if (index != -1) {
            cleaners[index].name = newName;
            cleaners[index].age = newAge;
        }
    }
    
    void searchCleaner(int id) {
        int index = findCleanerIndex(id);
        if (index != -1) {
            std::cout << "Cleaner found: " << cleaners[index].id << ", " << cleaners[index].name << ", " << cleaners[index].age << std::endl;
        } else {
            std::cout << "Cleaner not found" << std::endl;
        }
    }
    
    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            std::cout << cleaner.id << ", " << cleaner.name << ", " << cleaner.age << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "ABC123");
    system.addCar(2, "Honda", "XYZ789");
    system.displayCars();

    system.addCleaner(1, "John Doe", 30);
    system.addCleaner(2, "Jane Smith", 25);
    system.displayCleaners();

    system.searchCar(1);
    system.searchCleaner(2);

    system.updateCar(1, "Toyota Updated", "NEW123");
    system.updateCleaner(1, "John Updated", 31);
    system.displayCars();
    system.displayCleaners();

    system.deleteCar(2);
    system.deleteCleaner(2);
    system.displayCars();
    system.displayCleaners();

    return 0;
}