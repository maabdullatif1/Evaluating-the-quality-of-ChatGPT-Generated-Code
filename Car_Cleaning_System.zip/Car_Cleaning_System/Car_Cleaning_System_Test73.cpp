#include <iostream>
#include <vector>
#include <string>

struct Car {
    int id;
    std::string make;
    std::string model;
    int year;
};

struct Cleaner {
    int id;
    std::string name;
    int experienceYears;
};

class CarCleaningSystem {
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

    int generateCarId() {
        return cars.empty() ? 1 : cars.back().id + 1;
    }

    int generateCleanerId() {
        return cleaners.empty() ? 1 : cleaners.back().id + 1;
    }

public:
    void addCar(const std::string &make, const std::string &model, int year) {
        cars.push_back({generateCarId(), make, model, year});
    }

    void addCleaner(const std::string &name, int experienceYears) {
        cleaners.push_back({generateCleanerId(), name, experienceYears});
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, const std::string &make, const std::string &model, int year) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.year = year;
                break;
            }
        }
    }

    void updateCleaner(int id, const std::string &name, int experienceYears) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                cleaner.experienceYears = experienceYears;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    Cleaner* searchCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << ", Year: " << car.year << "\n";
        }
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            std::cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << ", Experience: " << cleaner.experienceYears << " years\n";
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("Toyota", "Camry", 2020);
    system.addCar("Honda", "Civic", 2018);
    system.addCleaner("John Doe", 5);
    system.addCleaner("Jane Smith", 3);
    
    std::cout << "Cars:\n";
    system.displayCars();
    
    std::cout << "\nCleaners:\n";
    system.displayCleaners();
    
    system.updateCar(1, "Toyota", "Corolla", 2021);
    system.updateCleaner(2, "Jane Doe", 4);

    std::cout << "\nUpdated Cars:\n";
    system.displayCars();
    
    std::cout << "\nUpdated Cleaners:\n";
    system.displayCleaners();

    system.deleteCar(2);
    system.deleteCleaner(1);

    std::cout << "\nAfter Deletion - Cars:\n";
    system.displayCars();
    
    std::cout << "\nAfter Deletion - Cleaners:\n";
    system.displayCleaners();
    
    return 0;
}