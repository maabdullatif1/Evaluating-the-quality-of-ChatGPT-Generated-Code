#include <iostream>
#include <string>
using namespace std;

struct Car {
    int id;
    string model;
    string owner;
    Car* next;
};

struct Cleaner {
    int id;
    string name;
    Cleaner* next;
};

class CarCleaningSystem {
    Car* carHead;
    Cleaner* cleanerHead;
    int carCount;
    int cleanerCount;

public:
    CarCleaningSystem() : carHead(nullptr), cleanerHead(nullptr), carCount(0), cleanerCount(0) {}

    void addCar(int id, const string& model, const string& owner) {
        Car* newCar = new Car{id, model, owner, carHead};
        carHead = newCar;
        carCount++;
    }

    void deleteCar(int id) {
        Car* current = carHead;
        Car* prev = nullptr;
        while (current && current->id != id) {
            prev = current;
            current = current->next;
        }
        if (current) {
            if (prev) {
                prev->next = current->next;
            } else {
                carHead = current->next;
            }
            delete current;
            carCount--;
        }
    }

    void updateCar(int id, const string& newModel, const string& newOwner) {
        Car* current = carHead;
        while (current && current->id != id) {
            current = current->next;
        }
        if (current) {
            current->model = newModel;
            current->owner = newOwner;
        }
    }

    Car* searchCar(int id) {
        Car* current = carHead;
        while (current && current->id != id) {
            current = current->next;
        }
        return current;
    }

    void addCleaner(int id, const string& name) {
        Cleaner* newCleaner = new Cleaner{id, name, cleanerHead};
        cleanerHead = newCleaner;
        cleanerCount++;
    }

    void deleteCleaner(int id) {
        Cleaner* current = cleanerHead;
        Cleaner* prev = nullptr;
        while (current && current->id != id) {
            prev = current;
            current = current->next;
        }
        if (current) {
            if (prev) {
                prev->next = current->next;
            } else {
                cleanerHead = current->next;
            }
            delete current;
            cleanerCount--;
        }
    }

    void updateCleaner(int id, const string& newName) {
        Cleaner* current = cleanerHead;
        while (current && current->id != id) {
            current = current->next;
        }
        if (current) {
            current->name = newName;
        }
    }

    Cleaner* searchCleaner(int id) {
        Cleaner* current = cleanerHead;
        while (current && current->id != id) {
            current = current->next;
        }
        return current;
    }

    void displayCars() {
        Car* current = carHead;
        while (current) {
            cout << "Car ID: " << current->id << ", Model: " << current->model << ", Owner: " << current->owner << endl;
            current = current->next;
        }
    }

    void displayCleaners() {
        Cleaner* current = cleanerHead;
        while (current) {
            cout << "Cleaner ID: " << current->id << ", Name: " << current->name << endl;
            current = current->next;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Alice");
    system.addCar(2, "Honda", "Bob");
    system.addCleaner(1, "Charlie");
    system.addCleaner(2, "Dave");

    system.displayCars();
    system.displayCleaners();

    system.updateCar(1, "Toyota Corolla", "Alice Updated");
    system.updateCleaner(2, "Dave Updated");

    system.displayCars();
    system.displayCleaners();

    system.deleteCar(2);
    system.deleteCleaner(1);

    system.displayCars();
    system.displayCleaners();

    Car* car = system.searchCar(1);
    if (car) {
        cout << "Found Car ID: " << car->id << ", Model: " << car->model << ", Owner: " << car->owner << endl;
    }

    Cleaner* cleaner = system.searchCleaner(2);
    if (cleaner) {
        cout << "Found Cleaner ID: " << cleaner->id << ", Name: " << cleaner->name << endl;
    }

    return 0;
}