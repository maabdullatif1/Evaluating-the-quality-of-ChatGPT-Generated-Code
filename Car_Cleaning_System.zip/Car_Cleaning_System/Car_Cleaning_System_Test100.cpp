#include <iostream>
#include <string>

using namespace std;

struct Car {
    int id;
    string model;
    string owner;
};

struct Cleaner {
    int id;
    string name;
    string phone;
};

class CarCleaningSystem {
    Car cars[100];
    Cleaner cleaners[100];
    int carCount;
    int cleanerCount;

public:
    CarCleaningSystem() : carCount(0), cleanerCount(0) {}

    void addCar(int id, const string& model, const string& owner) {
        cars[carCount++] = {id, model, owner};
    }

    void deleteCar(int id) {
        for (int i = 0; i < carCount; ++i) {
            if (cars[i].id == id) {
                for (int j = i; j < carCount - 1; ++j) {
                    cars[j] = cars[j + 1];
                }
                carCount--;
                break;
            }
        }
    }

    void updateCar(int id, const string& model, const string& owner) {
        for (int i = 0; i < carCount; ++i) {
            if (cars[i].id == id) {
                cars[i].model = model;
                cars[i].owner = owner;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (int i = 0; i < carCount; ++i) {
            if (cars[i].id == id) {
                return &cars[i];
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (int i = 0; i < carCount; ++i) {
            cout << "Car ID: " << cars[i].id << " Model: " << cars[i].model << " Owner: " << cars[i].owner << endl;
        }
    }

    void addCleaner(int id, const string& name, const string& phone) {
        cleaners[cleanerCount++] = {id, name, phone};
    }

    void deleteCleaner(int id) {
        for (int i = 0; i < cleanerCount; ++i) {
            if (cleaners[i].id == id) {
                for (int j = i; j < cleanerCount - 1; ++j) {
                    cleaners[j] = cleaners[j + 1];
                }
                cleanerCount--;
                break;
            }
        }
    }

    void updateCleaner(int id, const string& name, const string& phone) {
        for (int i = 0; i < cleanerCount; ++i) {
            if (cleaners[i].id == id) {
                cleaners[i].name = name;
                cleaners[i].phone = phone;
                break;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for (int i = 0; i < cleanerCount; ++i) {
            if (cleaners[i].id == id) {
                return &cleaners[i];
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (int i = 0; i < cleanerCount; ++i) {
            cout << "Cleaner ID: " << cleaners[i].id << " Name: " << cleaners[i].name << " Phone: " << cleaners[i].phone << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota Corolla", "John Doe");
    system.addCleaner(1, "Jane Smith", "555-1234");
    system.displayCars();
    system.displayCleaners();
    return 0;
}