#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string make;
    string model;
    string owner;

    Car(int id, string make, string model, string owner)
        : id(id), make(make), model(model), owner(owner) {}
};

class Cleaner {
public:
    int id;
    string name;
    int experience;

    Cleaner(int id, string name, int experience)
        : id(id), name(name), experience(experience) {}
};

class CarCleaningSystem {
private:
    vector<Car> cars;
    vector<Cleaner> cleaners;

    Car* findCarById(int id) {
        for (auto& car : cars)
            if (car.id == id)
                return &car;
        return nullptr;
    }

    Cleaner* findCleanerById(int id) {
        for (auto& cleaner : cleaners)
            if (cleaner.id == id)
                return &cleaner;
        return nullptr;
    }

public:
    void addCar(int id, string make, string model, string owner) {
        cars.emplace_back(id, make, model, owner);
    }

    void addCleaner(int id, string name, int experience) {
        cleaners.emplace_back(id, name, experience);
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string make, string model, string owner) {
        Car* car = findCarById(id);
        if (car) {
            car->make = make;
            car->model = model;
            car->owner = owner;
        }
    }

    void updateCleaner(int id, string name, int experience) {
        Cleaner* cleaner = findCleanerById(id);
        if (cleaner) {
            cleaner->name = name;
            cleaner->experience = experience;
        }
    }

    void searchCar(int id) {
        Car* car = findCarById(id);
        if (car) {
            cout << "Car Found: ID: " << car->id << ", Make: " << car->make
                 << ", Model: " << car->model << ", Owner: " << car->owner << endl;
        } else {
            cout << "Car Not Found" << endl;
        }
    }

    void searchCleaner(int id) {
        Cleaner* cleaner = findCleanerById(id);
        if (cleaner) {
            cout << "Cleaner Found: ID: " << cleaner->id << ", Name: " << cleaner->name
                 << ", Experience: " << cleaner->experience << " years" << endl;
        } else {
            cout << "Cleaner Not Found" << endl;
        }
    }

    void displayCars() {
        cout << "Cars Information:" << endl;
        for (const auto& car : cars) {
            cout << "ID: " << car.id << ", Make: " << car.make
                 << ", Model: " << car.model << ", Owner: " << car.owner << endl;
        }
    }

    void displayCleaners() {
        cout << "Cleaners Information:" << endl;
        for (const auto& cleaner : cleaners) {
            cout << "ID: " << cleaner.id << ", Name: " << cleaner.name
                 << ", Experience: " << cleaner.experience << " years" << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Corolla", "John Doe");
    system.addCleaner(1, "Alice", 5);
    system.displayCars();
    system.displayCleaners();
    system.searchCar(1);
    system.searchCleaner(1);
    system.updateCar(1, "Honda", "Civic", "Jane Doe");
    system.updateCleaner(1, "Alice", 6);
    system.displayCars();
    system.displayCleaners();
    system.deleteCar(1);
    system.deleteCleaner(1);
    system.displayCars();
    system.displayCleaners();
    return 0;
}