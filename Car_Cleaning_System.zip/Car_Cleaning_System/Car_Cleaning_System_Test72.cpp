#include <iostream>
#include <string>
#include <vector>

struct Car {
    int id;
    std::string brand;
    std::string model;
};

struct Cleaner {
    int id;
    std::string name;
};

class CarCleaningSystem {
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;
    int carIdCounter = 0;
    int cleanerIdCounter = 0;

public:
    void addCar(const std::string& brand, const std::string& model) {
        cars.push_back({++carIdCounter, brand, model});
    }
    
    void addCleaner(const std::string& name) {
        cleaners.push_back({++cleanerIdCounter, name});
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                return;
            }
        }
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                return;
            }
        }
    }

    void updateCar(int id, const std::string& brand, const std::string& model) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.brand = brand;
                car.model = model;
                return;
            }
        }
    }

    void updateCleaner(int id, const std::string& name) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                return;
            }
        }
    }

    void searchCar(int id) {
        for (const auto& car : cars) {
            if (car.id == id) {
                std::cout << "Car ID: " << car.id << ", Brand: " << car.brand << ", Model: " << car.model << '\n';
                return;
            }
        }
        std::cout << "Car not found.\n";
    }

    void searchCleaner(int id) {
        for (const auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << '\n';
                return;
            }
        }
        std::cout << "Cleaner not found.\n";
    }

    void displayCars() {
        if (cars.empty()) {
            std::cout << "No cars available.\n";
            return;
        }
        for (const auto& car : cars) {
            std::cout << "Car ID: " << car.id << ", Brand: " << car.brand << ", Model: " << car.model << '\n';
        }
    }

    void displayCleaners() {
        if (cleaners.empty()) {
            std::cout << "No cleaners available.\n";
            return;
        }
        for (const auto& cleaner : cleaners) {
            std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << '\n';
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar("Toyota", "Corolla");
    system.addCar("Honda", "Civic");
    system.addCleaner("Alice");
    system.addCleaner("Bob");

    system.displayCars();
    system.displayCleaners();

    system.updateCar(1, "Toyota", "Camry");
    system.searchCar(1);

    system.deleteCleaner(2);
    system.displayCleaners();

    return 0;
}