#include <iostream>
#include <vector>
#include <string>

struct Car {
    int id;
    std::string brand;
    std::string model;
};

struct Cleaner {
    int id;
    std::string name;
    int age;
};

class CarCleaningSystem {
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(int id, std::string brand, std::string model) {
        cars.push_back({id, brand, model});
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, std::string brand, std::string model) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.brand = brand;
                car.model = model;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "ID: " << car.id << ", Brand: " << car.brand << ", Model: " << car.model << "\n";
        }
    }

    void addCleaner(int id, std::string name, int age) {
        cleaners.push_back({id, name, age});
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, std::string name, int age) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                cleaner.age = age;
                break;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            std::cout << "ID: " << cleaner.id << ", Name: " << cleaner.name << ", Age: " << cleaner.age << "\n";
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota", "Corolla");
    system.addCar(2, "Ford", "Mustang");
    system.updateCar(1, "Toyota", "Camry");
    system.deleteCar(2);

    system.addCleaner(1, "John Doe", 30);
    system.addCleaner(2, "Jane Smith", 25);
    system.updateCleaner(1, "Johnny Doe", 31);
    system.deleteCleaner(2);
    
    std::cout << "Cars:\n";
    system.displayCars();

    std::cout << "\nCleaners:\n";
    system.displayCleaners();

    return 0;
}