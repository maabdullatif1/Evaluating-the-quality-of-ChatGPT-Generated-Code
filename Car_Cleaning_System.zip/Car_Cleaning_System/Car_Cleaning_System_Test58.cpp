#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    int id;
    string model;
    string owner;
};

struct Cleaner {
    int id;
    string name;
};

class CarCleaningSystem {
    vector<Car> cars;
    vector<Cleaner> cleaners;

public:
    void addCar(int id, string model, string owner) {
        Car car = {id, model, owner};
        cars.push_back(car);
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string model, string owner) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.model = model;
                car.owner = owner;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << endl;
        }
    }

    void addCleaner(int id, string name) {
        Cleaner cleaner = {id, name};
        cleaners.push_back(cleaner);
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, string name) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
            }
        }
    }

    Cleaner* searchCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << endl;
        }
    }
};

int main() {
    CarCleaningSystem system;

    system.addCar(1, "Toyota", "Alice");
    system.addCar(2, "Honda", "Bob");
    system.updateCar(2, "Ford", "Charlie");
    system.displayCars();
    system.deleteCar(1);
    system.displayCars();

    system.addCleaner(1, "John");
    system.addCleaner(2, "Mike");
    system.updateCleaner(2, "Steve");
    system.displayCleaners();
    system.deleteCleaner(1);
    system.displayCleaners();

    return 0;
}