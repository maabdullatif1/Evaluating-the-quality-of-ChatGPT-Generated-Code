#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string model;
    std::string owner;
};

class Cleaner {
public:
    int id;
    std::string name;
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;
public:
    void addCar(int id, const std::string& model, const std::string& owner) {
        Car car = {id, model, owner};
        cars.push_back(car);
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, const std::string& model, const std::string& owner) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.model = model;
                car.owner = owner;
                break;
            }
        }
    }

    void searchCar(int id) {
        for (const auto& car : cars) {
            if (car.id == id) {
                std::cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << std::endl;
                return;
            }
        }
        std::cout << "Car not found." << std::endl;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << std::endl;
        }
    }

    void addCleaner(int id, const std::string& name) {
        Cleaner cleaner = {id, name};
        cleaners.push_back(cleaner);
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                break;
            }
        }
    }

    void updateCleaner(int id, const std::string& name) {
        for (auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = name;
                break;
            }
        }
    }

    void searchCleaner(int id) {
        for (const auto& cleaner : cleaners) {
            if (cleaner.id == id) {
                std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << std::endl;
                return;
            }
        }
        std::cout << "Cleaner not found." << std::endl;
    }

    void displayCleaners() {
        for (const auto& cleaner : cleaners) {
            std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;
    system.addCar(1, "Toyota Camry", "Alice");
    system.addCar(2, "Honda Accord", "Bob");
    system.displayCars();
    system.updateCar(1, "Toyota Corolla", "Alice Smith");
    system.searchCar(1);
    system.deleteCar(2);
    system.displayCars();
    system.addCleaner(1, "John");
    system.addCleaner(2, "Jane");
    system.displayCleaners();
    system.updateCleaner(2, "Jane Doe");
    system.searchCleaner(2);
    system.deleteCleaner(1);
    system.displayCleaners();
    return 0;
}