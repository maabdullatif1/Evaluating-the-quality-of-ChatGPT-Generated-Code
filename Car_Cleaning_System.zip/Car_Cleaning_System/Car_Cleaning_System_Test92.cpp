#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string make;
    std::string model;

    Car(int id, std::string make, std::string model) : id(id), make(make), model(model) {}
};

class Cleaner {
public:
    int id;
    std::string name;

    Cleaner(int id, std::string name) : id(id), name(name) {}
};

class CarCleaningSystem {
private:
    std::vector<Car> cars;
    std::vector<Cleaner> cleaners;

public:
    void addCar(int id, std::string make, std::string model) {
        cars.push_back(Car(id, make, model));
    }

    void addCleaner(int id, std::string name) {
        cleaners.push_back(Cleaner(id, name));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                return;
            }
        }
    }

    void deleteCleaner(int id) {
        for (auto it = cleaners.begin(); it != cleaners.end(); ++it) {
            if (it->id == id) {
                cleaners.erase(it);
                return;
            }
        }
    }

    void updateCar(int id, std::string newMake, std::string newModel) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.make = newMake;
                car.model = newModel;
            }
        }
    }

    void updateCleaner(int id, std::string newName) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                cleaner.name = newName;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    Cleaner* searchCleaner(int id) {
        for (auto &cleaner : cleaners) {
            if (cleaner.id == id) {
                return &cleaner;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "Car ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << std::endl;
        }
    }

    void displayCleaners() {
        for (const auto &cleaner : cleaners) {
            std::cout << "Cleaner ID: " << cleaner.id << ", Name: " << cleaner.name << std::endl;
        }
    }
};

int main() {
    CarCleaningSystem system;

    system.addCar(1, "Toyota", "Camry");
    system.addCar(2, "Honda", "Civic");
    system.addCleaner(1, "John Doe");
    system.addCleaner(2, "Jane Smith");

    system.displayCars();
    system.displayCleaners();

    system.updateCar(1, "Toyota", "Corolla");
    system.updateCleaner(2, "Janet Smith");

    Car* car = system.searchCar(1);
    if (car) {
        std::cout << "Found Car ID: " << car->id << ", Make: " << car->make << ", Model: " << car->model << std::endl;
    }

    Cleaner* cleaner = system.searchCleaner(1);
    if (cleaner) {
        std::cout << "Found Cleaner ID: " << cleaner->id << ", Name: " << cleaner->name << std::endl;
    }

    system.deleteCar(2);
    system.deleteCleaner(2);

    system.displayCars();
    system.displayCleaners();

    return 0;
}