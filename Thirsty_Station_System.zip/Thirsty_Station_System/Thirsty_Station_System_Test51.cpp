#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

class DeliveryService {
    vector<Customer> customers;
    vector<Shop> shops;
    int customerIdCounter = 1;
    int shopIdCounter = 1;

    public:
    void addCustomer(string name, string address) {
        customers.push_back({customerIdCounter++, name, address});
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string address) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << endl;
        }
    }

    void addShop(string name, string location) {
        shops.push_back({shopIdCounter++, name, location});
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, string name, string location) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                break;
            }
        }
    }

    Shop* searchShop(int id) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayShops() {
        for (const auto &shop : shops) {
            cout << "Shop ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << endl;
        }
    }
};

int main() {
    DeliveryService service;
    service.addCustomer("Alice", "123 Street A");
    service.addCustomer("Bob", "456 Street B");
    service.addShop("Shop 1", "Location 1");
    service.addShop("Shop 2", "Location 2");

    cout << "Customers:\n";
    service.displayCustomers();
    cout << "\nShops:\n";
    service.displayShops();

    Customer* customer = service.searchCustomer(1);
    if (customer) {
        cout << "\nFound Customer: ID " << customer->id << ", Name: " << customer->name << ", Address: " << customer->address << endl;
    }

    Shop* shop = service.searchShop(1);
    if (shop) {
        cout << "Found Shop: ID " << shop->id << ", Name: " << shop->name << ", Location: " << shop->location << endl;
    }

    service.updateCustomer(1, "Alice Smith", "321 Updated Street A");
    service.updateShop(1, "Updated Shop 1", "Updated Location 1");

    cout << "\nUpdated Customers:\n";
    service.displayCustomers();
    cout << "\nUpdated Shops:\n";
    service.displayShops();

    return 0;
}