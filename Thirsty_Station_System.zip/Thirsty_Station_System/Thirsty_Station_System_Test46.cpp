#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string address;
    string phone;

    Customer(int id, const string& name, const string& address, const string& phone)
        : id(id), name(name), address(address), phone(phone) {}
};

class Shop {
public:
    int id;
    string name;
    string address;
    string phone;

    Shop(int id, const string& name, const string& address, const string& phone)
        : id(id), name(name), address(address), phone(phone) {}
};

class DeliveryServiceSystem {
private:
    vector<Customer> customers;
    vector<Shop> shops;

public:
    void addCustomer(int id, const string& name, const string& address, const string& phone) {
        customers.push_back(Customer(id, name, address, phone));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const string& name, const string& address, const string& phone) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                customer.phone = phone;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "ID: " << customer.id << ", Name: " << customer.name
                 << ", Address: " << customer.address << ", Phone: " << customer.phone << endl;
        }
    }

    void addShop(int id, const string& name, const string& address, const string& phone) {
        shops.push_back(Shop(id, name, address, phone));
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, const string& name, const string& address, const string& phone) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.address = address;
                shop.phone = phone;
                break;
            }
        }
    }

    Shop* searchShop(int id) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayShops() {
        for (const auto& shop : shops) {
            cout << "ID: " << shop.id << ", Name: " << shop.name
                 << ", Address: " << shop.address << ", Phone: " << shop.phone << endl;
        }
    }
};

int main() {
    DeliveryServiceSystem system;

    system.addCustomer(1, "John Doe", "123 Elm St", "555-1234");
    system.addShop(1, "DrinkStore", "456 Oak Rd", "555-5678");

    system.displayCustomers();
    system.displayShops();

    Customer* customer = system.searchCustomer(1);
    if (customer) {
        cout << "Found customer: " << customer->name << endl;
    }

    Shop* shop = system.searchShop(1);
    if (shop) {
        cout << "Found shop: " << shop->name << endl;
    }

    system.updateCustomer(1, "John A. Doe", "123 Elm St, Apt 2", "555-4321");
    system.updateShop(1, "Super Drink Store", "789 Pine Blvd", "555-9876");

    system.displayCustomers();
    system.displayShops();

    system.deleteCustomer(1);
    system.deleteShop(1);

    system.displayCustomers();
    system.displayShops();

    return 0;
}