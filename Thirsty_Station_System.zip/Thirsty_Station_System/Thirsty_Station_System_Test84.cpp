#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string address;
};

struct Shop {
    int id;
    std::string name;
    std::string location;
};

bool findCustomerById(const std::vector<Customer>& customers, int id, Customer &customer) {
    for (const auto& c : customers) {
        if (c.id == id) {
            customer = c;
            return true;
        }
    }
    return false;
}

bool findShopById(const std::vector<Shop>& shops, int id, Shop &shop) {
    for (const auto& s : shops) {
        if (s.id == id) {
            shop = s;
            return true;
        }
    }
    return false;
}

void addCustomer(std::vector<Customer>& customers, int id, const std::string& name, const std::string& address) {
    customers.push_back({id, name, address});
}

void addShop(std::vector<Shop>& shops, int id, const std::string& name, const std::string& location) {
    shops.push_back({id, name, location});
}

void deleteCustomer(std::vector<Customer>& customers, int id) {
    customers.erase(std::remove_if(customers.begin(), customers.end(), 
                [id](const Customer & c) { return c.id == id; }), customers.end());
}

void deleteShop(std::vector<Shop>& shops, int id) {
    shops.erase(std::remove_if(shops.begin(), shops.end(), 
                [id](const Shop & s) { return s.id == id; }), shops.end());
}

void updateCustomer(std::vector<Customer>& customers, int id, const std::string& name, const std::string& address) {
    for (auto& c : customers) {
        if (c.id == id) {
            c.name = name;
            c.address = address;
        }
    }
}

void updateShop(std::vector<Shop>& shops, int id, const std::string& name, const std::string& location) {
    for (auto& s : shops) {
        if (s.id == id) {
            s.name = name;
            s.location = location;
        }
    }
}

void displayCustomers(const std::vector<Customer>& customers) {
    for (const auto& c : customers) {
        std::cout << "ID: " << c.id << ", Name: " << c.name << ", Address: " << c.address << "\n";
    }
}

void displayShops(const std::vector<Shop>& shops) {
    for (const auto& s : shops) {
        std::cout << "ID: " << s.id << ", Name: " << s.name << ", Location: " << s.location << "\n";
    }
}

int main() {
    std::vector<Customer> customers;
    std::vector<Shop> shops;
    
    addCustomer(customers, 1, "John Doe", "123 Elm Street");
    addCustomer(customers, 2, "Jane Smith", "456 Oak Avenue");

    addShop(shops, 1, "The Drink Corner", "789 Pine Road");
    addShop(shops, 2, "Cheers Shop", "321 Maple Street");

    displayCustomers(customers);
    displayShops(shops);

    updateCustomer(customers, 1, "John Doe", "123 Elm St");
    updateShop(shops, 2, "Cheers Beverage Store", "321 Maple St");

    displayCustomers(customers);
    displayShops(shops);

    deleteCustomer(customers, 2);
    deleteShop(shops, 1);

    displayCustomers(customers);
    displayShops(shops);

    return 0;
}