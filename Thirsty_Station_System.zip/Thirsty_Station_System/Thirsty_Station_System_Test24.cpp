#include <iostream>
#include <vector>
#include <string>

class Entity {
public:
    std::string name;
    std::string address;
    Entity(std::string n, std::string a) : name(n), address(a) {}
    virtual void displayInfo() = 0;
};

class Customer : public Entity {
public:
    Customer(std::string n, std::string a) : Entity(n, a) {}
    void displayInfo() override {
        std::cout << "Customer Name: " << name << ", Address: " << address << std::endl;
    }
};

class Shop : public Entity {
public:
    Shop(std::string n, std::string a) : Entity(n, a) {}
    void displayInfo() override {
        std::cout << "Shop Name: " << name << ", Address: " << address << std::endl;
    }
};

class DeliveryService {
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(std::string name, std::string address) {
        customers.push_back(Customer(name, address));
    }

    void deleteCustomer(std::string name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(std::string name, std::string newAddress) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                customer.address = newAddress;
                break;
            }
        }
    }

    void searchCustomer(std::string name) {
        for (const auto& customer : customers) {
            if (customer.name == name) {
                customer.displayInfo();
                return;
            }
        }
        std::cout << "Customer not found." << std::endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            customer.displayInfo();
        }
    }

    void addShop(std::string name, std::string address) {
        shops.push_back(Shop(name, address));
    }

    void deleteShop(std::string name) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->name == name) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(std::string name, std::string newAddress) {
        for (auto& shop : shops) {
            if (shop.name == name) {
                shop.address = newAddress;
                break;
            }
        }
    }

    void searchShop(std::string name) {
        for (const auto& shop : shops) {
            if (shop.name == name) {
                shop.displayInfo();
                return;
            }
        }
        std::cout << "Shop not found." << std::endl;
    }

    void displayShops() {
        for (const auto& shop : shops) {
            shop.displayInfo();
        }
    }
};

int main() {
    DeliveryService service;
    service.addCustomer("John Doe", "123 Elm St");
    service.addShop("Quick Drinks", "456 Oak St");
    
    std::cout << "Customers:" << std::endl;
    service.displayCustomers();
    
    std::cout << "Shops:" << std::endl;
    service.displayShops();
    
    return 0;
}