#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string address;
};

struct Shop {
    int id;
    std::string name;
    std::string location;
};

class DeliverySystem {
    std::vector<Customer> customers;
    std::vector<Shop> shops;
    int customer_id_counter;
    int shop_id_counter;

public:
    DeliverySystem() : customer_id_counter(1), shop_id_counter(1) {}

    void addCustomer(const std::string& name, const std::string& address) {
        customers.push_back({customer_id_counter++, name, address});
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& address) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name 
                          << ", Address: " << customer.address << std::endl;
            }
        }
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name 
                      << ", Address: " << customer.address << std::endl;
        }
    }

    void addShop(const std::string& name, const std::string& location) {
        shops.push_back({shop_id_counter++, name, location});
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, const std::string& name, const std::string& location) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
            }
        }
    }

    void searchShop(int id) {
        for (const auto& shop : shops) {
            if (shop.id == id) {
                std::cout << "Shop ID: " << shop.id << ", Name: " << shop.name 
                          << ", Location: " << shop.location << std::endl;
            }
        }
    }

    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "Shop ID: " << shop.id << ", Name: " << shop.name 
                      << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    DeliverySystem system;
    system.addCustomer("John Doe", "123 Main St");
    system.addCustomer("Jane Smith", "456 Elm St");
    system.displayCustomers();
    system.addShop("Drink Shop", "Downtown");
    system.displayShops();
    system.searchCustomer(1);
    system.updateCustomer(1, "John Doe Jr.", "789 Maple St");
    system.displayCustomers();
    system.deleteCustomer(2);
    system.displayCustomers();
    system.searchShop(1);
    system.updateShop(1, "Super Drink Shop", "Uptown");
    system.displayShops();
    system.deleteShop(1);
    system.displayShops();
    return 0;
}