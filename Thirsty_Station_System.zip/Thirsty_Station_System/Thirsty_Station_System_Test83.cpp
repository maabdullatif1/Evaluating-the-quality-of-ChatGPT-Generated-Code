#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
public:
    string name;
    string address;
};

class Customer : public Person {
public:
    int customerID;
};

class Shop : public Person {
public:
    int shopID;
};

class DrinksDeliveryService {
private:
    vector<Customer> customers;
    vector<Shop> shops;

public:
    void addCustomer(int id, string name, string address) {
        Customer c;
        c.customerID = id;
        c.name = name;
        c.address = address;
        customers.push_back(c);
    }

    void deleteCustomer(int id) {
        auto it = remove_if(customers.begin(), customers.end(), [&](Customer const& c) { return c.customerID == id; });
        if (it != customers.end()) customers.erase(it, customers.end());
    }

    void updateCustomer(int id, string newName, string newAddress) {
        for (auto& c : customers) {
            if (c.customerID == id) {
                c.name = newName;
                c.address = newAddress;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto& c : customers) {
            if (c.customerID == id) {
                cout << "Customer ID: " << c.customerID << ", Name: " << c.name << ", Address: " << c.address << endl;
                return;
            }
        }
        cout << "Customer not found." << endl;
    }

    void displayCustomers() {
        for (const auto& c : customers) {
            cout << "Customer ID: " << c.customerID << ", Name: " << c.name << ", Address: " << c.address << endl;
        }
    }

    void addShop(int id, string name, string address) {
        Shop s;
        s.shopID = id;
        s.name = name;
        s.address = address;
        shops.push_back(s);
    }

    void deleteShop(int id) {
        auto it = remove_if(shops.begin(), shops.end(), [&](Shop const& s) { return s.shopID == id; });
        if (it != shops.end()) shops.erase(it, shops.end());
    }

    void updateShop(int id, string newName, string newAddress) {
        for (auto& s : shops) {
            if (s.shopID == id) {
                s.name = newName;
                s.address = newAddress;
                break;
            }
        }
    }

    void searchShop(int id) {
        for (const auto& s : shops) {
            if (s.shopID == id) {
                cout << "Shop ID: " << s.shopID << ", Name: " << s.name << ", Address: " << s.address << endl;
                return;
            }
        }
        cout << "Shop not found." << endl;
    }

    void displayShops() {
        for (const auto& s : shops) {
            cout << "Shop ID: " << s.shopID << ", Name: " << s.name << ", Address: " << s.address << endl;
        }
    }
};

int main() {
    DrinksDeliveryService service;

    service.addCustomer(1, "John Doe", "123 Elm Street");
    service.addCustomer(2, "Jane Smith", "456 Oak Avenue");

    service.displayCustomers();

    service.searchCustomer(1);

    service.updateCustomer(2, "Jane Johnson", "789 Pine Road");
    service.displayCustomers();

    service.deleteCustomer(1);
    service.displayCustomers();

    service.addShop(1, "Drink Heaven", "101 Beverages Blvd");
    service.addShop(2, "Cocktail Corner", "202 Spirits Street");

    service.displayShops();

    service.searchShop(1);

    service.updateShop(2, "Cocktail Paradise", "303 Liquor Lane");
    service.displayShops();

    service.deleteShop(1);
    service.displayShops();

    return 0;
}