#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

class DeliverySystem {
    vector<Customer> customers;
    vector<Shop> shops;
    int customerIdCounter = 1;
    int shopIdCounter = 1;

    Customer* findCustomerById(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Shop* findShopById(int id) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

public:
    void addCustomer(string name, string address) {
        Customer customer { customerIdCounter++, name, address };
        customers.push_back(customer);
    }
    
    void deleteCustomer(int id) {
        customers.erase(remove_if(customers.begin(), customers.end(), [id](const Customer& customer) {
            return customer.id == id;
        }), customers.end());
    }

    void updateCustomer(int id, string name, string address) {
        Customer* customer = findCustomerById(id);
        if (customer) {
            customer->name = name;
            customer->address = address;
        }
    }

    void addShop(string name, string location) {
        Shop shop { shopIdCounter++, name, location };
        shops.push_back(shop);
    }
    
    void deleteShop(int id) {
        shops.erase(remove_if(shops.begin(), shops.end(), [id](const Shop& shop) {
            return shop.id == id;
        }), shops.end());
    }

    void updateShop(int id, string name, string location) {
        Shop* shop = findShopById(id);
        if (shop) {
            shop->name = name;
            shop->location = location;
        }
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << endl;
        }
    }

    void displayShops() {
        for (const auto &shop : shops) {
            cout << "Shop ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << endl;
        }
    }

    Customer* searchCustomer(string name) {
        for (auto &customer : customers) {
            if (customer.name == name) {
                return &customer;
            }
        }
        return nullptr;
    }

    Shop* searchShop(string name) {
        for (auto &shop : shops) {
            if (shop.name == name) {
                return &shop;
            }
        }
        return nullptr;
    }
};

int main() {
    DeliverySystem system;
    system.addCustomer("John Doe", "123 Main St");
    system.addCustomer("Jane Smith", "456 Park Ave");
    system.addShop("Cool Drinks", "789 Market St");
    system.addShop("Thirsty Ventures", "101 High St");

    system.displayCustomers();
    system.displayShops();

    system.updateCustomer(1, "Johnathan Doe", "123 Main St, Apt 2");
    system.updateShop(2, "Thirst Quenchers", "101 High St, Suite 500");

    system.displayCustomers();
    system.displayShops();

    Customer* foundCustomer = system.searchCustomer("Jane Smith");
    if (foundCustomer) {
        cout << "Found Customer: " << foundCustomer->name << endl;
    }

    Shop* foundShop = system.searchShop("Thirst Quenchers");
    if (foundShop) {
        cout << "Found Shop: " << foundShop->name << endl;
    }

    system.deleteCustomer(2);
    system.deleteShop(1);

    system.displayCustomers();
    system.displayShops();

    return 0;
}