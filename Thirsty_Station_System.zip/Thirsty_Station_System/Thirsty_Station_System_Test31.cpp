#include <iostream>
#include <string>
#include <vector>

class Customer {
public:
    int id;
    std::string name;
    std::string address;
    std::string phone;
    Customer(int id, std::string name, std::string address, std::string phone)
        : id(id), name(name), address(address), phone(phone) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;
    std::string contact;
    Shop(int id, std::string name, std::string location, std::string contact)
        : id(id), name(name), location(location), contact(contact) {}
};

class DrinksDeliveryService {
private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;
public:
    void addCustomer(int id, std::string name, std::string address, std::string phone) {
        customers.push_back(Customer(id, name, address, phone));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string address, std::string phone) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                customer.phone = phone;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto &customer : customers) {
            if (customer.id == id) {
                std::cout << "ID: " << customer.id << " Name: " << customer.name
                          << " Address: " << customer.address << " Phone: " << customer.phone << std::endl;
                return;
            }
        }
        std::cout << "Customer not found" << std::endl;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "ID: " << customer.id << " Name: " << customer.name
                      << " Address: " << customer.address << " Phone: " << customer.phone << std::endl;
        }
    }

    void addShop(int id, std::string name, std::string location, std::string contact) {
        shops.push_back(Shop(id, name, location, contact));
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, std::string name, std::string location, std::string contact) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                shop.contact = contact;
                break;
            }
        }
    }

    void searchShop(int id) {
        for (const auto &shop : shops) {
            if (shop.id == id) {
                std::cout << "ID: " << shop.id << " Name: " << shop.name
                          << " Location: " << shop.location << " Contact: " << shop.contact << std::endl;
                return;
            }
        }
        std::cout << "Shop not found" << std::endl;
    }

    void displayShops() {
        for (const auto &shop : shops) {
            std::cout << "ID: " << shop.id << " Name: " << shop.name
                      << " Location: " << shop.location << " Contact: " << shop.contact << std::endl;
        }
    }
};

int main() {
    DrinksDeliveryService service;
    service.addCustomer(1, "Alice", "123 Main St", "111-222-3333");
    service.addShop(1, "Best Drinks", "Market St", "444-555-6666");
    service.displayCustomers();
    service.displayShops();
    service.updateCustomer(1, "Bob", "456 Maple Ave", "777-888-9999");
    service.searchCustomer(1);
    service.deleteCustomer(1);
    service.displayCustomers();
    service.searchShop(1);
    service.updateShop(1, "Better Drinks", "High St", "000-111-2222");
    service.searchShop(1);
    service.deleteShop(1);
    service.displayShops();
    return 0;
}