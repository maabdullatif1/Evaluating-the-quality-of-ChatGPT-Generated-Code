#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string address;
};

struct Shop {
    int id;
    std::string name;
    std::string location;
};

class DeliveryService {
private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;
    int nextCustomerId = 1;
    int nextShopId = 1;

public:
    void addCustomer(const std::string& name, const std::string& address) {
        customers.push_back({nextCustomerId++, name, address});
    }

    void addShop(const std::string& name, const std::string& location) {
        shops.push_back({nextShopId++, name, location});
    }

    void deleteCustomer(int id) {
        for(auto it = customers.begin(); it != customers.end(); ++it) {
            if(it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void deleteShop(int id) {
        for(auto it = shops.begin(); it != shops.end(); ++it) {
            if(it->id == id) {
                shops.erase(it);
                return;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& address) {
        for(auto& customer : customers) {
            if(customer.id == id) {
                customer.name = name;
                customer.address = address;
                return;
            }
        }
    }

    void updateShop(int id, const std::string& name, const std::string& location) {
        for(auto& shop : shops) {
            if(shop.id == id) {
                shop.name = name;
                shop.location = location;
                return;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for(auto& customer : customers) {
            if(customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Shop* searchShop(int id) {
        for(auto& shop : shops) {
            if(shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for(const auto& customer : customers) {
            std::cout << "ID: " << customer.id
                      << ", Name: " << customer.name
                      << ", Address: " << customer.address << std::endl;
        }
    }

    void displayShops() {
        for(const auto& shop : shops) {
            std::cout << "ID: " << shop.id
                      << ", Name: " << shop.name
                      << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    DeliveryService service;

    service.addCustomer("Alice", "123 Main St");
    service.addCustomer("Bob", "456 Elm St");
    service.displayCustomers();

    service.addShop("The Drink Place", "789 Maple Ave");
    service.addShop("Beverage Hub", "101 Oak St");
    service.displayShops();

    service.updateCustomer(1, "Alice Smith", "123 Main St, Suite A");
    service.displayCustomers();

    Customer* customer = service.searchCustomer(1);
    if(customer) {
        std::cout << "Found customer: " << customer->name << std::endl;
    }

    Shop* shop = service.searchShop(2);
    if(shop) {
        std::cout << "Found shop: " << shop->name << std::endl;
    }

    service.deleteCustomer(2);
    service.displayCustomers();

    service.deleteShop(1);
    service.displayShops();

    return 0;
}