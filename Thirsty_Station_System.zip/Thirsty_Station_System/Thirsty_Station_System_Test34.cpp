#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
    string phone;
};

struct Shop {
    int id;
    string name;
    string address;
};

vector<Customer> customers;
vector<Shop> shops;

int generateID(vector<int> &existingIDs) {
    int id = existingIDs.size() + 1;
    existingIDs.push_back(id);
    return id;
}

void addCustomer() {
    Customer customer;
    customer.id = generateID(existingIDs);
    cout << "Enter customer name: ";
    cin >> customer.name;
    cout << "Enter customer address: ";
    cin >> customer.address;
    cout << "Enter customer phone: ";
    cin >> customer.phone;
    customers.push_back(customer);
}

void addShop() {
    Shop shop;
    shop.id = generateID(existingIDs);
    cout << "Enter shop name: ";
    cin >> shop.name;
    cout << "Enter shop address: ";
    cin >> shop.address;
    shops.push_back(shop);
}

void deleteCustomer() {
    int id;
    cout << "Enter customer ID to delete: ";
    cin >> id;
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            break;
        }
    }
}

void deleteShop() {
    int id;
    cout << "Enter shop ID to delete: ";
    cin >> id;
    for (auto it = shops.begin(); it != shops.end(); ++it) {
        if (it->id == id) {
            shops.erase(it);
            break;
        }
    }
}

void updateCustomer() {
    int id;
    cout << "Enter customer ID to update: ";
    cin >> id;
    for (auto &customer : customers) {
        if (customer.id == id) {
            cout << "Enter new name: ";
            cin >> customer.name;
            cout << "Enter new address: ";
            cin >> customer.address;
            cout << "Enter new phone: ";
            cin >> customer.phone;
        }
    }
}

void updateShop() {
    int id;
    cout << "Enter shop ID to update: ";
    cin >> id;
    for (auto &shop : shops) {
        if (shop.id == id) {
            cout << "Enter new name: ";
            cin >> shop.name;
            cout << "Enter new address: ";
            cin >> shop.address;
        }
    }
}

void searchCustomer() {
    int id;
    cout << "Enter customer ID to search: ";
    cin >> id;
    for (const auto &customer : customers) {
        if (customer.id == id) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name
                << ", Address: " << customer.address << ", Phone: " << customer.phone << endl;
        }
    }
}

void searchShop() {
    int id;
    cout << "Enter shop ID to search: ";
    cin >> id;
    for (const auto &shop : shops) {
        if (shop.id == id) {
            cout << "Shop ID: " << shop.id << ", Name: " << shop.name
                << ", Address: " << shop.address << endl;
        }
    }
}

void displayCustomers() {
    for (const auto &customer : customers) {
        cout << "Customer ID: " << customer.id << ", Name: " << customer.name
            << ", Address: " << customer.address << ", Phone: " << customer.phone << endl;
    }
}

void displayShops() {
    for (const auto &shop : shops) {
        cout << "Shop ID: " << shop.id << ", Name: " << shop.name
            << ", Address: " << shop.address << endl;
    }
}

int main() {
    char choice;
    while (true) {
        cout << "1. Add Customer\n2. Add Shop\n3. Delete Customer\n4. Delete Shop\n5. Update Customer\n6. Update Shop\n7. Search Customer\n8. Search Shop\n9. Display Customers\n10. Display Shops\n11. Exit\n";
        cin >> choice;
        switch (choice) {
            case '1': addCustomer(); break;
            case '2': addShop(); break;
            case '3': deleteCustomer(); break;
            case '4': deleteShop(); break;
            case '5': updateCustomer(); break;
            case '6': updateShop(); break;
            case '7': searchCustomer(); break;
            case '8': searchShop(); break;
            case '9': displayCustomers(); break;
            case '10': displayShops(); break;
            case '11': return 0;
            default: cout << "Invalid choice. Please try again.\n"; break;
        }
    }
}