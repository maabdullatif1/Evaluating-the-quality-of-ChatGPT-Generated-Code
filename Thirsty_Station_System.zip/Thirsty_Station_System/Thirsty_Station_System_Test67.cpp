#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

vector<Customer> customers;
vector<Shop> shops;

void addCustomer(int id, const string& name, const string& address) {
    customers.push_back({id, name, address});
}

void deleteCustomer(int id) {
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            return;
        }
    }
}

void updateCustomer(int id, const string& name, const string& address) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            customer.name = name;
            customer.address = address;
            return;
        }
    }
}

Customer* searchCustomer(int id) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            return &customer;
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (const auto& customer : customers) {
        cout << "ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << endl;
    }
}

void addShop(int id, const string& name, const string& location) {
    shops.push_back({id, name, location});
}

void deleteShop(int id) {
    for (auto it = shops.begin(); it != shops.end(); ++it) {
        if (it->id == id) {
            shops.erase(it);
            return;
        }
    }
}

void updateShop(int id, const string& name, const string& location) {
    for (auto& shop : shops) {
        if (shop.id == id) {
            shop.name = name;
            shop.location = location;
            return;
        }
    }
}

Shop* searchShop(int id) {
    for (auto& shop : shops) {
        if (shop.id == id) {
            return &shop;
        }
    }
    return nullptr;
}

void displayShops() {
    for (const auto& shop : shops) {
        cout << "ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "123 Main St");
    addCustomer(2, "Jane Smith", "456 First Ave");

    addShop(1, "Beverage Haven", "789 Drink Blvd");
    addShop(2, "Liquid World", "1012 Refresh Dr");

    cout << "Customers:" << endl;
    displayCustomers();
    
    cout << "\nShops:" << endl;
    displayShops();
    
    updateCustomer(2, "Jane Smith", "987 New Address");
    updateShop(1, "Beverage Kingdom", "1111 Changed Rd");

    cout << "\nUpdated Customers:" << endl;
    displayCustomers();
    
    cout << "\nUpdated Shops:" << endl;
    displayShops();
    
    deleteCustomer(1);
    deleteShop(2);
    
    cout << "\nCustomers after deletion:" << endl;
    displayCustomers();
    
    cout << "\nShops after deletion:" << endl;
    displayShops();

    return 0;
}