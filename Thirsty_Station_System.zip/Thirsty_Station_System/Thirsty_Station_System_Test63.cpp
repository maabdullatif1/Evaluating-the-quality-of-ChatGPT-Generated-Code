#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Customer {
    string name;
    string address;
    string phone;
};

struct Shop {
    string name;
    string location;
    string contact;
};

class DeliveryService {
private:
    vector<Customer> customers;
    vector<Shop> shops;

public:
    void addCustomer(const string& name, const string& address, const string& phone) {
        customers.push_back({name, address, phone});
    }

    void addShop(const string& name, const string& location, const string& contact) {
        shops.push_back({name, location, contact});
    }

    void deleteCustomer(const string& name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                return;
            }
        }
    }

    void deleteShop(const string& name) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->name == name) {
                shops.erase(it);
                return;
            }
        }
    }

    void updateCustomer(const string& name, const string& newAddress, const string& newPhone) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                customer.address = newAddress;
                customer.phone = newPhone;
                return;
            }
        }
    }

    void updateShop(const string& name, const string& newLocation, const string& newContact) {
        for (auto& shop : shops) {
            if (shop.name == name) {
                shop.location = newLocation;
                shop.contact = newContact;
                return;
            }
        }
    }

    Customer* searchCustomer(const string& name) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                return &customer;
            }
        }
        return nullptr;
    }

    Shop* searchShop(const string& name) {
        for (auto& shop : shops) {
            if (shop.name == name) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Name: " << customer.name << ", Address: " << customer.address << ", Phone: " << customer.phone << endl;
        }
    }

    void displayShops() {
        for (const auto& shop : shops) {
            cout << "Name: " << shop.name << ", Location: " << shop.location << ", Contact: " << shop.contact << endl;
        }
    }
};

int main() {
    DeliveryService ds;

    ds.addCustomer("John Doe", "123 Elm St", "555-1234");
    ds.addShop("Cool Drinks", "456 Oak Blvd", "555-5678");

    ds.displayCustomers();
    ds.displayShops();

    Customer* c = ds.searchCustomer("John Doe");
    if (c != nullptr) {
        cout << "Found Customer: " << c->name << endl;
    }

    Shop* s = ds.searchShop("Cool Drinks");
    if (s != nullptr) {
        cout << "Found Shop: " << s->name << endl;
    }

    ds.updateCustomer("John Doe", "789 Maple Rd", "555-9876");
    ds.updateShop("Cool Drinks", "789 Pine St", "555-8765");

    ds.displayCustomers();
    ds.displayShops();

    ds.deleteCustomer("John Doe");
    ds.deleteShop("Cool Drinks");

    ds.displayCustomers();
    ds.displayShops();

    return 0;
}