#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

class DrinksDeliveryService {
    vector<Customer> customers;
    vector<Shop> shops;
    
    int findCustomerById(int id) {
        for (int i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) return i;
        }
        return -1;
    }

    int findShopById(int id) {
        for (int i = 0; i < shops.size(); ++i) {
            if (shops[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCustomer(int id, const string& name, const string& address) {
        if (findCustomerById(id) == -1) {
            customers.push_back(Customer{id, name, address});
        }
    }

    void deleteCustomer(int id) {
        int index = findCustomerById(id);
        if (index != -1) {
            customers.erase(customers.begin() + index);
        }
    }

    void updateCustomer(int id, const string& name, const string& address) {
        int index = findCustomerById(id);
        if (index != -1) {
            customers[index].name = name;
            customers[index].address = address;
        }
    }

    Customer* searchCustomer(int id) {
        int index = findCustomerById(id);
        return index != -1 ? &customers[index] : nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "ID: " << customer.id << ", Name: " << customer.name
                 << ", Address: " << customer.address << endl;
        }
    }

    void addShop(int id, const string& name, const string& location) {
        if (findShopById(id) == -1) {
            shops.push_back(Shop{id, name, location});
        }
    }

    void deleteShop(int id) {
        int index = findShopById(id);
        if (index != -1) {
            shops.erase(shops.begin() + index);
        }
    }

    void updateShop(int id, const string& name, const string& location) {
        int index = findShopById(id);
        if (index != -1) {
            shops[index].name = name;
            shops[index].location = location;
        }
    }

    Shop* searchShop(int id) {
        int index = findShopById(id);
        return index != -1 ? &shops[index] : nullptr;
    }

    void displayShops() {
        for (const auto& shop : shops) {
            cout << "ID: " << shop.id << ", Name: " << shop.name
                 << ", Location: " << shop.location << endl;
        }
    }
};

int main() {
    DrinksDeliveryService service;
    service.addCustomer(1, "John Doe", "123 Elm Street");
    service.addCustomer(2, "Jane Smith", "456 Oak Avenue");
    service.displayCustomers();
    
    service.updateCustomer(1, "John Doe", "789 Maple Lane");
    service.displayCustomers();
    
    service.deleteCustomer(2);
    service.displayCustomers();
    
    service.addShop(1, "Joe's Drinks", "Downtown");
    service.addShop(2, "Cool Beverages", "Uptown");
    service.displayShops();
    
    service.updateShop(1, "Joe's Drink Emporium", "Broadway");
    service.displayShops();
    
    service.deleteShop(2);
    service.displayShops();
    
    return 0;
}