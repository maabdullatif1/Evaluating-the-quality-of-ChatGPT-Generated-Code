#include <iostream>
#include <string>
#include <vector>

class Customer {
public:
    std::string name;
    std::string address;
    std::string phone;

    Customer(std::string n, std::string a, std::string p) : name(n), address(a), phone(p) {}
};

class Shop {
public:
    std::string name;
    std::string location;

    Shop(std::string n, std::string l) : name(n), location(l) {}
};

class System {
private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(const std::string& name, const std::string& address, const std::string& phone) {
        customers.emplace_back(name, address, phone);
    }

    void deleteCustomer(const std::string& name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                return;
            }
        }
    }

    void updateCustomer(const std::string& name, const std::string& address, const std::string& phone) {
        for (auto& c : customers) {
            if (c.name == name) {
                c.address = address;
                c.phone = phone;
                return;
            }
        }
    }

    void searchCustomer(const std::string& name) {
        for (const auto& c : customers) {
            if (c.name == name) {
                std::cout << "Customer found: " << c.name << ", " << c.address << ", " << c.phone << std::endl;
                return;
            }
        }
        std::cout << "Customer not found" << std::endl;
    }

    void displayCustomers() {
        for (const auto& c : customers) {
            std::cout << "Customer: " << c.name << ", " << c.address << ", " << c.phone << std::endl;
        }
    }

    void addShop(const std::string& name, const std::string& location) {
        shops.emplace_back(name, location);
    }

    void deleteShop(const std::string& name) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->name == name) {
                shops.erase(it);
                return;
            }
        }
    }

    void updateShop(const std::string& name, const std::string& location) {
        for (auto& s : shops) {
            if (s.name == name) {
                s.location = location;
                return;
            }
        }
    }

    void searchShop(const std::string& name) {
        for (const auto& s : shops) {
            if (s.name == name) {
                std::cout << "Shop found: " << s.name << ", " << s.location << std::endl;
                return;
            }
        }
        std::cout << "Shop not found" << std::endl;
    }

    void displayShops() {
        for (const auto& s : shops) {
            std::cout << "Shop: " << s.name << ", " << s.location << std::endl;
        }
    }
};

int main() {
    System system;

    system.addCustomer("John Doe", "123 Elm St", "555-1234");
    system.addCustomer("Jane Smith", "456 Oak St", "555-5678");
    system.addShop("The Beer Store", "789 Pine Ave");
    system.addShop("Wine World", "101 Maple Dr");

    system.displayCustomers();
    system.displayShops();

    system.searchCustomer("John Doe");
    system.searchShop("Wine World");

    system.updateCustomer("John Doe", "321 Palm St", "555-9876");
    system.updateShop("Wine World", "202 Birch Ln");

    system.displayCustomers();
    system.displayShops();

    system.deleteCustomer("Jane Smith");
    system.deleteShop("The Beer Store");

    system.displayCustomers();
    system.displayShops();

    return 0;
}