#include <iostream>
#include <string>
#include <vector>

class Customer {
public:
    int id;
    std::string name;
    std::string address;

    Customer(int id, const std::string& name, const std::string& address) : id(id), name(name), address(address) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;

    Shop(int id, const std::string& name, const std::string& location) : id(id), name(name), location(location) {}
};

class DrinksDeliveryService {
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(int id, const std::string& name, const std::string& address) {
        customers.push_back(Customer(id, name, address));
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, const std::string& name, const std::string& address) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                break;
            }
        }
    }
    
    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }
    
    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name
                      << ", Address: " << customer.address << std::endl;
        }
    }
    
    void addShop(int id, const std::string& name, const std::string& location) {
        shops.push_back(Shop(id, name, location));
    }
    
    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }
    
    void updateShop(int id, const std::string& name, const std::string& location) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                break;
            }
        }
    }
    
    Shop* searchShop(int id) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }
    
    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "Shop ID: " << shop.id << ", Name: " << shop.name
                      << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    DrinksDeliveryService service;

    service.addCustomer(1, "John Doe", "123 Elm Street");
    service.addCustomer(2, "Jane Smith", "456 Oak Avenue");
    service.displayCustomers();

    service.addShop(1, "Beverage Emporium", "Downtown");
    service.addShop(2, "Cool Drinks", "Uptown");
    service.displayShops();

    return 0;
}