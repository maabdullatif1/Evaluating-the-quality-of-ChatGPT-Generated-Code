#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

class DeliveryService {
    vector<Customer> customers;
    vector<Shop> shops;
    int customerCounter = 0;
    int shopCounter = 0;

public:
    void addCustomer(const string &name, const string &address) {
        Customer customer = {++customerCounter, name, address};
        customers.push_back(customer);
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const string &newName, const string &newAddress) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = newName;
                customer.address = newAddress;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name 
                 << ", Address: " << customer.address << endl;
        }
    }

    void addShop(const string &name, const string &location) {
        Shop shop = {++shopCounter, name, location};
        shops.push_back(shop);
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, const string &newName, const string &newLocation) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                shop.name = newName;
                shop.location = newLocation;
                break;
            }
        }
    }

    Shop* searchShop(int id) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayShops() {
        for (const auto &shop : shops) {
            cout << "Shop ID: " << shop.id << ", Name: " << shop.name 
                 << ", Location: " << shop.location << endl;
        }
    }
};

int main() {
    DeliveryService service;
    service.addCustomer("Alice", "123 Main St");
    service.addCustomer("Bob", "456 Elm St");

    service.addShop("Drink Hub", "Central Plaza");
    service.addShop("Beverage Barn", "Market Square");

    cout << "Customers:\n";
    service.displayCustomers();

    cout << "\nShops:\n";
    service.displayShops();

    service.updateCustomer(1, "Alice Smith", "789 Oak St");
    service.updateShop(2, "Beverage Depot", "Warehouse District");

    cout << "\nUpdated Customers:\n";
    service.displayCustomers();

    cout << "\nUpdated Shops:\n";
    service.displayShops();

    return 0;
}