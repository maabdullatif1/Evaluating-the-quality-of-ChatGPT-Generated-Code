#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
public:
    string name;
    string address;
    string phone;
};

class Customer : public Person {
public:
    Customer(string n, string a, string p) {
        name = n;
        address = a;
        phone = p;
    }
};

class Shop {
public:
    string name;
    string location;
    string phone;
    Shop(string n, string l, string p) {
        name = n;
        location = l;
        phone = p;
    }
};

class DeliverySystem {
private:
    vector<Customer> customers;
    vector<Shop> shops;
public:
    void addCustomer(string name, string address, string phone) {
        customers.push_back(Customer(name, address, phone));
    }

    void addShop(string name, string location, string phone) {
        shops.push_back(Shop(name, location, phone));
    }

    void deleteCustomer(string name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }

    void deleteShop(string name) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->name == name) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateCustomer(string oldName, string name, string address, string phone) {
        for (auto &customer : customers) {
            if (customer.name == oldName) {
                customer.name = name;
                customer.address = address;
                customer.phone = phone;
            }
        }
    }

    void updateShop(string oldName, string name, string location, string phone) {
        for (auto &shop : shops) {
            if (shop.name == oldName) {
                shop.name = name;
                shop.location = location;
                shop.phone = phone;
            }
        }
    }

    Customer* searchCustomer(string name) {
        for (auto &customer : customers) {
            if (customer.name == name) {
                return &customer;
            }
        }
        return nullptr;
    }

    Shop* searchShop(string name) {
        for (auto &shop : shops) {
            if (shop.name == name) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "Customer: " << customer.name << ", Address: " << customer.address << ", Phone: " << customer.phone << endl;
        }
    }

    void displayShops() {
        for (const auto &shop : shops) {
            cout << "Shop: " << shop.name << ", Location: " << shop.location << ", Phone: " << shop.phone << endl;
        }
    }
};

int main() {
    DeliverySystem system;
    system.addCustomer("John Doe", "123 Elm St", "555-1234");
    system.addShop("The Drink Shop", "456 Oak St", "555-5678");

    system.displayCustomers();
    system.displayShops();

    system.updateCustomer("John Doe", "John Smith", "789 Pine St", "555-9876");
    system.deleteShop("The Drink Shop");

    system.displayCustomers();
    system.displayShops();

    return 0;
}