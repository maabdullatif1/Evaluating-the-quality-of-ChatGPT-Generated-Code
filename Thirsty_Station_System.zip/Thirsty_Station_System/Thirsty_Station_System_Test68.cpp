#include <iostream>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string address;
};

struct Shop {
    int id;
    std::string name;
    std::string location;
};

class DeliveryService {
    Customer customers[100];
    Shop shops[100];
    int customerCount;
    int shopCount;

public:
    DeliveryService() : customerCount(0), shopCount(0) {}

    void addCustomer(int id, const std::string& name, const std::string& address) {
        if (customerCount < 100) {
            customers[customerCount++] = {id, name, address};
        }
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                for (int j = i; j < customerCount - 1; ++j) {
                    customers[j] = customers[j + 1];
                }
                --customerCount;
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& address) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i].name = name;
                customers[i].address = address;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                std::cout << "Customer ID: " << customers[i].id
                          << ", Name: " << customers[i].name
                          << ", Address: " << customers[i].address << "\n";
                return;
            }
        }
        std::cout << "Customer not found\n";
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; ++i) {
            std::cout << "Customer ID: " << customers[i].id
                      << ", Name: " << customers[i].name
                      << ", Address: " << customers[i].address << "\n";
        }
    }
    
    void addShop(int id, const std::string& name, const std::string& location) {
        if (shopCount < 100) {
            shops[shopCount++] = {id, name, location};
        }
    }

    void deleteShop(int id) {
        for (int i = 0; i < shopCount; ++i) {
            if (shops[i].id == id) {
                for (int j = i; j < shopCount - 1; ++j) {
                    shops[j] = shops[j + 1];
                }
                --shopCount;
                break;
            }
        }
    }

    void updateShop(int id, const std::string& name, const std::string& location) {
        for (int i = 0; i < shopCount; ++i) {
            if (shops[i].id == id) {
                shops[i].name = name;
                shops[i].location = location;
                break;
            }
        }
    }

    void searchShop(int id) {
        for (int i = 0; i < shopCount; ++i) {
            if (shops[i].id == id) {
                std::cout << "Shop ID: " << shops[i].id
                          << ", Name: " << shops[i].name
                          << ", Location: " << shops[i].location << "\n";
                return;
            }
        }
        std::cout << "Shop not found\n";
    }

    void displayShops() {
        for (int i = 0; i < shopCount; ++i) {
            std::cout << "Shop ID: " << shops[i].id
                      << ", Name: " << shops[i].name
                      << ", Location: " << shops[i].location << "\n";
        }
    }
};

int main() {
    DeliveryService service;
    service.addCustomer(1, "Alice", "123 Wonderland");
    service.addCustomer(2, "Bob", "456 Fantasy Ave");
    service.displayCustomers();
    service.updateCustomer(1, "Alice Wonderland", "789 Imagination St");
    service.searchCustomer(1);
    service.deleteCustomer(2);
    service.displayCustomers();
    service.addShop(1, "Cool Drinks", "Downtown");
    service.addShop(2, "Juice Bar", "Uptown");
    service.displayShops();
    service.updateShop(1, "Cooler Drinks", "New Downtown");
    service.searchShop(1);
    service.deleteShop(2);
    service.displayShops();
    return 0;
}