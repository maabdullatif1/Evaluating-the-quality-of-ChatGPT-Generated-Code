#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string address;
};

struct Shop {
    int id;
    std::string name;
    std::string location;
};

class DeliveryService {
private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;

    int findCustomerById(int id) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) return i;
        }
        return -1;
    }
    
    int findShopById(int id) {
        for (size_t i = 0; i < shops.size(); ++i) {
            if (shops[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCustomer(int id, std::string name, std::string address) {
        if (findCustomerById(id) == -1) {
            customers.push_back({id, name, address});
        }
    }

    void deleteCustomer(int id) {
        int index = findCustomerById(id);
        if (index != -1) {
            customers.erase(customers.begin() + index);
        }
    }

    void updateCustomer(int id, std::string name, std::string address) {
        int index = findCustomerById(id);
        if (index != -1) {
            customers[index].name = name;
            customers[index].address = address;
        }
    }

    Customer searchCustomer(int id) {
        int index = findCustomerById(id);
        if (index != -1) {
            return customers[index];
        }
        return {-1, "", ""};
    }

    void displayAllCustomers() {
        for (const auto &cust : customers) {
            std::cout << "ID: " << cust.id << ", Name: " << cust.name << ", Address: " << cust.address << std::endl;
        }
    }

    void addShop(int id, std::string name, std::string location) {
        if (findShopById(id) == -1) {
            shops.push_back({id, name, location});
        }
    }

    void deleteShop(int id) {
        int index = findShopById(id);
        if (index != -1) {
            shops.erase(shops.begin() + index);
        }
    }

    void updateShop(int id, std::string name, std::string location) {
        int index = findShopById(id);
        if (index != -1) {
            shops[index].name = name;
            shops[index].location = location;
        }
    }

    Shop searchShop(int id) {
        int index = findShopById(id);
        if (index != -1) {
            return shops[index];
        }
        return {-1, "", ""};
    }

    void displayAllShops() {
        for (const auto &shop : shops) {
            std::cout << "ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    DeliveryService service;
    
    service.addCustomer(1, "John Doe", "123 Elm Street");
    service.addCustomer(2, "Jane Smith", "456 Maple Avenue");
    service.displayAllCustomers();

    service.updateCustomer(1, "John Doe", "789 Oak Street");
    service.displayAllCustomers();

    service.addShop(1, "Drink Hub", "Downtown");
    service.addShop(2, "Beverage Point", "Midtown");
    service.displayAllShops();

    service.updateShop(1, "Drink Corner", "Uptown");
    service.displayAllShops();

    return 0;
}