#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    std::string name;
    std::string address;
    std::string phone;

    Customer(std::string n, std::string a, std::string p) : name(n), address(a), phone(p) {}

    void updateInfo(std::string n, std::string a, std::string p) {
        name = n;
        address = a;
        phone = p;
    }

    void display() const {
        std::cout << "Customer: " << name << ", Address: " << address << ", Phone: " << phone << std::endl;
    }
};

class Shop {
public:
    std::string name;
    std::string location;
    std::string contact;

    Shop(std::string n, std::string l, std::string c) : name(n), location(l), contact(c) {}

    void updateInfo(std::string n, std::string l, std::string c) {
        name = n;
        location = l;
        contact = c;
    }

    void display() const {
        std::cout << "Shop: " << name << ", Location: " << location << ", Contact: " << contact << std::endl;
    }
};

std::vector<Customer> customers;
std::vector<Shop> shops;

void addCustomer(const std::string& name, const std::string& address, const std::string& phone) {
    customers.emplace_back(name, address, phone);
}

void deleteCustomer(const std::string& name) {
    customers.erase(std::remove_if(customers.begin(), customers.end(),
        [&](Customer& c) { return c.name == name; }), customers.end());
}

void updateCustomer(const std::string& name, const std::string& newName, const std::string& address, const std::string& phone) {
    for (auto& c : customers) {
        if (c.name == name) {
            c.updateInfo(newName, address, phone);
            break;
        }
    }
}

Customer* searchCustomer(const std::string& name) {
    for (auto& c : customers) {
        if (c.name == name) return &c;
    }
    return nullptr;
}

void displayCustomers() {
    for (const auto& c : customers) {
        c.display();
    }
}

void addShop(const std::string& name, const std::string& location, const std::string& contact) {
    shops.emplace_back(name, location, contact);
}

void deleteShop(const std::string& name) {
    shops.erase(std::remove_if(shops.begin(), shops.end(),
        [&](Shop& s) { return s.name == name; }), shops.end());
}

void updateShop(const std::string& name, const std::string& newName, const std::string& location, const std::string& contact) {
    for (auto& s : shops) {
        if (s.name == name) {
            s.updateInfo(newName, location, contact);
            break;
        }
    }
}

Shop* searchShop(const std::string& name) {
    for (auto& s : shops) {
        if (s.name == name) return &s;
    }
    return nullptr;
}

void displayShops() {
    for (const auto& s : shops) {
        s.display();
    }
}

int main() {
    addCustomer("John Doe", "123 Main St", "555-5555");
    addCustomer("Jane Doe", "456 Elm St", "555-1234");
    
    addShop("Cool Drinks", "789 Maple Ave", "555-6789");
    addShop("Hot Brews", "321 Oak St", "555-4321");
    
    displayCustomers();
    displayShops();
    
    updateCustomer("John Doe", "John Smith", "123 Main St", "555-5555");
    updateShop("Cool Drinks", "Cooler Drinks", "789 Maple Ave", "555-6789");
    
    displayCustomers();
    displayShops();
    
    deleteCustomer("Jane Doe");
    deleteShop("Hot Brews");
    
    displayCustomers();
    displayShops();

    return 0;
}