#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string address;
    
    Customer(int id, std::string name, std::string address) : id(id), name(name), address(address) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string address;

    Shop(int id, std::string name, std::string address) : id(id), name(name), address(address) {}
};

std::vector<Customer> customers;
std::vector<Shop> shops;

void addCustomer(int id, std::string name, std::string address) {
    customers.push_back(Customer(id, name, address));
}

void deleteCustomer(int id) {
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            break;
        }
    }
}

void updateCustomer(int id, std::string name, std::string address) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            customer.name = name;
            customer.address = address;
            break;
        }
    }
}

void searchCustomer(int id) {
    for (auto& customer : customers) {
        if (customer.id == id) {
            std::cout << "Customer found: ID=" << customer.id << " Name=" << customer.name << " Address=" << customer.address << std::endl;
            return;
        }
    }
    std::cout << "Customer not found" << std::endl;
}

void displayCustomers() {
    for (auto& customer : customers) {
        std::cout << "ID=" << customer.id << " Name=" << customer.name << " Address=" << customer.address << std::endl;
    }
}

void addShop(int id, std::string name, std::string address) {
    shops.push_back(Shop(id, name, address));
}

void deleteShop(int id) {
    for (auto it = shops.begin(); it != shops.end(); ++it) {
        if (it->id == id) {
            shops.erase(it);
            break;
        }
    }
}

void updateShop(int id, std::string name, std::string address) {
    for (auto& shop : shops) {
        if (shop.id == id) {
            shop.name = name;
            shop.address = address;
            break;
        }
    }
}

void searchShop(int id) {
    for (auto& shop : shops) {
        if (shop.id == id) {
            std::cout << "Shop found: ID=" << shop.id << " Name=" << shop.name << " Address=" << shop.address << std::endl;
            return;
        }
    }
    std::cout << "Shop not found" << std::endl;
}

void displayShops() {
    for (auto& shop : shops) {
        std::cout << "ID=" << shop.id << " Name=" << shop.name << " Address=" << shop.address << std::endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "123 Elm Street");
    addCustomer(2, "Jane Smith", "456 Oak Avenue");
    displayCustomers();
    
    addShop(1, "Best Drinks", "789 Pine Road");
    addShop(2, "Cool Drinks", "101 Maple Street");
    displayShops();
    
    searchCustomer(1);
    searchShop(2);
    
    updateCustomer(1, "John A. Doe", "321 Elm Street");
    updateShop(1, "Best Drinks Shop", "987 Pine Road");
    
    displayCustomers();
    displayShops();
    
    deleteCustomer(2);
    deleteShop(2);
    
    displayCustomers();
    displayShops();

    return 0;
}