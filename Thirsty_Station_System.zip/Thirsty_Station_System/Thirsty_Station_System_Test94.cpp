#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string address;
    
    Customer(int id, std::string name, std::string address)
        : id(id), name(name), address(address) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;
    
    Shop(int id, std::string name, std::string location)
        : id(id), name(name), location(location) {}
};

class System {
private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;
    int customer_id_counter = 1;
    int shop_id_counter = 1;
    
public:
    void addCustomer(std::string name, std::string address) {
        customers.push_back(Customer(customer_id_counter++, name, address));
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, std::string name, std::string address) {
        for (auto &c : customers) {
            if (c.id == id) {
                c.name = name;
                c.address = address;
            }
        }
    }

    void searchCustomer(int id) {
        for (auto &c : customers) {
            if (c.id == id) {
                std::cout << "Customer ID: " << c.id << ", Name: " << c.name << ", Address: " << c.address << std::endl;
                return;
            }
        }
        std::cout << "Customer not found" << std::endl;
    }

    void displayCustomers() {
        for (auto &c : customers) {
            std::cout << "Customer ID: " << c.id << ", Name: " << c.name << ", Address: " << c.address << std::endl;
        }
    }
    
    void addShop(std::string name, std::string location) {
        shops.push_back(Shop(shop_id_counter++, name, location));
    }
    
    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }
    
    void updateShop(int id, std::string name, std::string location) {
        for (auto &s : shops) {
            if (s.id == id) {
                s.name = name;
                s.location = location;
            }
        }
    }

    void searchShop(int id) {
        for (auto &s : shops) {
            if (s.id == id) {
                std::cout << "Shop ID: " << s.id << ", Name: " << s.name << ", Location: " << s.location << std::endl;
                return;
            }
        }
        std::cout << "Shop not found" << std::endl;
    }

    void displayShops() {
        for (auto &s : shops) {
            std::cout << "Shop ID: " << s.id << ", Name: " << s.name << ", Location: " << s.location << std::endl;
        }
    }
};

int main() {
    System system;
    system.addCustomer("John Doe", "123 Elm Street");
    system.addCustomer("Jane Smith", "456 Oak Avenue");
    system.displayCustomers();

    system.addShop("Cool Beverages", "Downtown");
    system.addShop("Chill Drinks", "Uptown");
    system.displayShops();

    system.updateCustomer(1, "Johnathan Doe", "789 Pine Road");
    system.displayCustomers();

    system.deleteCustomer(2);
    system.displayCustomers();

    system.searchCustomer(1);

    system.updateShop(1, "Awesome Beverages", "New Downtown");
    system.displayShops();

    system.deleteShop(2);
    system.displayShops();

    system.searchShop(1);

    return 0;
}