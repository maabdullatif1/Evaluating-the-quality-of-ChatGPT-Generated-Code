#include <iostream>
#include <vector>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::string;
using std::vector;

class Customer {
public:
    string name;
    string address;
    string phone;

    Customer(string n, string a, string p) : name(n), address(a), phone(p) {}
};

class Shop {
public:
    string name;
    string location;
    string contact;

    Shop(string n, string l, string c) : name(n), location(l), contact(c) {}
};

class DeliveryServiceSystem {
private:
    vector<Customer> customers;
    vector<Shop> shops;

public:
    void addCustomer(const string& name, const string& address, const string& phone) {
        customers.emplace_back(name, address, phone);
    }

    void deleteCustomer(const string& name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(const string& name, const string& newAddress, const string& newPhone) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                customer.address = newAddress;
                customer.phone = newPhone;
                break;
            }
        }
    }

    void searchCustomer(const string& name) {
        for (const auto& customer : customers) {
            if (customer.name == name) {
                cout << "Customer found: " << customer.name << ", " 
                     << customer.address << ", " << customer.phone << endl;
                return;
            }
        }
        cout << "Customer not found" << endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << customer.name << ", " << customer.address << ", " << customer.phone << endl;
        }
    }

    void addShop(const string& name, const string& location, const string& contact) {
        shops.emplace_back(name, location, contact);
    }

    void deleteShop(const string& name) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->name == name) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(const string& name, const string& newLocation, const string& newContact) {
        for (auto& shop : shops) {
            if (shop.name == name) {
                shop.location = newLocation;
                shop.contact = newContact;
                break;
            }
        }
    }

    void searchShop(const string& name) {
        for (const auto& shop : shops) {
            if (shop.name == name) {
                cout << "Shop found: " << shop.name << ", " 
                     << shop.location << ", " << shop.contact << endl;
                return;
            }
        }
        cout << "Shop not found" << endl;
    }

    void displayShops() {
        for (const auto& shop : shops) {
            cout << shop.name << ", " << shop.location << ", " << shop.contact << endl;
        }
    }
};

int main() {
    DeliveryServiceSystem system;
    
    system.addCustomer("Alice", "123 Main St", "123-456-7890");
    system.addCustomer("Bob", "456 Elm St", "098-765-4321");
    system.displayCustomers();
    
    system.updateCustomer("Alice", "321 Maple St", "111-222-3333");
    system.searchCustomer("Alice");
    
    system.addShop("DrinkHub", "City Center", "555-0199");
    system.addShop("BeverageBarn", "Downtown", "555-0123");
    system.displayShops();
    
    system.updateShop("DrinkHub", "Suburbs", "555-0200");
    system.searchShop("DrinkHub");

    return 0;
}