#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string address;
    std::string phone;
    
    Customer(int id, std::string name, std::string address, std::string phone)
        : id(id), name(name), address(address), phone(phone) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;
    
    Shop(int id, std::string name, std::string location) 
        : id(id), name(name), location(location) {}
};

class System {
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void add_customer(int id, std::string name, std::string address, std::string phone) {
        customers.push_back(Customer(id, name, address, phone));
    }

    void delete_customer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void update_customer(int id, std::string name, std::string address, std::string phone) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                customer.phone = phone;
                break;
            }
        }
    }

    Customer* search_customer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void display_customers() {
        for (auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name 
                      << ", Address: " << customer.address 
                      << ", Phone: " << customer.phone << std::endl;
        }
    }

    void add_shop(int id, std::string name, std::string location) {
        shops.push_back(Shop(id, name, location));
    }

    void delete_shop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void update_shop(int id, std::string name, std::string location) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                break;
            }
        }
    }

    Shop* search_shop(int id) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

    void display_shops() {
        for (auto& shop : shops) {
            std::cout << "ID: " << shop.id << ", Name: " << shop.name 
                      << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    System system;
    system.add_customer(1, "Alice", "123 Wonderland", "123-456-7890");
    system.add_customer(2, "Bob", "456 Nowhere Rd", "987-654-3210");
    system.add_shop(1, "Shop A", "Central Park");
    system.add_shop(2, "Shop B", "East End");

    system.display_customers();
    system.display_shops();

    Customer* customer = system.search_customer(1);
    if (customer) {
        std::cout << "Found Customer: " << customer->name << std::endl;
    }

    Shop* shop = system.search_shop(1);
    if (shop) {
        std::cout << "Found Shop: " << shop->name << std::endl;
    }

    system.update_customer(1, "Alice Smith", "999 Wonderland", "000-111-2222");
    system.update_shop(1, "Shop A+", "Downtown");
    system.display_customers();
    system.display_shops();

    system.delete_customer(2);
    system.delete_shop(2);
    system.display_customers();
    system.display_shops();

    return 0;
}