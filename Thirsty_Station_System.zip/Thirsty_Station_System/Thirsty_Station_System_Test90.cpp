#include <iostream>
#include <string>
#include <vector>

class Customer {
public:
    int id;
    std::string name;
    std::string address;
    std::string phone;

    Customer(int i, std::string n, std::string a, std::string p)
        : id(i), name(n), address(a), phone(p) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;
    std::string contact;

    Shop(int i, std::string n, std::string l, std::string c)
        : id(i), name(n), location(l), contact(c) {}
};

class DeliveryServiceSystem {
private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(int id, std::string name, std::string address, std::string phone) {
        customers.push_back(Customer(id, name, address, phone));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string address, std::string phone) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                customer.phone = phone;
                return;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer Found - ID: " << customer.id
                          << ", Name: " << customer.name
                          << ", Address: " << customer.address 
                          << ", Phone: " << customer.phone << std::endl;
                return;
            }
        }
        std::cout << "Customer not found." << std::endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id
                      << ", Name: " << customer.name
                      << ", Address: " << customer.address
                      << ", Phone: " << customer.phone << std::endl;
        }
    }

    void addShop(int id, std::string name, std::string location, std::string contact) {
        shops.push_back(Shop(id, name, location, contact));
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                return;
            }
        }
    }

    void updateShop(int id, std::string name, std::string location, std::string contact) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                shop.contact = contact;
                return;
            }
        }
    }

    void searchShop(int id) {
        for (const auto& shop : shops) {
            if (shop.id == id) {
                std::cout << "Shop Found - ID: " << shop.id
                          << ", Name: " << shop.name
                          << ", Location: " << shop.location
                          << ", Contact: " << shop.contact << std::endl;
                return;
            }
        }
        std::cout << "Shop not found." << std::endl;
    }

    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "ID: " << shop.id
                      << ", Name: " << shop.name
                      << ", Location: " << shop.location
                      << ", Contact: " << shop.contact << std::endl;
        }
    }
};

int main() {
    DeliveryServiceSystem service;

    service.addCustomer(1, "Alice", "123 Park Ave", "555-0147");
    service.addCustomer(2, "Bob", "456 Elm St", "555-0189");

    service.addShop(1, "Shop A", "Downtown", "555-0100");
    service.addShop(2, "Shop B", "Uptown", "555-0101");

    std::cout << "Displaying Customers:" << std::endl;
    service.displayCustomers();

    std::cout << "Displaying Shops:" << std::endl;
    service.displayShops();
    
    service.searchCustomer(1);
    service.searchShop(2);

    service.updateCustomer(1, "Alice Smith", "123 Park Ave", "555-0147");
    service.updateShop(1, "Shop A+", "Central Downtown", "555-0100");

    service.deleteCustomer(2);
    service.deleteShop(2);
    
    std::cout << "Updated Customers:" << std::endl;
    service.displayCustomers();
    
    std::cout << "Updated Shops:" << std::endl;
    service.displayShops();

    return 0;
}