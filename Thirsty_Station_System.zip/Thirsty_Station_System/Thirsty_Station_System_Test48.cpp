#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string address;
    string phone;
};

struct Shop {
    int id;
    string name;
    string location;
    string contact;
};

Customer customers[100];
Shop shops[100];
int customerCount = 0;
int shopCount = 0;

void addCustomer(int id, string name, string address, string phone) {
    customers[customerCount++] = {id, name, address, phone};
}

void addShop(int id, string name, string location, string contact) {
    shops[shopCount++] = {id, name, location, contact};
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            customers[i] = customers[--customerCount];
            break;
        }
    }
}

void deleteShop(int id) {
    for (int i = 0; i < shopCount; ++i) {
        if (shops[i].id == id) {
            shops[i] = shops[--shopCount];
            break;
        }
    }
}

void updateCustomer(int id, string name, string address, string phone) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            customers[i] = {id, name, address, phone};
            break;
        }
    }
}

void updateShop(int id, string name, string location, string contact) {
    for (int i = 0; i < shopCount; ++i) {
        if (shops[i].id == id) {
            shops[i] = {id, name, location, contact};
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

Shop* searchShop(int id) {
    for (int i = 0; i < shopCount; ++i) {
        if (shops[i].id == id) {
            return &shops[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; ++i) {
        cout << "ID: " << customers[i].id 
             << " Name: " << customers[i].name 
             << " Address: " << customers[i].address 
             << " Phone: " << customers[i].phone << endl;
    }
}

void displayShops() {
    for (int i = 0; i < shopCount; ++i) {
        cout << "ID: " << shops[i].id 
             << " Name: " << shops[i].name 
             << " Location: " << shops[i].location 
             << " Contact: " << shops[i].contact << endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "123 Main St", "555-1234");
    addCustomer(2, "Jane Smith", "456 Elm St", "555-5678");
    addShop(1, "Beverage Haven", "Downtown", "contact@beveragehaven.com");
    addShop(2, "Drink Spot", "Uptown", "contact@drinkspot.com");

    displayCustomers();
    displayShops();

    updateCustomer(1, "John Doe", "789 Oak St", "555-0000");
    updateShop(2, "Drink Spot", "Central Plaza", "support@drinkspot.com");

    displayCustomers();
    displayShops();

    deleteCustomer(2);
    deleteShop(1);

    displayCustomers();
    displayShops();

    return 0;
}