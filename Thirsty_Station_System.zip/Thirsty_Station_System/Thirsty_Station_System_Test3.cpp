#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

class DrinksDeliveryService {
private:
    vector<Customer> customers;
    vector<Shop> shops;

    template <typename T>
    void displayCollection(const vector<T>& collection) {
        for (const auto& item : collection) {
            cout << "ID: " << item.id << ", Name: " << item.name;
            if constexpr (is_same<T, Customer>::value) {
                cout << ", Address: " << item.address;
            } else {
                cout << ", Location: " << item.location;
            }
            cout << endl;
        }
    }

public:
    void addCustomer(int id, const string& name, const string& address) {
        customers.push_back({id, name, address});
    }

    void addShop(int id, const string& name, const string& location) {
        shops.push_back({id, name, location});
    }

    void deleteCustomer(int id) {
        customers.erase(remove_if(customers.begin(), customers.end(), [id](const Customer& c) { return c.id == id; }), customers.end());
    }

    void deleteShop(int id) {
        shops.erase(remove_if(shops.begin(), shops.end(), [id](const Shop& s) { return s.id == id; }), shops.end());
    }

    void updateCustomer(int id, const string& name, const string& address) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                break;
            }
        }
    }

    void updateShop(int id, const string& name, const string& location) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Shop* searchShop(int id) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        displayCollection(customers);
    }

    void displayShops() {
        displayCollection(shops);
    }
};

int main() {
    DrinksDeliveryService service;
    service.addCustomer(1, "Alice", "123 Main St");
    service.addCustomer(2, "Bob", "456 Elm St");
    service.addShop(101, "Cool Drinks", "789 Oak St");
    service.addShop(102, "Hot Brews", "321 Pine St");

    service.displayCustomers();
    service.displayShops();

    service.updateCustomer(1, "Alice Wonderland", "123 Main St Apt 4");
    service.updateShop(101, "Cooler Drinks", "789 Oak St Suite 10");

    if (Customer* c = service.searchCustomer(1)) {
        cout << "Found Customer: " << c->name << endl;
    }

    if (Shop* s = service.searchShop(101)) {
        cout << "Found Shop: " << s->name << endl;
    }

    service.deleteCustomer(2);
    service.deleteShop(102);

    service.displayCustomers();
    service.displayShops();

    return 0;
}