#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Address {
public:
    string street;
    string city;
    string zipCode;

    Address(string street, string city, string zipCode)
        : street(street), city(city), zipCode(zipCode) {}
};

class Customer {
public:
    string id;
    string name;
    Address address;

    Customer(string id, string name, Address address)
        : id(id), name(name), address(address) {}
};

class Shop {
public:
    string id;
    string name;
    Address location;

    Shop(string id, string name, Address location)
        : id(id), name(name), location(location) {}
};

class DrinksDeliveryService {
private:
    vector<Customer> customers;
    vector<Shop> shops;

public:
    void addCustomer(string id, string name, Address address) {
        customers.push_back(Customer(id, name, address));
    }

    void deleteCustomer(string id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(string id, string newName, Address newAddress) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = newName;
                customer.address = newAddress;
                break;
            }
        }
    }

    void searchCustomer(string id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                cout << "Customer Found: " << customer.name << ", Address: "
                     << customer.address.street << ", " << customer.address.city
                     << ", " << customer.address.zipCode << endl;
                return;
            }
        }
        cout << "Customer not found." << endl;
    }

    void displayCustomers() {
        for (auto &customer : customers) {
            cout << "ID: " << customer.id << ", Name: " << customer.name
                 << ", Address: " << customer.address.street << ", "
                 << customer.address.city << ", " << customer.address.zipCode << endl;
        }
    }

    void addShop(string id, string name, Address location) {
        shops.push_back(Shop(id, name, location));
    }

    void deleteShop(string id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(string id, string newName, Address newLocation) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                shop.name = newName;
                shop.location = newLocation;
                break;
            }
        }
    }

    void searchShop(string id) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                cout << "Shop Found: " << shop.name << ", Location: "
                     << shop.location.street << ", " << shop.location.city
                     << ", " << shop.location.zipCode << endl;
                return;
            }
        }
        cout << "Shop not found." << endl;
    }

    void displayShops() {
        for (auto &shop : shops) {
            cout << "ID: " << shop.id << ", Name: " << shop.name
                 << ", Location: " << shop.location.street << ", "
                 << shop.location.city << ", " << shop.location.zipCode << endl;
        }
    }
};

int main() {
    DrinksDeliveryService service;
    service.addCustomer("1", "Alice", Address("123 Elm St", "Metropolis", "12345"));
    service.addCustomer("2", "Bob", Address("456 Oak St", "Gotham", "54321"));

    service.addShop("1", "Shop A", Address("789 Pine St", "Metropolis", "12345"));
    service.addShop("2", "Shop B", Address("135 Maple St", "Gotham", "54321"));

    service.displayCustomers();
    service.displayShops();

    service.searchCustomer("1");
    service.searchShop("2");

    service.updateCustomer("1", "Alice Smith", Address("123 Elm St", "Central City", "67890"));
    service.updateShop("2", "Shop B Updated", Address("246 Birch St", "Star City", "09876"));

    service.displayCustomers();
    service.displayShops();

    service.deleteCustomer("2");
    service.deleteShop("1");

    service.displayCustomers();
    service.displayShops();

    return 0;
}