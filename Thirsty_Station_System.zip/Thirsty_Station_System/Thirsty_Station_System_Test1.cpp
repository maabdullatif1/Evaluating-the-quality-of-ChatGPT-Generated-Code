#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    string name;
    string address;
};

struct Shop {
    string name;
    string location;
};

class DeliveryService {
public:
    void addCustomer(const string& name, const string& address) {
        customers.push_back({name, address});
    }

    void deleteCustomer(const string& name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                return;
            }
        }
    }

    void updateCustomer(const string& name, const string& newName, const string& newAddress) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                customer.name = newName;
                customer.address = newAddress;
            }
        }
    }

    Customer* searchCustomer(const string& name) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Name: " << customer.name << ", Address: " << customer.address << endl;
        }
    }

    void addShop(const string& name, const string& location) {
        shops.push_back({name, location});
    }

    void deleteShop(const string& name) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->name == name) {
                shops.erase(it);
                return;
            }
        }
    }

    void updateShop(const string& name, const string& newName, const string& newLocation) {
        for (auto& shop : shops) {
            if (shop.name == name) {
                shop.name = newName;
                shop.location = newLocation;
            }
        }
    }

    Shop* searchShop(const string& name) {
        for (auto& shop : shops) {
            if (shop.name == name) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayShops() {
        for (const auto& shop : shops) {
            cout << "Name: " << shop.name << ", Location: " << shop.location << endl;
        }
    }

private:
    vector<Customer> customers;
    vector<Shop> shops;
};

int main() {
    DeliveryService service;

    service.addCustomer("Alice", "123 Maple St");
    service.addCustomer("Bob", "456 Oak St");

    service.addShop("Cool Drinks", "789 Spruce St");
    service.addShop("Thirst Quench", "321 Pine St");

    cout << "Customers:" << endl;
    service.displayCustomers();

    cout << "Shops:" << endl;
    service.displayShops();

    service.updateCustomer("Alice", "Alicia", "987 Willow St");
    service.updateShop("Cool Drinks", "Cooler Drinks", "654 Birch St");

    cout << "Updated Customers:" << endl;
    service.displayCustomers();

    cout << "Updated Shops:" << endl;
    service.displayShops();

    return 0;
}