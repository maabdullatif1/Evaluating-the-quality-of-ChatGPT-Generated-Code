#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string address;
    
    Customer(int i, const std::string& n, const std::string& a) : id(i), name(n), address(a) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;
    
    Shop(int i, const std::string& n, const std::string& l) : id(i), name(n), location(l) {}
};

class DeliveryService {
private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(int id, const std::string& name, const std::string& address) {
        customers.push_back(Customer(id, name, address));
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, const std::string& name, const std::string& address) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
            }
        }
    }
    
    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name 
                          << ", Address: " << customer.address << std::endl;
            }
        }
    }
    
    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name 
                      << ", Address: " << customer.address << std::endl;
        }
    }
    
    void addShop(int id, const std::string& name, const std::string& location) {
        shops.push_back(Shop(id, name, location));
    }
    
    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }
    
    void updateShop(int id, const std::string& name, const std::string& location) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
            }
        }
    }
    
    void searchShop(int id) {
        for (const auto& shop : shops) {
            if (shop.id == id) {
                std::cout << "Shop ID: " << shop.id << ", Name: " << shop.name 
                          << ", Location: " << shop.location << std::endl;
            }
        }
    }
    
    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "Shop ID: " << shop.id << ", Name: " << shop.name 
                      << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    DeliveryService service;
    service.addCustomer(1, "John Doe", "123 Main St");
    service.addCustomer(2, "Jane Smith", "456 Elm St");
    service.displayCustomers();
    
    service.updateCustomer(1, "John Doe", "789 Oak St");
    service.searchCustomer(1);
    
    service.addShop(1, "Drink Shop 1", "Downtown");
    service.addShop(2, "Drink Shop 2", "Uptown");
    service.displayShops();
    
    service.updateShop(1, "Drink Shop 1", "Midtown");
    service.searchShop(1);
    
    service.deleteCustomer(2);
    service.deleteShop(2);
    service.displayCustomers();
    service.displayShops();

    return 0;
}