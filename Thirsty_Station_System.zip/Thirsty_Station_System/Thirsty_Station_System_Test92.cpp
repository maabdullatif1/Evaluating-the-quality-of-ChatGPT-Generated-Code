#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

Customer customers[100];
Shop shops[100];
int customerCount = 0;
int shopCount = 0;

void addCustomer(int id, string name, string address) {
    customers[customerCount++] = Customer{id, name, address};
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; ++j) {
                customers[j] = customers[j + 1];
            }
            --customerCount;
            break;
        }
    }
}

void updateCustomer(int id, string name, string address) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            customers[i].name = name;
            customers[i].address = address;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; ++i) {
        cout << "ID: " << customers[i].id << ", Name: " << customers[i].name
             << ", Address: " << customers[i].address << endl;
    }
}

void addShop(int id, string name, string location) {
    shops[shopCount++] = Shop{id, name, location};
}

void deleteShop(int id) {
    for (int i = 0; i < shopCount; ++i) {
        if (shops[i].id == id) {
            for (int j = i; j < shopCount - 1; ++j) {
                shops[j] = shops[j + 1];
            }
            --shopCount;
            break;
        }
    }
}

void updateShop(int id, string name, string location) {
    for (int i = 0; i < shopCount; ++i) {
        if (shops[i].id == id) {
            shops[i].name = name;
            shops[i].location = location;
            break;
        }
    }
}

Shop* searchShop(int id) {
    for (int i = 0; i < shopCount; ++i) {
        if (shops[i].id == id) {
            return &shops[i];
        }
    }
    return nullptr;
}

void displayShops() {
    for (int i = 0; i < shopCount; ++i) {
        cout << "ID: " << shops[i].id << ", Name: " << shops[i].name
             << ", Location: " << shops[i].location << endl;
    }
}

int main() {
    addCustomer(1, "Alice", "123 Street A");
    addCustomer(2, "Bob", "456 Street B");
    displayCustomers();
    updateCustomer(1, "Alice Chan", "123 Street A");
    displayCustomers();
    deleteCustomer(2);
    displayCustomers();

    addShop(1, "Cool Drinks", "Center Plaza");
    addShop(2, "Mega Beverages", "Downtown");
    displayShops();
    updateShop(1, "Cooler Drinks", "Center Plaza");
    displayShops();
    deleteShop(2);
    displayShops();

    return 0;
}