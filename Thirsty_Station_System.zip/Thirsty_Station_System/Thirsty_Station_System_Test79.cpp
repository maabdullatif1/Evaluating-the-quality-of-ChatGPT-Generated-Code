#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string address;
    string phone;
};

struct Shop {
    int id;
    string name;
    string location;
    string phone;
};

class DrinkDeliveryService {
    Customer customers[100];
    Shop shops[100];
    int customerCount;
    int shopCount;

public:
    DrinkDeliveryService() : customerCount(0), shopCount(0) {}

    void addCustomer(int id, string name, string address, string phone) {
        customers[customerCount++] = {id, name, address, phone};
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                for (int j = i; j < customerCount - 1; ++j) {
                    customers[j] = customers[j + 1];
                }
                --customerCount;
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string address, string phone) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                customers[i] = {id, name, address, phone};
                break;
            }
        }
    }

    const Customer* searchCustomer(int id) {
        for (int i = 0; i < customerCount; ++i) {
            if (customers[i].id == id) {
                return &customers[i];
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; ++i) {
            cout << "ID: " << customers[i].id << ", Name: " << customers[i].name
                 << ", Address: " << customers[i].address
                 << ", Phone: " << customers[i].phone << endl;
        }
    }

    void addShop(int id, string name, string location, string phone) {
        shops[shopCount++] = {id, name, location, phone};
    }

    void deleteShop(int id) {
        for (int i = 0; i < shopCount; ++i) {
            if (shops[i].id == id) {
                for (int j = i; j < shopCount - 1; ++j) {
                    shops[j] = shops[j + 1];
                }
                --shopCount;
                break;
            }
        }
    }

    void updateShop(int id, string name, string location, string phone) {
        for (int i = 0; i < shopCount; ++i) {
            if (shops[i].id == id) {
                shops[i] = {id, name, location, phone};
                break;
            }
        }
    }

    const Shop* searchShop(int id) {
        for (int i = 0; i < shopCount; ++i) {
            if (shops[i].id == id) {
                return &shops[i];
            }
        }
        return nullptr;
    }

    void displayShops() {
        for (int i = 0; i < shopCount; ++i) {
            cout << "ID: " << shops[i].id << ", Name: " << shops[i].name
                 << ", Location: " << shops[i].location
                 << ", Phone: " << shops[i].phone << endl;
        }
    }
};

int main() {
    DrinkDeliveryService service;
    service.addCustomer(1, "Alice", "123 Main St", "555-0100");
    service.addShop(1, "Beverage Paradise", "456 Elm St", "555-0200");
    service.displayCustomers();
    service.displayShops();
    return 0;
}