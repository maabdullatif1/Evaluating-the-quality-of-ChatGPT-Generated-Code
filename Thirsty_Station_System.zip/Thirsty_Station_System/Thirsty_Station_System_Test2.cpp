#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string address;

    Customer(int id, std::string name, std::string address) 
        : id(id), name(name), address(address) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;

    Shop(int id, std::string name, std::string location) 
        : id(id), name(name), location(location) {}
};

class DeliveryService {
    std::vector<Customer> customers;
    std::vector<Shop> shops;
    int customerIdCounter = 1;
    int shopIdCounter = 1;

public:
    void addCustomer(const std::string& name, const std::string& address) {
        customers.push_back(Customer(customerIdCounter++, name, address));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& address) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer Found: " << customer.name << ", " << customer.address << std::endl;
                return;
            }
        }
        std::cout << "Customer not found." << std::endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << std::endl;
        }
    }

    void addShop(const std::string& name, const std::string& location) {
        shops.push_back(Shop(shopIdCounter++, name, location));
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, const std::string& name, const std::string& location) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
            }
        }
    }

    void searchShop(int id) {
        for (const auto& shop : shops) {
            if (shop.id == id) {
                std::cout << "Shop Found: " << shop.name << ", " << shop.location << std::endl;
                return;
            }
        }
        std::cout << "Shop not found." << std::endl;
    }

    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    DeliveryService service;
    service.addCustomer("John Doe", "123 Elm St");
    service.addCustomer("Jane Smith", "456 Maple Ave");

    service.addShop("City Drinks", "Downtown");
    service.addShop("Suburban Liquor", "Suburbia");

    std::cout << "Customers:" << std::endl;
    service.displayCustomers();

    std::cout << "\nShops:" << std::endl;
    service.displayShops();

    return 0;
}