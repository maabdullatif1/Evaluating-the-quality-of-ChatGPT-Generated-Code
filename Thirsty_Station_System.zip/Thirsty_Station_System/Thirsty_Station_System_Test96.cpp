#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    std::string name;
    std::string address;
    std::string phoneNumber;

    Customer(const std::string &n, const std::string &a, const std::string &p)
        : name(n), address(a), phoneNumber(p) {}
};

class Shop {
public:
    std::string name;
    std::string location;

    Shop(const std::string &n, const std::string &l)
        : name(n), location(l) {}
};

class DeliveryService {
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(const std::string &name, const std::string &address, const std::string &phoneNumber) {
        customers.emplace_back(name, address, phoneNumber);
    }

    void deleteCustomer(const std::string &name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(const std::string &name, const std::string &newAddress, const std::string &newPhoneNumber) {
        for (auto &customer : customers) {
            if (customer.name == name) {
                customer.address = newAddress;
                customer.phoneNumber = newPhoneNumber;
                break;
            }
        }
    }

    void searchCustomer(const std::string &name) {
        for (const auto &customer : customers) {
            if (customer.name == name) {
                std::cout << "Customer Found: " << customer.name << ", " << customer.address << ", " 
                          << customer.phoneNumber << "\n";
                return;
            }
        }
        std::cout << "Customer Not Found\n";
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "Customer: " << customer.name << ", Address: " 
                      << customer.address << ", Phone: " << customer.phoneNumber << "\n";
        }
    }

    void addShop(const std::string &name, const std::string &location) {
        shops.emplace_back(name, location);
    }

    void deleteShop(const std::string &name) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->name == name) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(const std::string &name, const std::string &newLocation) {
        for (auto &shop : shops) {
            if (shop.name == name) {
                shop.location = newLocation;
                break;
            }
        }
    }

    void searchShop(const std::string &name) {
        for (const auto &shop : shops) {
            if (shop.name == name) {
                std::cout << "Shop Found: " << shop.name << ", " << shop.location << "\n";
                return;
            }
        }
        std::cout << "Shop Not Found\n";
    }

    void displayShops() {
        for (const auto &shop : shops) {
            std::cout << "Shop: " << shop.name << ", Location: " << shop.location << "\n";
        }
    }
};

int main() {
    DeliveryService service;
    service.addCustomer("Alice", "123 Street", "555-1234");
    service.addCustomer("Bob", "456 Avenue", "555-5678");
    service.displayCustomers();
    service.searchCustomer("Alice");

    service.addShop("Best Drinks", "Downtown");
    service.addShop("Chilled Outlet", "Suburbs");
    service.displayShops();
    service.searchShop("Best Drinks");

    service.updateCustomer("Alice", "789 New Street", "555-4321");
    service.updateShop("Best Drinks", "Central City");

    service.displayCustomers();
    service.displayShops();

    service.deleteCustomer("Bob");
    service.deleteShop("Chilled Outlet");

    service.displayCustomers();
    service.displayShops();

    return 0;
}