#include <iostream>
#include <vector>
#include <string>

class Entity {
public:
    std::string name;
    std::string address;
    std::string phone;

    Entity(std::string n, std::string addr, std::string ph) : name(n), address(addr), phone(ph) {}
};

class Customer : public Entity {
public:
    Customer(std::string n, std::string addr, std::string ph) : Entity(n, addr, ph) {}
};

class Shop : public Entity {
public:
    Shop(std::string n, std::string addr, std::string ph) : Entity(n, addr, ph) {}
};

template <typename T>
class ManagementSystem {
    std::vector<T> entities;

public:
    void add(T entity) {
        entities.push_back(entity);
    }

    void remove(std::string name) {
        for (auto it = entities.begin(); it != entities.end(); ++it) {
            if (it->name == name) {
                entities.erase(it);
                return;
            }
        }
    }

    void update(std::string name, std::string newAddr, std::string newPhone) {
        for (auto &entity : entities) {
            if (entity.name == name) {
                entity.address = newAddr;
                entity.phone = newPhone;
                return;
            }
        }
    }

    T* search(std::string name) {
        for (auto &entity : entities) {
            if (entity.name == name) {
                return &entity;
            }
        }
        return nullptr;
    }

    void display() {
        for (const auto &entity : entities) {
            std::cout << "Name: " << entity.name << ", Address: " << entity.address << ", Phone: " << entity.phone << std::endl;
        }
    }
};

int main() {
    ManagementSystem<Customer> customerSystem;
    ManagementSystem<Shop> shopSystem;

    customerSystem.add(Customer("Alice", "123 Elm St", "555-1234"));
    customerSystem.add(Customer("Bob", "456 Oak St", "555-5678"));

    shopSystem.add(Shop("Drink Shop 1", "789 Pine St", "555-8765"));
    shopSystem.add(Shop("Drink Shop 2", "135 Maple St", "555-4321"));

    std::cout << "Customers:" << std::endl;
    customerSystem.display();

    std::cout << "\nShops:" << std::endl;
    shopSystem.display();

    customerSystem.update("Alice", "321 Elm St", "555-0000");
    shopSystem.remove("Drink Shop 1");

    std::cout << "\nUpdated Customers:" << std::endl;
    customerSystem.display();

    std::cout << "\nUpdated Shops:" << std::endl;
    shopSystem.display();

    return 0;
}