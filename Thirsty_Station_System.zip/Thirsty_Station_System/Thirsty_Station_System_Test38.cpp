#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

class DrinksDeliverySystem {
    vector<Customer> customers;
    vector<Shop> shops;

    Customer* findCustomerById(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Shop* findShopById(int id) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

public:
    void addCustomer(int id, string name, string address) {
        customers.push_back({id, name, address});
    }

    void deleteCustomer(int id) {
        customers.erase(remove_if(customers.begin(), customers.end(),
            [id](Customer& c) { return c.id == id; }), customers.end());
    }

    void updateCustomer(int id, string name, string address) {
        Customer* customer = findCustomerById(id);
        if (customer) {
            customer->name = name;
            customer->address = address;
        }
    }

    void searchCustomer(int id) {
        Customer* customer = findCustomerById(id);
        if (customer) {
            cout << "Customer ID: " << customer->id << ", Name: " << customer->name << ", Address: " << customer->address << endl;
        } else {
            cout << "Customer not found!" << endl;
        }
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "Customer ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << endl;
        }
    }

    void addShop(int id, string name, string location) {
        shops.push_back({id, name, location});
    }

    void deleteShop(int id) {
        shops.erase(remove_if(shops.begin(), shops.end(),
            [id](Shop& s) { return s.id == id; }), shops.end());
    }

    void updateShop(int id, string name, string location) {
        Shop* shop = findShopById(id);
        if (shop) {
            shop->name = name;
            shop->location = location;
        }
    }

    void searchShop(int id) {
        Shop* shop = findShopById(id);
        if (shop) {
            cout << "Shop ID: " << shop->id << ", Name: " << shop->name << ", Location: " << shop->location << endl;
        } else {
            cout << "Shop not found!" << endl;
        }
    }

    void displayShops() {
        for (const auto& shop : shops) {
            cout << "Shop ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << endl;
        }
    }
};

int main() {
    DrinksDeliverySystem system;
    system.addCustomer(1, "Alice", "123 Happy St");
    system.addCustomer(2, "Bob", "456 Joy Rd");
    system.displayCustomers();
    system.updateCustomer(1, "Alice Smith", "123 Happy St, Apt 1");
    system.searchCustomer(1);
    system.deleteCustomer(2);
    system.displayCustomers();

    system.addShop(1, "Tropical Drinks", "789 Sunset Blvd");
    system.addShop(2, "Cool Beverages", "321 Ocean Ave");
    system.displayShops();
    system.updateShop(1, "Tropical Drinks and More", "789 Sunset Blvd");
    system.searchShop(1);
    system.deleteShop(2);
    system.displayShops();

    return 0;
}