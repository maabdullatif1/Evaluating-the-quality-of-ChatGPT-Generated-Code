#include <iostream>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string address;
    std::string phone;
};

struct Shop {
    int id;
    std::string name;
    std::string address;
    std::string phone;
};

const int MAX_ENTRIES = 100;
Customer customers[MAX_ENTRIES];
Shop shops[MAX_ENTRIES];
int customerCount = 0;
int shopCount = 0;

void addCustomer(int id, std::string name, std::string address, std::string phone) {
    if (customerCount < MAX_ENTRIES) {
        customers[customerCount++] = {id, name, address, phone};
    }
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; j++) {
                customers[j] = customers[j + 1];
            }
            customerCount--;
            break;
        }
    }
}

void updateCustomer(int id, std::string name, std::string address, std::string phone) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            customers[i] = {id, name, address, phone};
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; i++) {
        std::cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name
                  << ", Address: " << customers[i].address << ", Phone: " << customers[i].phone << std::endl;
    }
}

void addShop(int id, std::string name, std::string address, std::string phone) {
    if (shopCount < MAX_ENTRIES) {
        shops[shopCount++] = {id, name, address, phone};
    }
}

void deleteShop(int id) {
    for (int i = 0; i < shopCount; i++) {
        if (shops[i].id == id) {
            for (int j = i; j < shopCount - 1; j++) {
                shops[j] = shops[j + 1];
            }
            shopCount--;
            break;
        }
    }
}

void updateShop(int id, std::string name, std::string address, std::string phone) {
    for (int i = 0; i < shopCount; i++) {
        if (shops[i].id == id) {
            shops[i] = {id, name, address, phone};
            break;
        }
    }
}

Shop* searchShop(int id) {
    for (int i = 0; i < shopCount; i++) {
        if (shops[i].id == id) {
            return &shops[i];
        }
    }
    return nullptr;
}

void displayShops() {
    for (int i = 0; i < shopCount; i++) {
        std::cout << "Shop ID: " << shops[i].id << ", Name: " << shops[i].name
                  << ", Address: " << shops[i].address << ", Phone: " << shops[i].phone << std::endl;
    }
}

int main() {
    addCustomer(1, "Alice", "123 Maple St", "555-1234");
    addCustomer(2, "Bob", "456 Oak St", "555-5678");
    addShop(1, "Beverage Hub", "789 Pine St", "555-9999");
    addShop(2, "Drink Station", "159 Elm St", "555-8888");

    std::cout << "Customers:" << std::endl;
    displayCustomers();

    std::cout << "Shops:" << std::endl;
    displayShops();

    updateCustomer(1, "Alice Wonderland", "123 Maple St", "555-1234");
    updateShop(1, "Beverage Central", "789 Pine St", "555-9999");

    std::cout << "Updated Customers:" << std::endl;
    displayCustomers();

    std::cout << "Updated Shops:" << std::endl;
    displayShops();

    deleteCustomer(2);
    deleteShop(2);

    std::cout << "After Deletion - Customers:" << std::endl;
    displayCustomers();

    std::cout << "After Deletion - Shops:" << std::endl;
    displayShops();

    return 0;
}