#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string address;
    
    Customer(int i, std::string n, std::string a) : id(i), name(n), address(a) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;
    
    Shop(int i, std::string n, std::string l) : id(i), name(n), location(l) {}
};

class System {
public:
    std::vector<Customer> customers;
    std::vector<Shop> shops;
    
    void addCustomer(int id, std::string name, std::string address) {
        customers.push_back(Customer(id, name, address));
    }
    
    void deleteCustomer(int id) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) {
                customers.erase(customers.begin() + i);
                break;
            }
        }
    }
    
    void updateCustomer(int id, std::string name, std::string address) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                break;
            }
        }
    }
    
    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }
    
    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << std::endl;
        }
    }
    
    void addShop(int id, std::string name, std::string location) {
        shops.push_back(Shop(id, name, location));
    }
    
    void deleteShop(int id) {
        for (size_t i = 0; i < shops.size(); ++i) {
            if (shops[i].id == id) {
                shops.erase(shops.begin() + i);
                break;
            }
        }
    }
    
    void updateShop(int id, std::string name, std::string location) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                break;
            }
        }
    }
    
    Shop* searchShop(int id) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }
    
    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    System system;
    system.addCustomer(1, "Alice", "123 Wonderland");
    system.addCustomer(2, "Bob", "456 Builder St.");
    system.addShop(1, "Coffee Shop", "123 Main St.");
    system.addShop(2, "Tea Store", "456 Side St.");
    
    std::cout << "Customers:\n";
    system.displayCustomers();
    
    std::cout << "\nShops:\n";
    system.displayShops();
    
    system.updateCustomer(1, "Alice", "789 New Address");
    system.updateShop(2, "Tea Shop", "789 New Street");
    
    std::cout << "\nUpdated Customers:\n";
    system.displayCustomers();
    
    std::cout << "\nUpdated Shops:\n";
    system.displayShops();
    
    return 0;
}