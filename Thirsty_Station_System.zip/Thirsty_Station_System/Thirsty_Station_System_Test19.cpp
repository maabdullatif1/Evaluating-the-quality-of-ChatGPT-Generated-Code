#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
    string phone;
};

struct Shop {
    int id;
    string name;
    string location;
    string phone;
};

class DeliveryService {
    vector<Customer> customers;
    vector<Shop> shops;
    int customerIDCounter;
    int shopIDCounter;

public:
    DeliveryService() : customerIDCounter(1), shopIDCounter(1) {}

    void addCustomer(const string& name, const string& address, const string& phone) {
        customers.push_back({customerIDCounter++, name, address, phone});
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const string& name, const string& address, const string& phone) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                customer.phone = phone;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                displayCustomer(customer);
                return;
            }
        }
        cout << "Customer not found." << endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            displayCustomer(customer);
        }
    }

    void addShop(const string& name, const string& location, const string& phone) {
        shops.push_back({shopIDCounter++, name, location, phone});
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, const string& name, const string& location, const string& phone) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                shop.phone = phone;
                break;
            }
        }
    }

    void searchShop(int id) {
        for (const auto& shop : shops) {
            if (shop.id == id) {
                displayShop(shop);
                return;
            }
        }
        cout << "Shop not found." << endl;
    }

    void displayShops() {
        for (const auto& shop : shops) {
            displayShop(shop);
        }
    }

private:
    void displayCustomer(const Customer& customer) {
        cout << "Customer ID: " << customer.id << endl;
        cout << "Name: " << customer.name << endl;
        cout << "Address: " << customer.address << endl;
        cout << "Phone: " << customer.phone << endl;
    }

    void displayShop(const Shop& shop) {
        cout << "Shop ID: " << shop.id << endl;
        cout << "Name: " << shop.name << endl;
        cout << "Location: " << shop.location << endl;
        cout << "Phone: " << shop.phone << endl;
    }
};

int main() {
    DeliveryService service;
    service.addCustomer("John Doe", "123 Main St", "555-1234");
    service.addShop("Quick Drinks", "456 Market St", "555-5678");
    cout << "Customers:" << endl;
    service.displayCustomers();
    cout << "Shops:" << endl;
    service.displayShops();
    return 0;
}