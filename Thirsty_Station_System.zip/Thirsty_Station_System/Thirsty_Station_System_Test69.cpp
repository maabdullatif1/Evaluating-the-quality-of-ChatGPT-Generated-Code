#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

Customer customers[100];
Shop shops[100];

int customerCount = 0;
int shopCount = 0;

void addCustomer(int id, string name, string address) {
    customers[customerCount++] = {id, name, address};
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; ++j) {
                customers[j] = customers[j + 1];
            }
            --customerCount;
            return;
        }
    }
}

void updateCustomer(int id, string name, string address) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            customers[i].name = name;
            customers[i].address = address;
            return;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; ++i) {
        cout << "Customer ID: " << customers[i].id 
             << ", Name: " << customers[i].name 
             << ", Address: " << customers[i].address << endl;
    }
}

void addShop(int id, string name, string location) {
    shops[shopCount++] = {id, name, location};
}

void deleteShop(int id) {
    for (int i = 0; i < shopCount; ++i) {
        if (shops[i].id == id) {
            for (int j = i; j < shopCount - 1; ++j) {
                shops[j] = shops[j + 1];
            }
            --shopCount;
            return;
        }
    }
}

void updateShop(int id, string name, string location) {
    for (int i = 0; i < shopCount; ++i) {
        if (shops[i].id == id) {
            shops[i].name = name;
            shops[i].location = location;
            return;
        }
    }
}

Shop* searchShop(int id) {
    for (int i = 0; i < shopCount; ++i) {
        if (shops[i].id == id) {
            return &shops[i];
        }
    }
    return nullptr;
}

void displayShops() {
    for (int i = 0; i < shopCount; ++i) {
        cout << "Shop ID: " << shops[i].id 
             << ", Name: " << shops[i].name 
             << ", Location: " << shops[i].location << endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "123 Main St");
    addCustomer(2, "Jane Smith", "456 Park Ave");
    displayCustomers();
    updateCustomer(1, "Jonathan Doe", "123 Main St, Apt 4B");
    displayCustomers();
    deleteCustomer(2);
    displayCustomers();
    
    addShop(1, "Drink Shop", "5th Avenue");
    addShop(2, "Beverage Hub", "Downtown");
    displayShops();
    updateShop(1, "The Drink Store", "5th Avenue and Elm St");
    displayShops();
    deleteShop(2);
    displayShops();
    
    return 0;
}