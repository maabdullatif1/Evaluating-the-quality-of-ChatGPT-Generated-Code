#include <iostream>
#include <string>
#include <vector>

// Define a struct for Customer
struct Customer {
    int id;
    std::string name;
    std::string address;
    std::string phone;
};

// Define a struct for Shop
struct Shop {
    int id;
    std::string name;
    std::string address;
    std::string phone;
};

class DrinksDeliveryService {
    std::vector<Customer> customers;
    std::vector<Shop> shops;
    int customer_id_count = 1;
    int shop_id_count = 1;

public:
    void addCustomer(const std::string& name, const std::string& address, const std::string& phone) {
        customers.push_back({customer_id_count++, name, address, phone});
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& address, const std::string& phone) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                customer.phone = phone;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id 
                      << ", Name: " << customer.name 
                      << ", Address: " << customer.address 
                      << ", Phone: " << customer.phone << std::endl;
        }
    }

    void addShop(const std::string& name, const std::string& address, const std::string& phone) {
        shops.push_back({shop_id_count++, name, address, phone});
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, const std::string& name, const std::string& address, const std::string& phone) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.address = address;
                shop.phone = phone;
                break;
            }
        }
    }

    Shop* searchShop(int id) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "Shop ID: " << shop.id 
                      << ", Name: " << shop.name 
                      << ", Address: " << shop.address 
                      << ", Phone: " << shop.phone << std::endl;
        }
    }
};

int main() {
    DrinksDeliveryService service;
    service.addCustomer("John Doe", "123 Elm St", "555-1234");
    service.addShop("Joe's Drinks", "456 Oak Rd", "555-5678");

    service.displayCustomers();
    service.displayShops();

    return 0;
}