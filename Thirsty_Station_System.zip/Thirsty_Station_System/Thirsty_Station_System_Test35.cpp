#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    std::string name;
    std::string address;
    std::string phone;

    Customer(std::string n, std::string a, std::string p) : name(n), address(a), phone(p) {}
};

class Shop {
public:
    std::string name;
    std::string location;
    std::string speciality;

    Shop(std::string n, std::string l, std::string s) : name(n), location(l), speciality(s) {}
};

class DrinksDeliveryService {
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(const std::string& name, const std::string& address, const std::string& phone) {
        customers.push_back(Customer(name, address, phone));
    }

    void deleteCustomer(const std::string& name) {
        for (size_t i = 0; i < customers.size(); i++) {
            if (customers[i].name == name) {
                customers.erase(customers.begin() + i);
                break;
            }
        }
    }

    void updateCustomer(const std::string& name, const std::string& newAddress, const std::string& newPhone) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                customer.address = newAddress;
                customer.phone = newPhone;
                break;
            }
        }
    }

    void searchCustomer(const std::string& name) {
        for (const auto& customer : customers) {
            if (customer.name == name) {
                std::cout << "Customer Found: " << customer.name << ", " << customer.address << ", " << customer.phone << "\n";
                return;
            }
        }
        std::cout << "Customer Not Found\n";
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer: " << customer.name << ", " << customer.address << ", " << customer.phone << "\n";
        }
    }

    void addShop(const std::string& name, const std::string& location, const std::string& speciality) {
        shops.push_back(Shop(name, location, speciality));
    }

    void deleteShop(const std::string& name) {
        for (size_t i = 0; i < shops.size(); i++) {
            if (shops[i].name == name) {
                shops.erase(shops.begin() + i);
                break;
            }
        }
    }

    void updateShop(const std::string& name, const std::string& newLocation, const std::string& newSpeciality) {
        for (auto& shop : shops) {
            if (shop.name == name) {
                shop.location = newLocation;
                shop.speciality = newSpeciality;
                break;
            }
        }
    }

    void searchShop(const std::string& name) {
        for (const auto& shop : shops) {
            if (shop.name == name) {
                std::cout << "Shop Found: " << shop.name << ", " << shop.location << ", " << shop.speciality << "\n";
                return;
            }
        }
        std::cout << "Shop Not Found\n";
    }

    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "Shop: " << shop.name << ", " << shop.location << ", " << shop.speciality << "\n";
        }
    }
};

int main() {
    DrinksDeliveryService service;
    service.addCustomer("John Doe", "123 Elm St", "555-1234");
    service.addShop("Fresh Drinks", "Downtown", "Juices");

    service.displayCustomers();
    service.displayShops();

    service.searchCustomer("Jane Doe");
    service.searchShop("Fresh Drinks");

    service.updateCustomer("John Doe", "456 Oak St", "555-5678");
    service.updateShop("Fresh Drinks", "Uptown", "Smoothies");

    service.displayCustomers();
    service.displayShops();

    service.deleteCustomer("John Doe");
    service.deleteShop("Fresh Drinks");

    service.displayCustomers();
    service.displayShops();

    return 0;
}