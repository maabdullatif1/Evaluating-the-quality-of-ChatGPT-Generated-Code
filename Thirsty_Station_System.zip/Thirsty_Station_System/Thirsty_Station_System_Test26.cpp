#include <iostream>
#include <vector>
#include <string>

using namespace std;

// Structure for Customer
struct Customer {
    int id;
    string name;
    string address;
};

// Structure for Shop
struct Shop {
    int id;
    string name;
    string location;
};

class DeliverySystem {
    vector<Customer> customers;
    vector<Shop> shops;

public:
    void addCustomer(int id, string name, string address) {
        customers.push_back({id, name, address});
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, string name, string address) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                break;
            }
        }
    }
    
    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }
    
    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << endl;
        }
    }

    void addShop(int id, string name, string location) {
        shops.push_back({id, name, location});
    }
    
    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }
    
    void updateShop(int id, string name, string location) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                break;
            }
        }
    }
    
    Shop* searchShop(int id) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }
    
    void displayShops() {
        for (const auto &shop : shops) {
            cout << "ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << endl;
        }
    }
};

int main() {
    DeliverySystem system;
    system.addCustomer(1, "John Doe", "123 Elm St");
    system.addCustomer(2, "Jane Smith", "456 Maple Ave");
    system.addShop(1, "DrinkHub", "Downtown");
    system.addShop(2, "Beverage Corner", "Uptown");
    
    system.displayCustomers();
    system.displayShops();
    
    system.deleteCustomer(1);
    system.updateShop(2, "Beverage Central", "Midtown");
    
    system.displayCustomers();
    system.displayShops();
    
    Customer* customer = system.searchCustomer(2);
    if (customer) {
        cout << "Found Customer: " << customer->name << endl;
    }

    Shop* shop = system.searchShop(2);
    if (shop) {
        cout << "Found Shop: " << shop->name << endl;
    }

    return 0;
}