#include <iostream>
#include <string>
#include <vector>

class Customer {
public:
    int id;
    std::string name;
    std::string address;
    std::string phone;

    Customer(int id, const std::string &name, const std::string &address, const std::string &phone)
        : id(id), name(name), address(address), phone(phone) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;
    std::string contact;

    Shop(int id, const std::string &name, const std::string &location, const std::string &contact)
        : id(id), name(name), location(location), contact(contact) {}
};

class DeliverySystem {
private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;

    int findCustomerIndexById(int id) {
        for (int i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) return i;
        }
        return -1;
    }

    int findShopIndexById(int id) {
        for (int i = 0; i < shops.size(); ++i) {
            if (shops[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCustomer(int id, const std::string &name, const std::string &address, const std::string &phone) {
        customers.emplace_back(id, name, address, phone);
    }

    void addShop(int id, const std::string &name, const std::string &location, const std::string &contact) {
        shops.emplace_back(id, name, location, contact);
    }

    void deleteCustomer(int id) {
        int index = findCustomerIndexById(id);
        if (index != -1) {
            customers.erase(customers.begin() + index);
        }
    }

    void deleteShop(int id) {
        int index = findShopIndexById(id);
        if (index != -1) {
            shops.erase(shops.begin() + index);
        }
    }

    void updateCustomer(int id, const std::string &name, const std::string &address, const std::string &phone) {
        int index = findCustomerIndexById(id);
        if (index != -1) {
            customers[index].name = name;
            customers[index].address = address;
            customers[index].phone = phone;
        }
    }

    void updateShop(int id, const std::string &name, const std::string &location, const std::string &contact) {
        int index = findShopIndexById(id);
        if (index != -1) {
            shops[index].name = name;
            shops[index].location = location;
            shops[index].contact = contact;
        }
    }

    Customer* searchCustomer(int id) {
        int index = findCustomerIndexById(id);
        return (index != -1) ? &customers[index] : nullptr;
    }

    Shop* searchShop(int id) {
        int index = findShopIndexById(id);
        return (index != -1) ? &shops[index] : nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "ID: " << customer.id << " Name: " << customer.name 
                      << " Address: " << customer.address << " Phone: " << customer.phone << std::endl;
        }
    }

    void displayShops() {
        for (const auto &shop : shops) {
            std::cout << "ID: " << shop.id << " Name: " << shop.name 
                      << " Location: " << shop.location << " Contact: " << shop.contact << std::endl;
        }
    }
};

int main() {
    DeliverySystem system;

    system.addCustomer(1, "John Doe", "123 Elm St", "555-1234");
    system.addShop(1, "Drink Shop", "456 Maple St", "555-5678");

    system.displayCustomers();
    system.displayShops();

    system.updateCustomer(1, "John Smith", "123 Elm St", "555-6789");
    system.updateShop(1, "New Drink Shop", "789 Oak St", "555-0000");

    system.displayCustomers();
    system.displayShops();

    Customer* customer = system.searchCustomer(1);
    Shop* shop = system.searchShop(1);

    if (customer) {
        std::cout << "Found customer: " << customer->name << std::endl;
    }

    if (shop) {
        std::cout << "Found shop: " << shop->name << std::endl;
    }

    system.deleteCustomer(1);
    system.deleteShop(1);

    system.displayCustomers();
    system.displayShops();

    return 0;
}