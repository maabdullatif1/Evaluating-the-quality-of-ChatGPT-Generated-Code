#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    std::string address;
    std::string phoneNumber;
};

class Customer : public Person {
};

class Shop : public Person {
public:
    std::string shopName;
};

class System {
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(const std::string& name, const std::string& address, const std::string& phone) {
        Customer customer;
        customer.name = name;
        customer.address = address;
        customer.phoneNumber = phone;
        customers.push_back(customer);
    }

    void deleteCustomer(const std::string& name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(const std::string& name, const std::string& newAddress, const std::string& newPhone) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                customer.address = newAddress;
                customer.phoneNumber = newPhone;
                break;
            }
        }
    }

    Customer* searchCustomer(const std::string& name) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Name: " << customer.name << ", Address: " << customer.address
                      << ", Phone: " << customer.phoneNumber << std::endl;
        }
    }

    void addShop(const std::string& shopName, const std::string& address, const std::string& phone) {
        Shop shop;
        shop.shopName = shopName;
        shop.address = address;
        shop.phoneNumber = phone;
        shops.push_back(shop);
    }

    void deleteShop(const std::string& shopName) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->shopName == shopName) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(const std::string& shopName, const std::string& newAddress, const std::string& newPhone) {
        for (auto& shop : shops) {
            if (shop.shopName == shopName) {
                shop.address = newAddress;
                shop.phoneNumber = newPhone;
                break;
            }
        }
    }

    Shop* searchShop(const std::string& shopName) {
        for (auto& shop : shops) {
            if (shop.shopName == shopName) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "Shop Name: " << shop.shopName << ", Address: " << shop.address
                      << ", Phone: " << shop.phoneNumber << std::endl;
        }
    }
};

int main() {
    System system;
    system.addCustomer("John Doe", "123 Elm St", "555-1234");
    system.addShop("Quick Drinks", "456 Oak Ave", "555-5678");
    system.displayCustomers();
    system.displayShops();
    system.updateCustomer("John Doe", "789 Maple Rd", "555-0000");
    system.displayCustomers();
    system.deleteShop("Quick Drinks");
    system.displayShops();
    return 0;
}