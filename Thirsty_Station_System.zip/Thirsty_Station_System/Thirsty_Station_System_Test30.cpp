#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
protected:
    string name;
    string address;
    string phone;
public:
    Person(string n, string a, string p) : name(n), address(a), phone(p) {}
    virtual void display() const = 0;
    string getName() const { return name; }
    void setName(string n) { name = n; }
    void setAddress(string a) { address = a; }
    void setPhone(string p) { phone = p; }
};

class Customer : public Person {
public:
    Customer(string n, string a, string p) : Person(n, a, p) {}
    void display() const override {
        cout << "Customer Name: " << name << ", Address: " << address << ", Phone: " << phone << endl;
    }
};

class Shop : public Person {
public:
    Shop(string n, string a, string p) : Person(n, a, p) {}
    void display() const override {
        cout << "Shop Name: " << name << ", Address: " << address << ", Phone: " << phone << endl;
    }
};

class DrinksDeliverySystem {
private:
    vector<Customer> customers;
    vector<Shop> shops;
public:
    void addCustomer(string name, string address, string phone) {
        customers.push_back(Customer(name, address, phone));
    }

    void deleteCustomer(string name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getName() == name) {
                customers.erase(it);
                return;
            }
        }
    }

    void updateCustomer(string name, string newAddress, string newPhone) {
        for (auto &customer : customers) {
            if (customer.getName() == name) {
                customer.setAddress(newAddress);
                customer.setPhone(newPhone);
            }
        }
    }

    void searchCustomer(string name) const {
        for (const auto &customer : customers) {
            if (customer.getName() == name) {
                customer.display();
                return;
            }
        }
        cout << "Customer not found." << endl;
    }

    void displayCustomers() const {
        for (const auto &customer : customers) {
            customer.display();
        }
    }

    void addShop(string name, string address, string phone) {
        shops.push_back(Shop(name, address, phone));
    }

    void deleteShop(string name) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->getName() == name) {
                shops.erase(it);
                return;
            }
        }
    }

    void updateShop(string name, string newAddress, string newPhone) {
        for (auto &shop : shops) {
            if (shop.getName() == name) {
                shop.setAddress(newAddress);
                shop.setPhone(newPhone);
            }
        }
    }

    void searchShop(string name) const {
        for (const auto &shop : shops) {
            if (shop.getName() == name) {
                shop.display();
                return;
            }
        }
        cout << "Shop not found." << endl;
    }

    void displayShops() const {
        for (const auto &shop : shops) {
            shop.display();
        }
    }
};

int main() {
    DrinksDeliverySystem system;
    
    system.addCustomer("Alice", "123 Street A", "1234567890");
    system.addCustomer("Bob", "456 Street B", "0987654321");
    system.displayCustomers();
    
    system.addShop("DrinkShop1", "789 Road C", "1122334455");
    system.addShop("JuiceBar", "321 Avenue D", "5566778899");
    system.displayShops();
    
    system.searchCustomer("Alice");
    system.updateCustomer("Alice", "New Address A", "1111111111");
    system.searchCustomer("Alice");
    
    system.searchShop("DrinkShop1");
    system.deleteShop("DrinkShop1");
    system.displayShops();

    return 0;
}