#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string address;
    std::string phoneNumber;
    
    Customer(int id, const std::string& name, const std::string& address, const std::string& phoneNumber)
    : id(id), name(name), address(address), phoneNumber(phoneNumber) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;
    
    Shop(int id, const std::string& name, const std::string& location)
    : id(id), name(name), location(location) {}
};

class DeliveryService {
private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(const Customer& customer) {
        customers.push_back(customer);
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, const std::string& newName, const std::string& newAddress, const std::string& newPhoneNumber) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = newName;
                customer.address = newAddress;
                customer.phoneNumber = newPhoneNumber;
                break;
            }
        }
    }
    
    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name
                          << ", Address: " << customer.address << ", Phone: " << customer.phoneNumber << std::endl;
                return;
            }
        }
        std::cout << "Customer not found." << std::endl;
    }
    
    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name
                      << ", Address: " << customer.address << ", Phone: " << customer.phoneNumber << std::endl;
        }
    }
    
    void addShop(const Shop& shop) {
        shops.push_back(shop);
    }
    
    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }
    
    void updateShop(int id, const std::string& newName, const std::string& newLocation) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = newName;
                shop.location = newLocation;
                break;
            }
        }
    }
    
    void searchShop(int id) {
        for (const auto& shop : shops) {
            if (shop.id == id) {
                std::cout << "Shop ID: " << shop.id << ", Name: " << shop.name
                          << ", Location: " << shop.location << std::endl;
                return;
            }
        }
        std::cout << "Shop not found." << std::endl;
    }
    
    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "Shop ID: " << shop.id << ", Name: " << shop.name
                      << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    DeliveryService service;

    service.addCustomer(Customer(1, "John Doe", "123 Elm St", "555-1234"));
    service.addCustomer(Customer(2, "Jane Smith", "456 Oak St", "555-5678"));
    
    service.addShop(Shop(1, "Super Drinks", "789 Maple Ave"));
    service.addShop(Shop(2, "Bottle Shop", "101 Pine Rd"));
    
    service.displayCustomers();
    service.displayShops();
    
    service.updateCustomer(1, "John Doe", "999 New Address", "555-9999");
    service.updateShop(2, "The Bottle Shop", "202 New Location");
    
    service.searchCustomer(1);
    service.searchShop(2);
    
    service.deleteCustomer(2);
    service.deleteShop(1);
    
    service.displayCustomers();
    service.displayShops();

    return 0;
}