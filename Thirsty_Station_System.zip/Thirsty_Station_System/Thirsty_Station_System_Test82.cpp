#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
    string phone;
};

struct Shop {
    int id;
    string name;
    string address;
    string phone;
};

vector<Customer> customers;
vector<Shop> shops;

int generateCustomerId() {
    return customers.size() + 1;
}

int generateShopId() {
    return shops.size() + 1;
}

void addCustomer() {
    Customer customer;
    customer.id = generateCustomerId();
    cout << "Enter Customer Name: ";
    cin >> customer.name;
    cout << "Enter Customer Address: ";
    cin >> customer.address;
    cout << "Enter Customer Phone: ";
    cin >> customer.phone;
    customers.push_back(customer);
}

void addShop() {
    Shop shop;
    shop.id = generateShopId();
    cout << "Enter Shop Name: ";
    cin >> shop.name;
    cout << "Enter Shop Address: ";
    cin >> shop.address;
    cout << "Enter Shop Phone: ";
    cin >> shop.phone;
    shops.push_back(shop);
}

void deleteCustomer(int id) {
    for (auto it = customers.begin(); it != customers.end(); ++it) {
        if (it->id == id) {
            customers.erase(it);
            cout << "Customer deleted.\n";
            return;
        }
    }
    cout << "Customer not found.\n";
}

void deleteShop(int id) {
    for (auto it = shops.begin(); it != shops.end(); ++it) {
        if (it->id == id) {
            shops.erase(it);
            cout << "Shop deleted.\n";
            return;
        }
    }
    cout << "Shop not found.\n";
}

void updateCustomer(int id) {
    for (auto &customer : customers) {
        if (customer.id == id) {
            cout << "Enter New Name: ";
            cin >> customer.name;
            cout << "Enter New Address: ";
            cin >> customer.address;
            cout << "Enter New Phone: ";
            cin >> customer.phone;
            cout << "Customer updated.\n";
            return;
        }
    }
    cout << "Customer not found.\n";
}

void updateShop(int id) {
    for (auto &shop : shops) {
        if (shop.id == id) {
            cout << "Enter New Name: ";
            cin >> shop.name;
            cout << "Enter New Address: ";
            cin >> shop.address;
            cout << "Enter New Phone: ";
            cin >> shop.phone;
            cout << "Shop updated.\n";
            return;
        }
    }
    cout << "Shop not found.\n";
}

void searchCustomer(int id) {
    for (const auto &customer : customers) {
        if (customer.id == id) {
            cout << "ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << ", Phone: " << customer.phone << endl;
            return;
        }
    }
    cout << "Customer not found.\n";
}

void searchShop(int id) {
    for (const auto &shop : shops) {
        if (shop.id == id) {
            cout << "ID: " << shop.id << ", Name: " << shop.name << ", Address: " << shop.address << ", Phone: " << shop.phone << endl;
            return;
        }
    }
    cout << "Shop not found.\n";
}

void displayCustomers() {
    for (const auto &customer : customers) {
        cout << "ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << ", Phone: " << customer.phone << endl;
    }
}

void displayShops() {
    for (const auto &shop : shops) {
        cout << "ID: " << shop.id << ", Name: " << shop.name << ", Address: " << shop.address << ", Phone: " << shop.phone << endl;
    }
}

int main() {
    int choice, id;
    while (true) {
        cout << "1. Add Customer\n2. Add Shop\n3. Delete Customer\n4. Delete Shop\n5. Update Customer\n6. Update Shop\n7. Search Customer\n8. Search Shop\n9. Display Customers\n10. Display Shops\n11. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addCustomer(); break;
            case 2: addShop(); break;
            case 3: cout << "Enter Customer ID to delete: "; cin >> id; deleteCustomer(id); break;
            case 4: cout << "Enter Shop ID to delete: "; cin >> id; deleteShop(id); break;
            case 5: cout << "Enter Customer ID to update: "; cin >> id; updateCustomer(id); break;
            case 6: cout << "Enter Shop ID to update: "; cin >> id; updateShop(id); break;
            case 7: cout << "Enter Customer ID to search: "; cin >> id; searchCustomer(id); break;
            case 8: cout << "Enter Shop ID to search: "; cin >> id; searchShop(id); break;
            case 9: displayCustomers(); break;
            case 10: displayShops(); break;
            case 11: return 0;
            default: cout << "Invalid choice. Try again.\n";
        }
    }
}