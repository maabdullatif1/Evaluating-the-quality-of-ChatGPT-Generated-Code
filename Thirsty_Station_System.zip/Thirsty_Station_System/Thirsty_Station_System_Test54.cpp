#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string name;
    std::string address;
    std::string phone;

    Person(const std::string &n, const std::string &a, const std::string &p)
        : name(n), address(a), phone(p) {}
};

class Customer : public Person {
public:
    Customer(const std::string &n, const std::string &a, const std::string &p)
        : Person(n, a, p) {}
};

class Shop {
public:
    std::string name;
    std::string location;

    Shop(const std::string &n, const std::string &l) : name(n), location(l) {}
};

class DeliveryService {
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(const std::string &name, const std::string &address, const std::string &phone) {
        customers.push_back(Customer(name, address, phone));
    }

    void deleteCustomer(const std::string &name) {
        customers.erase(std::remove_if(customers.begin(), customers.end(),
                   [&](Customer &c) { return c.name == name; }), customers.end());
    }

    void updateCustomer(const std::string &name, const std::string &address, const std::string &phone) {
        for (auto &customer : customers) {
            if (customer.name == name) {
                customer.address = address;
                customer.phone = phone;
            }
        }
    }

    Customer searchCustomer(const std::string &name) {
        for (const auto &customer : customers) {
            if (customer.name == name) {
                return customer;
            }
        }
        return Customer("", "", "");
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "Customer Name: " << customer.name << ", Address: " 
                      << customer.address << ", Phone: " << customer.phone << std::endl;
        }
    }

    void addShop(const std::string &name, const std::string &location) {
        shops.push_back(Shop(name, location));
    }

    void deleteShop(const std::string &name) {
        shops.erase(std::remove_if(shops.begin(), shops.end(),
                   [&](Shop &s) { return s.name == name; }), shops.end());
    }

    void updateShop(const std::string &name, const std::string &location) {
        for (auto &shop : shops) {
            if (shop.name == name) {
                shop.location = location;
            }
        }
    }

    Shop searchShop(const std::string &name) {
        for (const auto &shop : shops) {
            if (shop.name == name) {
                return shop;
            }
        }
        return Shop("", "");
    }

    void displayShops() {
        for (const auto &shop : shops) {
            std::cout << "Shop Name: " << shop.name << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    DeliveryService service;
    
    service.addCustomer("John Doe", "123 Main St", "555-1234");
    service.addCustomer("Jane Smith", "456 Elm St", "555-5678");
    
    service.addShop("Drink Haven", "789 Oak St");
    service.addShop("Refresh Stop", "101 Pine St");
    
    service.displayCustomers();
    service.displayShops();
    
    return 0;
}