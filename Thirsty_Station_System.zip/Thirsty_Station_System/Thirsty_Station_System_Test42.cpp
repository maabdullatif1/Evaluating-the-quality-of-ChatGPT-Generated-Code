#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string address;
};

class Shop {
public:
    int id;
    string name;
    string location;
};

class DeliverySystem {
    vector<Customer> customers;
    vector<Shop> shops;

    int findCustomerById(int id) {
        for (int i = 0; i < customers.size(); i++) {
            if (customers[i].id == id) return i;
        }
        return -1;
    }

    int findShopById(int id) {
        for (int i = 0; i < shops.size(); i++) {
            if (shops[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCustomer(int id, string name, string address) {
        if (findCustomerById(id) == -1) {
            customers.push_back({id, name, address});
        }
    }

    void deleteCustomer(int id) {
        int index = findCustomerById(id);
        if (index != -1) {
            customers.erase(customers.begin() + index);
        }
    }

    void updateCustomer(int id, string name, string address) {
        int index = findCustomerById(id);
        if (index != -1) {
            customers[index].name = name;
            customers[index].address = address;
        }
    }

    Customer* searchCustomer(int id) {
        int index = findCustomerById(id);
        if (index != -1) {
            return &customers[index];
        }
        return nullptr;
    }

    void displayCustomers() {
        for (auto& customer : customers) {
            cout << "ID: " << customer.id << ", Name: " << customer.name << ", Address: " << customer.address << endl;
        }
    }

    void addShop(int id, string name, string location) {
        if (findShopById(id) == -1) {
            shops.push_back({id, name, location});
        }
    }

    void deleteShop(int id) {
        int index = findShopById(id);
        if (index != -1) {
            shops.erase(shops.begin() + index);
        }
    }

    void updateShop(int id, string name, string location) {
        int index = findShopById(id);
        if (index != -1) {
            shops[index].name = name;
            shops[index].location = location;
        }
    }

    Shop* searchShop(int id) {
        int index = findShopById(id);
        if (index != -1) {
            return &shops[index];
        }
        return nullptr;
    }

    void displayShops() {
        for (auto& shop : shops) {
            cout << "ID: " << shop.id << ", Name: " << shop.name << ", Location: " << shop.location << endl;
        }
    }
};

int main() {
    DeliverySystem ds;
    ds.addCustomer(1, "John Doe", "123 Maple St");
    ds.addShop(1, "The Coffee Place", "456 Main St");
    ds.displayCustomers();
    ds.displayShops();

    Customer* customer = ds.searchCustomer(1);
    if (customer) {
        cout << "Found customer: " << customer->name << endl;
    }

    Shop* shop = ds.searchShop(1);
    if (shop) {
        cout << "Found shop: " << shop->name << endl;
    }

    ds.updateCustomer(1, "John Doe", "789 Elm St");
    ds.updateShop(1, "The Coffee Place", "987 Oak Ave");
    ds.displayCustomers();
    ds.displayShops();

    ds.deleteCustomer(1);
    ds.deleteShop(1);
    ds.displayCustomers();
    ds.displayShops();

    return 0;
}