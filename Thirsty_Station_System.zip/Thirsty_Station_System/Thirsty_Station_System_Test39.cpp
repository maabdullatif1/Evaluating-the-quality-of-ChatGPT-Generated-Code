#include <iostream>
#include <cstring>

const int MAX_CUSTOMERS = 100;
const int MAX_SHOPS = 100;

struct Customer {
    int id;
    char name[100];
    char address[150];
};

struct Shop {
    int id;
    char name[100];
    char location[150];
};

Customer customers[MAX_CUSTOMERS];
Shop shops[MAX_SHOPS];

int customerCount = 0;
int shopCount = 0;

void addCustomer(int id, const char* name, const char* address) {
    if (customerCount < MAX_CUSTOMERS) {
        customers[customerCount].id = id;
        strcpy(customers[customerCount].name, name);
        strcpy(customers[customerCount].address, address);
        customerCount++;
    }
}

void updateCustomer(int id, const char* name, const char* address) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            strcpy(customers[i].name, name);
            strcpy(customers[i].address, address);
            break;
        }
    }
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; j++) {
                customers[j] = customers[j + 1];
            }
            customerCount--;
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; i++) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; i++) {
        std::cout << "Customer ID: " << customers[i].id 
                  << ", Name: " << customers[i].name 
                  << ", Address: " << customers[i].address << std::endl;
    }
}

void addShop(int id, const char* name, const char* location) {
    if (shopCount < MAX_SHOPS) {
        shops[shopCount].id = id;
        strcpy(shops[shopCount].name, name);
        strcpy(shops[shopCount].location, location);
        shopCount++;
    }
}

void updateShop(int id, const char* name, const char* location) {
    for (int i = 0; i < shopCount; i++) {
        if (shops[i].id == id) {
            strcpy(shops[i].name, name);
            strcpy(shops[i].location, location);
            break;
        }
    }
}

void deleteShop(int id) {
    for (int i = 0; i < shopCount; i++) {
        if (shops[i].id == id) {
            for (int j = i; j < shopCount - 1; j++) {
                shops[j] = shops[j + 1];
            }
            shopCount--;
            break;
        }
    }
}

Shop* searchShop(int id) {
    for (int i = 0; i < shopCount; i++) {
        if (shops[i].id == id) {
            return &shops[i];
        }
    }
    return nullptr;
}

void displayShops() {
    for (int i = 0; i < shopCount; i++) {
        std::cout << "Shop ID: " << shops[i].id 
                  << ", Name: " << shops[i].name 
                  << ", Location: " << shops[i].location << std::endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "123 Elm St");
    addCustomer(2, "Jane Smith", "456 Oak St");
    displayCustomers();

    addShop(1, "Drinks Galore", "789 Maple Ave");
    addShop(2, "Beverage House", "321 Pine Rd");
    displayShops();

    updateCustomer(1, "John Doe", "New Address 123");
    displayCustomers();

    deleteCustomer(2);
    displayCustomers();

    updateShop(1, "Drinks Galore+", "New Location 789");
    displayShops();

    deleteShop(2);
    displayShops();

    return 0;
}