#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

class DeliveryService {
    vector<Customer> customers;
    vector<Shop> shops;

public:
    void addCustomer(int id, string name, string address) {
        customers.push_back({id, name, address});
    }

    void deleteCustomer(int id) {
        for(auto it = customers.begin(); it != customers.end(); ++it) {
            if(it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string address) {
        for(auto &customer : customers) {
            if(customer.id == id) {
                customer.name = name;
                customer.address = address;
                break;
            }
        }
    }

    Customer searchCustomer(int id) {
        for(auto &customer : customers) {
            if(customer.id == id) {
                return customer;
            }
        }
        return {-1, "", ""};
    }

    void displayCustomers() {
        for(auto &customer : customers) {
            cout << "Customer ID: " << customer.id 
                 << ", Name: " << customer.name 
                 << ", Address: " << customer.address << endl;
        }
    }

    void addShop(int id, string name, string location) {
        shops.push_back({id, name, location});
    }

    void deleteShop(int id) {
        for(auto it = shops.begin(); it != shops.end(); ++it) {
            if(it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, string name, string location) {
        for(auto &shop : shops) {
            if(shop.id == id) {
                shop.name = name;
                shop.location = location;
                break;
            }
        }
    }

    Shop searchShop(int id) {
        for(auto &shop : shops) {
            if(shop.id == id) {
                return shop;
            }
        }
        return {-1, "", ""};
    }

    void displayShops() {
        for(auto &shop : shops) {
            cout << "Shop ID: " << shop.id 
                 << ", Name: " << shop.name 
                 << ", Location: " << shop.location << endl;
        }
    }
};

int main() {
    DeliveryService service;

    service.addCustomer(1, "John Doe", "123 Elm Street");
    service.addCustomer(2, "Jane Smith", "456 Oak Avenue");
    
    service.addShop(1, "Cool Drinks", "789 Pine Road");
    service.addShop(2, "Fresh Beverages", "101 Maple Drive");

    service.displayCustomers();
    service.displayShops();

    return 0;
}