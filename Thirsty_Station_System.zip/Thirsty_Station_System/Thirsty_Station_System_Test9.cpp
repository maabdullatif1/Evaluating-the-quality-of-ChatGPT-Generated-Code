#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    Customer(int id, std::string name, std::string address) 
        : id(id), name(name), address(address) {}
    
    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getAddress() const { return address; }
    
    void updateCustomer(std::string newName, std::string newAddress) {
        name = newName;
        address = newAddress;
    }

private:
    int id;
    std::string name;
    std::string address;
};

class Shop {
public:
    Shop(int id, std::string name, std::string location) 
        : id(id), name(name), location(location) {}
    
    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getLocation() const { return location; }
    
    void updateShop(std::string newName, std::string newLocation) {
        name = newName;
        location = newLocation;
    }

private:
    int id;
    std::string name;
    std::string location;
};

class DeliverySystem {
public:
    void addCustomer(int id, std::string name, std::string address) {
        customers.push_back(Customer(id, name, address));
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, std::string newName, std::string newAddress) {
        for (auto &customer : customers) {
            if (customer.getId() == id) {
                customer.updateCustomer(newName, newAddress);
                break;
            }
        }
    }
    
    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.getId() == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "Customer ID: " << customer.getId() 
                      << ", Name: " << customer.getName() 
                      << ", Address: " << customer.getAddress() << std::endl;
        }
    }

    void addShop(int id, std::string name, std::string location) {
        shops.push_back(Shop(id, name, location));
    }
    
    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->getId() == id) {
                shops.erase(it);
                break;
            }
        }
    }
    
    void updateShop(int id, std::string newName, std::string newLocation) {
        for (auto &shop : shops) {
            if (shop.getId() == id) {
                shop.updateShop(newName, newLocation);
                break;
            }
        }
    }

    Shop* searchShop(int id) {
        for (auto &shop : shops) {
            if (shop.getId() == id) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayShops() {
        for (const auto &shop : shops) {
            std::cout << "Shop ID: " << shop.getId() 
                      << ", Name: " << shop.getName() 
                      << ", Location: " << shop.getLocation() << std::endl;
        }
    }

private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;
};

int main() {
    DeliverySystem system;
    
    system.addCustomer(1, "John Doe", "123 Main St");
    system.addCustomer(2, "Jane Smith", "456 Elm St");
    system.displayCustomers();

    system.addShop(1, "Drink Shop A", "789 Oak Rd");
    system.addShop(2, "Drink Shop B", "101 Pine Rd");
    system.displayShops();

    system.updateCustomer(1, "John X. Doe", "321 Main St");
    system.displayCustomers();

    system.updateShop(1, "New Drink Shop A", "987 Oak Rd");
    system.displayShops();
    
    system.deleteCustomer(2);
    system.displayCustomers();
    
    system.deleteShop(2);
    system.displayShops();
    
    Customer* customer = system.searchCustomer(1);
    if (customer) {
        std::cout << "Found Customer: " << customer->getName() << std::endl;
    }
    
    Shop* shop = system.searchShop(1);
    if (shop) {
        std::cout << "Found Shop: " << shop->getName() << std::endl;
    }
    
    return 0;
}