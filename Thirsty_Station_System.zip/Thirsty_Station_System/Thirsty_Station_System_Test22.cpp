#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string address;
    std::string phone;
};

struct Shop {
    int id;
    std::string name;
    std::string location;
};

class DeliveryService {
private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;
    int customerIdCounter;
    int shopIdCounter;

public:
    DeliveryService() : customerIdCounter(1), shopIdCounter(1) {}

    void addCustomer(const std::string& name, const std::string& address, const std::string& phone) {
        customers.push_back({customerIdCounter++, name, address, phone});
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& address, const std::string& phone) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                customer.phone = phone;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name 
                      << ", Address: " << customer.address << ", Phone: " << customer.phone << "\n";
        }
    }

    void addShop(const std::string& name, const std::string& location) {
        shops.push_back({shopIdCounter++, name, location});
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, const std::string& name, const std::string& location) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                break;
            }
        }
    }

    Shop* searchShop(int id) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "ID: " << shop.id << ", Name: " << shop.name 
                      << ", Location: " << shop.location << "\n";
        }
    }
};

int main() {
    DeliveryService service;
    
    service.addCustomer("John Doe", "123 Main St", "555-1234");
    service.addCustomer("Jane Smith", "456 Elm St", "555-5678");
    
    service.addShop("Downtown Drinks", "789 Market St");
    service.addShop("Uptown Beverages", "101 North St");
    
    std::cout << "Customers:\n";
    service.displayCustomers();
    
    std::cout << "\nShops:\n";
    service.displayShops();
    
    return 0;
}