#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Person {
protected:
    string name;
    string address;
    string phone;
public:
    Person(string n, string a, string p) : name(n), address(a), phone(p) {}
    string getName() { return name; }
    string getAddress() { return address; }
    string getPhone() { return phone; }
    void setName(string n) { name = n; }
    void setAddress(string a) { address = a; }
    void setPhone(string p) { phone = p; }
};

class Customer : public Person {
public:
    Customer(string n, string a, string p) : Person(n, a, p) {}
};

class Shop : public Person {
public:
    Shop(string n, string a, string p) : Person(n, a, p) {}
};

template <typename T>
class ManagementSystem {
    vector<T> entities;
public:
    void addEntity(const T& entity) {
        entities.push_back(entity);
    }

    void deleteEntity(const string& name) {
        for (auto it = entities.begin(); it != entities.end(); ++it) {
            if (it->getName() == name) {
                entities.erase(it);
                break;
            }
        }
    }

    void updateEntity(const string& name, const string& newName, const string& newAddress, const string& newPhone) {
        for (auto& entity : entities) {
            if (entity.getName() == name) {
                entity.setName(newName);
                entity.setAddress(newAddress);
                entity.setPhone(newPhone);
                break;
            }
        }
    }

    T* searchEntity(const string& name) {
        for (auto& entity : entities) {
            if (entity.getName() == name) {
                return &entity;
            }
        }
        return nullptr;
    }

    void displayEntities() {
        for (const auto& entity : entities) {
            cout << "Name: " << entity.getName() << ", Address: " << entity.getAddress() << ", Phone: " << entity.getPhone() << endl;
        }
    }
};

int main() {
    ManagementSystem<Customer> customerSystem;
    ManagementSystem<Shop> shopSystem;

    customerSystem.addEntity(Customer("Alice", "123 Street A", "555-1234"));
    customerSystem.addEntity(Customer("Bob", "456 Street B", "555-5678"));
    
    shopSystem.addEntity(Shop("Drink Shop A", "789 Avenue X", "555-9876"));
    shopSystem.addEntity(Shop("Drink Shop B", "321 Avenue Y", "555-4321"));

    cout << "Customers:" << endl;
    customerSystem.displayEntities();

    cout << "\nShops:" << endl;
    shopSystem.displayEntities();

    customerSystem.updateEntity("Alice", "Alice Updated", "124 Street A", "555-0000");
    shopSystem.deleteEntity("Drink Shop B");

    cout << "\nUpdated Customers:" << endl;
    customerSystem.displayEntities();

    cout << "\nUpdated Shops:" << endl;
    shopSystem.displayEntities();

    return 0;
}