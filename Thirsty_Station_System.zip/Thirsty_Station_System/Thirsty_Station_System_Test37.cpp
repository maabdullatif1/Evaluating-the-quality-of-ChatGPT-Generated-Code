#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string address;
};

struct Shop {
    int id;
    std::string name;
    std::string location;
};

std::vector<Customer> customers;
std::vector<Shop> shops;

int findCustomerIndex(int id) {
    for (size_t i = 0; i < customers.size(); ++i) {
        if (customers[i].id == id) return i;
    }
    return -1;
}

int findShopIndex(int id) {
    for (size_t i = 0; i < shops.size(); ++i) {
        if (shops[i].id == id) return i;
    }
    return -1;
}

void addCustomer(int id, const std::string& name, const std::string& address) {
    customers.push_back({id, name, address});
}

void addShop(int id, const std::string& name, const std::string& location) {
    shops.push_back({id, name, location});
}

void deleteCustomer(int id) {
    int index = findCustomerIndex(id);
    if (index != -1) customers.erase(customers.begin() + index);
}

void deleteShop(int id) {
    int index = findShopIndex(id);
    if (index != -1) shops.erase(shops.begin() + index);
}

void updateCustomer(int id, const std::string& name, const std::string& address) {
    int index = findCustomerIndex(id);
    if (index != -1) {
        customers[index].name = name;
        customers[index].address = address;
    }
}

void updateShop(int id, const std::string& name, const std::string& location) {
    int index = findShopIndex(id);
    if (index != -1) {
        shops[index].name = name;
        shops[index].location = location;
    }
}

void searchCustomer(int id) {
    int index = findCustomerIndex(id);
    if (index != -1) {
        std::cout << "Customer ID: " << customers[index].id << ", Name: " 
                  << customers[index].name << ", Address: " << customers[index].address << std::endl;
    } else {
        std::cout << "Customer not found." << std::endl;
    }
}

void searchShop(int id) {
    int index = findShopIndex(id);
    if (index != -1) {
        std::cout << "Shop ID: " << shops[index].id << ", Name: " 
                  << shops[index].name << ", Location: " << shops[index].location << std::endl;
    } else {
        std::cout << "Shop not found." << std::endl;
    }
}

void displayCustomers() {
    for (const auto& customer : customers) {
        std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name 
                  << ", Address: " << customer.address << std::endl;
    }
}

void displayShops() {
    for (const auto& shop : shops) {
        std::cout << "Shop ID: " << shop.id << ", Name: " << shop.name 
                  << ", Location: " << shop.location << std::endl;
    }
}

int main() {
    addCustomer(1, "Alice", "123 Drinks St");
    addCustomer(2, "Bob", "456 Beers Lane");
    addShop(1, "Drinkies", "789 Booze Blvd");
    addShop(2, "Bottle House", "321 Liquor Ave");

    std::cout << "Displaying customers:" << std::endl;
    displayCustomers();
    std::cout << "Displaying shops:" << std::endl;
    displayShops();

    searchCustomer(1);
    searchShop(1);
    
    updateCustomer(1, "Alicia", "123 New Drinks St");
    updateShop(1, "Drinks & More", "987 New Booze Blvd");
    
    std::cout << "After updates:" << std::endl;
    displayCustomers();
    displayShops();

    deleteCustomer(2);
    deleteShop(2);

    std::cout << "After deletions:" << std::endl;
    displayCustomers();
    displayShops();

    return 0;
}