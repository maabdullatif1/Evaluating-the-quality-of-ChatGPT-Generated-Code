#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    std::string name;
    std::string address;
    std::string phone;

    Customer(const std::string& n, const std::string& a, const std::string& p)
        : name(n), address(a), phone(p) {}
};

class Shop {
public:
    std::string name;
    std::string location;

    Shop(const std::string& n, const std::string& l)
        : name(n), location(l) {}
};

class DeliveryService {
private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(const std::string& name, const std::string& address, const std::string& phone) {
        customers.push_back(Customer(name, address, phone));
    }

    void deleteCustomer(const std::string& name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(const std::string& oldName, const std::string& newName, const std::string& newAddress, const std::string& newPhone) {
        for (auto& customer : customers) {
            if (customer.name == oldName) {
                customer.name = newName;
                customer.address = newAddress;
                customer.phone = newPhone;
                break;
            }
        }
    }

    Customer* searchCustomer(const std::string& name) {
        for (auto& customer : customers) {
            if (customer.name == name) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() const {
        for (const auto& customer : customers) {
            std::cout << "Name: " << customer.name << ", Address: " << customer.address << ", Phone: " << customer.phone << std::endl;
        }
    }

    void addShop(const std::string& name, const std::string& location) {
        shops.push_back(Shop(name, location));
    }

    void deleteShop(const std::string& name) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->name == name) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(const std::string& oldName, const std::string& newName, const std::string& newLocation) {
        for (auto& shop : shops) {
            if (shop.name == oldName) {
                shop.name = newName;
                shop.location = newLocation;
                break;
            }
        }
    }

    Shop* searchShop(const std::string& name) {
        for (auto& shop : shops) {
            if (shop.name == name) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayShops() const {
        for (const auto& shop : shops) {
            std::cout << "Name: " << shop.name << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    DeliveryService service;
    service.addCustomer("Alice", "123 Main St", "123-456-7890");
    service.addCustomer("Bob", "456 Elm St", "987-654-3210");
    service.addShop("DrinkShop", "789 Market St");
    service.addShop("Beverage Store", "321 Broadway");

    service.displayCustomers();
    service.displayShops();

    Customer* customer = service.searchCustomer("Alice");
    if (customer) {
        std::cout << "Found customer: " << customer->name << std::endl;
    }

    Shop* shop = service.searchShop("Beverage Store");
    if (shop) {
        std::cout << "Found shop: " << shop->name << std::endl;
    }

    service.updateCustomer("Bob", "Robert", "456 Elm St", "111-222-3333");
    service.updateShop("DrinkShop", "Cool Drinks", "789 Market St");

    service.deleteCustomer("Alice");
    service.deleteShop("Beverage Store");

    service.displayCustomers();
    service.displayShops();

    return 0;
}