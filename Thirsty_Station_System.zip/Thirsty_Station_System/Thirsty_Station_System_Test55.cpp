#include <iostream>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string phone;
};

struct Shop {
    int id;
    std::string name;
    std::string location;
};

const int MAX_CUSTOMERS = 100;
const int MAX_SHOPS = 100;

Customer customers[MAX_CUSTOMERS];
Shop shops[MAX_SHOPS];

int customerCount = 0;
int shopCount = 0;

void addCustomer(int id, std::string name, std::string phone) {
    if (customerCount < MAX_CUSTOMERS) {
        customers[customerCount++] = {id, name, phone};
    }
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            customers[i] = customers[--customerCount];
            return;
        }
    }
}

void updateCustomer(int id, std::string name, std::string phone) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            customers[i].name = name;
            customers[i].phone = phone;
            return;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; ++i) {
        std::cout << "ID: " << customers[i].id << ", Name: " << customers[i].name << ", Phone: " << customers[i].phone << std::endl;
    }
}

void addShop(int id, std::string name, std::string location) {
    if (shopCount < MAX_SHOPS) {
        shops[shopCount++] = {id, name, location};
    }
}

void deleteShop(int id) {
    for (int i = 0; i < shopCount; ++i) {
        if (shops[i].id == id) {
            shops[i] = shops[--shopCount];
            return;
        }
    }
}

void updateShop(int id, std::string name, std::string location) {
    for (int i = 0; i < shopCount; ++i) {
        if (shops[i].id == id) {
            shops[i].name = name;
            shops[i].location = location;
            return;
        }
    }
}

Shop* searchShop(int id) {
    for (int i = 0; i < shopCount; ++i) {
        if (shops[i].id == id) {
            return &shops[i];
        }
    }
    return nullptr;
}

void displayShops() {
    for (int i = 0; i < shopCount; ++i) {
        std::cout << "ID: " << shops[i].id << ", Name: " << shops[i].name << ", Location: " << shops[i].location << std::endl;
    }
}

int main() {
    addCustomer(1, "John Doe", "123456789");
    addCustomer(2, "Jane Doe", "987654321");
    
    addShop(1, "Drinkies", "Downtown");
    addShop(2, "Sip & Savor", "Uptown");
    
    std::cout << "Customers:" << std::endl;
    displayCustomers();

    std::cout << "Shops:" << std::endl;
    displayShops();

    return 0;
}