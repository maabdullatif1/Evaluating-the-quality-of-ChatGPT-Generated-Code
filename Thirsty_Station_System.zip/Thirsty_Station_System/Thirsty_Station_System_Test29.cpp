#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Customer {
public:
    int id;
    string name;
    string address;
    string phone;

    Customer(int i, string n, string a, string p) : id(i), name(n), address(a), phone(p) {}
};

class Shop {
public:
    int id;
    string name;
    string location;

    Shop(int i, string n, string l) : id(i), name(n), location(l) {}
};

class ServiceSystem {
private:
    vector<Customer> customers;
    vector<Shop> shops;

public:
    void addCustomer(int id, string name, string address, string phone) {
        customers.push_back(Customer(id, name, address, phone));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, string name, string address, string phone) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                customer.phone = phone;
                return;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "ID: " << customer.id << " Name: " << customer.name << " Address: " << customer.address << " Phone: " << customer.phone << endl;
        }
    }

    void addShop(int id, string name, string location) {
        shops.push_back(Shop(id, name, location));
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, string name, string location) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                return;
            }
        }
    }

    Shop* searchShop(int id) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayShops() {
        for (const auto &shop : shops) {
            cout << "ID: " << shop.id << " Name: " << shop.name << " Location: " << shop.location << endl;
        }
    }
};

int main() {
    ServiceSystem system;
    system.addCustomer(1, "Alice", "123 Street", "555-0123");
    system.addCustomer(2, "Bob", "456 Avenue", "555-0456");
    system.displayCustomers();

    system.addShop(1, "Cool Drinks", "Downtown");
    system.addShop(2, "Thirst Quenchers", "Uptown");
    system.displayShops();

    Customer* customer = system.searchCustomer(1);
    if (customer) {
        cout << "Found customer: " << customer->name << endl;
    }

    Shop* shop = system.searchShop(1);
    if (shop) {
        cout << "Found shop: " << shop->name << endl;
    }

    system.updateCustomer(1, "Alice Cooper", "789 Boulevard", "555-0789");
    system.displayCustomers();

    system.deleteCustomer(2);
    system.displayCustomers();

    system.updateShop(1, "Best Drinks", "Midtown");
    system.displayShops();

    system.deleteShop(2);
    system.displayShops();

    return 0;
}