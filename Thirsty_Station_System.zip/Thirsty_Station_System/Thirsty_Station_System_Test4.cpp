#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string address;
    std::string phoneNumber;

    Customer(int id, const std::string& name, const std::string& address, const std::string& phoneNumber)
        : id(id), name(name), address(address), phoneNumber(phoneNumber) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;

    Shop(int id, const std::string& name, const std::string& location)
        : id(id), name(name), location(location) {}
};

class DeliveryService {
private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(int id, const std::string& name, const std::string& address, const std::string& phoneNumber) {
        customers.emplace_back(id, name, address, phoneNumber);
    }

    void deleteCustomer(int id) {
        for(auto it = customers.begin(); it != customers.end(); ++it) {
            if(it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& address, const std::string& phoneNumber) {
        for(auto &customer : customers) {
            if(customer.id == id) {
                customer.name = name;
                customer.address = address;
                customer.phoneNumber = phoneNumber;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for(auto &customer : customers) {
            if(customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for(const auto &customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name 
                      << ", Address: " << customer.address 
                      << ", Phone: " << customer.phoneNumber << std::endl;
        }
    }

    void addShop(int id, const std::string& name, const std::string& location) {
        shops.emplace_back(id, name, location);
    }

    void deleteShop(int id) {
        for(auto it = shops.begin(); it != shops.end(); ++it) {
            if(it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, const std::string& name, const std::string& location) {
        for(auto &shop : shops) {
            if(shop.id == id) {
                shop.name = name;
                shop.location = location;
            }
        }
    }

    Shop* searchShop(int id) {
        for(auto &shop : shops) {
            if(shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

    void displayShops() {
        for(const auto &shop : shops) {
            std::cout << "ID: " << shop.id << ", Name: " << shop.name 
                      << ", Location: " << shop.location << std::endl;
        }
    }
};

int main() {
    DeliveryService service;
    service.addCustomer(1, "Alice", "123 Wonderland", "555-1234");
    service.addCustomer(2, "Bob", "456 Nowhere", "555-5678");
    service.displayCustomers();

    service.updateCustomer(1, "Alice Johnson", "123 Wonderland Ave", "555-0000");
    service.displayCustomers();

    Customer* customer = service.searchCustomer(1);
    if(customer) {
        std::cout << "Found customer: " << customer->name << std::endl;
    }

    service.deleteCustomer(2);
    service.displayCustomers();

    service.addShop(1, "QuickMart", "789 Commerce Blvd");
    service.addShop(2, "DrinkWorld", "101 Main St");
    service.displayShops();

    service.updateShop(1, "Quick Stop", "789 Commerce Blvd Suite 100");
    service.displayShops();

    Shop* shop = service.searchShop(2);
    if(shop) {
        std::cout << "Found shop: " << shop->name << std::endl;
    }

    service.deleteShop(1);
    service.displayShops();

    return 0;
}