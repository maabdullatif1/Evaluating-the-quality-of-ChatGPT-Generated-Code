#include <iostream>
#include <string>
using namespace std;

const int MAX_CUSTOMERS = 100;
const int MAX_SHOPS = 50;

struct Customer {
    int id;
    string name;
    string address;
};

struct Shop {
    int id;
    string name;
    string location;
};

Customer customers[MAX_CUSTOMERS];
Shop shops[MAX_SHOPS];
int customerCount = 0;
int shopCount = 0;

void addCustomer(int id, string name, string address) {
    if (customerCount < MAX_CUSTOMERS) {
        customers[customerCount++] = {id, name, address};
    }
}

void deleteCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            for (int j = i; j < customerCount - 1; ++j) {
                customers[j] = customers[j + 1];
            }
            --customerCount;
            break;
        }
    }
}

void updateCustomer(int id, string name, string address) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            customers[i] = {id, name, address};
            break;
        }
    }
}

Customer* searchCustomer(int id) {
    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].id == id) {
            return &customers[i];
        }
    }
    return nullptr;
}

void displayCustomers() {
    for (int i = 0; i < customerCount; ++i) {
        cout << "ID: " << customers[i].id << ", Name: " << customers[i].name
             << ", Address: " << customers[i].address << endl;
    }
}

void addShop(int id, string name, string location) {
    if (shopCount < MAX_SHOPS) {
        shops[shopCount++] = {id, name, location};
    }
}

void deleteShop(int id) {
    for (int i = 0; i < shopCount; ++i) {
        if (shops[i].id == id) {
            for (int j = i; j < shopCount - 1; ++j) {
                shops[j] = shops[j + 1];
            }
            --shopCount;
            break;
        }
    }
}

void updateShop(int id, string name, string location) {
    for (int i = 0; i < shopCount; ++i) {
        if (shops[i].id == id) {
            shops[i] = {id, name, location};
            break;
        }
    }
}

Shop* searchShop(int id) {
    for (int i = 0; i < shopCount; ++i) {
        if (shops[i].id == id) {
            return &shops[i];
        }
    }
    return nullptr;
}

void displayShops() {
    for (int i = 0; i < shopCount; ++i) {
        cout << "ID: " << shops[i].id << ", Name: " << shops[i].name
             << ", Location: " << shops[i].location << endl;
    }
}

int main() {
    addCustomer(1, "Alice", "123 Main St");
    addCustomer(2, "Bob", "456 Side St");
    addShop(1, "Happy Drinks", "Market Square");
    addShop(2, "Thirst Quenchers", "High Street");

    updateCustomer(1, "Alice Smith", "123 Main St, Apt 4B");
    deleteCustomer(2);
    updateShop(1, "Happy Drinks Co.", "Market Square East");
    deleteShop(2);

    Customer* c = searchCustomer(1);
    if (c) {
        cout << "Found Customer - ID: " << c->id << ", Name: " << c->name << ", Address: " << c->address << endl;
    }

    Shop* s = searchShop(1);
    if (s) {
        cout << "Found Shop - ID: " << s->id << ", Name: " << s->name << ", Location: " << s->location << endl;
    }

    cout << "\nAll Customers:" << endl;
    displayCustomers();

    cout << "\nAll Shops:" << endl;
    displayShops();

    return 0;
}