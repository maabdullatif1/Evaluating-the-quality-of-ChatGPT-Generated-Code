#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string address;
    
    Customer(int id, std::string name, std::string address)
        : id(id), name(name), address(address) {}
    
    void update(std::string newName, std::string newAddress) {
        name = newName;
        address = newAddress;
    }

    void display() {
        std::cout << "Customer ID: " << id << ", Name: " << name 
                  << ", Address: " << address << std::endl;
    }
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;
    
    Shop(int id, std::string name, std::string location)
        : id(id), name(name), location(location) {}
    
    void update(std::string newName, std::string newLocation) {
        name = newName;
        location = newLocation;
    }

    void display() {
        std::cout << "Shop ID: " << id << ", Name: " << name 
                  << ", Location: " << location << std::endl;
    }
};

class DrinksDeliveryService {
    std::vector<Customer> customers;
    std::vector<Shop> shops;

public:
    void addCustomer(int id, std::string name, std::string address) {
        customers.push_back(Customer(id, name, address));
    }

    void deleteCustomer(int id) {
        for(auto it = customers.begin(); it != customers.end(); ++it) {
            if(it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, std::string name, std::string address) {
        for(auto &customer : customers) {
            if(customer.id == id) {
                customer.update(name, address);
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for(auto &customer : customers) {
            if(customer.id == id) {
                customer.display();
                return;
            }
        }
        std::cout << "Customer not found.\n";
    }

    void displayCustomers() {
        for(auto &customer : customers) {
            customer.display();
        }
    }

    void addShop(int id, std::string name, std::string location) {
        shops.push_back(Shop(id, name, location));
    }

    void deleteShop(int id) {
        for(auto it = shops.begin(); it != shops.end(); ++it) {
            if(it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, std::string name, std::string location) {
        for(auto &shop : shops) {
            if(shop.id == id) {
                shop.update(name, location);
                break;
            }
        }
    }

    void searchShop(int id) {
        for(auto &shop : shops) {
            if(shop.id == id) {
                shop.display();
                return;
            }
        }
        std::cout << "Shop not found.\n";
    }

    void displayShops() {
        for(auto &shop : shops) {
            shop.display();
        }
    }
};

int main() {
    DrinksDeliveryService service;
    service.addCustomer(1, "John Doe", "123 Main St");
    service.addCustomer(2, "Jane Smith", "456 Elm St");
    service.displayCustomers();
    
    service.addShop(1, "Downtown Drinks", "789 Oak St");
    service.addShop(2, "Uptown Beverages", "321 Birch Rd");
    service.displayShops();

    service.updateCustomer(1, "John Doe", "987 Maple Ave");
    service.searchCustomer(1);

    service.updateShop(1, "Central Liquids", "456 Pine St");
    service.searchShop(1);

    service.deleteCustomer(2);
    service.displayCustomers();

    service.deleteShop(2);
    service.displayShops();
    
    return 0;
}