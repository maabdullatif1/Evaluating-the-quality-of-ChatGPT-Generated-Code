#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    string address;
    string phone;
};

struct Shop {
    int id;
    string name;
    string address;
    string phone;
};

class DeliveryService {
    vector<Customer> customers;
    vector<Shop> shops;
    int customerIdCounter;
    int shopIdCounter;
    
public:
    DeliveryService() : customerIdCounter(0), shopIdCounter(0) {}

    void addCustomer(const string &name, const string &address, const string &phone) {
        customers.push_back({customerIdCounter++, name, address, phone});
    }

    void deleteCustomer(int id) {
        auto it = customers.begin();
        while (it != customers.end()) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
            ++it;
        }
    }

    void updateCustomer(int id, const string &name, const string &address, const string &phone) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                customer.phone = phone;
                break;
            }
        }
    }

    void searchCustomer(int id) {
        for (const auto &customer : customers) {
            if (customer.id == id) {
                cout << "Customer found: " << customer.name << ", " << customer.address << ", " << customer.phone << endl;
                return;
            }
        }
        cout << "Customer not found" << endl;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << customer.id << ": " << customer.name << ", " << customer.address << ", " << customer.phone << endl;
        }
    }

    void addShop(const string &name, const string &address, const string &phone) {
        shops.push_back({shopIdCounter++, name, address, phone});
    }

    void deleteShop(int id) {
        auto it = shops.begin();
        while (it != shops.end()) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
            ++it;
        }
    }

    void updateShop(int id, const string &name, const string &address, const string &phone) {
        for (auto &shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.address = address;
                shop.phone = phone;
                break;
            }
        }
    }

    void searchShop(int id) {
        for (const auto &shop : shops) {
            if (shop.id == id) {
                cout << "Shop found: " << shop.name << ", " << shop.address << ", " << shop.phone << endl;
                return;
            }
        }
        cout << "Shop not found" << endl;
    }

    void displayShops() {
        for (const auto &shop : shops) {
            cout << shop.id << ": " << shop.name << ", " << shop.address << ", " << shop.phone << endl;
        }
    }
};

int main() {
    DeliveryService service;
    service.addCustomer("John Doe", "123 Elm St", "555-1234");
    service.addCustomer("Jane Smith", "456 Oak St", "555-5678");
    service.addShop("Local Drink Shop", "789 Maple Ave", "555-8765");
    service.addShop("Beverage Co.", "321 Pine Rd", "555-4321");
    service.displayCustomers();
    service.displayShops();
    service.searchCustomer(0);
    service.searchShop(1);
    service.updateCustomer(0, "John Doe", "123 Elm St", "555-9999");
    service.updateShop(1, "Beverage Co.", "654 Spruce Ave", "555-0987");
    service.displayCustomers();
    service.displayShops();
    service.deleteCustomer(1);
    service.deleteShop(0);
    service.displayCustomers();
    service.displayShops();
    return 0;
}