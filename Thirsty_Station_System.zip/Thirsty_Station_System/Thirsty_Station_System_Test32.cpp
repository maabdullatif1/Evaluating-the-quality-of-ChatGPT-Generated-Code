#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string address;
    std::string phone;
    
    Customer(int id, std::string name, std::string address, std::string phone)
        : id(id), name(name), address(address), phone(phone) {}
};

class Shop {
public:
    int id;
    std::string name;
    std::string location;
    std::string phone;
    
    Shop(int id, std::string name, std::string location, std::string phone)
        : id(id), name(name), location(location), phone(phone) {}
};

class DeliverySystem {
    std::vector<Customer> customers;
    std::vector<Shop> shops;
    
public:
    void addCustomer(int id, std::string name, std::string address, std::string phone) {
        customers.push_back(Customer(id, name, address, phone));
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, std::string name, std::string address, std::string phone) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                customer.phone = phone;
                break;
            }
        }
    }
    
    void searchCustomer(int id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer ID: " << customer.id 
                          << ", Name: " << customer.name 
                          << ", Address: " << customer.address 
                          << ", Phone: " << customer.phone << std::endl;
                return;
            }
        }
        std::cout << "Customer not found." << std::endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id 
                      << ", Name: " << customer.name 
                      << ", Address: " << customer.address 
                      << ", Phone: " << customer.phone << std::endl;
        }
    }
    
    void addShop(int id, std::string name, std::string location, std::string phone) {
        shops.push_back(Shop(id, name, location, phone));
    }
    
    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }
    
    void updateShop(int id, std::string name, std::string location, std::string phone) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                shop.name = name;
                shop.location = location;
                shop.phone = phone;
                break;
            }
        }
    }
    
    void searchShop(int id) {
        for (const auto& shop : shops) {
            if (shop.id == id) {
                std::cout << "Shop ID: " << shop.id 
                          << ", Name: " << shop.name 
                          << ", Location: " << shop.location 
                          << ", Phone: " << shop.phone << std::endl;
                return;
            }
        }
        std::cout << "Shop not found." << std::endl;
    }

    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "Shop ID: " << shop.id 
                      << ", Name: " << shop.name 
                      << ", Location: " << shop.location 
                      << ", Phone: " << shop.phone << std::endl;
        }
    }
};

int main() {
    DeliverySystem ds;
    ds.addCustomer(1, "John Doe", "123 Elm St", "555-1234");
    ds.addShop(1, "Drink Heaven", "456 Oak St", "555-5678");
    ds.displayCustomers();
    ds.displayShops();
    ds.searchCustomer(1);
    ds.searchShop(1);
    ds.updateCustomer(1, "John Smith", "789 Maple St", "555-8765");
    ds.updateShop(1, "Drink Paradise", "789 Pine St", "555-4321");
    ds.displayCustomers();
    ds.displayShops();
    ds.deleteCustomer(1);
    ds.deleteShop(1);
    ds.displayCustomers();
    ds.displayShops();
    return 0;
}