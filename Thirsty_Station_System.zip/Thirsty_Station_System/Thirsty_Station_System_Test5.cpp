#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    std::string address;
    std::string phone;
};

struct Shop {
    int id;
    std::string name;
    std::string location;
    std::string owner;
};

class DeliveryService {
private:
    std::vector<Customer> customers;
    std::vector<Shop> shops;
    int customerIDCounter = 1;
    int shopIDCounter = 1;

    Customer* findCustomerById(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Shop* findShopById(int id) {
        for (auto& shop : shops) {
            if (shop.id == id) {
                return &shop;
            }
        }
        return nullptr;
    }

public:
    void addCustomer(const std::string& name, const std::string& address, const std::string& phone) {
        customers.push_back({customerIDCounter++, name, address, phone});
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& name, const std::string& address, const std::string& phone) {
        Customer* customer = findCustomerById(id);
        if (customer) {
            customer->name = name;
            customer->address = address;
            customer->phone = phone;
        }
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id
                      << ", Name: " << customer.name
                      << ", Address: " << customer.address
                      << ", Phone: " << customer.phone << std::endl;
        }
    }

    Customer* searchCustomer(int id) {
        return findCustomerById(id);
    }

    void addShop(const std::string& name, const std::string& location, const std::string& owner) {
        shops.push_back({shopIDCounter++, name, location, owner});
    }

    void deleteShop(int id) {
        for (auto it = shops.begin(); it != shops.end(); ++it) {
            if (it->id == id) {
                shops.erase(it);
                break;
            }
        }
    }

    void updateShop(int id, const std::string& name, const std::string& location, const std::string& owner) {
        Shop* shop = findShopById(id);
        if (shop) {
            shop->name = name;
            shop->location = location;
            shop->owner = owner;
        }
    }

    void displayShops() {
        for (const auto& shop : shops) {
            std::cout << "ID: " << shop.id
                      << ", Name: " << shop.name
                      << ", Location: " << shop.location
                      << ", Owner: " << shop.owner << std::endl;
        }
    }

    Shop* searchShop(int id) {
        return findShopById(id);
    }
};

int main() {
    DeliveryService service;

    service.addCustomer("Alice", "123 Street", "1234567890");
    service.addCustomer("Bob", "456 Avenue", "0987654321");

    service.addShop("Shop A", "Downtown", "Owner A");
    service.addShop("Shop B", "Uptown", "Owner B");

    service.displayCustomers();
    service.displayShops();

    service.updateCustomer(1, "Alice M", "123 Street", "1234567890");
    service.updateShop(1, "Shop A", "Downtown Central", "Owner A");

    service.displayCustomers();
    service.displayShops();

    service.deleteCustomer(2);
    service.deleteShop(2);

    service.displayCustomers();
    service.displayShops();

    return 0;
}