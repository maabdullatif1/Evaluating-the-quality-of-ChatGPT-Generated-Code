#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    std::string name;
    std::string country;
    
    Manufacturer(std::string n, std::string c) : name(n), country(c) {}
};

class ComputerPart {
public:
    std::string partName;
    std::string partNumber;
    Manufacturer* manufacturer;
    
    ComputerPart(std::string pn, std::string pnum, Manufacturer* m) : partName(pn), partNumber(pnum), manufacturer(m) {}
};

class PartsManagementSystem {
    std::vector<ComputerPart> parts;
    std::vector<Manufacturer> manufacturers;
    
public:
    void addManufacturer(std::string name, std::string country) {
        manufacturers.push_back(Manufacturer(name, country));
    }
    
    void addPart(std::string name, std::string number, std::string manufacturerName) {
        Manufacturer* manuf = findManufacturer(manufacturerName);
        if (manuf) {
            parts.push_back(ComputerPart(name, number, manuf));
        }
    }
    
    void deletePart(std::string partNumber) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partNumber == partNumber) {
                parts.erase(it);
                return;
            }
        }
    }
    
    void updatePart(std::string partNumber, std::string newName, std::string newManufacturerName) {
        Manufacturer* manuf = findManufacturer(newManufacturerName);
        if (manuf) {
            for (auto& part : parts) {
                if (part.partNumber == partNumber) {
                    part.partName = newName;
                    part.manufacturer = manuf;
                    return;
                }
            }
        }
    }
    
    ComputerPart* searchPart(std::string partNumber) {
        for (auto& part : parts) {
            if (part.partNumber == partNumber) {
                return &part;
            }
        }
        return nullptr;
    }
    
    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "Part Name: " << part.partName << ", Part Number: " << part.partNumber
                      << ", Manufacturer: " << part.manufacturer->name << ", Country: " << part.manufacturer->country << std::endl;
        }
    }
    
private:
    Manufacturer* findManufacturer(std::string name) {
        for (auto& manuf : manufacturers) {
            if (manuf.name == name) {
                return &manuf;
            }
        }
        return nullptr;
    }
};

int main() {
    PartsManagementSystem pms;
    pms.addManufacturer("Intel", "USA");
    pms.addManufacturer("AMD", "USA");
    
    pms.addPart("Core i7", "1234", "Intel");
    pms.addPart("Ryzen 5", "5678", "AMD");
    
    pms.displayParts();
    
    pms.updatePart("1234", "Core i9", "Intel");
    pms.displayParts();
    
    pms.deletePart("5678");
    pms.displayParts();
    
    return 0;
}