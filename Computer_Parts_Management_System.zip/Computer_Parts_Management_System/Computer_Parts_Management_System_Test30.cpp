#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
    std::string name;
    std::string address;

public:
    Manufacturer(const std::string& n, const std::string& a) : name(n), address(a) {}
    std::string getName() const { return name; }
    std::string getAddress() const { return address; }
    void setName(const std::string& n) { name = n; }
    void setAddress(const std::string& a) { address = a; }
};

class ComputerPart {
    std::string name;
    int partNumber;
    Manufacturer manufacturer;

public:
    ComputerPart(const std::string& n, int pn, const Manufacturer& m) : name(n), partNumber(pn), manufacturer(m) {}
    std::string getName() const { return name; }
    int getPartNumber() const { return partNumber; }
    Manufacturer getManufacturer() const { return manufacturer; }
    void setName(const std::string& n) { name = n; }
    void setPartNumber(int pn) { partNumber = pn; }
    void setManufacturer(const Manufacturer& m) { manufacturer = m; }
};

class PartsManagementSystem {
    std::vector<ComputerPart> parts;

public:
    void addPart(const ComputerPart& part) {
        parts.push_back(part);
    }

    bool deletePart(int partNumber) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->getPartNumber() == partNumber) {
                parts.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updatePart(int partNumber, const std::string& newName, const Manufacturer& newManufacturer) {
        for (auto& part : parts) {
            if (part.getPartNumber() == partNumber) {
                part.setName(newName);
                part.setManufacturer(newManufacturer);
                return true;
            }
        }
        return false;
    }

    ComputerPart* searchPart(int partNumber) {
        for (auto& part : parts) {
            if (part.getPartNumber() == partNumber) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() const {
        for (const auto& part : parts) {
            std::cout << "Part Name: " << part.getName() << ", Part Number: " << part.getPartNumber() 
                      << ", Manufacturer: " << part.getManufacturer().getName() 
                      << ", Address: " << part.getManufacturer().getAddress() << std::endl;
        }
    }
};

int main() {
    PartsManagementSystem pms;

    Manufacturer m1("Intel", "123 Silicon Valley");
    Manufacturer m2("AMD", "456 Tech Lane");

    pms.addPart(ComputerPart("Processor", 1001, m1));
    pms.addPart(ComputerPart("Graphics Card", 1002, m2));

    pms.displayParts();

    pms.updatePart(1002, "GPU", m1);

    if (auto part = pms.searchPart(1001)) {
        std::cout << "Found Part - Name: " << part->getName() << std::endl;
    }

    pms.deletePart(1001);

    pms.displayParts();

    return 0;
}