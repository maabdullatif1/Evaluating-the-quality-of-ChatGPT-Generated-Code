#include <iostream>
#include <string>
#include <vector>

class Manufacturer {
public:
    std::string name;
    std::string country;
    Manufacturer(const std::string &n, const std::string &c) : name(n), country(c) {}
};

class ComputerPart {
public:
    std::string name;
    std::string type;
    double price;
    Manufacturer manufacturer;
    ComputerPart(const std::string &n, const std::string &t, double p, const Manufacturer &m)
        : name(n), type(t), price(p), manufacturer(m) {}
};

class PartsManager {
private:
    std::vector<ComputerPart> parts;
public:
    void addPart(const ComputerPart &part) {
        parts.push_back(part);
    }
    
    void deletePart(const std::string &partName) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == partName) {
                parts.erase(it);
                break;
            }
        }
    }
    
    void updatePart(const std::string &partName, const std::string &newType, double newPrice, const Manufacturer &newManufacturer) {
        for (auto &part : parts) {
            if (part.name == partName) {
                part.type = newType;
                part.price = newPrice;
                part.manufacturer = newManufacturer;
                break;
            }
        }
    }
    
    ComputerPart* searchPart(const std::string &partName) {
        for (auto &part : parts) {
            if (part.name == partName) {
                return &part;
            }
        }
        return nullptr;
    }
    
    void displayParts() {
        for (const auto &part : parts) {
            std::cout << "Part Name: " << part.name << "\nType: " << part.type 
                      << "\nPrice: $" << part.price << "\nManufacturer: " 
                      << part.manufacturer.name << ", " << part.manufacturer.country << "\n\n";
        }
    }
};

int main() {
    PartsManager manager;
    
    Manufacturer intel("Intel", "USA");
    Manufacturer amd("AMD", "USA");
    
    manager.addPart(ComputerPart("Core i7", "CPU", 300.00, intel));
    manager.addPart(ComputerPart("Ryzen 5", "CPU", 250.00, amd));
    
    manager.displayParts();
    
    manager.updatePart("Ryzen 5", "CPU", 230.00, Manufacturer("AMD", "USA"));
    
    manager.displayParts();
    
    ComputerPart* part = manager.searchPart("Core i7");
    if (part) {
        std::cout << "Found Part: " << part->name << "\n";
    }
    
    manager.deletePart("Core i7");
    manager.displayParts();
    
    return 0;
}