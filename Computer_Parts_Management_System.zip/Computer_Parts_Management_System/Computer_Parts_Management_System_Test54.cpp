#include <iostream>
#include <vector>
#include <string>
using namespace std;

class ComputerPart {
public:
    string partName;
    string manufacturer;
    double price;

    ComputerPart(string partName, string manufacturer, double price)
        : partName(partName), manufacturer(manufacturer), price(price) {}
};

class PartsManager {
private:
    vector<ComputerPart> parts;

public:
    void addPart(const string& partName, const string& manufacturer, double price) {
        parts.push_back(ComputerPart(partName, manufacturer, price));
    }

    void deletePart(const string& partName) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partName == partName) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(const string& partName, const string& manufacturer, double price) {
        for (auto& part : parts) {
            if (part.partName == partName) {
                part.manufacturer = manufacturer;
                part.price = price;
                break;
            }
        }
    }

    void searchPart(const string& partName) const {
        bool found = false;
        for (const auto& part : parts) {
            if (part.partName == partName) {
                cout << "Found Part: " << part.partName << ", Manufacturer: " << part.manufacturer << ", Price: $" << part.price << endl;
                found = true;
                break;
            }
        }
        if (!found) {
            cout << "Part not found." << endl;
        }
    }

    void displayParts() const {
        if (parts.empty()) {
            cout << "No parts to display." << endl;
            return;
        }
        for (const auto& part : parts) {
            cout << "Part: " << part.partName << ", Manufacturer: " << part.manufacturer << ", Price: $" << part.price << endl;
        }
    }
};

int main() {
    PartsManager manager;
    int choice;
    
    while (true) {
        cout << "1. Add Part" << endl;
        cout << "2. Delete Part" << endl;
        cout << "3. Update Part" << endl;
        cout << "4. Search Part" << endl;
        cout << "5. Display Parts" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            string partName, manufacturer;
            double price;
            cout << "Enter Part Name: ";
            cin >> partName;
            cout << "Enter Manufacturer: ";
            cin >> manufacturer;
            cout << "Enter Price: ";
            cin >> price;
            manager.addPart(partName, manufacturer, price);
        } else if (choice == 2) {
            string partName;
            cout << "Enter Part Name to Delete: ";
            cin >> partName;
            manager.deletePart(partName);
        } else if (choice == 3) {
            string partName, manufacturer;
            double price;
            cout << "Enter Part Name to Update: ";
            cin >> partName;
            cout << "Enter New Manufacturer: ";
            cin >> manufacturer;
            cout << "Enter New Price: ";
            cin >> price;
            manager.updatePart(partName, manufacturer, price);
        } else if (choice == 4) {
            string partName;
            cout << "Enter Part Name to Search: ";
            cin >> partName;
            manager.searchPart(partName);
        } else if (choice == 5) {
            manager.displayParts();
        } else if (choice == 6) {
            break;
        } else {
            cout << "Invalid choice. Please try again." << endl;
        }
    }

    return 0;
}