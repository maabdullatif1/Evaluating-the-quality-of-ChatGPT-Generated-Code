#include <iostream>
#include <vector>
#include <string>

struct Manufacturer {
    std::string name;
    std::string country;
};

struct ComputerPart {
    std::string partName;
    std::string partNumber;
    Manufacturer manufacturer;
};

class ComputerPartsManager {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(const std::string& partName, const std::string& partNumber, const std::string& manufacturerName, const std::string& country) {
        Manufacturer mfg = {manufacturerName, country};
        ComputerPart part = {partName, partNumber, mfg};
        parts.push_back(part);
    }

    bool deletePart(const std::string& partNumber) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partNumber == partNumber) {
                parts.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updatePart(const std::string& partNumber, const std::string& newPartName, const std::string& newManufacturerName, const std::string& newCountry) {
        for (auto& part : parts) {
            if (part.partNumber == partNumber) {
                part.partName = newPartName;
                part.manufacturer.name = newManufacturerName;
                part.manufacturer.country = newCountry;
                return true;
            }
        }
        return false;
    }

    ComputerPart* searchPart(const std::string& partNumber) {
        for (auto& part : parts) {
            if (part.partNumber == partNumber) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() const {
        for (const auto& part : parts) {
            std::cout << "Part Name: " << part.partName << std::endl;
            std::cout << "Part Number: " << part.partNumber << std::endl;
            std::cout << "Manufacturer: " << part.manufacturer.name << std::endl;
            std::cout << "Country: " << part.manufacturer.country << std::endl << std::endl;
        }
    }
};

int main() {
    ComputerPartsManager manager;

    manager.addPart("CPU", "123-456", "Intel", "USA");
    manager.addPart("GPU", "789-012", "Nvidia", "USA");

    std::cout << "Display all parts:" << std::endl;
    manager.displayParts();

    manager.updatePart("789-012", "Graphics Card", "Nvidia Corp", "USA");

    ComputerPart* foundPart = manager.searchPart("123-456");
    if (foundPart) {
        std::cout << "Search Result: " << std::endl;
        std::cout << "Part Name: " << foundPart->partName << std::endl;
        std::cout << "Part Number: " << foundPart->partNumber << std::endl;
    }

    manager.deletePart("123-456");
    
    std::cout << "\nAfter deletion:" << std::endl;
    manager.displayParts();

    return 0;
}