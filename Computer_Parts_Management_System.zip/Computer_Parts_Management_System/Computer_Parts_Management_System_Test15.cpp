#include <iostream>
#include <vector>
#include <string>

using namespace std;

class ComputerPart {
public:
    string partName;
    string manufacturer;
    double price;

    ComputerPart(string name, string mfr, double p) : partName(name), manufacturer(mfr), price(p) {}
};

class PartManager {
private:
    vector<ComputerPart> inventory;

    int findPartIndex(const string& partName) {
        for (int i = 0; i < inventory.size(); ++i) {
            if (inventory[i].partName == partName) {
                return i;
            }
        }
        return -1;
    }

public:
    void addPart(const string& partName, const string& manufacturer, double price) {
        inventory.push_back(ComputerPart(partName, manufacturer, price));
    }

    void deletePart(const string& partName) {
        int index = findPartIndex(partName);
        if (index != -1) { 
            inventory.erase(inventory.begin() + index);
        }
    }

    void updatePart(const string& partName, const string& newManufacturer, double newPrice) {
        int index = findPartIndex(partName);
        if (index != -1) {
            inventory[index].manufacturer = newManufacturer;
            inventory[index].price = newPrice;
        }
    }

    void searchPart(const string& partName) {
        int index = findPartIndex(partName);
        if (index != -1) {
            cout << "Part Name: " << inventory[index].partName << ", Manufacturer: " << inventory[index].manufacturer << ", Price: $" << inventory[index].price << endl;
        } else {
            cout << "Part not found." << endl;
        }
    }

    void displayParts() {
        for (const auto& part : inventory) {
            cout << "Part Name: " << part.partName << ", Manufacturer: " << part.manufacturer << ", Price: $" << part.price << endl;
        }
    }
};

int main() {
    PartManager manager;
    int choice;
    string partName, manufacturer;
    double price;

    do {
        cout << "1. Add Part\n";
        cout << "2. Delete Part\n";
        cout << "3. Update Part\n";
        cout << "4. Search Part\n";
        cout << "5. Display Parts\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter Part Name: ";
                cin >> partName;
                cout << "Enter Manufacturer: ";
                cin >> manufacturer;
                cout << "Enter Price: ";
                cin >> price;
                manager.addPart(partName, manufacturer, price);
                break;
            case 2:
                cout << "Enter Part Name to Delete: ";
                cin >> partName;
                manager.deletePart(partName);
                break;
            case 3:
                cout << "Enter Part Name to Update: ";
                cin >> partName;
                cout << "Enter New Manufacturer: ";
                cin >> manufacturer;
                cout << "Enter New Price: ";
                cin >> price;
                manager.updatePart(partName, manufacturer, price);
                break;
            case 4:
                cout << "Enter Part Name to Search: ";
                cin >> partName;
                manager.searchPart(partName);
                break;
            case 5:
                manager.displayParts();
                break;
            case 6:
                cout << "Exiting program." << endl;
                break;
            default:
                cout << "Invalid choice." << endl;
        }
    } while (choice != 6);

    return 0;
}