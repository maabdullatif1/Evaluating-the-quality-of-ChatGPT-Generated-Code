#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    std::string name;
    std::string country;
    Manufacturer(std::string n, std::string c) : name(n), country(c) {}
};

class ComputerPart {
public:
    std::string name;
    std::string type;
    double price;
    Manufacturer manufacturer;
    ComputerPart(std::string n, std::string t, double p, Manufacturer m) 
        : name(n), type(t), price(p), manufacturer(m) {}
};

class PartsManagementSystem {
private:
    std::vector<ComputerPart> parts;

    int findPartIndex(const std::string& name) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].name == name)
                return i;
        }
        return -1;
    }

public:
    void addPart(const std::string& name, const std::string& type, double price, const Manufacturer& manufacturer) {
        ComputerPart part(name, type, price, manufacturer);
        parts.push_back(part);
    }

    void deletePart(const std::string& name) {
        int index = findPartIndex(name);
        if (index != -1) {
            parts.erase(parts.begin() + index);
        }
    }

    void updatePart(const std::string& name, const std::string& type, double price, const Manufacturer& manufacturer) {
        int index = findPartIndex(name);
        if (index != -1) {
            parts[index].type = type;
            parts[index].price = price;
            parts[index].manufacturer = manufacturer;
        }
    }

    void searchPart(const std::string& name) {
        int index = findPartIndex(name);
        if (index != -1) {
            std::cout << "Part found: " << parts[index].name << ", "
                      << parts[index].type << ", " << parts[index].price
                      << ", " << parts[index].manufacturer.name << ", "
                      << parts[index].manufacturer.country << std::endl;
        } else {
            std::cout << "Part not found." << std::endl;
        }
    }

    void displayAllParts() {
        for (const auto& part : parts) {
            std::cout << part.name << ", " << part.type << ", " << part.price
                      << ", " << part.manufacturer.name << ", " << part.manufacturer.country << std::endl;
        }
    }
};

int main() {
    PartsManagementSystem pms;
    Manufacturer intel("Intel Corp", "USA");
    Manufacturer amd("AMD", "USA");
    pms.addPart("Core i7", "CPU", 300.00, intel);
    pms.addPart("Ryzen 5", "CPU", 200.00, amd);
    pms.displayAllParts();
    pms.searchPart("Core i7");
    pms.updatePart("Core i7", "CPU", 299.99, intel);
    pms.searchPart("Core i7");
    pms.deletePart("Ryzen 5");
    pms.displayAllParts();
    return 0;
}