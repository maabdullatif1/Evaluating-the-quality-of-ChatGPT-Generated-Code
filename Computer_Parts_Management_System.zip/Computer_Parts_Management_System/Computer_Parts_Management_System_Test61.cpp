#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string partName;
    std::string manufacturer;
    int quantity;

    ComputerPart(std::string name, std::string manuf, int qty)
        : partName(name), manufacturer(manuf), quantity(qty) {}
};

class Inventory {
private:
    std::vector<ComputerPart> parts;

    int findPartIndex(const std::string& name) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].partName == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addPart(const std::string& name, const std::string& manuf, int qty) {
        parts.push_back(ComputerPart(name, manuf, qty));
    }

    void deletePart(const std::string& name) {
        int index = findPartIndex(name);
        if (index != -1) {
            parts.erase(parts.begin() + index);
        } else {
            std::cout << "Part not found\n";
        }
    }

    void updatePart(const std::string& name, const std::string& manuf, int qty) {
        int index = findPartIndex(name);
        if (index != -1) {
            parts[index].manufacturer = manuf;
            parts[index].quantity = qty;
        } else {
            std::cout << "Part not found\n";
        }
    }

    void searchPart(const std::string& name) {
        int index = findPartIndex(name);
        if (index != -1) {
            std::cout << "Part: " << parts[index].partName 
                      << ", Manufacturer: " << parts[index].manufacturer 
                      << ", Quantity: " << parts[index].quantity << "\n";
        } else {
            std::cout << "Part not found\n";
        }
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "Part: " << part.partName 
                      << ", Manufacturer: " << part.manufacturer 
                      << ", Quantity: " << part.quantity << "\n";
        }
    }
};

int main() {
    Inventory inventory;
    int choice;
    std::string name, manufacturer;
    int quantity;

    while (true) {
        std::cout << "1. Add Part\n";
        std::cout << "2. Delete Part\n";
        std::cout << "3. Update Part\n";
        std::cout << "4. Search Part\n";
        std::cout << "5. Display Parts\n";
        std::cout << "6. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
        case 1:
            std::cout << "Enter part name: ";
            std::cin >> name;
            std::cout << "Enter manufacturer: ";
            std::cin >> manufacturer;
            std::cout << "Enter quantity: ";
            std::cin >> quantity;
            inventory.addPart(name, manufacturer, quantity);
            break;
        case 2:
            std::cout << "Enter part name to delete: ";
            std::cin >> name;
            inventory.deletePart(name);
            break;
        case 3:
            std::cout << "Enter part name to update: ";
            std::cin >> name;
            std::cout << "Enter new manufacturer: ";
            std::cin >> manufacturer;
            std::cout << "Enter new quantity: ";
            std::cin >> quantity;
            inventory.updatePart(name, manufacturer, quantity);
            break;
        case 4:
            std::cout << "Enter part name to search: ";
            std::cin >> name;
            inventory.searchPart(name);
            break;
        case 5:
            inventory.displayParts();
            break;
        case 6:
            return 0;
        default:
            std::cout << "Invalid choice\n";
        }
    }
}