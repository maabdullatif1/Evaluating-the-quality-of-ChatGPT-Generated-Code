#include <iostream>
#include <vector>
#include <string>

struct Part {
    std::string name;
    std::string manufacturer;
    double price;
    int stock;
};

class PartsManagementSystem {
private:
    std::vector<Part> parts;

    int findPartIndex(const std::string& name) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addPart(const std::string& name, const std::string& manufacturer, double price, int stock) {
        if (findPartIndex(name) != -1) {
            std::cout << "Part already exists.\n";
            return;
        }
        parts.push_back({name, manufacturer, price, stock});
    }

    void deletePart(const std::string& name) {
        int index = findPartIndex(name);
        if (index == -1) {
            std::cout << "Part not found.\n";
            return;
        }
        parts.erase(parts.begin() + index);
    }

    void updatePart(const std::string& name, const std::string& manufacturer, double price, int stock) {
        int index = findPartIndex(name);
        if (index == -1) {
            std::cout << "Part not found.\n";
            return;
        }
        parts[index] = {name, manufacturer, price, stock};
    }

    void searchPart(const std::string& name) {
        int index = findPartIndex(name);
        if (index == -1) {
            std::cout << "Part not found.\n";
            return;
        }
        std::cout << "Part: " << parts[index].name 
                  << ", Manufacturer: " << parts[index].manufacturer 
                  << ", Price: " << parts[index].price 
                  << ", Stock: " << parts[index].stock << "\n";
    }

    void displayAllParts() {
        if (parts.empty()) {
            std::cout << "No parts available.\n";
            return;
        }
        for (const auto& part : parts) {
            std::cout << "Part: " << part.name 
                      << ", Manufacturer: " << part.manufacturer 
                      << ", Price: " << part.price 
                      << ", Stock: " << part.stock << "\n";
        }
    }
};

int main() {
    PartsManagementSystem system;
    system.addPart("Graphics Card", "NVIDIA", 349.99, 50);
    system.addPart("Processor", "Intel", 249.99, 30);
    system.displayAllParts();
    system.searchPart("Graphics Card");
    system.updatePart("Graphics Card", "NVIDIA", 329.99, 45);
    system.searchPart("Graphics Card");
    system.deletePart("Processor");
    system.displayAllParts();
    return 0;
}