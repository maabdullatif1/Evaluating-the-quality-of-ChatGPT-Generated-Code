#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Manufacturer {
public:
    string name;
    string country;

    Manufacturer(string n, string c) : name(n), country(c) {}
};

class ComputerPart {
public:
    string partID;
    string partName;
    Manufacturer manufacturer;

    ComputerPart(string id, string name, Manufacturer m) : partID(id), partName(name), manufacturer(m) {}
};

class ManagementSystem {
    vector<ComputerPart> parts;

public:
    void addPart(string id, string name, Manufacturer manufacturer) {
        parts.push_back(ComputerPart(id, name, manufacturer));
    }

    void deletePart(string id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partID == id) {
                parts.erase(it);
                return;
            }
        }
    }

    void updatePart(string id, string newName, Manufacturer newManufacturer) {
        for (auto& part : parts) {
            if (part.partID == id) {
                part.partName = newName;
                part.manufacturer = newManufacturer;
                return;
            }
        }
    }

    void searchPart(string id) {
        for (const auto& part : parts) {
            if (part.partID == id) {
                cout << "Part ID: " << part.partID << ", Part Name: " << part.partName
                     << ", Manufacturer: " << part.manufacturer.name << ", Country: " << part.manufacturer.country << endl;
                return;
            }
        }
        cout << "Part not found." << endl;
    }

    void displayParts() {
        for (const auto& part : parts) {
            cout << "Part ID: " << part.partID << ", Part Name: " << part.partName 
                 << ", Manufacturer: " << part.manufacturer.name << ", Country: " << part.manufacturer.country << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    Manufacturer m1("Intel", "USA");
    Manufacturer m2("AMD", "USA");

    system.addPart("001", "Processor", m1);
    system.addPart("002", "Graphics Card", m2);

    system.displayParts();

    system.searchPart("001");
    
    system.updatePart("002", "GPU", m1);
    system.displayParts();

    system.deletePart("001");
    system.displayParts();

    return 0;
}