#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    std::string name;
    std::string country;
    Manufacturer(std::string name, std::string country) : name(name), country(country) {}
};

class ComputerPart {
public:
    std::string name;
    std::string type;
    double price;
    Manufacturer manufacturer;
    ComputerPart(std::string name, std::string type, double price, Manufacturer manufacturer)
        : name(name), type(type), price(price), manufacturer(manufacturer) {}
};

class Inventory {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(const ComputerPart& part) {
        parts.push_back(part);
    }

    void deletePart(const std::string& partName) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == partName) {
                parts.erase(it);
                return;
            }
        }
    }

    void updatePart(const std::string& partName, const ComputerPart& updatedPart) {
        for (auto& part : parts) {
            if (part.name == partName) {
                part = updatedPart;
                return;
            }
        }
    }

    void searchPart(const std::string& partName) {
        for (const auto& part : parts) {
            if (part.name == partName) {
                std::cout << "Part Found: " << part.name << ", " << part.type << ", $" << part.price
                          << ", Manufacturer: " << part.manufacturer.name << ", " << part.manufacturer.country << "\n";
                return;
            }
        }
        std::cout << "Part not found\n";
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "Name: " << part.name << ", Type: " << part.type << ", Price: $" << part.price
                      << ", Manufacturer: " << part.manufacturer.name << ", " << part.manufacturer.country << "\n";
        }
    }
};

int main() {
    Inventory inventory;
    Manufacturer m1("Intel", "USA");
    Manufacturer m2("AMD", "USA");
    ComputerPart p1("Core i5", "CPU", 200.00, m1);
    ComputerPart p2("Ryzen 5", "CPU", 180.00, m2);
    
    inventory.addPart(p1);
    inventory.addPart(p2);
    
    std::cout << "Display Parts:\n";
    inventory.displayParts();
    
    std::cout << "\nSearching for 'Core i5':\n";
    inventory.searchPart("Core i5");
    
    std::cout << "\nUpdating 'Ryzen 5':\n";
    ComputerPart updatedP2("Ryzen 5", "CPU", 170.00, m2);
    inventory.updatePart("Ryzen 5", updatedP2);
    inventory.displayParts();
    
    std::cout << "\nDeleting 'Core i5':\n";
    inventory.deletePart("Core i5");
    inventory.displayParts();
    
    return 0;
}