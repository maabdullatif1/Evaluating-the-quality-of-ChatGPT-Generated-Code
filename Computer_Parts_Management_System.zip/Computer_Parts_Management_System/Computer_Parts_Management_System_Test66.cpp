#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Manufacturer {
    string name;
    string contact;
};

struct ComputerPart {
    string name;
    string type;
    double price;
    Manufacturer manufacturer;
};

class ComputerPartsSystem {
public:
    void addPart(const ComputerPart &part) {
        parts.push_back(part);
    }

    void deletePart(const string &partName) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == partName) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(const string &partName, const ComputerPart &newPart) {
        for (auto &part : parts) {
            if (part.name == partName) {
                part = newPart;
                break;
            }
        }
    }

    ComputerPart searchPart(const string &partName) {
        for (const auto &part : parts) {
            if (part.name == partName) {
                return part;
            }
        }
        return {};
    }

    void displayAllParts() {
        for (const auto &part : parts) {
            cout << "Part Name: " << part.name << endl;
            cout << "Part Type: " << part.type << endl;
            cout << "Price: $" << part.price << endl;
            cout << "Manufacturer: " << part.manufacturer.name << endl;
            cout << "Contact: " << part.manufacturer.contact << endl;
            cout << "---------------------" << endl;
        }
    }

private:
    vector<ComputerPart> parts;
};

int main() {
    ComputerPartsSystem system;
    Manufacturer m1 = {"Intel", "contact@intel.com"};
    Manufacturer m2 = {"AMD", "contact@amd.com"};
    ComputerPart p1 = {"Core i9", "CPU", 499.99, m1};
    ComputerPart p2 = {"Ryzen 7", "CPU", 329.99, m2};

    system.addPart(p1);
    system.addPart(p2);

    system.displayAllParts();

    system.deletePart("Core i9");

    system.displayAllParts();

    ComputerPart p3 = {"Ryzen 9", "CPU", 449.99, m2};
    system.updatePart("Ryzen 7", p3);

    system.displayAllParts();

    ComputerPart searchResult = system.searchPart("Ryzen 9");
    cout << "Search Result: " << endl;
    cout << "Part Name: " << searchResult.name << endl;

    return 0;
}