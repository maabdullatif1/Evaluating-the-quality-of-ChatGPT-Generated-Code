#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    int id;
    std::string name;
    std::string manufacturer;

    ComputerPart(int id, std::string name, std::string manufacturer)
        : id(id), name(name), manufacturer(manufacturer) {}
};

class PartsManager {
private:
    std::vector<ComputerPart> parts;
    int nextId;

public:
    PartsManager() : nextId(1) {}

    void addPart(const std::string& name, const std::string& manufacturer) {
        parts.push_back(ComputerPart(nextId++, name, manufacturer));
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->id == id) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(int id, const std::string& newName, const std::string& newManufacturer) {
        for (auto& part : parts) {
            if (part.id == id) {
                part.name = newName;
                part.manufacturer = newManufacturer;
                break;
            }
        }
    }

    ComputerPart* searchPart(int id) {
        for (auto& part : parts) {
            if (part.id == id) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "ID: " << part.id << ", Name: " << part.name
                      << ", Manufacturer: " << part.manufacturer << std::endl;
        }
    }
};

int main() {
    PartsManager manager;
    int choice;
    while (true) {
        std::cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;
        if (choice == 6) break;
        if (choice == 1) {
            std::string name, manufacturer;
            std::cout << "Enter part name: ";
            std::cin >> name;
            std::cout << "Enter manufacturer: ";
            std::cin >> manufacturer;
            manager.addPart(name, manufacturer);
        } else if (choice == 2) {
            int id;
            std::cout << "Enter part ID to delete: ";
            std::cin >> id;
            manager.deletePart(id);
        } else if (choice == 3) {
            int id;
            std::string name, manufacturer;
            std::cout << "Enter part ID to update: ";
            std::cin >> id;
            std::cout << "Enter new part name: ";
            std::cin >> name;
            std::cout << "Enter new manufacturer: ";
            std::cin >> manufacturer;
            manager.updatePart(id, name, manufacturer);
        } else if (choice == 4) {
            int id;
            std::cout << "Enter part ID to search: ";
            std::cin >> id;
            ComputerPart* part = manager.searchPart(id);
            if (part) {
                std::cout << "ID: " << part->id << ", Name: " << part->name
                          << ", Manufacturer: " << part->manufacturer << std::endl;
            } else {
                std::cout << "Part not found.\n";
            }
        } else if (choice == 5) {
            manager.displayParts();
        } else {
            std::cout << "Invalid choice.\n";
        }
    }
    return 0;
}