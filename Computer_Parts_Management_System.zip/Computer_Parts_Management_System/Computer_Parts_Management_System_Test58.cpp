#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct ComputerPart {
    string name;
    string manufacturer;
    double price;
};

class PartsManager {
private:
    vector<ComputerPart> parts;
    
    int findPartIndex(const string& name) {
        for (int i = 0; i < parts.size(); ++i) {
            if (parts[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addPart(const string& name, const string& manufacturer, double price) {
        if (findPartIndex(name) == -1) {
            parts.push_back({name, manufacturer, price});
            cout << "Part added successfully." << endl;
        } else {
            cout << "Part already exists." << endl;
        }
    }

    void deletePart(const string& name) {
        int index = findPartIndex(name);
        if (index != -1) {
            parts.erase(parts.begin() + index);
            cout << "Part deleted successfully." << endl;
        } else {
            cout << "Part not found." << endl;
        }
    }

    void updatePart(const string& name, const string& manufacturer, double price) {
        int index = findPartIndex(name);
        if (index != -1) {
            parts[index].manufacturer = manufacturer;
            parts[index].price = price;
            cout << "Part updated successfully." << endl;
        } else {
            cout << "Part not found." << endl;
        }
    }

    void searchPart(const string& name) {
        int index = findPartIndex(name);
        if (index != -1) {
            cout << "Part found: " << parts[index].name << ", " 
                 << parts[index].manufacturer << ", $" 
                 << parts[index].price << endl;
        } else {
            cout << "Part not found." << endl;
        }
    }

    void displayParts() {
        if (parts.empty()) {
            cout << "No parts available." << endl;
            return;
        }
        
        for (const auto& part : parts) {
            cout << "Name: " << part.name 
                 << ", Manufacturer: " << part.manufacturer 
                 << ", Price: $" << part.price << endl;
        }
    }
};

int main() {
    PartsManager manager;
    int choice;
    string name, manufacturer;
    double price;
    
    do {
        cout << "\n1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter name: ";
                cin >> name;
                cout << "Enter manufacturer: ";
                cin >> manufacturer;
                cout << "Enter price: ";
                cin >> price;
                manager.addPart(name, manufacturer, price);
                break;
            case 2:
                cout << "Enter name to delete: ";
                cin >> name;
                manager.deletePart(name);
                break;
            case 3:
                cout << "Enter name to update: ";
                cin >> name;
                cout << "Enter new manufacturer: ";
                cin >> manufacturer;
                cout << "Enter new price: ";
                cin >> price;
                manager.updatePart(name, manufacturer, price);
                break;
            case 4:
                cout << "Enter name to search: ";
                cin >> name;
                manager.searchPart(name);
                break;
            case 5:
                manager.displayParts();
                break;
            case 6:
                cout << "Exiting." << endl;
                break;
            default:
                cout << "Invalid choice. Try again." << endl;
        }
    } while (choice != 6);

    return 0;
}