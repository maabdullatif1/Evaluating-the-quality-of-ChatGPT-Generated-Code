#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    std::string name;
    std::string address;
    Manufacturer(std::string n, std::string a) : name(n), address(a) {}
};

class ComputerPart {
public:
    std::string name;
    std::string type;
    Manufacturer manufacturer;
    double price;
    ComputerPart(std::string n, std::string t, Manufacturer m, double p)
        : name(n), type(t), manufacturer(m), price(p) {}
};

class PartsManagementSystem {
private:
    std::vector<ComputerPart> parts;
    
    int findPartIndex(const std::string &name) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addPart(const ComputerPart &part) {
        parts.push_back(part);
    }

    void deletePart(const std::string &name) {
        int index = findPartIndex(name);
        if (index != -1) {
            parts.erase(parts.begin() + index);
        }
    }

    void updatePart(const std::string &name, const ComputerPart &newPart) {
        int index = findPartIndex(name);
        if (index != -1) {
            parts[index] = newPart;
        }
    }

    ComputerPart* searchPart(const std::string &name) {
        int index = findPartIndex(name);
        if (index != -1) {
            return &parts[index];
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto &part : parts) {
            std::cout << "Part Name: " << part.name
                      << ", Type: " << part.type
                      << ", Manufacturer: " << part.manufacturer.name
                      << ", Address: " << part.manufacturer.address
                      << ", Price: $" << part.price << '\n';
        }
    }
};

int main() {
    PartsManagementSystem system;
    Manufacturer intel("Intel", "1234 Silicon Ave");
    Manufacturer amd("AMD", "5678 Chip Rd");

    system.addPart(ComputerPart("Core i9", "CPU", intel, 499.99));
    system.addPart(ComputerPart("Ryzen 9", "CPU", amd, 429.99));

    system.displayParts();

    ComputerPart* part = system.searchPart("Core i9");
    if (part) {
        std::cout << "Found part: " << part->name << '\n';
    }

    system.updatePart("Core i9", ComputerPart("Core i9", "CPU", intel, 459.99));
    system.displayParts();
    
    system.deletePart("Ryzen 9");
    system.displayParts();

    return 0;
}