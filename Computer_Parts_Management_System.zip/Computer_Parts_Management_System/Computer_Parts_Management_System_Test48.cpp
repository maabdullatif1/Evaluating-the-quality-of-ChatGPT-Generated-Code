#include <iostream>
#include <vector>
#include <string>

using namespace std;

class ComputerPart {
public:
    string name;
    string manufacturer;
    double price;

    ComputerPart(string n, string m, double p) : name(n), manufacturer(m), price(p) {}

    void update(string n, string m, double p) {
        name = n;
        manufacturer = m;
        price = p;
    }
};

class Inventory {
private:
    vector<ComputerPart> parts;

public:
    void addPart(string name, string manufacturer, double price) {
        parts.push_back(ComputerPart(name, manufacturer, price));
    }

    bool deletePart(string name) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == name) {
                parts.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updatePart(string name, string newName, string newManufacturer, double newPrice) {
        for (auto &part : parts) {
            if (part.name == name) {
                part.update(newName, newManufacturer, newPrice);
                return true;
            }
        }
        return false;
    }

    ComputerPart *searchPart(string name) {
        for (auto &part : parts) {
            if (part.name == name) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto &part : parts) {
            cout << "Name: " << part.name << ", Manufacturer: " << part.manufacturer << ", Price: " << part.price << endl;
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addPart("CPU", "Intel", 300.0);
    inventory.addPart("GPU", "Nvidia", 500.0);

    inventory.displayParts();

    ComputerPart *part = inventory.searchPart("CPU");
    if (part) cout << "Found: " << part->name << endl;

    inventory.updatePart("GPU", "Graphics Card", "Nvidia", 520.0);
    inventory.displayParts();

    inventory.deletePart("CPU");
    inventory.displayParts();

    return 0;
}