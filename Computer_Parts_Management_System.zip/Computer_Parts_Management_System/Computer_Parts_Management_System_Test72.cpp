#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    int id;
    std::string name;
    Manufacturer(int id, const std::string& name) : id(id), name(name) {}
};

class ComputerPart {
public:
    int id;
    std::string name;
    int manufacturerId;
    ComputerPart(int id, const std::string& name, int manufacturerId) 
        : id(id), name(name), manufacturerId(manufacturerId) {}
};

class ManagementSystem {
private:
    std::vector<Manufacturer> manufacturers;
    std::vector<ComputerPart> parts;
    int partCounter = 1;
    int manufacturerCounter = 1;

public:
    void addManufacturer(const std::string& name) {
        manufacturers.push_back(Manufacturer(manufacturerCounter++, name));
    }

    void addPart(const std::string& name, int manufacturerId) {
        parts.push_back(ComputerPart(partCounter++, name, manufacturerId));
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->id == id) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(int id, const std::string& newName, int newManufacturerId) {
        for (auto& part : parts) {
            if (part.id == id) {
                part.name = newName;
                part.manufacturerId = newManufacturerId;
                break;
            }
        }
    }

    Manufacturer* searchManufacturer(int id) {
        for (auto& manufacturer : manufacturers) {
            if (manufacturer.id == id) {
                return &manufacturer;
            }
        }
        return nullptr;
    }

    ComputerPart* searchPart(int id) {
        for (auto& part : parts) {
            if (part.id == id) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto& part : parts) {
            Manufacturer* manufacturer = searchManufacturer(part.manufacturerId);
            std::cout << "Part ID: " << part.id 
                      << ", Name: " << part.name 
                      << ", Manufacturer: " << (manufacturer ? manufacturer->name : "Unknown") 
                      << '\n';
        }
    }

    void displayManufacturers() {
        for (const auto& manufacturer : manufacturers) {
            std::cout << "Manufacturer ID: " << manufacturer.id 
                      << ", Name: " << manufacturer.name 
                      << '\n';
        }
    }
};

int main() {
    ManagementSystem system;
    system.addManufacturer("Intel");
    system.addManufacturer("AMD");
    system.addPart("Processor", 1);
    system.addPart("Graphics Card", 2);
    system.displayParts();
    system.displayManufacturers();
    return 0;
}