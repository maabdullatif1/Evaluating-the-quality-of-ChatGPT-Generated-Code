#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string partName;
    std::string manufacturer;
    double price;

    ComputerPart(const std::string& partName, const std::string& manufacturer, double price)
        : partName(partName), manufacturer(manufacturer), price(price) {}

    void display() const {
        std::cout << "Part Name: " << partName
                  << ", Manufacturer: " << manufacturer
                  << ", Price: $" << price << std::endl;
    }
};

class PartsManagementSystem {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(const std::string& partName, const std::string& manufacturer, double price) {
        parts.push_back(ComputerPart(partName, manufacturer, price));
    }

    void deletePart(const std::string& partName) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partName == partName) {
                parts.erase(it);
                return;
            }
        }
    }

    void updatePart(const std::string& partName, const std::string& newManufacturer, double newPrice) {
        for (auto& part : parts) {
            if (part.partName == partName) {
                part.manufacturer = newManufacturer;
                part.price = newPrice;
                return;
            }
        }
    }

    void searchPart(const std::string& partName) const {
        for (const auto& part : parts) {
            if (part.partName == partName) {
                part.display();
                return;
            }
        }
        std::cout << "Part not found.\n";
    }

    void displayAllParts() const {
        for (const auto& part : parts) {
            part.display();
        }
    }
};

int main() {
    PartsManagementSystem pms;
    int choice;
    std::string partName, manufacturer;
    double price;

    do {
        std::cout << "1. Add part\n2. Delete part\n3. Update part\n4. Search part\n5. Display all parts\n6. Exit\n";
        std::cout << "Enter choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter part name: "; std::cin >> partName;
                std::cout << "Enter manufacturer: "; std::cin >> manufacturer;
                std::cout << "Enter price: "; std::cin >> price;
                pms.addPart(partName, manufacturer, price);
                break;
            case 2:
                std::cout << "Enter part name to delete: "; std::cin >> partName;
                pms.deletePart(partName);
                break;
            case 3:
                std::cout << "Enter part name to update: "; std::cin >> partName;
                std::cout << "Enter new manufacturer: "; std::cin >> manufacturer;
                std::cout << "Enter new price: "; std::cin >> price;
                pms.updatePart(partName, manufacturer, price);
                break;
            case 4:
                std::cout << "Enter part name to search: "; std::cin >> partName;
                pms.searchPart(partName);
                break;
            case 5:
                pms.displayAllParts();
                break;
            case 6:
                break;
            default:
                std::cout << "Invalid choice, please try again.\n";
        }
    } while (choice != 6);

    return 0;
}