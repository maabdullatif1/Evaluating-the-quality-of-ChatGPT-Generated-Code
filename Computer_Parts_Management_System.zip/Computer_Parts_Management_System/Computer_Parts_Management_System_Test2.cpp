#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string partName;
    std::string manufacturer;
    double price;

    ComputerPart(std::string partName, std::string manufacturer, double price)
        : partName(partName), manufacturer(manufacturer), price(price) {}
};

class PartManagementSystem {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(const std::string& partName, const std::string& manufacturer, double price) {
        parts.emplace_back(partName, manufacturer, price);
    }

    void deletePart(const std::string& partName) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].partName == partName) {
                parts.erase(parts.begin() + i);
                break;
            }
        }
    }

    void updatePart(const std::string& partName, const std::string& newManufacturer, double newPrice) {
        for (auto& part : parts) {
            if (part.partName == partName) {
                part.manufacturer = newManufacturer;
                part.price = newPrice;
                break;
            }
        }
    }

    void searchPart(const std::string& partName) {
        for (const auto& part : parts) {
            if (part.partName == partName) {
                std::cout << "Part Found: " << part.partName << ", Manufacturer: " 
                          << part.manufacturer << ", Price: " << part.price << "\n";
                return;
            }
        }
        std::cout << "Part not found.\n";
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "Part: " << part.partName << ", Manufacturer: " 
                      << part.manufacturer << ", Price: " << part.price << "\n";
        }
    }
};

int main() {
    PartManagementSystem pms;
    pms.addPart("CPU", "Intel", 300.00);
    pms.addPart("GPU", "NVIDIA", 500.00);
    pms.displayParts();
    pms.searchPart("CPU");
    pms.updatePart("CPU", "AMD", 350.00);
    pms.searchPart("CPU");
    pms.deletePart("GPU");
    pms.displayParts();
    return 0;
}