#include <iostream>
#include <vector>
#include <string>

struct Manufacturer {
    std::string name;
    std::string country;
};

struct ComputerPart {
    std::string name;
    std::string type;
    float price;
    Manufacturer manufacturer;
};

class PartManagementSystem {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(const ComputerPart& part) {
        parts.push_back(part);
    }
    
    void deletePart(const std::string& partName) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == partName) {
                parts.erase(it);
                return;
            }
        }
    }
    
    void updatePart(const std::string& partName, const ComputerPart& updatedPart) {
        for (auto& part : parts) {
            if (part.name == partName) {
                part = updatedPart;
                return;
            }
        }
    }
    
    ComputerPart* searchPart(const std::string& partName) {
        for (auto& part : parts) {
            if (part.name == partName) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() const {
        std::cout << "Computer Parts:\n";
        for (const auto& part : parts) {
            std::cout << "Name: " << part.name << ", Type: " << part.type
                      << ", Price: $" << part.price << ", Manufacturer: "
                      << part.manufacturer.name << ", Country: " 
                      << part.manufacturer.country << "\n";
        }
    }
};

int main() {
    PartManagementSystem system;

    Manufacturer m1 = {"Intel", "USA"};
    Manufacturer m2 = {"AMD", "USA"};
    Manufacturer m3 = {"Nvidia", "USA"};

    ComputerPart p1 = {"i7-9700K", "CPU", 350.0, m1};
    ComputerPart p2 = {"Ryzen 5 3600", "CPU", 200.0, m2};
    ComputerPart p3 = {"RTX 3080", "GPU", 700.0, m3};

    system.addPart(p1);
    system.addPart(p2);
    system.addPart(p3);

    system.displayParts();

    system.deletePart("Ryzen 5 3600");

    system.displayParts();

    ComputerPart* foundPart = system.searchPart("RTX 3080");
    if (foundPart) {
        std::cout << "Search result: " << foundPart->name << "\n";
    }

    ComputerPart p4 = {"RTX 3080", "GPU", 650.0, m3};
    system.updatePart("RTX 3080", p4);

    system.displayParts();

    return 0;
}