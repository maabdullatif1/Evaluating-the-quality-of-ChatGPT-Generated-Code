#include <iostream>
#include <vector>
#include <string>

class Part {
public:
    std::string partName;
    std::string manufacturer;
    std::string partID;

    Part(std::string id, std::string name, std::string manu) 
        : partID(id), partName(name), manufacturer(manu) {}
};

class PartManager {
private:
    std::vector<Part> parts;
public:
    void addPart(const std::string &id, const std::string &name, const std::string &manu) {
        parts.push_back(Part(id, name, manu));
    }

    void deletePart(const std::string &id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partID == id) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(const std::string &id, const std::string &newName, const std::string &newManu) {
        for (auto &part : parts) {
            if (part.partID == id) {
                part.partName = newName;
                part.manufacturer = newManu;
                break;
            }
        }
    }

    void searchPart(const std::string &id) {
        for (const auto &part : parts) {
            if (part.partID == id) {
                std::cout << "Part ID: " << part.partID << " Name: " << part.partName 
                          << " Manufacturer: " << part.manufacturer << std::endl;
                return;
            }
        }
        std::cout << "Part not found." << std::endl;
    }

    void displayParts() {
        if (parts.empty()) {
            std::cout << "No parts available." << std::endl;
            return;
        }
        for (const auto &part : parts) {
            std::cout << "Part ID: " << part.partID 
                      << " Name: " << part.partName 
                      << " Manufacturer: " << part.manufacturer << std::endl;
        }
    }
};

int main() {
    PartManager manager;
    int choice;
    std::string id, name, manufacturer;
    do {
        std::cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\nEnter choice: ";
        std::cin >> choice;
        switch (choice) {
            case 1:
                std::cout << "Enter Part ID: ";
                std::cin >> id;
                std::cout << "Enter Part Name: ";
                std::cin.ignore();
                std::getline(std::cin, name);
                std::cout << "Enter Manufacturer: ";
                std::getline(std::cin, manufacturer);
                manager.addPart(id, name, manufacturer);
                break;
            case 2:
                std::cout << "Enter Part ID to delete: ";
                std::cin >> id;
                manager.deletePart(id);
                break;
            case 3:
                std::cout << "Enter Part ID to update: ";
                std::cin >> id;
                std::cout << "Enter New Part Name: ";
                std::cin.ignore();
                std::getline(std::cin, name);
                std::cout << "Enter New Manufacturer: ";
                std::getline(std::cin, manufacturer);
                manager.updatePart(id, name, manufacturer);
                break;
            case 4:
                std::cout << "Enter Part ID to search: ";
                std::cin >> id;
                manager.searchPart(id);
                break;
            case 5:
                manager.displayParts();
                break;
            case 6:
                std::cout << "Exiting." << std::endl;
                break;
            default:
                std::cout << "Invalid Choice" << std::endl;
        }
    } while (choice != 6);
    
    return 0;
}