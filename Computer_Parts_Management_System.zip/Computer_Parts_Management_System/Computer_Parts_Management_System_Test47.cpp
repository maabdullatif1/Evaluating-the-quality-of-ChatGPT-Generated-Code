#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string partName;
    std::string manufacturer;
    double price;
    int stock;

    ComputerPart(std::string pName, std::string manu, double pr, int st)
        : partName(pName), manufacturer(manu), price(pr), stock(st) {}
};

class PartsManager {
    std::vector<ComputerPart> parts;

public:
    void addPart(const std::string& pName, const std::string& manu, double pr, int st) {
        parts.push_back(ComputerPart(pName, manu, pr, st));
    }

    void deletePart(const std::string& pName) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partName == pName) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(const std::string& pName, const std::string& newManu, double newPr, int newSt) {
        for (auto& part : parts) {
            if (part.partName == pName) {
                part.manufacturer = newManu;
                part.price = newPr;
                part.stock = newSt;
                break;
            }
        }
    }

    void searchPart(const std::string& pName) {
        for (const auto& part : parts) {
            if (part.partName == pName) {
                std::cout << "Part Name: " << part.partName 
                          << ", Manufacturer: " << part.manufacturer 
                          << ", Price: " << part.price 
                          << ", Stock: " << part.stock << std::endl;
                return;
            }
        }
        std::cout << "Part not found." << std::endl;
    }

    void displayParts() const {
        if (parts.empty()) {
            std::cout << "No parts available." << std::endl;
            return;
        }
        for (const auto& part : parts) {
            std::cout << "Part Name: " << part.partName 
                      << ", Manufacturer: " << part.manufacturer 
                      << ", Price: " << part.price 
                      << ", Stock: " << part.stock << std::endl;
        }
    }
};

int main() {
    PartsManager manager;
    manager.addPart("CPU", "Intel", 300.0, 10);
    manager.addPart("GPU", "NVIDIA", 500.0, 5);

    std::cout << "Displaying all parts:" << std::endl;
    manager.displayParts();
    
    std::cout << "Searching for GPU:" << std::endl;
    manager.searchPart("GPU");
    
    std::cout << "Updating GPU price and stock:" << std::endl;
    manager.updatePart("GPU", "NVIDIA", 450.0, 3);
    manager.searchPart("GPU");
    
    std::cout << "Deleting CPU part:" << std::endl;
    manager.deletePart("CPU");
    
    std::cout << "Displaying all parts again:" << std::endl;
    manager.displayParts();

    return 0;
}