#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    int id;
    std::string name;
    std::string manufacturer;
    float price;

    ComputerPart(int id, std::string name, std::string manufacturer, float price)
        : id(id), name(name), manufacturer(manufacturer), price(price) {}
};

class ManagementSystem {
private:
    std::vector<ComputerPart> parts;
    int nextId;

public:
    ManagementSystem() : nextId(1) {}

    void addPart(std::string name, std::string manufacturer, float price) {
        parts.push_back(ComputerPart(nextId++, name, manufacturer, price));
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->id == id) {
                parts.erase(it);
                return;
            }
        }
    }

    void updatePart(int id, std::string name, std::string manufacturer, float price) {
        for (auto& part : parts) {
            if (part.id == id) {
                part.name = name;
                part.manufacturer = manufacturer;
                part.price = price;
                return;
            }
        }
    }

    void searchPart(int id) {
        for (const auto& part : parts) {
            if (part.id == id) {
                std::cout << "ID: " << part.id << ", Name: " << part.name 
                          << ", Manufacturer: " << part.manufacturer 
                          << ", Price: $" << part.price << std::endl;
                return;
            }
        }
        std::cout << "Part not found." << std::endl;
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "ID: " << part.id << ", Name: " << part.name 
                      << ", Manufacturer: " << part.manufacturer 
                      << ", Price: $" << part.price << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    int choice;
    do {
        std::cout << "\n1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\nEnter choice: ";
        std::cin >> choice;

        if (choice == 1) {
            std::string name, manufacturer;
            float price;
            std::cout << "Enter Name: ";
            std::cin >> name;
            std::cout << "Enter Manufacturer: ";
            std::cin >> manufacturer;
            std::cout << "Enter Price: ";
            std::cin >> price;
            system.addPart(name, manufacturer, price);
        } else if (choice == 2) {
            int id;
            std::cout << "Enter Part ID to Delete: ";
            std::cin >> id;
            system.deletePart(id);
        } else if (choice == 3) {
            int id;
            std::string name, manufacturer;
            float price;
            std::cout << "Enter Part ID to Update: ";
            std::cin >> id;
            std::cout << "Enter New Name: ";
            std::cin >> name;
            std::cout << "Enter New Manufacturer: ";
            std::cin >> manufacturer;
            std::cout << "Enter New Price: ";
            std::cin >> price;
            system.updatePart(id, name, manufacturer, price);
        } else if (choice == 4) {
            int id;
            std::cout << "Enter Part ID to Search: ";
            std::cin >> id;
            system.searchPart(id);
        } else if (choice == 5) {
            system.displayParts();
        }
    } while (choice != 6);

    return 0;
}