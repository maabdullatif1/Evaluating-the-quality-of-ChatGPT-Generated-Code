#include <iostream>
#include <string>
#include <vector>

class ComputerPart {
public:
    int id;
    std::string name;
    std::string manufacturer;
    double price;

    ComputerPart(int id, std::string name, std::string manufacturer, double price)
        : id(id), name(name), manufacturer(manufacturer), price(price) {}
};

class System {
private:
    std::vector<ComputerPart> parts;

    int findIndexById(int id) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].id == id) return i;
        }
        return -1;
    }

public:
    void addPart(int id, std::string name, std::string manufacturer, double price) {
        if (findIndexById(id) == -1) {
            parts.emplace_back(id, name, manufacturer, price);
        }
    }

    void deletePart(int id) {
        int index = findIndexById(id);
        if (index != -1) {
            parts.erase(parts.begin() + index);
        }
    }

    void updatePart(int id, std::string name, std::string manufacturer, double price) {
        int index = findIndexById(id);
        if (index != -1) {
            parts[index].name = name;
            parts[index].manufacturer = manufacturer;
            parts[index].price = price;
        }
    }

    void searchPart(int id) {
        int index = findIndexById(id);
        if (index != -1) {
            std::cout << "ID: " << parts[index].id << "\n"
                      << "Name: " << parts[index].name << "\n"
                      << "Manufacturer: " << parts[index].manufacturer << "\n"
                      << "Price: " << parts[index].price << "\n";
        } else {
            std::cout << "Part not found\n";
        }
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "ID: " << part.id << "\n"
                      << "Name: " << part.name << "\n"
                      << "Manufacturer: " << part.manufacturer << "\n"
                      << "Price: " << part.price << "\n";
        }
    }
};

int main() {
    System system;
    
    system.addPart(1, "CPU", "Intel", 299.99);
    system.addPart(2, "GPU", "NVIDIA", 499.99);
    
    system.displayParts();
    
    system.updatePart(1, "CPU", "AMD", 199.99);
    
    system.displayParts();
    
    system.searchPart(2);
    
    system.deletePart(2);
    
    system.displayParts();
    
    return 0;
}