#include <iostream>
#include <string>
#include <vector>

class Manufacturer {
public:
    std::string name;
    std::string address;

    Manufacturer(const std::string& name, const std::string& address)
        : name(name), address(address) {}
};

class ComputerPart {
public:
    std::string name;
    std::string type;
    double price;
    Manufacturer manufacturer;

    ComputerPart(const std::string& name, const std::string& type, double price, const Manufacturer& manufacturer)
        : name(name), type(type), price(price), manufacturer(manufacturer) {}
};

class InventorySystem {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(const ComputerPart& part) {
        parts.push_back(part);
    }

    void deletePart(const std::string& partName) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == partName) {
                parts.erase(it);
                return;
            }
        }
    }

    void updatePart(const std::string& partName, const ComputerPart& updatedPart) {
        for (auto& part : parts) {
            if (part.name == partName) {
                part = updatedPart;
                return;
            }
        }
    }

    ComputerPart* searchPart(const std::string& partName) {
        for (auto& part : parts) {
            if (part.name == partName) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "Part Name: " << part.name << std::endl;
            std::cout << "Type: " << part.type << std::endl;
            std::cout << "Price: " << part.price << std::endl;
            std::cout << "Manufacturer: " << part.manufacturer.name << std::endl;
            std::cout << "Address: " << part.manufacturer.address << std::endl;
            std::cout << "-----------------------------" << std::endl;
        }
    }
};

int main() {
    InventorySystem inventory;

    Manufacturer m1("Intel", "123 Tech Lane");
    Manufacturer m2("AMD", "456 Innovation Rd");

    inventory.addPart(ComputerPart("i7 Processor", "CPU", 320.00, m1));
    inventory.addPart(ComputerPart("Ryzen 5", "CPU", 200.00, m2));

    inventory.displayParts();

    inventory.updatePart("i7 Processor", ComputerPart("i7 Processor", "CPU", 299.99, m1));

    ComputerPart* foundPart = inventory.searchPart("Ryzen 5");
    if (foundPart) {
        std::cout << "Found: " << foundPart->name << " costing " << foundPart->price << std::endl;
    }
    
    inventory.deletePart("Ryzen 5");

    inventory.displayParts();

    return 0;
}