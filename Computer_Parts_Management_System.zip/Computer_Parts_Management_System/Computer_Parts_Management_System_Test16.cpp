#include <iostream>
#include <vector>
#include <string>

struct Manufacturer {
    int id;
    std::string name;
};

struct ComputerPart {
    int id;
    std::string name;
    std::string type;
    int manufacturerId;
};

class PartsManagementSystem {
    std::vector<ComputerPart> parts;
    std::vector<Manufacturer> manufacturers;

public:
    void addManufacturer(int id, const std::string &name) {
        manufacturers.push_back({id, name});
    }

    void addPart(int id, const std::string &name, const std::string &type, int manufacturerId) {
        parts.push_back({id, name, type, manufacturerId});
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->id == id) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(int id, const std::string &name, const std::string &type, int manufacturerId) {
        for (auto &part : parts) {
            if (part.id == id) {
                part.name = name;
                part.type = type;
                part.manufacturerId = manufacturerId;
                break;
            }
        }
    }

    void searchPartByName(const std::string &name) {
        for (const auto &part : parts) {
            if (part.name == name) {
                displayPart(part);
            }
        }
    }

    void displayParts() {
        for (const auto &part : parts) {
            displayPart(part);
        }
    }

    void displayManufacturers() {
        for (const auto &manufacturer : manufacturers) {
            std::cout << "Manufacturer ID: " << manufacturer.id << ", Name: " << manufacturer.name << std::endl;
        }
    }

private:
    void displayPart(const ComputerPart &part) {
        std::cout << "Part ID: " << part.id 
                  << ", Name: " << part.name 
                  << ", Type: " << part.type 
                  << ", Manufacturer ID: " << part.manufacturerId 
                  << std::endl;
    }
};

int main() {
    PartsManagementSystem system;
    system.addManufacturer(1, "Intel");
    system.addManufacturer(2, "AMD");

    system.addPart(1, "Core i7", "CPU", 1);
    system.addPart(2, "Ryzen 5", "CPU", 2);

    std::cout << "All Parts:" << std::endl;
    system.displayParts();

    std::cout << "\nAll Manufacturers:" << std::endl;
    system.displayManufacturers();

    std::cout << "\nSearching for 'Ryzen 5':" << std::endl;
    system.searchPartByName("Ryzen 5");

    std::cout << "\nUpdating 'Ryzen 5' to 'Ryzen 7':" << std::endl;
    system.updatePart(2, "Ryzen 7", "CPU", 2);
    system.searchPartByName("Ryzen 7");

    std::cout << "\nDeleting 'Core i7':" << std::endl;
    system.deletePart(1);
    system.displayParts();

    return 0;
}