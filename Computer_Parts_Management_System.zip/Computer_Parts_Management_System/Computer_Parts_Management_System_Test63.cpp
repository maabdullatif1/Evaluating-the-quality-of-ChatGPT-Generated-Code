#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Manufacturer {
    string name;
    string country;
};

struct ComputerPart {
    string name;
    string type;
    Manufacturer manufacturer;
    double price;
};

class PartsManagementSystem {
private:
    vector<ComputerPart> parts;

public:
    void addPart(const ComputerPart& part) {
        parts.push_back(part);
    }

    void deletePart(const string& partName) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == partName) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(const string& partName, const ComputerPart& updatedPart) {
        for (auto& part : parts) {
            if (part.name == partName) {
                part = updatedPart;
                break;
            }
        }
    }

    void searchPart(const string& partName) {
        for (const auto& part : parts) {
            if (part.name == partName) {
                cout << "Name: " << part.name << "\nType: " << part.type
                     << "\nManufacturer: " << part.manufacturer.name
                     << "\nCountry: " << part.manufacturer.country
                     << "\nPrice: " << part.price << "\n";
                return;
            }
        }
        cout << "Part not found." << endl;
    }

    void displayParts() {
        if (parts.empty()) {
            cout << "No parts available." << endl;
            return;
        }
        for (const auto& part : parts) {
            cout << "Name: " << part.name << "\nType: " << part.type
                 << "\nManufacturer: " << part.manufacturer.name
                 << "\nCountry: " << part.manufacturer.country
                 << "\nPrice: " << part.price << "\n\n";
        }
    }
};

int main() {
    PartsManagementSystem pms;
    int choice;
    while (true) {
        cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n0. Exit\n";
        cin >> choice;
        if (choice == 0)
            break;

        ComputerPart part;
        string partName;

        switch (choice) {
            case 1:
                cout << "Enter part name: ";
                cin >> part.name;
                cout << "Enter part type: ";
                cin >> part.type;
                cout << "Enter manufacturer name: ";
                cin >> part.manufacturer.name;
                cout << "Enter manufacturer country: ";
                cin >> part.manufacturer.country;
                cout << "Enter part price: ";
                cin >> part.price;
                pms.addPart(part);
                break;
            case 2:
                cout << "Enter part name to delete: ";
                cin >> partName;
                pms.deletePart(partName);
                break;
            case 3:
                cout << "Enter part name to update: ";
                cin >> partName;
                cout << "Enter new part name: ";
                cin >> part.name;
                cout << "Enter new part type: ";
                cin >> part.type;
                cout << "Enter new manufacturer name: ";
                cin >> part.manufacturer.name;
                cout << "Enter new manufacturer country: ";
                cin >> part.manufacturer.country;
                cout << "Enter new part price: ";
                cin >> part.price;
                pms.updatePart(partName, part);
                break;
            case 4:
                cout << "Enter part name to search: ";
                cin >> partName;
                pms.searchPart(partName);
                break;
            case 5:
                pms.displayParts();
                break;
            default:
                cout << "Invalid choice." << endl;
        }
    }
    return 0;
}