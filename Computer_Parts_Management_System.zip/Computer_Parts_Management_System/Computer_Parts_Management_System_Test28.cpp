#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Manufacturer {
    string name;
    string address;
};

struct ComputerPart {
    string name;
    string type;
    float price;
    Manufacturer manufacturer;
};

class PartsManagementSystem {
private:
    vector<ComputerPart> parts;

public:
    void addPart(const ComputerPart& part) {
        parts.push_back(part);
    }

    void deletePart(const string& partName) {
        for(auto it = parts.begin(); it != parts.end(); ++it) {
            if(it->name == partName) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(const string& partName, const ComputerPart& updatedPart) {
        for(auto& part : parts) {
            if(part.name == partName) {
                part = updatedPart;
                break;
            }
        }
    }

    ComputerPart searchPart(const string& partName) {
        for(auto& part : parts) {
            if(part.name == partName) {
                return part;
            }
        }
        return {"", "", 0.0, {"", ""}};
    }

    void displayParts() {
        for(const auto& part : parts) {
            cout << "Part Name: " << part.name << endl;
            cout << "Type: " << part.type << endl;
            cout << "Price: $" << part.price << endl;
            cout << "Manufacturer: " << part.manufacturer.name << endl;
            cout << "Address: " << part.manufacturer.address << endl << endl;
        }
    }
};

int main() {
    PartsManagementSystem system;
    Manufacturer m1 = {"Intel", "123 Processor St."};
    Manufacturer m2 = {"NVIDIA", "456 Graphics Ave."};

    ComputerPart cpu = {"i7-9700K", "CPU", 350.00, m1};
    ComputerPart gpu = {"RTX 3080", "GPU", 699.99, m2};

    system.addPart(cpu);
    system.addPart(gpu);

    system.displayParts();

    ComputerPart newCPU = {"i7-11700K", "CPU", 400.00, m1};
    system.updatePart("i7-9700K", newCPU);

    system.displayParts();

    system.deletePart("RTX 3080");

    system.displayParts();

    ComputerPart foundPart = system.searchPart("i7-11700K");
    cout << "Found Part: " << foundPart.name << ", Price: $" << foundPart.price << endl;

    return 0;
}