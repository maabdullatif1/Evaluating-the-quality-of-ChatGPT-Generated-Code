#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    std::string name;
    std::string country;
    
    Manufacturer(const std::string& n, const std::string& c) : name(n), country(c) {}
};

class ComputerPart {
public:
    std::string partName;
    std::string partNumber;
    Manufacturer manufacturer;
    
    ComputerPart(const std::string& pn, const std::string& pnum, const Manufacturer& m)
        : partName(pn), partNumber(pnum), manufacturer(m) {}
};

class PartsManager {
    std::vector<ComputerPart> parts;

public:
    void addPart(const ComputerPart& part) {
        parts.push_back(part);
    }

    void deletePart(const std::string& partNumber) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partNumber == partNumber) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(const std::string& partNumber, const ComputerPart& newPart) {
        for (auto& part : parts) {
            if (part.partNumber == partNumber) {
                part = newPart;
                break;
            }
        }
    }

    ComputerPart* searchPart(const std::string& partNumber) {
        for (auto& part : parts) {
            if (part.partNumber == partNumber) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() const {
        for (const auto& part : parts) {
            std::cout << "Part Name: " << part.partName 
                      << ", Part Number: " << part.partNumber
                      << ", Manufacturer: " << part.manufacturer.name
                      << ", Country: " << part.manufacturer.country << std::endl;
        }
    }
};

int main() {
    PartsManager manager;
    Manufacturer manu1("Intel", "USA");
    Manufacturer manu2("AMD", "USA");

    manager.addPart(ComputerPart("CPU", "1234", manu1));
    manager.addPart(ComputerPart("GPU", "5678", manu2));
    
    manager.displayParts();
    
    ComputerPart* foundPart = manager.searchPart("1234");
    if (foundPart) {
        std::cout << "Found: " << foundPart->partName << std::endl;
    }

    manager.updatePart("1234", ComputerPart("Processor", "1234", manu1));
    
    manager.displayParts();

    manager.deletePart("5678");
    
    manager.displayParts();

    return 0;
}