#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Manufacturer {
    string name;
    string country;
};

struct ComputerPart {
    string partName;
    int partID;
    Manufacturer manufacturer;
};

class PartsManagementSystem {
    vector<ComputerPart> parts;
    int currentID = 1;

public:
    void addPart(const string& partName, const string& manufacturerName, const string& manufacturerCountry) {
        ComputerPart newPart;
        newPart.partName = partName;
        newPart.partID = currentID++;
        newPart.manufacturer = {manufacturerName, manufacturerCountry};
        parts.push_back(newPart);
    }

    void deletePart(int partID) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partID == partID) {
                parts.erase(it);
                cout << "Part deleted successfully." << endl;
                return;
            }
        }
        cout << "Part not found." << endl;
    }

    void updatePart(int partID, const string& newPartName, const string& newManufacturerName, const string& newManufacturerCountry) {
        for (auto& part : parts) {
            if (part.partID == partID) {
                part.partName = newPartName;
                part.manufacturer = {newManufacturerName, newManufacturerCountry};
                cout << "Part updated successfully." << endl;
                return;
            }
        }
        cout << "Part not found." << endl;
    }

    void searchPart(int partID) {
        for (const auto& part : parts) {
            if (part.partID == partID) {
                cout << "Part ID: " << part.partID << "\nPart Name: " << part.partName
                     << "\nManufacturer: " << part.manufacturer.name
                     << "\nCountry: " << part.manufacturer.country << endl;
                return;
            }
        }
        cout << "Part not found." << endl;
    }

    void displayAllParts() {
        for (const auto& part : parts) {
            cout << "Part ID: " << part.partID << "\nPart Name: " << part.partName
                 << "\nManufacturer: " << part.manufacturer.name
                 << "\nCountry: " << part.manufacturer.country << endl;
        }
    }
};

int main() {
    PartsManagementSystem system;
    system.addPart("CPU", "Intel", "USA");
    system.addPart("GPU", "NVIDIA", "USA");
    system.displayAllParts();
    system.searchPart(1);
    system.updatePart(2, "Graphics Card", "AMD", "USA");
    system.displayAllParts();
    system.deletePart(1);
    system.displayAllParts();
    return 0;
}