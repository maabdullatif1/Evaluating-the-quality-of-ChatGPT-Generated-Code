#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string name;
    std::string manufacturer;
    float price;

    ComputerPart(std::string n, std::string m, float p) : name(n), manufacturer(m), price(p) {}
};

class PartManager {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(const std::string& name, const std::string& manufacturer, float price) {
        parts.push_back(ComputerPart(name, manufacturer, price));
    }

    bool deletePart(const std::string& name) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == name) {
                parts.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updatePart(const std::string& name, const std::string& newName, const std::string& newManufacturer, float newPrice) {
        for (auto& part : parts) {
            if (part.name == name) {
                part.name = newName;
                part.manufacturer = newManufacturer;
                part.price = newPrice;
                return true;
            }
        }
        return false;
    }

    void searchPart(const std::string& name) const {
        for (const auto& part : parts) {
            if (part.name == name) {
                std::cout << "Part found: " << part.name << ", Manufacturer: " << part.manufacturer << ", Price: " << part.price << std::endl;
                return;
            }
        }
        std::cout << "Part not found" << std::endl;
    }

    void displayParts() const {
        if (parts.empty()) {
            std::cout << "No parts in inventory" << std::endl;
            return;
        }
        for (const auto& part : parts) {
            std::cout << "Name: " << part.name << ", Manufacturer: " << part.manufacturer << ", Price: " << part.price << std::endl;
        }
    }
};

int main() {
    PartManager partManager;
    int choice;
    std::string name, manufacturer, newName, newManufacturer;
    float price;

    while (true) {
        std::cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter part name, manufacturer and price: ";
                std::cin >> name >> manufacturer >> price;
                partManager.addPart(name, manufacturer, price);
                break;
            case 2:
                std::cout << "Enter part name to delete: ";
                std::cin >> name;
                if (!partManager.deletePart(name)) {
                    std::cout << "Part not found" << std::endl;
                }
                break;
            case 3:
                std::cout << "Enter part name to update: ";
                std::cin >> name;
                std::cout << "Enter new name, manufacturer and price: ";
                std::cin >> newName >> newManufacturer >> price;
                if (!partManager.updatePart(name, newName, newManufacturer, price)) {
                    std::cout << "Part not found" << std::endl;
                }
                break;
            case 4:
                std::cout << "Enter part name to search: ";
                std::cin >> name;
                partManager.searchPart(name);
                break;
            case 5:
                partManager.displayParts();
                break;
            case 6:
                return 0;
        }
    }
}