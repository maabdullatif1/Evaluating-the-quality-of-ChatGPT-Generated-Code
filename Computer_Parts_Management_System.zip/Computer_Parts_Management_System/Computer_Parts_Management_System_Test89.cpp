#include <iostream>
#include <vector>
#include <string>

struct Manufacturer {
    std::string name;
    std::string country;
};

struct Part {
    std::string name;
    std::string type;
    Manufacturer manufacturer;
    double price;
};

class ComputerPartsManagementSystem {
private:
    std::vector<Part> parts;

public:
    void addPart(const std::string& name, const std::string& type, const std::string& manuName, const std::string& manuCountry, double price) {
        parts.push_back({name, type, {manuName, manuCountry}, price});
    }

    void deletePart(const std::string& name) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == name) {
                parts.erase(it);
                return;
            }
        }
    }

    void updatePart(const std::string& name, const std::string& newName, const std::string& newType, const std::string& manuName, const std::string& manuCountry, double newPrice) {
        for (auto& part : parts) {
            if (part.name == name) {
                part.name = newName;
                part.type = newType;
                part.manufacturer.name = manuName;
                part.manufacturer.country = manuCountry;
                part.price = newPrice;
                return;
            }
        }
    }

    Part* searchPart(const std::string& name) {
        for (auto& part : parts) {
            if (part.name == name) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "Part Name: " << part.name << ", Type: " << part.type
                      << ", Manufacturer: " << part.manufacturer.name << ", Country: " 
                      << part.manufacturer.country << ", Price: $" << part.price << std::endl;
        }
    }
};

int main() {
    ComputerPartsManagementSystem system;
    system.addPart("RTX 3080", "GPU", "NVIDIA", "USA", 699.99);
    system.addPart("Ryzen 5900X", "CPU", "AMD", "USA", 549.99);
    system.displayParts();
    Part* foundPart = system.searchPart("RTX 3080");
    if (foundPart) {
        std::cout << "Found: " << foundPart->name << std::endl;
    }
    system.updatePart("RTX 3080", "RTX 3090", "GPU", "NVIDIA", "USA", 1499.99);
    system.displayParts();
    system.deletePart("Ryzen 5900X");
    system.displayParts();
    return 0;
}