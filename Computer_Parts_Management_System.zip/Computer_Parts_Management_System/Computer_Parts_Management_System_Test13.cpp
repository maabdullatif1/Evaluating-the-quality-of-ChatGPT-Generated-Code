#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Manufacturer {
public:
    int id;
    string name;

    Manufacturer(int id, string name) : id(id), name(name) {}
};

class ComputerPart {
public:
    int id;
    string name;
    int manufacturerId;

    ComputerPart(int id, string name, int manufacturerId) : id(id), name(name), manufacturerId(manufacturerId) {}
};

class ManagementSystem {
    vector<Manufacturer> manufacturers;
    vector<ComputerPart> parts;

public:
    void addManufacturer(int id, string name) {
        manufacturers.push_back(Manufacturer(id, name));
    }

    void addPart(int id, string name, int manufacturerId) {
        parts.push_back(ComputerPart(id, name, manufacturerId));
    }

    void deleteManufacturer(int id) {
        for (auto it = manufacturers.begin(); it != manufacturers.end(); ++it) {
            if (it->id == id) {
                manufacturers.erase(it);
                break;
            }
        }
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->id == id) {
                parts.erase(it);
                break;
            }
        }
    }

    void updateManufacturer(int id, string newName) {
        for (auto& m : manufacturers) {
            if (m.id == id) {
                m.name = newName;
                break;
            }
        }
    }

    void updatePart(int id, string newName, int newManufacturerId) {
        for (auto& p : parts) {
            if (p.id == id) {
                p.name = newName;
                p.manufacturerId = newManufacturerId;
                break;
            }
        }
    }

    void searchManufacturer(int id) {
        for (auto& m : manufacturers) {
            if (m.id == id) {
                cout << "Manufacturer ID: " << m.id << ", Name: " << m.name << endl;
                return;
            }
        }
        cout << "Manufacturer not found." << endl;
    }

    void searchPart(int id) {
        for (auto& p : parts) {
            if (p.id == id) {
                cout << "Part ID: " << p.id << ", Name: " << p.name << ", Manufacturer ID: " << p.manufacturerId << endl;
                return;
            }
        }
        cout << "Part not found." << endl;
    }

    void displayManufacturers() {
        for (auto& m : manufacturers) {
            cout << "Manufacturer ID: " << m.id << ", Name: " << m.name << endl;
        }
    }

    void displayParts() {
        for (auto& p : parts) {
            cout << "Part ID: " << p.id << ", Name: " << p.name << ", Manufacturer ID: " << p.manufacturerId << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addManufacturer(1, "Intel");
    system.addManufacturer(2, "AMD");
    system.addPart(101, "CPU", 1);
    system.addPart(102, "GPU", 2);
    system.displayManufacturers();
    system.displayParts();
    system.searchManufacturer(1);
    system.searchPart(102);
    system.updateManufacturer(2, "Advanced Micro Devices");
    system.updatePart(101, "Ryzen CPU", 2);
    system.displayManufacturers();
    system.displayParts();
    system.deleteManufacturer(1);
    system.deletePart(101);
    system.displayManufacturers();
    system.displayParts();
    return 0;
}