#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    int id;
    std::string name;
    std::string manufacturer;
    double price;

    ComputerPart(int i, const std::string& n, const std::string& m, double p)
        : id(i), name(n), manufacturer(m), price(p) {}
};

class PartManagementSystem {
private:
    std::vector<ComputerPart> parts;
    int nextId = 1;

    int findIndexById(int id) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addPart(const std::string& name, const std::string& manufacturer, double price) {
        parts.push_back(ComputerPart(nextId++, name, manufacturer, price));
    }

    void deletePart(int id) {
        int index = findIndexById(id);
        if (index != -1) {
            parts.erase(parts.begin() + index);
        }
    }

    void updatePart(int id, const std::string& name, const std::string& manufacturer, double price) {
        int index = findIndexById(id);
        if (index != -1) {
            parts[index] = ComputerPart(id, name, manufacturer, price);
        }
    }

    void searchPart(const std::string& keyword) {
        for (const auto& part : parts) {
            if (part.name.find(keyword) != std::string::npos || part.manufacturer.find(keyword) != std::string::npos) {
                std::cout << "ID: " << part.id << ", Name: " << part.name
                          << ", Manufacturer: " << part.manufacturer << ", Price: $" << part.price << "\n";
            }
        }
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "ID: " << part.id << ", Name: " << part.name 
                      << ", Manufacturer: " << part.manufacturer << ", Price: $" << part.price << "\n";
        }
    }
};

int main() {
    PartManagementSystem pms;
    pms.addPart("CPU", "Intel", 299.99);
    pms.addPart("GPU", "NVIDIA", 499.99);
    pms.displayParts();
    pms.updatePart(1, "CPU", "AMD", 289.99);
    pms.displayParts();
    pms.searchPart("NVIDIA");
    pms.deletePart(2);
    pms.displayParts();
    return 0;
}