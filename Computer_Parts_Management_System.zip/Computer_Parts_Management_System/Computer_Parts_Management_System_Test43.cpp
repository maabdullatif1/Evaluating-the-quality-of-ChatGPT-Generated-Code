#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    std::string name;
    std::string country;

    Manufacturer(const std::string &name, const std::string &country)
        : name(name), country(country) {}
};

class ComputerPart {
public:
    std::string name;
    std::string type;
    double price;
    Manufacturer manufacturer;

    ComputerPart(const std::string &name, const std::string &type, double price, const Manufacturer &manufacturer)
        : name(name), type(type), price(price), manufacturer(manufacturer) {}
};

class ManagementSystem {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(const ComputerPart &part) {
        parts.push_back(part);
    }

    bool deletePart(const std::string &partName) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == partName) {
                parts.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updatePart(const std::string &partName, const ComputerPart &newPart) {
        for (auto &part : parts) {
            if (part.name == partName) {
                part = newPart;
                return true;
            }
        }
        return false;
    }

    ComputerPart* searchPart(const std::string &partName) {
        for (auto &part : parts) {
            if (part.name == partName) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() const {
        if (parts.empty()) {
            std::cout << "No parts available." << std::endl;
            return;
        }
        for (const auto &part : parts) {
            std::cout << "Part Name: " << part.name << "\nType: " << part.type 
                      << "\nPrice: " << part.price << "\nManufacturer: " << part.manufacturer.name 
                      << " (" << part.manufacturer.country << ")\n" << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    Manufacturer intel("Intel", "USA");
    Manufacturer amd("AMD", "USA");

    ComputerPart cpu("Core i9", "Processor", 500.0, intel);
    ComputerPart gpu("Radeon RX 6800", "Graphics Card", 579.0, amd);

    system.addPart(cpu);
    system.addPart(gpu);

    system.displayParts();

    system.updatePart("Core i9", ComputerPart("Core i7", "Processor", 350.0, intel));
    system.displayParts();

    system.deletePart("Radeon RX 6800");
    system.displayParts();

    ComputerPart *found = system.searchPart("Core i7");
    if (found) {
        std::cout << "Found: " << found->name << std::endl;
    } else {
        std::cout << "Not Found" << std::endl;
    }

    return 0;
}