#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string name;
    std::string manufacturer;

    ComputerPart(std::string n, std::string m) : name(n), manufacturer(m) {}
};

class PartsManager {
private:
    std::vector<ComputerPart> parts;

    int findPartIndex(const std::string& name) {
        for (size_t i = 0; i < parts.size(); i++) {
            if (parts[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addPart(const std::string& name, const std::string& manufacturer) {
        parts.push_back(ComputerPart(name, manufacturer));
    }

    void deletePart(const std::string& name) {
        int index = findPartIndex(name);
        if (index != -1) {
            parts.erase(parts.begin() + index);
        }
    }

    void updatePart(const std::string& name, const std::string& newManufacturer) {
        int index = findPartIndex(name);
        if (index != -1) {
            parts[index].manufacturer = newManufacturer;
        }
    }

    void searchPart(const std::string& name) {
        int index = findPartIndex(name);
        if (index != -1) {
            std::cout << "Part found: " << parts[index].name 
                      << " by " << parts[index].manufacturer << std::endl;
        } else {
            std::cout << "Part not found" << std::endl;
        }
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << part.name << " by " << part.manufacturer << std::endl;
        }
    }
};

int main() {
    PartsManager manager;
    int choice;
    std::string name, manufacturer;
    
    do {
        std::cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\nChoose an option: ";
        std::cin >> choice;
        
        switch (choice) {
            case 1:
                std::cout << "Enter part name: ";
                std::cin >> name;
                std::cout << "Enter manufacturer: ";
                std::cin >> manufacturer;
                manager.addPart(name, manufacturer);
                break;
            case 2:
                std::cout << "Enter part name to delete: ";
                std::cin >> name;
                manager.deletePart(name);
                break;
            case 3:
                std::cout << "Enter part name to update: ";
                std::cin >> name;
                std::cout << "Enter new manufacturer: ";
                std::cin >> manufacturer;
                manager.updatePart(name, manufacturer);
                break;
            case 4:
                std::cout << "Enter part name to search: ";
                std::cin >> name;
                manager.searchPart(name);
                break;
            case 5:
                manager.displayParts();
                break;
        }
    } while (choice != 6);

    return 0;
}