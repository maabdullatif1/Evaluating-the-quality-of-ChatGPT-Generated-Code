#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    int id;
    std::string name;

    Manufacturer(int id, std::string name) : id(id), name(name) {}
};

class ComputerPart {
public:
    int id;
    std::string name;
    Manufacturer* manufacturer;

    ComputerPart(int id, std::string name, Manufacturer* manufacturer)
        : id(id), name(name), manufacturer(manufacturer) {}
};

class ManagementSystem {
private:
    std::vector<ComputerPart> parts;
    std::vector<Manufacturer> manufacturers;

public:
    void addManufacturer(int id, std::string name) {
        manufacturers.push_back(Manufacturer(id, name));
    }
    
    Manufacturer* findManufacturer(int id) {
        for (auto& manufacturer : manufacturers) {
            if (manufacturer.id == id) {
                return &manufacturer;
            }
        }
        return nullptr;
    }

    void addPart(int id, std::string name, Manufacturer* manufacturer) {
        parts.push_back(ComputerPart(id, name, manufacturer));
    }
    
    void deletePart(int id) {
        parts.erase(std::remove_if(parts.begin(), parts.end(),
            [id](ComputerPart& part) { return part.id == id; }), parts.end());
    }

    void updatePart(int id, std::string newName, Manufacturer* newManufacturer) {
        for (auto& part : parts) {
            if (part.id == id) {
                part.name = newName;
                part.manufacturer = newManufacturer;
                return;
            }
        }
    }

    ComputerPart* searchPart(int id) {
        for (auto& part : parts) {
            if (part.id == id) {
                return &part;
            }
        }
        return nullptr;
    }

    Manufacturer* searchManufacturer(int id) {
        for (auto& manufacturer : manufacturers) {
            if (manufacturer.id == id) {
                return &manufacturer;
            }
        }
        return nullptr;
    }

    void displayParts() {
        for (auto& part : parts) {
            std::cout << "Part ID: " << part.id << ", Name: " << part.name
                      << ", Manufacturer: " << part.manufacturer->name << std::endl;
        }
    }

    void displayManufacturers() {
        for (auto& manufacturer : manufacturers) {
            std::cout << "Manufacturer ID: " << manufacturer.id << ", Name: " << manufacturer.name << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addManufacturer(1, "Intel");
    system.addManufacturer(2, "AMD");

    Manufacturer* intel = system.findManufacturer(1);
    Manufacturer* amd = system.findManufacturer(2);

    system.addPart(1, "CPU", intel);
    system.addPart(2, "GPU", amd);

    system.displayParts();
    system.displayManufacturers();

    system.updatePart(1, "Intel CPU", intel);
    system.displayParts();

    system.deletePart(2);
    system.displayParts();

    return 0;
}