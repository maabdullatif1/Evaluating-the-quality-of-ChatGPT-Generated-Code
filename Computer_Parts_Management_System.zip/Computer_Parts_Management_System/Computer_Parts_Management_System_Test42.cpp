#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

class Manufacturer {
public:
    std::string name;
    std::string location;

    Manufacturer(const std::string &n, const std::string &l) : name(n), location(l) {}
};

class ComputerPart {
public:
    std::string name;
    std::string type;
    int quantity;
    Manufacturer manufacturer;

    ComputerPart(const std::string &n, const std::string &t, int q, const Manufacturer &m)
        : name(n), type(t), quantity(q), manufacturer(m) {}
};

class PartsManagementSystem {
    std::vector<ComputerPart> parts;

public:
    void addPart(const ComputerPart &part) {
        parts.push_back(part);
    }

    void deletePart(const std::string &name) {
        parts.erase(std::remove_if(parts.begin(), parts.end(), [&](const ComputerPart &part) {
            return part.name == name;
        }), parts.end());
    }

    void updatePart(const std::string &name, const std::string &newType, int newQuantity) {
        for (auto &part : parts) {
            if (part.name == name) {
                part.type = newType;
                part.quantity = newQuantity;
            }
        }
    }

    ComputerPart* searchPart(const std::string &name) {
        for (auto &part : parts) {
            if (part.name == name) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() const {
        for (const auto &part : parts) {
            std::cout << "Part Name: " << part.name
                      << ", Type: " << part.type
                      << ", Quantity: " << part.quantity
                      << ", Manufacturer: " << part.manufacturer.name
                      << ", Location: " << part.manufacturer.location << std::endl;
        }
    }
};

int main() {
    PartsManagementSystem system;
    Manufacturer m1("Manufacturer A", "Location A");
    Manufacturer m2("Manufacturer B", "Location B");

    system.addPart(ComputerPart("CPU", "Processor", 50, m1));
    system.addPart(ComputerPart("GPU", "Graphics Card", 20, m2));

    std::cout << "All parts:" << std::endl;
    system.displayParts();

    system.updatePart("CPU", "High-End Processor", 40);
    std::cout << "\nAfter updating CPU:" << std::endl;
    system.displayParts();

    system.deletePart("GPU");
    std::cout << "\nAfter deleting GPU:" << std::endl;
    system.displayParts();

    ComputerPart* part = system.searchPart("CPU");
    if (part) {
        std::cout << "\nSearched Part: " << part->name << ", Quantity: " << part->quantity << std::endl;
    }

    return 0;
}