#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Manufacturer {
public:
    string name;
    string country;
    Manufacturer(string n, string c) : name(n), country(c) {}
};

class ComputerPart {
public:
    string name;
    string type;
    double price;
    Manufacturer manufacturer;
    ComputerPart(string n, string t, double p, Manufacturer m) 
        : name(n), type(t), price(p), manufacturer(m) {}
};

class Inventory {
private:
    vector<ComputerPart> parts;
public:
    void addPart(const string& name, const string& type, double price, const Manufacturer& manufacturer) {
        parts.push_back(ComputerPart(name, type, price, manufacturer));
    }

    void deletePart(const string& name) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == name) {
                parts.erase(it);
                return;
            }
        }
    }

    void updatePart(const string& name, const string& newType, double newPrice) {
        for (auto& part : parts) {
            if (part.name == name) {
                part.type = newType;
                part.price = newPrice;
                return;
            }
        }
    }

    void searchPart(const string& name) {
        for (const auto& part : parts) {
            if (part.name == name) {
                cout << "Part Name: " << part.name 
                     << ", Type: " << part.type 
                     << ", Price: " << part.price 
                     << ", Manufacturer: " << part.manufacturer.name 
                     << ", Country: " << part.manufacturer.country << endl;
                return;
            }
        }
        cout << "Part not found." << endl;
    }

    void displayParts() {
        for (const auto& part : parts) {
            cout << "Part Name: " << part.name 
                 << ", Type: " << part.type 
                 << ", Price: " << part.price 
                 << ", Manufacturer: " << part.manufacturer.name 
                 << ", Country: " << part.manufacturer.country << endl;
        }
    }
};

int main() {
    Inventory inventory;
    Manufacturer m1("Intel", "USA");
    Manufacturer m2("AMD", "USA");
    inventory.addPart("Core i7", "CPU", 320.00, m1);
    inventory.addPart("Ryzen 5", "CPU", 250.00, m2);
    inventory.displayParts();
    inventory.searchPart("Core i7");
    inventory.updatePart("Core i7", "CPU", 300.00);
    inventory.searchPart("Core i7");
    inventory.deletePart("Core i7");
    inventory.displayParts();
    return 0;
}