#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    Manufacturer(std::string name) : name(name) {}
    std::string name;
};

class ComputerPart {
public:
    ComputerPart(std::string name, double price, Manufacturer manufacturer)
        : name(name), price(price), manufacturer(manufacturer) {}
    
    std::string name;
    double price;
    Manufacturer manufacturer;
};

class PartsManager {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(const std::string& name, double price, const std::string& manufacturerName) {
        Manufacturer manufacturer(manufacturerName);
        ComputerPart part(name, price, manufacturer);
        parts.push_back(part);
    }

    void deletePart(const std::string& name) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == name) {
                parts.erase(it);
                return;
            }
        }
        std::cout << "Part not found.\n";
    }

    void updatePart(const std::string& name, double newPrice) {
        for (auto& part : parts) {
            if (part.name == name) {
                part.price = newPrice;
                return;
            }
        }
        std::cout << "Part not found.\n";
    }

    void searchPart(const std::string& name) {
        for (const auto& part : parts) {
            if (part.name == name) {
                std::cout << "Part: " << part.name << ", Price: $" << part.price 
                          << ", Manufacturer: " << part.manufacturer.name << "\n";
                return;
            }
        }
        std::cout << "Part not found.\n";
    }

    void displayParts() {
        if (parts.empty()) {
            std::cout << "No parts available.\n";
            return;
        }
        for (const auto& part : parts) {
            std::cout << "Part: " << part.name << ", Price: $" << part.price 
                      << ", Manufacturer: " << part.manufacturer.name << "\n";
        }
    }
};

int main() {
    PartsManager manager;
    manager.addPart("CPU", 250.00, "Intel");
    manager.addPart("GPU", 500.00, "NVIDIA");
    manager.displayParts();
    manager.searchPart("CPU");
    manager.updatePart("GPU", 450.00);
    manager.displayParts();
    manager.deletePart("CPU");
    manager.displayParts();
    return 0;
}