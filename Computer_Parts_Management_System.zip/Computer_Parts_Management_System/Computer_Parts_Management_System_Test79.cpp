#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string name;
    std::string manufacturer;
    double price;

    ComputerPart(std::string n, std::string m, double p) : name(n), manufacturer(m), price(p) {}
};

class ManagementSystem {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(const std::string &name, const std::string &manufacturer, double price) {
        parts.emplace_back(name, manufacturer, price);
    }

    void deletePart(const std::string &name) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == name) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(const std::string &name, const std::string &manufacturer, double price) {
        for (auto &part : parts) {
            if (part.name == name) {
                part.manufacturer = manufacturer;
                part.price = price;
                break;
            }
        }
    }

    void searchPart(const std::string &name) {
        for (const auto &part : parts) {
            if (part.name == name) {
                std::cout << "Part Name: " << part.name << "\nManufacturer: " << part.manufacturer << "\nPrice: $" << part.price << "\n";
                return;
            }
        }
        std::cout << "Part not found.\n";
    }

    void displayParts() {
        for (const auto &part : parts) {
            std::cout << "Part Name: " << part.name << "\nManufacturer: " << part.manufacturer << "\nPrice: $" << part.price << "\n";
        }
    }
};

int main() {
    ManagementSystem sys;
    int choice;
    std::string name, manufacturer;
    double price;

    do {
        std::cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display All Parts\n6. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter part name: ";
                std::cin >> name;
                std::cout << "Enter manufacturer: ";
                std::cin >> manufacturer;
                std::cout << "Enter price: ";
                std::cin >> price;
                sys.addPart(name, manufacturer, price);
                break;
            case 2:
                std::cout << "Enter part name to delete: ";
                std::cin >> name;
                sys.deletePart(name);
                break;
            case 3:
                std::cout << "Enter part name to update: ";
                std::cin >> name;
                std::cout << "Enter new manufacturer: ";
                std::cin >> manufacturer;
                std::cout << "Enter new price: ";
                std::cin >> price;
                sys.updatePart(name, manufacturer, price);
                break;
            case 4:
                std::cout << "Enter part name to search: ";
                std::cin >> name;
                sys.searchPart(name);
                break;
            case 5:
                sys.displayParts();
                break;
            case 6:
                break;
            default:
                std::cout << "Invalid choice.\n";
                break;
        }
    } while (choice != 6);

    return 0;
}