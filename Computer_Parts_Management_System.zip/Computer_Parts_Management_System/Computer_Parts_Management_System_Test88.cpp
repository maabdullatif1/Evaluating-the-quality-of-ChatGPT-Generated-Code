#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Part {
public:
    string partName;
    string manufacturer;
    double price;
    Part(string partName, string manufacturer, double price)
        : partName(partName), manufacturer(manufacturer), price(price) {}
};

class PartManager {
private:
    vector<Part> parts;

    int findPartIndex(const string& partName) {
        for (int i = 0; i < parts.size(); ++i) {
            if (parts[i].partName == partName) {
                return i;
            }
        }
        return -1;
    }

public:
    void addPart(const string& partName, const string& manufacturer, double price) {
        if (findPartIndex(partName) != -1) {
            cout << "Part already exists.\n";
            return;
        }
        parts.push_back(Part(partName, manufacturer, price));
        cout << "Part added successfully.\n";
    }

    void deletePart(const string& partName) {
        int index = findPartIndex(partName);
        if (index == -1) {
            cout << "Part not found.\n";
            return;
        }
        parts.erase(parts.begin() + index);
        cout << "Part deleted successfully.\n";
    }

    void updatePart(const string& partName, const string& manufacturer, double price) {
        int index = findPartIndex(partName);
        if (index == -1) {
            cout << "Part not found.\n";
            return;
        }
        parts[index].manufacturer = manufacturer;
        parts[index].price = price;
        cout << "Part updated successfully.\n";
    }

    void searchPart(const string& partName) {
        int index = findPartIndex(partName);
        if (index == -1) {
            cout << "Part not found.\n";
            return;
        }
        cout << "Part: " << parts[index].partName << ", Manufacturer: " 
             << parts[index].manufacturer << ", Price: " << parts[index].price << '\n';
    }

    void displayParts() {
        if (parts.empty()) {
            cout << "No parts to display.\n";
            return;
        }
        for (const auto& part : parts) {
            cout << "Part: " << part.partName << ", Manufacturer: " 
                 << part.manufacturer << ", Price: " << part.price << '\n';
        }
    }
};

int main() {
    PartManager manager;
    int choice;
    string partName, manufacturer;
    double price;
    
    do {
        cout << "1. Add Part\n";
        cout << "2. Delete Part\n";
        cout << "3. Update Part\n";
        cout << "4. Search Part\n";
        cout << "5. Display Parts\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter part name: ";
            cin >> partName;
            cout << "Enter manufacturer: ";
            cin >> manufacturer;
            cout << "Enter price: ";
            cin >> price;
            manager.addPart(partName, manufacturer, price);
            break;
        case 2:
            cout << "Enter part name: ";
            cin >> partName;
            manager.deletePart(partName);
            break;
        case 3:
            cout << "Enter part name: ";
            cin >> partName;
            cout << "Enter manufacturer: ";
            cin >> manufacturer;
            cout << "Enter price: ";
            cin >> price;
            manager.updatePart(partName, manufacturer, price);
            break;
        case 4:
            cout << "Enter part name: ";
            cin >> partName;
            manager.searchPart(partName);
            break;
        case 5:
            manager.displayParts();
            break;
        case 0:
            break;
        default:
            cout << "Invalid choice.\n";
        }
    } while (choice != 0);

    return 0;
}