#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    int id;
    std::string name;
    std::string manufacturer;
    double price;

    ComputerPart(int id, const std::string& name, const std::string& manufacturer, double price)
        : id(id), name(name), manufacturer(manufacturer), price(price) {}
};

class ComputerPartsManager {
private:
    std::vector<ComputerPart> parts;
    int nextId = 1;

    int findPartIndexById(int id) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addPart(const std::string& name, const std::string& manufacturer, double price) {
        parts.emplace_back(nextId++, name, manufacturer, price);
    }

    void deletePart(int id) {
        int index = findPartIndexById(id);
        if (index != -1) {
            parts.erase(parts.begin() + index);
        }
    }

    void updatePart(int id, const std::string& name, const std::string& manufacturer, double price) {
        int index = findPartIndexById(id);
        if (index != -1) {
            parts[index].name = name;
            parts[index].manufacturer = manufacturer;
            parts[index].price = price;
        }
    }

    void searchPartByName(const std::string& name) {
        for (const auto& part : parts) {
            if (part.name == name) {
                std::cout << "ID: " << part.id << ", Name: " << part.name
                          << ", Manufacturer: " << part.manufacturer
                          << ", Price: " << part.price << '\n';
            }
        }
    }

    void displayAllParts() {
        for (const auto& part : parts) {
            std::cout << "ID: " << part.id << ", Name: " << part.name
                      << ", Manufacturer: " << part.manufacturer
                      << ", Price: " << part.price << '\n';
        }
    }
};

int main() {
    ComputerPartsManager manager;

    manager.addPart("CPU", "Intel", 250.00);
    manager.addPart("GPU", "Nvidia", 500.00);
    manager.displayAllParts();

    manager.updatePart(1, "CPU", "AMD", 300.00);
    manager.displayAllParts();

    manager.searchPartByName("GPU");
    manager.deletePart(1);
    manager.displayAllParts();

    return 0;
}