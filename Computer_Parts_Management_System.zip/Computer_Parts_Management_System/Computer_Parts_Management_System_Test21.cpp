#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    int id;
    std::string name;
    std::string country;
    
    Manufacturer(int i, std::string n, std::string c) : id(i), name(n), country(c) {}
};

class ComputerPart {
public:
    int id;
    std::string name;
    int manufacturerId;
    std::string type;
    
    ComputerPart(int i, std::string n, int m, std::string t) : id(i), name(n), manufacturerId(m), type(t) {}
};

class ManagementSystem {
    std::vector<Manufacturer> manufacturers;
    std::vector<ComputerPart> computerParts;
    
    Manufacturer* findManufacturerById(int id) {
        for(auto &m : manufacturers) if(m.id == id) return &m;
        return nullptr;
    }
    
    ComputerPart* findComputerPartById(int id) {
        for(auto &p : computerParts) if(p.id == id) return &p;
        return nullptr;
    }
    
public:
    void addManufacturer(int id, std::string name, std::string country) {
        manufacturers.push_back(Manufacturer(id, name, country));
    }

    void addComputerPart(int id, std::string name, int manufacturerId, std::string type) {
        computerParts.push_back(ComputerPart(id, name, manufacturerId, type));
    }

    void updateManufacturer(int id, std::string name, std::string country) {
        Manufacturer* m = findManufacturerById(id);
        if(m) {
            m->name = name;
            m->country = country;
        }
    }

    void updateComputerPart(int id, std::string name, int manufacturerId, std::string type) {
        ComputerPart* p = findComputerPartById(id);
        if(p) {
            p->name = name;
            p->manufacturerId = manufacturerId;
            p->type = type;
        }
    }

    void deleteManufacturer(int id) {
        for(auto it = manufacturers.begin(); it != manufacturers.end(); ++it) {
            if(it->id == id) {
                manufacturers.erase(it);
                break;
            }
        }
    }

    void deleteComputerPart(int id) {
        for(auto it = computerParts.begin(); it != computerParts.end(); ++it) {
            if(it->id == id) {
                computerParts.erase(it);
                break;
            }
        }
    }

    void searchManufacturer(int id) {
        Manufacturer* m = findManufacturerById(id);
        if(m) {
            std::cout << "ID: " << m->id << ", Name: " << m->name << ", Country: " << m->country << std::endl;
        } else {
            std::cout << "Manufacturer not found" << std::endl;
        }
    }

    void searchComputerPart(int id) {
        ComputerPart* p = findComputerPartById(id);
        if(p) {
            std::cout << "ID: " << p->id << ", Name: " << p->name << ", Manufacturer ID: " << p->manufacturerId << ", Type: " << p->type << std::endl;
        } else {
            std::cout << "Computer part not found" << std::endl;
        }
    }

    void displayManufacturers() {
        for(const auto &m : manufacturers) {
            std::cout << "ID: " << m.id << ", Name: " << m.name << ", Country: " << m.country << std::endl;
        }
    }

    void displayComputerParts() {
        for(const auto &p : computerParts) {
            std::cout << "ID: " << p.id << ", Name: " << p.name << ", Manufacturer ID: " << p.manufacturerId << ", Type: " << p.type << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addManufacturer(1, "Intel", "USA");
    system.addManufacturer(2, "AMD", "USA");
    system.addComputerPart(1, "Core i7", 1, "Processor");
    system.addComputerPart(2, "Ryzen 5", 2, "Processor");
    
    system.displayManufacturers();
    system.displayComputerParts();
    
    system.searchManufacturer(1);
    system.searchComputerPart(2);
    
    system.updateManufacturer(2, "Advanced Micro Devices", "USA");
    system.updateComputerPart(1, "Core i9", 1, "Processor");
    
    system.deleteManufacturer(1);
    system.deleteComputerPart(2);
    
    system.displayManufacturers();
    system.displayComputerParts();
    
    return 0;
}