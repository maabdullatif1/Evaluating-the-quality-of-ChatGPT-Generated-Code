#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    int id;
    std::string name;
    std::string manufacturer;
    double price;

    ComputerPart(int id, const std::string& name, const std::string& manufacturer, double price)
        : id(id), name(name), manufacturer(manufacturer), price(price) {}
};

class PartsManager {
    std::vector<ComputerPart> parts;
    int nextId = 1;

public:
    void addPart(const std::string& name, const std::string& manufacturer, double price) {
        parts.push_back(ComputerPart(nextId++, name, manufacturer, price));
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->id == id) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(int id, const std::string& name, const std::string& manufacturer, double price) {
        for (auto& part : parts) {
            if (part.id == id) {
                part.name = name;
                part.manufacturer = manufacturer;
                part.price = price;
                break;
            }
        }
    }

    ComputerPart* searchPart(int id) {
        for (auto& part : parts) {
            if (part.id == id) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() {
        if (parts.empty()) {
            std::cout << "No parts available." << std::endl;
            return;
        }
        for (const auto& part : parts) {
            std::cout << "ID: " << part.id << ", Name: " << part.name 
                      << ", Manufacturer: " << part.manufacturer << ", Price: $" << part.price << std::endl;
        }
    }
};

int main() {
    PartsManager pm;
    int choice;
    do {
        std::cout << "\n1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\nChoose an option: ";
        std::cin >> choice;
        switch (choice) {
            case 1: {
                std::string name, manufacturer;
                double price;
                std::cout << "Enter name: ";
                std::cin.ignore();
                std::getline(std::cin, name);
                std::cout << "Enter manufacturer: ";
                std::getline(std::cin, manufacturer);
                std::cout << "Enter price: ";
                std::cin >> price;
                pm.addPart(name, manufacturer, price);
                break;
            }
            case 2: {
                int id;
                std::cout << "Enter part ID to delete: ";
                std::cin >> id;
                pm.deletePart(id);
                break;
            }
            case 3: {
                int id;
                std::string name, manufacturer;
                double price;
                std::cout << "Enter part ID to update: ";
                std::cin >> id;
                std::cout << "Enter new name: ";
                std::cin.ignore();
                std::getline(std::cin, name);
                std::cout << "Enter new manufacturer: ";
                std::getline(std::cin, manufacturer);
                std::cout << "Enter new price: ";
                std::cin >> price;
                pm.updatePart(id, name, manufacturer, price);
                break;
            }
            case 4: {
                int id;
                std::cout << "Enter part ID to search: ";
                std::cin >> id;
                ComputerPart* part = pm.searchPart(id);
                if (part) {
                    std::cout << "ID: " << part->id << ", Name: " << part->name 
                              << ", Manufacturer: " << part->manufacturer << ", Price: $" << part->price << std::endl;
                } else {
                    std::cout << "Part not found." << std::endl;
                }
                break;
            }
            case 5:
                pm.displayParts();
                break;
            case 6:
                std::cout << "Exiting." << std::endl;
                break;
            default:
                std::cout << "Invalid option." << std::endl;
        }
    } while (choice != 6);

    return 0;
}