#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    int id;
    std::string name;
    std::string manufacturer;
};

class ComputerPartsManagement {
private:
    std::vector<ComputerPart> parts;
    int currentID;
    
public:
    ComputerPartsManagement() : currentID(0) {}

    void addPart(const std::string& name, const std::string& manufacturer) {
        ComputerPart part;
        part.id = currentID++;
        part.name = name;
        part.manufacturer = manufacturer;
        parts.push_back(part);
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->id == id) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(int id, const std::string& name, const std::string& manufacturer) {
        for (auto& part : parts) {
            if (part.id == id) {
                part.name = name;
                part.manufacturer = manufacturer;
                break;
            }
        }
    }

    void searchPart(int id) {
        for (const auto& part : parts) {
            if (part.id == id) {
                std::cout << "ID: " << part.id << ", Name: " << part.name << ", Manufacturer: " << part.manufacturer << std::endl;
                return;
            }
        }
        std::cout << "Part not found" << std::endl;
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "ID: " << part.id << ", Name: " << part.name << ", Manufacturer: " << part.manufacturer << std::endl;
        }
    }
};

int main() {
    ComputerPartsManagement management;
    management.addPart("CPU", "Intel");
    management.addPart("Graphics Card", "NVIDIA");
    management.displayParts();
    management.searchPart(0);
    management.updatePart(1, "Graphics Card", "AMD");
    management.deletePart(0);
    management.displayParts();
    return 0;
}