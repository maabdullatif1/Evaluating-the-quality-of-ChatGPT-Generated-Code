#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string name;
    std::string manufacturer;
    double price;
    
    ComputerPart(std::string n, std::string m, double p) : name(n), manufacturer(m), price(p) {}
};

class PartsManagementSystem {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(const std::string &name, const std::string &manufacturer, double price) {
        parts.push_back(ComputerPart(name, manufacturer, price));
    }

    void deletePart(const std::string &name) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == name) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(const std::string &name, const std::string &manufacturer, double price) {
        for (auto &part : parts) {
            if (part.name == name) {
                part.manufacturer = manufacturer;
                part.price = price;
                break;
            }
        }
    }

    void searchPart(const std::string &name) {
        for (const auto &part : parts) {
            if (part.name == name) {
                std::cout << "Name: " << part.name << ", Manufacturer: "
                          << part.manufacturer << ", Price: " << part.price << std::endl;
                return;
            }
        }
        std::cout << "Part not found." << std::endl;
    }

    void displayParts() {
        for (const auto &part : parts) {
            std::cout << "Name: " << part.name << ", Manufacturer: "
                      << part.manufacturer << ", Price: " << part.price << std::endl;
        }
    }
};

int main() {
    PartsManagementSystem pms;
    
    pms.addPart("CPU", "Intel", 250.99);
    pms.addPart("GPU", "NVIDIA", 499.99);
    
    pms.displayParts();
    
    pms.searchPart("GPU");
    
    pms.updatePart("GPU", "AMD", 399.99);
    
    pms.displayParts();
    
    pms.deletePart("CPU");
    
    pms.displayParts();
    
    return 0;
}