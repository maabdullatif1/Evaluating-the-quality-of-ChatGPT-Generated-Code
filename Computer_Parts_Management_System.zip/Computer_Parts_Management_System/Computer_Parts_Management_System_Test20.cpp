#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Manufacturer {
    int id;
    string name;
};

struct ComputerPart {
    int id;
    string name;
    Manufacturer manufacturer;
};

class PartsManagementSystem {
    vector<ComputerPart> parts;
    vector<Manufacturer> manufacturers;
    int partIdCounter;
    int manufacturerIdCounter;

public:
    PartsManagementSystem() : partIdCounter(1), manufacturerIdCounter(1) {}

    void addManufacturer(const string& name) {
        manufacturers.push_back({manufacturerIdCounter++, name});
    }

    void addPart(const string& name, int manufacturerId) {
        for (auto& manufacturer : manufacturers) {
            if (manufacturer.id == manufacturerId) {
                parts.push_back({partIdCounter++, name, manufacturer});
                return;
            }
        }
        cout << "Manufacturer not found.\n";
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->id == id) {
                parts.erase(it);
                return;
            }
        }
        cout << "Part not found.\n";
    }

    void updatePart(int id, const string& newName, int newManufacturerId) {
        for (auto& part : parts) {
            if (part.id == id) {
                for (auto& manufacturer : manufacturers) {
                    if (manufacturer.id == newManufacturerId) {
                        part.name = newName;
                        part.manufacturer = manufacturer;
                        return;
                    }
                }
                cout << "Manufacturer not found.\n";
                return;
            }
        }
        cout << "Part not found.\n";
    }

    void searchPart(const string& name) {
        for (const auto& part : parts) {
            if (part.name == name) {
                cout << "Part ID: " << part.id
                     << ", Name: " << part.name
                     << ", Manufacturer: " << part.manufacturer.name << endl;
                return;
            }
        }
        cout << "Part not found.\n";
    }

    void displayAllParts() {
        for (const auto& part : parts) {
            cout << "Part ID: " << part.id
                 << ", Name: " << part.name
                 << ", Manufacturer: " << part.manufacturer.name << endl;
        }
    }

    void displayAllManufacturers() {
        for (const auto& manufacturer : manufacturers) {
            cout << "Manufacturer ID: " << manufacturer.id
                 << ", Name: " << manufacturer.name << endl;
        }
    }
};

int main() {
    PartsManagementSystem system;
    system.addManufacturer("Intel");
    system.addManufacturer("AMD");
    system.addPart("Core i9", 1);
    system.addPart("Ryzen 9", 2);
    system.displayAllParts();
    system.searchPart("Core i9");
    system.updatePart(1, "Core i7", 1);
    system.deletePart(2);
    system.displayAllParts();
    return 0;
}