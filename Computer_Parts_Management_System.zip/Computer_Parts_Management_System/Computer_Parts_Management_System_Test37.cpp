#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Manufacturer {
    string name;
    string country;
};

struct ComputerPart {
    string name;
    string type;
    double price;
    Manufacturer manufacturer;
};

class PartsManager {
    vector<ComputerPart> parts;

public:
    void addPart(const ComputerPart& part) {
        parts.push_back(part);
    }

    bool deletePart(const string& name) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == name) {
                parts.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updatePart(const string& name, const ComputerPart& updatedPart) {
        for (auto& part : parts) {
            if (part.name == name) {
                part = updatedPart;
                return true;
            }
        }
        return false;
    }

    ComputerPart* searchPart(const string& name) {
        for (auto& part : parts) {
            if (part.name == name) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto& part : parts) {
            cout << "Part Name: " << part.name << ", Type: " << part.type
                 << ", Price: $" << part.price 
                 << ", Manufacturer: " << part.manufacturer.name 
                 << " (" << part.manufacturer.country << ")" << endl;
        }
    }
};

int main() {
    PartsManager manager;

    Manufacturer intel = {"Intel", "USA"};
    Manufacturer amd = {"AMD", "USA"};

    ComputerPart part1 = {"Core i7", "CPU", 300.00, intel};
    ComputerPart part2 = {"Ryzen 5", "CPU", 250.00, amd};

    manager.addPart(part1);
    manager.addPart(part2);

    manager.displayParts();

    manager.deletePart("Core i7");
    manager.displayParts();

    ComputerPart newPart = {"Ryzen 7", "CPU", 350.00, amd};
    manager.updatePart("Ryzen 5", newPart);
    manager.displayParts();

    ComputerPart* searchResult = manager.searchPart("Ryzen 7");
    if (searchResult) {
        cout << "Found: " << searchResult->name << endl;
    } else {
        cout << "Part not found." << endl;
    }

    return 0;
}