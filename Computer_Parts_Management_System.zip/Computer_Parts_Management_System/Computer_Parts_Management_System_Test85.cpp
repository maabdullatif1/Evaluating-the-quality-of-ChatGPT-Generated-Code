#include <iostream>
#include <vector>
#include <string>

class Part {
public:
    std::string name;
    std::string manufacturer;
    double price;

    Part(std::string name, std::string manufacturer, double price)
        : name(name), manufacturer(manufacturer), price(price) {}
};

class PartManager {
private:
    std::vector<Part> parts;
public:
    void addPart(const std::string& name, const std::string& manufacturer, double price) {
        parts.push_back(Part(name, manufacturer, price));
    }
    
    void deletePart(const std::string& name) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].name == name) {
                parts.erase(parts.begin() + i);
                return;
            }
        }
    }
    
    void updatePart(const std::string& name, const std::string& newManufacturer, double newPrice) {
        for (Part& part : parts) {
            if (part.name == name) {
                part.manufacturer = newManufacturer;
                part.price = newPrice;
                return;
            }
        }
    }
    
    Part* searchPart(const std::string& name) {
        for (Part& part : parts) {
            if (part.name == name) {
                return &part;
            }
        }
        return nullptr;
    }
    
    void displayParts() {
        for (const Part& part : parts) {
            std::cout << "Name: " << part.name
                      << ", Manufacturer: " << part.manufacturer
                      << ", Price: " << part.price << std::endl;
        }
    }
};

int main() {
    PartManager manager;
    manager.addPart("CPU", "Intel", 299.99);
    manager.addPart("GPU", "NVIDIA", 499.99);
    manager.displayParts();
    
    manager.updatePart("CPU", "AMD", 279.99);
    manager.displayParts();
    
    manager.deletePart("GPU");
    manager.displayParts();
    
    Part* part = manager.searchPart("CPU");
    if (part) {
        std::cout << "Found: " << part->name 
                  << ", Manufacturer: " << part->manufacturer 
                  << ", Price: " << part->price << std::endl;
    }

    return 0;
}