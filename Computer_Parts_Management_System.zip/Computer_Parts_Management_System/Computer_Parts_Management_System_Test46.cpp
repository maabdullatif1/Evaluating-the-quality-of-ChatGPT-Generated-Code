#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    Manufacturer(const std::string &name) : name(name) {}
    std::string name;
};

class ComputerPart {
public:
    ComputerPart(const std::string &name, const std::string &manufacturer) 
        : name(name), manufacturer(manufacturer) {}
    std::string name;
    std::string manufacturer;
};

class ManagementSystem {
    std::vector<Manufacturer> manufacturers;
    std::vector<ComputerPart> parts;
public:
    void addManufacturer(const std::string &name) {
        manufacturers.emplace_back(name);
    }

    void addPart(const std::string &partName, const std::string &manufacturerName) {
        parts.emplace_back(partName, manufacturerName);
    }

    void deleteManufacturer(const std::string &name) {
        manufacturers.erase(remove_if(manufacturers.begin(), manufacturers.end(), [&](Manufacturer &m) {
            return m.name == name;
        }), manufacturers.end());
    }

    void deletePart(const std::string &name) {
        parts.erase(remove_if(parts.begin(), parts.end(), [&](ComputerPart &p) {
            return p.name == name;
        }), parts.end());
    }

    void updateManufacturer(const std::string &oldName, const std::string &newName) {
        for (auto &m : manufacturers) {
            if (m.name == oldName) m.name = newName;
        }
    }

    void updatePart(const std::string &oldName, const std::string &newName, const std::string &newManufacturer) {
        for (auto &p : parts) {
            if (p.name == oldName) {
                p.name = newName;
                p.manufacturer = newManufacturer;
            }
        }
    }

    void searchManufacturer(const std::string &name) {
        for (const auto &m : manufacturers) {
            if (m.name == name) {
                std::cout << "Manufacturer found: " << m.name << std::endl;
                return;
            }
        }
        std::cout << "Manufacturer not found." << std::endl;
    }

    void searchPart(const std::string &name) {
        for (const auto &p : parts) {
            if (p.name == name) {
                std::cout << "Part found: " << p.name << ", Manufacturer: " << p.manufacturer << std::endl;
                return;
            }
        }
        std::cout << "Part not found." << std::endl;
    }

    void displayManufacturers() {
        for (const auto &m : manufacturers) {
            std::cout << "Manufacturer: " << m.name << std::endl;
        }
    }

    void displayParts() {
        for (const auto &p : parts) {
            std::cout << "Part: " << p.name << ", Manufacturer: " << p.manufacturer << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addManufacturer("Intel");
    system.addPart("CPU", "Intel");
    system.displayManufacturers();
    system.displayParts();
    system.searchManufacturer("Intel");
    system.searchPart("CPU");
    system.updateManufacturer("Intel", "Intel Corporation");
    system.updatePart("CPU", "Core i7", "Intel Corporation");
    system.displayManufacturers();
    system.displayParts();
    system.deletePart("Core i7");
    system.deleteManufacturer("Intel Corporation");
    system.displayManufacturers();
    system.displayParts();
    return 0;
}