#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    Manufacturer(const std::string &n, const std::string &a) : name(n), address(a) {}
    void update(const std::string &n, const std::string &a) {
        name = n;
        address = a;
    }
    std::string getName() const { return name; }
    std::string getAddress() const { return address; }
private:
    std::string name;
    std::string address;
};

class Part {
public:
    Part(const std::string &n, const std::string &model, double p, const Manufacturer &m)
        : name(n), modelNumber(model), price(p), manufacturer(m) {}
    void update(const std::string &n, const std::string &model, double p, const Manufacturer &m) {
        name = n;
        modelNumber = model;
        price = p;
        manufacturer = m;
    }
    std::string getName() const { return name; }
    std::string getModelNumber() const { return modelNumber; }
    double getPrice() const { return price; }
    Manufacturer getManufacturer() const { return manufacturer; }
private:
    std::string name;
    std::string modelNumber;
    double price;
    Manufacturer manufacturer;
};

class System {
public:
    void addPart(const Part &part) { parts.push_back(part); }
    
    void deletePart(const std::string &model) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->getModelNumber() == model) {
                parts.erase(it);
                break;
            }
        }
    }
    
    void updatePart(const std::string &model, const Part &newPart) {
        for (auto &part : parts) {
            if (part.getModelNumber() == model) {
                part.update(newPart.getName(), newPart.getModelNumber(), newPart.getPrice(), newPart.getManufacturer());
                break;
            }
        }
    }
    
    Part* searchPart(const std::string &model) {
        for (auto &part : parts) {
            if (part.getModelNumber() == model) {
                return &part;
            }
        }
        return nullptr;
    }
    
    void displayParts() const {
        for (const auto &part : parts) {
            std::cout << "Part Name: " << part.getName() 
                      << ", Model Number: " << part.getModelNumber() 
                      << ", Price: " << part.getPrice() 
                      << ", Manufacturer: " << part.getManufacturer().getName() 
                      << ", Address: " << part.getManufacturer().getAddress() 
                      << std::endl;
        }
    }
    
    void addManufacturer(const Manufacturer &manufacturer) { manufacturers.push_back(manufacturer); }
    
    void deleteManufacturer(const std::string &name) {
        for (auto it = manufacturers.begin(); it != manufacturers.end(); ++it) {
            if (it->getName() == name) {
                manufacturers.erase(it);
                break;
            }
        }
    }
    
    Manufacturer* searchManufacturer(const std::string &name) {
        for (auto &manufacturer : manufacturers) {
            if (manufacturer.getName() == name) {
                return &manufacturer;
            }
        }
        return nullptr;
    }
    
    void displayManufacturers() const {
        for (const auto &manufacturer : manufacturers) {
            std::cout << "Manufacturer Name: " << manufacturer.getName() 
                      << ", Address: " << manufacturer.getAddress() 
                      << std::endl;
        }
    }
    
private:
    std::vector<Part> parts;
    std::vector<Manufacturer> manufacturers;
};

int main() {
    System sys;
    Manufacturer m1("Intel", "USA");
    Manufacturer m2("AMD", "USA");
    Manufacturer m3("NVIDIA", "USA");
    sys.addManufacturer(m1);
    sys.addManufacturer(m2);
    sys.addManufacturer(m3);
    Part p1("CPU", "i7-9700K", 350.00, m1);
    Part p2("GPU", "RX5700", 450.00, m2);
    Part p3("GPU", "RTX3080", 699.99, m3);
    sys.addPart(p1);
    sys.addPart(p2);
    sys.addPart(p3);
    sys.displayParts();
    sys.displayManufacturers();
    return 0;
}