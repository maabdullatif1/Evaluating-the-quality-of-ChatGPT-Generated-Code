#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    std::string name;
    std::string country;

    Manufacturer(const std::string& name, const std::string& country)
        : name(name), country(country) {}
};

class ComputerPart {
public:
    std::string name;
    std::string type;
    Manufacturer manufacturer;

    ComputerPart(const std::string& name, const std::string& type, const Manufacturer& manufacturer)
        : name(name), type(type), manufacturer(manufacturer) {}
};

class PartsManagementSystem {
private:
    std::vector<ComputerPart> parts;

    int findPartIndex(const std::string& partName) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].name == partName) {
                return i;
            }
        }
        return -1;
    }

public:
    void addPart(const std::string& partName, const std::string& partType, const Manufacturer& manufacturer) {
        parts.push_back(ComputerPart(partName, partType, manufacturer));
    }

    void deletePart(const std::string& partName) {
        int index = findPartIndex(partName);
        if (index != -1) {
            parts.erase(parts.begin() + index);
        } else {
            std::cout << "Part not found.\n";
        }
    }

    void updatePart(const std::string& oldName, const std::string& newName, const std::string& partType, const Manufacturer& manufacturer) {
        int index = findPartIndex(oldName);
        if (index != -1) {
            parts[index] = ComputerPart(newName, partType, manufacturer);
        } else {
            std::cout << "Part not found.\n";
        }
    }

    void searchPart(const std::string& partName) {
        int index = findPartIndex(partName);
        if (index != -1) {
            ComputerPart& p = parts[index];
            std::cout << "Part found: " << p.name << ", Type: " << p.type << ", Manufacturer: " << p.manufacturer.name << ", Country: " << p.manufacturer.country << "\n";
        } else {
            std::cout << "Part not found.\n";
        }
    }

    void displayParts() {
        if (parts.empty()) {
            std::cout << "No parts available.\n";
            return;
        }
        for (const auto& part : parts) {
            std::cout << "Part: " << part.name << ", Type: " << part.type << ", Manufacturer: " << part.manufacturer.name << ", Country: " << part.manufacturer.country << "\n";
        }
    }
};

int main() {
    PartsManagementSystem system;

    Manufacturer intel("Intel", "USA");
    Manufacturer amd("AMD", "USA");

    system.addPart("Core i7", "CPU", intel);
    system.addPart("Ryzen 5", "CPU", amd);

    system.displayParts();
    system.searchPart("Core i7");

    system.updatePart("Core i7", "Core i9", "CPU", intel);
    system.deletePart("Ryzen 5");

    system.displayParts();
    system.searchPart("Ryzen 5");

    return 0;
}