#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    int id;
    std::string name;
    std::string manufacturer;
    double price;

    ComputerPart(int id, std::string name, std::string manufacturer, double price) 
        : id(id), name(name), manufacturer(manufacturer), price(price) {}
};

class ComputerPartsManager {
private:
    std::vector<ComputerPart> parts;
    int nextId = 1;

public:
    void addPart(const std::string &name, const std::string &manufacturer, double price) {
        parts.push_back(ComputerPart(nextId++, name, manufacturer, price));
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->id == id) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(int id, const std::string &name, const std::string &manufacturer, double price) {
        for (auto &part : parts) {
            if (part.id == id) {
                part.name = name;
                part.manufacturer = manufacturer;
                part.price = price;
                break;
            }
        }
    }

    int searchPart(const std::string &name) {
        for (const auto &part : parts) {
            if (part.name == name) {
                return part.id;
            }
        }
        return -1;
    }

    void displayParts() {
        for (const auto &part : parts) {
            std::cout << "ID: " << part.id << ", Name: " << part.name 
                      << ", Manufacturer: " << part.manufacturer 
                      << ", Price: " << part.price << std::endl;
        }
    }
};

int main() {
    ComputerPartsManager manager;
    manager.addPart("CPU", "Intel", 250.00);
    manager.addPart("GPU", "NVIDIA", 550.00);
    manager.displayParts();
    int id = manager.searchPart("GPU");
    std::cout << "GPU ID: " << id << std::endl;
    manager.updatePart(id, "GPU", "AMD", 500.00);
    manager.displayParts();
    manager.deletePart(id);
    manager.displayParts();
    return 0;
}