#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Manufacturer {
public:
    int id;
    string name;

    Manufacturer(int id, string name) : id(id), name(name) {}
};

class ComputerPart {
public:
    int id;
    string name;
    int manufacturerId;

    ComputerPart(int id, string name, int manufacturerId) : id(id), name(name), manufacturerId(manufacturerId) {}
};

class PartsManagementSystem {
private:
    vector<Manufacturer> manufacturers;
    vector<ComputerPart> parts;

    Manufacturer* findManufacturerById(int id) {
        for (auto& manufacturer : manufacturers) {
            if (manufacturer.id == id) {
                return &manufacturer;
            }
        }
        return nullptr;
    }

    ComputerPart* findPartById(int id) {
        for (auto& part : parts) {
            if (part.id == id) {
                return &part;
            }
        }
        return nullptr;
    }

public:
    void addManufacturer(int id, string name) {
        manufacturers.push_back(Manufacturer(id, name));
    }

    void addPart(int id, string name, int manufacturerId) {
        if (findManufacturerById(manufacturerId)) {
            parts.push_back(ComputerPart(id, name, manufacturerId));
        } else {
            cout << "Manufacturer not found." << endl;
        }
    }

    void deleteManufacturer(int id) {
        manufacturers.erase(remove_if(manufacturers.begin(), manufacturers.end(), [id](Manufacturer& m) { return m.id == id; }), manufacturers.end());
        parts.erase(remove_if(parts.begin(), parts.end(), [id](ComputerPart& p) { return p.manufacturerId == id; }), parts.end());
    }

    void deletePart(int id) {
        parts.erase(remove_if(parts.begin(), parts.end(), [id](ComputerPart& p) { return p.id == id; }), parts.end());
    }

    void updateManufacturer(int id, string newName) {
        Manufacturer* manufacturer = findManufacturerById(id);
        if (manufacturer) {
            manufacturer->name = newName;
        } else {
            cout << "Manufacturer not found." << endl;
        }
    }

    void updatePart(int id, string newName, int newManufacturerId) {
        ComputerPart* part = findPartById(id);
        if (part && findManufacturerById(newManufacturerId)) {
            part->name = newName;
            part->manufacturerId = newManufacturerId;
        } else {
            cout << "Part or Manufacturer not found." << endl;
        }
    }

    void searchManufacturer(int id) {
        Manufacturer* manufacturer = findManufacturerById(id);
        if (manufacturer) {
            cout << "Manufacturer ID: " << manufacturer->id << ", Name: " << manufacturer->name << endl;
        } else {
            cout << "Manufacturer not found." << endl;
        }
    }

    void searchPart(int id) {
        ComputerPart* part = findPartById(id);
        if (part) {
            Manufacturer* manufacturer = findManufacturerById(part->manufacturerId);
            string manufacturerName = manufacturer ? manufacturer->name : "Unknown";
            cout << "Part ID: " << part->id << ", Name: " << part->name << ", Manufacturer: " << manufacturerName << endl;
        } else {
            cout << "Part not found." << endl;
        }
    }

    void displayAllManufacturers() {
        for (auto& manufacturer : manufacturers) {
            cout << "Manufacturer ID: " << manufacturer.id << ", Name: " << manufacturer.name << endl;
        }
    }

    void displayAllParts() {
        for (auto& part : parts) {
            Manufacturer* manufacturer = findManufacturerById(part.manufacturerId);
            string manufacturerName = manufacturer ? manufacturer->name : "Unknown";
            cout << "Part ID: " << part.id << ", Name: " << part.name << ", Manufacturer: " << manufacturerName << endl;
        }
    }
};

int main() {
    PartsManagementSystem pms;
    pms.addManufacturer(1, "Intel");
    pms.addManufacturer(2, "AMD");
    pms.addPart(101, "Core i7", 1);
    pms.addPart(102, "Ryzen 9", 2);
    pms.displayAllManufacturers();
    pms.displayAllParts();
    pms.searchPart(101);
    pms.updatePart(101, "Core i9", 1);
    pms.searchPart(101);
    pms.deleteManufacturer(2);
    pms.displayAllManufacturers();
    pms.displayAllParts();
    return 0;
}