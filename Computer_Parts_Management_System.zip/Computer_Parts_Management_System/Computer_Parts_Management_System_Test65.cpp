#include <iostream>
#include <vector>
#include <string>

struct Manufacturer {
    std::string name;
    std::string country;
};

struct ComputerPart {
    std::string partName;
    std::string partNumber;
    Manufacturer manufacturer;
    double price;
    int quantity;
};

class PartsManagementSystem {
    std::vector<ComputerPart> parts;

public:
    void addPart(const ComputerPart& part) {
        parts.push_back(part);
    }

    void deletePart(const std::string& partNumber) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partNumber == partNumber) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(const std::string& partNumber, const ComputerPart& updatedPart) {
        for (auto& part : parts) {
            if (part.partNumber == partNumber) {
                part = updatedPart;
                break;
            }
        }
    }

    ComputerPart* searchPart(const std::string& partNumber) {
        for (auto& part : parts) {
            if (part.partNumber == partNumber) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "Part Name: " << part.partName << std::endl;
            std::cout << "Part Number: " << part.partNumber << std::endl;
            std::cout << "Manufacturer Name: " << part.manufacturer.name << std::endl;
            std::cout << "Manufacturer Country: " << part.manufacturer.country << std::endl;
            std::cout << "Price: " << part.price << std::endl;
            std::cout << "Quantity: " << part.quantity << std::endl << std::endl;
        }
    }
};

int main() {
    PartsManagementSystem system;
    Manufacturer manufacturer1 = {"Intel", "USA"};
    Manufacturer manufacturer2 = {"AMD", "USA"};

    ComputerPart part1 = {"Processor", "INT123", manufacturer1, 299.99, 50};
    ComputerPart part2 = {"Graphics Card", "AMD456", manufacturer2, 499.99, 30};

    system.addPart(part1);
    system.addPart(part2);

    system.displayParts();

    ComputerPart updatedPart = {"Processor", "INT123", manufacturer1, 279.99, 60};
    system.updatePart("INT123", updatedPart);

    system.displayParts();

    system.deletePart("AMD456");

    system.displayParts();

    ComputerPart* searchResult = system.searchPart("INT123");
    if (searchResult) {
        std::cout << "Found: " << searchResult->partName << ", " << searchResult->partNumber << std::endl;
    }

    return 0;
}