#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Manufacturer {
    string name;
    string country;
};

struct ComputerPart {
    string name;
    string type;
    Manufacturer manufacturer;
    double price;
};

class Inventory {
    vector<ComputerPart> parts;

public:
    void addPart(const ComputerPart& part) {
        parts.push_back(part);
    }

    void deletePart(const string& partName) {
        parts.erase(remove_if(parts.begin(), parts.end(), [&](const ComputerPart& part) {
            return part.name == partName;
        }), parts.end());
    }

    void updatePart(const string& partName, const ComputerPart& updatedPart) {
        for (auto& part : parts) {
            if (part.name == partName) {
                part = updatedPart;
                break;
            }
        }
    }

    ComputerPart* searchPart(const string& partName) {
        for (auto& part : parts) {
            if (part.name == partName) return &part;
        }
        return nullptr;
    }

    void displayParts() const {
        for (const auto& part : parts) {
            cout << "Name: " << part.name << ", Type: " << part.type
                 << ", Manufacturer: " << part.manufacturer.name
                 << ", Country: " << part.manufacturer.country
                 << ", Price: $" << part.price << endl;
        }
    }
};

int main() {
    Inventory inventory;
    int choice;
    while (true) {
        cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\nChoose an option: ";
        cin >> choice;
        if (choice == 1) {
            ComputerPart part;
            cout << "Enter part name: "; cin >> part.name;
            cout << "Enter part type: "; cin >> part.type;
            cout << "Enter manufacturer name: "; cin >> part.manufacturer.name;
            cout << "Enter manufacturer country: "; cin >> part.manufacturer.country;
            cout << "Enter price: "; cin >> part.price;
            inventory.addPart(part);
        } else if (choice == 2) {
            string partName;
            cout << "Enter part name to delete: "; cin >> partName;
            inventory.deletePart(partName);
        } else if (choice == 3) {
            string partName;
            ComputerPart updatedPart;
            cout << "Enter part name to update: "; cin >> partName;
            cout << "Enter new part name: "; cin >> updatedPart.name;
            cout << "Enter new part type: "; cin >> updatedPart.type;
            cout << "Enter new manufacturer name: "; cin >> updatedPart.manufacturer.name;
            cout << "Enter new manufacturer country: "; cin >> updatedPart.manufacturer.country;
            cout << "Enter new price: "; cin >> updatedPart.price;
            inventory.updatePart(partName, updatedPart);
        } else if (choice == 4) {
            string partName;
            cout << "Enter part name to search: "; cin >> partName;
            ComputerPart* part = inventory.searchPart(partName);
            if (part) {
                cout << "Name: " << part->name << ", Type: " << part->type
                     << ", Manufacturer: " << part->manufacturer.name
                     << ", Country: " << part->manufacturer.country
                     << ", Price: $" << part->price << endl;
            } else {
                cout << "Part not found." << endl;
            }
        } else if (choice == 5) {
            inventory.displayParts();
        } else if (choice == 6) {
            break;
        } else {
            cout << "Invalid choice. Try again." << endl;
        }
    }
    return 0;
}