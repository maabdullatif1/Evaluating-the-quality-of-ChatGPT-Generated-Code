#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Manufacturer {
    string name;
    string address;
    string contact;
};

struct ComputerPart {
    string partName;
    string partNumber;
    Manufacturer manufacturer;
    double price;
    int quantity;
};

vector<ComputerPart> inventory;

void addPart() {
    ComputerPart part;
    cout << "Enter part name: ";
    cin >> part.partName;
    cout << "Enter part number: ";
    cin >> part.partNumber;
    cout << "Enter manufacturer name: ";
    cin >> part.manufacturer.name;
    cout << "Enter manufacturer address: ";
    cin >> part.manufacturer.address;
    cout << "Enter manufacturer contact: ";
    cin >> part.manufacturer.contact;
    cout << "Enter price: ";
    cin >> part.price;
    cout << "Enter quantity: ";
    cin >> part.quantity;
    inventory.push_back(part);
}

void deletePart() {
    string partNumber;
    cout << "Enter part number to delete: ";
    cin >> partNumber;
    for (auto it = inventory.begin(); it != inventory.end(); ++it) {
        if (it->partNumber == partNumber) {
            inventory.erase(it);
            cout << "Part deleted successfully.\n";
            return;
        }
    }
    cout << "Part not found.\n";
}

void updatePart() {
    string partNumber;
    cout << "Enter part number to update: ";
    cin >> partNumber;
    for (auto &part : inventory) {
        if (part.partNumber == partNumber) {
            cout << "Enter new part name: ";
            cin >> part.partName;
            cout << "Enter new manufacturer name: ";
            cin >> part.manufacturer.name;
            cout << "Enter new manufacturer address: ";
            cin >> part.manufacturer.address;
            cout << "Enter new manufacturer contact: ";
            cin >> part.manufacturer.contact;
            cout << "Enter new price: ";
            cin >> part.price;
            cout << "Enter new quantity: ";
            cin >> part.quantity;
            cout << "Part updated successfully.\n";
            return;
        }
    }
    cout << "Part not found.\n";
}

void searchPart() {
    string partNumber;
    cout << "Enter part number to search: ";
    cin >> partNumber;
    for (const auto &part : inventory) {
        if (part.partNumber == partNumber) {
            cout << "Part Name: " << part.partName << "\n";
            cout << "Manufacturer Name: " << part.manufacturer.name << "\n";
            cout << "Manufacturer Address: " << part.manufacturer.address << "\n";
            cout << "Manufacturer Contact: " << part.manufacturer.contact << "\n";
            cout << "Price: $" << part.price << "\n";
            cout << "Quantity: " << part.quantity << "\n";
            return;
        }
    }
    cout << "Part not found.\n";
}

void displayParts() {
    if (inventory.empty()) {
        cout << "No parts available.\n";
        return;
    }
    for (const auto &part : inventory) {
        cout << "Part Name: " << part.partName << "\n";
        cout << "Part Number: " << part.partNumber << "\n";
        cout << "Manufacturer Name: " << part.manufacturer.name << "\n";
        cout << "Manufacturer Address: " << part.manufacturer.address << "\n";
        cout << "Manufacturer Contact: " << part.manufacturer.contact << "\n";
        cout << "Price: $" << part.price << "\n";
        cout << "Quantity: " << part.quantity << "\n";
        cout << "-----------------------\n";
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Part\n";
        cout << "2. Delete Part\n";
        cout << "3. Update Part\n";
        cout << "4. Search Part\n";
        cout << "5. Display Parts\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addPart(); break;
            case 2: deletePart(); break;
            case 3: updatePart(); break;
            case 4: searchPart(); break;
            case 5: displayParts(); break;
            case 6: cout << "Exiting...\n"; break;
            default: cout << "Invalid choice.\n";
        }
    } while (choice != 6);
    return 0;
}