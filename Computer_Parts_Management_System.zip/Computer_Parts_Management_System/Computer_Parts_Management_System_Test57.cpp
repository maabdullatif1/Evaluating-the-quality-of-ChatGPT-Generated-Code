#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    int id;
    std::string name;
    std::string country;

    Manufacturer(int id, const std::string& name, const std::string& country)
        : id(id), name(name), country(country) {}
};

class ComputerPart {
public:
    int id;
    std::string name;
    double price;
    Manufacturer manufacturer;

    ComputerPart(int id, const std::string& name, double price, const Manufacturer& manufacturer)
        : id(id), name(name), price(price), manufacturer(manufacturer) {}
};

class ManagementSystem {
    std::vector<Manufacturer> manufacturers;
    std::vector<ComputerPart> parts;

public:
    void addManufacturer(int id, const std::string& name, const std::string& country) {
        manufacturers.push_back(Manufacturer(id, name, country));
    }

    void addPart(int id, const std::string& name, double price, const Manufacturer& manufacturer) {
        parts.push_back(ComputerPart(id, name, price, manufacturer));
    }

    void updateManufacturer(int id, const std::string& name, const std::string& country) {
        for (auto& m : manufacturers) {
            if (m.id == id) {
                m.name = name;
                m.country = country;
                break;
            }
        }
    }

    void updatePart(int id, const std::string& name, double price, const Manufacturer& manufacturer) {
        for (auto& p : parts) {
            if (p.id == id) {
                p.name = name;
                p.price = price;
                p.manufacturer = manufacturer;
                break;
            }
        }
    }

    void deleteManufacturer(int id) {
        for (auto it = manufacturers.begin(); it != manufacturers.end(); ++it) {
            if (it->id == id) {
                manufacturers.erase(it);
                break;
            }
        }
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->id == id) {
                parts.erase(it);
                break;
            }
        }
    }

    void searchManufacturer(int id) const {
        for (const auto& m : manufacturers) {
            if (m.id == id) {
                std::cout << "Manufacturer ID: " << m.id << ", Name: " << m.name << ", Country: " << m.country << '\n';
                return;
            }
        }
        std::cout << "Manufacturer not found.\n";
    }

    void searchPart(int id) const {
        for (const auto& p : parts) {
            if (p.id == id) {
                std::cout << "Part ID: " << p.id << ", Name: " << p.name << ", Price: " << p.price 
                          << ", Manufacturer Name: " << p.manufacturer.name << ", Manufacturer Country: " 
                          << p.manufacturer.country << '\n';
                return;
            }
        }
        std::cout << "Part not found.\n";
    }

    void displayAllManufacturers() const {
        for (const auto& m : manufacturers) {
            std::cout << "Manufacturer ID: " << m.id << ", Name: " << m.name << ", Country: " << m.country << '\n';
        }
    }

    void displayAllParts() const {
        for (const auto& p : parts) {
            std::cout << "Part ID: " << p.id << ", Name: " << p.name << ", Price: " << p.price 
                      << ", Manufacturer Name: " << p.manufacturer.name << ", Manufacturer Country: " 
                      << p.manufacturer.country << '\n';
        }
    }
};

int main() {
    ManagementSystem system;
    Manufacturer m1(1, "Intel", "USA");
    Manufacturer m2(2, "AMD", "USA");

    system.addManufacturer(m1.id, m1.name, m1.country);
    system.addManufacturer(m2.id, m2.name, m2.country);

    system.addPart(1, "Processor", 320.50, m1);
    system.addPart(2, "Graphic Card", 520.99, m2);

    system.displayAllManufacturers();
    system.displayAllParts();

    system.searchManufacturer(1);
    system.searchPart(2);

    system.updateManufacturer(1, "Intel Corp", "USA");
    system.updatePart(1, "Intel Processor", 299.99, m1);

    system.deleteManufacturer(2);
    system.deletePart(2);

    system.displayAllManufacturers();
    system.displayAllParts();

    return 0;
}