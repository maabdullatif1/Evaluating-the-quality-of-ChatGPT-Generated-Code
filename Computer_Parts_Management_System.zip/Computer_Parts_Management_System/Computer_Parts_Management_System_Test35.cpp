#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    int id;
    std::string name;
    std::string manufacturer;
    double price;

    ComputerPart(int i, std::string n, std::string m, double p)
        : id(i), name(n), manufacturer(m), price(p) {}
};

class PartsManager {
private:
    std::vector<ComputerPart> parts;
    int nextId;

    int findPartIndexById(int id) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    PartsManager() : nextId(1) {}

    void addPart(const std::string &name, const std::string &manufacturer, double price) {
        parts.push_back(ComputerPart(nextId++, name, manufacturer, price));
    }

    void deletePart(int id) {
        int index = findPartIndexById(id);
        if (index != -1) {
            parts.erase(parts.begin() + index);
        } else {
            std::cout << "Part not found.\n";
        }
    }

    void updatePart(int id, const std::string &name, const std::string &manufacturer, double price) {
        int index = findPartIndexById(id);
        if (index != -1) {
            parts[index].name = name;
            parts[index].manufacturer = manufacturer;
            parts[index].price = price;
        } else {
            std::cout << "Part not found.\n";
        }
    }

    void searchPart(int id) {
        int index = findPartIndexById(id);
        if (index != -1) {
            const ComputerPart &part = parts[index];
            std::cout << "ID: " << part.id << ", Name: " << part.name
                      << ", Manufacturer: " << part.manufacturer
                      << ", Price: " << part.price << "\n";
        } else {
            std::cout << "Part not found.\n";
        }
    }

    void displayAllParts() {
        for (const ComputerPart &part : parts) {
            std::cout << "ID: " << part.id << ", Name: " << part.name
                      << ", Manufacturer: " << part.manufacturer
                      << ", Price: " << part.price << "\n";
        }
        if (parts.empty()) {
            std::cout << "No parts available.\n";
        }
    }
};

int main() {
    PartsManager manager;
    int choice, id;
    std::string name, manufacturer;
    double price;

    while (true) {
        std::cout << "\n1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display All Parts\n6. Exit\n";
        std::cout << "Enter choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter part name, manufacturer, price: ";
                std::cin >> name >> manufacturer >> price;
                manager.addPart(name, manufacturer, price);
                break;

            case 2:
                std::cout << "Enter part ID to delete: ";
                std::cin >> id;
                manager.deletePart(id);
                break;

            case 3:
                std::cout << "Enter part ID to update, new name, new manufacturer, new price: ";
                std::cin >> id >> name >> manufacturer >> price;
                manager.updatePart(id, name, manufacturer, price);
                break;

            case 4:
                std::cout << "Enter part ID to search: ";
                std::cin >> id;
                manager.searchPart(id);
                break;

            case 5:
                manager.displayAllParts();
                break;

            case 6:
                return 0;

            default:
                std::cout << "Invalid choice.\n";
        }
    }
}