#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    int id;
    std::string name;
    std::string manufacturer;

    ComputerPart(int id, const std::string& name, const std::string& manufacturer)
        : id(id), name(name), manufacturer(manufacturer) {}
};

class PartsManagementSystem {
private:
    std::vector<ComputerPart> parts;

    int findPartIndex(int id) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].id == id) return i;
        }
        return -1;
    }

public:
    void addPart(int id, const std::string& name, const std::string& manufacturer) {
        if (findPartIndex(id) == -1) {
            parts.emplace_back(id, name, manufacturer);
        } else {
            std::cout << "Part with ID " << id << " already exists.\n";
        }
    }

    void deletePart(int id) {
        int index = findPartIndex(id);
        if (index != -1) {
            parts.erase(parts.begin() + index);
        } else {
            std::cout << "No part found with ID " << id << ".\n";
        }
    }

    void updatePart(int id, const std::string& name, const std::string& manufacturer) {
        int index = findPartIndex(id);
        if (index != -1) {
            parts[index].name = name;
            parts[index].manufacturer = manufacturer;
        } else {
            std::cout << "No part found with ID " << id << ".\n";
        }
    }

    void searchPart(int id) {
        int index = findPartIndex(id);
        if (index != -1) {
            std::cout << "ID: " << parts[index].id 
                      << ", Name: " << parts[index].name 
                      << ", Manufacturer: " << parts[index].manufacturer << "\n";
        } else {
            std::cout << "No part found with ID " << id << ".\n";
        }
    }

    void displayParts() {
        if (parts.empty()) {
            std::cout << "No parts available.\n";
        } else {
            for (const auto& part : parts) {
                std::cout << "ID: " << part.id 
                          << ", Name: " << part.name 
                          << ", Manufacturer: " << part.manufacturer << "\n";
            }
        }
    }
};

int main() {
    PartsManagementSystem system;

    system.addPart(1, "CPU", "Intel");
    system.addPart(2, "GPU", "NVIDIA");

    std::cout << "Parts list:\n";
    system.displayParts();

    system.updatePart(1, "CPU", "AMD");
    std::cout << "After update:\n";
    system.displayParts();

    system.searchPart(1);

    system.deletePart(2);
    std::cout << "After deletion:\n";
    system.displayParts();

    return 0;
}