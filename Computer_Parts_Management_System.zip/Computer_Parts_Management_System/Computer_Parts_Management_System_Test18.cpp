#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    std::string name;
    std::string country;

    Manufacturer(std::string n, std::string c) : name(n), country(c) {}
};

class ComputerPart {
public:
    std::string name;
    std::string type;
    float price;
    Manufacturer* manufacturer;

    ComputerPart(std::string n, std::string t, float p, Manufacturer* m)
        : name(n), type(t), price(p), manufacturer(m) {}
};

class PartsManager {
    std::vector<ComputerPart> parts;
    std::vector<Manufacturer> manufacturers;

public:
    void addManufacturer(std::string name, std::string country) {
        manufacturers.push_back(Manufacturer(name, country));
    }

    Manufacturer* findManufacturer(std::string name) {
        for (auto &man : manufacturers) {
            if (man.name == name) {
                return &man;
            }
        }
        return nullptr;
    }

    void addPart(std::string name, std::string type, float price, std::string manufacturerName) {
        Manufacturer* man = findManufacturer(manufacturerName);
        if (man != nullptr) {
            parts.push_back(ComputerPart(name, type, price, man));
        }
    }

    void deletePart(std::string name) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == name) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(std::string name, std::string newType, float newPrice, std::string newManufacturer) {
        for (auto &part : parts) {
            if (part.name == name) {
                part.type = newType;
                part.price = newPrice;
                Manufacturer* man = findManufacturer(newManufacturer);
                if (man != nullptr)
                    part.manufacturer = man;
                break;
            }
        }
    }

    ComputerPart* searchPart(std::string name) {
        for (auto &part : parts) {
            if (part.name == name) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto &part : parts) {
            std::cout << "Name: " << part.name << ", Type: " << part.type
                      << ", Price: " << part.price << ", Manufacturer: "
                      << part.manufacturer->name << ", Country: "
                      << part.manufacturer->country << std::endl;
        }
    }

    void displayManufacturers() {
        for (const auto &man : manufacturers) {
            std::cout << "Name: " << man.name << ", Country: " << man.country << std::endl;
        }
    }
};

int main() {
    PartsManager manager;
    manager.addManufacturer("Intel", "USA");
    manager.addManufacturer("AMD", "USA");
    manager.addPart("Core i7", "Processor", 320.0, "Intel");
    manager.addPart("Ryzen 5", "Processor", 220.0, "AMD");
    manager.displayParts();
    manager.updatePart("Core i7", "Processor", 310.0, "Intel");
    manager.displayParts();
    manager.deletePart("Ryzen 5");
    manager.displayParts();
    manager.displayManufacturers();
    return 0;
}