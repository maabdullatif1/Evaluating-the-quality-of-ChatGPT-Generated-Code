#include <iostream>
#include <vector>
#include <string>

struct Manufacturer {
    std::string name;
    std::string address;
};

struct ComputerPart {
    std::string name;
    std::string type;
    Manufacturer manufacturer;
};

class PartsManagementSystem {
    std::vector<ComputerPart> parts;
public:
    void addPart(const std::string& name, const std::string& type, const std::string& manufacturerName, const std::string& manufacturerAddress) {
        Manufacturer manufacturer = {manufacturerName, manufacturerAddress};
        ComputerPart part = {name, type, manufacturer};
        parts.push_back(part);
    }

    void deletePart(const std::string& name) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == name) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(const std::string& name, const std::string& newName, const std::string& newType, const std::string& newManufacturerName, const std::string& newManufacturerAddress) {
        for (auto& part : parts) {
            if (part.name == name) {
                part.name = newName;
                part.type = newType;
                part.manufacturer.name = newManufacturerName;
                part.manufacturer.address = newManufacturerAddress;
                break;
            }
        }
    }

    void searchPart(const std::string& name) {
        for (const auto& part : parts) {
            if (part.name == name) {
                std::cout << "Part found: " << part.name << ", Type: " << part.type << ", Manufacturer: " << part.manufacturer.name << ", Address: " << part.manufacturer.address << std::endl;
                return;
            }
        }
        std::cout << "Part not found." << std::endl;
    }

    void displayAllParts() {
        for (const auto& part : parts) {
            std::cout << "Part: " << part.name << ", Type: " << part.type << ", Manufacturer: " << part.manufacturer.name << ", Address: " << part.manufacturer.address << std::endl;
        }
    }
};

int main() {
    PartsManagementSystem system;
    system.addPart("CPU", "Processor", "Intel", "Santa Clara");
    system.addPart("GPU", "Graphics Card", "NVIDIA", "Santa Clara");
    system.displayAllParts();
    system.searchPart("CPU");
    system.updatePart("CPU", "CPU", "Processor", "AMD", "Austin");
    system.displayAllParts();
    system.deletePart("GPU");
    system.displayAllParts();
    return 0;
}