#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string partName;
    std::string manufacturer;
    double price;

    ComputerPart(const std::string& pn, const std::string& manu, double p)
        : partName(pn), manufacturer(manu), price(p) {}
};

class PartsManagementSystem {
private:
    std::vector<ComputerPart> parts;

    int findPartIndex(const std::string& partName) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].partName == partName)
                return i;
        }
        return -1;
    }

public:
    void addPart(const std::string& partName, const std::string& manufacturer, double price) {
        if (findPartIndex(partName) == -1) {
            parts.push_back(ComputerPart(partName, manufacturer, price));
        } else {
            std::cout << "Part already exists.\n";
        }
    }

    void deletePart(const std::string& partName) {
        int index = findPartIndex(partName);
        if (index != -1) {
            parts.erase(parts.begin() + index);
        } else {
            std::cout << "Part not found.\n";
        }
    }

    void updatePart(const std::string& partName, const std::string& manufacturer, double price) {
        int index = findPartIndex(partName);
        if (index != -1) {
            parts[index].manufacturer = manufacturer;
            parts[index].price = price;
        } else {
            std::cout << "Part not found.\n";
        }
    }

    void searchPart(const std::string& partName) {
        int index = findPartIndex(partName);
        if (index != -1) {
            std::cout << "Part Name: " << parts[index].partName
                      << ", Manufacturer: " << parts[index].manufacturer
                      << ", Price: $" << parts[index].price << "\n";
        } else {
            std::cout << "Part not found.\n";
        }
    }

    void displayAll() {
        if (parts.empty()) {
            std::cout << "No parts available.\n";
        } else {
            for (const auto& part : parts) {
                std::cout << "Part Name: " << part.partName
                          << ", Manufacturer: " << part.manufacturer
                          << ", Price: $" << part.price << "\n";
            }
        }
    }
};

int main() {
    PartsManagementSystem pms;
    pms.addPart("CPU", "Intel", 300.0);
    pms.addPart("GPU", "NVIDIA", 500.0);
    pms.displayAll();
    pms.searchPart("CPU");
    pms.updatePart("CPU", "AMD", 250.0);
    pms.searchPart("CPU");
    pms.deletePart("GPU");
    pms.displayAll();
    return 0;
}