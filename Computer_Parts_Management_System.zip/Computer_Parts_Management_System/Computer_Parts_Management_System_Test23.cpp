#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    int id;
    std::string name;
    std::string country;
    
    Manufacturer(int id, std::string name, std::string country)
        : id(id), name(name), country(country) {}
};

class ComputerPart {
public:
    int id;
    std::string name;
    std::string type;
    Manufacturer manufacturer;
    
    ComputerPart(int id, std::string name, std::string type, Manufacturer manufacturer)
        : id(id), name(name), type(type), manufacturer(manufacturer) {}
};

class PartsManagementSystem {
    std::vector<ComputerPart> parts;
    std::vector<Manufacturer> manufacturers;
    
    Manufacturer* findManufacturerById(int mfgId) {
        for(auto &mfg : manufacturers)
            if(mfg.id == mfgId)
                return &mfg;
        return nullptr;
    }

    ComputerPart* findPartById(int partId) {
        for(auto &part : parts)
            if(part.id == partId)
                return &part;
        return nullptr;
    }

public:
    void addManufacturer(int id, std::string name, std::string country) {
        manufacturers.push_back(Manufacturer(id, name, country));
    }

    void addPart(int id, std::string name, std::string type, int manufacturerId) {
        Manufacturer* mfg = findManufacturerById(manufacturerId);
        if(mfg != nullptr)
            parts.push_back(ComputerPart(id, name, type, *mfg));
    }

    void deletePart(int id) {
        for(auto it = parts.begin(); it != parts.end(); ++it) {
            if(it->id == id) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(int id, std::string name, std::string type, int manufacturerId) {
        ComputerPart* part = findPartById(id);
        if(part) {
            part->name = name;
            part->type = type;
            Manufacturer* mfg = findManufacturerById(manufacturerId);
            if(mfg) 
                part->manufacturer = *mfg;
        }
    }
    
    void searchPart(int id) {
        ComputerPart* part = findPartById(id);
        if(part) {
            std::cout << "ID: " << part->id << ", Name: " << part->name 
                      << ", Type: " << part->type 
                      << ", Manufacturer: " << part->manufacturer.name << "\n";
        } else {
            std::cout << "Part not found.\n";
        }
    }

    void displayParts() {
        for(auto &part : parts) {
            std::cout << "ID: " << part.id << ", Name: " << part.name 
                      << ", Type: " << part.type 
                      << ", Manufacturer: " << part.manufacturer.name << "\n";
        }
    }
};

int main() {
    PartsManagementSystem system;
    system.addManufacturer(1, "Manufacturer A", "USA");
    system.addManufacturer(2, "Manufacturer B", "Germany");

    system.addPart(1, "CPU", "Processor", 1);
    system.addPart(2, "GPU", "Graphics Card", 2);

    system.displayParts();
    system.updatePart(1, "CPU X", "Processor", 2);
    system.searchPart(1);
    system.deletePart(2);
    system.displayParts();

    return 0;
}