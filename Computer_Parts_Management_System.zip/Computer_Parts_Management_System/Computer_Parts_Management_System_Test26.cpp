#include <iostream>
#include <vector>
#include <string>

class Part {
public:
    int id;
    std::string name;
    std::string manufacturer;

    Part(int i, std::string n, std::string m)
        : id(i), name(n), manufacturer(m) {}
};

class ManagementSystem {
private:
    std::vector<Part> parts;

    int findPartIndex(int id) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].id == id) return i;
        }
        return -1;
    }

public:
    void addPart(int id, std::string name, std::string manufacturer) {
        parts.push_back(Part(id, name, manufacturer));
    }

    void deletePart(int id) {
        int index = findPartIndex(id);
        if (index != -1) {
            parts.erase(parts.begin() + index);
        }
    }

    void updatePart(int id, std::string name, std::string manufacturer) {
        int index = findPartIndex(id);
        if (index != -1) {
            parts[index].name = name;
            parts[index].manufacturer = manufacturer;
        }
    }

    Part searchPart(int id) {
        int index = findPartIndex(id);
        if (index != -1) {
            return parts[index];
        }
        return Part(-1, "", "");
    }

    void displayParts() {
        for (size_t i = 0; i < parts.size(); ++i) {
            std::cout << "ID: " << parts[i].id
                      << ", Name: " << parts[i].name
                      << ", Manufacturer: " << parts[i].manufacturer
                      << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPart(1, "CPU", "Intel");
    system.addPart(2, "GPU", "NVIDIA");
    system.displayParts();
    system.updatePart(1, "CPU", "AMD");
    system.displayParts();
    system.deletePart(2);
    system.displayParts();
    Part found = system.searchPart(1);
    if (found.id != -1) {
        std::cout << "Found part: ID: " << found.id
                  << ", Name: " << found.name
                  << ", Manufacturer: " << found.manufacturer
                  << std::endl;
    }

    return 0;
}