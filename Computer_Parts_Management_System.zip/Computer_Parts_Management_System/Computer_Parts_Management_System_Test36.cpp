#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string name;
    std::string manufacturer;
    std::string partNumber;

    ComputerPart(std::string n, std::string m, std::string pn)
        : name(n), manufacturer(m), partNumber(pn) {}
};

class PartsManagementSystem {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(const std::string& name, const std::string& manufacturer, const std::string& partNumber) {
        parts.emplace_back(name, manufacturer, partNumber);
    }

    bool deletePart(const std::string& partNumber) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partNumber == partNumber) {
                parts.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updatePart(const std::string& partNumber, const std::string& newName, const std::string& newManufacturer) {
        for (auto& part : parts) {
            if (part.partNumber == partNumber) {
                part.name = newName;
                part.manufacturer = newManufacturer;
                return true;
            }
        }
        return false;
    }

    ComputerPart* searchPart(const std::string& partNumber) {
        for (auto& part : parts) {
            if (part.partNumber == partNumber) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "Name: " << part.name << ", Manufacturer: " << part.manufacturer
                      << ", Part Number: " << part.partNumber << "\n";
        }
    }
};

int main() {
    PartsManagementSystem pms;
    int choice;
    std::string name, manufacturer, partNumber;

    while (true) {
        std::cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\n";
        std::cout << "Enter choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter name, manufacturer, part number: ";
                std::cin >> name >> manufacturer >> partNumber;
                pms.addPart(name, manufacturer, partNumber);
                break;
            case 2:
                std::cout << "Enter part number to delete: ";
                std::cin >> partNumber;
                if (pms.deletePart(partNumber))
                    std::cout << "Deleted successfully.\n";
                else
                    std::cout << "Part not found.\n";
                break;
            case 3:
                std::cout << "Enter part number to update: ";
                std::cin >> partNumber;
                std::cout << "Enter new name and manufacturer: ";
                std::cin >> name >> manufacturer;
                if (pms.updatePart(partNumber, name, manufacturer))
                    std::cout << "Updated successfully.\n";
                else
                    std::cout << "Part not found.\n";
                break;
            case 4:
                std::cout << "Enter part number to search: ";
                std::cin >> partNumber;
                {
                    ComputerPart* part = pms.searchPart(partNumber);
                    if (part)
                        std::cout << "Name: " << part->name << ", Manufacturer: " << part->manufacturer
                                  << ", Part Number: " << part->partNumber << "\n";
                    else
                        std::cout << "Part not found.\n";
                }
                break;
            case 5:
                pms.displayParts();
                break;
            case 6:
                return 0;
            default:
                std::cout << "Invalid choice.\n";
                break;
        }
    }
    return 0;
}