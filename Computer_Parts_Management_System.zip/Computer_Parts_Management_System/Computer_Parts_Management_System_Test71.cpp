#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Part {
public:
    string name;
    string manufacturer;
    float price;

    Part(string n, string m, float p) : name(n), manufacturer(m), price(p) {}
};

class PartsManager {
    vector<Part> parts;

    int findPartIndex(const string& name) {
        for (int i = 0; i < parts.size(); ++i)
            if (parts[i].name == name)
                return i;
        return -1;
    }

public:
    void addPart(const string& name, const string& manufacturer, float price) {
        parts.push_back(Part(name, manufacturer, price));
    }

    void deletePart(const string& name) {
        int index = findPartIndex(name);
        if (index != -1)
            parts.erase(parts.begin() + index);
    }

    void updatePart(const string& name, const string& newManufacturer, float newPrice) {
        int index = findPartIndex(name);
        if (index != -1) {
            parts[index].manufacturer = newManufacturer;
            parts[index].price = newPrice;
        }
    }

    void searchPart(const string& name) {
        int index = findPartIndex(name);
        if (index != -1) {
            cout << "Part found: " << parts[index].name << ", Manufacturer: " << parts[index].manufacturer << ", Price: " << parts[index].price << "\n";
        } else {
            cout << "Part not found.\n";
        }
    }

    void displayParts() {
        if (parts.empty()) {
            cout << "No parts available.\n";
            return;
        }
        for (const auto& part : parts)
            cout << "Name: " << part.name << ", Manufacturer: " << part.manufacturer << ", Price: " << part.price << "\n";
    }
};

int main() {
    PartsManager manager;
    int choice;
    string name, manufacturer;
    float price;

    do {
        cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\n";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter name, manufacturer, price: ";
                cin >> name >> manufacturer >> price;
                manager.addPart(name, manufacturer, price);
                break;
            case 2:
                cout << "Enter name: ";
                cin >> name;
                manager.deletePart(name);
                break;
            case 3:
                cout << "Enter name, new manufacturer, new price: ";
                cin >> name >> manufacturer >> price;
                manager.updatePart(name, manufacturer, price);
                break;
            case 4:
                cout << "Enter name: ";
                cin >> name;
                manager.searchPart(name);
                break;
            case 5:
                manager.displayParts();
                break;
            case 6:
                break;
            default:
                cout << "Invalid choice.\n";
        }
    } while (choice != 6);

    return 0;
}