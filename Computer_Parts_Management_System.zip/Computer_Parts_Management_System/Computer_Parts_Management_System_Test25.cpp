#include <iostream>
#include <vector>
#include <string>

using namespace std;

class ComputerPart {
public:
    int id;
    string name;
    string manufacturer;
    double price;

    ComputerPart(int id, const string& name, const string& manufacturer, double price)
        : id(id), name(name), manufacturer(manufacturer), price(price) {}
};

class PartsManager {
private:
    vector<ComputerPart> parts;
    int nextId;

public:
    PartsManager() : nextId(1) {}

    void addPart(const string& name, const string& manufacturer, double price) {
        parts.push_back(ComputerPart(nextId++, name, manufacturer, price));
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->id == id) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(int id, const string& name, const string& manufacturer, double price) {
        for (auto& part : parts) {
            if (part.id == id) {
                part.name = name;
                part.manufacturer = manufacturer;
                part.price = price;
                break;
            }
        }
    }

    void searchPart(const string& name) {
        for (const auto& part : parts) {
            if (part.name == name) {
                cout << "ID: " << part.id << ", Name: " << part.name << ", Manufacturer: " << part.manufacturer << ", Price: $" << part.price << endl;
            }
        }
    }

    void displayParts() {
        for (const auto& part : parts) {
            cout << "ID: " << part.id << ", Name: " << part.name << ", Manufacturer: " << part.manufacturer << ", Price: $" << part.price << endl;
        }
    }
};

int main() {
    PartsManager manager;

    manager.addPart("CPU", "Intel", 299.99);
    manager.addPart("GPU", "NVIDIA", 499.99);
    manager.displayParts();

    manager.updatePart(1, "CPU", "AMD", 279.99);
    manager.displayParts();

    manager.searchPart("GPU");
    manager.deletePart(1);
    manager.displayParts();

    return 0;
}