#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    int id;
    std::string name;

    Manufacturer(int mid, std::string mname) : id(mid), name(mname) {}
};

class Part {
public:
    int id;
    std::string name;
    int manufacturerId;

    Part(int pid, std::string pname, int mid) : id(pid), name(pname), manufacturerId(mid) {}
};

class Inventory {
    std::vector<Manufacturer> manufacturers;
    std::vector<Part> parts;

public:
    void addManufacturer(int id, std::string name) {
        manufacturers.emplace_back(id, name);
    }

    void deleteManufacturer(int id) {
        for (auto it = manufacturers.begin(); it != manufacturers.end(); ++it) {
            if (it->id == id) {
                manufacturers.erase(it);
                break;
            }
        }
    }

    void updateManufacturer(int id, std::string name) {
        for (auto &manufacturer : manufacturers) {
            if (manufacturer.id == id) {
                manufacturer.name = name;
            }
        }
    }

    void addPart(int id, std::string name, int manufacturerId) {
        parts.emplace_back(id, name, manufacturerId);
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->id == id) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(int id, std::string name, int manufacturerId) {
        for (auto &part : parts) {
            if (part.id == id) {
                part.name = name;
                part.manufacturerId = manufacturerId;
            }
        }
    }

    void searchPart(int id) {
        for (const auto &part : parts) {
            if (part.id == id) {
                std::cout << "Part ID: " << part.id 
                          << ", Part Name: " << part.name 
                          << ", Manufacturer ID: " << part.manufacturerId 
                          << "\n";
                return;
            }
        }
        std::cout << "Part not found.\n";
    }

    void searchManufacturer(int id) {
        for (const auto &manufacturer : manufacturers) {
            if (manufacturer.id == id) {
                std::cout << "Manufacturer ID: " << manufacturer.id 
                          << ", Manufacturer Name: " << manufacturer.name 
                          << "\n";
                return;
            }
        }
        std::cout << "Manufacturer not found.\n";
    }

    void display() {
        std::cout << "Manufacturers:\n";
        for (const auto &manufacturer : manufacturers) {
            std::cout << "ID: " << manufacturer.id 
                      << ", Name: " << manufacturer.name 
                      << "\n";
        }

        std::cout << "\nParts:\n";
        for (const auto &part : parts) {
            std::cout << "ID: " << part.id 
                      << ", Name: " << part.name 
                      << ", Manufacturer ID: " << part.manufacturerId 
                      << "\n";
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addManufacturer(1, "Manufacturer A");
    inventory.addManufacturer(2, "Manufacturer B");
    
    inventory.addPart(101, "CPU", 1);
    inventory.addPart(102, "GPU", 2);
    
    inventory.display();

    inventory.updateManufacturer(1, "Manufacturer X");
    inventory.updatePart(101, "High-End CPU", 1);
    
    inventory.display();
    
    inventory.searchPart(101);
    inventory.searchManufacturer(2);

    inventory.deletePart(102);
    inventory.deleteManufacturer(2);

    inventory.display();

    return 0;
}