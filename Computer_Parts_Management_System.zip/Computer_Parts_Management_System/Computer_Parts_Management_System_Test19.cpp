#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string name;
    std::string manufacturer;
    int quantity;
    double price;

    ComputerPart(std::string n, std::string m, int q, double p) 
        : name(n), manufacturer(m), quantity(q), price(p) {}
};

class PartsInventory {
private:
    std::vector<ComputerPart> inventory;

public:
    void addPart(const std::string& name, const std::string& manufacturer, int quantity, double price) {
        inventory.push_back(ComputerPart(name, manufacturer, quantity, price));
    }

    void deletePart(const std::string& name) {
        for (auto it = inventory.begin(); it != inventory.end(); ++it) {
            if (it->name == name) {
                inventory.erase(it);
                return;
            }
        }
    }
    
    void updatePart(const std::string& name, const std::string& manufacturer, int quantity, double price) {
        for (auto& part : inventory) {
            if (part.name == name) {
                part.manufacturer = manufacturer;
                part.quantity = quantity;
                part.price = price;
                return;
            }
        }
    }

    void searchPart(const std::string& name) {
        for (const auto& part : inventory) {
            if (part.name == name) {
                std::cout << "Name: " << part.name << ", Manufacturer: " << part.manufacturer 
                          << ", Quantity: " << part.quantity << ", Price: " << part.price << "\n";
                return;
            }
        }
        std::cout << "Part not found.\n";
    }

    void displayInventory() const {
        if (inventory.empty()) {
            std::cout << "Inventory is empty.\n";
            return;
        }
        for (const auto& part : inventory) {
            std::cout << "Name: " << part.name << ", Manufacturer: " << part.manufacturer 
                      << ", Quantity: " << part.quantity << ", Price: " << part.price << "\n";
        }
    }
};

int main() {
    PartsInventory inventory;
    inventory.addPart("CPU", "Intel", 50, 200.00);
    inventory.addPart("GPU", "NVIDIA", 20, 499.99);
    inventory.displayInventory();
    inventory.searchPart("CPU");
    inventory.updatePart("GPU", "NVIDIA", 15, 479.99);
    inventory.searchPart("GPU");
    inventory.deletePart("CPU");
    inventory.displayInventory();
    return 0;
}