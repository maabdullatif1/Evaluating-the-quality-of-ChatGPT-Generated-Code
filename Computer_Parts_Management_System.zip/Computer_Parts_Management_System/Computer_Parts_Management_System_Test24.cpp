#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Part {
public:
    int id;
    string name;
    string manufacturer;
    double price;
    
    Part(int id, string name, string manufacturer, double price) 
        : id(id), name(name), manufacturer(manufacturer), price(price) {}
};

class PartManager {
private:
    vector<Part> parts;
    int nextId = 1;

public:
    void addPart(string name, string manufacturer, double price) {
        parts.push_back(Part(nextId++, name, manufacturer, price));
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->id == id) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(int id, string name, string manufacturer, double price) {
        for (auto &part : parts) {
            if (part.id == id) {
                part.name = name;
                part.manufacturer = manufacturer;
                part.price = price;
                break;
            }
        }
    }

    Part* searchPart(int id) {
        for (auto &part : parts) {
            if (part.id == id) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto &part : parts) {
            cout << "ID: " << part.id << ", Name: " << part.name 
                 << ", Manufacturer: " << part.manufacturer 
                 << ", Price: $" << part.price << endl;
        }
    }
};

int main() {
    PartManager manager;
    int choice;
    while (true) {
        cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\nChoice: ";
        cin >> choice;

        if (choice == 1) {
            string name, manufacturer;
            double price;
            cout << "Enter name: ";
            cin >> name;
            cout << "Enter manufacturer: ";
            cin >> manufacturer;
            cout << "Enter price: ";
            cin >> price;
            manager.addPart(name, manufacturer, price);
        } else if (choice == 2) {
            int id;
            cout << "Enter ID to delete: ";
            cin >> id;
            manager.deletePart(id);
        } else if (choice == 3) {
            int id;
            string name, manufacturer;
            double price;
            cout << "Enter ID to update: ";
            cin >> id;
            cout << "Enter new name: ";
            cin >> name;
            cout << "Enter new manufacturer: ";
            cin >> manufacturer;
            cout << "Enter new price: ";
            cin >> price;
            manager.updatePart(id, name, manufacturer, price);
        } else if (choice == 4) {
            int id;
            cout << "Enter ID to search: ";
            cin >> id;
            Part* part = manager.searchPart(id);
            if (part) {
                cout << "ID: " << part->id << ", Name: " << part->name 
                     << ", Manufacturer: " << part->manufacturer 
                     << ", Price: $" << part->price << endl;
            } else {
                cout << "Part not found." << endl;
            }
        } else if (choice == 5) {
            manager.displayParts();
        } else if (choice == 6) {
            break;
        }
    }
    return 0;
}