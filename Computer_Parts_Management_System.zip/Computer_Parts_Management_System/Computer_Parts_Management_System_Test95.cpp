#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Manufacturer {
    string name;
    string country;
};

struct ComputerPart {
    string name;
    string type;
    Manufacturer manufacturer;
    double price;
};

class PartsManager {
    vector<ComputerPart> parts;
public:
    void addPart(const string& name, const string& type, const string& manufacturerName, const string& country, double price) {
        Manufacturer manufacturer = {manufacturerName, country};
        ComputerPart part = {name, type, manufacturer, price};
        parts.push_back(part);
    }

    void deletePart(const string& name) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == name) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(const string& name, const string& newName, const string& newType, const string& newManufacturerName, const string& newCountry, double newPrice) {
        for (auto& part : parts) {
            if (part.name == name) {
                part.name = newName;
                part.type = newType;
                part.manufacturer.name = newManufacturerName;
                part.manufacturer.country = newCountry;
                part.price = newPrice;
                break;
            }
        }
    }

    void searchPart(const string& name) const {
        for (const auto& part : parts) {
            if (part.name == name) {
                cout << "Found part: " << part.name << ", Type: " << part.type
                     << ", Manufacturer: " << part.manufacturer.name 
                     << ", Country: " << part.manufacturer.country 
                     << ", Price: $" << part.price << endl;
                return;
            }
        }
        cout << "Part not found" << endl;
    }

    void displayParts() const {
        if (parts.empty()) {
            cout << "No parts available" << endl;
            return;
        }
        for (const auto& part : parts) {
            cout << "Name: " << part.name << ", Type: " << part.type
                 << ", Manufacturer: " << part.manufacturer.name 
                 << ", Country: " << part.manufacturer.country 
                 << ", Price: $" << part.price << endl;
        }
    }
};

int main() {
    PartsManager manager;
    manager.addPart("GTX 3080", "GPU", "NVIDIA", "USA", 699.99);
    manager.addPart("Ryzen 9 5900X", "CPU", "AMD", "USA", 549.99);
    manager.displayParts();
    manager.searchPart("GTX 3080");
    manager.updatePart("GTX 3080", "RTX 3080", "GPU", "NVIDIA", "USA", 699.99);
    manager.displayParts();
    manager.deletePart("RTX 3080");
    manager.displayParts();
    return 0;
}