#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    ComputerPart(std::string partName, std::string manufacturer, double price) 
        : name(partName), manufacturerName(manufacturer), price(price) {}

    std::string getName() const { return name; }
    std::string getManufacturer() const { return manufacturerName; }
    double getPrice() const { return price; }
    
    void setName(std::string newName) { name = newName; }
    void setManufacturer(std::string newManufacturer) { manufacturerName = newManufacturer; }
    void setPrice(double newPrice) { price = newPrice; }

private:
    std::string name;
    std::string manufacturerName;
    double price;
};

class PartsManager {
public:
    void addPart(const ComputerPart& part) {
        parts.push_back(part);
    }

    void deletePart(const std::string& partName) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->getName() == partName) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(const std::string& partName, const std::string& newManufacturer, double newPrice) {
        for (auto& part : parts) {
            if (part.getName() == partName) {
                part.setManufacturer(newManufacturer);
                part.setPrice(newPrice);
                break;
            }
        }
    }

    ComputerPart* searchPart(const std::string& partName) {
        for (auto& part : parts) {
            if (part.getName() == partName) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() const {
        for (const auto& part : parts) {
            std::cout << "Part Name: " << part.getName()
                      << ", Manufacturer: " << part.getManufacturer()
                      << ", Price: " << part.getPrice() 
                      << std::endl;
        }
    }

private:
    std::vector<ComputerPart> parts;
};

int main() {
    PartsManager manager;
    manager.addPart(ComputerPart("CPU", "Intel", 250.00));
    manager.addPart(ComputerPart("GPU", "NVIDIA", 450.00));

    manager.displayParts();

    manager.updatePart("CPU", "AMD", 230.00);
    
    manager.displayParts();

    ComputerPart* part = manager.searchPart("GPU");
    if (part) {
        std::cout << "Found Part: " << part->getName() << std::endl;
    }

    manager.deletePart("GPU");
    manager.displayParts();

    return 0;
}