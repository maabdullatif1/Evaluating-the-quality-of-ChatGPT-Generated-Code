#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    int partID;
    std::string partName;
    std::string manufacturer;

    ComputerPart(int id, std::string name, std::string manu)
        : partID(id), partName(name), manufacturer(manu) {}
};

class PartsManager {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(int id, std::string name, std::string manufacturer) {
        parts.push_back(ComputerPart(id, name, manufacturer));
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partID == id) {
                parts.erase(it);
                return;
            }
        }
    }

    void updatePart(int id, std::string newName, std::string newManufacturer) {
        for (auto &part : parts) {
            if (part.partID == id) {
                part.partName = newName;
                part.manufacturer = newManufacturer;
                return;
            }
        }
    }

    void searchPart(int id) {
        for (auto &part : parts) {
            if (part.partID == id) {
                std::cout << "Part ID: " << part.partID << ", Name: " << part.partName
                          << ", Manufacturer: " << part.manufacturer << std::endl;
                return;
            }
        }
        std::cout << "Part not found." << std::endl;
    }

    void displayParts() {
        for (auto &part : parts) {
            std::cout << "Part ID: " << part.partID << ", Name: " << part.partName
                      << ", Manufacturer: " << part.manufacturer << std::endl;
        }
    }
};

int main() {
    PartsManager manager;
    manager.addPart(1, "CPU", "Intel");
    manager.addPart(2, "GPU", "NVIDIA");
    manager.displayParts();
    manager.searchPart(1);
    manager.updatePart(1, "Processor", "Intel");
    manager.displayParts();
    manager.deletePart(2);
    manager.displayParts();
    return 0;
}