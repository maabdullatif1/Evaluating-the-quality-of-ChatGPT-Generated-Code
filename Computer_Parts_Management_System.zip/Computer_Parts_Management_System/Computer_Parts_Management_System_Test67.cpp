#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    std::string name;
    std::string country;

    Manufacturer(const std::string& name, const std::string& country)
        : name(name), country(country) {}
};

class ComputerPart {
public:
    std::string name;
    std::string type;
    Manufacturer manufacturer;

    ComputerPart(const std::string& name, const std::string& type, const Manufacturer& manufacturer)
        : name(name), type(type), manufacturer(manufacturer) {}
};

class PartsManager {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(const ComputerPart& part) {
        parts.push_back(part);
    }

    void deletePart(const std::string& name) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == name) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(const std::string& name, const ComputerPart& updatedPart) {
        for (auto& part : parts) {
            if (part.name == name) {
                part = updatedPart;
                break;
            }
        }
    }

    void searchPart(const std::string& name) const {
        for (const auto& part : parts) {
            if (part.name == name) {
                std::cout << "Name: " << part.name << ", Type: " << part.type
                          << ", Manufacturer: " << part.manufacturer.name
                          << ", Country: " << part.manufacturer.country << "\n";
                return;
            }
        }
        std::cout << "Part not found\n";
    }

    void displayParts() const {
        for (const auto& part : parts) {
            std::cout << "Name: " << part.name << ", Type: " << part.type
                      << ", Manufacturer: " << part.manufacturer.name
                      << ", Country: " << part.manufacturer.country << "\n";
        }
    }
};

int main() {
    PartsManager manager;
    Manufacturer m1("Intel", "USA");
    Manufacturer m2("AMD", "USA");
    manager.addPart(ComputerPart("i7-9700K", "CPU", m1));
    manager.addPart(ComputerPart("Ryzen 7 3700X", "CPU", m2));
    manager.displayParts();
    manager.searchPart("Ryzen 7 3700X");
    manager.updatePart("i7-9700K", ComputerPart("i9-9900K", "CPU", m1));
    manager.deletePart("Ryzen 7 3700X");
    manager.displayParts();
    return 0;
}