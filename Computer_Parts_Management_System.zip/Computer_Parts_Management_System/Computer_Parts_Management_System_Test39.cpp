#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Manufacturer {
public:
    string name;
    string country;

    Manufacturer(string name, string country) : name(name), country(country) {}
};

class ComputerPart {
public:
    string partName;
    double price;
    Manufacturer manufacturer;

    ComputerPart(string partName, double price, Manufacturer manufacturer)
        : partName(partName), price(price), manufacturer(manufacturer) {}
};

class PartsManagementSystem {
    vector<ComputerPart> parts;

public:
    void addPart(string partName, double price, string manufacturerName, string manufacturerCountry) {
        Manufacturer manufacturer(manufacturerName, manufacturerCountry);
        ComputerPart part(partName, price, manufacturer);
        parts.push_back(part);
    }

    void deletePart(string partName) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partName == partName) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(string partName, double newPrice, string newManufacturerName, string newManufacturerCountry) {
        for (auto& part : parts) {
            if (part.partName == partName) {
                part.price = newPrice;
                part.manufacturer.name = newManufacturerName;
                part.manufacturer.country = newManufacturerCountry;
                break;
            }
        }
    }

    void searchPart(string partName) {
        for (auto& part : parts) {
            if (part.partName == partName) {
                cout << "Part Name: " << part.partName << ", Price: " << part.price 
                     << ", Manufacturer: " << part.manufacturer.name 
                     << ", Country: " << part.manufacturer.country << endl;
            }
        }
    }

    void displayParts() {
        for (auto& part : parts) {
            cout << "Part Name: " << part.partName << ", Price: " << part.price 
                 << ", Manufacturer: " << part.manufacturer.name 
                 << ", Country: " << part.manufacturer.country << endl;
        }
    }
};

int main() {
    PartsManagementSystem system;
    system.addPart("CPU", 250.0, "Intel", "USA");
    system.addPart("GPU", 500.0, "NVIDIA", "USA");
    system.displayParts();
    system.searchPart("GPU");
    system.updatePart("GPU", 450.0, "NVIDIA", "USA");
    system.searchPart("GPU");
    system.deletePart("CPU");
    system.displayParts();
    return 0;
}