#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    int id;
    std::string name;
    std::string manufacturer;

    ComputerPart(int i, std::string n, std::string m) : id(i), name(n), manufacturer(m) {}
};

class ManagementSystem {
private:
    std::vector<ComputerPart> parts;
    int nextId = 1;

    int findIndexById(int id) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addPart(std::string name, std::string manufacturer) {
        parts.push_back(ComputerPart(nextId++, name, manufacturer));
    }

    void deletePart(int id) {
        int index = findIndexById(id);
        if (index != -1) {
            parts.erase(parts.begin() + index);
        }
    }

    void updatePart(int id, std::string name, std::string manufacturer) {
        int index = findIndexById(id);
        if (index != -1) {
            parts[index].name = name;
            parts[index].manufacturer = manufacturer;
        }
    }

    ComputerPart* searchPart(int id) {
        int index = findIndexById(id);
        if (index != -1) {
            return &parts[index];
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "ID: " << part.id << ", Name: " << part.name 
                      << ", Manufacturer: " << part.manufacturer << "\n";
        }
    }
};

int main() {
    ManagementSystem system;
    int choice, id;
    std::string name, manufacturer;

    while (true) {
        std::cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\n";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter part name: ";
                std::cin >> name;
                std::cout << "Enter manufacturer: ";
                std::cin >> manufacturer;
                system.addPart(name, manufacturer);
                break;
            case 2:
                std::cout << "Enter part ID to delete: ";
                std::cin >> id;
                system.deletePart(id);
                break;
            case 3:
                std::cout << "Enter part ID to update: ";
                std::cin >> id;
                std::cout << "Enter new part name: ";
                std::cin >> name;
                std::cout << "Enter new manufacturer: ";
                std::cin >> manufacturer;
                system.updatePart(id, name, manufacturer);
                break;
            case 4:
                std::cout << "Enter part ID to search: ";
                std::cin >> id;
                {
                    ComputerPart* part = system.searchPart(id);
                    if (part) {
                        std::cout << "Found - ID: " << part->id << ", Name: " << part->name 
                                  << ", Manufacturer: " << part->manufacturer << "\n";
                    } else {
                        std::cout << "Part not found.\n";
                    }
                }
                break;
            case 5:
                system.displayParts();
                break;
            case 6:
                return 0;
            default:
                std::cout << "Invalid choice.\n";
        }
    }
}