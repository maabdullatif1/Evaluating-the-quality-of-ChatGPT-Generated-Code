#include <iostream>
#include <string>
#include <vector>

class Manufacturer {
public:
    std::string name;
    std::string address;

    Manufacturer(std::string n, std::string a) : name(n), address(a) {}
};

class ComputerPart {
public:
    std::string name;
    std::string type;
    Manufacturer manufacturer;

    ComputerPart(std::string n, std::string t, Manufacturer m) : name(n), type(t), manufacturer(m) {}
};

class PartsManagementSystem {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(std::string partName, std::string partType, std::string manufName, std::string manufAddress) {
        Manufacturer manuf(manufName, manufAddress);
        ComputerPart part(partName, partType, manuf);
        parts.push_back(part);
    }

    void deletePart(std::string partName) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == partName) {
                parts.erase(it);
                return;
            }
        }
    }

    void updatePart(std::string partName, std::string newType) {
        for (auto& part : parts) {
            if (part.name == partName) {
                part.type = newType;
                return;
            }
        }
    }

    void searchPart(std::string partName) {
        for (const auto& part : parts) {
            if (part.name == partName) {
                std::cout << "Part found: " << part.name << ", Type: " << part.type
                          << ", Manufacturer: " << part.manufacturer.name
                          << ", Address: " << part.manufacturer.address << std::endl;
                return;
            }
        }
        std::cout << "Part not found" << std::endl;
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "Name: " << part.name << ", Type: " << part.type
                      << ", Manufacturer: " << part.manufacturer.name
                      << ", Address: " << part.manufacturer.address << std::endl;
        }
    }
};

int main() {
    PartsManagementSystem pms;
    char choice;
    std::string name, type, manufName, manufAddress;

    do {
        std::cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\n";
        std::cin >> choice;

        switch (choice) {
            case '1':
                std::cout << "Enter part name: ";
                std::cin >> name;
                std::cout << "Enter part type: ";
                std::cin >> type;
                std::cout << "Enter manufacturer name: ";
                std::cin >> manufName;
                std::cout << "Enter manufacturer address: ";
                std::cin >> manufAddress;
                pms.addPart(name, type, manufName, manufAddress);
                break;
            case '2':
                std::cout << "Enter part name to delete: ";
                std::cin >> name;
                pms.deletePart(name);
                break;
            case '3':
                std::cout << "Enter part name to update: ";
                std::cin >> name;
                std::cout << "Enter new type: ";
                std::cin >> type;
                pms.updatePart(name, type);
                break;
            case '4':
                std::cout << "Enter part name to search: ";
                std::cin >> name;
                pms.searchPart(name);
                break;
            case '5':
                pms.displayParts();
                break;
            case '6':
                break;
            default:
                std::cout << "Invalid choice" << std::endl;
        }
    } while (choice != '6');

    return 0;
}