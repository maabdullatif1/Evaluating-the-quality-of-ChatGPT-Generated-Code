#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string part_name;
    std::string manufacturer;
    double price;

    ComputerPart(std::string p_name, std::string manu, double pr) :
        part_name(p_name), manufacturer(manu), price(pr) {}
};

class PartsInventory {
private:
    std::vector<ComputerPart> inventory;

    int findPartIndex(const std::string &part_name) {
        for (size_t i = 0; i < inventory.size(); ++i) {
            if (inventory[i].part_name == part_name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addPart(const std::string &p_name, const std::string &manu, double pr) {
        inventory.push_back(ComputerPart(p_name, manu, pr));
    }

    void deletePart(const std::string &part_name) {
        int index = findPartIndex(part_name);
        if (index != -1) {
            inventory.erase(inventory.begin() + index);
        }
    }

    void updatePart(const std::string &part_name, const std::string &new_manu, double new_price) {
        int index = findPartIndex(part_name);
        if (index != -1) {
            inventory[index].manufacturer = new_manu;
            inventory[index].price = new_price;
        }
    }

    ComputerPart* searchPart(const std::string &part_name) {
        int index = findPartIndex(part_name);
        if (index != -1) {
            return &inventory[index];
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto &part : inventory) {
            std::cout << "Part Name: " << part.part_name
                      << ", Manufacturer: " << part.manufacturer
                      << ", Price: $" << part.price << std::endl;
        }
    }
};

int main() {
    PartsInventory inventory;
    int choice;
    std::string part_name, manufacturer;
    double price;

    do {
        std::cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter Part Name: ";
                std::cin >> part_name;
                std::cout << "Enter Manufacturer: ";
                std::cin >> manufacturer;
                std::cout << "Enter Price: ";
                std::cin >> price;
                inventory.addPart(part_name, manufacturer, price);
                break;
            case 2:
                std::cout << "Enter Part Name to Delete: ";
                std::cin >> part_name;
                inventory.deletePart(part_name);
                break;
            case 3:
                std::cout << "Enter Part Name to Update: ";
                std::cin >> part_name;
                std::cout << "Enter New Manufacturer: ";
                std::cin >> manufacturer;
                std::cout << "Enter New Price: ";
                std::cin >> price;
                inventory.updatePart(part_name, manufacturer, price);
                break;
            case 4:
                std::cout << "Enter Part Name to Search: ";
                std::cin >> part_name;
                ComputerPart* part = inventory.searchPart(part_name);
                if (part) {
                    std::cout << "Found - Part Name: " << part->part_name
                              << ", Manufacturer: " << part->manufacturer
                              << ", Price: $" << part->price << std::endl;
                } else {
                    std::cout << "Part not found." << std::endl;
                }
                break;
            case 5:
                inventory.displayParts();
                break;
            case 6:
                std::cout << "Exiting the system." << std::endl;
                break;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl;
        }
    } while (choice != 6);

    return 0;
}