#include <iostream>
#include <string>
#include <vector>

class Manufacturer {
public:
    std::string manufacturerName;

    Manufacturer(std::string name) : manufacturerName(name) {}
};

class Part {
public:
    std::string partName;
    std::string partNumber;
    Manufacturer manufacturer;

    Part(std::string name, std::string number, Manufacturer mfg) 
    : partName(name), partNumber(number), manufacturer(mfg) {}
};

class System {
private:
    std::vector<Part> parts;

public:
    void addPart(std::string partName, std::string partNumber, std::string manufacturerName) {
        Manufacturer manufacturer(manufacturerName);
        Part part(partName, partNumber, manufacturer);
        parts.push_back(part);
    }

    void deletePart(std::string partNumber) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partNumber == partNumber) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(std::string partNumber, std::string newName, std::string newManufacturerName) {
        for (auto &part : parts) {
            if (part.partNumber == partNumber) {
                part.partName = newName;
                part.manufacturer = Manufacturer(newManufacturerName);
                break;
            }
        }
    }

    Part* searchPart(std::string partNumber) {
        for (auto &part : parts) {
            if (part.partNumber == partNumber) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto &part : parts) {
            std::cout << "Part Name: " << part.partName << ", Part Number: " << part.partNumber 
                      << ", Manufacturer: " << part.manufacturer.manufacturerName << std::endl;
        }
    }
};

int main() {
    System sys;
    sys.addPart("CPU", "001", "Intel");
    sys.addPart("GPU", "002", "NVIDIA");
    sys.displayParts();
    sys.updatePart("002", "Graphics Card", "AMD");
    sys.displayParts();
    Part* part = sys.searchPart("001");
    if (part) {
        std::cout << "Found: " << part->partName << std::endl;
    }
    sys.deletePart("001");
    sys.displayParts();
    return 0;
}