#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string name;
    std::string manufacturer;
    double price;
    int stock;

    ComputerPart(std::string n, std::string m, double p, int s)
        : name(n), manufacturer(m), price(p), stock(s) {}
};

class InventoryManagement {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(std::string name, std::string manufacturer, double price, int stock) {
        parts.push_back(ComputerPart(name, manufacturer, price, stock));
    }

    void deletePart(std::string name) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == name) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(std::string name, std::string manufacturer, double price, int stock) {
        for (auto &part : parts) {
            if (part.name == name) {
                part.manufacturer = manufacturer;
                part.price = price;
                part.stock = stock;
                break;
            }
        }
    }

    ComputerPart* searchPart(std::string name) {
        for (auto &part : parts) {
            if (part.name == name) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto &part : parts) {
            std::cout << "Name: " << part.name
                      << ", Manufacturer: " << part.manufacturer
                      << ", Price: " << part.price
                      << ", Stock: " << part.stock << std::endl;
        }
    }
};

int main() {
    InventoryManagement inventory;

    inventory.addPart("CPU", "Intel", 320.99, 50);
    inventory.addPart("GPU", "NVIDIA", 499.99, 30);

    std::cout << "All Parts:\n";
    inventory.displayParts();

    std::cout << "\nUpdating GPU...\n";
    inventory.updatePart("GPU", "NVIDIA", 459.99, 25);
    inventory.displayParts();

    std::cout << "\nSearching for CPU...\n";
    ComputerPart* part = inventory.searchPart("CPU");
    if (part) {
        std::cout << "Found: " << part->name << " by " << part->manufacturer << std::endl;
    }

    std::cout << "\nDeleting CPU...\n";
    inventory.deletePart("CPU");
    inventory.displayParts();

    return 0;
}