#include <iostream>
#include <vector>
#include <string>

struct Manufacturer {
    std::string name;
    std::string country;
};

struct ComputerPart {
    std::string name;
    float price;
    Manufacturer manufacturer;
};

class PartsManagementSystem {
    std::vector<ComputerPart> parts;

public:
    void addPart(std::string partName, float partPrice, std::string manufacturerName, std::string manufacturerCountry) {
        Manufacturer manufacturer = {manufacturerName, manufacturerCountry};
        ComputerPart newPart = {partName, partPrice, manufacturer};
        parts.push_back(newPart);
    }

    void deletePart(std::string partName) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == partName) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(std::string partName, float newPrice) {
        for (auto &part : parts) {
            if (part.name == partName) {
                part.price = newPrice;
                break;
            }
        }
    }

    void searchPart(std::string partName) {
        for (const auto &part : parts) {
            if (part.name == partName) {
                std::cout << "Part: " << part.name << ", Price: " << part.price << ", Manufacturer: " 
                          << part.manufacturer.name << ", Country: " << part.manufacturer.country << std::endl;
                return;
            }
        }
        std::cout << "Part not found.\n";
    }

    void displayParts() {
        if (parts.empty()) {
            std::cout << "No parts in the inventory.\n";
            return;
        }
        for (const auto &part : parts) {
            std::cout << "Part: " << part.name << ", Price: " << part.price << ", Manufacturer: " 
                      << part.manufacturer.name << ", Country: " << part.manufacturer.country << std::endl;
        }
    }
};

int main() {
    PartsManagementSystem pms;
    pms.addPart("CPU", 250.50, "Intel", "USA");
    pms.addPart("Motherboard", 120.00, "ASUS", "Taiwan");
    pms.displayParts();
    pms.searchPart("CPU");
    pms.updatePart("CPU", 300.00);
    pms.searchPart("CPU");
    pms.deletePart("Motherboard");
    pms.displayParts();
    return 0;
}