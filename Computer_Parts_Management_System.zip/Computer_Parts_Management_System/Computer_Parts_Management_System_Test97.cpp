#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Part {
    int id;
    string name;
    string manufacturer;
};

class PartsManagementSystem {
private:
    vector<Part> parts;
    int currentId = 1;
    
    Part* findPartById(int id) {
        for (auto& part : parts) {
            if (part.id == id) return &part;
        }
        return nullptr;
    }

public:
    void addPart(const string& name, const string& manufacturer) {
        parts.push_back({currentId++, name, manufacturer});
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->id == id) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(int id, const string& name, const string& manufacturer) {
        Part* part = findPartById(id);
        if (part) {
            part->name = name;
            part->manufacturer = manufacturer;
        }
    }

    Part* searchPartById(int id) {
        return findPartById(id);
    }

    vector<Part> searchPartByName(const string& name) {
        vector<Part> result;
        for (const auto& part : parts) {
            if (part.name == name) result.push_back(part);
        }
        return result;
    }

    void displayParts() {
        for (const auto& part : parts) {
            cout << "ID: " << part.id << ", Name: " << part.name 
                 << ", Manufacturer: " << part.manufacturer << endl;
        }
    }
};

int main() {
    PartsManagementSystem system;
    system.addPart("CPU", "Intel");
    system.addPart("GPU", "Nvidia");
    system.displayParts();
    system.updatePart(1, "CPU", "AMD");
    system.displayParts();
    system.deletePart(1);
    system.displayParts();
    Part* part = system.searchPartById(2);
    if (part) {
        cout << "Found: " << part->name << " by " << part->manufacturer << endl;
    }
    return 0;
}