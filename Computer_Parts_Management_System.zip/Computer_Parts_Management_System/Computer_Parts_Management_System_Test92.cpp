#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Manufacturer {
    int id;
    string name;
    string country;
};

struct ComputerPart {
    int id;
    string name;
    string type;
    float price;
    int manufacturerId;
};

class ManagementSystem {
private:
    vector<Manufacturer> manufacturers;
    vector<ComputerPart> parts;
    int manufacturerIdCounter;
    int partIdCounter;

    Manufacturer* findManufacturerById(int id) {
        for (auto &manufacturer : manufacturers) {
            if (manufacturer.id == id) {
                return &manufacturer;
            }
        }
        return nullptr;
    }

    ComputerPart* findPartById(int id) {
        for (auto &part : parts) {
            if (part.id == id) {
                return &part;
            }
        }
        return nullptr;
    }

public:
    ManagementSystem() : manufacturerIdCounter(1), partIdCounter(1) {}

    void addManufacturer(string name, string country) {
        manufacturers.push_back({manufacturerIdCounter++, name, country});
    }

    void addComputerPart(string name, string type, float price, int manufacturerId) {
        if (findManufacturerById(manufacturerId)) {
            parts.push_back({partIdCounter++, name, type, price, manufacturerId});
        } else {
            cout << "Manufacturer ID not found." << endl;
        }
    }

    void deleteManufacturer(int id) {
        manufacturers.erase(
            remove_if(manufacturers.begin(), manufacturers.end(),
                      [id](const Manufacturer& m) { return m.id == id; }),
            manufacturers.end());

        parts.erase(
            remove_if(parts.begin(), parts.end(),
                      [id](const ComputerPart& p) { return p.manufacturerId == id; }),
            parts.end());
    }

    void deleteComputerPart(int id) {
        parts.erase(
            remove_if(parts.begin(), parts.end(),
                      [id](const ComputerPart& p) { return p.id == id; }),
            parts.end());
    }

    void updateManufacturer(int id, string name, string country) {
        Manufacturer* manufacturer = findManufacturerById(id);
        if (manufacturer) {
            manufacturer->name = name;
            manufacturer->country = country;
        } else {
            cout << "Manufacturer ID not found." << endl;
        }
    }

    void updateComputerPart(int id, string name, string type, float price, int manufacturerId) {
        ComputerPart* part = findPartById(id);
        if (part && findManufacturerById(manufacturerId)) {
            part->name = name;
            part->type = type;
            part->price = price;
            part->manufacturerId = manufacturerId;
        } else {
            cout << "Part or Manufacturer ID not found." << endl;
        }
    }

    void searchComputerPart(int id) {
        ComputerPart* part = findPartById(id);
        if (part) {
            cout << "Part ID: " << part->id << ", Name: " << part->name << ", Type: " << part->type
                 << ", Price: " << part->price << ", Manufacturer ID: " << part->manufacturerId << endl;
        } else {
            cout << "Computer part not found." << endl;
        }
    }

    void displayManufacturers() {
        for (const auto &manufacturer : manufacturers) {
            cout << "Manufacturer ID: " << manufacturer.id << ", Name: " << manufacturer.name
                 << ", Country: " << manufacturer.country << endl;
        }
    }

    void displayComputerParts() {
        for (const auto &part : parts) {
            cout << "Part ID: " << part.id << ", Name: " << part.name << ", Type: " << part.type
                 << ", Price: " << part.price << ", Manufacturer ID: " << part.manufacturerId << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addManufacturer("Intel", "USA");
    system.addManufacturer("AMD", "USA");
    system.addComputerPart("Core i7", "CPU", 300.0, 1);
    system.addComputerPart("Ryzen 5", "CPU", 220.0, 2);
    system.displayManufacturers();
    system.displayComputerParts();
    system.searchComputerPart(1);
    system.updateComputerPart(1, "Core i9", "CPU", 500.0, 1);
    system.displayComputerParts();
    system.deleteComputerPart(2);
    system.displayComputerParts();
    system.deleteManufacturer(1);
    system.displayManufacturers();
    system.displayComputerParts();
    return 0;
}