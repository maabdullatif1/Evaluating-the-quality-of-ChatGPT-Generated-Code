#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string partName;
    std::string manufacturer;
    ComputerPart(std::string name, std::string maker) : partName(name), manufacturer(maker) {}
};

class PartsManagementSystem {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(const std::string& name, const std::string& manufacturer) {
        parts.push_back(ComputerPart(name, manufacturer));
    }

    void deletePart(const std::string& name) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partName == name) {
                parts.erase(it);
                return;
            }
        }
    }

    void updatePart(const std::string& name, const std::string& newName, const std::string& newManufacturer) {
        for (auto& part : parts) {
            if (part.partName == name) {
                part.partName = newName;
                part.manufacturer = newManufacturer;
                return;
            }
        }
    }

    void searchPart(const std::string& name) {
        for (const auto& part : parts) {
            if (part.partName == name) {
                std::cout << "Part Found: " << part.partName << " - Manufacturer: " << part.manufacturer << std::endl;
                return;
            }
        }
        std::cout << "Part Not Found" << std::endl;
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "Part: " << part.partName << ", Manufacturer: " << part.manufacturer << std::endl;
        }
    }
};

int main() {
    PartsManagementSystem system;
    int choice;
    std::string name, manufacturer, newName;

    do {
        std::cout << "\n1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\n\nEnter choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter Part Name: ";
                std::cin >> name;
                std::cout << "Enter Manufacturer: ";
                std::cin >> manufacturer;
                system.addPart(name, manufacturer);
                break;
            case 2:
                std::cout << "Enter Part Name to Delete: ";
                std::cin >> name;
                system.deletePart(name);
                break;
            case 3:
                std::cout << "Enter Part Name to Update: ";
                std::cin >> name;
                std::cout << "Enter New Part Name: ";
                std::cin >> newName;
                std::cout << "Enter New Manufacturer: ";
                std::cin >> manufacturer;
                system.updatePart(name, newName, manufacturer);
                break;
            case 4:
                std::cout << "Enter Part Name to Search: ";
                std::cin >> name;
                system.searchPart(name);
                break;
            case 5:
                system.displayParts();
                break;
        }
    } while (choice != 6);

    return 0;
}