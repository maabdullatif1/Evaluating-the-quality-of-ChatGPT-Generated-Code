#include <iostream>
#include <vector>
#include <string>

struct Part {
    std::string name;
    std::string manufacturer;
    int quantity;
    double price;
};

class PartsManager {
private:
    std::vector<Part> parts;
public:
    void addPart(const std::string &name, const std::string &manufacturer, int quantity, double price) {
        parts.push_back({name, manufacturer, quantity, price});
    }

    void deletePart(const std::string &name) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == name) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(const std::string &name, const std::string &manufacturer, int quantity, double price) {
        for (auto &part : parts) {
            if (part.name == name) {
                part.manufacturer = manufacturer;
                part.quantity = quantity;
                part.price = price;
                break;
            }
        }
    }

    void searchPart(const std::string &name) {
        for (const auto &part : parts) {
            if (part.name == name) {
                std::cout << "Name: " << part.name << ", Manufacturer: " << part.manufacturer 
                          << ", Quantity: " << part.quantity << ", Price: $" << part.price << "\n";
                return;
            }
        }
        std::cout << "Part not found\n";
    }

    void displayParts() {
        for (const auto &part : parts) {
            std::cout << "Name: " << part.name << ", Manufacturer: " << part.manufacturer 
                      << ", Quantity: " << part.quantity << ", Price: $" << part.price << "\n";
        }
    }
};

int main() {
    PartsManager manager;
    int choice;
    do {
        std::cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        if (choice == 1) {
            std::string name, manufacturer;
            int quantity;
            double price;
            std::cout << "Enter name: ";
            std::cin >> name;
            std::cout << "Enter manufacturer: ";
            std::cin >> manufacturer;
            std::cout << "Enter quantity: ";
            std::cin >> quantity;
            std::cout << "Enter price: ";
            std::cin >> price;
            manager.addPart(name, manufacturer, quantity, price);
        } else if (choice == 2) {
            std::string name;
            std::cout << "Enter name: ";
            std::cin >> name;
            manager.deletePart(name);
        } else if (choice == 3) {
            std::string name, manufacturer;
            int quantity;
            double price;
            std::cout << "Enter name: ";
            std::cin >> name;
            std::cout << "Enter manufacturer: ";
            std::cin >> manufacturer;
            std::cout << "Enter quantity: ";
            std::cin >> quantity;
            std::cout << "Enter price: ";
            std::cin >> price;
            manager.updatePart(name, manufacturer, quantity, price);
        } else if (choice == 4) {
            std::string name;
            std::cout << "Enter name: ";
            std::cin >> name;
            manager.searchPart(name);
        } else if (choice == 5) {
            manager.displayParts();
        }
    } while (choice != 6);
    return 0;
}