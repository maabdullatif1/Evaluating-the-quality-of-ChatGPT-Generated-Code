#include <iostream>
#include <vector>
#include <string>

class Part {
public:
    int id;
    std::string name;
    std::string manufacturer;

    Part(int pid, const std::string &pname, const std::string &pmanufacturer)
        : id(pid), name(pname), manufacturer(pmanufacturer) {}
};

class InventorySystem {
private:
    std::vector<Part> parts;
    int nextId = 1;

public:
    void addPart(const std::string &name, const std::string &manufacturer) {
        parts.emplace_back(nextId++, name, manufacturer);
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->id == id) {
                parts.erase(it);
                std::cout << "Part with ID " << id << " deleted." << std::endl;
                return;
            }
        }
        std::cout << "Part with ID " << id << " not found." << std::endl;
    }

    void updatePart(int id, const std::string &name, const std::string &manufacturer) {
        for (auto &part : parts) {
            if (part.id == id) {
                part.name = name;
                part.manufacturer = manufacturer;
                std::cout << "Part with ID " << id << " updated." << std::endl;
                return;
            }
        }
        std::cout << "Part with ID " << id << " not found." << std::endl;
    }

    void searchPart(int id) {
        for (const auto &part : parts) {
            if (part.id == id) {
                std::cout << "Part ID: " << part.id << ", Name: " << part.name
                          << ", Manufacturer: " << part.manufacturer << std::endl;
                return;
            }
        }
        std::cout << "Part with ID " << id << " not found." << std::endl;
    }

    void displayParts() const {
        if (parts.empty()) {
            std::cout << "No parts available." << std::endl;
        } else {
            for (const auto &part : parts) {
                std::cout << "Part ID: " << part.id << ", Name: " << part.name
                          << ", Manufacturer: " << part.manufacturer << std::endl;
            }
        }
    }
};

int main() {
    InventorySystem system;
    system.addPart("CPU", "Intel");
    system.addPart("GPU", "NVIDIA");
    system.displayParts();
    system.searchPart(1);
    system.updatePart(1, "CPU", "AMD");
    system.displayParts();
    system.deletePart(1);
    system.displayParts();
    system.searchPart(1);
    return 0;
}