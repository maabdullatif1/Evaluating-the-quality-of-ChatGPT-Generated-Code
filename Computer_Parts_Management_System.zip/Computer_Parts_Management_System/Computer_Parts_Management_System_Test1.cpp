#include <iostream>
#include <vector>
#include <string>
using namespace std;

class ComputerPart {
public:
    int id;
    string name;
    string manufacturer;
    double price;
    
    ComputerPart(int i, string n, string m, double p) : id(i), name(n), manufacturer(m), price(p) {}
};

class ManagementSystem {
private:
    vector<ComputerPart> parts;
    int generateId() {
        return parts.empty() ? 1 : parts.back().id + 1;
    }

public:
    void addPart(string name, string manufacturer, double price) {
        int id = generateId();
        parts.emplace_back(id, name, manufacturer, price);
    }

    void deletePart(int id) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->id == id) {
                parts.erase(it);
                return;
            }
        }
    }

    void updatePart(int id, string name, string manufacturer, double price) {
        for (auto& part : parts) {
            if (part.id == id) {
                part.name = name;
                part.manufacturer = manufacturer;
                part.price = price;
                return;
            }
        }
    }

    void searchPart(int id) {
        for (const auto& part : parts) {
            if (part.id == id) {
                cout << "ID: " << part.id << " Name: " << part.name
                     << " Manufacturer: " << part.manufacturer
                     << " Price: " << part.price << endl;
                return;
            }
        }
        cout << "Part not found." << endl;
    }

    void displayParts() {
        for (const auto& part : parts) {
            cout << "ID: " << part.id << " Name: " << part.name
                 << " Manufacturer: " << part.manufacturer
                 << " Price: " << part.price << endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPart("CPU", "Intel", 250.0);
    system.addPart("GPU", "NVIDIA", 500.0);
    system.searchPart(1);
    system.updatePart(1, "CPU", "AMD", 270.0);
    system.displayParts();
    system.deletePart(1);
    system.displayParts();
    return 0;
}