#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    int id;
    std::string name;
    std::string country;
    
    Manufacturer(int id, const std::string& name, const std::string& country)
        : id(id), name(name), country(country) {}
};

class ComputerPart {
public:
    int id;
    std::string name;
    std::string category;
    Manufacturer manufacturer;
    
    ComputerPart(int id, const std::string& name, const std::string& category, Manufacturer manufacturer)
        : id(id), name(name), category(category), manufacturer(manufacturer) {}
};

class PartsManagementSystem {
private:
    std::vector<Manufacturer> manufacturers;
    std::vector<ComputerPart> parts;
    
    Manufacturer* findManufacturerById(int id) {
        for (auto& manufacturer : manufacturers) {
            if (manufacturer.id == id) return &manufacturer;
        }
        return nullptr;
    }

    ComputerPart* findPartById(int id) {
        for (auto& part : parts) {
            if (part.id == id) return &part;
        }
        return nullptr;
    }

public:
    void addManufacturer(int id, const std::string& name, const std::string& country) {
        manufacturers.push_back(Manufacturer(id, name, country));
    }

    void addPart(int id, const std::string& name, const std::string& category, int manufacturerId) {
        Manufacturer* manufacturer = findManufacturerById(manufacturerId);
        if (manufacturer != nullptr) {
            parts.push_back(ComputerPart(id, name, category, *manufacturer));
        }
    }

    void deletePart(int id) {
        parts.erase(std::remove_if(parts.begin(), parts.end(),
                    [id](const ComputerPart& part) { return part.id == id; }), parts.end());
    }

    void updatePart(int id, const std::string& name, const std::string& category, int manufacturerId) {
        ComputerPart* part = findPartById(id);
        Manufacturer* manufacturer = findManufacturerById(manufacturerId);
        if (part && manufacturer) {
            part->name = name;
            part->category = category;
            part->manufacturer = *manufacturer;
        }
    }

    void searchPartByName(const std::string& name) {
        for (const auto& part : parts) {
            if (part.name == name) {
                std::cout << "Part ID: " << part.id 
                          << ", Name: " << part.name 
                          << ", Category: " << part.category 
                          << ", Manufacturer: " << part.manufacturer.name << std::endl;
            }
        }
    }

    void displayAllParts() {
        for (const auto& part : parts) {
            std::cout << "Part ID: " << part.id 
                      << ", Name: " << part.name 
                      << ", Category: " << part.category 
                      << ", Manufacturer: " << part.manufacturer.name 
                      << ", Country: " << part.manufacturer.country << std::endl;
        }
    }
};

int main() {
    PartsManagementSystem pms;
    pms.addManufacturer(1, "Intel", "USA");
    pms.addManufacturer(2, "AMD", "USA");
    pms.addPart(1, "CPU", "Processor", 1);
    pms.addPart(2, "GPU", "Graphics Card", 2);
    pms.displayAllParts();
    pms.searchPartByName("CPU");
    pms.updatePart(1, "CPU", "Central Processing Unit", 1);
    pms.displayAllParts();
    pms.deletePart(1);
    pms.displayAllParts();
    return 0;
}