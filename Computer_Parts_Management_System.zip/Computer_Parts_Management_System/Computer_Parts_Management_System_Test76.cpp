#include <iostream>
#include <vector>
#include <string>

struct Manufacturer {
    std::string name;
    std::string country;
};

struct ComputerPart {
    std::string name;
    std::string type;
    Manufacturer manufacturer;
    double price;
};

class PartsManagementSystem {
    std::vector<ComputerPart> parts;

    int findPartIndex(const std::string& partName) {
        for (int i = 0; i < parts.size(); ++i) {
            if (parts[i].name == partName) {
                return i;
            }
        }
        return -1;
    }

public:
    void addPart(const ComputerPart& part) {
        parts.push_back(part);
    }

    void deletePart(const std::string& partName) {
        int index = findPartIndex(partName);
        if (index != -1) {
            parts.erase(parts.begin() + index);
        }
    }

    void updatePart(const std::string& partName, const ComputerPart& updatedPart) {
        int index = findPartIndex(partName);
        if (index != -1) {
            parts[index] = updatedPart;
        }
    }

    ComputerPart* searchPart(const std::string& partName) {
        int index = findPartIndex(partName);
        if (index != -1) {
            return &parts[index];
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "Name: " << part.name << ", Type: " << part.type
                      << ", Manufacturer: " << part.manufacturer.name
                      << " (" << part.manufacturer.country << "), Price: " << part.price
                      << std::endl;
        }
    }
};

int main() {
    PartsManagementSystem system;
    Manufacturer dell = {"Dell", "USA"};
    Manufacturer hp = {"HP", "USA"};

    system.addPart({"Monitor", "Display", dell, 150.0});
    system.addPart({"Keyboard", "Input", hp, 49.99});

    system.displayParts();

    ComputerPart* part = system.searchPart("Monitor");
    if(part) {
        std::cout << "Found part: " << part->name << std::endl;
    }

    system.updatePart("Monitor", {"Monitor", "Display", dell, 140.0});
    system.deletePart("Keyboard");

    system.displayParts();

    return 0;
}