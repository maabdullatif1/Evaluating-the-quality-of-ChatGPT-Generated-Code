#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string partName;
    std::string manufacturer;
    double price;

    ComputerPart(std::string name, std::string manu, double cost)
        : partName(name), manufacturer(manu), price(cost) {}
};

class ManagementSystem {
    std::vector<ComputerPart> inventory;

public:
    void addPart(const std::string& name, const std::string& manu, double price) {
        inventory.push_back(ComputerPart(name, manu, price));
    }

    bool deletePart(const std::string& name) {
        for (auto it = inventory.begin(); it != inventory.end(); ++it) {
            if (it->partName == name) {
                inventory.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updatePart(const std::string& name, const std::string& newManu, double newPrice) {
        for (auto& part : inventory) {
            if (part.partName == name) {
                part.manufacturer = newManu;
                part.price = newPrice;
                return true;
            }
        }
        return false;
    }

    void searchPart(const std::string& name) const {
        for (const auto& part : inventory) {
            if (part.partName == name) {
                std::cout << "Part: " << part.partName << ", Manufacturer: " << part.manufacturer << ", Price: $" << part.price << std::endl;
                return;
            }
        }
        std::cout << "Part not found." << std::endl;
    }

    void displayAllParts() const {
        if (inventory.empty()) {
            std::cout << "No parts available." << std::endl;
            return;
        }
        for (const auto& part : inventory) {
            std::cout << "Part: " << part.partName << ", Manufacturer: " << part.manufacturer << ", Price: $" << part.price << std::endl;
        }
    }
};

int main() {
    ManagementSystem system;
    system.addPart("CPU", "Intel", 250.50);
    system.addPart("GPU", "NVIDIA", 550.99);
    system.displayAllParts();
    system.searchPart("CPU");
    system.updatePart("CPU", "AMD", 230.75);
    system.searchPart("CPU");
    system.deletePart("GPU");
    system.displayAllParts();
    return 0;
}