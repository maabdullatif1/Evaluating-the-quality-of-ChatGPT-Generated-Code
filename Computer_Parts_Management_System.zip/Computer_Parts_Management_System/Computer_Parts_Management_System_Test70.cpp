#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    std::string name;
    std::string address;

    Manufacturer(const std::string& name, const std::string& address) 
        : name(name), address(address) {}
};

class ComputerPart {
public:
    std::string partName;
    std::string partNumber;
    Manufacturer *manufacturer;

    ComputerPart(const std::string& partName, const std::string& partNumber, Manufacturer* manufacturer) 
        : partName(partName), partNumber(partNumber), manufacturer(manufacturer) {}
};

class ManagementSystem {
    std::vector<Manufacturer> manufacturers;
    std::vector<ComputerPart> parts;

public:
    void addManufacturer(const std::string& name, const std::string& address) {
        manufacturers.push_back(Manufacturer(name, address));
    }

    void addPart(const std::string& partName, const std::string& partNumber, const std::string& manufName) {
        Manufacturer* manuf = nullptr;
        for (auto& m : manufacturers) {
            if (m.name == manufName) {
                manuf = &m;
                break;
            }
        }
        if (manuf != nullptr) {
            parts.push_back(ComputerPart(partName, partNumber, manuf));
        }
    }

    void deletePart(const std::string& partNumber) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partNumber == partNumber) {
                parts.erase(it);
                break;
            }
        }
    }

    void updatePart(const std::string& partNumber, const std::string& newPartName, const std::string& newPartNumber, const std::string& newManufName) {
        for (auto& part : parts) {
            if (part.partNumber == partNumber) {
                part.partName = newPartName;
                part.partNumber = newPartNumber;
                for (auto& m : manufacturers) {
                    if (m.name == newManufName) {
                        part.manufacturer = &m;
                        break;
                    }
                }
                break;
            }
        }
    }

    void searchPart(const std::string& partNumber) {
        for (const auto& part : parts) {
            if (part.partNumber == partNumber) {
                std::cout << "Part Name: " << part.partName << "\n"
                          << "Part Number: " << part.partNumber << "\n"
                          << "Manufacturer: " << part.manufacturer->name << "\n"
                          << "Address: " << part.manufacturer->address << "\n";
                return;
            }
        }
        std::cout << "Part not found.\n";
    }

    void displayAll() {
        for (const auto& part : parts) {
            std::cout << "Part Name: " << part.partName << "\n"
                      << "Part Number: " << part.partNumber << "\n"
                      << "Manufacturer: " << part.manufacturer->name << "\n"
                      << "Address: " << part.manufacturer->address << "\n\n";
        }
    }
};

int main() {
    ManagementSystem system;
    system.addManufacturer("Intel", "Santa Clara");
    system.addManufacturer("AMD", "Austin");
    system.addPart("i7 Processor", "1234", "Intel");
    system.addPart("Ryzen Processor", "5678", "AMD");
    system.displayAll();
    system.searchPart("1234");
    system.updatePart("1234", "i9 Processor", "1235", "Intel");
    system.displayAll();
    system.deletePart("1235");
    system.displayAll();
    return 0;
}