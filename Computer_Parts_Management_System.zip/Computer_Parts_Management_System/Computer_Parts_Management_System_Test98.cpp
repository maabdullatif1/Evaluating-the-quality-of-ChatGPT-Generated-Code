#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Manufacturer {
    string name;
    string country;
};

struct ComputerPart {
    string name;
    string type;
    double price;
    Manufacturer manufacturer;
};

class Inventory {
private:
    vector<ComputerPart> parts;

public:
    void addPart(const ComputerPart& part) {
        parts.push_back(part);
    }

    void deletePart(const string& partName) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == partName) {
                parts.erase(it);
                return;
            }
        }
    }

    void updatePart(const string& partName, const ComputerPart& newPart) {
        for (auto& part : parts) {
            if (part.name == partName) {
                part = newPart;
                return;
            }
        }
    }

    ComputerPart* searchPart(const string& partName) {
        for (auto& part : parts) {
            if (part.name == partName) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() {
        cout << "Computer Parts Inventory:" << endl;
        for (const auto& part : parts) {
            cout << "Name: " << part.name << ", Type: " << part.type 
                 << ", Price: " << part.price 
                 << ", Manufacturer: " << part.manufacturer.name 
                 << ", Country: " << part.manufacturer.country << endl;
        }
    }
};

int main() {
    Inventory inventory;
    Manufacturer m1 = {"Intel", "USA"};
    Manufacturer m2 = {"AMD", "USA"};
    
    inventory.addPart({"i9-9900K", "CPU", 499.99, m1});
    inventory.addPart({"Ryzen 9 5900X", "CPU", 549.99, m2});
    
    inventory.displayParts();

    ComputerPart* part = inventory.searchPart("i9-9900K");
    if (part) {
        cout << "Found part: " << part->name << endl;
    }

    inventory.updatePart("i9-9900K", {"i9-11900K", "CPU", 549.99, m1});

    inventory.displayParts();
    
    inventory.deletePart("Ryzen 9 5900X");

    inventory.displayParts();

    return 0;
}