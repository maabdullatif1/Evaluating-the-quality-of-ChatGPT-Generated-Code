#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string partName;
    std::string manufacturer;
    int partID;

    ComputerPart(std::string pName, std::string mfr, int pID) : partName(pName), manufacturer(mfr), partID(pID) {}
};

class PartManager {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(std::string partName, std::string manufacturer, int partID) {
        parts.push_back(ComputerPart(partName, manufacturer, partID));
        std::cout << "Part added.\n";
    }

    void deletePart(int partID) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partID == partID) {
                parts.erase(it);
                std::cout << "Part deleted.\n";
                return;
            }
        }
        std::cout << "Part not found.\n";
    }

    void updatePart(int partID, std::string newPartName, std::string newManufacturer) {
        for (auto &part : parts) {
            if (part.partID == partID) {
                part.partName = newPartName;
                part.manufacturer = newManufacturer;
                std::cout << "Part updated.\n";
                return;
            }
        }
        std::cout << "Part not found.\n";
    }

    void searchPart(int partID) {
        for (const auto& part : parts) {
            if (part.partID == partID) {
                std::cout << "Part ID: " << part.partID << ", Name: " << part.partName << ", Manufacturer: " << part.manufacturer << '\n';
                return;
            }
        }
        std::cout << "Part not found.\n";
    }

    void displayParts() {
        if (parts.empty()) {
            std::cout << "No parts to display.\n";
            return;
        }
        for (const auto& part : parts) {
            std::cout << "Part ID: " << part.partID << ", Name: " << part.partName << ", Manufacturer: " << part.manufacturer << '\n';
        }
    }
};

int main() {
    PartManager manager;
    int choice, partID;
    std::string partName, manufacturer;

    do {
        std::cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter part name, manufacturer, and ID: ";
                std::cin >> partName >> manufacturer >> partID;
                manager.addPart(partName, manufacturer, partID);
                break;
            case 2:
                std::cout << "Enter part ID to delete: ";
                std::cin >> partID;
                manager.deletePart(partID);
                break;
            case 3:
                std::cout << "Enter part ID to update: ";
                std::cin >> partID;
                std::cout << "Enter new part name and manufacturer: ";
                std::cin >> partName >> manufacturer;
                manager.updatePart(partID, partName, manufacturer);
                break;
            case 4:
                std::cout << "Enter part ID to search: ";
                std::cin >> partID;
                manager.searchPart(partID);
                break;
            case 5:
                manager.displayParts();
                break;
            case 6:
                std::cout << "Exiting...\n";
                break;
            default:
                std::cout << "Invalid choice.\n";
        }
    } while (choice != 6);

    return 0;
}