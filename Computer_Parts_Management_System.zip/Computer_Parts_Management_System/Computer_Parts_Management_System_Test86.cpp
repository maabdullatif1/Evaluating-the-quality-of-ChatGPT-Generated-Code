#include <iostream>
#include <vector>
#include <string>

class Part {
public:
    std::string name;
    std::string manufacturer;
    std::string modelNumber;
    float price;
    Part(std::string n, std::string m, std::string mn, float p) 
        : name(n), manufacturer(m), modelNumber(mn), price(p) {}
};

class Inventory {
private:
    std::vector<Part> parts;

    int findPartByName(const std::string& name) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addPart(const std::string& name, const std::string& manufacturer, const std::string& modelNumber, float price) {
        if (findPartByName(name) == -1) {
            parts.emplace_back(name, manufacturer, modelNumber, price);
        }
    }

    void deletePart(const std::string& name) {
        int index = findPartByName(name);
        if (index != -1) {
            parts.erase(parts.begin() + index);
        }
    }

    void updatePart(const std::string& name, const std::string& manufacturer, const std::string& modelNumber, float price) {
        int index = findPartByName(name);
        if (index != -1) {
            parts[index] = Part(name, manufacturer, modelNumber, price);
        }
    }

    Part* searchPart(const std::string& name) {
        int index = findPartByName(name);
        if (index != -1) {
            return &parts[index];
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "Name: " << part.name 
                      << ", Manufacturer: " << part.manufacturer 
                      << ", Model Number: " << part.modelNumber 
                      << ", Price: " << part.price << std::endl;
        }
    }
};

int main() {
    Inventory inventory;
    int choice;
    std::string name, manufacturer, modelNumber;
    float price;

    while (true) {
        std::cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\n";
        std::cin >> choice;
        if (choice == 6) break;

        switch (choice) {
        case 1:
            std::cout << "Enter name, manufacturer, model number and price: ";
            std::cin >> name >> manufacturer >> modelNumber >> price;
            inventory.addPart(name, manufacturer, modelNumber, price);
            break;
        case 2:
            std::cout << "Enter name of part to delete: ";
            std::cin >> name;
            inventory.deletePart(name);
            break;
        case 3:
            std::cout << "Enter name of part to update: ";
            std::cin >> name;
            std::cout << "Enter new manufacturer, model number and price: ";
            std::cin >> manufacturer >> modelNumber >> price;
            inventory.updatePart(name, manufacturer, modelNumber, price);
            break;
        case 4:
            std::cout << "Enter name of part to search: ";
            std::cin >> name;
            Part* part = inventory.searchPart(name);
            if (part) {
                std::cout << "Part Found: "
                          << part->name << ", "
                          << part->manufacturer << ", "
                          << part->modelNumber << ", "
                          << part->price << std::endl;
            } else {
                std::cout << "Part not found\n";
            }
            break;
        case 5:
            inventory.displayParts();
            break;
        default:
            std::cout << "Invalid choice, please try again\n";
        }
    }
    return 0;
}