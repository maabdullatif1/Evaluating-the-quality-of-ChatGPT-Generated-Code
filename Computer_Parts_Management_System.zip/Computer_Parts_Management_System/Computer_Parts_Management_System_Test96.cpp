#include <iostream>
#include <vector>
#include <string>

class Manufacturer {
public:
    std::string name;
    std::string address;

    Manufacturer(std::string n, std::string a) : name(n), address(a) {}
};

class ComputerPart {
public:
    std::string partName;
    std::string partNumber;
    Manufacturer manufacturer;

    ComputerPart(std::string pname, std::string pnumber, Manufacturer m) 
        : partName(pname), partNumber(pnumber), manufacturer(m) {}
};

class PartsManagementSystem {
private:
    std::vector<ComputerPart> parts;

public:
    void addPart(const ComputerPart& part) {
        parts.push_back(part);
    }
    
    bool deletePart(const std::string& partNumber) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->partNumber == partNumber) {
                parts.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updatePart(const std::string& partNumber, const std::string& newPartName, const Manufacturer& newManufacturer) {
        for (auto& part : parts) {
            if (part.partNumber == partNumber) {
                part.partName = newPartName;
                part.manufacturer = newManufacturer;
                return true;
            }
        }
        return false;
    }

    ComputerPart* searchPart(const std::string& partNumber) {
        for (auto& part : parts) {
            if (part.partNumber == partNumber) {
                return &part;
            }
        }
        return nullptr;
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "Part Name: " << part.partName << "\nPart Number: " << part.partNumber 
                      << "\nManufacturer: " << part.manufacturer.name 
                      << "\nAddress: " << part.manufacturer.address << "\n\n";
        }
    }
};

int main() {
    PartsManagementSystem pms;

    Manufacturer m1("Intel", "1234 Silicon Valley");
    Manufacturer m2("AMD", "5678 Tech Park");

    ComputerPart p1("CPU", "123", m1);
    ComputerPart p2("GPU", "456", m2);

    pms.addPart(p1);
    pms.addPart(p2);

    pms.displayParts();

    pms.updatePart("123", "New CPU", Manufacturer("Intel New", "7890 New Valley"));

    pms.displayParts();

    pms.deletePart("456");

    pms.displayParts();

    return 0;
}