#include <iostream>
#include <string>
#include <vector>

class ComputerPart {
public:
    std::string name;
    std::string manufacturer;
    double price;

    ComputerPart(const std::string& name, const std::string& manufacturer, double price)
        : name(name), manufacturer(manufacturer), price(price) {}
};

class PartsManagementSystem {
    std::vector<ComputerPart> parts;

public:
    void addPart(const std::string& name, const std::string& manufacturer, double price) {
        parts.push_back(ComputerPart(name, manufacturer, price));
    }

    void deletePart(const std::string& name) {
        for (auto it = parts.begin(); it != parts.end(); ++it) {
            if (it->name == name) {
                parts.erase(it);
                return;
            }
        }
    }

    void updatePart(const std::string& name, const std::string& newName, const std::string& newManufacturer, double newPrice) {
        for (auto& part : parts) {
            if (part.name == name) {
                part.name = newName;
                part.manufacturer = newManufacturer;
                part.price = newPrice;
                return;
            }
        }
    }

    void searchPart(const std::string& name) {
        for (const auto& part : parts) {
            if (part.name == name) {
                std::cout << "Name: " << part.name 
                          << ", Manufacturer: " << part.manufacturer 
                          << ", Price: " << part.price << "\n";
                return;
            }
        }
        std::cout << "Part not found\n";
    }

    void displayParts() {
        for (const auto& part : parts) {
            std::cout << "Name: " << part.name 
                      << ", Manufacturer: " << part.manufacturer 
                      << ", Price: " << part.price << "\n";
        }
    }
};

int main() {
    PartsManagementSystem pms;
    int choice;
    std::string name, manufacturer, newName;
    double price;

    while (true) {
        std::cout << "1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\n";
        std::cin >> choice;

        switch (choice) {
        case 1:
            std::cout << "Enter name, manufacturer, and price: ";
            std::cin >> name >> manufacturer >> price;
            pms.addPart(name, manufacturer, price);
            break;
        case 2:
            std::cout << "Enter name to delete: ";
            std::cin >> name;
            pms.deletePart(name);
            break;
        case 3:
            std::cout << "Enter existing name, new name, new manufacturer, and new price: ";
            std::cin >> name >> newName >> manufacturer >> price;
            pms.updatePart(name, newName, manufacturer, price);
            break;
        case 4:
            std::cout << "Enter name to search: ";
            std::cin >> name;
            pms.searchPart(name);
            break;
        case 5:
            pms.displayParts();
            break;
        case 6:
            return 0;
        default:
            std::cout << "Invalid option\n";
        }
    }
}