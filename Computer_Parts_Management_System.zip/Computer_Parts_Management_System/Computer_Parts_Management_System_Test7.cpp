#include <iostream>
#include <vector>
#include <string>

class ComputerPart {
public:
    std::string partName;
    std::string manufacturer;
    double price;

    ComputerPart(const std::string& partName, const std::string& manufacturer, double price)
        : partName(partName), manufacturer(manufacturer), price(price) {}
};

class PartsManagementSystem {
private:
    std::vector<ComputerPart> parts;

    int findPartIndex(const std::string& partName) {
        for (size_t i = 0; i < parts.size(); ++i) {
            if (parts[i].partName == partName) {
                return i;
            }
        }
        return -1;
    }

public:
    void addPart(const std::string& partName, const std::string& manufacturer, double price) {
        if (findPartIndex(partName) == -1) {
            parts.push_back(ComputerPart(partName, manufacturer, price));
            std::cout << "Part added successfully.\n";
        } else {
            std::cout << "Part already exists.\n";
        }
    }

    void deletePart(const std::string& partName) {
        int index = findPartIndex(partName);
        if (index != -1) {
            parts.erase(parts.begin() + index);
            std::cout << "Part deleted successfully.\n";
        } else {
            std::cout << "Part not found.\n";
        }
    }

    void updatePart(const std::string& partName, const std::string& manufacturer, double price) {
        int index = findPartIndex(partName);
        if (index != -1) {
            parts[index].manufacturer = manufacturer;
            parts[index].price = price;
            std::cout << "Part updated successfully.\n";
        } else {
            std::cout << "Part not found.\n";
        }
    }

    void searchPart(const std::string& partName) {
        int index = findPartIndex(partName);
        if (index != -1) {
            std::cout << "Part Name: " << parts[index].partName << "\n"
                      << "Manufacturer: " << parts[index].manufacturer << "\n"
                      << "Price: $" << parts[index].price << "\n";
        } else {
            std::cout << "Part not found.\n";
        }
    }

    void displayParts() {
        if (parts.empty()) {
            std::cout << "No parts available.\n";
            return;
        }
        for (const auto& part : parts) {
            std::cout << "Part Name: " << part.partName << "\n"
                      << "Manufacturer: " << part.manufacturer << "\n"
                      << "Price: $" << part.price << "\n\n";
        }
    }
};

int main() {
    PartsManagementSystem pms;
    int choice;
    std::string partName, manufacturer;
    double price;

    do {
        std::cout << "\n1. Add Part\n2. Delete Part\n3. Update Part\n4. Search Part\n5. Display Parts\n6. Exit\nEnter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter Part Name: ";
                std::cin >> partName;
                std::cout << "Enter Manufacturer: ";
                std::cin >> manufacturer;
                std::cout << "Enter Price: ";
                std::cin >> price;
                pms.addPart(partName, manufacturer, price);
                break;
            case 2:
                std::cout << "Enter Part Name to Delete: ";
                std::cin >> partName;
                pms.deletePart(partName);
                break;
            case 3:
                std::cout << "Enter Part Name to Update: ";
                std::cin >> partName;
                std::cout << "Enter New Manufacturer: ";
                std::cin >> manufacturer;
                std::cout << "Enter New Price: ";
                std::cin >> price;
                pms.updatePart(partName, manufacturer, price);
                break;
            case 4:
                std::cout << "Enter Part Name to Search: ";
                std::cin >> partName;
                pms.searchPart(partName);
                break;
            case 5:
                pms.displayParts();
                break;
            case 6:
                std::cout << "Exiting...\n";
                break;
            default:
                std::cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 6);

    return 0;
}