#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Guest {
public:
    string name;
    string email;
    int id;

    Guest(int id, string name, string email) : id(id), name(name), email(email) {}
};

class Room {
public:
    int number;
    string type;
    bool isOccupied;

    Room(int number, string type, bool isOccupied) : number(number), type(type), isOccupied(isOccupied) {}
};

class HotelReservationSystem {
private:
    vector<Guest> guests;
    vector<Room> rooms;

    int findGuestIndexById(int id) {
        for (int i = 0; i < guests.size(); i++) {
            if (guests[i].id == id) {
                return i;
            }
        }
        return -1;
    }

    int findRoomIndexByNumber(int number) {
        for (int i = 0; i < rooms.size(); i++) {
            if (rooms[i].number == number) {
                return i;
            }
        }
        return -1;
    }

public:
    void addGuest(int id, string name, string email) {
        guests.push_back(Guest(id, name, email));
    }

    void addRoom(int number, string type, bool isOccupied) {
        rooms.push_back(Room(number, type, isOccupied));
    }

    void deleteGuest(int id) {
        int index = findGuestIndexById(id);
        if (index != -1) {
            guests.erase(guests.begin() + index);
        }
    }

    void deleteRoom(int number) {
        int index = findRoomIndexByNumber(number);
        if (index != -1) {
            rooms.erase(rooms.begin() + index);
        }
    }

    void updateGuest(int id, string name, string email) {
        int index = findGuestIndexById(id);
        if (index != -1) {
            guests[index].name = name;
            guests[index].email = email;
        }
    }

    void updateRoom(int number, string type, bool isOccupied) {
        int index = findRoomIndexByNumber(number);
        if (index != -1) {
            rooms[index].type = type;
            rooms[index].isOccupied = isOccupied;
        }
    }

    void searchGuest(int id) {
        int index = findGuestIndexById(id);
        if (index != -1) {
            cout << "Guest ID: " << guests[index].id << ", Name: " << guests[index].name << ", Email: " << guests[index].email << endl;
        } else {
            cout << "Guest not found." << endl;
        }
    }

    void searchRoom(int number) {
        int index = findRoomIndexByNumber(number);
        if (index != -1) {
            cout << "Room Number: " << rooms[index].number << ", Type: " << rooms[index].type << ", Occupied: " << (rooms[index].isOccupied ? "Yes" : "No") << endl;
        } else {
            cout << "Room not found." << endl;
        }
    }

    void displayAllGuests() {
        for (const auto& guest : guests) {
            cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Email: " << guest.email << endl;
        }
    }

    void displayAllRooms() {
        for (const auto& room : rooms) {
            cout << "Room Number: " << room.number << ", Type: " << room.type << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe", "john@example.com");
    system.addRoom(101, "Single", false);
    system.displayAllGuests();
    system.displayAllRooms();
    system.updateGuest(1, "John Doe", "john.doe@example.com");
    system.updateRoom(101, "Double", true);
    system.searchGuest(1);
    system.searchRoom(101);
    system.deleteGuest(1);
    system.deleteRoom(101);
    system.displayAllGuests();
    system.displayAllRooms();
    return 0;
}