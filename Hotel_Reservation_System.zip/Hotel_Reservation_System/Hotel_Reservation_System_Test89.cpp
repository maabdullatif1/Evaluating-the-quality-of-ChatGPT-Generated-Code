#include <iostream>
#include <string>
#include <vector>

class Guest {
public:
    int id;
    std::string name;

    Guest(int id, const std::string& name): id(id), name(name) {}
};

class Room {
public:
    int number;
    std::string type;
    bool occupied;

    Room(int number, const std::string& type, bool occupied): number(number), type(type), occupied(occupied) {}
};

std::vector<Guest> guests;
std::vector<Room> rooms;

void addGuest(int id, const std::string& name) {
    guests.push_back(Guest(id, name));
}

void addRoom(int number, const std::string& type, bool occupied) {
    rooms.push_back(Room(number, type, occupied));
}

void deleteGuest(int id) {
    for (auto it = guests.begin(); it != guests.end(); ++it) {
        if (it->id == id) {
            guests.erase(it);
            break;
        }
    }
}

void deleteRoom(int number) {
    for (auto it = rooms.begin(); it != rooms.end(); ++it) {
        if (it->number == number) {
            rooms.erase(it);
            break;
        }
    }
}

void updateGuest(int id, const std::string& name) {
    for (auto& guest : guests) {
        if (guest.id == id) {
            guest.name = name;
            break;
        }
    }
}

void updateRoom(int number, const std::string& type, bool occupied) {
    for (auto& room : rooms) {
        if (room.number == number) {
            room.type = type;
            room.occupied = occupied;
            break;
        }
    }
}

Guest* searchGuest(int id) {
    for (auto& guest : guests) {
        if (guest.id == id) {
            return &guest;
        }
    }
    return nullptr;
}

Room* searchRoom(int number) {
    for (auto& room : rooms) {
        if (room.number == number) {
            return &room;
        }
    }
    return nullptr;
}

void displayGuests() {
    for (const auto& guest : guests) {
        std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << std::endl;
    }
}

void displayRooms() {
    for (const auto& room : rooms) {
        std::cout << "Room Number: " << room.number << ", Type: " << room.type << ", Occupied: " << (room.occupied ? "Yes" : "No") << std::endl;
    }
}

int main() {
    addGuest(1, "Alice");
    addGuest(2, "Bob");
    addRoom(101, "Single", false);
    addRoom(102, "Double", false);

    updateGuest(1, "Alice Smith");
    updateRoom(101, "Single", true);

    displayGuests();
    displayRooms();

    Guest* g = searchGuest(2);
    if (g) std::cout << "Found Guest: " << g->name << std::endl;

    Room* r = searchRoom(102);
    if (r) std::cout << "Found Room Type: " << r->type << std::endl;

    deleteGuest(1);
    deleteRoom(101);

    displayGuests();
    displayRooms();

    return 0;
}