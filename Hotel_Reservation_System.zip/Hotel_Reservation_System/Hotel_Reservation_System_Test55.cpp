#include <iostream>
#include <string>
#include <vector>

class Guest {
public:
    int id;
    std::string name;
    std::string phone;
    Guest(int i, std::string n, std::string p) : id(i), name(n), phone(p) {}
};

class Room {
public:
    int number;
    std::string type;
    bool isAvailable;
    Room(int n, std::string t) : number(n), type(t), isAvailable(true) {}
};

class Hotel {
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, std::string name, std::string phone) {
        guests.push_back(Guest(id, name, phone));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, std::string name, std::string phone) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.phone = phone;
                return;
            }
        }
    }

    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phone << "\n";
                return;
            }
        }
        std::cout << "Guest not found.\n";
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phone << "\n";
        }
    }

    void addRoom(int number, std::string type) {
        rooms.push_back(Room(number, type));
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, std::string type, bool availability) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.type = type;
                room.isAvailable = availability;
                return;
            }
        }
    }

    void searchRoom(int number) {
        for (const auto &room : rooms) {
            if (room.number == number) {
                std::cout << "Room Number: " << room.number << ", Type: " << room.type;
                std::cout << ", Available: " << (room.isAvailable ? "Yes" : "No") << "\n";
                return;
            }
        }
        std::cout << "Room not found.\n";
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number: " << room.number << ", Type: " << room.type;
            std::cout << ", Available: " << (room.isAvailable ? "Yes" : "No") << "\n";
        }
    }
};

int main() {
    Hotel hotel;
    hotel.addGuest(1, "John Doe", "1234567890");
    hotel.addGuest(2, "Jane Smith", "0987654321");
    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");
    hotel.displayGuests();
    hotel.displayRooms();
    hotel.updateGuest(1, "John Doe", "1122334455");
    hotel.updateRoom(101, "Single", false);
    hotel.searchGuest(1);
    hotel.searchRoom(101);
    hotel.deleteGuest(2);
    hotel.deleteRoom(102);
    hotel.displayGuests();
    hotel.displayRooms();
    return 0;
}