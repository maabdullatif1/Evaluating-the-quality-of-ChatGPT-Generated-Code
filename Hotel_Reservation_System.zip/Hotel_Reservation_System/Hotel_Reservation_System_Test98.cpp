#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Guest {
public:
    int id;
    string name;
    string phoneNumber;

    Guest(int id, string name, string phoneNumber)
        : id(id), name(name), phoneNumber(phoneNumber) {}
};

class Room {
public:
    int roomNumber;
    string type;
    bool isAvailable;

    Room(int roomNumber, string type, bool isAvailable)
        : roomNumber(roomNumber), type(type), isAvailable(isAvailable) {}
};

class HotelReservationSystem {
    vector<Guest> guests;
    vector<Room> rooms;

public:
    void addGuest(int id, string name, string phoneNumber) {
        guests.push_back(Guest(id, name, phoneNumber));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string name, string phoneNumber) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.phoneNumber = phoneNumber;
                break;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            cout << "Guest ID: " << guest.id << ", Name: " << guest.name
                 << ", Phone: " << guest.phoneNumber << endl;
        }
    }

    void addRoom(int roomNumber, string type, bool isAvailable) {
        rooms.push_back(Room(roomNumber, type, isAvailable));
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int roomNumber, string type, bool isAvailable) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.type = type;
                room.isAvailable = isAvailable;
                break;
            }
        }
    }

    Room* searchRoom(int roomNumber) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            cout << "Room Number: " << room.roomNumber << ", Type: " << room.type
                 << ", Available: " << (room.isAvailable ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelReservationSystem system;

    system.addGuest(1, "John Doe", "123456789");
    system.addGuest(2, "Jane Smith", "987654321");

    system.addRoom(101, "Single", true);
    system.addRoom(102, "Double", false);

    cout << "Current Guests:" << endl;
    system.displayGuests();

    cout << "\nCurrent Rooms:" << endl;
    system.displayRooms();

    return 0;
}