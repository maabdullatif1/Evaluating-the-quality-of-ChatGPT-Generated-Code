#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;
    std::string phone;

    Guest(int guestId, const std::string &guestName, const std::string &guestPhone)
        : id(guestId), name(guestName), phone(guestPhone) {}
};

class Room {
public:
    int number;
    std::string type;
    bool isBooked;

    Room(int roomNumber, const std::string &roomType)
        : number(roomNumber), type(roomType), isBooked(false) {}
};

class Hotel {
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, const std::string &name, const std::string &phone) {
        guests.push_back(Guest(id, name, phone));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, const std::string &name, const std::string &phone) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.phone = phone;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                std::cout << "Guest ID: " << guest.id 
                          << ", Name: " << guest.name 
                          << ", Phone: " << guest.phone << std::endl;
                return;
            }
        }
        std::cout << "Guest not found." << std::endl;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "Guest ID: " << guest.id 
                      << ", Name: " << guest.name 
                      << ", Phone: " << guest.phone << std::endl;
        }
    }

    void addRoom(int number, const std::string &type) {
        rooms.push_back(Room(number, type));
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, const std::string &type) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.type = type;
                break;
            }
        }
    }

    void searchRoom(int number) {
        for (const auto &room : rooms) {
            if (room.number == number) {
                std::cout << "Room Number: " << room.number 
                          << ", Type: " << room.type 
                          << ", Booked: " << (room.isBooked ? "Yes" : "No") << std::endl;
                return;
            }
        }
        std::cout << "Room not found." << std::endl;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number: " << room.number 
                      << ", Type: " << room.type 
                      << ", Booked: " << (room.isBooked ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    Hotel hotel;
    hotel.addGuest(1, "Alice", "123456789");
    hotel.addGuest(2, "Bob", "987654321");
    hotel.displayGuests();
    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");
    hotel.displayRooms();
    hotel.searchGuest(1);
    hotel.searchRoom(101);
    hotel.updateGuest(1, "Alice Johnson", "1122334455");
    hotel.deleteGuest(2);
    hotel.updateRoom(101, "Deluxe");
    hotel.deleteRoom(102);
    hotel.displayGuests();
    hotel.displayRooms();
    return 0;
}