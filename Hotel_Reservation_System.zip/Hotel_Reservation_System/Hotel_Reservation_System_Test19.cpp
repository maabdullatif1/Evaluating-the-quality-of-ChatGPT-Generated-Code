#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Guest {
public:
    int id;
    string name;
    string phone;

    Guest(int i, string n, string p) : id(i), name(n), phone(p) {}
};

class Room {
public:
    int number;
    string type;
    bool isOccupied;

    Room(int num, string t, bool occupied) : number(num), type(t), isOccupied(occupied) {}
};

class Hotel {
private:
    vector<Guest> guests;
    vector<Room> rooms;

public:
    void addGuest(int id, string name, string phone) {
        guests.push_back(Guest(id, name, phone));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string name, string phone) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.phone = phone;
                break;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            cout << "ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phone << endl;
        }
    }

    void addRoom(int number, string type, bool isOccupied) {
        rooms.push_back(Room(number, type, isOccupied));
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, string type, bool isOccupied) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.type = type;
                room.isOccupied = isOccupied;
                break;
            }
        }
    }

    Room* searchRoom(int number) {
        for (auto &room : rooms) {
            if (room.number == number) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            cout << "Room Number: " << room.number << ", Type: " << room.type << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    Hotel hotel;

    hotel.addGuest(1, "John Doe", "1234567890");
    hotel.addGuest(2, "Jane Smith", "0987654321");

    hotel.addRoom(101, "Single", false);
    hotel.addRoom(102, "Double", true);

    hotel.displayGuests();
    hotel.displayRooms();

    Guest* guest = hotel.searchGuest(1);
    if (guest) {
        cout << "Found guest: " << guest->name << endl;
    }

    Room* room = hotel.searchRoom(101);
    if (room) {
        cout << "Found room type: " << room->type << endl;
    }

    hotel.updateGuest(1, "John Doe Updated", "1111111111");
    hotel.updateRoom(101, "Single Updated", true);

    hotel.displayGuests();
    hotel.displayRooms();

    hotel.deleteGuest(2);
    hotel.deleteRoom(102);

    hotel.displayGuests();
    hotel.displayRooms();

    return 0;
}