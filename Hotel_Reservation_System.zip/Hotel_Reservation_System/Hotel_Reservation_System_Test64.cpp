#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;
    std::string phone;
    Guest(int i, std::string n, std::string p) : id(i), name(n), phone(p) {}
};

class Room {
public:
    int number;
    std::string type;
    bool isOccupied;
    Room(int n, std::string t) : number(n), type(t), isOccupied(false) {}
};

class Hotel {
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, std::string name, std::string phone) {
        guests.push_back(Guest(id, name, phone));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, std::string name, std::string phone) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.phone = phone;
                break;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto &guest : guests) {
            if (guest.id == id)
                return &guest;
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phone << std::endl;
        }
    }

    void addRoom(int number, std::string type) {
        rooms.push_back(Room(number, type));
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, std::string type, bool isOccupied) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.type = type;
                room.isOccupied = isOccupied;
                break;
            }
        }
    }

    Room* searchRoom(int number) {
        for (auto &room : rooms) {
            if (room.number == number)
                return &room;
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number: " << room.number << ", Type: " << room.type << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    Hotel hotel;
    hotel.addGuest(1, "John Doe", "1234567890");
    hotel.addRoom(101, "Single");
    hotel.displayGuests();
    hotel.displayRooms();
    hotel.updateGuest(1, "Jane Doe", "0987654321");
    hotel.updateRoom(101, "Double", true);
    hotel.displayGuests();
    hotel.displayRooms();
    return 0;
}