#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;
    std::string email;

    Guest(int guestId, std::string guestName, std::string guestEmail)
        : id(guestId), name(guestName), email(guestEmail) {}
};

class Room {
public:
    int roomNumber;
    std::string type;
    bool isBooked;

    Room(int number, std::string roomType, bool booked)
        : roomNumber(number), type(roomType), isBooked(booked) {}
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

    Guest* findGuestById(int id) {
        for (auto& guest : guests) {
            if (guest.id == id)
                return &guest;
        }
        return nullptr;
    }

    Room* findRoomByNumber(int roomNumber) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber)
                return &room;
        }
        return nullptr;
    }

public:
    void addGuest(int id, std::string name, std::string email) {
        guests.push_back(Guest(id, name, email));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, std::string name, std::string email) {
        Guest* guest = findGuestById(id);
        if (guest) {
            guest->name = name;
            guest->email = email;
        }
    }

    void searchGuest(int id) {
        Guest* guest = findGuestById(id);
        if (guest) {
            std::cout << "Guest ID: " << guest->id << ", Name: " << guest->name << ", Email: " << guest->email << std::endl;
        } else {
            std::cout << "Guest not found." << std::endl;
        }
    }

    void displayGuests() {
        for (auto& guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Email: " << guest.email << std::endl;
        }
    }

    void addRoom(int roomNumber, std::string type) {
        rooms.push_back(Room(roomNumber, type, false));
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int roomNumber, std::string type, bool isBooked) {
        Room* room = findRoomByNumber(roomNumber);
        if (room) {
            room->type = type;
            room->isBooked = isBooked;
        }
    }

    void searchRoom(int roomNumber) {
        Room* room = findRoomByNumber(roomNumber);
        if (room) {
            std::cout << "Room Number: " << room->roomNumber << ", Type: " << room->type << ", Booked: " << (room->isBooked ? "Yes" : "No") << std::endl;
        } else {
            std::cout << "Room not found." << std::endl;
        }
    }

    void displayRooms() {
        for (auto& room : rooms) {
            std::cout << "Room Number: " << room.roomNumber << ", Type: " << room.type << ", Booked: " << (room.isBooked ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe", "john@example.com");
    system.addGuest(2, "Jane Smith", "jane@example.com");

    system.addRoom(101, "Single");
    system.addRoom(102, "Double");

    system.displayGuests();
    system.displayRooms();

    return 0;
}