#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;
    std::string phone;
    
    Guest(int id, const std::string& name, const std::string& phone)
        : id(id), name(name), phone(phone) {}
};

class Room {
public:
    int number;
    std::string type;
    bool isOccupied;
    
    Room(int number, const std::string& type, bool isOccupied = false)
        : number(number), type(type), isOccupied(isOccupied) {}
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

    Guest* findGuest(int id) {
        for (auto& guest : guests) {
            if (guest.id == id) return &guest;
        }
        return nullptr;
    }

    Room* findRoom(int number) {
        for (auto& room : rooms) {
            if (room.number == number) return &room;
        }
        return nullptr;
    }

public:
    void addGuest(int id, const std::string& name, const std::string& phone) {
        guests.push_back(Guest(id, name, phone));
    }

    void deleteGuest(int id) {
        guests.erase(
            std::remove_if(guests.begin(), guests.end(), [id](const Guest& g) {
                return g.id == id;
            }),
            guests.end()
        );
    }

    void updateGuest(int id, const std::string& name, const std::string& phone) {
        Guest* guest = findGuest(id);
        if (guest) {
            guest->name = name;
            guest->phone = phone;
        }
    }

    Guest* searchGuest(int id) {
        return findGuest(id);
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            std::cout << "ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phone << std::endl;
        }
    }

    void addRoom(int number, const std::string& type) {
        rooms.push_back(Room(number, type));
    }

    void deleteRoom(int number) {
        rooms.erase(
            std::remove_if(rooms.begin(), rooms.end(), [number](const Room& r) {
                return r.number == number;
            }),
            rooms.end()
        );
    }

    void updateRoom(int number, const std::string& type, bool isOccupied) {
        Room* room = findRoom(number);
        if (room) {
            room->type = type;
            room->isOccupied = isOccupied;
        }
    }

    Room* searchRoom(int number) {
        return findRoom(number);
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            std::cout << "Number: " << room.number << ", Type: " << room.type
                      << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe", "555-1234");
    system.addRoom(101, "Single");
    system.displayGuests();
    system.displayRooms();
    return 0;
}