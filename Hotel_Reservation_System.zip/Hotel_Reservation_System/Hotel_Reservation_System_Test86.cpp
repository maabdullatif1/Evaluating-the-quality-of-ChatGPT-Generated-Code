#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Guest {
    int id;
    string name;
};

struct Room {
    int number;
    string type;
};

class HotelReservationSystem {
public:
    void addGuest(int id, string name) {
        guests.push_back({id, name});
    }
    
    void deleteGuest(int id) {
        for(auto it = guests.begin(); it != guests.end(); ++it) {
            if(it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string newName) {
        for(auto &guest : guests) {
            if(guest.id == id) {
                guest.name = newName;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for(auto &guest : guests) {
            if(guest.id == id) {
                cout << "Guest found: " << guest.name << endl;
                return;
            }
        }
        cout << "Guest not found." << endl;
    }

    void displayGuests() {
        for(auto &guest : guests) {
            cout << "ID: " << guest.id << ", Name: " << guest.name << endl;
        }
    }

    void addRoom(int number, string type) {
        rooms.push_back({number, type});
    }
    
    void deleteRoom(int number) {
        for(auto it = rooms.begin(); it != rooms.end(); ++it) {
            if(it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, string newType) {
        for(auto &room : rooms) {
            if(room.number == number) {
                room.type = newType;
                break;
            }
        }
    }

    void searchRoom(int number) {
        for(auto &room : rooms) {
            if(room.number == number) {
                cout << "Room found: " << room.type << endl;
                return;
            }
        }
        cout << "Room not found." << endl;
    }

    void displayRooms() {
        for(auto &room : rooms) {
            cout << "Number: " << room.number << ", Type: " << room.type << endl;
        }
    }

private:
    vector<Guest> guests;
    vector<Room> rooms;
};

int main() {
    HotelReservationSystem hotel;
    
    hotel.addGuest(1, "John Doe");
    hotel.addGuest(2, "Jane Smith");
    hotel.displayGuests();

    hotel.updateGuest(1, "Johnathan Doe");
    hotel.displayGuests();
    
    hotel.searchGuest(2);
    hotel.deleteGuest(2);
    hotel.searchGuest(2);

    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");
    hotel.displayRooms();

    hotel.updateRoom(101, "Deluxe");
    hotel.displayRooms();
    
    hotel.searchRoom(102);
    hotel.deleteRoom(102);
    hotel.searchRoom(102);

    return 0;
}