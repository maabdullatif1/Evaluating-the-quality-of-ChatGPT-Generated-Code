#include <iostream>
#include <string>
#include <vector>

class Room {
public:
    int roomNumber;
    std::string type;
    bool isOccupied;

    Room(int n, const std::string& t, bool o) : roomNumber(n), type(t), isOccupied(o) {}
};

class Guest {
public:
    std::string name;
    int roomNumber;

    Guest(const std::string& n, int r) : name(n), roomNumber(r) {}
};

class Hotel {
private:
    std::vector<Room> rooms;
    std::vector<Guest> guests;

    Room* findRoom(int roomNumber) {
        for (auto& room : rooms)
            if (room.roomNumber == roomNumber)
                return &room;
        return nullptr;
    }

    Guest* findGuest(const std::string& name) {
        for (auto& guest : guests)
            if (guest.name == name)
                return &guest;
        return nullptr;
    }

public:
    void addRoom(int number, const std::string& type) {
        if (!findRoom(number)) {
            rooms.emplace_back(number, type, false);
            std::cout << "Room added.\n";
        }
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == number) {
                if (!it->isOccupied) {
                    rooms.erase(it);
                    std::cout << "Room deleted.\n";
                }
                return;
            }
        }
    }

    void addGuest(const std::string& name, int roomNumber) {
        Room* room = findRoom(roomNumber);
        if (room && !room->isOccupied) {
            guests.emplace_back(name, roomNumber);
            room->isOccupied = true;
            std::cout << "Guest added.\n";
        }
    }

    void deleteGuest(const std::string& name) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->name == name) {
                Room* room = findRoom(it->roomNumber);
                if (room) {
                    room->isOccupied = false;
                }
                guests.erase(it);
                std::cout << "Guest deleted.\n";
                return;
            }
        }
    }

    void updateGuest(const std::string& name, int newRoomNumber) {
        Guest* guest = findGuest(name);
        if (guest) {
            Room* oldRoom = findRoom(guest->roomNumber);
            Room* newRoom = findRoom(newRoomNumber);
            if (newRoom && !newRoom->isOccupied) {
                if (oldRoom) {
                    oldRoom->isOccupied = false;
                }
                guest->roomNumber = newRoomNumber;
                newRoom->isOccupied = true;
                std::cout << "Guest updated.\n";
            }
        }
    }

    void searchGuest(const std::string& name) {
        Guest* guest = findGuest(name);
        if (guest) {
            std::cout << "Guest: " << guest->name << ", Room: " << guest->roomNumber << "\n";
        }
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            std::cout << "Room " << room.roomNumber 
                      << " (" << room.type
                      << "), " << (room.isOccupied ? "Occupied" : "Available") << "\n";
        }
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            std::cout << "Guest: " << guest.name 
                      << ", Room: " << guest.roomNumber << "\n";
        }
    }
};

int main() {
    Hotel hotel;
    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");
    hotel.addGuest("Alice", 101);
    hotel.displayRooms();
    hotel.displayGuests();
    hotel.updateGuest("Alice", 102);
    hotel.displayRooms();
    hotel.displayGuests();
    hotel.deleteGuest("Alice");
    hotel.displayGuests();
    hotel.deleteRoom(102);
    hotel.displayRooms();
    return 0;
}