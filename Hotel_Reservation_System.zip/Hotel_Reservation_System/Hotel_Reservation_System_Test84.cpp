#include <iostream>
#include <string>
#include <vector>

class Room {
public:
    int roomNumber;
    std::string roomType;
    bool isAvailable;

    Room(int number, std::string type) : roomNumber(number), roomType(type), isAvailable(true) {}
};

class Guest {
public:
    std::string name;
    int roomNumber;

    Guest(std::string guestName, int number) : name(guestName), roomNumber(number) {}
};

class HotelReservationSystem {
private:
    std::vector<Room> rooms;
    std::vector<Guest> guests;

public:
    void addRoom(int roomNumber, std::string roomType) {
        rooms.push_back(Room(roomNumber, roomType));
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void addGuest(std::string name, int roomNumber) {
        bool found = false;
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber && room.isAvailable) {
                guests.push_back(Guest(name, roomNumber));
                room.isAvailable = false;
                found = true;
                break;
            }
        }
        if (!found) std::cout << "Room not available.\n";
    }

    void deleteGuest(std::string name) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->name == name) {
                for (auto &room : rooms) {
                    if (room.roomNumber == it->roomNumber) {
                        room.isAvailable = true;
                        break;
                    }
                }
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(std::string name, std::string newName, int newRoomNumber) {
        for (auto &guest : guests) {
            if (guest.name == name) {
                guest.name = newName;
                if (guest.roomNumber != newRoomNumber) {
                    for (auto &room : rooms) {
                        if (room.roomNumber == guest.roomNumber) {
                            room.isAvailable = true;
                        }
                        if (room.roomNumber == newRoomNumber && room.isAvailable) {
                            guest.roomNumber = newRoomNumber;
                            room.isAvailable = false;
                        }
                    }
                }
                break;
            }
        }
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number: " << room.roomNumber
                      << ", Type: " << room.roomType
                      << ", Available: " << (room.isAvailable ? "Yes" : "No") << "\n";
        }
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "Guest Name: " << guest.name
                      << ", Room Number: " << guest.roomNumber << "\n";
        }
    }

    void searchGuest(std::string name) {
        for (const auto &guest : guests) {
            if (guest.name == name) {
                std::cout << "Guest found: " << guest.name 
                          << ", Room Number: " << guest.roomNumber << "\n";
                return;
            }
        }
        std::cout << "Guest not found.\n";
    }

    void searchRoom(int roomNumber) {
        for (const auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                std::cout << "Room Number: " << room.roomNumber
                          << ", Type: " << room.roomType
                          << ", Available: " << (room.isAvailable ? "Yes" : "No") << "\n";
                return;
            }
        }
        std::cout << "Room not found.\n";
    }
};

int main() {
    HotelReservationSystem system;
    system.addRoom(101, "Single");
    system.addRoom(102, "Double");
    system.addGuest("Alice", 101);
    system.addGuest("Bob", 102);
    system.displayRooms();
    system.searchGuest("Alice");
    system.updateGuest("Alice", "Alice Smith", 102);
    system.displayGuests();
    system.deleteGuest("Alice Smith");
    system.displayRooms();
    return 0;
}