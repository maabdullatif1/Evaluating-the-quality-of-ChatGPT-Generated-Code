#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Guest {
    int id;
    string name;
    string contact;
};

struct Room {
    int number;
    string type;
    bool isOccupied;
    int guestId;
};

vector<Guest> guests;
vector<Room> rooms;

int generateGuestId() {
    return guests.size() ? guests.back().id + 1 : 1;
}

int generateRoomNumber() {
    return rooms.size() ? rooms.back().number + 1 : 1;
}

void addGuest() {
    Guest g;
    g.id = generateGuestId();
    cout << "Enter Guest Name: ";
    cin >> g.name;
    cout << "Enter Guest Contact: ";
    cin >> g.contact;
    guests.push_back(g);
}

void deleteGuest() {
    int id;
    cout << "Enter Guest ID to delete: ";
    cin >> id;
    for (auto it = guests.begin(); it != guests.end(); ++it) {
        if (it->id == id) {
            for (auto &room : rooms)
                if (room.guestId == id)
                    room.isOccupied = false;
            guests.erase(it);
            cout << "Guest deleted.\n";
            return;
        }
    }
    cout << "Guest not found.\n";
}

void updateGuest() {
    int id;
    cout << "Enter Guest ID to update: ";
    cin >> id;
    for (auto &g : guests) {
        if (g.id == id) {
            cout << "Enter new name: ";
            cin >> g.name;
            cout << "Enter new contact: ";
            cin >> g.contact;
            cout << "Guest updated.\n";
            return;
        }
    }
    cout << "Guest not found.\n";
}

void searchGuest() {
    int id;
    cout << "Enter Guest ID to search: ";
    cin >> id;
    for (const auto &g : guests) {
        if (g.id == id) {
            cout << "Guest ID: " << g.id << ", Name: " << g.name << ", Contact: " << g.contact << "\n";
            return;
        }
    }
    cout << "Guest not found.\n";
}

void displayGuests() {
    for (const auto &g : guests)
        cout << "Guest ID: " << g.id << ", Name: " << g.name << ", Contact: " << g.contact << "\n";
}

void addRoom() {
    Room r;
    r.number = generateRoomNumber();
    cout << "Enter Room Type: ";
    cin >> r.type;
    r.isOccupied = false;
    r.guestId = 0;
    rooms.push_back(r);
}

void deleteRoom() {
    int number;
    cout << "Enter Room Number to delete: ";
    cin >> number;
    for (auto it = rooms.begin(); it != rooms.end(); ++it) {
        if (it->number == number) {
            rooms.erase(it);
            cout << "Room deleted.\n";
            return;
        }
    }
    cout << "Room not found.\n";
}

void updateRoom() {
    int number;
    cout << "Enter Room Number to update: ";
    cin >> number;
    for (auto &r : rooms) {
        if (r.number == number) {
            cout << "Enter new type: ";
            cin >> r.type;
            cout << "Room updated.\n";
            return;
        }
    }
    cout << "Room not found.\n";
}

void searchRoom() {
    int number;
    cout << "Enter Room Number to search: ";
    cin >> number;
    for (const auto &r : rooms) {
        if (r.number == number) {
            cout << "Room Number: " << r.number << ", Type: " << r.type
                 << ", Occupied: " << (r.isOccupied ? "Yes" : "No")
                 << ", Guest ID: " << r.guestId << "\n";
            return;
        }
    }
    cout << "Room not found.\n";
}

void displayRooms() {
    for (const auto &r : rooms)
        cout << "Room Number: " << r.number << ", Type: " << r.type
             << ", Occupied: " << (r.isOccupied ? "Yes" : "No")
             << ", Guest ID: " << r.guestId << "\n";
}

int main() {
    int choice;
    do {
        cout << "\nHotel Reservation System\n";
        cout << "1. Add Guest\n2. Delete Guest\n3. Update Guest\n4. Search Guest\n5. Display Guests\n";
        cout << "6. Add Room\n7. Delete Room\n8. Update Room\n9. Search Room\n10. Display Rooms\n";
        cout << "11. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addGuest(); break;
            case 2: deleteGuest(); break;
            case 3: updateGuest(); break;
            case 4: searchGuest(); break;
            case 5: displayGuests(); break;
            case 6: addRoom(); break;
            case 7: deleteRoom(); break;
            case 8: updateRoom(); break;
            case 9: searchRoom(); break;
            case 10: displayRooms(); break;
            case 11: cout << "Exiting...\n"; break;
            default: cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 11);
    return 0;
}