#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;
    
    Guest(int i, const std::string &n) : id(i), name(n) {}
};

class Room {
public:
    int number;
    std::string type;
    
    Room(int n, const std::string &t) : number(n), type(t) {}
};

class HotelSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;
    
    template<typename T>
    void display(const std::vector<T> &items) {
        for (const auto &item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name << std::endl;
        }
    }
    
    template<>
    void display(const std::vector<Room> &items) {
        for (const auto &item : items) {
            std::cout << "Number: " << item.number << ", Type: " << item.type << std::endl;
        }
    }
    
public:
    void addGuest(int id, const std::string &name) {
        guests.emplace_back(id, name);
    }
    
    void addRoom(int number, const std::string &type) {
        rooms.emplace_back(number, type);
    }
    
    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }
    
    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }
    
    void updateGuest(int id, const std::string &name) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                break;
            }
        }
    }
    
    void updateRoom(int number, const std::string &type) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.type = type;
                break;
            }
        }
    }
    
    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                std::cout << "Found Guest - ID: " << guest.id << ", Name: " << guest.name << std::endl;
                return;
            }
        }
        std::cout << "Guest not found." << std::endl;
    }
    
    void searchRoom(int number) {
        for (const auto &room : rooms) {
            if (room.number == number) {
                std::cout << "Found Room - Number: " << room.number << ", Type: " << room.type << std::endl;
                return;
            }
        }
        std::cout << "Room not found." << std::endl;
    }
    
    void displayGuests() {
        display(guests);
    }
    
    void displayRooms() {
        display(rooms);
    }
};

int main() {
    HotelSystem hs;
    hs.addGuest(1, "John Doe");
    hs.addRoom(101, "Single");
    hs.addGuest(2, "Jane Smith");
    hs.addRoom(102, "Double");
    hs.displayGuests();
    hs.displayRooms();
    hs.searchGuest(1);
    hs.searchRoom(101);
    hs.updateGuest(1, "Johnny Doe");
    hs.updateRoom(101, "Suite");
    hs.displayGuests();
    hs.displayRooms();
    hs.deleteGuest(2);
    hs.deleteRoom(102);
    hs.displayGuests();
    hs.displayRooms();
    return 0;
}