#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    std::string name;
    int guestID;

    Guest(std::string n, int id) : name(n), guestID(id) {}
};

class Room {
public:
    int roomNumber;
    bool isOccupied;
    int guestID;

    Room(int rn) : roomNumber(rn), isOccupied(false), guestID(-1) {}

    void assignGuest(int id) {
        isOccupied = true;
        guestID = id;
    }

    void removeGuest() {
        isOccupied = false;
        guestID = -1;
    }
};

class Hotel {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(std::string name, int id) {
        guests.push_back(Guest(name, id));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->guestID == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, std::string newName) {
        for (auto &guest : guests) {
            if (guest.guestID == id) {
                guest.name = newName;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.guestID == id) {
                std::cout << "Guest ID: " << guest.guestID << ", Name: " << guest.name << std::endl;
                return;
            }
        }
        std::cout << "Guest not found." << std::endl;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "Guest ID: " << guest.guestID << ", Name: " << guest.name << std::endl;
        }
    }

    void addRoom(int roomNumber) {
        rooms.push_back(Room(roomNumber));
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int roomNumber, bool occupancy, int guestID) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                if (occupancy) {
                    room.assignGuest(guestID);
                } else {
                    room.removeGuest();
                }
                break;
            }
        }
    }

    void searchRoom(int roomNumber) {
        for (const auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                std::cout << "Room Number: " << room.roomNumber << ", Occupied: " << room.isOccupied << ", Guest ID: " << room.guestID << std::endl;
                return;
            }
        }
        std::cout << "Room not found." << std::endl;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number: " << room.roomNumber << ", Occupied: " << room.isOccupied << ", Guest ID: " << room.guestID << std::endl;
        }
    }
};

int main() {
    Hotel hotel;

    hotel.addGuest("Alice", 1);
    hotel.addGuest("Bob", 2);

    hotel.addRoom(101);
    hotel.addRoom(102);

    hotel.updateRoom(101, true, 1);

    std::cout << "Guests:\n";
    hotel.displayGuests();
    
    std::cout << "\nRooms:\n";
    hotel.displayRooms();

    return 0;
}