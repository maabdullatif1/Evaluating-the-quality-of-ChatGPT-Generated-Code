#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Guest {
public:
    int id;
    string name;
    string contact;
    Guest(int guestId, string guestName, string guestContact)
        : id(guestId), name(guestName), contact(guestContact) {}
};

class Room {
public:
    int number;
    string type;
    bool isAvailable;
    Room(int roomNumber, string roomType)
        : number(roomNumber), type(roomType), isAvailable(true) {}
};

class Hotel {
private:
    vector<Guest> guests;
    vector<Room> rooms;

public:
    void addGuest(int id, string name, string contact) {
        guests.emplace_back(id, name, contact);
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string name, string contact) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.contact = contact;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for (const auto& guest : guests) {
            if (guest.id == id) {
                cout << "Guest ID: " << guest.id << " Name: " << guest.name
                     << " Contact: " << guest.contact << endl;
                return;
            }
        }
        cout << "Guest not found." << endl;
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            cout << "Guest ID: " << guest.id << " Name: " << guest.name
                 << " Contact: " << guest.contact << endl;
        }
    }

    void addRoom(int number, string type) {
        rooms.emplace_back(number, type);
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, string type, bool isAvailable) {
        for (auto& room : rooms) {
            if (room.number == number) {
                room.type = type;
                room.isAvailable = isAvailable;
                break;
            }
        }
    }

    void searchRoom(int number) {
        for (const auto& room : rooms) {
            if (room.number == number) {
                cout << "Room Number: " << room.number << " Type: " << room.type
                     << " Available: " << (room.isAvailable ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Room not found." << endl;
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            cout << "Room Number: " << room.number << " Type: " << room.type
                 << " Available: " << (room.isAvailable ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    Hotel hotel;
    hotel.addGuest(1, "John Doe", "123456789");
    hotel.addGuest(2, "Jane Smith", "987654321");
    hotel.displayGuests();
    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");
    hotel.displayRooms();
    hotel.searchGuest(1);
    hotel.searchRoom(101);
    hotel.updateGuest(1, "Johnathan Doe", "123456789");
    hotel.updateRoom(101, "Single Deluxe", false);
    hotel.displayGuests();
    hotel.displayRooms();
    hotel.deleteGuest(2);
    hotel.deleteRoom(102);
    hotel.displayGuests();
    hotel.displayRooms();
    return 0;
}