#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Room {
public:
    int number;
    string type;
    bool isAvailable;

    Room(int num, string t, bool available = true) : number(num), type(t), isAvailable(available) {}
};

class Guest {
public:
    int id;
    string name;
    int roomNumber;

    Guest(int guestId, string guestName, int roomNum) : id(guestId), name(guestName), roomNumber(roomNum) {}
};

class HotelReservationSystem {
private:
    vector<Room> rooms;
    vector<Guest> guests;

public:
    void addRoom(int number, string type) {
        rooms.push_back(Room(number, type));
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, string type) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.type = type;
                break;
            }
        }
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            cout << "Room Number: " << room.number << ", Type: " << room.type << ", Available: " << (room.isAvailable ? "Yes" : "No") << endl;
        }
    }

    void addGuest(int id, string name, int roomNumber) {
        for (auto &room : rooms) {
            if (room.number == roomNumber && room.isAvailable) {
                guests.push_back(Guest(id, name, roomNumber));
                room.isAvailable = false;
                break;
            }
        }
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                for (auto &room : rooms) {
                    if (room.number == it->roomNumber) {
                        room.isAvailable = true;
                        break;
                    }
                }
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string name) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                break;
            }
        }
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Room Number: " << guest.roomNumber << endl;
        }
    }

    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Room Number: " << guest.roomNumber << endl;
                return;
            }
        }
        cout << "Guest not found." << endl;
    }

    void searchRoom(int number) {
        for (const auto &room : rooms) {
            if (room.number == number) {
                cout << "Room Number: " << room.number << ", Type: " << room.type << ", Available: " << (room.isAvailable ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Room not found." << endl;
    }
};

int main() {
    HotelReservationSystem system;
    system.addRoom(101, "Single");
    system.addRoom(102, "Double");
    system.addGuest(1, "Alice", 101);
    system.displayRooms();
    system.displayGuests();
    system.updateGuest(1, "Alice Smith");
    system.searchGuest(1);
    system.deleteGuest(1);
    system.searchRoom(101);
    system.displayGuests();
    return 0;
}