#include <iostream>
#include <string>
#include <vector>

class Guest {
public:
    int id;
    std::string name;
    std::string phone;

    Guest(int id, std::string name, std::string phone) : id(id), name(name), phone(phone) {}
};

class Room {
public:
    int roomNumber;
    std::string type;
    bool isAvailable;

    Room(int roomNumber, std::string type) : roomNumber(roomNumber), type(type), isAvailable(true) {}
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, std::string name, std::string phone) {
        guests.push_back(Guest(id, name, phone));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, std::string name, std::string phone) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.phone = phone;
                break;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phone << std::endl;
        }
    }

    void addRoom(int roomNumber, std::string type) {
        rooms.push_back(Room(roomNumber, type));
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int roomNumber, std::string type, bool isAvailable) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.type = type;
                room.isAvailable = isAvailable;
                break;
            }
        }
    }

    Room* searchRoom(int roomNumber) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            std::cout << "Room Number: " << room.roomNumber << ", Type: " << room.type << ", Available: " << (room.isAvailable ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe", "1234567890");
    system.addGuest(2, "Jane Smith", "0987654321");
    system.addRoom(101, "Single");
    system.addRoom(102, "Double");
    
    std::cout << "Guests:" << std::endl;
    system.displayGuests();
    
    std::cout << "\nRooms:" << std::endl;
    system.displayRooms();

    return 0;
}