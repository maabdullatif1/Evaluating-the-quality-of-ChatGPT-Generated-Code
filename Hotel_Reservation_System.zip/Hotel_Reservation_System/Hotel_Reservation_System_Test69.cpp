#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Guest {
public:
    int id;
    string name;
    int roomNumber;

    Guest(int id, string name, int roomNumber) : id(id), name(name), roomNumber(roomNumber) {}
};

class Room {
public:
    int number;
    string type;
    bool isBooked;

    Room(int number, string type, bool isBooked = false) : number(number), type(type), isBooked(isBooked) {}
};

class HotelReservationSystem {
private:
    vector<Guest> guests;
    vector<Room> rooms;

public:
    void addGuest(int id, string name, int roomNumber) {
        guests.push_back(Guest(id, name, roomNumber));
        updateRoomStatus(roomNumber, true);
    }

    void deleteGuest(int id) {
        for(auto it = guests.begin(); it != guests.end(); ++it) {
            if(it->id == id) {
                updateRoomStatus(it->roomNumber, false);
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string name, int roomNumber) {
        for(auto &guest : guests) {
            if(guest.id == id) {
                updateRoomStatus(guest.roomNumber, false);
                guest.name = name;
                guest.roomNumber = roomNumber;
                updateRoomStatus(roomNumber, true);
                break;
            }
        }
    }

    void searchGuest(int id) {
        for(const auto &guest : guests) {
            if(guest.id == id) {
                cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Room Number: " << guest.roomNumber << endl;
                return;
            }
        }
        cout << "Guest not found" << endl;
    }

    void displayGuests() {
        for(const auto &guest : guests) {
            cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Room Number: " << guest.roomNumber << endl;
        }
    }

    void addRoom(int number, string type) {
        rooms.push_back(Room(number, type));
    }

    void deleteRoom(int number) {
        for(auto it = rooms.begin(); it != rooms.end(); ++it) {
            if(it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, string type, bool isBooked) {
        for(auto &room : rooms) {
            if(room.number == number) {
                room.type = type;
                room.isBooked = isBooked;
                break;
            }
        }
    }

    void searchRoom(int number) {
        for(const auto &room : rooms) {
            if(room.number == number) {
                cout << "Room Number: " << room.number << ", Type: " << room.type << (room.isBooked ? ", Booked" : ", Available") << endl;
                return;
            }
        }
        cout << "Room not found" << endl;
    }

    void displayRooms() {
        for(const auto &room : rooms) {
            cout << "Room Number: " << room.number << ", Type: " << room.type << (room.isBooked ? ", Booked" : ", Available") << endl;
        }
    }

private:
    void updateRoomStatus(int roomNumber, bool isBooked) {
        for(auto &room : rooms) {
            if(room.number == roomNumber) {
                room.isBooked = isBooked;
                break;
            }
        }
    }
};

int main() {
    HotelReservationSystem hotel;

    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");
    hotel.addRoom(103, "Suite");

    hotel.addGuest(1, "Alice", 101);
    hotel.addGuest(2, "Bob", 102);

    hotel.displayGuests();
    hotel.displayRooms();

    hotel.updateGuest(1, "Alice Smith", 103);
    hotel.displayGuests();

    hotel.searchGuest(2);
    hotel.searchRoom(101);

    hotel.deleteGuest(2);
    hotel.displayGuests();
    hotel.displayRooms();

    return 0;
}