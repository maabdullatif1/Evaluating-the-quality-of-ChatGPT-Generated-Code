#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Room {
public:
    int roomNumber;
    bool isAvailable;
    Room(int number) : roomNumber(number), isAvailable(true) {}
};

class Guest {
public:
    string name;
    int age;
    int roomNumber;
    Guest(string n, int a, int r) : name(n), age(a), roomNumber(r) {}
};

class Hotel {
private:
    vector<Room> rooms;
    vector<Guest> guests;
public:
    void addRoom(int roomNumber) {
        rooms.push_back(Room(roomNumber));
    }
    
    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }
    
    void updateRoomAvailability(int roomNumber, bool status) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.isAvailable = status;
                break;
            }
        }
    }
    
    void addGuest(string name, int age, int roomNumber) {
        guests.push_back(Guest(name, age, roomNumber));
        updateRoomAvailability(roomNumber, false);
    }
    
    void deleteGuest(string name) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->name == name) {
                updateRoomAvailability(it->roomNumber, true);
                guests.erase(it);
                break;
            }
        }
    }
    
    void updateGuestRoom(string name, int newRoomNumber) {
        for (auto &guest : guests) {
            if (guest.name == name) {
                updateRoomAvailability(guest.roomNumber, true);
                guest.roomNumber = newRoomNumber;
                updateRoomAvailability(newRoomNumber, false);
                break;
            }
        }
    }
    
    void searchGuest(string name) {
        for (const auto &guest : guests) {
            if (guest.name == name) {
                cout << "Guest: " << guest.name << ", Age: " << guest.age << ", Room: " << guest.roomNumber << endl;
                return;
            }
        }
        cout << "Guest not found." << endl;
    }
    
    void displayGuests() {
        for (const auto &guest : guests) {
            cout << "Guest: " << guest.name << ", Age: " << guest.age << ", Room: " << guest.roomNumber << endl;
        }
    }
    
    void displayRooms() {
        for (const auto &room : rooms) {
            cout << "Room Number: " << room.roomNumber << ", Available: " << (room.isAvailable ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    Hotel hotel;
    hotel.addRoom(101);
    hotel.addRoom(102);
    hotel.addRoom(103);
    hotel.addGuest("Alice", 30, 101);
    hotel.addGuest("Bob", 25, 102);
    hotel.displayGuests();
    hotel.displayRooms();
    hotel.searchGuest("Alice");
    hotel.updateGuestRoom("Alice", 103);
    hotel.displayGuests();
    hotel.displayRooms();
    hotel.deleteGuest("Bob");
    hotel.displayGuests();
    hotel.displayRooms();
    return 0;
}