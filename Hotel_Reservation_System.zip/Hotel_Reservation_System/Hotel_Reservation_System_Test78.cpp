#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Guest {
    int id;
    string name;
    string email;
};

struct Room {
    int roomNumber;
    string type;
    bool isOccupied;
};

class HotelReservationSystem {
private:
    vector<Guest> guests;
    vector<Room> rooms;

    int findGuestIndex(int id) {
        for (unsigned int i = 0; i < guests.size(); ++i) {
            if (guests[i].id == id) return i;
        }
        return -1;
    }

    int findRoomIndex(int roomNumber) {
        for (unsigned int i = 0; i < rooms.size(); ++i) {
            if (rooms[i].roomNumber == roomNumber) return i;
        }
        return -1;
    }

public:
    void addGuest(int id, string name, string email) {
        guests.push_back({id, name, email});
    }

    void deleteGuest(int id) {
        int index = findGuestIndex(id);
        if (index != -1) guests.erase(guests.begin() + index);
    }

    void updateGuest(int id, string name, string email) {
        int index = findGuestIndex(id);
        if (index != -1) {
            guests[index].name = name;
            guests[index].email = email;
        }
    }

    Guest* searchGuest(int id) {
        int index = findGuestIndex(id);
        if (index != -1) return &guests[index];
        return nullptr;
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            cout << "ID: " << guest.id << ", Name: " << guest.name << ", Email: " << guest.email << endl;
        }
    }

    void addRoom(int roomNumber, string type) {
        rooms.push_back({roomNumber, type, false});
    }

    void deleteRoom(int roomNumber) {
        int index = findRoomIndex(roomNumber);
        if (index != -1) rooms.erase(rooms.begin() + index);
    }

    void updateRoom(int roomNumber, string type, bool isOccupied) {
        int index = findRoomIndex(roomNumber);
        if (index != -1) {
            rooms[index].type = type;
            rooms[index].isOccupied = isOccupied;
        }
    }

    Room* searchRoom(int roomNumber) {
        int index = findRoomIndex(roomNumber);
        if (index != -1) return &rooms[index];
        return nullptr;
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            cout << "Room Number: " << room.roomNumber << ", Type: " << room.type
                 << ", Is Occupied: " << (room.isOccupied ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelReservationSystem hrs;
    hrs.addGuest(1, "John Doe", "john@example.com");
    hrs.addGuest(2, "Jane Smith", "jane@example.com");
    hrs.addRoom(101, "Single");
    hrs.addRoom(102, "Double");
    
    hrs.displayGuests();
    hrs.displayRooms();
    
    return 0;
}