#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Guest {
public:
    int id;
    string name;
    Guest(int id, string name) : id(id), name(name) {}
};

class Room {
public:
    int roomNumber;
    bool isOccupied;
    Room(int roomNumber, bool isOccupied = false) : roomNumber(roomNumber), isOccupied(isOccupied) {}
};

class HotelReservationSystem {
private:
    vector<Guest> guests;
    vector<Room> rooms;
    int guestCount = 0;

public:
    void addGuest(string name) {
        guests.push_back(Guest(++guestCount, name));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string name) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                cout << "Guest ID: " << guest.id << ", Name: " << guest.name << endl;
                return;
            }
        }
        cout << "Guest not found" << endl;
    }

    void displayGuests() {
        for (auto& guest : guests) {
            cout << "Guest ID: " << guest.id << ", Name: " << guest.name << endl;
        }
    }

    void addRoom(int roomNumber) {
        rooms.push_back(Room(roomNumber));
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int roomNumber, bool isOccupied) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.isOccupied = isOccupied;
                break;
            }
        }
    }

    void searchRoom(int roomNumber) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                cout << "Room Number: " << room.roomNumber << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Room not found" << endl;
    }

    void displayRooms() {
        for (auto& room : rooms) {
            cout << "Room Number: " << room.roomNumber << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest("Alice");
    system.addGuest("Bob");
    system.addRoom(101);
    system.addRoom(102);
    system.displayGuests();
    system.displayRooms();
    system.updateRoom(101, true);
    system.searchRoom(101);
    system.deleteGuest(1);
    system.searchGuest(1);
    system.displayGuests();
    return 0;
}