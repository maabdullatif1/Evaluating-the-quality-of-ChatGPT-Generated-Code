#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;
    std::string contact;
};

class Room {
public:
    int roomNumber;
    std::string type;
    bool isAvailable;
    Guest* guest;
};

class Hotel {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;
    
public:
    void addGuest(int id, const std::string& name, const std::string& contact) {
        guests.push_back({id, name, contact});
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                return;
            }
        }
    }

    void updateGuest(int id, const std::string& name, const std::string& contact) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.contact = contact;
                return;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        std::cout << "--- Guests ---" << std::endl;
        for (const auto& guest : guests) {
            std::cout << "ID: " << guest.id 
                      << ", Name: " << guest.name 
                      << ", Contact: " << guest.contact 
                      << std::endl;
        }
    }

    void addRoom(int roomNumber, const std::string& type) {
        rooms.push_back({roomNumber, type, true, nullptr});
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                return;
            }
        }
    }

    void updateRoom(int roomNumber, const std::string& type, bool isAvailable) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.type = type;
                room.isAvailable = isAvailable;
                return;
            }
        }
    }

    Room* searchRoom(int roomNumber) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayRooms() {
        std::cout << "--- Rooms ---" << std::endl;
        for (const auto& room : rooms) {
            std::cout << "Room Number: " << room.roomNumber 
                      << ", Type: " << room.type 
                      << ", Available: " << (room.isAvailable ? "Yes" : "No") 
                      << std::endl;
        }
    }

    bool bookRoom(int roomNumber, int guestId) {
        Guest* guest = searchGuest(guestId);
        Room* room = searchRoom(roomNumber);

        if (guest && room && room->isAvailable) {
            room->guest = guest;
            room->isAvailable = false;
            return true;
        }
        return false;
    }

    void checkOut(int roomNumber) {
        Room* room = searchRoom(roomNumber);
        if (room && !room->isAvailable) {
            room->guest = nullptr;
            room->isAvailable = true;
        }
    }
};

int main() {
    Hotel hotel;
    
    hotel.addGuest(1, "John Doe", "1234567890");
    hotel.addGuest(2, "Jane Smith", "0987654321");
    
    hotel.displayGuests();

    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");
    
    hotel.displayRooms();

    hotel.bookRoom(101, 1);
    hotel.displayRooms();

    hotel.checkOut(101);
    hotel.displayRooms();

    return 0;
}