#include <iostream>
#include <string>

using namespace std;

struct Room {
    int roomNumber;
    string roomType;
    bool isAvailable;
};

struct Guest {
    int guestID;
    string name;
    int roomNumber;
};

class HotelReservationSystem {
private:
    Room rooms[100];
    Guest guests[100];
    int roomCount;
    int guestCount;

public:
    HotelReservationSystem() : roomCount(0), guestCount(0) {}

    void addRoom(int roomNumber, string roomType) {
        rooms[roomCount++] = {roomNumber, roomType, true};
    }

    void deleteRoom(int roomNumber) {
        for (int i = 0; i < roomCount; ++i) {
            if (rooms[i].roomNumber == roomNumber) {
                rooms[i] = rooms[--roomCount];
                break;
            }
        }
    }

    void updateRoom(int roomNumber, string roomType) {
        for (int i = 0; i < roomCount; ++i) {
            if (rooms[i].roomNumber == roomNumber) {
                rooms[i].roomType = roomType;
                break;
            }
        }
    }

    void searchRoom(int roomNumber) {
        for (int i = 0; i < roomCount; ++i) {
            if (rooms[i].roomNumber == roomNumber) {
                cout << "Room Number: " << rooms[i].roomNumber << ", Type: " << rooms[i].roomType << ", Available: " << (rooms[i].isAvailable ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Room not found" << endl;
    }

    void displayRooms() {
        for (int i = 0; i < roomCount; ++i) {
            cout << "Room Number: " << rooms[i].roomNumber << ", Type: " << rooms[i].roomType << ", Available: " << (rooms[i].isAvailable ? "Yes" : "No") << endl;
        }
    }

    void addGuest(int guestID, string name, int roomNumber) {
        for (int i = 0; i < roomCount; ++i) {
            if (rooms[i].roomNumber == roomNumber && rooms[i].isAvailable) {
                guests[guestCount++] = {guestID, name, roomNumber};
                rooms[i].isAvailable = false;
                return;
            }
        }
        cout << "Room not available" << endl;
    }

    void deleteGuest(int guestID) {
        for (int i = 0; i < guestCount; ++i) {
            if (guests[i].guestID == guestID) {
                for (int j = 0; j < roomCount; ++j) {
                    if (rooms[j].roomNumber == guests[i].roomNumber) {
                        rooms[j].isAvailable = true;
                        break;
                    }
                }
                guests[i] = guests[--guestCount];
                break;
            }
        }
    }

    void updateGuest(int guestID, string name, int roomNumber) {
        for (int i = 0; i < guestCount; ++i) {
            if (guests[i].guestID == guestID) {
                for (int j = 0; j < roomCount; ++j) {
                    if (rooms[j].roomNumber == guests[i].roomNumber) {
                        rooms[j].isAvailable = true;
                    }
                    if (rooms[j].roomNumber == roomNumber && rooms[j].isAvailable) {
                        guests[i].name = name;
                        guests[i].roomNumber = roomNumber;
                        rooms[j].isAvailable = false;
                    }
                }
                return;
            }
        }
        cout << "Guest not found" << endl;
    }

    void searchGuest(int guestID) {
        for (int i = 0; i < guestCount; ++i) {
            if (guests[i].guestID == guestID) {
                cout << "Guest ID: " << guests[i].guestID << ", Name: " << guests[i].name << ", Room Number: " << guests[i].roomNumber << endl;
                return;
            }
        }
        cout << "Guest not found" << endl;
    }

    void displayGuests() {
        for (int i = 0; i < guestCount; ++i) {
            cout << "Guest ID: " << guests[i].guestID << ", Name: " << guests[i].name << ", Room Number: " << guests[i].roomNumber << endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    
    system.addRoom(101, "Single");
    system.addRoom(102, "Double");
    
    system.addGuest(1, "John Doe", 101);
    
    system.displayRooms();
    system.displayGuests();
    
    system.searchRoom(101);
    system.searchGuest(1);
    
    system.updateRoom(102, "Suite");
    system.updateGuest(1, "John Doe", 102);
    
    system.displayRooms();
    system.displayGuests();
    
    system.deleteGuest(1);
    system.deleteRoom(101);
    
    system.displayRooms();
    system.displayGuests();
    
    return 0;
}