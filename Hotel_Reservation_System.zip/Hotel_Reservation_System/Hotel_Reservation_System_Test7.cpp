#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;

    Guest(int g_id, std::string g_name) : id(g_id), name(g_name) {}
};

class Room {
public:
    int roomNumber;
    bool isAvailable;

    Room(int r_number) : roomNumber(r_number), isAvailable(true) {}
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, std::string name) {
        guests.push_back(Guest(id, name));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, std::string name) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << std::endl;
                return;
            }
        }
        std::cout << "Guest not found." << std::endl;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << std::endl;
        }
    }

    void addRoom(int roomNumber) {
        rooms.push_back(Room(roomNumber));
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoomAvailability(int roomNumber, bool isAvailable) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.isAvailable = isAvailable;
                break;
            }
        }
    }

    void searchRoom(int roomNumber) {
        for (const auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                std::cout << "Room Number: " << room.roomNumber << ", Available: " << (room.isAvailable ? "Yes" : "No") << std::endl;
                return;
            }
        }
        std::cout << "Room not found." << std::endl;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number: " << room.roomNumber << ", Available: " << (room.isAvailable ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe");
    system.addGuest(2, "Jane Doe");
    system.displayGuests();
    system.searchGuest(1);
    system.updateGuest(1, "John Smith");
    system.displayGuests();
    system.deleteGuest(2);
    system.displayGuests();
    
    system.addRoom(101);
    system.addRoom(102);
    system.displayRooms();
    system.updateRoomAvailability(101, false);
    system.searchRoom(101);
    system.deleteRoom(102);
    system.displayRooms();
    return 0;
}