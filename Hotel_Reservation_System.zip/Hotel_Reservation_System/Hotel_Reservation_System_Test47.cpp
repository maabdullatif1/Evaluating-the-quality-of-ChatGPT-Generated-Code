#include <iostream>
#include <string>
using namespace std;

const int MAX_GUESTS = 100;
const int MAX_ROOMS = 100;

struct Guest {
    int id;
    string name;
    string email;
};

struct Room {
    int number;
    string type;
    bool isOccupied;
};

class HotelReservationSystem {
    Guest guests[MAX_GUESTS];
    Room rooms[MAX_ROOMS];
    int guestCount = 0;
    int roomCount = 0;

public:
    void addGuest(int id, string name, string email) {
        if (guestCount < MAX_GUESTS) {
            guests[guestCount++] = {id, name, email};
        }
    }

    void deleteGuest(int id) {
        for (int i = 0; i < guestCount; i++) {
            if (guests[i].id == id) {
                for (int j = i; j < guestCount - 1; j++) {
                    guests[j] = guests[j + 1];
                }
                guestCount--;
                break;
            }
        }
    }

    void updateGuest(int id, string name, string email) {
        for (int i = 0; i < guestCount; i++) {
            if (guests[i].id == id) {
                guests[i].name = name;
                guests[i].email = email;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for (int i = 0; i < guestCount; i++) {
            if (guests[i].id == id) {
                cout << "Guest Found: ID=" << guests[i].id << ", Name=" << guests[i].name << ", Email=" << guests[i].email << endl;
                return;
            }
        }
        cout << "Guest not found." << endl;
    }

    void displayGuests() {
        for (int i = 0; i < guestCount; i++) {
            cout << "ID: " << guests[i].id << ", Name: " << guests[i].name << ", Email: " << guests[i].email << endl;
        }
    }

    void addRoom(int number, string type, bool isOccupied) {
        if (roomCount < MAX_ROOMS) {
            rooms[roomCount++] = {number, type, isOccupied};
        }
    }

    void deleteRoom(int number) {
        for (int i = 0; i < roomCount; i++) {
            if (rooms[i].number == number) {
                for (int j = i; j < roomCount - 1; j++) {
                    rooms[j] = rooms[j + 1];
                }
                roomCount--;
                break;
            }
        }
    }

    void updateRoom(int number, string type, bool isOccupied) {
        for (int i = 0; i < roomCount; i++) {
            if (rooms[i].number == number) {
                rooms[i].type = type;
                rooms[i].isOccupied = isOccupied;
                break;
            }
        }
    }

    void searchRoom(int number) {
        for (int i = 0; i < roomCount; i++) {
            if (rooms[i].number == number) {
                cout << "Room Found: Number=" << rooms[i].number << ", Type=" << rooms[i].type << ", Occupied=" << (rooms[i].isOccupied ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Room not found." << endl;
    }

    void displayRooms() {
        for (int i = 0; i < roomCount; i++) {
            cout << "Number: " << rooms[i].number << ", Type: " << rooms[i].type << ", Occupied: " << (rooms[i].isOccupied ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelReservationSystem hotel;

    hotel.addGuest(1, "John Doe", "john@example.com");
    hotel.addGuest(2, "Jane Smith", "jane@example.com");

    hotel.addRoom(101, "Single", false);
    hotel.addRoom(102, "Double", true);

    hotel.displayGuests();
    hotel.displayRooms();

    hotel.searchGuest(1);
    hotel.searchRoom(101);

    hotel.updateGuest(1, "John Updated", "john_updated@example.com");
    hotel.updateRoom(101, "Single Updated", true);

    hotel.displayGuests();
    hotel.displayRooms();

    hotel.deleteGuest(2);
    hotel.deleteRoom(102);

    hotel.displayGuests();
    hotel.displayRooms();

    return 0;
}