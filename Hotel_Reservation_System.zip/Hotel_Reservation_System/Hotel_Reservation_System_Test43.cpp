#include <iostream>
#include <vector>
#include <string>

struct Guest {
    int id;
    std::string name;
};

struct Room {
    int roomNumber;
    std::string type;
    bool isAvailable;
    int guestId;
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;
    int nextGuestId = 1;

public:
    void addGuest(const std::string& name) {
        guests.push_back({nextGuestId++, name});
    }

    void deleteGuest(int guestId) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == guestId) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int guestId, const std::string& newName) {
        for (auto& guest : guests) {
            if (guest.id == guestId) {
                guest.name = newName;
                break;
            }
        }
    }

    Guest* searchGuest(int guestId) {
        for (auto& guest : guests) {
            if (guest.id == guestId) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << std::endl;
        }
    }

    void addRoom(int roomNumber, const std::string& type) {
        rooms.push_back({roomNumber, type, true, 0});
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int roomNumber, const std::string& newType, bool availability) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.type = newType;
                room.isAvailable = availability;
                break;
            }
        }
    }

    Room* searchRoom(int roomNumber) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            std::cout << "Room Number: " << room.roomNumber 
                      << ", Type: " << room.type 
                      << ", Available: " << (room.isAvailable ? "Yes" : "No") 
                      << ", Guest ID: " << room.guestId 
                      << std::endl;
        }
    }

    void assignRoom(int roomNumber, int guestId) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber && room.isAvailable) {
                room.isAvailable = false;
                room.guestId = guestId;
                break;
            }
        }
    }

    void releaseRoom(int roomNumber) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.isAvailable = true;
                room.guestId = 0;
                break;
            }
        }
    }
};

int main() {
    HotelReservationSystem hotel;

    hotel.addGuest("John Doe");
    hotel.addGuest("Jane Smith");

    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");

    hotel.displayGuests();
    hotel.displayRooms();

    hotel.assignRoom(101, 1);
    
    hotel.displayRooms();

    hotel.releaseRoom(101);

    hotel.displayRooms();

    return 0;
}