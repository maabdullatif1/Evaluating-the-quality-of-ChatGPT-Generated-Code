#include <iostream>
#include <vector>
#include <string>

class Room {
public:
    int roomNumber;
    std::string roomType;
    bool isOccupied;
    Room(int number, std::string type) : roomNumber(number), roomType(type), isOccupied(false) {}
};

class Guest {
public:
    std::string name;
    int roomNumber;
    Guest(std::string guestName, int rNumber) : name(guestName), roomNumber(rNumber) {}
};

class Hotel {
private:
    std::vector<Room> rooms;
    std::vector<Guest> guests;

public:
    void addRoom(int roomNumber, std::string roomType) {
        rooms.push_back(Room(roomNumber, roomType));
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int roomNumber, std::string newType) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.roomType = newType;
                break;
            }
        }
    }

    Room* searchRoom(int roomNumber) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number: " << room.roomNumber << ", Type: " << room.roomType
                      << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
        }
    }

    void addGuest(std::string name, int roomNumber) {
        Room* room = searchRoom(roomNumber);
        if (room && !room->isOccupied) {
            guests.push_back(Guest(name, roomNumber));
            room->isOccupied = true;
        }
    }

    void deleteGuest(std::string name) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->name == name) {
                Room* room = searchRoom(it->roomNumber);
                if (room) {
                    room->isOccupied = false;
                }
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(std::string oldName, std::string newName) {
        for (auto &guest : guests) {
            if (guest.name == oldName) {
                guest.name = newName;
                break;
            }
        }
    }

    Guest* searchGuest(std::string name) {
        for (auto &guest : guests) {
            if (guest.name == name) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "Guest Name: " << guest.name << ", Room Number: " << guest.roomNumber << std::endl;
        }
    }
};

int main() {
    Hotel hotel;
    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");
    hotel.addRoom(103, "Suite");

    hotel.addGuest("John Doe", 101);
    hotel.addGuest("Jane Smith", 102);

    std::cout << "--- Current Guests ---" << std::endl;
    hotel.displayGuests();

    std::cout << "--- Current Rooms ---" << std::endl;
    hotel.displayRooms();

    hotel.updateGuest("John Doe", "John Roe");
    hotel.updateRoom(103, "Deluxe Suite");

    std::cout << "--- Updated Guests ---" << std::endl;
    hotel.displayGuests();

    std::cout << "--- Updated Rooms ---" << std::endl;
    hotel.displayRooms();

    hotel.deleteGuest("Jane Smith");
    hotel.deleteRoom(102);

    std::cout << "--- Final Guests ---" << std::endl;
    hotel.displayGuests();

    std::cout << "--- Final Rooms ---" << std::endl;
    hotel.displayRooms();

    return 0;
}