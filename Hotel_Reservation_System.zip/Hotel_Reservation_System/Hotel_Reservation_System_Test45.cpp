#include <iostream>
#include <string>
#include <vector>

class Room {
public:
    int roomNumber;
    bool isBooked;

    Room(int num) : roomNumber(num), isBooked(false) {}
};

class Guest {
public:
    std::string name;
    int roomNumber;

    Guest(std::string guestName, int num) : name(guestName), roomNumber(num) {}
};

class HotelReservationSystem {
private:
    std::vector<Room> rooms;
    std::vector<Guest> guests;

public:
    void addRoom(int roomNumber) {
        rooms.push_back(Room(roomNumber));
    }

    void addGuest(std::string name, int roomNumber) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber && !room.isBooked) {
                guests.push_back(Guest(name, roomNumber));
                room.isBooked = true;
                return;
            }
        }
        std::cout << "Room not available or invalid.\n";
    }

    void deleteGuest(std::string name) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->name == name) {
                int roomNum = it->roomNumber;
                guests.erase(it);
                for (auto &room : rooms) {
                    if (room.roomNumber == roomNum)
                        room.isBooked = false;
                }
                std::cout << "Guest deleted.\n";
                return;
            }
        }
        std::cout << "Guest not found.\n";
    }

    void updateGuest(std::string name, std::string newName, int newRoomNumber) {
        for (auto &guest : guests) {
            if (guest.name == name) {
                for (auto &room : rooms) {
                    if (room.roomNumber == newRoomNumber && !room.isBooked) {
                        guest.name = newName;
                        rooms[guest.roomNumber - 1].isBooked = false;
                        guest.roomNumber = newRoomNumber;
                        room.isBooked = true;
                        std::cout << "Guest updated.\n";
                        return;
                    }
                }
                std::cout << "New room not available or invalid.\n";
                return;
            }
        }
        std::cout << "Guest not found.\n";
    }

    void searchGuest(std::string name) {
        for (auto &guest : guests) {
            if (guest.name == name) {
                std::cout << "Guest found: " << guest.name << ", Room: " << guest.roomNumber << "\n";
                return;
            }
        }
        std::cout << "Guest not found.\n";
    }

    void displayGuests() {
        for (auto &guest : guests) {
            std::cout << "Guest Name: " << guest.name << ", Room: " << guest.roomNumber << "\n";
        }
    }

    void displayRooms() {
        for (auto &room : rooms) {
            std::cout << "Room Number: " << room.roomNumber << ", Status: " << (room.isBooked ? "Booked" : "Available") << "\n";
        }
    }
};

int main() {
    HotelReservationSystem hotel;

    hotel.addRoom(101);
    hotel.addRoom(102);
    hotel.addRoom(103);

    hotel.addGuest("Alice", 101);
    hotel.addGuest("Bob", 102);

    std::cout << "Guests:\n";
    hotel.displayGuests();

    std::cout << "Rooms:\n";
    hotel.displayRooms();

    hotel.searchGuest("Alice");

    hotel.updateGuest("Alice", "Alice Wonderland", 103);

    std::cout << "Updated Guests:\n";
    hotel.displayGuests();

    hotel.deleteGuest("Bob");

    std::cout << "Final Guests:\n";
    hotel.displayGuests();

    std::cout << "Final Rooms:\n";
    hotel.displayRooms();

    return 0;
}