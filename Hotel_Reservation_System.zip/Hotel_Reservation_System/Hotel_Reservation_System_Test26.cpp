#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;
    std::string phone;
};

class Room {
public:
    int id;
    std::string type;
    bool isOccupied;
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

    bool roomExists(int id) {
        for (auto &room : rooms) {
            if (room.id == id) return true;
        }
        return false;
    }

    bool guestExists(int id) {
        for (auto &guest : guests) {
            if (guest.id == id) return true;
        }
        return false;
    }

public:
    void addGuest(int id, const std::string &name, const std::string &phone) {
        if (guestExists(id)) return;
        guests.push_back({id, name, phone});
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, const std::string &name, const std::string &phone) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.phone = phone;
                break;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto &guest : guests) {
            if (guest.id == id) return &guest;
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "ID: " << guest.id
                      << ", Name: " << guest.name
                      << ", Phone: " << guest.phone << std::endl;
        }
    }

    void addRoom(int id, const std::string &type, bool isOccupied) {
        if (roomExists(id)) return;
        rooms.push_back({id, type, isOccupied});
    }

    void deleteRoom(int id) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->id == id) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int id, const std::string &type, bool isOccupied) {
        for (auto &room : rooms) {
            if (room.id == id) {
                room.type = type;
                room.isOccupied = isOccupied;
                break;
            }
        }
    }

    Room* searchRoom(int id) {
        for (auto &room : rooms) {
            if (room.id == id) return &room;
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "ID: " << room.id
                      << ", Type: " << room.type
                      << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    
    system.addGuest(1, "John Doe", "1234567890");
    system.addGuest(2, "Jane Smith", "0987654321");
    
    system.addRoom(101, "Single", false);
    system.addRoom(102, "Double", true);

    system.displayGuests();
    system.displayRooms();

    system.updateGuest(1, "John Doe", "1111111111");
    system.updateRoom(101, "Single", true);

    system.displayGuests();
    system.displayRooms();

    system.deleteGuest(2);
    system.deleteRoom(102);

    system.displayGuests();
    system.displayRooms();

    return 0;
}