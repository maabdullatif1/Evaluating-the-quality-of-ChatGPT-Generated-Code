#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;
    Guest(int gid, std::string gname) : id(gid), name(gname) {}
};

class Room {
public:
    int number;
    std::string type;
    bool isOccupied;
    Room(int rnum, std::string rtype, bool occupied = false) : number(rnum), type(rtype), isOccupied(occupied) {}
};

class Hotel {
    std::vector<Guest> guests;
    std::vector<Room> rooms;
public:
    void addGuest(int id, std::string name) {
        guests.push_back(Guest(id, name));
    }
    
    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }
    
    void updateGuest(int id, std::string newName) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = newName;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                std::cout << "Guest Found: ID = " << guest.id << ", Name = " << guest.name << std::endl;
                return;
            }
        }
        std::cout << "Guest Not Found\n";
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << std::endl;
        }
    }

    void addRoom(int number, std::string type) {
        rooms.push_back(Room(number, type));
    }
    
    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }
    
    void updateRoom(int number, std::string newType) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.type = newType;
                break;
            }
        }
    }
    
    void searchRoom(int number) {
        for (const auto &room : rooms) {
            if (room.number == number) {
                std::cout << "Room Found: Number = " << room.number << ", Type = " << room.type << ", Occupied = " << (room.isOccupied ? "Yes" : "No") << std::endl;
                return;
            }
        }
        std::cout << "Room Not Found\n";
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number: " << room.number << ", Type: " << room.type << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    Hotel hotel;
    hotel.addGuest(1, "Alice");
    hotel.addGuest(2, "Bob");
    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");

    std::cout << "Guests:\n";
    hotel.displayGuests();
    std::cout << "Rooms:\n";
    hotel.displayRooms();

    hotel.searchGuest(1);
    hotel.searchRoom(102);

    hotel.updateGuest(1, "Alice Smith");
    hotel.updateRoom(101, "Deluxe");

    std::cout << "Updated Guests:\n";
    hotel.displayGuests();
    std::cout << "Updated Rooms:\n";
    hotel.displayRooms();

    hotel.deleteGuest(2);
    hotel.deleteRoom(102);

    std::cout << "After Deletion Guests:\n";
    hotel.displayGuests();
    std::cout << "After Deletion Rooms:\n";
    hotel.displayRooms();

    return 0;
}