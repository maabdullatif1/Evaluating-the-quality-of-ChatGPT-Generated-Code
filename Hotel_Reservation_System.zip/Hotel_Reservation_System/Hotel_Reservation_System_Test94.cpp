#include <iostream>
#include <string>

using namespace std;

class Guest {
public:
    int guestID;
    string name;
    string email;
    Guest* nextGuest;
    
    Guest(int id, string n, string e) : guestID(id), name(n), email(e), nextGuest(nullptr) {}
};

class Room {
public:
    int roomID;
    string type;
    bool isOccupied;
    Room* nextRoom;

    Room(int id, string t) : roomID(id), type(t), isOccupied(false), nextRoom(nullptr) {}
};

class HotelReservationSystem {
    Guest* guestHead;
    Room* roomHead;
    int guestCounter;
    int roomCounter;

public:
    HotelReservationSystem() : guestHead(nullptr), roomHead(nullptr), guestCounter(0), roomCounter(0) {}

    void addGuest(string name, string email) {
        Guest* newGuest = new Guest(++guestCounter, name, email);
        if (!guestHead) {
            guestHead = newGuest;
        } else {
            Guest* temp = guestHead;
            while (temp->nextGuest) {
                temp = temp->nextGuest;
            }
            temp->nextGuest = newGuest;
        }
    }

    void deleteGuest(int id) {
        if (!guestHead) return;
        if (guestHead->guestID == id) {
            Guest* toDelete = guestHead;
            guestHead = guestHead->nextGuest;
            delete toDelete;
            return;
        }
        Guest* temp = guestHead;
        while (temp->nextGuest && temp->nextGuest->guestID != id) {
            temp = temp->nextGuest;
        }
        if (temp->nextGuest) {
            Guest* toDelete = temp->nextGuest;
            temp->nextGuest = toDelete->nextGuest;
            delete toDelete;
        }
    }

    void updateGuest(int id, string name, string email) {
        Guest* temp = guestHead;
        while (temp && temp->guestID != id) {
            temp = temp->nextGuest;
        }
        if (temp) {
            temp->name = name;
            temp->email = email;
        }
    }

    Guest* searchGuest(int id) {
        Guest* temp = guestHead;
        while (temp && temp->guestID != id) {
            temp = temp->nextGuest;
        }
        return temp;
    }

    void displayGuests() {
        Guest* temp = guestHead;
        while (temp) {
            cout << "Guest ID: " << temp->guestID << ", Name: " << temp->name << ", Email: " << temp->email << endl;
            temp = temp->nextGuest;
        }
    }

    void addRoom(string type) {
        Room* newRoom = new Room(++roomCounter, type);
        if (!roomHead) {
            roomHead = newRoom;
        } else {
            Room* temp = roomHead;
            while (temp->nextRoom) {
                temp = temp->nextRoom;
            }
            temp->nextRoom = newRoom;
        }
    }

    void deleteRoom(int id) {
        if (!roomHead) return;
        if (roomHead->roomID == id) {
            Room* toDelete = roomHead;
            roomHead = roomHead->nextRoom;
            delete toDelete;
            return;
        }
        Room* temp = roomHead;
        while (temp->nextRoom && temp->nextRoom->roomID != id) {
            temp = temp->nextRoom;
        }
        if (temp->nextRoom) {
            Room* toDelete = temp->nextRoom;
            temp->nextRoom = toDelete->nextRoom;
            delete toDelete;
        }
    }

    void updateRoom(int id, string type, bool isOccupied) {
        Room* temp = roomHead;
        while (temp && temp->roomID != id) {
            temp = temp->nextRoom;
        }
        if (temp) {
            temp->type = type;
            temp->isOccupied = isOccupied;
        }
    }

    Room* searchRoom(int id) {
        Room* temp = roomHead;
        while (temp && temp->roomID != id) {
            temp = temp->nextRoom;
        }
        return temp;
    }

    void displayRooms() {
        Room* temp = roomHead;
        while (temp) {
            cout << "Room ID: " << temp->roomID << ", Type: " << temp->type << ", Occupied: " << (temp->isOccupied ? "Yes" : "No") << endl;
            temp = temp->nextRoom;
        }
    }
};

int main() {
    HotelReservationSystem system;
    
    system.addGuest("John Doe", "john@example.com");
    system.addGuest("Jane Smith", "jane@example.com");

    system.addRoom("Single");
    system.addRoom("Double");

    system.displayGuests();
    system.displayRooms();

    system.updateGuest(1, "John Updated", "john.updated@example.com");
    system.updateRoom(1, "Suite", true);

    system.displayGuests();
    system.displayRooms();

    Guest* guest = system.searchGuest(2);
    if (guest) cout << "Found Guest: " << guest->name << endl;

    Room* room = system.searchRoom(2);
    if (room) cout << "Found Room: " << room->type << endl;

    system.deleteGuest(1);
    system.deleteRoom(1);

    system.displayGuests();
    system.displayRooms();

    return 0;
}