#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;
    std::string email;
    
    Guest(int id, std::string name, std::string email)
        : id(id), name(name), email(email) {}
};

class Room {
public:
    int roomNumber;
    std::string type;
    bool isAvailable;
    
    Room(int roomNumber, std::string type, bool isAvailable)
        : roomNumber(roomNumber), type(type), isAvailable(isAvailable) {}
};

class HotelReservationSystem {
public:
    std::vector<Guest> guests;
    std::vector<Room> rooms;
    
    void addGuest(int id, std::string name, std::string email) {
        guests.emplace_back(id, name, email);
    }
    
    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }
    
    void updateGuest(int id, std::string name, std::string email) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.email = email;
                break;
            }
        }
    }
    
    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                std::cout << "ID: " << guest.id << ", Name: " << guest.name << ", Email: " << guest.email << std::endl;
                return;
            }
        }
        std::cout << "Guest not found" << std::endl;
    }
    
    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "ID: " << guest.id << ", Name: " << guest.name << ", Email: " << guest.email << std::endl;
        }
    }

    void addRoom(int roomNumber, std::string type, bool isAvailable) {
        rooms.emplace_back(roomNumber, type, isAvailable);
    }
    
    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }
    
    void updateRoom(int roomNumber, std::string type, bool isAvailable) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.type = type;
                room.isAvailable = isAvailable;
                break;
            }
        }
    }
    
    void searchRoom(int roomNumber) {
        for (const auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                std::cout << "Room Number: " << room.roomNumber << ", Type: " << room.type << ", Availability: " << (room.isAvailable ? "Yes" : "No") << std::endl;
                return;
            }
        }
        std::cout << "Room not found" << std::endl;
    }
    
    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number: " << room.roomNumber << ", Type: " << room.type << ", Availability: " << (room.isAvailable ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    
    system.addGuest(1, "John Doe", "john@example.com");
    system.addRoom(101, "Single", true);
    
    std::cout << "Guests:" << std::endl;
    system.displayGuests();
    
    std::cout << "Rooms:" << std::endl;
    system.displayRooms();
    
    return 0;
}