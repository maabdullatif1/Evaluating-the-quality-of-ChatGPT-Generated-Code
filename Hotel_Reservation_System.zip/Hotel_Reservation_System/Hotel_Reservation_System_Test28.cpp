#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Room {
    int roomNumber;
    bool isBooked;
};

struct Guest {
    string name;
    int roomNumber;
};

vector<Room> rooms;
vector<Guest> guests;

void addRoom(int roomNumber) {
    rooms.push_back({roomNumber, false});
}

void addGuest(string name, int roomNumber) {
    for (auto &room : rooms) {
        if (room.roomNumber == roomNumber && !room.isBooked) {
            guests.push_back({name, roomNumber});
            room.isBooked = true;
            return;
        }
    }
    cout << "Room not available" << endl;
}

void deleteGuest(string name) {
    for (size_t i = 0; i < guests.size(); ++i) {
        if (guests[i].name == name) {
            for (auto &room : rooms) {
                if (room.roomNumber == guests[i].roomNumber) {
                    room.isBooked = false;
                    break;
                }
            }
            guests.erase(guests.begin() + i);
            return;
        }
    }
    cout << "Guest not found" << endl;
}

void updateGuest(string oldName, string newName, int newRoomNumber) {
    for (auto &guest : guests) {
        if (guest.name == oldName) {
            for (auto &room : rooms) {
                if (room.roomNumber == guest.roomNumber) {
                    room.isBooked = false;
                }
            }
            guest.name = newName;
            guest.roomNumber = newRoomNumber;
            for (auto &room : rooms) {
                if (room.roomNumber == newRoomNumber) {
                    room.isBooked = true;
                }
            }
            return;
        }
    }
    cout << "Guest not found" << endl;
}

Guest* searchGuest(string name) {
    for (auto &guest : guests) {
        if (guest.name == name) {
            return &guest;
        }
    }
    cout << "Guest not found" << endl;
    return nullptr;
}

Room* searchRoom(int roomNumber) {
    for (auto &room : rooms) {
        if (room.roomNumber == roomNumber) {
            return &room;
        }
    }
    cout << "Room not found" << endl;
    return nullptr;
}

void displayGuests() {
    for (const auto &guest : guests) {
        cout << "Name: " << guest.name << ", Room Number: " << guest.roomNumber << endl;
    }
}

void displayRooms() {
    for (const auto &room : rooms) {
        cout << "Room Number: " << room.roomNumber << ", Booked: " << (room.isBooked ? "Yes" : "No") << endl;
    }
}

int main() {
    addRoom(101);
    addRoom(102);
    addRoom(103);

    addGuest("Alice", 101);
    addGuest("Bob", 102);

    displayGuests();
    displayRooms();

    updateGuest("Alice", "Alice Smith", 103);
    deleteGuest("Bob");

    displayGuests();
    displayRooms();

    if (searchGuest("Alice Smith")) {
        cout << "Alice Smith is staying with us." << endl;
    }

    if (searchRoom(101)) {
        cout << "Room 101 is in the system." << endl;
    }

    return 0;
}