#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    std::string name;
    int guestID;
    
    Guest(int id, const std::string& n) : guestID(id), name(n) {}
};

class Room {
public:
    int roomNumber;
    bool isOccupied;

    Room(int number) : roomNumber(number), isOccupied(false) {}
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(const std::string& name, int id) {
        guests.emplace_back(id, name);
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->guestID == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, const std::string& newName) {
        for (auto& guest : guests) {
            if (guest.guestID == id) {
                guest.name = newName;
                break;
            }
        }
    }

    bool searchGuest(int id) {
        for (const auto& guest : guests) {
            if (guest.guestID == id) {
                std::cout << "Guest Found: " << guest.name << std::endl;
                return true;
            }
        }
        return false;
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            std::cout << "ID: " << guest.guestID << ", Name: " << guest.name << std::endl;
        }
    }

    void addRoom(int roomNumber) {
        rooms.emplace_back(roomNumber);
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoomStatus(int roomNumber, bool occupied) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.isOccupied = occupied;
                break;
            }
        }
    }

    bool searchRoom(int roomNumber) {
        for (const auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                std::cout << "Room Found: " << room.roomNumber << ", Occupied: " 
                          << (room.isOccupied ? "Yes" : "No") << std::endl;
                return true;
            }
        }
        return false;
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            std::cout << "Room Number: " << room.roomNumber 
                      << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem hotel;

    hotel.addGuest("Alice", 1);
    hotel.addGuest("Bob", 2);
    hotel.displayGuests();

    hotel.updateGuest(1, "Alice Smith");
    hotel.searchGuest(1);

    hotel.deleteGuest(2);
    hotel.displayGuests();

    hotel.addRoom(101);
    hotel.addRoom(102);
    hotel.updateRoomStatus(101, true);
    
    hotel.displayRooms();
    hotel.searchRoom(102);

    hotel.deleteRoom(101);
    hotel.displayRooms();

    return 0;
}