#include <iostream>
#include <string>
using namespace std;

class Guest {
public:
    int id;
    string name;
    Guest* next;

    Guest(int i, string n) : id(i), name(n), next(nullptr) {}
};

class Room {
public:
    int number;
    bool isOccupied;
    Room* next;

    Room(int num) : number(num), isOccupied(false), next(nullptr) {}
};

class HotelReservationSystem {
private:
    Guest* guestHead;
    Room* roomHead;

public:
    HotelReservationSystem() : guestHead(nullptr), roomHead(nullptr) {}

    ~HotelReservationSystem() {
        clearGuests();
        clearRooms();
    }

    void addGuest(int id, string name) {
        Guest* newGuest = new Guest(id, name);
        newGuest->next = guestHead;
        guestHead = newGuest;
    }

    void deleteGuest(int id) {
        Guest* temp = guestHead;
        Guest* prev = nullptr;
        while (temp != nullptr && temp->id != id) {
            prev = temp;
            temp = temp->next;
        }
        if (temp == nullptr) return;
        if (prev == nullptr) guestHead = temp->next;
        else prev->next = temp->next;
        delete temp;
    }

    void updateGuest(int id, string newName) {
        Guest* temp = guestHead;
        while (temp != nullptr) {
            if (temp->id == id) {
                temp->name = newName;
                return;
            }
            temp = temp->next;
        }
    }

    Guest* searchGuest(int id) {
        Guest* temp = guestHead;
        while (temp != nullptr) {
            if (temp->id == id) return temp;
            temp = temp->next;
        }
        return nullptr;
    }

    void displayGuests() {
        Guest* temp = guestHead;
        while (temp != nullptr) {
            cout << "Guest ID: " << temp->id << ", Name: " << temp->name << endl;
            temp = temp->next;
        }
    }

    void addRoom(int number) {
        Room* newRoom = new Room(number);
        newRoom->next = roomHead;
        roomHead = newRoom;
    }

    void deleteRoom(int number) {
        Room* temp = roomHead;
        Room* prev = nullptr;
        while (temp != nullptr && temp->number != number) {
            prev = temp;
            temp = temp->next;
        }
        if (temp == nullptr) return;
        if (prev == nullptr) roomHead = temp->next;
        else prev->next = temp->next;
        delete temp;
    }

    void updateRoomStatus(int number, bool isOccupied) {
        Room* temp = roomHead;
        while (temp != nullptr) {
            if (temp->number == number) {
                temp->isOccupied = isOccupied;
                return;
            }
            temp = temp->next;
        }
    }

    Room* searchRoom(int number) {
        Room* temp = roomHead;
        while (temp != nullptr) {
            if (temp->number == number) return temp;
            temp = temp->next;
        }
        return nullptr;
    }

    void displayRooms() {
        Room* temp = roomHead;
        while (temp != nullptr) {
            cout << "Room Number: " << temp->number << ", ";
            cout << "Status: " << (temp->isOccupied ? "Occupied" : "Available") << endl;
            temp = temp->next;
        }
    }

private:
    void clearGuests() {
        while (guestHead != nullptr) {
            Guest* temp = guestHead;
            guestHead = guestHead->next;
            delete temp;
        }
    }

    void clearRooms() {
        while (roomHead != nullptr) {
            Room* temp = roomHead;
            roomHead = roomHead->next;
            delete temp;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(101, "Alice");
    system.addGuest(102, "Bob");
    system.displayGuests();
    system.addRoom(201);
    system.addRoom(202);
    system.displayRooms();
    system.updateRoomStatus(201, true);
    system.displayRooms();
    system.deleteGuest(101);
    system.displayGuests();
    system.deleteRoom(202);
    system.displayRooms();
    return 0;
}