#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Guest {
public:
    int id;
    string name;
    string phone;

    Guest(int id, string name, string phone) : id(id), name(name), phone(phone) {}
};

class Room {
public:
    int roomNumber;
    string type;
    bool isAvailable;

    Room(int roomNumber, string type) : roomNumber(roomNumber), type(type), isAvailable(true) {}
};

class HotelReservationSystem {
private:
    vector<Guest> guests;
    vector<Room> rooms;

    int findGuestIndexById(int id) {
        for (int i = 0; i < guests.size(); i++) {
            if (guests[i].id == id) return i;
        }
        return -1;
    }
    
    int findRoomIndexByNumber(int roomNumber) {
        for (int i = 0; i < rooms.size(); i++) {
            if (rooms[i].roomNumber == roomNumber) return i;
        }
        return -1;
    }

public:
    void addGuest(int id, const string& name, const string& phone) {
        guests.push_back(Guest(id, name, phone));
    }

    void deleteGuest(int id) {
        int index = findGuestIndexById(id);
        if (index != -1) guests.erase(guests.begin() + index);
    }

    void updateGuest(int id, const string& name, const string& phone) {
        int index = findGuestIndexById(id);
        if (index != -1) {
            guests[index].name = name;
            guests[index].phone = phone;
        }
    }

    void searchGuest(int id) {
        int index = findGuestIndexById(id);
        if (index != -1) {
            cout << "Guest Found: ID=" << guests[index].id << ", Name=" << guests[index].name << ", Phone=" << guests[index].phone << endl;
        } else {
            cout << "Guest Not Found" << endl;
        }
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            cout << "ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phone << endl;
        }
    }

    void addRoom(int roomNumber, const string& type) {
        rooms.push_back(Room(roomNumber, type));
    }

    void deleteRoom(int roomNumber) {
        int index = findRoomIndexByNumber(roomNumber);
        if (index != -1) rooms.erase(rooms.begin() + index);
    }

    void updateRoom(int roomNumber, const string& type, bool isAvailable) {
        int index = findRoomIndexByNumber(roomNumber);
        if (index != -1) {
            rooms[index].type = type;
            rooms[index].isAvailable = isAvailable;
        }
    }

    void searchRoom(int roomNumber) {
        int index = findRoomIndexByNumber(roomNumber);
        if (index != -1) {
            cout << "Room Found: Number=" << rooms[index].roomNumber << ", Type=" << rooms[index].type << ", Available=" << (rooms[index].isAvailable ? "Yes" : "No") << endl;
        } else {
            cout << "Room Not Found" << endl;
        }
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            cout << "Room Number: " << room.roomNumber << ", Type: " << room.type << ", Available: " << (room.isAvailable ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelReservationSystem system;

    system.addGuest(1, "John Doe", "123456789");
    system.addGuest(2, "Jane Doe", "987654321");
    system.addRoom(101, "Single");
    system.addRoom(102, "Double");

    system.displayGuests();
    system.displayRooms();

    system.updateGuest(1, "John Smith", "123450987");
    system.updateRoom(101, "Suite", false);

    system.searchGuest(1);
    system.searchRoom(101);

    system.deleteGuest(2);
    system.deleteRoom(102);

    system.displayGuests();
    system.displayRooms();

    return 0;
}