#include <iostream>
#include <vector>
#include <string>

struct Guest {
    int id;
    std::string name;
    std::string contact;
};

struct Room {
    int roomNumber;
    std::string type;
    bool isAvailable;
};

class HotelReservationSystem {
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, const std::string &name, const std::string &contact) {
        guests.push_back({id, name, contact});
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                return;
            }
        }
    }

    void updateGuest(int id, const std::string &name, const std::string &contact) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.contact = contact;
                return;
            }
        }
    }

    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                std::cout << "Guest found: ID=" << guest.id << ", Name=" << guest.name << ", Contact=" << guest.contact << std::endl;
                return;
            }
        }
        std::cout << "Guest not found." << std::endl;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "Guest ID=" << guest.id << ", Name=" << guest.name << ", Contact=" << guest.contact << std::endl;
        }
    }

    void addRoom(int roomNumber, const std::string &type, bool isAvailable) {
        rooms.push_back({roomNumber, type, isAvailable});
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                return;
            }
        }
    }

    void updateRoom(int roomNumber, const std::string &type, bool isAvailable) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.type = type;
                room.isAvailable = isAvailable;
                return;
            }
        }
    }

    void searchRoom(int roomNumber) {
        for (const auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                std::cout << "Room found: Number=" << room.roomNumber << ", Type=" << room.type << ", Available=" << (room.isAvailable ? "Yes" : "No") << std::endl;
                return;
            }
        }
        std::cout << "Room not found." << std::endl;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number=" << room.roomNumber << ", Type=" << room.type << ", Available=" << (room.isAvailable ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe", "123456789");
    system.addGuest(2, "Jane Smith", "987654321");
    system.displayGuests();
    system.searchGuest(1);
    system.updateGuest(1, "John A. Doe", "111222333");
    system.displayGuests();
    system.deleteGuest(2);
    system.displayGuests();

    system.addRoom(101, "Single", true);
    system.addRoom(102, "Double", false);
    system.displayRooms();
    system.searchRoom(101);
    system.updateRoom(101, "Single Deluxe", true);
    system.displayRooms();
    system.deleteRoom(102);
    system.displayRooms();

    return 0;
}