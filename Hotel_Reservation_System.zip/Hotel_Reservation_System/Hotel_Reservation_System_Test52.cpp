#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Guest {
    int id;
    string name;
    string phone;
};

struct Room {
    int number;
    string type;
    bool isOccupied;
};

class HotelReservationSystem {
    vector<Guest> guests;
    vector<Room> rooms;
    
    Guest* findGuest(int id) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    Room* findRoom(int number) {
        for (auto &room : rooms) {
            if (room.number == number) {
                return &room;
            }
        }
        return nullptr;
    }

public:
    void addGuest(int id, string name, string phone) {
        guests.push_back({id, name, phone});
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string name, string phone) {
        Guest* guest = findGuest(id);
        if (guest) {
            guest->name = name;
            guest->phone = phone;
        }
    }

    void searchGuest(int id) {
        Guest* guest = findGuest(id);
        if (guest) {
            cout << "Guest ID: " << guest->id << ", Name: " << guest->name << ", Phone: " << guest->phone << endl;
        } else {
            cout << "Guest not found." << endl;
        }
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phone << endl;
        }
    }

    void addRoom(int number, string type, bool isOccupied) {
        rooms.push_back({number, type, isOccupied});
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, string type, bool isOccupied) {
        Room* room = findRoom(number);
        if (room) {
            room->type = type;
            room->isOccupied = isOccupied;
        }
    }

    void searchRoom(int number) {
        Room* room = findRoom(number);
        if (room) {
            cout << "Room Number: " << room->number << ", Type: " << room->type << ", Occupied: " << (room->isOccupied ? "Yes" : "No") << endl;
        } else {
            cout << "Room not found." << endl;
        }
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            cout << "Room Number: " << room.number << ", Type: " << room.type << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe", "1234567890");
    system.addGuest(2, "Jane Smith", "0987654321");
    system.displayGuests();
    system.addRoom(101, "Single", false);
    system.addRoom(102, "Double", true);
    system.displayRooms();
    system.searchGuest(1);
    system.searchRoom(101);
    system.updateGuest(1, "John A. Doe", "1112223333");
    system.updateRoom(101, "Single", true);
    system.displayGuests();
    system.displayRooms();
    system.deleteGuest(2);
    system.deleteRoom(102);
    system.displayGuests();
    system.displayRooms();
    return 0;
}