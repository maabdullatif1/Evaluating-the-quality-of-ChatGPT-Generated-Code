#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Guest {
public:
    int id;
    string name;
    string phone;
    
    Guest(int gid, string gname, string gphone) : id(gid), name(gname), phone(gphone) {}
};

class Room {
public:
    int room_number;
    string type;
    bool is_reserved;
    
    Room(int rnum, string rtype) : room_number(rnum), type(rtype), is_reserved(false) {}    
};

class HotelSystem {
    vector<Guest> guests;
    vector<Room> rooms;
    
public:
    void addGuest(int id, string name, string phone) {
        guests.push_back(Guest(id, name, phone));
    }
    
    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                return;
            }
        }
    }
    
    void updateGuest(int id, string name, string phone) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.phone = phone;
                return;
            }
        }
    }
    
    Guest* searchGuest(int id) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }
    
    void displayGuests() {
        for (auto& guest : guests) {
            cout << "ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phone << endl;
        }
    }
    
    void addRoom(int room_number, string type) {
        rooms.push_back(Room(room_number, type));
    }
    
    void deleteRoom(int room_number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->room_number == room_number) {
                rooms.erase(it);
                return;
            }
        }
    }
    
    void updateRoom(int room_number, string type, bool is_reserved) {
        for (auto& room : rooms) {
            if (room.room_number == room_number) {
                room.type = type;
                room.is_reserved = is_reserved;
                return;
            }
        }
    }
    
    Room* searchRoom(int room_number) {
        for (auto& room : rooms) {
            if (room.room_number == room_number) {
                return &room;
            }
        }
        return nullptr;
    }
    
    void displayRooms() {
        for (auto& room : rooms) {
            cout << "Room Number: " << room.room_number << ", Type: " << room.type 
                 << ", Reserved: " << (room.is_reserved ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelSystem system;
    
    system.addGuest(1, "John Doe", "555-1234");
    system.addGuest(2, "Jane Smith", "555-5678");
    system.addRoom(101, "Single");
    system.addRoom(102, "Double");

    cout << "Guest List:" << endl;
    system.displayGuests();

    cout << "Room List:" << endl;
    system.displayRooms();
    
    system.updateGuest(1, "Johnny Doe", "555-4321");
    system.updateRoom(101, "Single", true);
    
    cout << "Updated Guest List:" << endl;
    system.displayGuests();
    
    cout << "Updated Room List:" << endl;
    system.displayRooms();
    
    return 0;
}