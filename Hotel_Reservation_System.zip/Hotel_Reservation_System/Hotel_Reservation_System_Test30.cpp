#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Guest {
public:
    int id;
    string name;
    string phoneNumber;

    Guest(int guestId, string guestName, string guestPhoneNumber)
        : id(guestId), name(guestName), phoneNumber(guestPhoneNumber) {}

    void display() const {
        cout << "Guest ID: " << id << ", Name: " << name << ", Phone: " << phoneNumber << endl;
    }
};

class Room {
public:
    int roomNumber;
    string type;
    bool isAvailable;

    Room(int number, string roomType, bool availability)
        : roomNumber(number), type(roomType), isAvailable(availability) {}

    void display() const {
        cout << "Room Number: " << roomNumber << ", Type: " << type << ", Available: " << (isAvailable ? "Yes" : "No") << endl;
    }
};

class HotelReservationSystem {
private:
    vector<Guest> guests;
    vector<Room> rooms;

public:
    void addGuest(int id, string name, string phoneNumber) {
        guests.push_back(Guest(id, name, phoneNumber));
    }

    void deleteGuest(int id) {
        for(auto it = guests.begin(); it != guests.end(); ++it) {
            if(it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string name, string phoneNumber) {
        for(auto& guest : guests) {
            if(guest.id == id) {
                guest.name = name;
                guest.phoneNumber = phoneNumber;
                break;
            }
        }
    }

    void searchGuest(int id) const {
        for(const auto& guest : guests) {
            if(guest.id == id) {
                guest.display();
                return;
            }
        }
        cout << "Guest not found." << endl;
    }

    void displayGuests() const {
        for(const auto& guest : guests) {
            guest.display();
        }
    }

    void addRoom(int number, string type, bool isAvailable) {
        rooms.push_back(Room(number, type, isAvailable));
    }

    void deleteRoom(int number) {
        for(auto it = rooms.begin(); it != rooms.end(); ++it) {
            if(it->roomNumber == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, string type, bool isAvailable) {
        for(auto& room : rooms) {
            if(room.roomNumber == number) {
                room.type = type;
                room.isAvailable = isAvailable;
                break;
            }
        }
    }

    void searchRoom(int number) const {
        for(const auto& room : rooms) {
            if(room.roomNumber == number) {
                room.display();
                return;
            }
        }
        cout << "Room not found." << endl;
    }

    void displayRooms() const {
        for(const auto& room : rooms) {
            room.display();
        }
    }
};

int main() {
    HotelReservationSystem hotel;

    hotel.addGuest(1, "Alice", "123456789");
    hotel.addGuest(2, "Bob", "987654321");
    
    hotel.addRoom(101, "Single", true);
    hotel.addRoom(102, "Double", false);

    cout << "Guests:" << endl;
    hotel.displayGuests();

    cout << "\nRooms:" << endl;
    hotel.displayRooms();

    return 0;
}