#include <iostream>
#include <string>
#include <vector>

class Guest {
public:
    int id;
    std::string name;
    std::string contact;

    Guest(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class Room {
public:
    int roomNumber;
    std::string type;
    bool isAvailable;

    Room(int roomNumber, std::string type, bool isAvailable = true)
        : roomNumber(roomNumber), type(type), isAvailable(isAvailable) {}
};

class HotelManagement {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, std::string name, std::string contact) {
        guests.push_back(Guest(id, name, contact));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, std::string name, std::string contact) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.contact = contact;
                break;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "Guest ID: " << guest.id 
                      << ", Name: " << guest.name 
                      << ", Contact: " << guest.contact << std::endl;
        }
    }

    void addRoom(int roomNumber, std::string type) {
        rooms.push_back(Room(roomNumber, type));
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int roomNumber, std::string type, bool isAvailable) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.type = type;
                room.isAvailable = isAvailable;
                break;
            }
        }
    }

    Room* searchRoom(int roomNumber) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number: " << room.roomNumber 
                      << ", Type: " << room.type 
                      << ", Available: " << (room.isAvailable ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    HotelManagement hotel;

    hotel.addGuest(1, "John Doe", "1234567890");
    hotel.addGuest(2, "Jane Smith", "0987654321");

    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");

    hotel.displayGuests();
    hotel.displayRooms();

    hotel.updateGuest(1, "John D.", "1112223333");
    hotel.updateRoom(101, "Single Deluxe", false);

    hotel.displayGuests();
    hotel.displayRooms();

    return 0;
}