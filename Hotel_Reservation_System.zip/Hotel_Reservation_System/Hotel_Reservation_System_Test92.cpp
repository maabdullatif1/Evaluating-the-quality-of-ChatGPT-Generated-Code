#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Guest {
public:
    int id;
    string name;
    string phone;
    
    Guest(int id, string name, string phone) : id(id), name(name), phone(phone) {}
};

class Room {
public:
    int number;
    string type;
    bool isOccupied;
    
    Room(int number, string type) : number(number), type(type), isOccupied(false) {}
};

class Hotel {
private:
    vector<Guest> guests;
    vector<Room> rooms;

    int findGuestIndexById(int id) {
        for (int i = 0; i < guests.size(); i++) {
            if (guests[i].id == id) {
                return i;
            }
        }
        return -1;
    }

    int findRoomIndexByNumber(int number) {
        for (int i = 0; i < rooms.size(); i++) {
            if (rooms[i].number == number) {
                return i;
            }
        }
        return -1;
    }

public:
    void addGuest(int id, string name, string phone) {
        guests.emplace_back(id, name, phone);
    }

    void deleteGuest(int id) {
        int index = findGuestIndexById(id);
        if (index != -1) {
            guests.erase(guests.begin() + index);
        }
    }

    void updateGuest(int id, string name, string phone) {
        int index = findGuestIndexById(id);
        if (index != -1) {
            guests[index].name = name;
            guests[index].phone = phone;
        }
    }

    void searchGuest(int id) {
        int index = findGuestIndexById(id);
        if (index != -1) {
            cout << "Guest ID: " << guests[index].id << ", Name: " << guests[index].name << ", Phone: " << guests[index].phone << endl;
        } else {
            cout << "Guest not found." << endl;
        }
    }

    void displayAllGuests() {
        for (const auto &guest : guests) {
            cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phone << endl;
        }
    }

    void addRoom(int number, string type) {
        rooms.emplace_back(number, type);
    }

    void deleteRoom(int number) {
        int index = findRoomIndexByNumber(number);
        if (index != -1) {
            rooms.erase(rooms.begin() + index);
        }
    }

    void updateRoom(int number, string type, bool isOccupied) {
        int index = findRoomIndexByNumber(number);
        if (index != -1) {
            rooms[index].type = type;
            rooms[index].isOccupied = isOccupied;
        }
    }

    void searchRoom(int number) {
        int index = findRoomIndexByNumber(number);
        if (index != -1) {
            cout << "Room Number: " << rooms[index].number << ", Type: " << rooms[index].type << ", Occupied: " << (rooms[index].isOccupied ? "Yes" : "No") << endl;
        } else {
            cout << "Room not found." << endl;
        }
    }

    void displayAllRooms() {
        for (const auto &room : rooms) {
            cout << "Room Number: " << room.number << ", Type: " << room.type << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    Hotel hotel;
    hotel.addGuest(1, "Alice", "1234567890");
    hotel.addGuest(2, "Bob", "0987654321");
    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");
    
    cout << "All Guests:" << endl;
    hotel.displayAllGuests();
    
    cout << "All Rooms:" << endl;
    hotel.displayAllRooms();
    
    hotel.updateGuest(1, "Alice Smith", "1112223333");
    hotel.updateRoom(101, "Single Deluxe", true);
    
    cout << "Updated Guest Info:" << endl;
    hotel.searchGuest(1);
    
    cout << "Updated Room Info:" << endl;
    hotel.searchRoom(101);
    
    hotel.deleteGuest(2);
    hotel.deleteRoom(102);
    
    cout << "All Guests After Deletion:" << endl;
    hotel.displayAllGuests();
    
    cout << "All Rooms After Deletion:" << endl;
    hotel.displayAllRooms();
    
    return 0;
}