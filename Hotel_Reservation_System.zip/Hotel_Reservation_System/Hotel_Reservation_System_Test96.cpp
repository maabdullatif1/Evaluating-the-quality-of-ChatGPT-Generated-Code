#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;

    Guest(int guestId, std::string guestName) : id(guestId), name(guestName) {}
};

class Room {
public:
    int number;
    std::string type;

    Room(int roomNumber, std::string roomType) : number(roomNumber), type(roomType) {}
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, std::string name) {
        guests.push_back(Guest(id, name));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, std::string newName) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = newName;
            }
        }
    }

    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << std::endl;
                return;
            }
        }
        std::cout << "Guest not found!" << std::endl;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << std::endl;
        }
    }

    void addRoom(int number, std::string type) {
        rooms.push_back(Room(number, type));
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, std::string newType) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.type = newType;
            }
        }
    }

    void searchRoom(int number) {
        for (const auto &room : rooms) {
            if (room.number == number) {
                std::cout << "Room Number: " << room.number << ", Type: " << room.type << std::endl;
                return;
            }
        }
        std::cout << "Room not found!" << std::endl;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number: " << room.number << ", Type: " << room.type << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe");
    system.addGuest(2, "Jane Smith");
    system.addRoom(101, "Single");
    system.addRoom(102, "Double");

    std::cout << "All Guests:" << std::endl;
    system.displayGuests();

    std::cout << "All Rooms:" << std::endl;
    system.displayRooms();

    std::cout << "Search Guest with ID 1:" << std::endl;
    system.searchGuest(1);

    std::cout << "Update Guest with ID 1:" << std::endl;
    system.updateGuest(1, "John A. Doe");

    std::cout << "All Guests after update:" << std::endl;
    system.displayGuests();

    std::cout << "Delete Guest with ID 2:" << std::endl;
    system.deleteGuest(2);

    std::cout << "All Guests after deletion:" << std::endl;
    system.displayGuests();

    return 0;
}