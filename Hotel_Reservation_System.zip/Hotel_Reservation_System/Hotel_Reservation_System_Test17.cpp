#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    std::string name;
    int id;
    Guest(int _id, std::string _name) : id(_id), name(_name) {}
};

class Room {
public:
    int number;
    bool occupied;
    Room(int _number) : number(_number), occupied(false) {}
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;
public:
    void addGuest(int id, std::string name) {
        guests.push_back(Guest(id, name));
    }
    
    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, std::string newName) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = newName;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                std::cout << "Guest ID: " << guest.id << " Name: " << guest.name << std::endl;
                return;
            }
        }
        std::cout << "Guest not found." << std::endl;
    }

    void displayGuests() {
        for (const auto &guest : guests)
            std::cout << "Guest ID: " << guest.id << " Name: " << guest.name << std::endl;
    }

    void addRoom(int number) {
        rooms.push_back(Room(number));
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, bool occupancy) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.occupied = occupancy;
                break;
            }
        }
    }

    void searchRoom(int number) {
        for (const auto &room : rooms) {
            if (room.number == number) {
                std::cout << "Room Number: " << room.number 
                          << " Occupied: " << (room.occupied ? "Yes" : "No") << std::endl;
                return;
            }
        }
        std::cout << "Room not found." << std::endl;
    }

    void displayRooms() {
        for (const auto &room : rooms)
            std::cout << "Room Number: " << room.number 
                      << " Occupied: " << (room.occupied ? "Yes" : "No") << std::endl;
    }
};

int main() {
    HotelReservationSystem hrs;
    hrs.addGuest(1, "John Doe");
    hrs.addRoom(101);
    hrs.displayGuests();
    hrs.displayRooms();
    hrs.searchGuest(1);
    hrs.updateGuest(1, "Jane Doe");
    hrs.searchGuest(1);
    hrs.updateRoom(101, true);
    hrs.searchRoom(101);
    return 0;
}