#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Guest {
    int id;
    string name;
    string contact;
};

struct Room {
    int number;
    string type;
    bool isOccupied;
};

class Hotel {
    vector<Guest> guests;
    vector<Room> rooms;

    Guest* findGuestById(int id) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    Room* findRoomByNumber(int number) {
        for (auto& room : rooms) {
            if (room.number == number) {
                return &room;
            }
        }
        return nullptr;
    }

public:
    void addGuest(int id, const string& name, const string& contact) {
        guests.push_back({id, name, contact});
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, const string& name, const string& contact) {
        Guest* guest = findGuestById(id);
        if (guest) {
            guest->name = name;
            guest->contact = contact;
        }
    }

    void searchGuest(int id) {
        Guest* guest = findGuestById(id);
        if (guest) {
            cout << "Guest ID: " << guest->id << ", Name: " << guest->name << ", Contact: " << guest->contact << endl;
        } else {
            cout << "Guest not found" << endl;
        }
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Contact: " << guest.contact << endl;
        }
    }

    void addRoom(int number, const string& type, bool isOccupied) {
        rooms.push_back({number, type, isOccupied});
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, const string& type, bool isOccupied) {
        Room* room = findRoomByNumber(number);
        if (room) {
            room->type = type;
            room->isOccupied = isOccupied;
        }
    }

    void searchRoom(int number) {
        Room* room = findRoomByNumber(number);
        if (room) {
            cout << "Room Number: " << room->number << ", Type: " << room->type << ", Occupied: " << (room->isOccupied ? "Yes" : "No") << endl;
        } else {
            cout << "Room not found" << endl;
        }
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            cout << "Room Number: " << room.number << ", Type: " << room.type << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    Hotel hotel;
    hotel.addGuest(1, "John Doe", "123456789");
    hotel.addGuest(2, "Jane Smith", "987654321");
    hotel.addRoom(101, "Single", false);
    hotel.addRoom(102, "Double", true);

    cout << "Guests:" << endl;
    hotel.displayGuests();
    cout << "Rooms:" << endl;
    hotel.displayRooms();

    return 0;
}