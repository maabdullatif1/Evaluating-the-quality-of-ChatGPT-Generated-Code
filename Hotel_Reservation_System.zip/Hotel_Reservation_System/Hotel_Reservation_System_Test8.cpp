#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Guest {
public:
    int id;
    string name;
    string phone;

    Guest(int id, string name, string phone)
        : id(id), name(name), phone(phone) {}
};

class Room {
public:
    int number;
    bool isOccupied;
    int guestId;

    Room(int number, bool isOccupied = false, int guestId = -1)
        : number(number), isOccupied(isOccupied), guestId(guestId) {}
};

class Hotel {
private:
    vector<Guest> guests;
    vector<Room> rooms;

    Guest* findGuestById(int id) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    Room* findRoomByNumber(int number) {
        for (auto &room : rooms) {
            if (room.number == number) {
                return &room;
            }
        }
        return nullptr;
    }

public:
    void addGuest(int id, string name, string phone) {
        guests.emplace_back(id, name, phone);
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string name, string phone) {
        Guest* guest = findGuestById(id);
        if (guest != nullptr) {
            guest->name = name;
            guest->phone = phone;
        }
    }

    void addRoom(int number) {
        rooms.emplace_back(number);
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, bool isOccupied, int guestId) {
        Room* room = findRoomByNumber(number);
        if (room != nullptr) {
            room->isOccupied = isOccupied;
            room->guestId = guestId;
        }
    }

    Guest* searchGuest(int id) {
        return findGuestById(id);
    }

    Room* searchRoom(int number) {
        return findRoomByNumber(number);
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            cout << "ID: " << guest.id << ", Name: " << guest.name 
                 << ", Phone: " << guest.phone << endl;
        }
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            cout << "Room Number: " << room.number << ", Is Occupied: " 
                 << (room.isOccupied ? "Yes" : "No") 
                 << ", Guest ID: " << (room.isOccupied ? to_string(room.guestId) : "N/A") 
                 << endl;
        }
    }
};

int main() {
    Hotel hotel;
    hotel.addGuest(1, "John Doe", "123-456-7890");
    hotel.addGuest(2, "Jane Smith", "987-654-3210");
    hotel.addRoom(101);
    hotel.addRoom(102);
    hotel.updateRoom(101, true, 1);

    cout << "Guests:" << endl;
    hotel.displayGuests();
    cout << "Rooms:" << endl;
    hotel.displayRooms();

    return 0;
}