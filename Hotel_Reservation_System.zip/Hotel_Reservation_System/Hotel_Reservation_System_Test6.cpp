#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;

    Guest(int gid, std::string gname) : id(gid), name(gname) {}
};

class Room {
public:
    int roomNumber;
    std::string type;
    bool isOccupied;

    Room(int rnumber, std::string rtype) : roomNumber(rnumber), type(rtype), isOccupied(false) {}
};

class Hotel {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, std::string name) {
        guests.push_back(Guest(id, name));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                return;
            }
        }
    }

    void updateGuest(int id, std::string newName) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = newName;
                return;
            }
        }
    }

    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << std::endl;
                return;
            }
        }
        std::cout << "Guest not found." << std::endl;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << std::endl;
        }
    }

    void addRoom(int roomNumber, std::string type) {
        rooms.push_back(Room(roomNumber, type));
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                return;
            }
        }
    }

    void updateRoom(int roomNumber, std::string newType) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.type = newType;
                return;
            }
        }
    }

    void searchRoom(int roomNumber) {
        for (const auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                std::cout << "Room Number: " << room.roomNumber << ", Type: " << room.type 
                          << ", Is Occupied: " << room.isOccupied << std::endl;
                return;
            }
        }
        std::cout << "Room not found." << std::endl;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number: " << room.roomNumber << ", Type: " << room.type 
                      << ", Is Occupied: " << room.isOccupied << std::endl;
        }
    }

    void bookRoom(int roomNumber) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                if (!room.isOccupied) {
                    room.isOccupied = true;
                    std::cout << "Room " << roomNumber << " booked." << std::endl;
                } else {
                    std::cout << "Room is already occupied." << std::endl;
                }
                return;
            }
        }
        std::cout << "Room not found." << std::endl;
    }

    void releaseRoom(int roomNumber) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                if (room.isOccupied) {
                    room.isOccupied = false;
                    std::cout << "Room " << roomNumber << " released." << std::endl;
                } else {
                    std::cout << "Room is already free." << std::endl;
                }
                return;
            }
        }
        std::cout << "Room not found." << std::endl;
    }
};

int main() {
    Hotel hotel;
    hotel.addGuest(1, "John Doe");
    hotel.addGuest(2, "Jane Smith");

    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");

    hotel.displayGuests();
    hotel.displayRooms();

    hotel.bookRoom(101);

    hotel.searchGuest(1);
    hotel.searchRoom(101);

    hotel.updateGuest(1, "John A. Doe");
    hotel.updateRoom(101, "Suite");

    hotel.displayGuests();
    hotel.displayRooms();

    hotel.releaseRoom(101);
    hotel.deleteGuest(2);
    hotel.deleteRoom(102);

    hotel.displayGuests();
    hotel.displayRooms();

    return 0;
}