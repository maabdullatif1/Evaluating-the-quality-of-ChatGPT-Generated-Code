#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Guest {
    int id;
    string name;
    string phoneNumber;
};

struct Room {
    int roomNumber;
    string roomType;
    bool isBooked;
};

vector<Guest> guests;
vector<Room> rooms;

int findGuestIndex(int id) {
    for (int i = 0; i < guests.size(); ++i) {
        if (guests[i].id == id) return i;
    }
    return -1;
}

int findRoomIndex(int roomNumber) {
    for (int i = 0; i < rooms.size(); ++i) {
        if (rooms[i].roomNumber == roomNumber) return i;
    }
    return -1;
}

void addGuest() {
    Guest guest;
    cout << "Enter Guest ID: ";
    cin >> guest.id;
    cout << "Enter Guest Name: ";
    cin >> guest.name;
    cout << "Enter Guest Phone Number: ";
    cin >> guest.phoneNumber;
    guests.push_back(guest);
}

void addRoom() {
    Room room;
    cout << "Enter Room Number: ";
    cin >> room.roomNumber;
    cout << "Enter Room Type: ";
    cin >> room.roomType;
    room.isBooked = false;
    rooms.push_back(room);
}

void deleteGuest() {
    int id;
    cout << "Enter Guest ID to delete: ";
    cin >> id;
    int index = findGuestIndex(id);
    if (index != -1) {
        guests.erase(guests.begin() + index);
        cout << "Guest deleted successfully.\n";
    } else {
        cout << "Guest not found.\n";
    }
}

void deleteRoom() {
    int roomNumber;
    cout << "Enter Room Number to delete: ";
    cin >> roomNumber;
    int index = findRoomIndex(roomNumber);
    if (index != -1 && !rooms[index].isBooked) {
        rooms.erase(rooms.begin() + index);
        cout << "Room deleted successfully.\n";
    } else {
        cout << "Room not found or is booked.\n";
    }
}

void updateGuest() {
    int id;
    cout << "Enter Guest ID to update: ";
    cin >> id;
    int index = findGuestIndex(id);
    if (index != -1) {
        cout << "Enter New Guest Name: ";
        cin >> guests[index].name;
        cout << "Enter New Guest Phone Number: ";
        cin >> guests[index].phoneNumber;
    } else {
        cout << "Guest not found.\n";
    }
}

void updateRoom() {
    int roomNumber;
    cout << "Enter Room Number to update: ";
    cin >> roomNumber;
    int index = findRoomIndex(roomNumber);
    if (index != -1) {
        cout << "Enter New Room Type: ";
        cin >> rooms[index].roomType;
    } else {
        cout << "Room not found.\n";
    }
}

void displayGuests() {
    for (const auto& guest : guests) {
        cout << "ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phoneNumber << endl;
    }
}

void displayRooms() {
    for (const auto& room : rooms) {
        cout << "Room Number: " << room.roomNumber << ", Type: " << room.roomType << ", Booked: " << (room.isBooked ? "Yes" : "No") << endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Guest\n2. Add Room\n3. Delete Guest\n4. Delete Room\n5. Update Guest\n6. Update Room\n7. Display Guests\n8. Display Rooms\n9. Exit\nChoose an option: ";
        cin >> choice;
        switch (choice) {
            case 1: addGuest(); break;
            case 2: addRoom(); break;
            case 3: deleteGuest(); break;
            case 4: deleteRoom(); break;
            case 5: updateGuest(); break;
            case 6: updateRoom(); break;
            case 7: displayGuests(); break;
            case 8: displayRooms(); break;
            case 9: return 0;
            default: cout << "Invalid option. Try again.\n"; break;
        }
    }
}