#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Guest {
public:
    int id;
    string name;
    string address;

    Guest(int id, string name, string address)
        : id(id), name(name), address(address) {}
};

class Room {
public:
    int number;
    string type;
    bool isOccupied;

    Room(int number, string type, bool isOccupied)
        : number(number), type(type), isOccupied(isOccupied) {}
};

class HotelReservationSystem {
private:
    vector<Guest> guests;
    vector<Room> rooms;

public:
    void addGuest(int id, string name, string address) {
        guests.push_back(Guest(id, name, address));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string name, string address) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.address = address;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Address: " << guest.address << endl;
                return;
            }
        }
        cout << "Guest not found" << endl;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Address: " << guest.address << endl;
        }
    }

    void addRoom(int number, string type, bool isOccupied) {
        rooms.push_back(Room(number, type, isOccupied));
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, string type, bool isOccupied) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.type = type;
                room.isOccupied = isOccupied;
                break;
            }
        }
    }

    void searchRoom(int number) {
        for (const auto &room : rooms) {
            if (room.number == number) {
                cout << "Room Number: " << room.number << ", Type: " << room.type << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Room not found" << endl;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            cout << "Room Number: " << room.number << ", Type: " << room.type << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelReservationSystem system;

    system.addGuest(1, "John Doe", "123 Main St");
    system.addGuest(2, "Jane Smith", "456 Elm St");

    system.addRoom(101, "Single", false);
    system.addRoom(102, "Double", true);

    system.displayGuests();
    system.displayRooms();

    system.searchGuest(1);
    system.searchRoom(101);

    system.updateGuest(1, "John Doe", "789 Oak St");
    system.updateRoom(102, "Suite", false);

    system.displayGuests();
    system.displayRooms();

    system.deleteGuest(2);
    system.deleteRoom(101);

    system.displayGuests();
    system.displayRooms();

    return 0;
}