#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;
    std::string email;

    Guest(int id, std::string name, std::string email) : id(id), name(name), email(email) {}
};

class Room {
public:
    int roomNumber;
    std::string type;
    bool isBooked;

    Room(int roomNumber, std::string type) : roomNumber(roomNumber), type(type), isBooked(false) {}
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, std::string name, std::string email) {
        guests.push_back(Guest(id, name, email));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, std::string name, std::string email) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.email = email;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                std::cout << "Guest Found: " << guest.name << ", " << guest.email << std::endl;
                return;
            }
        }
        std::cout << "Guest not found" << std::endl;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "ID: " << guest.id << ", Name: " << guest.name << ", Email: " << guest.email << std::endl;
        }
    }

    void addRoom(int roomNumber, std::string type) {
        rooms.push_back(Room(roomNumber, type));
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int roomNumber, std::string type, bool isBooked) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.type = type;
                room.isBooked = isBooked;
                break;
            }
        }
    }

    void searchRoom(int roomNumber) {
        for (const auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                std::cout << "Room Found: " << room.type << ", Booked: " << (room.isBooked ? "Yes" : "No") << std::endl;
                return;
            }
        }
        std::cout << "Room not found" << std::endl;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number: " << room.roomNumber << ", Type: " << room.type << ", Booked: " << (room.isBooked ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem hotel;

    hotel.addGuest(1, "John Doe", "john@example.com");
    hotel.addGuest(2, "Jane Doe", "jane@example.com");

    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");

    hotel.displayGuests();
    hotel.displayRooms();

    return 0;
}