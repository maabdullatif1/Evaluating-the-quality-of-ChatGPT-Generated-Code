#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int guestID;
    std::string name;
    std::string phone;
    Guest(int id, std::string n, std::string p) : guestID(id), name(n), phone(p) {}
};

class Room {
public:
    int roomNumber;
    std::string type;
    bool isOccupied;
    Room(int number, std::string t, bool occupied = false) : roomNumber(number), type(t), isOccupied(occupied) {}
};

class Hotel {
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, std::string name, std::string phone) {
        guests.push_back(Guest(id, name, phone));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->guestID == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, std::string name, std::string phone) {
        for (auto &guest : guests) {
            if (guest.guestID == id) {
                guest.name = name;
                guest.phone = phone;
                break;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto &guest : guests) {
            if (guest.guestID == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "Guest ID: " << guest.guestID << ", Name: " << guest.name << ", Phone: " << guest.phone << std::endl;
        }
    }

    void addRoom(int number, std::string type, bool isOccupied = false) {
        rooms.push_back(Room(number, type, isOccupied));
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, std::string type, bool isOccupied) {
        for (auto &room : rooms) {
            if (room.roomNumber == number) {
                room.type = type;
                room.isOccupied = isOccupied;
                break;
            }
        }
    }

    Room* searchRoom(int number) {
        for (auto &room : rooms) {
            if (room.roomNumber == number) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number: " << room.roomNumber << ", Type: " << room.type
                      << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    Hotel hotel;

    hotel.addGuest(1, "John Doe", "123-456-7890");
    hotel.addGuest(2, "Jane Smith", "987-654-3210");
    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");

    hotel.displayGuests();
    hotel.displayRooms();

    Guest *guest = hotel.searchGuest(1);
    if (guest) std::cout << "Found Guest: " << guest->name << std::endl;

    Room *room = hotel.searchRoom(102);
    if (room) std::cout << "Found Room Number: " << room->roomNumber << std::endl;

    return 0;
}