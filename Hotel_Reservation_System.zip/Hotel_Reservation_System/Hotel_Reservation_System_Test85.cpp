#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Guest {
    int id;
    string name;
    int roomNumber;
};

struct Room {
    int number;
    bool isAvailable;
};

class Hotel {
private:
    vector<Guest> guests;
    vector<Room> rooms;

    Guest* findGuestById(int id) {
        for (auto & guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    Room* findRoomByNumber(int number) {
        for (auto & room : rooms) {
            if (room.number == number) {
                return &room;
            }
        }
        return nullptr;
    }

public:
    void addGuest(int id, const string &name, int roomNumber) {
        Room* room = findRoomByNumber(roomNumber);
        if (room && room->isAvailable) {
            guests.push_back({id, name, roomNumber});
            room->isAvailable = false;
        }
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                Room* room = findRoomByNumber(it->roomNumber);
                if (room) {
                    room->isAvailable = true;
                }
                guests.erase(it);
                return;
            }
        }
    }

    void updateGuest(int id, const string &newName, int newRoomNumber) {
        Guest* guest = findGuestById(id);
        if (guest) {
            if (guest->roomNumber != newRoomNumber) {
                Room* currentRoom = findRoomByNumber(guest->roomNumber);
                Room* newRoom = findRoomByNumber(newRoomNumber);
                if (newRoom && newRoom->isAvailable) {
                    if (currentRoom) {
                        currentRoom->isAvailable = true;
                    }
                    guest->roomNumber = newRoomNumber;
                    newRoom->isAvailable = false;
                }
            }
            guest->name = newName;
        }
    }

    Guest* searchGuest(int id) {
        return findGuestById(id);
    }

    void addRoom(int number) {
        rooms.push_back({number, true});
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            cout << "ID: " << guest.id << ", Name: " << guest.name << ", Room: " << guest.roomNumber << endl;
        }
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            cout << "Room Number: " << room.number << ", Available: " << (room.isAvailable ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    Hotel hotel;
    hotel.addRoom(101);
    hotel.addRoom(102);
    hotel.addRoom(103);

    hotel.addGuest(1, "John Doe", 101);
    hotel.addGuest(2, "Jane Smith", 102);

    hotel.updateGuest(1, "John Doe Jr.", 103);

    hotel.displayGuests();
    hotel.displayRooms();

    hotel.deleteGuest(2);
    hotel.displayGuests();
    hotel.displayRooms();
    
    return 0;
}