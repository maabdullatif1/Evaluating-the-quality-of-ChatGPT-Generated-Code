#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Room {
public:
    int roomNumber;
    string type;
    bool isAvailable;

    Room(int number, const string& roomType, bool available)
        : roomNumber(number), type(roomType), isAvailable(available) {}
};

class Guest {
public:
    string name;
    int age;
    string phone;

    Guest(const string& guestName, int guestAge, const string& phoneNumber)
        : name(guestName), age(guestAge), phone(phoneNumber) {}
};

class Hotel {
private:
    vector<Room> rooms;
    vector<Guest> guests;

public:
    void addRoom(int roomNumber, const string& type);
    bool deleteRoom(int roomNumber);
    bool updateRoom(int roomNumber, const string& newType, bool isAvailable);
    Room* searchRoom(int roomNumber);
    void displayRooms();

    void addGuest(const string& name, int age, const string& phone);
    bool deleteGuest(const string& name);
    bool updateGuest(const string& name, int age, const string& phone);
    Guest* searchGuest(const string& name);
    void displayGuests();
};

void Hotel::addRoom(int roomNumber, const string& type) {
    rooms.push_back(Room(roomNumber, type, true));
}

bool Hotel::deleteRoom(int roomNumber) {
    for (auto it = rooms.begin(); it != rooms.end(); ++it) {
        if (it->roomNumber == roomNumber) {
            rooms.erase(it);
            return true;
        }
    }
    return false;
}

bool Hotel::updateRoom(int roomNumber, const string& newType, bool isAvailable) {
    for (auto& room : rooms) {
        if (room.roomNumber == roomNumber) {
            room.type = newType;
            room.isAvailable = isAvailable;
            return true;
        }
    }
    return false;
}

Room* Hotel::searchRoom(int roomNumber) {
    for (auto& room : rooms) {
        if (room.roomNumber == roomNumber) {
            return &room;
        }
    }
    return nullptr;
}

void Hotel::displayRooms() {
    for (const auto& room : rooms) {
        cout << "Room Number: " << room.roomNumber
             << ", Type: " << room.type
             << ", Available: " << (room.isAvailable ? "Yes" : "No") << endl;
    }
}

void Hotel::addGuest(const string& name, int age, const string& phone) {
    guests.push_back(Guest(name, age, phone));
}

bool Hotel::deleteGuest(const string& name) {
    for (auto it = guests.begin(); it != guests.end(); ++it) {
        if (it->name == name) {
            guests.erase(it);
            return true;
        }
    }
    return false;
}

bool Hotel::updateGuest(const string& name, int age, const string& phone) {
    for (auto& guest : guests) {
        if (guest.name == name) {
            guest.age = age;
            guest.phone = phone;
            return true;
        }
    }
    return false;
}

Guest* Hotel::searchGuest(const string& name) {
    for (auto& guest : guests) {
        if (guest.name == name) {
            return &guest;
        }
    }
    return nullptr;
}

void Hotel::displayGuests() {
    for (const auto& guest : guests) {
        cout << "Name: " << guest.name
             << ", Age: " << guest.age
             << ", Phone: " << guest.phone << endl;
    }
}

int main() {
    Hotel hotel;
    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");
    hotel.addGuest("John Doe", 35, "123456789");

    cout << "Rooms available:" << endl;
    hotel.displayRooms();
    cout << "\nGuests:" << endl;
    hotel.displayGuests();

    return 0;
}