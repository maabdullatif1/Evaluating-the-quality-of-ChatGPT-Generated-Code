#include <iostream>
#include <string>
#include <vector>

struct Guest {
    int id;
    std::string name;
};

struct Room {
    int number;
    std::string type;
    bool isOccupied;
    int guestId; // -1 if no guest is staying
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;
    int nextGuestId = 1;

public:
    void addGuest(const std::string& name) {
        guests.push_back({nextGuestId++, name});
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, const std::string& newName) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                guest.name = newName;
                break;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << std::endl;
        }
    }

    void addRoom(int number, const std::string& type) {
        rooms.push_back({number, type, false, -1});
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, const std::string& newType) {
        for (auto& room : rooms) {
            if (room.number == number) {
                room.type = newType;
                break;
            }
        }
    }

    Room* searchRoom(int number) {
        for (auto& room : rooms) {
            if (room.number == number) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            std::cout << "Room Number: " << room.number 
                      << ", Type: " << room.type 
                      << ", Occupied: " << (room.isOccupied ? "Yes" : "No") 
                      << ", Guest ID: " << room.guestId << std::endl;
        }
    }

    bool checkIn(int roomNumber, int guestId) {
        Room* room = searchRoom(roomNumber);
        Guest* guest = searchGuest(guestId);
        if (room && guest && !room->isOccupied) {
            room->isOccupied = true;
            room->guestId = guestId;
            return true;
        }
        return false;
    }

    bool checkOut(int roomNumber) {
        Room* room = searchRoom(roomNumber);
        if (room && room->isOccupied) {
            room->isOccupied = false;
            room->guestId = -1;
            return true;
        }
        return false;
    }
};

int main() {
    HotelReservationSystem system;
    
    system.addGuest("John Doe");
    system.addGuest("Jane Smith");

    system.addRoom(101, "Single");
    system.addRoom(102, "Double");

    system.displayGuests();
    system.displayRooms();

    system.checkIn(101, 1);

    system.displayRooms();

    system.checkOut(101);

    system.displayRooms();

    return 0;
}