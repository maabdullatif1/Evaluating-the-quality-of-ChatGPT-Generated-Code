#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    std::string name;
    int id;
    Guest(int i, std::string n) : id(i), name(n) {}
};

class Room {
public:
    int number;
    bool isOccupied;
    Room(int num) : number(num), isOccupied(false) {}
};

class HotelReservationSystem {
    std::vector<Guest> guests;
    std::vector<Room> rooms;

    void displayGuests() {
        for (auto &guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << std::endl;
        }
    }

    void displayRooms() {
        for (auto &room : rooms) {
            std::cout << "Room Number: " << room.number << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
        }
    }

public:
    void addGuest(int id, std::string name) {
        guests.push_back(Guest(id, name));
    }

    void deleteGuest(int id) {
        guests.erase(std::remove_if(guests.begin(), guests.end(), [&](Guest &g) { return g.id == id; }), guests.end());
    }

    void updateGuest(int id, std::string newName) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = newName;
                return;
            }
        }
    }

    void addRoom(int number) {
        rooms.push_back(Room(number));
    }

    void deleteRoom(int number) {
        rooms.erase(std::remove_if(rooms.begin(), rooms.end(), [&](Room &r) { return r.number == number; }), rooms.end());
    }

    void updateRoomStatus(int number, bool isOccupied) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.isOccupied = isOccupied;
                return;
            }
        }
    }

    void searchGuest(int id) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                std::cout << "Found Guest - ID: " << guest.id << ", Name: " << guest.name << std::endl;
                return;
            }
        }
        std::cout << "Guest not found." << std::endl;
    }

    void searchRoom(int number) {
        for (auto &room : rooms) {
            if (room.number == number) {
                std::cout << "Found Room - Number: " << room.number << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
                return;
            }
        }
        std::cout << "Room not found." << std::endl;
    }

    void display() {
        std::cout << "Guests:" << std::endl;
        displayGuests();
        std::cout << "Rooms:" << std::endl;
        displayRooms();
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe");
    system.addGuest(2, "Jane Smith");
    system.addRoom(101);
    system.addRoom(102);
    system.updateRoomStatus(101, true);
    system.display();
    system.searchGuest(1);
    system.searchRoom(102);
    system.updateGuest(1, "Johnny Doe");
    system.display();
    system.deleteGuest(1);
    system.deleteRoom(102);
    system.display();
    return 0;
}