#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Guest {
public:
    int id;
    string name;
    string email;

    Guest(int id, string name, string email) : id(id), name(name), email(email) {}
};

class Room {
public:
    int number;
    string type;
    bool isAvailable;

    Room(int number, string type, bool isAvailable) : number(number), type(type), isAvailable(isAvailable) {}
};

class HotelReservationSystem {
private:
    vector<Guest> guests;
    vector<Room> rooms;

public:
    void addGuest(int id, string name, string email) {
        guests.push_back(Guest(id, name, email));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string name, string email) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.email = email;
            }
        }
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Email: " << guest.email << endl;
        }
    }

    void addRoom(int number, string type, bool isAvailable) {
        rooms.push_back(Room(number, type, isAvailable));
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, string type, bool isAvailable) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.type = type;
                room.isAvailable = isAvailable;
            }
        }
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            cout << "Room Number: " << room.number << ", Type: " << room.type 
                 << ", Availability: " << (room.isAvailable ? "Yes" : "No") << endl;
        }
    }

    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Email: " << guest.email << endl;
                return;
            }
        }
        cout << "Guest not found!" << endl;
    }

    void searchRoom(int number) {
        for (const auto &room : rooms) {
            if (room.number == number) {
                cout << "Room Number: " << room.number << ", Type: " << room.type 
                     << ", Availability: " << (room.isAvailable ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Room not found!" << endl;
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe", "john@example.com");
    system.addGuest(2, "Jane Smith", "jane@example.com");
    system.addRoom(101, "Single", true);
    system.addRoom(102, "Double", false);

    cout << "-- Display Guests --" << endl;
    system.displayGuests();

    cout << "-- Display Rooms --" << endl;
    system.displayRooms();

    cout << "-- Search Guest with ID 1 --" << endl;
    system.searchGuest(1);

    cout << "-- Search Room with Number 101 --" << endl;
    system.searchRoom(101);
    
    return 0;
}