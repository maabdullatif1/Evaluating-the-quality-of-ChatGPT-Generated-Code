#include <iostream>
#include <string>

using namespace std;

struct Room {
    int roomNumber;
    string type;
    bool isAvailable;
};

struct Guest {
    string name;
    int roomNumber;
};

const int MAX_ROOMS = 100;
const int MAX_GUESTS = 100;
Room rooms[MAX_ROOMS];
Guest guests[MAX_GUESTS];
int roomCount = 0;
int guestCount = 0;

void addRoom(int number, string type) {
    if(roomCount < MAX_ROOMS) {
        rooms[roomCount].roomNumber = number;
        rooms[roomCount].type = type;
        rooms[roomCount].isAvailable = true;
        roomCount++;
    }
}

void addGuest(string name, int roomNumber) {
    if(guestCount < MAX_GUESTS) {
        guests[guestCount].name = name;
        guests[guestCount].roomNumber = roomNumber;
        for(int i = 0; i < roomCount; i++) {
            if(rooms[i].roomNumber == roomNumber) {
                rooms[i].isAvailable = false;
                break;
            }
        }
        guestCount++;
    }
}

void deleteGuest(string name) {
    for(int i = 0; i < guestCount; i++) {
        if(guests[i].name == name) {
            for(int j = 0; j < roomCount; j++) {
                if(rooms[j].roomNumber == guests[i].roomNumber) {
                    rooms[j].isAvailable = true;
                    break;
                }
            }
            for(int k = i; k < guestCount - 1; k++) {
                guests[k] = guests[k + 1];
            }
            guestCount--;
            break;
        }
    }
}

void updateGuest(string name, string newName, int newRoomNumber) {
    for(int i = 0; i < guestCount; i++) {
        if(guests[i].name == name) {
            for(int j = 0; j < roomCount; j++) {
                if(rooms[j].roomNumber == guests[i].roomNumber) {
                    rooms[j].isAvailable = true;
                    break;
                }
            }
            guests[i].name = newName;
            guests[i].roomNumber = newRoomNumber;
            for(int j = 0; j < roomCount; j++) {
                if(rooms[j].roomNumber == newRoomNumber) {
                    rooms[j].isAvailable = false;
                    break;
                }
            }
            break;
        }
    }
}

void searchGuest(string name) {
    for(int i = 0; i < guestCount; i++) {
        if(guests[i].name == name) {
            cout << "Guest found: " << guests[i].name
                 << ", Room Number: " << guests[i].roomNumber << endl;
            return;
        }
    }
    cout << "Guest not found" << endl;
}

void searchRoom(int roomNumber) {
    for(int i = 0; i < roomCount; i++) {
        if(rooms[i].roomNumber == roomNumber) {
            cout << "Room Number: " << rooms[i].roomNumber
                 << ", Type: " << rooms[i].type
                 << ", Available: " << (rooms[i].isAvailable ? "Yes" : "No") << endl;
            return;
        }
    }
    cout << "Room not found" << endl;
}

void displayGuests() {
    for(int i = 0; i < guestCount; i++) {
        cout << "Guest: " << guests[i].name
             << ", Room Number: " << guests[i].roomNumber << endl;
    }
}

void displayRooms() {
    for(int i = 0; i < roomCount; i++) {
        cout << "Room Number: " << rooms[i].roomNumber
             << ", Type: " << rooms[i].type
             << ", Available: " << (rooms[i].isAvailable ? "Yes" : "No") << endl;
    }
}

int main() {
    addRoom(101, "Single");
    addRoom(102, "Double");
    addGuest("John Doe", 101);
    displayGuests();
    displayRooms();
    updateGuest("John Doe", "Jane Doe", 102);
    searchGuest("Jane Doe");
    deleteGuest("Jane Doe");
    displayGuests();
    return 0;
}