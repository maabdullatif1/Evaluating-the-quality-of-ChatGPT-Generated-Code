#include <iostream>
#include <vector>
#include <string>

class Room {
public:
    int roomNumber;
    bool isAvailable;

    Room(int num) : roomNumber(num), isAvailable(true) {}
};

class Guest {
public:
    std::string name;
    int roomNumber;

    Guest(const std::string& n, int num) : name(n), roomNumber(num) {}
};

class HotelReservationSystem {
private:
    std::vector<Room> rooms;
    std::vector<Guest> guests;

    Room* findRoom(int roomNumber) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                return &room;
            }
        }
        return nullptr;
    }

    Guest* findGuest(const std::string& name) {
        for (auto& guest : guests) {
            if (guest.name == name) {
                return &guest;
            }
        }
        return nullptr;
    }

public:
    void addRoom(int roomNumber) {
        if (!findRoom(roomNumber)) {
            rooms.emplace_back(roomNumber);
        }
    }

    void deleteRoom(int roomNumber) {
        rooms.erase(std::remove_if(rooms.begin(), rooms.end(),
                                   [&roomNumber](Room& r) { return r.roomNumber == roomNumber; }),
                    rooms.end());
    }

    void updateRoom(int oldRoomNumber, int newRoomNumber) {
        Room* room = findRoom(oldRoomNumber);
        if (room) {
            room->roomNumber = newRoomNumber;
        }
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            std::cout << "Room: " << room.roomNumber << ", "
                      << (room.isAvailable ? "Available" : "Occupied") << std::endl;
        }
    }

    void addGuest(const std::string& name, int roomNumber) {
        Room* room = findRoom(roomNumber);
        if (room && room->isAvailable && !findGuest(name)) {
            guests.emplace_back(name, roomNumber);
            room->isAvailable = false;
        }
    }

    void deleteGuest(const std::string& name) {
        auto it = std::remove_if(guests.begin(), guests.end(), [&name](Guest& g) { return g.name == name; });
        if (it != guests.end()) {
            Room* room = findRoom(it->roomNumber);
            if (room) {
                room->isAvailable = true;
            }
            guests.erase(it, guests.end());
        }
    }

    void updateGuest(const std::string& name, const std::string& newName, int newRoomNumber) {
        Guest* guest = findGuest(name);
        if (guest) {
            Room* oldRoom = findRoom(guest->roomNumber);
            Room* newRoom = findRoom(newRoomNumber);
            if (oldRoom) {
                oldRoom->isAvailable = true;
            }
            if (newRoom && newRoom->isAvailable) {
                newRoom->isAvailable = false;
                guest->name = newName;
                guest->roomNumber = newRoomNumber;
            }
        }
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            std::cout << "Guest: " << guest.name << ", Room: " << guest.roomNumber << std::endl;
        }
    }

    void searchGuest(const std::string& name) {
        Guest* guest = findGuest(name);
        if (guest) {
            std::cout << "Found Guest: " << guest->name << ", Room: " << guest->roomNumber << std::endl;
        } else {
            std::cout << "Guest not found" << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem hotel;

    hotel.addRoom(101);
    hotel.addRoom(102);
    hotel.addGuest("Alice", 101);
    hotel.displayRooms();
    hotel.displayGuests();
    hotel.searchGuest("Alice");
    hotel.updateGuest("Alice", "Alicia", 102);
    hotel.displayGuests();
    hotel.deleteGuest("Alicia");
    hotel.displayGuests();
    hotel.displayRooms();
    
    return 0;
}