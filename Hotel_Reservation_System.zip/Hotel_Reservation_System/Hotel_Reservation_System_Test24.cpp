#include <iostream>
#include <string>

using namespace std;

struct Guest {
    int id;
    string name;
    string email;
};

struct Room {
    int number;
    string type;
    bool isOccupied;
};

class Hotel {
    Guest guests[100];
    Room rooms[100];
    int guestCount;
    int roomCount;

public:
    Hotel() : guestCount(0), roomCount(0) {}

    void addGuest() {
        if (guestCount < 100) {
            cout << "Enter Guest ID, Name, Email: ";
            cin >> guests[guestCount].id >> guests[guestCount].name >> guests[guestCount].email;
            guestCount++;
        } else {
            cout << "Max guests reached!" << endl;
        }
    }

    void addRoom() {
        if (roomCount < 100) {
            cout << "Enter Room Number, Type (e.g., Single, Double): ";
            cin >> rooms[roomCount].number >> rooms[roomCount].type;
            rooms[roomCount].isOccupied = false;
            roomCount++;
        } else {
            cout << "Max rooms reached!" << endl;
        }
    }

    void deleteGuest() {
        int id;
        cout << "Enter Guest ID to delete: ";
        cin >> id;
        for (int i = 0; i < guestCount; i++) {
            if (guests[i].id == id) {
                for (int j = i; j < guestCount - 1; j++) {
                    guests[j] = guests[j + 1];
                }
                guestCount--;
                cout << "Guest Deleted!" << endl;
                return;
            }
        }
        cout << "Guest not found!" << endl;
    }

    void deleteRoom() {
        int number;
        cout << "Enter Room Number to delete: ";
        cin >> number;
        for (int i = 0; i < roomCount; i++) {
            if (rooms[i].number == number) {
                for (int j = i; j < roomCount - 1; j++) {
                    rooms[j] = rooms[j + 1];
                }
                roomCount--;
                cout << "Room Deleted!" << endl;
                return;
            }
        }
        cout << "Room not found!" << endl;
    }

    void updateGuest() {
        int id;
        cout << "Enter Guest ID to update: ";
        cin >> id;
        for (int i = 0; i < guestCount; i++) {
            if (guests[i].id == id) {
                cout << "Enter new Name and Email: ";
                cin >> guests[i].name >> guests[i].email;
                cout << "Guest Updated!" << endl;
                return;
            }
        }
        cout << "Guest not found!" << endl;
    }

    void updateRoom() {
        int number;
        cout << "Enter Room Number to update: ";
        cin >> number;
        for (int i = 0; i < roomCount; i++) {
            if (rooms[i].number == number) {
                cout << "Enter new Type and Occupancy (0 or 1): ";
                cin >> rooms[i].type >> rooms[i].isOccupied;
                cout << "Room Updated!" << endl;
                return;
            }
        }
        cout << "Room not found!" << endl;
    }

    void searchGuest() {
        int id;
        cout << "Enter Guest ID to search: ";
        cin >> id;
        for (int i = 0; i < guestCount; i++) {
            if (guests[i].id == id) {
                cout << "Guest Found: " << guests[i].name << ", " << guests[i].email << endl;
                return;
            }
        }
        cout << "Guest not found!" << endl;
    }

    void searchRoom() {
        int number;
        cout << "Enter Room Number to search: ";
        cin >> number;
        for (int i = 0; i < roomCount; i++) {
            if (rooms[i].number == number) {
                cout << "Room Found: " << rooms[i].type << ", Occupied: " << (rooms[i].isOccupied ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Room not found!" << endl;
    }

    void displayGuests() {
        cout << "List of Guests:" << endl;
        for (int i = 0; i < guestCount; i++) {
            cout << guests[i].id << ": " << guests[i].name << ", " << guests[i].email << endl;
        }
    }

    void displayRooms() {
        cout << "List of Rooms:" << endl;
        for (int i = 0; i < roomCount; i++) {
            cout << rooms[i].number << ": " << rooms[i].type << ", Occupied: " << (rooms[i].isOccupied ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    Hotel hotel;
    int choice;

    while (true) {
        cout << "1. Add Guest\n2. Add Room\n3. Delete Guest\n4. Delete Room\n5. Update Guest\n6. Update Room\n7. Search Guest\n8. Search Room\n9. Display Guests\n10. Display Rooms\n0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1: hotel.addGuest(); break;
            case 2: hotel.addRoom(); break;
            case 3: hotel.deleteGuest(); break;
            case 4: hotel.deleteRoom(); break;
            case 5: hotel.updateGuest(); break;
            case 6: hotel.updateRoom(); break;
            case 7: hotel.searchGuest(); break;
            case 8: hotel.searchRoom(); break;
            case 9: hotel.displayGuests(); break;
            case 10: hotel.displayRooms(); break;
            case 0: return 0;
            default: cout << "Invalid choice!" << endl;
        }
    }
}