#include <iostream>
#include <vector>
#include <string>

struct Guest {
    int id;
    std::string name;
    std::string phone;
};

struct Room {
    int roomNumber;
    std::string type;
    bool available;
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, const std::string& name, const std::string& phone) {
        guests.push_back({id, name, phone});
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                return;
            }
        }
    }

    void updateGuest(int id, const std::string& name, const std::string& phone) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.phone = phone;
                return;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayGuests() const {
        for (const auto& guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name 
                      << ", Phone: " << guest.phone << std::endl;
        }
    }

    void addRoom(int roomNumber, const std::string& type, bool available) {
        rooms.push_back({roomNumber, type, available});
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                return;
            }
        }
    }

    void updateRoom(int roomNumber, const std::string& type, bool available) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.type = type;
                room.available = available;
                return;
            }
        }
    }

    Room* searchRoom(int roomNumber) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayRooms() const {
        for (const auto& room : rooms) {
            std::cout << "Room Number: " << room.roomNumber << ", Type: " 
                      << room.type << ", Available: " << (room.available ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem hotel;

    hotel.addGuest(1, "John Doe", "123-456-7890");
    hotel.addGuest(2, "Jane Smith", "098-765-4321");
    hotel.addRoom(101, "Single", true);
    hotel.addRoom(102, "Double", false);

    std::cout << "Guests:\n";
    hotel.displayGuests();
    
    std::cout << "\nRooms:\n";
    hotel.displayRooms();
    
    hotel.updateGuest(1, "John Doe Jr.", "321-654-0987");
    hotel.updateRoom(101, "Single", false);

    std::cout << "\nUpdated Guests:\n";
    hotel.displayGuests();

    std::cout << "\nUpdated Rooms:\n";
    hotel.displayRooms();

    hotel.deleteGuest(2);
    hotel.deleteRoom(102);

    std::cout << "\nGuests after deletion:\n";
    hotel.displayGuests();
    
    std::cout << "\nRooms after deletion:\n";
    hotel.displayRooms();

    return 0;
}