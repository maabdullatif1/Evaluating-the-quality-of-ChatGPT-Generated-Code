#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;
    std::string phone;

    Guest(int id, std::string name, std::string phone) : id(id), name(name), phone(phone) {}
};

class Room {
public:
    int number;
    std::string type;
    bool isOccupied;

    Room(int number, std::string type, bool isOccupied) : number(number), type(type), isOccupied(isOccupied) {}
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, std::string name, std::string phone) {
        guests.push_back(Guest(id, name, phone));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, std::string name, std::string phone) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.phone = phone;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for (const auto& guest : guests) {
            if (guest.id == id) {
                std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phone << std::endl;
            }
        }
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phone << std::endl;
        }
    }

    void addRoom(int number, std::string type, bool isOccupied) {
        rooms.push_back(Room(number, type, isOccupied));
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, std::string type, bool isOccupied) {
        for (auto& room : rooms) {
            if (room.number == number) {
                room.type = type;
                room.isOccupied = isOccupied;
                break;
            }
        }
    }

    void searchRoom(int number) {
        for (const auto& room : rooms) {
            if (room.number == number) {
                std::cout << "Room Number: " << room.number << ", Type: " << room.type << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
            }
        }
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            std::cout << "Room Number: " << room.number << ", Type: " << room.type << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem hotel;
    hotel.addGuest(1, "Alice", "123456");
    hotel.addGuest(2, "Bob", "654321");

    hotel.addRoom(101, "Single", false);
    hotel.addRoom(102, "Double", true);

    std::cout << "Guests:" << std::endl;
    hotel.displayGuests();

    std::cout << "Rooms:" << std::endl;
    hotel.displayRooms();

    hotel.updateGuest(1, "Alice Smith", "000000");
    hotel.updateRoom(101, "Single", true);

    std::cout << "Updated Guests:" << std::endl;
    hotel.displayGuests();

    std::cout << "Updated Rooms:" << std::endl;
    hotel.displayRooms();

    hotel.searchGuest(2);
    hotel.searchRoom(102);

    hotel.deleteGuest(1);
    hotel.deleteRoom(101);

    std::cout << "After Deletion:" << std::endl;
    std::cout << "Guests:" << std::endl;
    hotel.displayGuests();
    std::cout << "Rooms:" << std::endl;
    hotel.displayRooms();

    return 0;
}