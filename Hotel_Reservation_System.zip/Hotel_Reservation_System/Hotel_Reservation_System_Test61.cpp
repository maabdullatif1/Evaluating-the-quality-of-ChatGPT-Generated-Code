#include <iostream>
#include <vector>
#include <string>

class Room {
public:
    int roomNumber;
    std::string roomType;
    bool isAvailable;

    Room(int num, std::string type, bool available)
        : roomNumber(num), roomType(type), isAvailable(available) {}
};

class Guest {
public:
    int id;
    std::string name;
    int roomNumber;

    Guest(int guestId, std::string guestName, int roomNum)
        : id(guestId), name(guestName), roomNumber(roomNum) {}
};

class HotelSystem {
private:
    std::vector<Room> rooms;
    std::vector<Guest> guests;

public:
    void addRoom(int roomNumber, std::string roomType) {
        rooms.push_back(Room(roomNumber, roomType, true));
    }

    void addGuest(int guestId, std::string guestName, int roomNumber) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber && room.isAvailable) {
                room.isAvailable = false;
                guests.push_back(Guest(guestId, guestName, roomNumber));
                break;
            }
        }
    }

    void deleteGuest(int guestId) {
        for (size_t i = 0; i < guests.size(); ++i) {
            if (guests[i].id == guestId) {
                for (auto &room : rooms) {
                    if (room.roomNumber == guests[i].roomNumber) {
                        room.isAvailable = true;
                    }
                }
                guests.erase(guests.begin() + i);
                break;
            }
        }
    }

    void updateGuest(int guestId, std::string newName, int newRoomNumber) {
        for (auto &guest : guests) {
            if (guest.id == guestId) {
                for (auto &room : rooms) {
                    if (room.roomNumber == guest.roomNumber) {
                        room.isAvailable = true;
                    }
                    if (room.roomNumber == newRoomNumber) {
                        room.isAvailable = false;
                    }
                }
                guest.name = newName;
                guest.roomNumber = newRoomNumber;
                break;
            }
        }
    }

    Guest* searchGuest(int guestId) {
        for (auto &guest : guests) {
            if (guest.id == guestId) {
                return &guest;
            }
        }
        return nullptr;
    }

    Room* searchRoom(int roomNumber) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name
                      << ", Room Number: " << guest.roomNumber << std::endl;
        }
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number: " << room.roomNumber
                      << ", Type: " << room.roomType
                      << ", Available: " << (room.isAvailable ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    HotelSystem system;
    system.addRoom(101, "Single");
    system.addRoom(102, "Double");
    system.addGuest(1, "John Doe", 101);
    system.displayGuests();
    system.displayRooms();
    system.updateGuest(1, "John Smith", 102);
    system.displayGuests();
    system.displayRooms();
    system.deleteGuest(1);
    system.displayGuests();
    system.displayRooms();
    return 0;
}