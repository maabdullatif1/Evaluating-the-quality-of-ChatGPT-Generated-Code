#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Guest {
    int id;
    string name;
};

struct Room {
    int number;
    string type;
    bool isOccupied;
};

class HotelReservationSystem {
private:
    vector<Guest> guests;
    vector<Room> rooms;
    int nextGuestId;

public:
    HotelReservationSystem() : nextGuestId(1) {}

    void addGuest(const string& name) {
        guests.push_back({ nextGuestId++, name });
    }

    void deleteGuest(int guestId) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == guestId) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int guestId, const string& newName) {
        for (auto& guest : guests) {
            if (guest.id == guestId) {
                guest.name = newName;
                break;
            }
        }
    }

    Guest* searchGuest(int guestId) {
        for (auto& guest : guests) {
            if (guest.id == guestId) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            cout << "ID: " << guest.id << ", Name: " << guest.name << endl;
        }
    }

    void addRoom(int number, const string& type) {
        rooms.push_back({ number, type, false });
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int roomNumber, const string& newType, bool isOccupied) {
        for (auto& room : rooms) {
            if (room.number == roomNumber) {
                room.type = newType;
                room.isOccupied = isOccupied;
                break;
            }
        }
    }

    Room* searchRoom(int roomNumber) {
        for (auto& room : rooms) {
            if (room.number == roomNumber) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            cout << "Number: " << room.number << ", Type: " << room.type
                 << ", Is Occupied: " << (room.isOccupied ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelReservationSystem hotel;

    hotel.addGuest("Alice Smith");
    hotel.addGuest("Bob Johnson");

    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");

    hotel.displayGuests();
    hotel.displayRooms();

    hotel.updateGuest(1, "Alice Johnson");
    hotel.updateRoom(101, "Single Deluxe", true);
    
    hotel.displayGuests();
    hotel.displayRooms();

    hotel.deleteGuest(2);
    hotel.deleteRoom(102);

    hotel.displayGuests();
    hotel.displayRooms();

    return 0;
}