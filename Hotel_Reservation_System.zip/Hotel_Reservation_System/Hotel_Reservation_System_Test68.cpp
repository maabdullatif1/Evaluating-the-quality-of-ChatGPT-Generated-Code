#include <iostream>
#include <string>
#include <vector>

struct Guest {
    int id;
    std::string name;
    std::string email;
};

struct Room {
    int number;
    std::string type;
    bool isOccupied;
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;
    int nextGuestId = 1;

    int findGuestIndex(int id) {
        for (int i = 0; i < guests.size(); ++i) {
            if (guests[i].id == id) return i;
        }
        return -1;
    }

    int findRoomIndex(int number) {
        for (int i = 0; i < rooms.size(); ++i) {
            if (rooms[i].number == number) return i;
        }
        return -1;
    }

public:
    void addGuest(const std::string& name, const std::string& email) {
        guests.push_back({nextGuestId++, name, email});
    }
    
    void deleteGuest(int id) {
        int index = findGuestIndex(id);
        if (index != -1) guests.erase(guests.begin() + index);
    }

    void updateGuest(int id, const std::string& name, const std::string& email) {
        int index = findGuestIndex(id);
        if (index != -1) {
            guests[index].name = name;
            guests[index].email = email;
        }
    }

    void searchGuest(int id) {
        int index = findGuestIndex(id);
        if (index != -1) {
            std::cout << "Guest ID: " << guests[index].id 
                      << ", Name: " << guests[index].name 
                      << ", Email: " << guests[index].email << std::endl;
        } else {
            std::cout << "Guest not found." << std::endl;
        }
    }

    void addRoom(int number, const std::string& type) {
        rooms.push_back({number, type, false});
    }
    
    void deleteRoom(int number) {
        int index = findRoomIndex(number);
        if (index != -1) rooms.erase(rooms.begin() + index);
    }

    void updateRoom(int number, const std::string& type, bool isOccupied) {
        int index = findRoomIndex(number);
        if (index != -1) {
            rooms[index].type = type;
            rooms[index].isOccupied = isOccupied;
        }
    }

    void searchRoom(int number) {
        int index = findRoomIndex(number);
        if (index != -1) {
            std::cout << "Room Number: " << rooms[index].number 
                      << ", Type: " << rooms[index].type 
                      << ", Occupied: " << (rooms[index].isOccupied ? "Yes" : "No") 
                      << std::endl;
        } else {
            std::cout << "Room not found." << std::endl;
        }
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            std::cout << "Guest ID: " << guest.id 
                      << ", Name: " << guest.name 
                      << ", Email: " << guest.email << std::endl;
        }
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            std::cout << "Room Number: " << room.number 
                      << ", Type: " << room.type 
                      << ", Occupied: " << (room.isOccupied ? "Yes" : "No") 
                      << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest("John Doe", "john@example.com");
    system.addRoom(101, "Single");
    system.displayGuests();
    system.displayRooms();
    system.searchGuest(1);
    system.searchRoom(101);
    system.updateGuest(1, "John Doe", "john.doe@example.com");
    system.updateRoom(101, "Double", true);
    system.displayGuests();
    system.displayRooms();
    system.deleteGuest(1);
    system.deleteRoom(101);
    system.displayGuests();
    system.displayRooms();
    return 0;
}