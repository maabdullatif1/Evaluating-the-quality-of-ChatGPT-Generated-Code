#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;

    Guest(int id, std::string name) : id(id), name(name) {}
};

class Room {
public:
    int roomNumber;
    std::string type;
    bool isAvailable;

    Room(int roomNumber, std::string type, bool isAvailable = true)
        : roomNumber(roomNumber), type(type), isAvailable(isAvailable) {}
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, std::string name) {
        guests.push_back(Guest(id, name));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, std::string newName) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                guest.name = newName;
                break;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << std::endl;
        }
    }

    void addRoom(int roomNumber, std::string type) {
        rooms.push_back(Room(roomNumber, type));
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int roomNumber, std::string newType, bool newAvailability) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.type = newType;
                room.isAvailable = newAvailability;
                break;
            }
        }
    }

    Room* searchRoom(int roomNumber) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            std::cout << "Room Number: " << room.roomNumber 
                      << ", Type: " << room.type 
                      << ", Availability: " << (room.isAvailable ? "Available" : "Occupied") << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem system;

    system.addGuest(1, "John Doe");
    system.addGuest(2, "Jane Smith");

    system.addRoom(101, "Single");
    system.addRoom(102, "Double");

    system.displayGuests();
    system.displayRooms();

    system.updateGuest(1, "John Doe Jr.");
    system.updateRoom(102, "Suite", false);

    system.displayGuests();
    system.displayRooms();

    return 0;
}