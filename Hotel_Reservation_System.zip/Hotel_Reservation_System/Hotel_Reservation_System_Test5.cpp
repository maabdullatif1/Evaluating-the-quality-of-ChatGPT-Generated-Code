#include <iostream>
#include <string>
#include <vector>

class Room {
public:
    int roomNumber;
    std::string type;
    bool isOccupied;

    Room(int rn, std::string t) : roomNumber(rn), type(t), isOccupied(false) {}
};

class Guest {
public:
    std::string name;
    int roomNumber;

    Guest(std::string n, int rn) : name(n), roomNumber(rn) {}
};

class HotelReservationSystem {
private:
    std::vector<Room> rooms;
    std::vector<Guest> guests;

public:
    void addRoom(int roomNumber, const std::string& type) {
        rooms.push_back(Room(roomNumber, type));
    }

    void addGuest(const std::string& name, int roomNumber) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber && !room.isOccupied) {
                guests.push_back(Guest(name, roomNumber));
                room.isOccupied = true;
                return;
            }
        }
        std::cout << "Room not available\n";
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                return;
            }
        }
    }

    void deleteGuest(const std::string& name) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->name == name) {
                for (auto& room : rooms) {
                    if (room.roomNumber == it->roomNumber) {
                        room.isOccupied = false;
                        break;
                    }
                }
                guests.erase(it);
                return;
            }
        }
    }

    void updateRoom(int roomNumber, const std::string& type) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.type = type;
                return;
            }
        }
    }

    void updateGuest(const std::string& name, int newRoomNumber) {
        for (auto& guest : guests) {
            if (guest.name == name) {
                guest.roomNumber = newRoomNumber;
                return;
            }
        }
    }

    Room* searchRoom(int roomNumber) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                return &room;
            }
        }
        return nullptr;
    }

    Guest* searchGuest(const std::string& name) {
        for (auto& guest : guests) {
            if (guest.name == name) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            std::cout << "Room Number: " << room.roomNumber 
                      << ", Type: " << room.type 
                      << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << "\n";
        }
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            std::cout << "Guest Name: " << guest.name 
                      << ", Room Number: " << guest.roomNumber << "\n";
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addRoom(101, "Single");
    system.addRoom(102, "Double");
    system.addGuest("Alice", 101);
    system.displayRooms();
    system.displayGuests();
    system.updateGuest("Alice", 102);
    system.displayGuests();
    system.deleteGuest("Alice");
    system.displayRooms();
    return 0;
}