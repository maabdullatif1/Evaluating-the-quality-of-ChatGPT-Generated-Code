#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Guest {
    int id;
    string name;
    string phoneNumber;
};

struct Room {
    int number;
    bool isOccupied;
    int guestId;
};

class HotelReservationSystem {
    vector<Guest> guests;
    vector<Room> rooms;

public:
    void addGuest(int id, const string& name, const string& phoneNumber) {
        guests.push_back({id, name, phoneNumber});
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, const string& name, const string& phoneNumber) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.phoneNumber = phoneNumber;
                break;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto& guest : guests) {
            if (guest.id == id) return &guest;
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            cout << "ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phoneNumber << endl;
        }
    }

    void addRoom(int number) {
        rooms.push_back({number, false, -1});
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, bool isOccupied, int guestId) {
        for (auto& room : rooms) {
            if (room.number == number) {
                room.isOccupied = isOccupied;
                room.guestId = guestId;
                break;
            }
        }
    }

    Room* searchRoom(int number) {
        for (auto& room : rooms) {
            if (room.number == number) return &room;
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            cout << "Room Number: " << room.number << ", Occupied: " << (room.isOccupied ? "Yes" : "No");
            if (room.isOccupied) {
                Guest* guest = searchGuest(room.guestId);
                if (guest) cout << ", Guest ID: " << guest->id << ", Guest Name: " << guest->name;
            }
            cout << endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "Alice", "1234567890");
    system.addGuest(2, "Bob", "0987654321");

    system.addRoom(101);
    system.addRoom(102);

    system.displayGuests();
    system.displayRooms();

    system.updateRoom(101, true, 1);
    system.displayRooms();

    system.deleteGuest(2);
    system.displayGuests();

    return 0;
}