#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Guest {
public:
    int id;
    string name;
    string email;
    
    Guest(int id, string name, string email) : id(id), name(name), email(email) {}
};

class Room {
public:
    int number;
    string type;
    bool isOccupied;
    
    Room(int number, string type, bool isOccupied = false) : number(number), type(type), isOccupied(isOccupied) {}
};

class HotelReservationSystem {
private:
    vector<Guest> guests;
    vector<Room> rooms;
    
public:
    void addGuest(int id, string name, string email) {
        guests.push_back(Guest(id, name, email));
    }
    
    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }
    
    void updateGuest(int id, string name, string email) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.email = email;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Email: " << guest.email << endl;
                return;
            }
        }
        cout << "Guest not found." << endl;
    }
    
    void displayGuests() {
        for (auto &guest : guests) {
            cout << "Guest ID: " << guest.id << ", Name: " << guest.name << ", Email: " << guest.email << endl;
        }
    }
    
    void addRoom(int number, string type) {
        rooms.push_back(Room(number, type));
    }
    
    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, string type, bool isOccupied) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.type = type;
                room.isOccupied = isOccupied;
                break;
            }
        }
    }
    
    void searchRoom(int number) {
        for (auto &room : rooms) {
            if (room.number == number) {
                cout << "Room Number: " << room.number << ", Type: " << room.type << ", Is Occupied: " << (room.isOccupied ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Room not found." << endl;
    }

    void displayRooms() {
        for (auto &room : rooms) {
            cout << "Room Number: " << room.number << ", Type: " << room.type << ", Is Occupied: " << (room.isOccupied ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelReservationSystem hotel;

    hotel.addGuest(1, "John Doe", "john@example.com");
    hotel.addGuest(2, "Jane Smith", "jane@example.com");
    
    hotel.displayGuests();
    
    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");
    
    hotel.displayRooms();
    
    hotel.searchGuest(1);
    hotel.searchRoom(101);

    hotel.updateGuest(1, "John Doe Jr.", "johnjr@example.com");
    hotel.updateRoom(101, "Suite", true);

    hotel.displayGuests();
    hotel.displayRooms();

    hotel.deleteGuest(2);
    hotel.deleteRoom(102);

    hotel.displayGuests();
    hotel.displayRooms();

    return 0;
}