#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;
    std::string phone;

    Guest(int id, const std::string& name, const std::string& phone) 
        : id(id), name(name), phone(phone) {}
};

class Room {
public:
    int number;
    std::string type;
    bool isAvailable;

    Room(int number, const std::string& type, bool isAvailable)
        : number(number), type(type), isAvailable(isAvailable) {}
};

class Hotel {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, const std::string& name, const std::string& phone) {
        guests.push_back(Guest(id, name, phone));
    }

    void addRoom(int number, const std::string& type, bool isAvailable) {
        rooms.push_back(Room(number, type, isAvailable));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                return;
            }
        }
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                return;
            }
        }
    }

    void updateGuest(int id, const std::string& name, const std::string& phone) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.phone = phone;
                return;
            }
        }
    }

    void updateRoom(int number, const std::string& type, bool isAvailable) {
        for (auto& room : rooms) {
            if (room.number == number) {
                room.type = type;
                room.isAvailable = isAvailable;
                return;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    Room* searchRoom(int number) {
        for (auto& room : rooms) {
            if (room.number == number) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            std::cout << "ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phone << std::endl;
        }
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            std::cout << "Room Number: " << room.number << ", Type: " << room.type 
                      << ", Available: " << (room.isAvailable ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    Hotel hotel;
    hotel.addGuest(1, "Alice", "1234567890");
    hotel.addGuest(2, "Bob", "9876543210");
    hotel.addRoom(101, "Single", true);
    hotel.addRoom(102, "Double", false);

    hotel.displayGuests();
    hotel.displayRooms();

    Guest* search = hotel.searchGuest(1);
    if (search) {
        std::cout << "Found guest: " << search->name << std::endl;
    }

    Room* roomSearch = hotel.searchRoom(102);
    if (roomSearch) {
        std::cout << "Found room: " << roomSearch->number << std::endl;
    }

    hotel.updateGuest(1, "Alice Smith", "1234567899");
    hotel.updateRoom(102, "Double", true);

    hotel.displayGuests();
    hotel.displayRooms();

    hotel.deleteGuest(2);
    hotel.deleteRoom(101);

    hotel.displayGuests();
    hotel.displayRooms();

    return 0;
}