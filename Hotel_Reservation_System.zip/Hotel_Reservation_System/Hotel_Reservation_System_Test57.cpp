#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Guest {
public:
    int guestID;
    string name;
    int roomNumber;

    Guest(int gid, string gname, int rnumber) : guestID(gid), name(gname), roomNumber(rnumber) {}
};

class Room {
public:
    int roomNumber;
    string type;
    bool available;

    Room(int rnumber, string rtype, bool avail) : roomNumber(rnumber), type(rtype), available(avail) {}
};

class HotelReservationSystem {
private:
    vector<Guest> guests;
    vector<Room> rooms;

    int findGuestIndexByID(int guestID) {
        for (int i = 0; i < guests.size(); ++i) {
            if (guests[i].guestID == guestID) {
                return i;
            }
        }
        return -1;
    }

    int findRoomIndexByNumber(int roomNumber) {
        for (int i = 0; i < rooms.size(); ++i) {
            if (rooms[i].roomNumber == roomNumber) {
                return i;
            }
        }
        return -1;
    }

public:
    void addGuest(int guestID, string name, int roomNumber) {
        if (findGuestIndexByID(guestID) == -1) {
            guests.push_back(Guest(guestID, name, roomNumber));
            updateRoomAvailability(roomNumber, false);
        }
    }

    void deleteGuest(int guestID) {
        int index = findGuestIndexByID(guestID);
        if (index != -1) {
            updateRoomAvailability(guests[index].roomNumber, true);
            guests.erase(guests.begin() + index);
        }
    }

    void updateGuest(int guestID, string name, int roomNumber) {
        int index = findGuestIndexByID(guestID);
        if (index != -1) {
            updateRoomAvailability(guests[index].roomNumber, true);
            guests[index].name = name;
            guests[index].roomNumber = roomNumber;
            updateRoomAvailability(roomNumber, false);
        }
    }

    void searchGuest(int guestID) {
        int index = findGuestIndexByID(guestID);
        if (index != -1) {
            cout << "Guest ID: " << guests[index].guestID << ", Name: " << guests[index].name << ", Room: " << guests[index].roomNumber << endl;
        } else {
            cout << "Guest not found" << endl;
        }
    }

    void displayGuests() {
        for (auto& guest : guests) {
            cout << "Guest ID: " << guest.guestID << ", Name: " << guest.name << ", Room: " << guest.roomNumber << endl;
        }
    }

    void addRoom(int roomNumber, string type) {
        if (findRoomIndexByNumber(roomNumber) == -1) {
            rooms.push_back(Room(roomNumber, type, true));
        }
    }

    void deleteRoom(int roomNumber) {
        int index = findRoomIndexByNumber(roomNumber);
        if (index != -1) {
            rooms.erase(rooms.begin() + index);
        }
    }

    void updateRoomAvailability(int roomNumber, bool available) {
        int index = findRoomIndexByNumber(roomNumber);
        if (index != -1) {
            rooms[index].available = available;
        }
    }

    void searchRoom(int roomNumber) {
        int index = findRoomIndexByNumber(roomNumber);
        if (index != -1) {
            cout << "Room Number: " << rooms[index].roomNumber << ", Type: " << rooms[index].type << ", Available: " << (rooms[index].available ? "Yes" : "No") << endl;
        } else {
            cout << "Room not found" << endl;
        }
    }

    void displayRooms() {
        for (auto& room : rooms) {
            cout << "Room Number: " << room.roomNumber << ", Type: " << room.type << ", Available: " << (room.available ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addRoom(101, "Single");
    system.addRoom(102, "Double");
    system.addGuest(1, "Alice", 101);
    system.addGuest(2, "Bob", 102);

    cout << "Guests:" << endl;
    system.displayGuests();

    cout << "\nRooms:" << endl;
    system.displayRooms();

    return 0;
}