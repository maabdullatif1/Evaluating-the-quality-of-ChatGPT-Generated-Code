#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Guest {
public:
    int id;
    string name;
    int roomNumber;

    Guest(int id, string name, int roomNumber)
        : id(id), name(name), roomNumber(roomNumber) {}
};

class Room {
public:
    int number;
    string type;
    bool isAvailable;

    Room(int number, string type, bool isAvailable = true)
        : number(number), type(type), isAvailable(isAvailable) {}
};

class Hotel {
private:
    vector<Guest> guests;
    vector<Room> rooms;

public:
    void addGuest(int id, string name, int roomNumber) {
        guests.push_back(Guest(id, name, roomNumber));
        updateRoomAvailability(roomNumber, false);
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                updateRoomAvailability(it->roomNumber, true);
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string name, int roomNumber) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                updateRoomAvailability(guest.roomNumber, true);
                guest.name = name;
                guest.roomNumber = roomNumber;
                updateRoomAvailability(roomNumber, false);
                break;
            }
        }
    }

    void addRoom(int number, string type) {
        rooms.push_back(Room(number, type));
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, string type, bool isAvailable) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.type = type;
                room.isAvailable = isAvailable;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                cout << "Guest ID: " << guest.id << ", Name: " << guest.name
                     << ", Room Number: " << guest.roomNumber << '\n';
                return;
            }
        }
        cout << "Guest not found.\n";
    }

    void searchRoom(int number) {
        for (const auto &room : rooms) {
            if (room.number == number) {
                cout << "Room Number: " << room.number << ", Type: " << room.type
                     << ", Available: " << (room.isAvailable ? "Yes" : "No") << '\n';
                return;
            }
        }
        cout << "Room not found.\n";
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            cout << "Guest ID: " << guest.id << ", Name: " << guest.name
                 << ", Room Number: " << guest.roomNumber << '\n';
        }
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            cout << "Room Number: " << room.number << ", Type: " << room.type
                 << ", Available: " << (room.isAvailable ? "Yes" : "No") << '\n';
        }
    }

private:
    void updateRoomAvailability(int number, bool isAvailable) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.isAvailable = isAvailable;
                break;
            }
        }
    }
};

int main() {
    Hotel hotel;
    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");
    hotel.addGuest(1, "Alice", 101);
    hotel.addGuest(2, "Bob", 102);
    hotel.displayGuests();
    hotel.displayRooms();
    hotel.deleteGuest(1);
    hotel.updateRoom(102, "Suite", true);
    hotel.displayGuests();
    hotel.searchRoom(102);
    return 0;
}