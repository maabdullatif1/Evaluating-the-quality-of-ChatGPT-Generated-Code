#include <iostream>
#include <string>
#include <vector>

class Room {
public:
    int number;
    bool isAvailable;
    Room(int number) : number(number), isAvailable(true) {}
};

class Guest {
public:
    std::string name;
    int roomNumber;
    Guest(std::string name, int roomNumber) : name(name), roomNumber(roomNumber) {}
};

class HotelReservationSystem {
private:
    std::vector<Room> rooms;
    std::vector<Guest> guests;
public:
    void addRoom(int roomNumber) {
        rooms.push_back(Room(roomNumber));
    }

    void addGuest(const std::string& name, int roomNumber) {
        for (auto &room : rooms) {
            if (room.number == roomNumber && room.isAvailable) {
                guests.push_back(Guest(name, roomNumber));
                room.isAvailable = false;
                return;
            }
        }
        std::cout << "Room not available or does not exist.\n";
    }

    void deleteGuest(const std::string& name) {
        auto it = std::remove_if(guests.begin(), guests.end(), [&](Guest& guest) {
            return guest.name == name;
        });
        if (it != guests.end()) {
            for (auto &room : rooms) {
                if (room.number == it->roomNumber) {
                    room.isAvailable = true;
                }
            }
            guests.erase(it, guests.end());
            std::cout << "Guest deleted.\n";
        } else {
            std::cout << "Guest not found.\n";
        }
    }

    void updateGuest(const std::string& name, int newRoomNumber) {
        for (auto &guest : guests) {
            if (guest.name == name) {
                for (auto &room : rooms) {
                    if (room.number == newRoomNumber && room.isAvailable) {
                        for (auto &r : rooms) {
                            if (r.number == guest.roomNumber) {
                                r.isAvailable = true;
                            }
                        }
                        guest.roomNumber = newRoomNumber;
                        room.isAvailable = false;
                        return;
                    }
                }
            }
        }
        std::cout << "Guest or room not found or room not available.\n";
    }

    void searchGuest(const std::string& name) {
        for (const auto &guest : guests) {
            if (guest.name == name) {
                std::cout << "Guest found: " << guest.name << " in room " << guest.roomNumber << "\n";
                return;
            }
        }
        std::cout << "Guest not found.\n";
    }

    void displayGuests() {
        std::cout << "Guests:\n";
        for (const auto &guest : guests) {
            std::cout << guest.name << " in room " << guest.roomNumber << "\n";
        }
    }

    void displayRooms() {
        std::cout << "Rooms:\n";
        for (const auto &room : rooms) {
            std::cout << "Room " << room.number << " is " << (room.isAvailable ? "available" : "occupied") << "\n";
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addRoom(101);
    system.addRoom(102);
    system.addGuest("Alice", 101);
    system.displayGuests();
    system.displayRooms();
    system.updateGuest("Alice", 102);
    system.displayGuests();
    system.displayRooms();
    system.searchGuest("Alice");
    system.deleteGuest("Alice");
    system.displayGuests();
    system.displayRooms();
    return 0;
}