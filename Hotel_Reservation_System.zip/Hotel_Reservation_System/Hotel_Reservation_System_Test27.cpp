#include <iostream>
#include <vector>
#include <string>

class Guest {
private:
    int id;
    std::string name;
    std::string phone;

public:
    Guest(int id, const std::string& name, const std::string& phone) 
        : id(id), name(name), phone(phone) {}

    int getId() const {
        return id;
    }

    std::string getName() const {
        return name;
    }
    
    std::string getPhone() const {
        return phone;
    }

    void update(const std::string& newName, const std::string& newPhone) {
        name = newName;
        phone = newPhone;
    }

    void display() const {
        std::cout << "Guest ID: " << id 
                  << ", Name: " << name 
                  << ", Phone: " << phone << std::endl;
    }
};

class Room {
private:
    int roomNumber;
    std::string type;
    bool isBooked;

public:
    Room(int roomNumber, const std::string& type) 
        : roomNumber(roomNumber), type(type), isBooked(false) {}

    int getRoomNumber() const {
        return roomNumber;
    }

    std::string getType() const {
        return type;
    }

    bool getBookingStatus() const {
        return isBooked;
    }

    void bookRoom() {
        isBooked = true;
    }

    void releaseRoom() {
        isBooked = false;
    }

    void updateRoom(const std::string& newType) {
        type = newType;
    }

    void display() const {
        std::cout << "Room Number: " << roomNumber 
                  << ", Type: " << type 
                  << ", Status: " << (isBooked ? "Booked" : "Available") << std::endl;
    }
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;
    int guestCounter;

public:
    HotelReservationSystem() : guestCounter(0) {}

    void addGuest(const std::string& name, const std::string& phone) {
        guests.emplace_back(++guestCounter, name, phone);
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->getId() == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, const std::string& name, const std::string& phone) {
        for (auto& guest : guests) {
            if (guest.getId() == id) {
                guest.update(name, phone);
                break;
            }
        }
    }

    void searchGuest(int id) const {
        for (const auto& guest : guests) {
            if (guest.getId() == id) {
                guest.display();
                return;
            }
        }
        std::cout << "Guest not found." << std::endl;
    }

    void displayGuests() const {
        for (const auto& guest : guests) {
            guest.display();
        }
    }

    void addRoom(int roomNumber, const std::string& type) {
        rooms.emplace_back(roomNumber, type);
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->getRoomNumber() == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int roomNumber, const std::string& type) {
        for (auto& room : rooms) {
            if (room.getRoomNumber() == roomNumber) {
                room.updateRoom(type);
                break;
            }
        }
    }

    void bookRoom(int roomNumber) {
        for (auto& room : rooms) {
            if (room.getRoomNumber() == roomNumber) {
                room.bookRoom();
                return;
            }
        }
    }

    void releaseRoom(int roomNumber) {
        for (auto& room : rooms) {
            if (room.getRoomNumber() == roomNumber) {
                room.releaseRoom();
                return;
            }
        }
    }

    void searchRoom(int roomNumber) const {
        for (const auto& room : rooms) {
            if (room.getRoomNumber() == roomNumber) {
                room.display();
                return;
            }
        }
        std::cout << "Room not found." << std::endl;
    }

    void displayRooms() const {
        for (const auto& room : rooms) {
            room.display();
        }
    }
};

int main() {
    HotelReservationSystem hotel;

    hotel.addGuest("Alice", "1234567890");
    hotel.addGuest("Bob", "0987654321");

    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");

    hotel.displayGuests();
    hotel.displayRooms();

    hotel.bookRoom(101);

    hotel.displayRooms();

    return 0;
}