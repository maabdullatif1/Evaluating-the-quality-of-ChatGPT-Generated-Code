#include <iostream>
#include <string>
using namespace std;

struct Guest {
    int id;
    string name;
};

struct Room {
    int number;
    string type;
    bool isOccupied;
};

class HotelReservationSystem {
private:
    Guest guests[100];
    Room rooms[100];
    int guestCount;
    int roomCount;

public:
    HotelReservationSystem() : guestCount(0), roomCount(0) {}

    void addGuest(int id, string name) {
        guests[guestCount++] = {id, name};
    }

    void deleteGuest(int id) {
        for (int i = 0; i < guestCount; ++i) {
            if (guests[i].id == id) {
                guests[i] = guests[guestCount - 1];
                --guestCount;
                break;
            }
        }
    }

    void updateGuest(int id, string name) {
        for (int i = 0; i < guestCount; ++i) {
            if (guests[i].id == id) {
                guests[i].name = name;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for (int i = 0; i < guestCount; ++i) {
            if (guests[i].id == id) {
                cout << "Guest ID: " << guests[i].id << ", Name: " << guests[i].name << endl;
                return;
            }
        }
        cout << "Guest not found" << endl;
    }

    void displayAllGuests() {
        for (int i = 0; i < guestCount; ++i) {
            cout << "Guest ID: " << guests[i].id << ", Name: " << guests[i].name << endl;
        }
    }

    void addRoom(int number, string type, bool isOccupied) {
        rooms[roomCount++] = {number, type, isOccupied};
    }

    void deleteRoom(int number) {
        for (int i = 0; i < roomCount; ++i) {
            if (rooms[i].number == number) {
                rooms[i] = rooms[roomCount - 1];
                --roomCount;
                break;
            }
        }
    }

    void updateRoom(int number, string type, bool isOccupied) {
        for (int i = 0; i < roomCount; ++i) {
            if (rooms[i].number == number) {
                rooms[i].type = type;
                rooms[i].isOccupied = isOccupied;
                break;
            }
        }
    }

    void searchRoom(int number) {
        for (int i = 0; i < roomCount; ++i) {
            if (rooms[i].number == number) {
                cout << "Room Number: " << rooms[i].number << ", Type: " << rooms[i].type
                     << ", Occupied: " << (rooms[i].isOccupied ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Room not found" << endl;
    }

    void displayAllRooms() {
        for (int i = 0; i < roomCount; ++i) {
            cout << "Room Number: " << rooms[i].number << ", Type: " << rooms[i].type
                 << ", Occupied: " << (rooms[i].isOccupied ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe");
    system.addGuest(2, "Jane Smith");
    system.displayAllGuests();
    system.updateGuest(1, "John A. Doe");
    system.searchGuest(1);

    system.addRoom(101, "Single", false);
    system.addRoom(102, "Double", true);
    system.displayAllRooms();
    system.updateRoom(101, "Super Single", true);
    system.searchRoom(101);

    return 0;
}