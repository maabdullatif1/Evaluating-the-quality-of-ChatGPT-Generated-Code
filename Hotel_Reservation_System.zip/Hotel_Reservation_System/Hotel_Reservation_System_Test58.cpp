#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Guest {
public:
    string name;
    int id;
    Guest(string n, int i) : name(n), id(i) {}
};

class Room {
public:
    int roomNumber;
    bool isOccupied;
    Room(int rn) : roomNumber(rn), isOccupied(false) {}
};

class Hotel {
private:
    vector<Guest> guests;
    vector<Room> rooms;
public:
    void addGuest(string name, int id) {
        guests.push_back(Guest(name, id));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string newName) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = newName;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                cout << "Found Guest: " << guest.name << ", ID: " << guest.id << endl;
                return;
            }
        }
        cout << "Guest not found" << endl;
    }

    void displayGuests() {
        cout << "Guests List:" << endl;
        for (const auto &guest : guests) {
            cout << "Name: " << guest.name << ", ID: " << guest.id << endl;
        }
    }

    void addRoom(int roomNumber) {
        rooms.push_back(Room(roomNumber));
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoomStatus(int roomNumber, bool isOccupied) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.isOccupied = isOccupied;
                break;
            }
        }
    }

    void searchRoom(int roomNumber) {
        for (const auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                cout << "Room Number: " << room.roomNumber << ", Occupied: " 
                     << (room.isOccupied ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Room not found" << endl;
    }

    void displayRooms() {
        cout << "Rooms List:" << endl;
        for (const auto &room : rooms) {
            cout << "Room Number: " << room.roomNumber << ", Occupied: " 
                 << (room.isOccupied ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    Hotel hotel;
    hotel.addGuest("John Doe", 1);
    hotel.addGuest("Jane Smith", 2);
    hotel.displayGuests();
    hotel.searchGuest(2);
    hotel.updateGuest(2, "Janet Smith");
    hotel.displayGuests();
    hotel.deleteGuest(1);
    hotel.displayGuests();
    hotel.addRoom(101);
    hotel.addRoom(102);
    hotel.displayRooms();
    hotel.updateRoomStatus(101, true);
    hotel.displayRooms();
    hotel.searchRoom(101);
    hotel.deleteRoom(102);
    hotel.displayRooms();
    return 0;
}