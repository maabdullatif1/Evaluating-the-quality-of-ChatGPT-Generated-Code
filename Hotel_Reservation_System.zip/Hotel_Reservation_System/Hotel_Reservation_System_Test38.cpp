#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Guest {
public:
    int id;
    string name;
    string email;

    Guest(int id, string name, string email) : id(id), name(name), email(email) {}
};

class Room {
public:
    int roomNumber;
    string type;
    bool isAvailable;

    Room(int roomNumber, string type, bool isAvailable = true)
        : roomNumber(roomNumber), type(type), isAvailable(isAvailable) {}
};

class HotelSystem {
    vector<Guest> guests;
    vector<Room> rooms;
    int nextGuestId = 1;

public:
    void addGuest(string name, string email) {
        guests.push_back(Guest(nextGuestId++, name, email));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string name, string email) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.email = email;
                break;
            }
        }
    }

    void searchGuest(string name) {
        for (const auto &guest : guests) {
            if (guest.name == name) {
                cout << "Guest Found: ID=" << guest.id << ", Name=" << guest.name << ", Email=" << guest.email << endl;
            }
        }
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            cout << "ID=" << guest.id << ", Name=" << guest.name << ", Email=" << guest.email << endl;
        }
    }

    void addRoom(int roomNumber, string type) {
        rooms.push_back(Room(roomNumber, type));
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int roomNumber, string type, bool isAvailable) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.type = type;
                room.isAvailable = isAvailable;
                break;
            }
        }
    }

    void searchRoom(int roomNumber) {
        for (const auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                cout << "Room Found: Number=" << room.roomNumber << ", Type=" << room.type 
                     << ", Available=" << room.isAvailable << endl;
            }
        }
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            cout << "Number=" << room.roomNumber << ", Type=" << room.type 
                 << ", Available=" << room.isAvailable << endl;
        }
    }
};

int main() {
    HotelSystem hotel;

    hotel.addGuest("John Doe", "john@example.com");
    hotel.addGuest("Jane Smith", "jane@example.com");

    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");

    hotel.displayGuests();
    hotel.displayRooms();

    hotel.updateGuest(1, "John D.", "john.d@example.com");
    hotel.searchGuest("John D.");

    hotel.updateRoom(101, "Single", false);
    hotel.searchRoom(101);

    hotel.deleteGuest(2);
    hotel.deleteRoom(102);

    hotel.displayGuests();
    hotel.displayRooms();

    return 0;
}