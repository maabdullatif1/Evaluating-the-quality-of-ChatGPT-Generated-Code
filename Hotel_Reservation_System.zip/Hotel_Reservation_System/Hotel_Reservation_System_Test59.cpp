#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;
    std::string phoneNumber;

    Guest(int id, std::string name, std::string phoneNumber) 
        : id(id), name(name), phoneNumber(phoneNumber) {}
};

class Room {
public:
    int roomNumber;
    std::string type;
    bool isOccupied;

    Room(int roomNumber, std::string type, bool isOccupied) 
        : roomNumber(roomNumber), type(type), isOccupied(isOccupied) {}
};

std::vector<Guest> guests;
std::vector<Room> rooms;

void addGuest(int id, std::string name, std::string phoneNumber) {
    guests.push_back(Guest(id, name, phoneNumber));
}

void addRoom(int roomNumber, std::string type, bool isOccupied) {
    rooms.push_back(Room(roomNumber, type, isOccupied));
}

void deleteGuest(int id) {
    for (size_t i = 0; i < guests.size(); ++i) {
        if (guests[i].id == id) {
            guests.erase(guests.begin() + i);
            break;
        }
    }
}

void deleteRoom(int roomNumber) {
    for (size_t i = 0; i < rooms.size(); ++i) {
        if (rooms[i].roomNumber == roomNumber) {
            rooms.erase(rooms.begin() + i);
            break;
        }
    }
}

void updateGuest(int id, std::string name, std::string phoneNumber) {
    for (auto& guest : guests) {
        if (guest.id == id) {
            guest.name = name;
            guest.phoneNumber = phoneNumber;
            break;
        }
    }
}

void updateRoom(int roomNumber, std::string type, bool isOccupied) {
    for (auto& room : rooms) {
        if (room.roomNumber == roomNumber) {
            room.type = type;
            room.isOccupied = isOccupied;
            break;
        }
    }
}

Guest* searchGuest(int id) {
    for (auto& guest : guests) {
        if (guest.id == id) {
            return &guest;
        }
    }
    return nullptr;
}

Room* searchRoom(int roomNumber) {
    for (auto& room : rooms) {
        if (room.roomNumber == roomNumber) {
            return &room;
        }
    }
    return nullptr;
}

void displayGuests() {
    for (const auto& guest : guests) {
        std::cout << "Guest ID: " << guest.id 
                  << ", Name: " << guest.name 
                  << ", Phone: " << guest.phoneNumber << std::endl;
    }
}

void displayRooms() {
    for (const auto& room : rooms) {
        std::cout << "Room Number: " << room.roomNumber 
                  << ", Type: " << room.type 
                  << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
    }
}

int main() {
    addGuest(1, "John Doe", "1234567890");
    addGuest(2, "Jane Smith", "0987654321");
    addRoom(101, "Single", false);
    addRoom(102, "Double", true);

    displayGuests();
    displayRooms();

    Guest* guest = searchGuest(1);
    if (guest != nullptr) {
        std::cout << "Found Guest: " << guest->name << std::endl;
    }

    Room* room = searchRoom(101);
    if (room != nullptr) {
        std::cout << "Found Room: " << room->roomNumber << std::endl;
    }

    updateGuest(1, "John Doe Jr.", "1112223333");
    updateRoom(101, "Single", true);
    
    displayGuests();
    displayRooms();

    deleteGuest(2);
    deleteRoom(102);

    displayGuests();
    displayRooms();

    return 0;
}