#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Guest {
    int id;
    string name;
};

struct Room {
    int number;
    bool isAvailable;
};

vector<Guest> guests;
vector<Room> rooms;

void addGuest(int id, const string& name) {
    guests.push_back({id, name});
}

void deleteGuest(int id) {
    for (auto it = guests.begin(); it != guests.end(); ++it) {
        if (it->id == id) {
            guests.erase(it);
            break;
        }
    }
}

void updateGuest(int id, const string& newName) {
    for (auto& guest : guests) {
        if (guest.id == id) {
            guest.name = newName;
            break;
        }
    }
}

void displayGuests() {
    for (const auto& guest : guests) {
        cout << "Guest ID: " << guest.id << ", Name: " << guest.name << endl;
    }
}

void searchGuest(int id) {
    for (const auto& guest : guests) {
        if (guest.id == id) {
            cout << "Guest Found - ID: " << guest.id << ", Name: " << guest.name << endl;
            return;
        }
    }
    cout << "Guest not found" << endl;
}

void addRoom(int number) {
    rooms.push_back({number, true});
}

void deleteRoom(int number) {
    for (auto it = rooms.begin(); it != rooms.end(); ++it) {
        if (it->number == number) {
            rooms.erase(it);
            break;
        }
    }
}

void updateRoom(int number, bool isAvailable) {
    for (auto& room : rooms) {
        if (room.number == number) {
            room.isAvailable = isAvailable;
            break;
        }
    }
}

void displayRooms() {
    for (const auto& room : rooms) {
        cout << "Room Number: " << room.number << ", Available: " << (room.isAvailable ? "Yes" : "No") << endl;
    }
}

void searchRoom(int number) {
    for (const auto& room : rooms) {
        if (room.number == number) {
            cout << "Room Found - Number: " << room.number << ", Available: " << (room.isAvailable ? "Yes" : "No") << endl;
            return;
        }
    }
    cout << "Room not found" << endl;
}

int main() {
    addGuest(1, "Alice");
    addGuest(2, "Bob");
    addRoom(101);
    addRoom(102);

    cout << "All Guests:" << endl;
    displayGuests();
    
    cout << "All Rooms:" << endl;
    displayRooms();
    
    searchGuest(1);
    searchRoom(101);

    updateGuest(1, "Alice Smith");
    updateRoom(101, false);

    deleteGuest(2);
    deleteRoom(102);

    cout << "Updated Guests:" << endl;
    displayGuests();
    
    cout << "Updated Rooms:" << endl;
    displayRooms();

    return 0;
}