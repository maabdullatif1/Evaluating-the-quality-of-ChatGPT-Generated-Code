#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Guest {
    int id;
    string name;
    string address;
};

struct Room {
    int number;
    string type;
    bool isOccupied;
};

class Hotel {
private:
    vector<Guest> guests;
    vector<Room> rooms;

public:
    void addGuest(int id, string name, string address) {
        guests.push_back({id, name, address});
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string name, string address) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.address = address;
                break;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    void addRoom(int number, string type, bool isOccupied) {
        rooms.push_back({number, type, isOccupied});
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, string type, bool isOccupied) {
        for (auto& room : rooms) {
            if (room.number == number) {
                room.type = type;
                room.isOccupied = isOccupied;
                break;
            }
        }
    }

    Room* searchRoom(int number) {
        for (auto& room : rooms) {
            if (room.number == number) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayGuests() const {
        for (const auto& guest : guests) {
            cout << "Guest ID: " << guest.id << ", Name: " << guest.name 
                 << ", Address: " << guest.address << endl;
        }
    }

    void displayRooms() const {
        for (const auto& room : rooms) {
            cout << "Room Number: " << room.number << ", Type: " << room.type
                 << ", Is Occupied: " << (room.isOccupied ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    Hotel hotel;

    hotel.addGuest(1, "John Doe", "123 Elm Street");
    hotel.addGuest(2, "Jane Smith", "456 Maple Avenue");

    hotel.addRoom(101, "Single", false);
    hotel.addRoom(102, "Double", false);

    cout << "Guests:" << endl;
    hotel.displayGuests();

    cout << "Rooms:" << endl;
    hotel.displayRooms();

    hotel.updateGuest(1, "John Doe", "789 Oak Road");
    hotel.updateRoom(102, "Double", true);

    cout << "Updated Guests:" << endl;
    hotel.displayGuests();

    cout << "Updated Rooms:" << endl;
    hotel.displayRooms();

    Guest* guest = hotel.searchGuest(1);
    if (guest) {
        cout << "Found guest: " << guest->name << endl;
    }

    Room* room = hotel.searchRoom(102);
    if (room) {
        cout << "Found room: " << room->type << ", Occupied: " << (room->isOccupied ? "Yes" : "No") << endl;
    }

    hotel.deleteGuest(2);
    hotel.deleteRoom(101);

    cout << "After Deletion:" << endl;
    hotel.displayGuests();
    hotel.displayRooms();

    return 0;
}