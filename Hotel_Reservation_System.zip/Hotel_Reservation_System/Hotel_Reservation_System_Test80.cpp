#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Guest {
public:
    int id;
    string name;
    string contact;
    Guest(int id, string name, string contact) : id(id), name(name), contact(contact) {}
};

class Room {
public:
    int id;
    string type;
    bool isAvailable;
    Room(int id, string type, bool isAvailable) : id(id), type(type), isAvailable(isAvailable) {}
};

class HotelReservationSystem {
private:
    vector<Guest> guests;
    vector<Room> rooms;

public:
    void addGuest(int id, string name, string contact) {
        guests.push_back(Guest(id, name, contact));
    }

    void deleteGuest(int id) {
        for (size_t i = 0; i < guests.size(); ++i) {
            if (guests[i].id == id) {
                guests.erase(guests.begin() + i);
                break;
            }
        }
    }

    void updateGuest(int id, string name, string contact) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.contact = contact;
                break;
            }
        }
    }

    void searchGuest(int id) {
        for (const auto &guest : guests) {
            if (guest.id == id) {
                cout << "Found Guest: ID=" << guest.id << ", Name=" << guest.name << ", Contact=" << guest.contact << endl;
                return;
            }
        }
        cout << "Guest not found." << endl;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            cout << "Guest ID=" << guest.id << ", Name=" << guest.name << ", Contact=" << guest.contact << endl;
        }
    }

    void addRoom(int id, string type, bool isAvailable) {
        rooms.push_back(Room(id, type, isAvailable));
    }

    void deleteRoom(int id) {
        for (size_t i = 0; i < rooms.size(); ++i) {
            if (rooms[i].id == id) {
                rooms.erase(rooms.begin() + i);
                break;
            }
        }
    }

    void updateRoom(int id, string type, bool isAvailable) {
        for (auto &room : rooms) {
            if (room.id == id) {
                room.type = type;
                room.isAvailable = isAvailable;
                break;
            }
        }
    }

    void searchRoom(int id) {
        for (const auto &room : rooms) {
            if (room.id == id) {
                cout << "Found Room: ID=" << room.id << ", Type=" << room.type << ", IsAvailable=" << (room.isAvailable ? "Yes" : "No") << endl;
                return;
            }
        }
        cout << "Room not found." << endl;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            cout << "Room ID=" << room.id << ", Type=" << room.type << ", IsAvailable=" << (room.isAvailable ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "Alice", "123456789");
    system.addGuest(2, "Bob", "987654321");
    system.displayGuests();

    system.updateGuest(1, "Alice Smith", "1234567890");
    system.searchGuest(1);

    system.addRoom(101, "Single", true);
    system.addRoom(102, "Double", false);
    system.displayRooms();

    system.updateRoom(102, "Double", true);
    system.searchRoom(102);

    return 0;
}