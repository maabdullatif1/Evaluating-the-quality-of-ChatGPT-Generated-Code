#include <iostream>
#include <string>
using namespace std;

class Guest {
public:
    int id;
    string name;
    string phone;
};

class Room {
public:
    int number;
    string type;
    bool isOccupied;
    int guestId;  // ID of the guest occupying the room, -1 if none
};

class HotelReservationSystem {
private:
    Guest guests[100];
    Room rooms[100];
    int guestCount;
    int roomCount;

public:
    HotelReservationSystem() : guestCount(0), roomCount(0) {}

    void addGuest(int id, string name, string phone) {
        guests[guestCount] = {id, name, phone};
        guestCount++;
    }

    void deleteGuest(int id) {
        for (int i = 0; i < guestCount; i++) {
            if (guests[i].id == id) {
                for (int j = i; j < guestCount - 1; j++) {
                    guests[j] = guests[j + 1];
                }
                guestCount--;
                break;
            }
        }
    }

    void updateGuest(int id, string name, string phone) {
        for (int i = 0; i < guestCount; i++) {
            if (guests[i].id == id) {
                guests[i].name = name;
                guests[i].phone = phone;
                break;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (int i = 0; i < guestCount; i++) {
            if (guests[i].id == id) return &guests[i];
        }
        return nullptr;
    }

    void displayGuests() {
        for (int i = 0; i < guestCount; i++) {
            cout << "Guest ID: " << guests[i].id << ", Name: " << guests[i].name << ", Phone: " << guests[i].phone << endl;
        }
    }

    void addRoom(int number, string type, bool isOccupied = false, int guestId = -1) {
        rooms[roomCount] = {number, type, isOccupied, guestId};
        roomCount++;
    }

    void deleteRoom(int number) {
        for (int i = 0; i < roomCount; i++) {
            if (rooms[i].number == number) {
                for (int j = i; j < roomCount - 1; j++) {
                    rooms[j] = rooms[j + 1];
                }
                roomCount--;
                break;
            }
        }
    }

    void updateRoom(int number, string type, bool isOccupied, int guestId) {
        for (int i = 0; i < roomCount; i++) {
            if (rooms[i].number == number) {
                rooms[i].type = type;
                rooms[i].isOccupied = isOccupied;
                rooms[i].guestId = guestId;
                break;
            }
        }
    }

    Room* searchRoom(int number) {
        for (int i = 0; i < roomCount; i++) {
            if (rooms[i].number == number) return &rooms[i];
        }
        return nullptr;
    }

    void displayRooms() {
        for (int i = 0; i < roomCount; i++) {
            cout << "Room Number: " << rooms[i].number << ", Type: " << rooms[i].type << ", Is Occupied: " << (rooms[i].isOccupied ? "Yes" : "No") << ", Guest ID: " << rooms[i].guestId << endl;
        }
    }
};

int main() {
    HotelReservationSystem hotelSystem;

    hotelSystem.addGuest(1, "John Doe", "123456789");
    hotelSystem.addGuest(2, "Jane Smith", "987654321");
    hotelSystem.addRoom(101, "Single");
    hotelSystem.addRoom(102, "Double", true, 1);

    cout << "Guests:" << endl;
    hotelSystem.displayGuests();
    cout << endl;

    cout << "Rooms:" << endl;
    hotelSystem.displayRooms();
    
    return 0;
}