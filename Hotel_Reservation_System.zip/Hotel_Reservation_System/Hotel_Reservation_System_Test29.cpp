#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;
    
    Guest(int id, const std::string& name) : id(id), name(name) {}
};

class Room {
public:
    int number;
    bool isOccupied;
    
    Room(int number) : number(number), isOccupied(false) {}
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, const std::string& name) {
        guests.push_back(Guest(id, name));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, const std::string& newName) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                guest.name = newName;
            }
        }
    }

    void searchGuest(int id) const {
        for (const auto& guest : guests) {
            if (guest.id == id) {
                std::cout << "Guest Found: ID=" << guest.id << ", Name=" << guest.name << std::endl;
                return;
            }
        }
        std::cout << "Guest not found" << std::endl;
    }

    void displayGuests() const {
        for (const auto& guest : guests) {
            std::cout << "ID: " << guest.id << ", Name: " << guest.name << std::endl;
        }
    }

    void addRoom(int number) {
        rooms.push_back(Room(number));
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, bool occupied) {
        for (auto& room : rooms) {
            if (room.number == number) {
                room.isOccupied = occupied;
            }
        }
    }

    void searchRoom(int number) const {
        for (const auto& room : rooms) {
            if (room.number == number) {
                std::cout << "Room Found: Number=" << room.number 
                          << ", Occupied=" << (room.isOccupied ? "Yes" : "No") << std::endl;
                return;
            }
        }
        std::cout << "Room not found" << std::endl;
    }

    void displayRooms() const {
        for (const auto& room : rooms) {
            std::cout << "Number: " << room.number 
                      << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    
    system.addGuest(1, "John Doe");
    system.addGuest(2, "Jane Doe");
    
    system.addRoom(101);
    system.addRoom(102);
    
    system.displayGuests();
    system.displayRooms();
    
    system.searchGuest(1);
    system.searchRoom(101);
    
    system.updateGuest(1, "John Smith");
    system.updateRoom(101, true);
    
    system.displayGuests();
    system.displayRooms();
    
    system.deleteGuest(2);
    system.deleteRoom(102);
    
    system.displayGuests();
    system.displayRooms();
    
    return 0;
}