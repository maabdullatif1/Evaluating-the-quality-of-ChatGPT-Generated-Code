#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Guest {
public:
    int id;
    string name;
    string phone;
    Guest(int i, string n, string p) : id(i), name(n), phone(p) {}
};

class Room {
public:
    int number;
    string type;
    bool isAvailable;
    Room(int n, string t) : number(n), type(t), isAvailable(true) {}
};

class HotelReservationSystem {
private:
    vector<Guest> guests;
    vector<Room> rooms;

public:
    void addGuest(int id, string name, string phone) {
        guests.push_back(Guest(id, name, phone));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                return;
            }
        }
    }

    void updateGuest(int id, string name, string phone) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.phone = phone;
                return;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            cout << "ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phone << endl;
        }
    }

    void addRoom(int number, string type) {
        rooms.push_back(Room(number, type));
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                return;
            }
        }
    }

    void updateRoom(int number, string type, bool isAvailable) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.type = type;
                room.isAvailable = isAvailable;
                return;
            }
        }
    }

    Room* searchRoom(int number) {
        for (auto &room : rooms) {
            if (room.number == number) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            cout << "Number: " << room.number << ", Type: " << room.type
                 << ", Available: " << (room.isAvailable ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelReservationSystem system;

    system.addGuest(1, "John Doe", "+123456789");
    system.addGuest(2, "Jane Smith", "+987654321");
    system.displayGuests();

    system.addRoom(101, "Single");
    system.addRoom(102, "Double");
    system.displayRooms();

    return 0;
}