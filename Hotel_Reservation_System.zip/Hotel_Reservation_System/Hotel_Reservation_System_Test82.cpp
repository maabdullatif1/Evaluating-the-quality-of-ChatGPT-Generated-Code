#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Room {
    int roomNumber;
    string type;
    bool isAvailable;
};

struct Guest {
    int id;
    string name;
    int roomNumber;
};

class Hotel {
    vector<Room> rooms;
    vector<Guest> guests;
public:
    void addRoom(int roomNumber, string type) {
        rooms.push_back({roomNumber, type, true});
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); it++) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int roomNumber, string newType) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.type = newType;
                break;
            }
        }
    }

    Room* searchRoom(int roomNumber) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            cout << "Room Number: " << room.roomNumber
                 << ", Type: " << room.type
                 << ", Available: " << (room.isAvailable ? "Yes" : "No") << endl;
        }
    }

    void addGuest(int id, string name, int roomNumber) {
        Room* room = searchRoom(roomNumber);
        if (room && room->isAvailable) {
            guests.push_back({id, name, roomNumber});
            room->isAvailable = false;
        }
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); it++) {
            if (it->id == id) {
                Room* room = searchRoom(it->roomNumber);
                if (room) {
                    room->isAvailable = true;
                }
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, string newName) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = newName;
                break;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            cout << "Guest ID: " << guest.id
                 << ", Name: " << guest.name
                 << ", Room Number: " << guest.roomNumber << endl;
        }
    }
};

int main() {
    Hotel hotel;
    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");
    hotel.displayRooms();

    hotel.addGuest(1, "John Doe", 101);
    hotel.displayGuests();
    
    hotel.updateGuest(1, "Jane Doe");
    hotel.displayGuests();

    hotel.deleteGuest(1);
    hotel.displayGuests();

    hotel.deleteRoom(101);
    hotel.displayRooms();

    return 0;
}