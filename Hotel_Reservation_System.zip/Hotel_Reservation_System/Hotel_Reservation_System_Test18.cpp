#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Guest {
public:
    int id;
    string name;
    
    Guest(int guestId, string guestName) : id(guestId), name(guestName) {}
};

class Room {
public:
    int roomNumber;
    bool isBooked;
    
    Room(int rNumber) : roomNumber(rNumber), isBooked(false) {}
};

class HotelReservationSystem {
public:
    vector<Guest> guests;
    vector<Room> rooms;
    
    void addGuest(int id, string name) {
        guests.push_back(Guest(id, name));
    }
    
    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }
    
    void updateGuest(int id, string newName) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = newName;
                break;
            }
        }
    }
    
    Guest* searchGuest(int id) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }
    
    void displayGuests() {
        for (const auto &guest : guests) {
            cout << "Guest ID: " << guest.id << ", Name: " << guest.name << endl;
        }
    }
    
    void addRoom(int roomNumber) {
        rooms.push_back(Room(roomNumber));
    }
    
    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }
    
    void updateRoom(int roomNumber, bool isBooked) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.isBooked = isBooked;
                break;
            }
        }
    }
    
    Room* searchRoom(int roomNumber) {
        for (auto &room : rooms) {
            if (room.roomNumber == roomNumber) {
                return &room;
            }
        }
        return nullptr;
    }
    
    void displayRooms() {
        for (const auto &room : rooms) {
            cout << "Room Number: " << room.roomNumber << ", Is Booked: " << (room.isBooked ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    
    system.addGuest(1, "John Doe");
    system.addGuest(2, "Jane Smith");
    system.displayGuests();
    
    system.addRoom(101);
    system.addRoom(102);
    system.displayRooms();
    
    system.updateGuest(1, "John Doe Jr.");
    system.displayGuests();
    
    system.updateRoom(101, true);
    system.displayRooms();
    
    system.deleteGuest(2);
    system.displayGuests();
    
    system.deleteRoom(102);
    system.displayRooms();
    
    return 0;
}