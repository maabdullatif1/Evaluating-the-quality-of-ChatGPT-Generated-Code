#include <iostream>
#include <vector>
#include <string>

struct Guest {
    int id;
    std::string name;
};

struct Room {
    int number;
    std::string type;
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

    int findGuestIndexById(int id) {
        for (size_t i = 0; i < guests.size(); ++i) {
            if (guests[i].id == id) return i;
        }
        return -1;
    }

    int findRoomIndexByNumber(int number) {
        for (size_t i = 0; i < rooms.size(); ++i) {
            if (rooms[i].number == number) return i;
        }
        return -1;
    }

public:
    void addGuest(int id, std::string name) {
        if (findGuestIndexById(id) == -1) {
            guests.push_back({id, name});
        }
    }

    void deleteGuest(int id) {
        int index = findGuestIndexById(id);
        if (index != -1) {
            guests.erase(guests.begin() + index);
        }
    }

    void updateGuest(int id, std::string name) {
        int index = findGuestIndexById(id);
        if (index != -1) {
            guests[index].name = name;
        }
    }

    void searchGuest(int id) {
        int index = findGuestIndexById(id);
        if (index != -1) {
            std::cout << "Guest ID: " << guests[index].id << ", Name: " << guests[index].name << std::endl;
        } else {
            std::cout << "Guest not found" << std::endl;
        }
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << std::endl;
        }
    }

    void addRoom(int number, std::string type) {
        if (findRoomIndexByNumber(number) == -1) {
            rooms.push_back({number, type});
        }
    }

    void deleteRoom(int number) {
        int index = findRoomIndexByNumber(number);
        if (index != -1) {
            rooms.erase(rooms.begin() + index);
        }
    }

    void updateRoom(int number, std::string type) {
        int index = findRoomIndexByNumber(number);
        if (index != -1) {
            rooms[index].type = type;
        }
    }

    void searchRoom(int number) {
        int index = findRoomIndexByNumber(number);
        if (index != -1) {
            std::cout << "Room Number: " << rooms[index].number << ", Type: " << rooms[index].type << std::endl;
        } else {
            std::cout << "Room not found" << std::endl;
        }
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            std::cout << "Room Number: " << room.number << ", Type: " << room.type << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe");
    system.addGuest(2, "Jane Smith");
    system.displayGuests();
    system.updateGuest(1, "Johnny Doe");
    system.searchGuest(1);
    system.addRoom(101, "Single");
    system.addRoom(102, "Double");
    system.displayRooms();
    system.updateRoom(101, "Suite");
    system.searchRoom(101);
    system.deleteGuest(2);
    system.displayGuests();
    return 0;
}