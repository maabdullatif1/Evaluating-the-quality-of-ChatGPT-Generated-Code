#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;
    std::string phone;
    Guest(int id, const std::string& name, const std::string& phone) : id(id), name(name), phone(phone) {}
};

class Room {
public:
    int number;
    std::string type;
    bool isOccupied;
    Room(int number, const std::string& type) : number(number), type(type), isOccupied(false) {}
};

class HotelReservationSystem {
public:
    void addGuest(int id, const std::string& name, const std::string& phone) {
        guests.emplace_back(id, name, phone);
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, const std::string& name, const std::string& phone) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.phone = phone;
                break;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayGuests() const {
        for (const auto& guest : guests) {
            std::cout << "ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phone << std::endl;
        }
    }

    void addRoom(int number, const std::string& type) {
        rooms.emplace_back(number, type);
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int number, const std::string& type, bool isOccupied) {
        for (auto& room : rooms) {
            if (room.number == number) {
                room.type = type;
                room.isOccupied = isOccupied;
                break;
            }
        }
    }

    Room* searchRoom(int number) {
        for (auto& room : rooms) {
            if (room.number == number) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayRooms() const {
        for (const auto& room : rooms) {
            std::cout << "Number: " << room.number << ", Type: " << room.type 
                      << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
        }
    }

private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;
};

int main() {
    HotelReservationSystem system;
    
    system.addGuest(1, "John Doe", "+1234567890");
    system.addGuest(2, "Jane Smith", "+0987654321");
    system.displayGuests();
    
    system.addRoom(101, "Single");
    system.addRoom(102, "Double");
    system.displayRooms();
    
    system.updateGuest(1, "John Wick", "+1111111111");
    system.displayGuests();
    
    system.updateRoom(101, "Single", true);
    system.displayRooms();
    
    Guest* guest = system.searchGuest(1);
    if (guest) {
        std::cout << "Found Guest: " << guest->name << std::endl;
    }
    
    Room* room = system.searchRoom(101);
    if (room) {
        std::cout << "Found Room: " << room->number << std::endl;
    }
    
    system.deleteGuest(2);
    system.displayGuests();
    
    system.deleteRoom(102);
    system.displayRooms();
    
    return 0;
}