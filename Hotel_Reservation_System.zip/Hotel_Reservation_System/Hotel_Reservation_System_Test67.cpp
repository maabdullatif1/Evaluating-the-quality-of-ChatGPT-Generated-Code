#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Guest {
    int id;
    string name;
};

struct Room {
    int number;
    string type;
    bool available;
};

class HotelReservationSystem {
private:
    vector<Guest> guests;
    vector<Room> rooms;

    int findGuestIndex(int id) {
        for (size_t i = 0; i < guests.size(); ++i) {
            if (guests[i].id == id) return i;
        }
        return -1;
    }

    int findRoomIndex(int number) {
        for (size_t i = 0; i < rooms.size(); ++i) {
            if (rooms[i].number == number) return i;
        }
        return -1;
    }

public:
    void addGuest(int id, string name) {
        if (findGuestIndex(id) != -1) {
            cout << "Guest already exists." << endl;
            return;
        }
        guests.push_back({id, name});
    }

    void deleteGuest(int id) {
        int index = findGuestIndex(id);
        if (index != -1) {
            guests.erase(guests.begin() + index);
        } else {
            cout << "Guest not found." << endl;
        }
    }

    void updateGuest(int id, string newName) {
        int index = findGuestIndex(id);
        if (index != -1) {
            guests[index].name = newName;
        } else {
            cout << "Guest not found." << endl;
        }
    }

    void searchGuest(int id) {
        int index = findGuestIndex(id);
        if (index != -1) {
            cout << "Guest ID: " << guests[index].id << ", Name: " << guests[index].name << endl;
        } else {
            cout << "Guest not found." << endl;
        }
    }

    void displayGuests() {
        for (auto &guest : guests) {
            cout << "Guest ID: " << guest.id << ", Name: " << guest.name << endl;
        }
    }

    void addRoom(int number, string type, bool available) {
        if (findRoomIndex(number) != -1) {
            cout << "Room already exists." << endl;
            return;
        }
        rooms.push_back({number, type, available});
    }

    void deleteRoom(int number) {
        int index = findRoomIndex(number);
        if (index != -1) {
            rooms.erase(rooms.begin() + index);
        } else {
            cout << "Room not found." << endl;
        }
    }

    void updateRoom(int number, string newType, bool newAvailable) {
        int index = findRoomIndex(number);
        if (index != -1) {
            rooms[index].type = newType;
            rooms[index].available = newAvailable;
        } else {
            cout << "Room not found." << endl;
        }
    }

    void searchRoom(int number) {
        int index = findRoomIndex(number);
        if (index != -1) {
            cout << "Room Number: " << rooms[index].number << ", Type: " << rooms[index].type << ", ";
            cout << (rooms[index].available ? "Available" : "Not Available") << endl;
        } else {
            cout << "Room not found." << endl;
        }
    }

    void displayRooms() {
        for (auto &room : rooms) {
            cout << "Room Number: " << room.number << ", Type: " << room.type << ", ";
            cout << (room.available ? "Available" : "Not Available") << endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe");
    system.addRoom(101, "Single", true);
    system.displayGuests();
    system.displayRooms();
    system.searchGuest(1);
    system.searchRoom(101);
    system.updateGuest(1, "Jane Doe");
    system.updateRoom(101, "Double", false);
    system.displayGuests();
    system.displayRooms();
    system.deleteGuest(1);
    system.deleteRoom(101);
    system.displayGuests();
    system.displayRooms();
    return 0;
}