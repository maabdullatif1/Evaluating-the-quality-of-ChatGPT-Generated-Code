#include <iostream>
#include <string>
#include <vector>

class Guest {
public:
    std::string name;
    int id;

    Guest(int i, const std::string& n) : id(i), name(n) {}
};

class Room {
public:
    int number;
    std::string type;
    bool isOccupied;

    Room(int num, const std::string& t) : number(num), type(t), isOccupied(false) {}
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

    int findGuestById(int id) {
        for (size_t i = 0; i < guests.size(); ++i)
            if (guests[i].id == id)
                return i;
        return -1;
    }

    int findRoomByNumber(int number) {
        for (size_t i = 0; i < rooms.size(); ++i)
            if (rooms[i].number == number)
                return i;
        return -1;
    }

public:
    void addGuest(int id, const std::string& name) {
        if (findGuestById(id) == -1)
            guests.push_back(Guest(id, name));
    }

    void deleteGuest(int id) {
        int index = findGuestById(id);
        if (index != -1)
            guests.erase(guests.begin() + index);
    }

    void updateGuest(int id, const std::string& name) {
        int index = findGuestById(id);
        if (index != -1)
            guests[index].name = name;
    }

    Guest* searchGuest(int id) {
        int index = findGuestById(id);
        if (index != -1)
            return &guests[index];
        return nullptr;
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << std::endl;
        }
    }

    void addRoom(int number, const std::string& type) {
        if (findRoomByNumber(number) == -1)
            rooms.push_back(Room(number, type));
    }

    void deleteRoom(int number) {
        int index = findRoomByNumber(number);
        if (index != -1)
            rooms.erase(rooms.begin() + index);
    }

    void updateRoom(int number, const std::string& type, bool isOccupied) {
        int index = findRoomByNumber(number);
        if (index != -1) {
            rooms[index].type = type;
            rooms[index].isOccupied = isOccupied;
        }
    }

    Room* searchRoom(int number) {
        int index = findRoomByNumber(number);
        if (index != -1)
            return &rooms[index];
        return nullptr;
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            std::cout << "Room Number: " << room.number << ", Type: " << room.type
                      << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe");
    system.addGuest(2, "Jane Smith");
    system.addRoom(101, "Single");
    system.addRoom(102, "Double");

    std::cout << "Guests:" << std::endl;
    system.displayGuests();

    std::cout << "Rooms:" << std::endl;
    system.displayRooms();

    system.updateGuest(1, "John A. Doe");
    system.updateRoom(101, "Suite", true);

    std::cout << "Updated Guests:" << std::endl;
    system.displayGuests();

    std::cout << "Updated Rooms:" << std::endl;
    system.displayRooms();

    return 0;
}