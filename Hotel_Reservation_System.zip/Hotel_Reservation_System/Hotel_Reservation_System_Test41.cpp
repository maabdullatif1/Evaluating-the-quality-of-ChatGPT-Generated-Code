#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;

    Guest(int guestId, std::string guestName) : id(guestId), name(guestName) {}
};

class Room {
public:
    int number;
    bool isOccupied;

    Room(int roomNumber) : number(roomNumber), isOccupied(false) {}
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, std::string name) {
        guests.push_back(Guest(id, name));
    }

    void removeGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, std::string newName) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                guest.name = newName;
                break;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto &guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            std::cout << "Guest ID: " << guest.id << ", Name: " << guest.name << std::endl;
        }
    }

    void addRoom(int number) {
        rooms.push_back(Room(number));
    }

    void removeRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoomStatus(int number, bool isOccupied) {
        for (auto &room : rooms) {
            if (room.number == number) {
                room.isOccupied = isOccupied;
                break;
            }
        }
    }

    Room* searchRoom(int number) {
        for (auto &room : rooms) {
            if (room.number == number) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            std::cout << "Room Number: " << room.number << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe");
    system.addRoom(101);
    system.displayGuests();
    system.displayRooms();
    return 0;
}