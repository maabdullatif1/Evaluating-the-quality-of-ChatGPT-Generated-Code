#include <iostream>
#include <vector>
#include <string>

class Guest {
public:
    int id;
    std::string name;
    std::string email;

    Guest(int gid, std::string gname, std::string gemail)
        : id(gid), name(gname), email(gemail) {}
};

class Room {
public:
    int roomNumber;
    std::string type;
    bool isOccupied;

    Room(int number, std::string rtype)
        : roomNumber(number), type(rtype), isOccupied(false) {}
};

class Hotel {
    std::vector<Guest> guests;
    std::vector<Room> rooms;

public:
    void addGuest(int id, std::string name, std::string email) {
        guests.push_back(Guest(id, name, email));
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                break;
            }
        }
    }

    void updateGuest(int id, std::string name, std::string email) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                guest.name = name;
                guest.email = email;
                break;
            }
        }
    }

    void addRoom(int roomNumber, std::string type) {
        rooms.push_back(Room(roomNumber, type));
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateRoom(int roomNumber, std::string type, bool isOccupied) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                room.type = type;
                room.isOccupied = isOccupied;
                break;
            }
        }
    }

    Guest* searchGuest(int id) {
        for (auto& guest : guests) {
            if (guest.id == id) {
                return &guest;
            }
        }
        return nullptr;
    }

    Room* searchRoom(int roomNumber) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                return &room;
            }
        }
        return nullptr;
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            std::cout << "Guest ID: " << guest.id
                      << ", Name: " << guest.name
                      << ", Email: " << guest.email << std::endl;
        }
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            std::cout << "Room Number: " << room.roomNumber
                      << ", Type: " << room.type
                      << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
        }
    }
};

int main() {
    Hotel hotel;

    hotel.addGuest(1, "Alice", "alice@example.com");
    hotel.addGuest(2, "Bob", "bob@example.com");
    hotel.addRoom(101, "Single");
    hotel.addRoom(102, "Double");

    hotel.displayGuests();
    hotel.displayRooms();

    hotel.updateGuest(1, "Alice Smith", "alice.smith@example.com");
    hotel.updateRoom(101, "Single", true);

    Guest* guest = hotel.searchGuest(1);
    if (guest) {
        std::cout << "Found Guest: " << guest->name << std::endl;
    }

    Room* room = hotel.searchRoom(101);
    if (room) {
        std::cout << "Found Room: " << room->roomNumber << std::endl;
    }

    hotel.deleteGuest(2);
    hotel.deleteRoom(102);

    hotel.displayGuests();
    hotel.displayRooms();

    return 0;
}