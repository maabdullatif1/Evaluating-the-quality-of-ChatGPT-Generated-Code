#include <iostream>
#include <string>
#include <vector>

struct Guest {
    int id;
    std::string name;
    std::string contact;
};

struct Room {
    int number;
    std::string type;
    bool isAvailable;
};

class HotelReservationSystem {
    std::vector<Guest> guests;
    std::vector<Room> rooms;

    int findGuestIndexById(int id) {
        for (int i = 0; i < guests.size(); ++i) {
            if (guests[i].id == id) return i;
        }
        return -1;
    }

    int findRoomIndexByNumber(int number) {
        for (int i = 0; i < rooms.size(); ++i) {
            if (rooms[i].number == number) return i;
        }
        return -1;
    }

public:
    void addGuest(int id, const std::string& name, const std::string& contact) {
        guests.push_back({id, name, contact});
    }

    void deleteGuest(int id) {
        int index = findGuestIndexById(id);
        if (index != -1) guests.erase(guests.begin() + index);
    }

    void updateGuest(int id, const std::string& name, const std::string& contact) {
        int index = findGuestIndexById(id);
        if (index != -1) guests[index] = {id, name, contact};
    }

    Guest* searchGuest(int id) {
        int index = findGuestIndexById(id);
        return index != -1 ? &guests[index] : nullptr;
    }

    void displayGuests() {
        for (const auto& guest : guests) {
            std::cout << "ID: " << guest.id 
                      << ", Name: " << guest.name 
                      << ", Contact: " << guest.contact << "\n";
        }
    }

    void addRoom(int number, const std::string& type, bool isAvailable) {
        rooms.push_back({number, type, isAvailable});
    }

    void deleteRoom(int number) {
        int index = findRoomIndexByNumber(number);
        if (index != -1) rooms.erase(rooms.begin() + index);
    }

    void updateRoom(int number, const std::string& type, bool isAvailable) {
        int index = findRoomIndexByNumber(number);
        if (index != -1) rooms[index] = {number, type, isAvailable};
    }

    Room* searchRoom(int number) {
        int index = findRoomIndexByNumber(number);
        return index != -1 ? &rooms[index] : nullptr;
    }

    void displayRooms() {
        for (const auto& room : rooms) {
            std::cout << "Room Number: " << room.number 
                      << ", Type: " << room.type 
                      << ", Available: " << (room.isAvailable ? "Yes" : "No") << "\n";
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "Alice", "123456789");
    system.addGuest(2, "Bob", "987654321");
    system.displayGuests();

    system.addRoom(101, "Single", true);
    system.addRoom(102, "Double", false);
    system.displayRooms();

    system.updateGuest(1, "Alice Smith", "1234567890");
    system.searchGuest(1);
    system.displayGuests();

    system.updateRoom(102, "Double", true);
    system.displayRooms();

    system.deleteGuest(2);
    system.deleteRoom(101);

    system.displayGuests();
    system.displayRooms();
    
    return 0;
}