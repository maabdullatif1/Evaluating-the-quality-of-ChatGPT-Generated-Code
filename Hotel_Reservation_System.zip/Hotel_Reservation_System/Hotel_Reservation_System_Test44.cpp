#include <iostream>
#include <vector>
#include <string>

struct Guest {
    int guestID;
    std::string name;
    std::string phone;
};

struct Room {
    int roomNumber;
    std::string type;
    bool isOccupied;
};

class HotelReservationSystem {
private:
    std::vector<Guest> guests;
    std::vector<Room> rooms;

    Guest* findGuestById(int guestID) {
        for (auto& guest : guests) {
            if (guest.guestID == guestID) {
                return &guest;
            }
        }
        return nullptr;
    }

    Room* findRoomByNumber(int roomNumber) {
        for (auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                return &room;
            }
        }
        return nullptr;
    }

public:
    void addGuest(int guestID, const std::string& name, const std::string& phone) {
        if (findGuestById(guestID) == nullptr) {
            guests.push_back({guestID, name, phone});
        }
    }

    void addRoom(int roomNumber, const std::string& type) {
        if (findRoomByNumber(roomNumber) == nullptr) {
            rooms.push_back({roomNumber, type, false});
        }
    }

    void deleteGuest(int guestID) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->guestID == guestID) {
                guests.erase(it);
                break;
            }
        }
    }

    void deleteRoom(int roomNumber) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->roomNumber == roomNumber) {
                rooms.erase(it);
                break;
            }
        }
    }

    void updateGuest(int guestID, const std::string& name, const std::string& phone) {
        Guest* guest = findGuestById(guestID);
        if (guest != nullptr) {
            guest->name = name;
            guest->phone = phone;
        }
    }

    void updateRoom(int roomNumber, const std::string& type, bool isOccupied) {
        Room* room = findRoomByNumber(roomNumber);
        if (room != nullptr) {
            room->type = type;
            room->isOccupied = isOccupied;
        }
    }

    void displayGuests() const {
        for (const auto& guest : guests) {
            std::cout << "Guest ID: " << guest.guestID << ", Name: " << guest.name 
                      << ", Phone: " << guest.phone << std::endl;
        }
    }

    void displayRooms() const {
        for (const auto& room : rooms) {
            std::cout << "Room Number: " << room.roomNumber << ", Type: " << room.type 
                      << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
        }
    }

    void searchGuest(int guestID) const {
        for (const auto& guest : guests) {
            if (guest.guestID == guestID) {
                std::cout << "Found Guest - ID: " << guest.guestID << ", Name: " << guest.name 
                          << ", Phone: " << guest.phone << std::endl;
                return;
            }
        }
        std::cout << "Guest not found." << std::endl;
    }

    void searchRoom(int roomNumber) const {
        for (const auto& room : rooms) {
            if (room.roomNumber == roomNumber) {
                std::cout << "Found Room - Number: " << room.roomNumber << ", Type: " << room.type 
                          << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << std::endl;
                return;
            }
        }
        std::cout << "Room not found." << std::endl;
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe", "123-456-7890");
    system.addRoom(101, "Single");
    system.displayGuests();
    system.displayRooms();
    system.updateGuest(1, "John Smith", "098-765-4321");
    system.updateRoom(101, "Double", true);
    system.displayGuests();
    system.displayRooms();
    system.searchGuest(1);
    system.searchRoom(101);
    system.deleteGuest(1);
    system.deleteRoom(101);
    system.displayGuests();
    system.displayRooms();
    return 0;
}