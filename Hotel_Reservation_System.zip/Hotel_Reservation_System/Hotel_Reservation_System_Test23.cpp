#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Guest {
public:
    int id;
    string name;
    string phone;

    Guest(int id, string name, string phone) : id(id), name(name), phone(phone) {}
};

class Room {
public:
    int number;
    string type;
    bool isOccupied;

    Room(int number, string type, bool isOccupied = false) : number(number), type(type), isOccupied(isOccupied) {}
};

class HotelReservationSystem {
private:
    vector<Guest> guests;
    vector<Room> rooms;

    Guest* findGuest(int id) {
        for (auto &guest : guests) {
            if (guest.id == id)
                return &guest;
        }
        return nullptr;
    }

    Room* findRoom(int number) {
        for (auto &room : rooms) {
            if (room.number == number)
                return &room;
        }
        return nullptr;
    }

public:
    void addGuest(int id, string name, string phone) {
        Guest guest(id, name, phone);
        guests.push_back(guest);
    }

    void deleteGuest(int id) {
        for (auto it = guests.begin(); it != guests.end(); ++it) {
            if (it->id == id) {
                guests.erase(it);
                return;
            }
        }
    }

    void updateGuest(int id, string name, string phone) {
        Guest* guest = findGuest(id);
        if (guest) {
            guest->name = name;
            guest->phone = phone;
        }
    }

    void addRoom(int number, string type, bool isOccupied = false) {
        Room room(number, type, isOccupied);
        rooms.push_back(room);
    }

    void deleteRoom(int number) {
        for (auto it = rooms.begin(); it != rooms.end(); ++it) {
            if (it->number == number) {
                rooms.erase(it);
                return;
            }
        }
    }

    void updateRoom(int number, string type, bool isOccupied) {
        Room* room = findRoom(number);
        if (room) {
            room->type = type;
            room->isOccupied = isOccupied;
        }
    }

    Guest* searchGuest(int id) {
        return findGuest(id);
    }

    Room* searchRoom(int number) {
        return findRoom(number);
    }

    void displayGuests() {
        for (const auto &guest : guests) {
            cout << "ID: " << guest.id << ", Name: " << guest.name << ", Phone: " << guest.phone << endl;
        }
    }

    void displayRooms() {
        for (const auto &room : rooms) {
            cout << "Number: " << room.number << ", Type: " << room.type << ", Occupied: " << (room.isOccupied ? "Yes" : "No") << endl;
        }
    }
};

int main() {
    HotelReservationSystem system;
    system.addGuest(1, "John Doe", "123-456-7890");
    system.addGuest(2, "Jane Smith", "987-654-3210");
    system.addRoom(101, "Single");
    system.addRoom(102, "Double", true);

    system.displayGuests();
    system.displayRooms();

    system.updateGuest(1, "Johnathan Doe", "111-222-3333");
    system.updateRoom(101, "Single", true);

    cout << "After updates:" << endl;
    system.displayGuests();
    system.displayRooms();

    system.deleteGuest(2);
    system.deleteRoom(102);

    cout << "After deletions:" << endl;
    system.displayGuests();
    system.displayRooms();

    return 0;
}