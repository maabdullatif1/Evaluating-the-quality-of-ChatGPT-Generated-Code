#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;

    Item(int id, std::string name, int quantity, double price)
        : id(id), name(name), quantity(quantity), price(price) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(int id, std::string name, int quantity, double price) {
        items.push_back(Item(id, name, quantity, price));
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, std::string name, int quantity, double price) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    Item* searchItem(int id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for (auto& item : items) {
            std::cout << "ID: " << item.id << " Name: " << item.name
                      << " Quantity: " << item.quantity << " Price: " << item.price << "\n";
        }
    }

    void displaySuppliers() {
        for (auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << " Name: " << supplier.name
                      << " Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem(1, "Item1", 100, 10.5);
    ims.addItem(2, "Item2", 150, 20.0);
    ims.addSupplier(1, "Supplier1", "Contact1");
    ims.addSupplier(2, "Supplier2", "Contact2");
    
    std::cout << "Items:\n";
    ims.displayItems();
    
    std::cout << "\nSuppliers:\n";
    ims.displaySuppliers();
    
    ims.updateItem(1, "NewItem1", 110, 11.0);
    ims.deleteSupplier(2);
    
    std::cout << "\nUpdated Items:\n";
    ims.displayItems();
    
    std::cout << "\nUpdated Suppliers:\n";
    ims.displaySuppliers();

    return 0;
}