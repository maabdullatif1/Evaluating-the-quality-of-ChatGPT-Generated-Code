#include <iostream>
#include <string>
#include <vector>

struct Supplier {
    int supplierID;
    std::string name;
    std::string contact;
};

struct Item {
    int itemID;
    std::string description;
    int quantity;
    Supplier supplier;
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;
    
    Supplier* findSupplierByID(int supplierID) {
        for (auto& supplier : suppliers) {
            if (supplier.supplierID == supplierID) {
                return &supplier;
            }
        }
        return nullptr;
    }

public:
    void addSupplier(int id, const std::string& name, const std::string& contact) {
        Supplier supplier{id, name, contact};
        suppliers.push_back(supplier);
    }

    void deleteSupplier(int supplierID) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->supplierID == supplierID) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int supplierID, const std::string& name, const std::string& contact) {
        Supplier* supplier = findSupplierByID(supplierID);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void addItem(int itemID, const std::string& description, int quantity, int supplierID) {
        Supplier* supplier = findSupplierByID(supplierID);
        if (supplier) {
            Item item{itemID, description, quantity, *supplier};
            items.push_back(item);
        }
    }

    void deleteItem(int itemID) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->itemID == itemID) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int itemID, const std::string& description, int quantity, int supplierID) {
        for (auto& item : items) {
            if (item.itemID == itemID) {
                item.description = description;
                item.quantity = quantity;
                Supplier* supplier = findSupplierByID(supplierID);
                if (supplier) {
                    item.supplier = *supplier;
                }
                break;
            }
        }
    }

    Item* searchItem(int itemID) {
        for (auto& item : items) {
            if (item.itemID == itemID) {
                return &item;
            }
        }
        return nullptr;
    }

    Supplier* searchSupplier(int supplierID) {
        return findSupplierByID(supplierID);
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "ID: " << item.itemID << ", Description: " << item.description 
                      << ", Quantity: " << item.quantity 
                      << ", Supplier: " << item.supplier.name << " (" << item.supplier.contact << ")" << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.supplierID << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier(1, "Supplier A", "123-456-7890");
    ims.addSupplier(2, "Supplier B", "987-654-3210");
    ims.addItem(101, "Item 1", 50, 1);
    ims.addItem(102, "Item 2", 30, 2);
    ims.updateItem(102, "Item 2 - Updated", 45, 1);
    ims.displayItems();
    ims.displaySuppliers();
    ims.deleteSupplier(1);
    ims.deleteItem(101);
    ims.displayItems();
    ims.displaySuppliers();
    return 0;
}