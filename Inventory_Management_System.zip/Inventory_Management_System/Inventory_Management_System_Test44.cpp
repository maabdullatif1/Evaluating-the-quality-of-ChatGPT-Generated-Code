#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    std::string id;
    std::string name;
    std::string contact;
    
    Supplier(std::string id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}

    void display() const {
        std::cout << "Supplier ID: " << id << ", Name: " << name << ", Contact: " << contact << std::endl;
    }
};

class Item {
public:
    std::string id;
    std::string name;
    int quantity;
    double price;
    std::string supplierId;

    Item(std::string id, std::string name, int quantity, double price, std::string supplierId)
        : id(id), name(name), quantity(quantity), price(price), supplierId(supplierId) {}

    void display() const {
        std::cout << "Item ID: " << id << ", Name: " << name << ", Quantity: " << quantity << ", Price: " << price << ", Supplier ID: " << supplierId << std::endl;
    }
};

class InventorySystem {
private:
    std::vector<Supplier> suppliers;
    std::vector<Item> items;

public:
    void addSupplier(const Supplier& supplier) {
        suppliers.push_back(supplier);
    }

    void deleteSupplier(const std::string& id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(const std::string& id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(const std::string& id) const {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.display();
                return;
            }
        }
        std::cout << "Supplier not found." << std::endl;
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            supplier.display();
        }
    }

    void addItem(const Item& item) {
        items.push_back(item);
    }

    void deleteItem(const std::string& id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(const std::string& id, const std::string& name, int quantity, double price, const std::string& supplierId) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                item.supplierId = supplierId;
                break;
            }
        }
    }

    void searchItem(const std::string& id) const {
        for (const auto& item : items) {
            if (item.id == id) {
                item.display();
                return;
            }
        }
        std::cout << "Item not found." << std::endl;
    }

    void displayItems() const {
        for (const auto& item : items) {
            item.display();
        }
    }
};

int main() {
    InventorySystem system;
    system.addSupplier(Supplier("S1", "Supplier A", "1234567890"));
    system.addSupplier(Supplier("S2", "Supplier B", "0987654321"));
    system.displaySuppliers();
    system.addItem(Item("I1", "Item 1", 10, 15.5, "S1"));
    system.addItem(Item("I2", "Item 2", 5, 25.0, "S2"));
    system.displayItems();
    system.searchItem("I1");
    system.updateItem("I1", "Updated Item", 20, 30.0, "S1");
    system.searchItem("I1");
    system.deleteItem("I2");
    system.displayItems();
    return 0;
}