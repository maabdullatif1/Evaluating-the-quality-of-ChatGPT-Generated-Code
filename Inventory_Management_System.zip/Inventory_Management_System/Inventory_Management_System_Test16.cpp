#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Supplier {
    int id;
    string name;
    string contact;
};

struct Item {
    int id;
    string name;
    int quantity;
    double price;
    int supplierId;
};

class InventorySystem {
private:
    vector<Supplier> suppliers;
    vector<Item> items;

public:
    void addSupplier(int id, string name, string contact) {
        suppliers.push_back({id, name, contact});
    }

    void addItem(int id, string name, int quantity, double price, int supplierId) {
        items.push_back({id, name, quantity, price, supplierId});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void updateItem(int id, string name, int quantity, double price, int supplierId) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                item.supplierId = supplierId;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    Item* searchItem(int id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }

    void displayItems() {
        for (const auto& item : items) {
            cout << "ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity
                 << ", Price: " << item.price << ", Supplier ID: " << item.supplierId << endl;
        }
    }
};

int main() {
    InventorySystem system;

    system.addSupplier(1, "Supplier A", "123-456-7890");
    system.addItem(1, "Item 1", 10, 99.99, 1);

    system.displaySuppliers();
    system.displayItems();

    system.updateSupplier(1, "Supplier A+", "098-765-4321");
    system.updateItem(1, "Item 1+", 15, 89.99, 1);

    system.displaySuppliers();
    system.displayItems();

    Supplier* supplier = system.searchSupplier(1);
    if (supplier) {
        cout << "Found Supplier: " << supplier->name << endl;
    } else {
        cout << "Supplier not found." << endl;
    }

    Item* item = system.searchItem(1);
    if (item) {
        cout << "Found Item: " << item->name << endl;
    } else {
        cout << "Item not found." << endl;
    }

    system.deleteSupplier(1);
    system.deleteItem(1);

    system.displaySuppliers();
    system.displayItems();

    return 0;
}