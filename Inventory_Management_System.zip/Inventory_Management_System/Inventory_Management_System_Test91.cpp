#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Supplier {
    int id;
    string name;
    string contact;
};

struct Item {
    int id;
    string name;
    int quantity;
    Supplier supplier;
};

class InventorySystem {
private:
    vector<Item> items;
    vector<Supplier> suppliers;

    Item* findItemById(int id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

public:
    void addSupplier(int id, string name, string contact) {
        suppliers.push_back({id, name, contact});
    }

    void addItem(int id, string name, int quantity, int supplierId) {
        Supplier* supplier = findSupplierById(supplierId);
        if (supplier != nullptr) {
            items.push_back({id, name, quantity, *supplier});
        }
    }

    void deleteSupplier(int id) {
        suppliers.erase(remove_if(suppliers.begin(), suppliers.end(),
            [id](Supplier& s) { return s.id == id; }), suppliers.end());
    }

    void deleteItem(int id) {
        items.erase(remove_if(items.begin(), items.end(),
            [id](Item& item) { return item.id == id; }), items.end());
    }

    void updateItem(int id, string name, int quantity, int supplierId) {
        Item* item = findItemById(id);
        Supplier* supplier = findSupplierById(supplierId);
        if (item != nullptr && supplier != nullptr) {
            item->name = name;
            item->quantity = quantity;
            item->supplier = *supplier;
        }
    }

    void searchItemByName(string name) {
        for (const auto& item : items) {
            if (item.name == name) {
                cout << "ID: " << item.id << ", Name: " << item.name 
                     << ", Quantity: " << item.quantity 
                     << ", Supplier: " << item.supplier.name << endl;
            }
        }
    }

    void displayItems() {
        for (const auto& item : items) {
            cout << "ID: " << item.id << ", Name: " << item.name 
                 << ", Quantity: " << item.quantity 
                 << ", Supplier: " << item.supplier.name << endl;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name 
                 << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    InventorySystem inventory;
    inventory.addSupplier(1, "Supplier A", "123-456");
    inventory.addSupplier(2, "Supplier B", "789-012");

    inventory.addItem(1, "Item A", 100, 1);
    inventory.addItem(2, "Item B", 200, 2);

    inventory.displaySuppliers();
    inventory.displayItems();

    inventory.updateItem(1, "Item AA", 150, 2);
    inventory.searchItemByName("Item AA");

    inventory.deleteItem(2);
    inventory.deleteSupplier(1);

    inventory.displaySuppliers();
    inventory.displayItems();

    return 0;
}