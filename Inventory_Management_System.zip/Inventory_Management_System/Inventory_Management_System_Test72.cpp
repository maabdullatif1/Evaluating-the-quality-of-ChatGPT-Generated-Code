#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;

    Item(int id, std::string name, int quantity, double price)
        : id(id), name(name), quantity(quantity), price(price) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    int findItemIndex(int id) {
        for (int i = 0; i < items.size(); ++i) {
            if (items[i].id == id)
                return i;
        }
        return -1;
    }

    int findSupplierIndex(int id) {
        for (int i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].id == id)
                return i;
        }
        return -1;
    }

public:
    void addItem(int id, std::string name, int quantity, double price) {
        items.push_back(Item(id, name, quantity, price));
    }

    void deleteItem(int id) {
        int index = findItemIndex(id);
        if (index != -1) {
            items.erase(items.begin() + index);
        }
    }

    void updateItem(int id, std::string name, int quantity, double price) {
        int index = findItemIndex(id);
        if (index != -1) {
            items[index] = Item(id, name, quantity, price);
        }
    }

    Item* searchItem(int id) {
        int index = findItemIndex(id);
        if (index != -1) {
            return &items[index];
        }
        return nullptr;
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item ID: " << item.id
                      << ", Name: " << item.name
                      << ", Quantity: " << item.quantity
                      << ", Price: " << item.price << std::endl;
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        int index = findSupplierIndex(id);
        if (index != -1) {
            suppliers.erase(suppliers.begin() + index);
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        int index = findSupplierIndex(id);
        if (index != -1) {
            suppliers[index] = Supplier(id, name, contact);
        }
    }

    Supplier* searchSupplier(int id) {
        int index = findSupplierIndex(id);
        if (index != -1) {
            return &suppliers[index];
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id
                      << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem(1, "Item1", 100, 9.99);
    ims.addItem(2, "Item2", 50, 19.99);
    ims.displayItems();
    ims.addSupplier(1, "Supplier1", "123-456-7890");
    ims.addSupplier(2, "Supplier2", "987-654-3210");
    ims.displaySuppliers();
    return 0;
}