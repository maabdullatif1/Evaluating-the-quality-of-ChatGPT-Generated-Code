#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    std::string name;
    std::string contact;
    
    Supplier(std::string n, std::string c) : name(n), contact(c) {}
};

class Item {
public:
    std::string name;
    int quantity;
    double price;
    Supplier supplier;
    
    Item(std::string n, int q, double p, Supplier s) 
        : name(n), quantity(q), price(p), supplier(s) {}
};

class Inventory {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.emplace_back(name, contact);
    }

    void addItem(const std::string& name, int quantity, double price, const std::string& supplierName) {
        for (auto &sup : suppliers) {
            if (sup.name == supplierName) {
                items.emplace_back(name, quantity, price, sup);
                return;
            }
        }
        std::cout << "Supplier not found.\n";
    }

    void deleteItem(const std::string& name) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->name == name) {
                items.erase(it);
                return;
            }
        }
        std::cout << "Item not found.\n";
    }

    void updateItem(const std::string& name, int quantity, double price) {
        for (auto &item : items) {
            if (item.name == name) {
                item.quantity = quantity;
                item.price = price;
                return;
            }
        }
        std::cout << "Item not found.\n";
    }

    void searchItem(const std::string& name) {
        for (const auto &item : items) {
            if (item.name == name) {
                std::cout << "Item: " << item.name 
                          << ", Quantity: " << item.quantity 
                          << ", Price: $" << item.price 
                          << ", Supplier: " << item.supplier.name 
                          << ", Contact: " << item.supplier.contact << "\n";
                return;
            }
        }
        std::cout << "Item not found.\n";
    }
    
    void displayItems() {
        if (items.empty()) {
            std::cout << "No items in inventory.\n";
            return;
        }
        for (const auto &item : items) {
            std::cout << "Item: " << item.name 
                      << ", Quantity: " << item.quantity 
                      << ", Price: $" << item.price 
                      << ", Supplier: " << item.supplier.name 
                      << ", Contact: " << item.supplier.contact << "\n";
        }
    }

    void displaySuppliers() {
        if (suppliers.empty()) {
            std::cout << "No suppliers available.\n";
            return;
        }
        for (const auto &sup : suppliers) {
            std::cout << "Supplier: " << sup.name << ", Contact: " << sup.contact << "\n";
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addSupplier("ABC Supplies", "123-456-7890");
    inventory.addSupplier("XYZ Traders", "987-654-3210");

    inventory.addItem("Laptop", 10, 999.99, "ABC Supplies");
    inventory.addItem("Mouse", 50, 19.99, "XYZ Traders");
    
    std::cout << "All Items:\n";
    inventory.displayItems();
    
    std::cout << "\nAll Suppliers:\n";
    inventory.displaySuppliers();
    
    std::cout << "\nSearching for Laptop:\n";
    inventory.searchItem("Laptop");

    inventory.updateItem("Laptop", 8, 950.99);
    
    std::cout << "\nAfter updating Laptop quantity and price:\n";
    inventory.searchItem("Laptop");

    inventory.deleteItem("Mouse");
    
    std::cout << "\nAfter deleting Mouse:\n";
    inventory.displayItems();

    return 0;
}