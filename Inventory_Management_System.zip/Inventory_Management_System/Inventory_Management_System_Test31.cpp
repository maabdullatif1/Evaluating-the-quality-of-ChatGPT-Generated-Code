#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Item {
public:
    int id;
    string name;
    int quantity;
    double price;
    
    Item(int i, string n, int q, double p) : id(i), name(n), quantity(q), price(p) {}
};

class Supplier {
public:
    int id;
    string name;
    string contactInfo;
    
    Supplier(int i, string n, string c) : id(i), name(n), contactInfo(c) {}
};

class InventorySystem {
private:
    vector<Item> items;
    vector<Supplier> suppliers;
    
    Item* findItemById(int id) {
        for(auto &item : items) {
            if(item.id == id) return &item;
        }
        return nullptr;
    }
    
    Supplier* findSupplierById(int id) {
        for(auto &supplier : suppliers) {
            if(supplier.id == id) return &supplier;
        }
        return nullptr;
    }

public:
    void addItem(int id, string name, int quantity, double price) {
        items.push_back(Item(id, name, quantity, price));
    }
    
    void deleteItem(int id) {
        for(auto it = items.begin(); it != items.end(); ++it) {
            if(it->id == id) {
                items.erase(it);
                return;
            }
        }
    }
    
    void updateItem(int id, string name, int quantity, double price) {
        Item* item = findItemById(id);
        if(item) {
            item->name = name;
            item->quantity = quantity;
            item->price = price;
        }
    }
    
    void searchItem(int id) {
        Item* item = findItemById(id);
        if(item) {
            cout << "Item ID: " << item->id << ", Name: " << item->name
                 << ", Quantity: " << item->quantity << ", Price: " << item->price << endl;
        } else {
            cout << "Item not found" << endl;
        }
    }
    
    void displayItems() {
        for(auto &item : items) {
            cout << "Item ID: " << item.id << ", Name: " << item.name
                 << ", Quantity: " << item.quantity << ", Price: " << item.price << endl;
        }
    }

    void addSupplier(int id, string name, string contactInfo) {
        suppliers.push_back(Supplier(id, name, contactInfo));
    }

    void deleteSupplier(int id) {
        for(auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if(it->id == id) {
                suppliers.erase(it);
                return;
            }
        }
    }

    void updateSupplier(int id, string name, string contactInfo) {
        Supplier* supplier = findSupplierById(id);
        if(supplier) {
            supplier->name = name;
            supplier->contactInfo = contactInfo;
        }
    }
    
    void searchSupplier(int id) {
        Supplier* supplier = findSupplierById(id);
        if(supplier) {
            cout << "Supplier ID: " << supplier->id << ", Name: " << supplier->name
                 << ", Contact: " << supplier->contactInfo << endl;
        } else {
            cout << "Supplier not found" << endl;
        }
    }

    void displaySuppliers() {
        for(auto &supplier : suppliers) {
            cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name
                 << ", Contact: " << supplier.contactInfo << endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addItem(1, "Laptop", 10, 999.99);
    system.addItem(2, "Mouse", 50, 19.99);
    system.addSupplier(1, "ABC Supplies", "contact@abc.com");
    system.addSupplier(2, "XYZ Distributors", "sales@xyz.com");
    
    cout << "Displaying Items:" << endl;
    system.displayItems();

    cout << "\nDisplaying Suppliers:" << endl;
    system.displaySuppliers();

    return 0;
}