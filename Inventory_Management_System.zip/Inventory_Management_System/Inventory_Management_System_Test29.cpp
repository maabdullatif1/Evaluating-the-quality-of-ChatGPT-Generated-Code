#include <iostream>
#include <string>

struct Item {
    int id;
    std::string name;
    int quantity;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contactInfo;
};

class InventoryManagement {
    Item items[100];
    Supplier suppliers[100];
    int itemCount;
    int supplierCount;

public:
    InventoryManagement() : itemCount(0), supplierCount(0) {}

    void addItem(int id, const std::string& name, int quantity, double price) {
        items[itemCount++] = {id, name, quantity, price};
    }

    void addSupplier(int id, const std::string& name, const std::string& contactInfo) {
        suppliers[supplierCount++] = {id, name, contactInfo};
    }

    void deleteItem(int id) {
        for (int i = 0; i < itemCount; ++i) {
            if (items[i].id == id) {
                items[i] = items[--itemCount];
                break;
            }
        }
    }

    void deleteSupplier(int id) {
        for (int i = 0; i < supplierCount; ++i) {
            if (suppliers[i].id == id) {
                suppliers[i] = suppliers[--supplierCount];
                break;
            }
        }
    }

    void updateItem(int id, const std::string& name, int quantity, double price) {
        for (int i = 0; i < itemCount; ++i) {
            if (items[i].id == id) {
                items[i].name = name;
                items[i].quantity = quantity;
                items[i].price = price;
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contactInfo) {
        for (int i = 0; i < supplierCount; ++i) {
            if (suppliers[i].id == id) {
                suppliers[i].name = name;
                suppliers[i].contactInfo = contactInfo;
                break;
            }
        }
    }

    Item* searchItem(int id) {
        for (int i = 0; i < itemCount; ++i) {
            if (items[i].id == id)
                return &items[i];
        }
        return nullptr;
    }

    Supplier* searchSupplier(int id) {
        for (int i = 0; i < supplierCount; ++i) {
            if (suppliers[i].id == id)
                return &suppliers[i];
        }
        return nullptr;
    }

    void displayItems() {
        for (int i = 0; i < itemCount; ++i) {
            std::cout << "ID: " << items[i].id << ", Name: " << items[i].name
                      << ", Quantity: " << items[i].quantity << ", Price: " << items[i].price << '\n';
        }
    }

    void displaySuppliers() {
        for (int i = 0; i < supplierCount; ++i) {
            std::cout << "ID: " << suppliers[i].id << ", Name: " << suppliers[i].name
                      << ", Contact: " << suppliers[i].contactInfo << '\n';
        }
    }
};

int main() {
    InventoryManagement system;
    system.addItem(1, "Item1", 10, 15.5);
    system.addSupplier(1, "Supplier1", "123-456-7890");
    system.displayItems();
    system.displaySuppliers();
    Item* item = system.searchItem(1);
    if (item) {
        std::cout << "Found item: " << item->name << '\n';
    }
    Supplier* supplier = system.searchSupplier(1);
    if (supplier) {
        std::cout << "Found supplier: " << supplier->name << '\n';
    }
    system.updateItem(1, "NewItem", 20, 25.5);
    system.updateSupplier(1, "NewSupplier", "987-654-3210");
    system.displayItems();
    system.displaySuppliers();
    system.deleteItem(1);
    system.deleteSupplier(1);
    system.displayItems();
    system.displaySuppliers();
    return 0;
}