#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Item {
public:
    int id;
    string name;
    int quantity;
    double price;
    int supplierId;

    Item(int i, const string &n, int q, double p, int sId) : id(i), name(n), quantity(q), price(p), supplierId(sId) {}
};

class Supplier {
public:
    int id;
    string name;
    string contact;

    Supplier(int i, const string &n, const string &c) : id(i), name(n), contact(c) {}
};

class InventorySystem {
private:
    vector<Item> items;
    vector<Supplier> suppliers;

public:
    void addItem(int id, const string &name, int quantity, double price, int supplierId) {
        items.emplace_back(id, name, quantity, price, supplierId);
    }

    void deleteItem(int id) {
        items.erase(remove_if(items.begin(), items.end(), [&](Item &item) { return item.id == id; }), items.end());
    }

    void updateItem(int id, const string &name, int quantity, double price, int supplierId) {
        for (auto &item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                item.supplierId = supplierId;
            }
        }
    }

    Item *searchItem(int id) {
        for (auto &item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for (const auto &item : items) {
            cout << "ID: " << item.id << " Name: " << item.name << " Quantity: " << item.quantity
                 << " Price: " << item.price << " Supplier ID: " << item.supplierId << endl;
        }
    }

    void addSupplier(int id, const string &name, const string &contact) {
        suppliers.emplace_back(id, name, contact);
    }

    void deleteSupplier(int id) {
        suppliers.erase(remove_if(suppliers.begin(), suppliers.end(), [&](Supplier &supplier) { return supplier.id == id; }), suppliers.end());
    }

    void updateSupplier(int id, const string &name, const string &contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
            }
        }
    }

    Supplier *searchSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            cout << "ID: " << supplier.id << " Name: " << supplier.name << " Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addSupplier(1, "Supplier One", "123-456-7890");
    system.addItem(1, "Item One", 10, 19.99, 1);
    system.displaySuppliers();
    system.displayItems();

    return 0;
}