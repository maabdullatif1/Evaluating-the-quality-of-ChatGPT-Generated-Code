#include <iostream>
#include <string>

struct Supplier {
    int supplierID;
    std::string name;
    std::string contact;
};

struct Item {
    int itemID;
    std::string name;
    int quantity;
    double price;
    Supplier supplier;
};

class InventoryManagement {
    Item items[100];
    int itemCount;

public:
    InventoryManagement() : itemCount(0) {}

    void addItem(int itemID, const std::string& name, int quantity, double price, const Supplier& supplier) {
        items[itemCount++] = { itemID, name, quantity, price, supplier };
    }

    void deleteItem(int itemID) {
        for (int i = 0; i < itemCount; ++i) {
            if (items[i].itemID == itemID) {
                for (int j = i; j < itemCount - 1; ++j) {
                    items[j] = items[j + 1];
                }
                --itemCount;
                return;
            }
        }
    }

    void updateItem(int itemID, const std::string& name, int quantity, double price, const Supplier& supplier) {
        for (int i = 0; i < itemCount; ++i) {
            if (items[i].itemID == itemID) {
                items[i] = { itemID, name, quantity, price, supplier };
                return;
            }
        }
    }

    Item* searchItem(int itemID) {
        for (int i = 0; i < itemCount; ++i) {
            if (items[i].itemID == itemID) {
                return &items[i];
            }
        }
        return nullptr;
    }

    void displayItems() const {
        for (int i = 0; i < itemCount; ++i) {
            std::cout << "Item ID: " << items[i].itemID
                      << " Name: " << items[i].name
                      << " Quantity: " << items[i].quantity
                      << " Price: " << items[i].price
                      << " Supplier ID: " << items[i].supplier.supplierID
                      << " Supplier Name: " << items[i].supplier.name
                      << " Supplier Contact: " << items[i].supplier.contact << '\n';
        }
    }
};

int main() {
    InventoryManagement inv;

    Supplier s1 = {101, "Supplier A", "123456789"};
    Supplier s2 = {102, "Supplier B", "987654321"};

    inv.addItem(1, "Item 1", 100, 10.0, s1);
    inv.addItem(2, "Item 2", 150, 15.0, s2);

    inv.displayItems();

    inv.updateItem(1, "Updated Item 1", 200, 20.0, s2);

    inv.displayItems();

    inv.deleteItem(2);

    inv.displayItems();

    return 0;
}