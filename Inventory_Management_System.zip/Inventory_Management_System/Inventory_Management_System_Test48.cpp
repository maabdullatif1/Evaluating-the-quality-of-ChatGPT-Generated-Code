#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Supplier {
public:
    int id;
    string name;
    string contact;
    
    Supplier(int id, string name, string contact) 
        : id(id), name(name), contact(contact) {}
};

class Item {
public:
    int id;
    string name;
    int quantity;
    float price;
    int supplierId;
    
    Item(int id, string name, int quantity, float price, int supplierId) 
        : id(id), name(name), quantity(quantity), price(price), supplierId(supplierId) {}
};

class InventoryManagementSystem {
private:
    vector<Supplier> suppliers;
    vector<Item> items;

    Supplier* findSupplierById(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id)
                return &supplier;
        }
        return nullptr;
    }

    Item* findItemById(int id) {
        for (auto& item : items) {
            if (item.id == id)
                return &item;
        }
        return nullptr;
    }

public:
    void addSupplier(int id, string name, string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void searchSupplier(int id) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            cout << "Supplier ID: " << supplier->id << ", Name: " << supplier->name 
                 << ", Contact: " << supplier->contact << endl;
        } else {
            cout << "Supplier not found" << endl;
        }
    }

    void displaySuppliers() {
        for (auto& supplier : suppliers) {
            cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name 
                 << ", Contact: " << supplier.contact << endl;
        }
    }

    void addItem(int id, string name, int quantity, float price, int supplierId) {
        items.push_back(Item(id, name, quantity, price, supplierId));
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, string name, int quantity, float price, int supplierId) {
        Item* item = findItemById(id);
        if (item) {
            item->name = name;
            item->quantity = quantity;
            item->price = price;
            item->supplierId = supplierId;
        }
    }

    void searchItem(int id) {
        Item* item = findItemById(id);
        if (item) {
            cout << "Item ID: " << item->id << ", Name: " << item->name 
                 << ", Quantity: " << item->quantity << ", Price: " << item->price
                 << ", Supplier ID: " << item->supplierId << endl;
        } else {
            cout << "Item not found" << endl;
        }
    }

    void displayItems() {
        for (auto& item : items) {
            cout << "Item ID: " << item.id << ", Name: " << item.name 
                 << ", Quantity: " << item.quantity << ", Price: " << item.price
                 << ", Supplier ID: " << item.supplierId << endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addSupplier(1, "Supplier A", "01234");
    ims.addSupplier(2, "Supplier B", "56789");

    ims.addItem(1, "Item 1", 100, 10.5, 1);
    ims.addItem(2, "Item 2", 200, 20.0, 2);

    ims.displaySuppliers();
    ims.displayItems();

    ims.updateSupplier(1, "Updated Supplier A", "99999");
    ims.updateItem(1, "Updated Item 1", 150, 15.0, 1);

    ims.searchSupplier(1);
    ims.searchItem(1);

    ims.deleteSupplier(2);
    ims.deleteItem(2);
    
    ims.displaySuppliers();
    ims.displayItems();

    return 0;
}