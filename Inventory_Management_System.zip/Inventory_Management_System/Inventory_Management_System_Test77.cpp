#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int itemId;
    std::string itemName;
    int quantity;
    double price;
    
    Item(int id, std::string name, int qty, double prc)
        : itemId(id), itemName(name), quantity(qty), price(prc) {}
};

class Supplier {
public:
    int supplierId;
    std::string supplierName;
    std::string contactInfo;

    Supplier(int id, std::string name, std::string contact)
        : supplierId(id), supplierName(name), contactInfo(contact) {}
};

class InventoryManagementSystem {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;
    
public:
    void addItem(int itemId, std::string itemName, int quantity, double price) {
        items.push_back(Item(itemId, itemName, quantity, price));
    }

    void deleteItem(int itemId) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->itemId == itemId) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int itemId, std::string itemName, int quantity, double price) {
        for (auto &item : items) {
            if (item.itemId == itemId) {
                item.itemName = itemName;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    void searchItem(int itemId) {
        for (const auto &item : items) {
            if (item.itemId == itemId) {
                std::cout << "Item ID: " << item.itemId 
                          << ", Name: " << item.itemName 
                          << ", Quantity: " << item.quantity 
                          << ", Price: " << item.price << std::endl;
                return;
            }
        }
        std::cout << "Item not found" << std::endl;
    }

    void displayItems() {
        for (const auto &item : items) {
            std::cout << "Item ID: " << item.itemId 
                      << ", Name: " << item.itemName 
                      << ", Quantity: " << item.quantity 
                      << ", Price: " << item.price << std::endl;
        }
    }

    void addSupplier(int supplierId, std::string supplierName, std::string contactInfo) {
        suppliers.push_back(Supplier(supplierId, supplierName, contactInfo));
    }

    void deleteSupplier(int supplierId) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->supplierId == supplierId) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int supplierId, std::string supplierName, std::string contactInfo) {
        for (auto &supplier : suppliers) {
            if (supplier.supplierId == supplierId) {
                supplier.supplierName = supplierName;
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    void searchSupplier(int supplierId) {
        for (const auto &supplier : suppliers) {
            if (supplier.supplierId == supplierId) {
                std::cout << "Supplier ID: " << supplier.supplierId 
                          << ", Name: " << supplier.supplierName 
                          << ", Contact: " << supplier.contactInfo << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found" << std::endl;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.supplierId 
                      << ", Name: " << supplier.supplierName 
                      << ", Contact: " << supplier.contactInfo << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem(1, "Item1", 10, 15.5);
    ims.addItem(2, "Item2", 5, 7.5);
    ims.displayItems();
    ims.searchItem(1);
    ims.updateItem(1, "NewItem1", 20, 20.0);
    ims.displayItems();
    ims.deleteItem(2);
    ims.displayItems();

    ims.addSupplier(100, "Supplier1", "contact1@example.com");
    ims.addSupplier(101, "Supplier2", "contact2@example.com");
    ims.displaySuppliers();
    ims.searchSupplier(100);
    ims.updateSupplier(100, "UpdatedSupplier1", "updated_contact1@example.com");
    ims.displaySuppliers();
    ims.deleteSupplier(101);
    ims.displaySuppliers();

    return 0;
}