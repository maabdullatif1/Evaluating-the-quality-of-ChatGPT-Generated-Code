#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Supplier {
public:
    int id;
    string name;
    string contactInfo;

    Supplier(int i, string n, string c) : id(i), name(n), contactInfo(c) {}
};

class Item {
public:
    int id;
    string name;
    int quantity;
    double price;

    Item(int i, string n, int q, double p) : id(i), name(n), quantity(q), price(p) {}
};

class InventoryManagementSystem {
private:
    vector<Item> items;
    vector<Supplier> suppliers;

public:
    void addItem(int id, string name, int quantity, double price) {
        items.push_back(Item(id, name, quantity, price));
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, string name, int quantity, double price) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    void searchItem(int id) {
        for (const auto& item : items) {
            if (item.id == id) {
                cout << "Item found: " << item.name << ", Quantity: " << item.quantity << ", Price: " << item.price << endl;
                return;
            }
        }
        cout << "Item not found" << endl;
    }

    void displayItems() {
        for (const auto& item : items) {
            cout << "ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity << ", Price: " << item.price << endl;
        }
    }

    void addSupplier(int id, string name, string contactInfo) {
        suppliers.push_back(Supplier(id, name, contactInfo));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                cout << "Supplier found: " << supplier.name << ", Contact: " << supplier.contactInfo << endl;
                return;
            }
        }
        cout << "Supplier not found" << endl;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contactInfo << endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem(1, "Laptop", 10, 999.99);
    ims.addItem(2, "Smartphone", 15, 599.99);
    ims.addSupplier(1, "TechSupplier", "contact@techsupplier.com");
    ims.addSupplier(2, "GadgetProvider", "info@gadgetprovider.com");
    ims.displayItems();
    ims.displaySuppliers();
    ims.searchItem(1);
    ims.searchSupplier(2);
    ims.updateItem(1, "Gaming Laptop", 5, 1499.99);
    ims.updateSupplier(1, "Updated TechSupplier", "newcontact@techsupplier.com");
    ims.displayItems();
    ims.displaySuppliers();
    ims.deleteItem(2);
    ims.deleteSupplier(2);
    ims.displayItems();
    ims.displaySuppliers();
    return 0;
}