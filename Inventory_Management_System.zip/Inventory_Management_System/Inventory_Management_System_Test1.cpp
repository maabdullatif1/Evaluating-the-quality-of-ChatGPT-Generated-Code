#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;
    Item(int i, const std::string &n, int q, double p) : id(i), name(n), quantity(q), price(p) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    Supplier(int i, const std::string &n, const std::string &c) : id(i), name(n), contact(c) {}
};

class InventoryManagementSystem {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(int id, const std::string &name, int qty, double price) {
        items.push_back(Item(id, name, qty, price));
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, const std::string &name, int qty, double price) {
        for (auto &item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = qty;
                item.price = price;
                break;
            }
        }
    }

    Item* searchItem(int id) {
        for (auto &item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for (const auto &item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << "\n";
        }
    }

    void addSupplier(int id, const std::string &name, const std::string &contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string &name, const std::string &contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventoryManagementSystem system;
    system.addItem(1, "Item1", 10, 5.99);
    system.addItem(2, "Item2", 15, 6.99);
    system.addSupplier(1, "Supplier1", "123456789");
    system.addSupplier(2, "Supplier2", "987654321");
    
    system.displayItems();
    system.displaySuppliers();
    
    system.updateItem(1, "NewItem1", 20, 7.99);
    system.updateSupplier(1, "NewSupplier1", "111222333");
    
    system.displayItems();
    system.displaySuppliers();
    
    system.deleteItem(2);
    system.deleteSupplier(2);

    system.displayItems();
    system.displaySuppliers();

    if (auto item = system.searchItem(1)) {
        std::cout << "Found Item: " << item->name << "\n";
    }

    if (auto supplier = system.searchSupplier(1)) {
        std::cout << "Found Supplier: " << supplier->name << "\n";
    }

    return 0;
}