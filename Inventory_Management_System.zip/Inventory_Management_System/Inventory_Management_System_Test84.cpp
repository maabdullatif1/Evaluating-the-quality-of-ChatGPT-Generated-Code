#include <iostream>
#include <vector>
#include <string>

struct Item {
    int id;
    std::string name;
    int quantity;
    double price;
    int supplierId;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventoryManagement {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    void addItem() {
        Item item;
        std::cout << "Enter Item ID: ";
        std::cin >> item.id;
        std::cout << "Enter Item Name: ";
        std::cin >> item.name;
        std::cout << "Enter Quantity: ";
        std::cin >> item.quantity;
        std::cout << "Enter Price: ";
        std::cin >> item.price;
        std::cout << "Enter Supplier ID: ";
        std::cin >> item.supplierId;
        items.push_back(item);
    }

    void deleteItem() {
        int id;
        std::cout << "Enter Item ID to delete: ";
        std::cin >> id;
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem() {
        int id;
        std::cout << "Enter Item ID to update: ";
        std::cin >> id;
        for (auto &item : items) {
            if (item.id == id) {
                std::cout << "Update Name: ";
                std::cin >> item.name;
                std::cout << "Update Quantity: ";
                std::cin >> item.quantity;
                std::cout << "Update Price: ";
                std::cin >> item.price;
                std::cout << "Update Supplier ID: ";
                std::cin >> item.supplierId;
                break;
            }
        }
    }

    void searchItem() {
        int id;
        std::cout << "Enter Item ID to search: ";
        std::cin >> id;
        for (const auto &item : items) {
            if (item.id == id) {
                std::cout << "ID: " << item.id << "\nName: " << item.name << "\nQuantity: " << item.quantity << "\nPrice: " << item.price << "\nSupplier ID: " << item.supplierId << "\n";
                return;
            }
        }
        std::cout << "Item not found\n";
    }

    void displayItems() {
        for (const auto &item : items) {
            std::cout << "ID: " << item.id << "\nName: " << item.name << "\nQuantity: " << item.quantity << "\nPrice: " << item.price << "\nSupplier ID: " << item.supplierId << "\n\n";
        }
    }

    void addSupplier() {
        Supplier supplier;
        std::cout << "Enter Supplier ID: ";
        std::cin >> supplier.id;
        std::cout << "Enter Supplier Name: ";
        std::cin >> supplier.name;
        std::cout << "Enter Supplier Contact: ";
        std::cin >> supplier.contact;
        suppliers.push_back(supplier);
    }

    void deleteSupplier() {
        int id;
        std::cout << "Enter Supplier ID to delete: ";
        std::cin >> id;
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier() {
        int id;
        std::cout << "Enter Supplier ID to update: ";
        std::cin >> id;
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                std::cout << "Update Name: ";
                std::cin >> supplier.name;
                std::cout << "Update Contact: ";
                std::cin >> supplier.contact;
                break;
            }
        }
    }

    void searchSupplier() {
        int id;
        std::cout << "Enter Supplier ID to search: ";
        std::cin >> id;
        for (const auto &supplier : suppliers) {
            if (supplier.id == id) {
                std::cout << "ID: " << supplier.id << "\nName: " << supplier.name << "\nContact: " << supplier.contact << "\n";
                return;
            }
        }
        std::cout << "Supplier not found\n";
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "ID: " << supplier.id << "\nName: " << supplier.name << "\nContact: " << supplier.contact << "\n\n";
        }
    }

public:
    void menu() {
        while (true) {
            int choice;
            std::cout << "1. Add Item\n2. Delete Item\n3. Update Item\n4. Search Item\n5. Display Items\n6. Add Supplier\n7. Delete Supplier\n8. Update Supplier\n9. Search Supplier\n10. Display Suppliers\n11. Exit\nEnter choice: ";
            std::cin >> choice;
            switch (choice) {
                case 1: addItem(); break;
                case 2: deleteItem(); break;
                case 3: updateItem(); break;
                case 4: searchItem(); break;
                case 5: displayItems(); break;
                case 6: addSupplier(); break;
                case 7: deleteSupplier(); break;
                case 8: updateSupplier(); break;
                case 9: searchSupplier(); break;
                case 10: displaySuppliers(); break;
                case 11: return;
                default: std::cout << "Invalid choice\n"; break;
            }
        }
    }
};

int main() {
    InventoryManagement system;
    system.menu();
    return 0;
}