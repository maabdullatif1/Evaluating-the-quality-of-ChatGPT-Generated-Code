#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;

    Item(int i, const std::string &n, int q) : id(i), name(n), quantity(q) {}
};

class Supplier {
public:
    int id;
    std::string name;

    Supplier(int i, const std::string &n) : id(i), name(n) {}
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(int id, const std::string &name, int quantity) {
        items.push_back(Item(id, name, quantity));
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                return;
            }
        }
    }

    void updateItem(int id, const std::string &name, int quantity) {
        for (auto &item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                return;
            }
        }
    }

    void searchItem(int id) {
        for (const auto &item : items) {
            if (item.id == id) {
                std::cout << "Item found: ID=" << item.id << ", Name=" << item.name 
                          << ", Quantity=" << item.quantity << std::endl;
                return;
            }
        }
        std::cout << "Item not found." << std::endl;
    }

    void displayItems() {
        for (const auto &item : items) {
            std::cout << "ID=" << item.id << ", Name=" << item.name 
                      << ", Quantity=" << item.quantity << std::endl;
        }
    }

    void addSupplier(int id, const std::string &name) {
        suppliers.push_back(Supplier(id, name));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                return;
            }
        }
    }

    void updateSupplier(int id, const std::string &name) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                return;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto &supplier : suppliers) {
            if (supplier.id == id) {
                std::cout << "Supplier found: ID=" << supplier.id << ", Name=" << supplier.name << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found." << std::endl;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "ID=" << supplier.id << ", Name=" << supplier.name << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addItem(1, "Item1", 100);
    ims.addItem(2, "Item2", 250);
    ims.addSupplier(1, "Supplier1");
    ims.addSupplier(2, "Supplier2");

    std::cout << "Items:" << std::endl;
    ims.displayItems();
    
    std::cout << "Suppliers:" << std::endl;
    ims.displaySuppliers();

    ims.updateItem(1, "NewItem1", 150);
    ims.searchItem(1);

    ims.deleteItem(2);
    ims.displayItems();
    
    ims.updateSupplier(1, "NewSupplier1");
    ims.searchSupplier(1);

    ims.deleteSupplier(2);
    ims.displaySuppliers();

    return 0;
}