#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;
    
    Item(int i, std::string n, int q, double p) : id(i), name(n), quantity(q), price(p) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    
    Supplier(int i, std::string n, std::string c) : id(i), name(n), contact(c) {}
};

class InventoryManagement {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;
    
public:
    void addItem(int id, std::string name, int quantity, double price) {
        items.emplace_back(id, name, quantity, price);
    }
    
    void deleteItem(int id) {
        items.erase(std::remove_if(items.begin(), items.end(), [id](Item& item) { return item.id == id; }), items.end());
    }
    
    void updateItem(int id, std::string name, int quantity, double price) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }
    
    Item* searchItem(int id) {
        for (auto& item : items) {
            if (item.id == id) return &item;
        }
        return nullptr;
    }
    
    void displayItems() {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity << ", Price: $" << item.price << std::endl;
        }
    }
    
    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.emplace_back(id, name, contact);
    }
    
    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(), [id](Supplier& supplier) { return supplier.id == id; }), suppliers.end());
    }
    
    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }
    
    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) return &supplier;
        }
        return nullptr;
    }
    
    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagement invMng;
    
    invMng.addItem(1, "ItemA", 100, 5.50);
    invMng.addItem(2, "ItemB", 200, 3.75);
    
    invMng.updateItem(1, "ItemA-Updated", 150, 6.00);
    
    invMng.displayItems();
    
    invMng.addSupplier(1, "SupplierA", "123-456-789");
    invMng.addSupplier(2, "SupplierB", "987-654-321");

    invMng.updateSupplier(1, "SupplierA-Updated", "111-222-333");

    invMng.displaySuppliers();

    return 0;
}