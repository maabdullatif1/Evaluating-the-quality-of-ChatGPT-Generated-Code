#include <iostream>
#include <string>
#include <vector>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;

    Item(int _id, const std::string& _name, int _quantity, double _price)
        : id(_id), name(_name), quantity(_quantity), price(_price) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int _id, const std::string& _name, const std::string& _contact)
        : id(_id), name(_name), contact(_contact) {}
};

class InventorySystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    template<typename T>
    void displayEntity(const T& entity) {
        std::cout << "ID: " << entity.id << ", Name: " << entity.name;
    }

public:
    void addItem(int id, const std::string& name, int quantity, double price) {
        items.push_back(Item(id, name, quantity, price));
    }

    void deleteItem(int id) {
        items.erase(std::remove_if(items.begin(), items.end(), [id](Item& item) { return item.id == id; }), items.end());
    }

    void updateItem(int id, const std::string& name, int quantity, double price) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    void searchItem(int id) {
        for (const auto& item : items) {
            if (item.id == id) {
                displayEntity(item);
                std::cout << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
                return;
            }
        }
        std::cout << "Item not found" << std::endl;
    }

    void displayItems() {
        for (const auto& item : items) {
            displayEntity(item);
            std::cout << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
        }
    }

    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(), [id](Supplier& supplier) { return supplier.id == id; }), suppliers.end());
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                displayEntity(supplier);
                std::cout << ", Contact: " << supplier.contact << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found" << std::endl;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            displayEntity(supplier);
            std::cout << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventorySystem inventory;

    inventory.addItem(1, "Laptop", 10, 1000.0);
    inventory.addItem(2, "Tablet", 20, 500.0);
    inventory.displayItems();

    inventory.addSupplier(1, "TechCorp", "contact@techcorp.com");
    inventory.addSupplier(2, "GizmoSupplies", "info@gizmosupplies.com");
    inventory.displaySuppliers();

    inventory.updateItem(1, "Laptop", 15, 950.0);
    inventory.searchItem(1);

    inventory.updateSupplier(1, "TechCorp Ltd.", "sales@techcorp.com");
    inventory.searchSupplier(1);

    inventory.deleteItem(2);
    inventory.displayItems();

    inventory.deleteSupplier(2);
    inventory.displaySuppliers();

    return 0;
}