#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
};

class Item {
public:
    int id;
    std::string name;
    int quantity;
    int supplier_id;
};

class InventoryManagementSystem {
private:
    std::vector<Supplier> suppliers;
    std::vector<Item> items;
    int supplierCounter = 0;
    int itemCounter = 0;

public:
    void addSupplier(const std::string& name, const std::string& contact) {
        Supplier supplier = {++supplierCounter, name, contact};
        suppliers.push_back(supplier);
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(),
            [&id](Supplier& supplier) { return supplier.id == id; }), suppliers.end());
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers)
            if (supplier.id == id)
                return &supplier;
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }

    void addItem(const std::string& name, int quantity, int supplier_id) {
        Item item = {++itemCounter, name, quantity, supplier_id};
        items.push_back(item);
    }

    void deleteItem(int id) {
        items.erase(std::remove_if(items.begin(), items.end(),
            [&id](Item& item) { return item.id == id; }), items.end());
    }

    void updateItem(int id, const std::string& name, int quantity, int supplier_id) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.supplier_id = supplier_id;
            }
        }
    }

    Item* searchItem(int id) {
        for (auto& item : items)
            if (item.id == id)
                return &item;
        return nullptr;
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity << ", Supplier ID: " << item.supplier_id << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier("Supplier A", "123-456-7890");
    ims.addSupplier("Supplier B", "987-654-3210");
    ims.displaySuppliers();
    ims.addItem("Item X", 100, 1);
    ims.addItem("Item Y", 50, 2);
    ims.displayItems();
    return 0;
}