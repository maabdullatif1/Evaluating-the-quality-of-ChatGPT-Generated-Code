#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;

    Item(int i, std::string n, int q, double p) : id(i), name(n), quantity(q), price(p) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int i, std::string n, std::string c) : id(i), name(n), contact(c) {}
};

class InventoryManagementSystem {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;
    
    Item* findItemById(int id) {
        for (auto &item : items) {
            if (item.id == id) return &item;
        }
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) return &supplier;
        }
        return nullptr;
    }

public:
    void addItem(int id, std::string name, int quantity, double price) {
        if (findItemById(id)) return;
        items.push_back(Item(id, name, quantity, price));
    }

    void deleteItem(int id) {
        items.erase(std::remove_if(items.begin(), items.end(), [&](Item &item){ return item.id == id; }), items.end());
    }

    void updateItem(int id, std::string name, int quantity, double price) {
        Item* item = findItemById(id);
        if (item) {
            item->name = name;
            item->quantity = quantity;
            item->price = price;
        }
    }

    void searchItem(int id) {
        Item* item = findItemById(id);
        if (item) {
            std::cout << "Item found: ID: " << item->id << ", Name: " << item->name 
                      << ", Quantity: " << item->quantity << ", Price: " << item->price << std::endl;
        } else {
            std::cout << "Item not found" << std::endl;
        }
    }

    void displayItems() {
        for (const auto &item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name 
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        if (findSupplierById(id)) return;
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(), [&](Supplier &supplier){ return supplier.id == id; }), suppliers.end());
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void searchSupplier(int id) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            std::cout << "Supplier found: ID: " << supplier->id << ", Name: " << supplier->name 
                      << ", Contact: " << supplier->contact << std::endl;
        } else {
            std::cout << "Supplier not found" << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem(1, "Item1", 10, 5.5);
    ims.addItem(2, "Item2", 20, 6.5);
    ims.displayItems();
    ims.searchItem(1);
    ims.updateItem(1, "NewItem1", 15, 7.5);
    ims.deleteItem(2);
    ims.displayItems();
    
    ims.addSupplier(1, "Supplier1", "123456789");
    ims.addSupplier(2, "Supplier2", "987654321");
    ims.displaySuppliers();
    ims.searchSupplier(1);
    ims.updateSupplier(1, "NewSupplier1", "111111111");
    ims.deleteSupplier(2);
    ims.displaySuppliers();

    return 0;
}