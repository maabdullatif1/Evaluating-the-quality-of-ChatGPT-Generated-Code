#include <iostream>
#include <vector>
#include <string>

struct Supplier {
    int id;
    std::string name;
    std::string contactInfo;
};

struct Item {
    int id;
    std::string name;
    int quantity;
    float price;
    int supplierId;
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;
    int nextItemId;
    int nextSupplierId;

public:
    InventoryManagementSystem() : nextItemId(1), nextSupplierId(1) {}

    void addItem(const std::string& name, int quantity, float price, int supplierId) {
        items.push_back({nextItemId++, name, quantity, price, supplierId});
    }

    void addSupplier(const std::string& name, const std::string& contactInfo) {
        suppliers.push_back({nextSupplierId++, name, contactInfo});
    }

    void deleteItem(int itemId) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == itemId) {
                items.erase(it);
                break;
            }
        }
    }

    void deleteSupplier(int supplierId) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == supplierId) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateItem(int itemId, const std::string& name, int quantity, float price, int supplierId) {
        for (auto& item : items) {
            if (item.id == itemId) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                item.supplierId = supplierId;
                break;
            }
        }
    }

    void updateSupplier(int supplierId, const std::string& name, const std::string& contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.id == supplierId) {
                supplier.name = name;
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    Item* searchItemByName(const std::string& name) {
        for (auto& item : items) {
            if (item.name == name) {
                return &item;
            }
        }
        return nullptr;
    }

    Supplier* searchSupplierByName(const std::string& name) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item ID: " << item.id
                      << ", Name: " << item.name
                      << ", Quantity: " << item.quantity
                      << ", Price: " << item.price
                      << ", Supplier ID: " << item.supplierId << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id
                      << ", Name: " << supplier.name
                      << ", Contact Info: " << supplier.contactInfo << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier("Supplier1", "Contact1");
    ims.addSupplier("Supplier2", "Contact2");
    ims.addItem("Item1", 100, 10.5, 1);
    ims.addItem("Item2", 200, 20.5, 2);

    ims.displayItems();
    ims.displaySuppliers();

    ims.updateItem(1, "NewItem1", 150, 15.5, 2);
    ims.updateSupplier(1, "NewSupplier1", "NewContact1");

    ims.displayItems();
    ims.displaySuppliers();

    Item* item = ims.searchItemByName("NewItem1");
    if (item) std::cout << "Found: " << item->name << std::endl;

    Supplier* supplier = ims.searchSupplierByName("NewSupplier1");
    if (supplier) std::cout << "Found: " << supplier->name << std::endl;

    ims.deleteItem(1);
    ims.deleteSupplier(1);

    ims.displayItems();
    ims.displaySuppliers();

    return 0;
}