#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

class Supplier {
public:
    int id;
    std::string name;

    Supplier(int supplierId, const std::string& supplierName) : id(supplierId), name(supplierName) {}
};

class Item {
public:
    int id;
    std::string name;
    int quantity;
    Supplier supplier;

    Item(int itemId, const std::string& itemName, int itemQuantity, const Supplier& itemSupplier) 
        : id(itemId), name(itemName), quantity(itemQuantity), supplier(itemSupplier) {}
};

class InventorySystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    Supplier* findSupplierById(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

public:
    void addItem(int id, const std::string& name, int quantity, int supplierId) {
        Supplier* supplier = findSupplierById(supplierId);
        if (supplier) {
            items.emplace_back(id, name, quantity, *supplier);
        } else {
            std::cout << "Supplier not found.\n";
        }
    }

    void deleteItem(int id) {
        items.erase(std::remove_if(items.begin(), items.end(), [id](const Item& item) { return item.id == id; }), items.end());
    }

    void updateItem(int id, const std::string& name, int quantity, int supplierId) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                Supplier* supplier = findSupplierById(supplierId);
                if (supplier) {
                    item.supplier = *supplier;
                }
                return;
            }
        }
        std::cout << "Item not found.\n";
    }

    void searchItem(int id) {
        for (const auto& item : items) {
            if (item.id == id) {
                std::cout << "Item ID: " << item.id << "\nName: " << item.name 
                          << "\nQuantity: " << item.quantity 
                          << "\nSupplier: " << item.supplier.name << "\n";
                return;
            }
        }
        std::cout << "Item not found.\n";
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item ID: " << item.id << "\nName: " << item.name 
                      << "\nQuantity: " << item.quantity 
                      << "\nSupplier: " << item.supplier.name << "\n\n";
        }
    }

    void addSupplier(int id, const std::string& name) {
        suppliers.emplace_back(id, name);
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(), [id](const Supplier& supplier) { return supplier.id == id; }), suppliers.end());
    }

    void updateSupplier(int id, const std::string& name) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                return;
            }
        }
        std::cout << "Supplier not found.\n";
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << "\nName: " << supplier.name << "\n\n";
        }
    }
};

int main() {
    InventorySystem system;
    system.addSupplier(1, "Supplier A");
    system.addSupplier(2, "Supplier B");

    system.addItem(1, "Item A", 100, 1);
    system.addItem(2, "Item B", 200, 2);

    system.displayItems();
    system.searchItem(1);

    system.updateItem(1, "Updated Item A", 150, 2);
    system.displayItems();

    system.deleteItem(2);
    system.displayItems();

    system.displaySuppliers();
    system.updateSupplier(1, "Updated Supplier A");
    system.displaySuppliers();
    system.deleteSupplier(2);
    system.displaySuppliers();

    return 0;
}