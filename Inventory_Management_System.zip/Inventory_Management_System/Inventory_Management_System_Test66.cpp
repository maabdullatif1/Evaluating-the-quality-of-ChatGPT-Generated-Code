#include <iostream>
#include <vector>
#include <string>

struct Item {
    std::string name;
    int quantity;
    float price;
};

struct Supplier {
    std::string name;
    std::string contact;
};

class InventoryManagement {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    int findItemIndex(const std::string& name) {
        for (int i = 0; i < items.size(); ++i) {
            if (items[i].name == name) return i;
        }
        return -1;
    }

    int findSupplierIndex(const std::string& name) {
        for (int i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].name == name) return i;
        }
        return -1;
    }

public:
    void addItem(const std::string& name, int quantity, float price) {
        int index = findItemIndex(name);
        if (index == -1) {
            items.push_back({name, quantity, price});
        }
    }

    void deleteItem(const std::string& name) {
        int index = findItemIndex(name);
        if (index != -1) {
            items.erase(items.begin() + index);
        }
    }

    void updateItem(const std::string& name, int quantity, float price) {
        int index = findItemIndex(name);
        if (index != -1) {
            items[index].quantity = quantity;
            items[index].price = price;
        }
    }

    Item* searchItem(const std::string& name) {
        int index = findItemIndex(name);
        return (index != -1) ? &items[index] : nullptr;
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item: " << item.name << " Quantity: " << item.quantity << " Price: " << item.price << "\n";
        }
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        int index = findSupplierIndex(name);
        if (index == -1) {
            suppliers.push_back({name, contact});
        }
    }

    void deleteSupplier(const std::string& name) {
        int index = findSupplierIndex(name);
        if (index != -1) {
            suppliers.erase(suppliers.begin() + index);
        }
    }

    void updateSupplier(const std::string& name, const std::string& contact) {
        int index = findSupplierIndex(name);
        if (index != -1) {
            suppliers[index].contact = contact;
        }
    }

    Supplier* searchSupplier(const std::string& name) {
        int index = findSupplierIndex(name);
        return (index != -1) ? &suppliers[index] : nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier: " << supplier.name << " Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addItem("Widget", 10, 2.5);
    inventory.addSupplier("ACME Corp", "123-456-7890");
    inventory.displayItems();
    inventory.displaySuppliers();
    return 0;
}