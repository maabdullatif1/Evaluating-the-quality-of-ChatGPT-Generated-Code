#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;

    Item(int id, std::string name, int quantity, double price)
        : id(id), name(name), quantity(quantity), price(price) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class InventoryManagement {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(int id, std::string name, int quantity, double price) {
        items.push_back(Item(id, name, quantity, price));
    }

    void deleteItem(int id) {
        for (size_t i = 0; i < items.size(); ++i) {
            if (items[i].id == id) {
                items.erase(items.begin() + i);
                break;
            }
        }
    }

    void updateItem(int id, std::string name, int quantity, double price) {
        for (auto &item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    Item* searchItem(int id) {
        for (auto &item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for (const auto &item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << "\n";
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (size_t i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].id == id) {
                suppliers.erase(suppliers.begin() + i);
                break;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventoryManagement inventory;

    inventory.addItem(1, "Item1", 10, 99.99);
    inventory.addItem(2, "Item2", 5, 59.99);
    inventory.displayItems();

    inventory.addSupplier(1, "Supplier1", "123-456-7890");
    inventory.addSupplier(2, "Supplier2", "098-765-4321");
    inventory.displaySuppliers();

    inventory.updateItem(1, "Item1 Updated", 20, 89.99);
    inventory.displayItems();

    inventory.updateSupplier(1, "Supplier1 Updated", "111-222-3333");
    inventory.displaySuppliers();

    inventory.deleteItem(2);
    inventory.displayItems();

    inventory.deleteSupplier(2);
    inventory.displaySuppliers();

    return 0;
}