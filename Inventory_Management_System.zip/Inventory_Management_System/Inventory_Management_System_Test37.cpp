#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;

    Item(int id, const std::string& name, int quantity, double price)
        : id(id), name(name), quantity(quantity), price(price) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, const std::string& name, const std::string& contact)
        : id(id), name(name), contact(contact) {}
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;
    
    Item* findItemById(int id) {
        for(auto& item : items) {
            if(item.id == id) return &item;
        }
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for(auto& supplier : suppliers) {
            if(supplier.id == id) return &supplier;
        }
        return nullptr;
    }

public:
    void addItem(const Item& item) {
        items.push_back(item);
    }

    void deleteItem(int id) {
        for(auto it = items.begin(); it != items.end(); ++it) {
            if(it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, const std::string& name, int quantity, double price) {
        Item* item = findItemById(id);
        if(item) {
            item->name = name;
            item->quantity = quantity;
            item->price = price;
        }
    }

    void searchItem(int id) {
        Item* item = findItemById(id);
        if(item) {
            std::cout << "Item ID: " << item->id << ", Name: " << item->name
                      << ", Quantity: " << item->quantity << ", Price: " << item->price << "\n";
        } else {
            std::cout << "Item not found\n";
        }
    }

    void displayItems() {
        for(const auto& item : items) {
            std::cout << "Item ID: " << item.id << ", Name: " << item.name
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << "\n";
        }
    }

    void addSupplier(const Supplier& supplier) {
        suppliers.push_back(supplier);
    }

    void deleteSupplier(int id) {
        for(auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if(it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        Supplier* supplier = findSupplierById(id);
        if(supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void searchSupplier(int id) {
        Supplier* supplier = findSupplierById(id);
        if(supplier) {
            std::cout << "Supplier ID: " << supplier->id << ", Name: " << supplier->name
                      << ", Contact: " << supplier->contact << "\n";
        } else {
            std::cout << "Supplier not found\n";
        }
    }

    void displaySuppliers() {
        for(const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    
    ims.addItem(Item(1, "Item1", 50, 20.5));
    ims.addItem(Item(2, "Item2", 30, 15.0));
    ims.addSupplier(Supplier(1, "Supplier1", "123-456-7890"));
    ims.addSupplier(Supplier(2, "Supplier2", "098-765-4321"));

    ims.displayItems();
    ims.displaySuppliers();

    ims.searchItem(1);
    ims.searchSupplier(2);

    ims.updateItem(1, "NewItem1", 60, 22.0);
    ims.updateSupplier(1, "NewSupplier1", "112-233-4455");
    
    ims.displayItems();
    ims.displaySuppliers();

    ims.deleteItem(2);
    ims.deleteSupplier(2);

    ims.displayItems();
    ims.displaySuppliers();

    return 0;
}