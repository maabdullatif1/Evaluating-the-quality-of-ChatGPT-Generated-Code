#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Item {
public:
    int id;
    string name;
    int quantity;

    Item(int i, string n, int q) : id(i), name(n), quantity(q) {}
};

class Supplier {
public:
    int id;
    string name;
    string contact_info;

    Supplier(int i, string n, string c) : id(i), name(n), contact_info(c) {}
};

class InventorySystem {
    vector<Item> items;
    vector<Supplier> suppliers;

public:

    void addItem(int id, string name, int quantity) {
        items.push_back(Item(id, name, quantity));
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, string name, int quantity) {
        for (auto &item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                break;
            }
        }
    }

    Item* searchItem(int id) {
        for (auto &item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for (const auto &item : items) {
            cout << "Item ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity << endl;
        }
    }

    void addSupplier(int id, string name, string contact_info) {
        suppliers.push_back(Supplier(id, name, contact_info));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contact_info) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact_info = contact_info;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact Info: " << supplier.contact_info << endl;
        }
    }
};

int main() {
    InventorySystem system;

    system.addItem(1, "Item1", 10);
    system.addItem(2, "Item2", 20);

    system.displayItems();

    system.updateItem(1, "NewItem1", 15);

    Item* item = system.searchItem(2);
    if (item) {
        cout << "Found item: " << item->name << ", Quantity: " << item->quantity << endl;
    }

    system.deleteItem(2);

    system.addSupplier(1, "Supplier1", "contact1@example.com");
    system.addSupplier(2, "Supplier2", "contact2@example.com");

    system.displaySuppliers();

    system.updateSupplier(1, "NewSupplier1", "newcontact1@example.com");

    Supplier* supplier = system.searchSupplier(2);
    if (supplier) {
        cout << "Found supplier: " << supplier->name << ", Contact Info: " << supplier->contact_info << endl;
    }

    system.deleteSupplier(2);

    return 0;
}