#include <iostream>
#include <vector>
#include <string>

struct Item {
    int id;
    std::string name;
    int quantity;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventoryManagementSystem {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    int findItemIndex(int id) {
        for (int i = 0; i < items.size(); ++i) {
            if (items[i].id == id) return i;
        }
        return -1;
    }

    int findSupplierIndex(int id) {
        for (int i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].id == id) return i;
        }
        return -1;
    }

public:
    void addItem(int id, const std::string& name, int quantity, double price) {
        Item item = { id, name, quantity, price };
        items.push_back(item);
    }

    void deleteItem(int id) {
        int index = findItemIndex(id);
        if (index != -1) items.erase(items.begin() + index);
    }

    void updateItem(int id, const std::string& name, int quantity, double price) {
        int index = findItemIndex(id);
        if (index != -1) {
            items[index].name = name;
            items[index].quantity = quantity;
            items[index].price = price;
        }
    }

    void displayItems() const {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name 
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << "\n";
        }
    }

    void searchItem(int id) const {
        int index = findItemIndex(id);
        if (index != -1) {
            const Item& item = items[index];
            std::cout << "ID: " << item.id << ", Name: " << item.name 
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << "\n";
        } else {
            std::cout << "Item not found.\n";
        }
    }

    void addSupplier(int id, const std::string& name, const std::string& contact) {
        Supplier supplier = { id, name, contact };
        suppliers.push_back(supplier);
    }

    void deleteSupplier(int id) {
        int index = findSupplierIndex(id);
        if (index != -1) suppliers.erase(suppliers.begin() + index);
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        int index = findSupplierIndex(id);
        if (index != -1) {
            suppliers[index].name = name;
            suppliers[index].contact = contact;
        }
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << "\n";
        }
    }

    void searchSupplier(int id) const {
        int index = findSupplierIndex(id);
        if (index != -1) {
            const Supplier& supplier = suppliers[index];
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << "\n";
        } else {
            std::cout << "Supplier not found.\n";
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem(1, "Widget", 100, 2.5);
    ims.addSupplier(1, "Supplier Co", "123-456-7890");
    ims.displayItems();
    ims.displaySuppliers();
    return 0;
}