#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, const std::string& name, const std::string& contact)
        : id(id), name(name), contact(contact) {}
};

class Item {
public:
    int id;
    std::string name;
    int quantity;
    int supplierId;

    Item(int id, const std::string& name, int quantity, int supplierId)
        : id(id), name(name), quantity(quantity), supplierId(supplierId) {}
};

class InventoryManagement {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;
    
    Supplier* findSupplier(int supplierId) {
        for (auto& supplier : suppliers) {
            if (supplier.id == supplierId) return &supplier;
        }
        return nullptr;
    }

public:
    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void removeSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(),
                        [id](Supplier& s) { return s.id == id; }), suppliers.end());
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                return;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                std::cout << "Supplier Found: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found" << std::endl;
    }

    void addItem(int id, const std::string& name, int quantity, int supplierId) {
        items.push_back(Item(id, name, quantity, supplierId));
    }

    void removeItem(int id) {
        items.erase(std::remove_if(items.begin(), items.end(),
                      [id](Item& i) { return i.id == id; }), items.end());
    }

    void updateItem(int id, const std::string& name, int quantity, int supplierId) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.supplierId = supplierId;
                return;
            }
        }
    }

    void searchItem(int id) {
        for (const auto& item : items) {
            if (item.id == id) {
                std::cout << "Item Found: " << item.name << ", Quantity: " << item.quantity << std::endl;
                Supplier* supplier = findSupplier(item.supplierId);
                if (supplier) std::cout << "Supplier: " << supplier->name << std::endl;
                return;
            }
        }
        std::cout << "Item not found" << std::endl;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item ID: " << item.id << ", Name: " << item.name
                      << ", Quantity: " << item.quantity << std::endl;
            Supplier* supplier = findSupplier(item.supplierId);
            if (supplier) std::cout << "Supplier: " << supplier->name << std::endl;
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addSupplier(1, "Supplier A", "123-456-7890");
    inventory.addItem(1, "Item A", 100, 1);
    inventory.displaySuppliers();
    inventory.displayItems();
    inventory.searchItem(1);
    inventory.searchSupplier(1);
    inventory.updateSupplier(1, "Supplier A2", "987-654-3210");
    inventory.updateItem(1, "Item A2", 200, 1);
    inventory.displaySuppliers();
    inventory.displayItems();
    inventory.removeItem(1);
    inventory.removeSupplier(1);
    inventory.displayItems();
    inventory.displaySuppliers();
    return 0;
}