#include <iostream>
#include <vector>
#include <string>

struct Item {
    int id;
    std::string name;
    int quantity;
    double price;
    int supplierId;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventoryManager {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    Item* findItemById(int id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

public:
    void addItem(int id, const std::string& name, int quantity, double price, int supplierId) {
        items.push_back({id, name, quantity, price, supplierId});
    }

    void deleteItem(int id) {
        items.erase(std::remove_if(items.begin(), items.end(),
                                   [id](const Item& item) { return item.id == id; }),
                    items.end());
    }

    void updateItem(int id, const std::string& name, int quantity, double price, int supplierId) {
        Item* item = findItemById(id);
        if (item) {
            item->name = name;
            item->quantity = quantity;
            item->price = price;
            item->supplierId = supplierId;
        }
    }

    Item* searchItem(int id) {
        return findItemById(id);
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name 
                      << ", Quantity: " << item.quantity << ", Price: " << item.price 
                      << ", Supplier ID: " << item.supplierId << std::endl;
        }
    }

    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.push_back({id, name, contact});
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(),
                                       [id](const Supplier& supplier) { return supplier.id == id; }),
                        suppliers.end());
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    Supplier* searchSupplier(int id) {
        return findSupplierById(id);
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManager manager;
    manager.addSupplier(1, "Supplier A", "123-456-7890");
    manager.addSupplier(2, "Supplier B", "098-765-4321");

    manager.addItem(1, "Item A", 100, 9.99, 1);
    manager.addItem(2, "Item B", 50, 19.99, 2);

    manager.displaySuppliers();
    manager.displayItems();

    return 0;
}