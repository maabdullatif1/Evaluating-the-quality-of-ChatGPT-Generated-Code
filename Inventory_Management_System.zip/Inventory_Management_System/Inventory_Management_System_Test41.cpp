#include <iostream>
#include <string>
#include <vector>

class Item {
public:
    std::string id, name;
    int quantity;
    double price;

    Item(std::string id, std::string name, int quantity, double price)
        : id(id), name(name), quantity(quantity), price(price) {}
};

class Supplier {
public:
    std::string id, name, contact;

    Supplier(std::string id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class InventoryManagement {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(std::string id, std::string name, int quantity, double price) {
        items.push_back(Item(id, name, quantity, price));
    }

    void addSupplier(std::string id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteItem(std::string id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void deleteSupplier(std::string id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateItem(std::string id, std::string name, int quantity, double price) {
        for (auto &item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
            }
        }
    }

    void updateSupplier(std::string id, std::string name, std::string contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
            }
        }
    }

    Item* searchItem(std::string id) {
        for (auto &item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    Supplier* searchSupplier(std::string id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for (auto &item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
        }
    }

    void displaySuppliers() {
        for (auto &supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagement inventory;

    inventory.addItem("001", "Laptop", 10, 999.99);
    inventory.addItem("002", "Phone", 20, 499.99);

    inventory.addSupplier("S001", "Supplier A", "contactA");
    inventory.addSupplier("S002", "Supplier B", "contactB");

    inventory.displayItems();
    inventory.displaySuppliers();

    inventory.updateItem("001", "Laptop Pro", 5, 1299.99);
    inventory.updateSupplier("S001", "Supplier A Updated", "contactAUpdated");

    inventory.displayItems();
    inventory.displaySuppliers();

    Item* item = inventory.searchItem("002");
    if (item) std::cout << "Found item: " << item->name << std::endl;

    Supplier* supplier = inventory.searchSupplier("S002");
    if (supplier) std::cout << "Found supplier: " << supplier->name << std::endl;

    inventory.deleteItem("002");
    inventory.deleteSupplier("S002");

    inventory.displayItems();
    inventory.displaySuppliers();

    return 0;
}