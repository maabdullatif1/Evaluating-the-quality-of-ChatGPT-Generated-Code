#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Item {
    int id;
    string name;
    int quantity;
    double price;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

class InventoryManagementSystem {
private:
    vector<Item> items;
    vector<Supplier> suppliers;

public:
    void addItem(int id, const string& name, int quantity, double price) {
        items.push_back({id, name, quantity, price});
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, const string& name, int quantity, double price) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    void searchItem(int id) {
        for (const auto& item : items) {
            if (item.id == id) {
                cout << "Item ID: " << item.id << ", Name: " << item.name 
                     << ", Quantity: " << item.quantity << ", Price: " << item.price << endl;
                return;
            }
        }
        cout << "Item not found." << endl;
    }

    void displayItems() {
        for (const auto& item : items) {
            cout << "Item ID: " << item.id << ", Name: " << item.name 
                 << ", Quantity: " << item.quantity << ", Price: " << item.price << endl;
        }
    }

    void addSupplier(int id, const string& name, const string& contact) {
        suppliers.push_back({id, name, contact});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const string& name, const string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name 
                     << ", Contact: " << supplier.contact << endl;
                return;
            }
        }
        cout << "Supplier not found." << endl;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name 
                 << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addItem(1, "Widget", 100, 2.5);
    ims.addItem(2, "Gadget", 150, 3.75);
    ims.displayItems();
    ims.searchItem(1);
    ims.updateItem(1, "Widget Improved", 120, 2.65);
    ims.deleteItem(2);
    ims.displayItems();

    ims.addSupplier(1, "ACME Corp", "123-456-7890");
    ims.addSupplier(2, "SupplyCo", "098-765-4321");
    ims.displaySuppliers();
    ims.searchSupplier(1);
    ims.updateSupplier(1, "ACME Corporation", "111-222-3333");
    ims.deleteSupplier(2);
    ims.displaySuppliers();

    return 0;
}