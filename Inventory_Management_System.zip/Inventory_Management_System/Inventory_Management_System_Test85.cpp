#include <iostream>
#include <vector>
#include <string>

struct Item {
    int id;
    std::string name;
    int quantity;
    double price;
    int supplierId;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventorySystem {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;
    
    int findItemIndex(int id) {
        for (size_t i = 0; i < items.size(); ++i) {
            if (items[i].id == id) return i;
        }
        return -1;
    }
    
    int findSupplierIndex(int id) {
        for (size_t i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].id == id) return i;
        }
        return -1;
    }

public:
    void addItem(int id, std::string name, int quantity, double price, int supplierId) {
        if (findItemIndex(id) == -1)
            items.push_back({id, name, quantity, price, supplierId});
    }
    
    void deleteItem(int id) {
        int index = findItemIndex(id);
        if (index != -1)
            items.erase(items.begin() + index);
    }
    
    void updateItem(int id, std::string name, int quantity, double price, int supplierId) {
        int index = findItemIndex(id);
        if (index != -1)
            items[index] = {id, name, quantity, price, supplierId};
    }
    
    Item* searchItem(int id) {
        int index = findItemIndex(id);
        return index != -1 ? &items[index] : nullptr;
    }
    
    void addSupplier(int id, std::string name, std::string contact) {
        if (findSupplierIndex(id) == -1)
            suppliers.push_back({id, name, contact});
    }
    
    void deleteSupplier(int id) {
        int index = findSupplierIndex(id);
        if (index != -1)
            suppliers.erase(suppliers.begin() + index);
    }
    
    void updateSupplier(int id, std::string name, std::string contact) {
        int index = findSupplierIndex(id);
        if (index != -1)
            suppliers[index] = {id, name, contact};
    }
    
    Supplier* searchSupplier(int id) {
        int index = findSupplierIndex(id);
        return index != -1 ? &suppliers[index] : nullptr;
    }
    
    void displayItems() {
        for (const auto& item : items)
            std::cout << "ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity
                      << ", Price: " << item.price << ", Supplier ID: " << item.supplierId << "\n";
    }
    
    void displaySuppliers() {
        for (const auto& supplier : suppliers)
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << "\n";
    }
};

int main() {
    InventorySystem inventory;
    inventory.addSupplier(1, "Supplier A", "123-456-7890");
    inventory.addItem(101, "Item A", 50, 10.5, 1);
    inventory.displaySuppliers();
    inventory.displayItems();
    inventory.updateItem(101, "Item A Updated", 45, 11.0, 1);
    Item* foundItem = inventory.searchItem(101);
    if (foundItem) {
        std::cout << "Found Item: " << foundItem->name << "\n";
    }
    inventory.deleteItem(101);
    inventory.displayItems();
    return 0;
}