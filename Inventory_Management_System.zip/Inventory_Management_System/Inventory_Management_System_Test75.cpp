#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Item {
    int id;
    string name;
    double price;
    int quantity;
    int supplierId;
};

struct Supplier {
    int id;
    string name;
    string contactInfo;
};

class InventoryManagementSystem {
private:
    vector<Item> items;
    vector<Supplier> suppliers;
    int itemCounter;
    int supplierCounter;

public:
    InventoryManagementSystem() : itemCounter(0), supplierCounter(0) {}

    void addItem(string name, double price, int quantity, int supplierId) {
        Item newItem;
        newItem.id = ++itemCounter;
        newItem.name = name;
        newItem.price = price;
        newItem.quantity = quantity;
        newItem.supplierId = supplierId;
        items.push_back(newItem);
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, string name, double price, int quantity, int supplierId) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.price = price;
                item.quantity = quantity;
                item.supplierId = supplierId;
                break;
            }
        }
    }

    Item searchItem(int id) {
        for (const auto& item : items) {
            if (item.id == id) {
                return item;
            }
        }
        return Item(); 
    }

    void displayItems() {
        for (const auto& item : items) {
            cout << "ID: " << item.id << ", Name: " << item.name << ", Price: " << item.price
                 << ", Quantity: " << item.quantity << ", Supplier ID: " << item.supplierId << endl;
        }
    }

    void addSupplier(string name, string contactInfo) {
        Supplier newSupplier;
        newSupplier.id = ++supplierCounter;
        newSupplier.name = name;
        newSupplier.contactInfo = contactInfo;
        suppliers.push_back(newSupplier);
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    Supplier searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                return supplier;
            }
        }
        return Supplier();
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name 
                 << ", Contact Info: " << supplier.contactInfo << endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addSupplier("Supplier One", "contact1@example.com");
    ims.addSupplier("Supplier Two", "contact2@example.com");

    ims.addItem("Item One", 10.99, 100, 1);
    ims.addItem("Item Two", 5.49, 200, 2);

    cout << "Initial Suppliers:" << endl;
    ims.displaySuppliers();

    cout << "Initial Items:" << endl;
    ims.displayItems();

    ims.updateSupplier(1, "Updated Supplier One", "updated_contact1@example.com");
    ims.updateItem(2, "Updated Item Two", 6.49, 150, 2);

    cout << "Updated Suppliers:" << endl;
    ims.displaySuppliers();

    cout << "Updated Items:" << endl;
    ims.displayItems();

    ims.deleteSupplier(1);
    ims.deleteItem(1);

    cout << "After Deletions:" << endl;
    ims.displaySuppliers();
    ims.displayItems();

    return 0;
}