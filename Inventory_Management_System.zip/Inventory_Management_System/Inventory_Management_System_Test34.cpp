#include <iostream>
#include <string>
#include <vector>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;

    Item(int i, const std::string &n, int q, double p)
    : id(i), name(n), quantity(q), price(p) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int i, const std::string &n, const std::string &c)
    : id(i), name(n), contact(c) {}
};

class InventorySystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(int id, const std::string &name, int quantity, double price) {
        items.push_back(Item(id, name, quantity, price));
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, const std::string &name, int quantity, double price) {
        for (auto &item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    Item* searchItem(int id) {
        for (auto &item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for (const auto &item : items) {
            std::cout << "ID: " << item.id << " Name: " << item.name 
                      << " Quantity: " << item.quantity << " Price: " << item.price << "\n";
        }
    }

    void addSupplier(int id, const std::string &name, const std::string &contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string &name, const std::string &contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "ID: " << supplier.id << " Name: " << supplier.name 
                      << " Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventorySystem system;
    system.addItem(1, "Laptop", 10, 750.50);
    system.addItem(2, "Mouse", 25, 12.30);
    system.displayItems();
    system.addSupplier(1, "TechSupply", "tech@techsupply.com");
    system.addSupplier(2, "OfficeGoods", "contact@officegoods.com");
    system.displaySuppliers();
    return 0;
}