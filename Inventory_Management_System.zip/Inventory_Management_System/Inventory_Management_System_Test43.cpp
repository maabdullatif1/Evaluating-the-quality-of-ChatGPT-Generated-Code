#include <iostream>
#include <vector>
#include <string>

struct Item {
    int id;
    std::string name;
    int quantity;
    std::string supplier;
};

void addItem(std::vector<Item> &inventory) {
    Item newItem;
    std::cout << "Enter Item ID: ";
    std::cin >> newItem.id;
    std::cout << "Enter Item Name: ";
    std::cin >> newItem.name;
    std::cout << "Enter Quantity: ";
    std::cin >> newItem.quantity;
    std::cout << "Enter Supplier: ";
    std::cin >> newItem.supplier;
    inventory.push_back(newItem);
}

void deleteItem(std::vector<Item> &inventory) {
    int id;
    std::cout << "Enter Item ID to delete: ";
    std::cin >> id;
    for (auto it = inventory.begin(); it != inventory.end(); ++it) {
        if (it->id == id) {
            inventory.erase(it);
            break;
        }
    }
}

void updateItem(std::vector<Item> &inventory) {
    int id;
    std::cout << "Enter Item ID to update: ";
    std::cin >> id;
    for (auto &item : inventory) {
        if (item.id == id) {
            std::cout << "Enter new Item Name: ";
            std::cin >> item.name;
            std::cout << "Enter new Quantity: ";
            std::cin >> item.quantity;
            std::cout << "Enter new Supplier: ";
            std::cin >> item.supplier;
            break;
        }
    }
}

void searchItem(const std::vector<Item> &inventory) {
    int id;
    std::cout << "Enter Item ID to search: ";
    std::cin >> id;
    for (const auto &item : inventory) {
        if (item.id == id) {
            std::cout << "Item ID: " << item.id << "\n";
            std::cout << "Item Name: " << item.name << "\n";
            std::cout << "Quantity: " << item.quantity << "\n";
            std::cout << "Supplier: " << item.supplier << "\n";
            break;
        }
    }
}

void displayItems(const std::vector<Item> &inventory) {
    for (const auto &item : inventory) {
        std::cout << "Item ID: " << item.id << ", ";
        std::cout << "Name: " << item.name << ", ";
        std::cout << "Quantity: " << item.quantity << ", ";
        std::cout << "Supplier: " << item.supplier << "\n";
    }
}

int main() {
    std::vector<Item> inventory;
    int choice;
    do {
        std::cout << "1. Add Item\n2. Delete Item\n3. Update Item\n4. Search Item\n5. Display All Items\n6. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;
        switch (choice) {
            case 1: addItem(inventory); break;
            case 2: deleteItem(inventory); break;
            case 3: updateItem(inventory); break;
            case 4: searchItem(inventory); break;
            case 5: displayItems(inventory); break;
            case 6: break;
            default: std::cout << "Invalid choice\n"; break;
        }
    } while (choice != 6);
    return 0;
}