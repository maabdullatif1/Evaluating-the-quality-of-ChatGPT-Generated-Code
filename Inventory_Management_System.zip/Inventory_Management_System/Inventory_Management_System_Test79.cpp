#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    std::string name;
    std::string contactInfo;

    Supplier(const std::string& n, const std::string& c) : name(n), contactInfo(c) {}
};

class Item {
public:
    std::string name;
    int quantity;
    double price;
    Supplier supplier;

    Item(const std::string& n, int q, double p, const Supplier& s) 
        : name(n), quantity(q), price(p), supplier(s) {}
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back(Supplier(name, contact));
    }

    void addItem(const std::string& name, int quantity, double price, const std::string& supplierName) {
        for (const auto& supplier : suppliers) {
            if (supplier.name == supplierName) {
                items.push_back(Item(name, quantity, price, supplier));
                return;
            }
        }
    }

    void deleteItem(const std::string& name) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->name == name) {
                items.erase(it);
                return;
            }
        }
    }

    void updateItem(const std::string& name, int quantity, double price) {
        for (auto& item : items) {
            if (item.name == name) {
                item.quantity = quantity;
                item.price = price;
                return;
            }
        }
    }

    Item* searchItem(const std::string& name) {
        for (auto& item : items) {
            if (item.name == name) {
                return &item;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item Name: " << item.name 
                      << ", Quantity: " << item.quantity 
                      << ", Price: " << item.price 
                      << ", Supplier: " << item.supplier.name 
                      << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier Name: " << supplier.name 
                      << ", Contact Info: " << supplier.contactInfo 
                      << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier("Apple", "apple@contact.com");
    ims.addSupplier("Samsung", "samsung@contact.com");
    ims.addItem("iPhone", 10, 999.99, "Apple");
    ims.addItem("Galaxy", 5, 899.99, "Samsung");
    ims.displayItems();
    ims.displaySuppliers();
    ims.updateItem("iPhone", 8, 949.99);
    ims.deleteItem("Galaxy");
    ims.displayItems();

    return 0;
}