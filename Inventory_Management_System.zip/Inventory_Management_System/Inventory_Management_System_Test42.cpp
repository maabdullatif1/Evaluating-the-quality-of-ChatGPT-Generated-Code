#include <iostream>
#include <vector>
#include <string>

struct Item {
    int id;
    std::string name;
    int quantity;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventorySystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    Item* searchItemById(int id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    Supplier* searchSupplierById(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

public:
    void addItem(int id, const std::string& name, int quantity, double price) {
        if (searchItemById(id) == nullptr) {
            items.push_back({id, name, quantity, price});
        }
    }

    void deleteItem(int id) {
        items.erase(std::remove_if(items.begin(), items.end(), [id](Item& item) { return item.id == id; }), items.end());
    }

    void updateItem(int id, const std::string& name, int quantity, double price) {
        Item* item = searchItemById(id);
        if (item) {
            item->name = name;
            item->quantity = quantity;
            item->price = price;
        }
    }

    Item* searchItem(int id) {
        return searchItemById(id);
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity << ", Price: " << item.price << "\n";
        }
    }

    void addSupplier(int id, const std::string& name, const std::string& contact) {
        if (searchSupplierById(id) == nullptr) {
            suppliers.push_back({id, name, contact});
        }
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(), [id](Supplier& supplier) { return supplier.id == id; }), suppliers.end());
    }

    Supplier* searchSupplier(int id) {
        return searchSupplierById(id);
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventorySystem inventory;
    inventory.addItem(1, "Item1", 50, 20.5);
    inventory.addItem(2, "Item2", 30, 15.0);
    inventory.updateItem(1, "Item1 Updated", 60, 25.0);
    inventory.displayItems();
    inventory.deleteItem(2);
    inventory.displayItems();
    
    inventory.addSupplier(1, "Supplier1", "Contact1");
    inventory.addSupplier(2, "Supplier2", "Contact2");
    inventory.displaySuppliers();
    inventory.deleteSupplier(1);
    inventory.displaySuppliers();
    
    return 0;
}