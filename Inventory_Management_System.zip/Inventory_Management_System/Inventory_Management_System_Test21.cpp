#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Item {
public:
    int id;
    string name;
    int quantity;
    double price;

    Item(int id, string name, int quantity, double price)
        : id(id), name(name), quantity(quantity), price(price) {}
};

class Supplier {
public:
    int id;
    string name;
    string contact;

    Supplier(int id, string name, string contact)
        : id(id), name(name), contact(contact) {}
};

class InventoryManagementSystem {
private:
    vector<Item> items;
    vector<Supplier> suppliers;

    Item* findItemById(int id) {
        for (auto& item : items) {
            if (item.id == id) return &item;
        }
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) return &supplier;
        }
        return nullptr;
    }

public:
    void addItem(int id, string name, int quantity, double price) {
        if (!findItemById(id)) {
            items.push_back(Item(id, name, quantity, price));
        }
    }

    void deleteItem(int id) {
        items.erase(remove_if(items.begin(), items.end(), [&](Item& item) {
            return item.id == id;
        }), items.end());
    }

    void updateItem(int id, string name, int quantity, double price) {
        Item* item = findItemById(id);
        if (item) {
            item->name = name;
            item->quantity = quantity;
            item->price = price;
        }
    }

    void searchItem(int id) {
        Item* item = findItemById(id);
        if (item) {
            cout << "Item Found: " << item->id << ", " << item->name 
                 << ", " << item->quantity << ", " << item->price << endl;
        } else {
            cout << "Item not found." << endl;
        }
    }

    void displayItems() {
        for (const auto& item : items) {
            cout << item.id << ", " << item.name << ", " 
                 << item.quantity << ", " << item.price << endl;
        }
    }

    void addSupplier(int id, string name, string contact) {
        if (!findSupplierById(id)) {
            suppliers.push_back(Supplier(id, name, contact));
        }
    }

    void deleteSupplier(int id) {
        suppliers.erase(remove_if(suppliers.begin(), suppliers.end(), [&](Supplier& supplier) {
            return supplier.id == id;
        }), suppliers.end());
    }

    void updateSupplier(int id, string name, string contact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void searchSupplier(int id) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            cout << "Supplier Found: " << supplier->id << ", " << supplier->name 
                 << ", " << supplier->contact << endl;
        } else {
            cout << "Supplier not found." << endl;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << supplier.id << ", " << supplier.name << ", " 
                 << supplier.contact << endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem(1, "Laptop", 10, 999.99);
    ims.addItem(2, "Mouse", 50, 19.99);
    ims.addSupplier(1, "Tech Supplies", "123-456-7890");
    ims.displayItems();
    ims.displaySuppliers();
    ims.searchItem(1);
    ims.searchSupplier(1);
    ims.updateItem(1, "Laptop", 8, 899.99);
    ims.updateSupplier(1, "Tech World", "987-654-3210");
    ims.displayItems();
    ims.displaySuppliers();
    ims.deleteItem(1);
    ims.deleteSupplier(1);
    ims.displayItems();
    ims.displaySuppliers();
    return 0;
}