#include <iostream>
#include <string>

using namespace std;

struct Item {
    int id;
    string name;
    int quantity;
    double price;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

const int MAX_ITEMS = 100;
const int MAX_SUPPLIERS = 50;

Item items[MAX_ITEMS];
Supplier suppliers[MAX_SUPPLIERS];

int itemCount = 0;
int supplierCount = 0;

void addItem() {
    if (itemCount < MAX_ITEMS) {
        Item newItem;
        cout << "Enter Item ID: ";
        cin >> newItem.id;
        cout << "Enter Item Name: ";
        cin.ignore();
        getline(cin, newItem.name);
        cout << "Enter Quantity: ";
        cin >> newItem.quantity;
        cout << "Enter Price: ";
        cin >> newItem.price;
        items[itemCount++] = newItem;
    } else {
        cout << "Inventory full\n";
    }
}

void deleteItem() {
    int id;
    cout << "Enter Item ID to delete: ";
    cin >> id;
    for (int i = 0; i < itemCount; i++) {
        if (items[i].id == id) {
            for (int j = i; j < itemCount - 1; j++) {
                items[j] = items[j + 1];
            }
            itemCount--;
            return;
        }
    }
    cout << "Item not found\n";
}

void updateItem() {
    int id;
    cout << "Enter Item ID to update: ";
    cin >> id;
    for (int i = 0; i < itemCount; i++) {
        if (items[i].id == id) {
            cout << "Enter new Item Name: ";
            cin.ignore();
            getline(cin, items[i].name);
            cout << "Enter new Quantity: ";
            cin >> items[i].quantity;
            cout << "Enter new Price: ";
            cin >> items[i].price;
            return;
        }
    }
    cout << "Item not found\n";
}

void searchItem() {
    int id;
    cout << "Enter Item ID to search: ";
    cin >> id;
    for (int i = 0; i < itemCount; i++) {
        if (items[i].id == id) {
            cout << "Item ID: " << items[i].id << endl;
            cout << "Item Name: " << items[i].name << endl;
            cout << "Quantity: " << items[i].quantity << endl;
            cout << "Price: " << items[i].price << endl;
            return;
        }
    }
    cout << "Item not found\n";
}

void displayItems() {
    for (int i = 0; i < itemCount; i++) {
        cout << "Item ID: " << items[i].id << endl;
        cout << "Item Name: " << items[i].name << endl;
        cout << "Quantity: " << items[i].quantity << endl;
        cout << "Price: " << items[i].price << endl;
    }
}

void addSupplier() {
    if (supplierCount < MAX_SUPPLIERS) {
        Supplier newSupplier;
        cout << "Enter Supplier ID: ";
        cin >> newSupplier.id;
        cout << "Enter Supplier Name: ";
        cin.ignore();
        getline(cin, newSupplier.name);
        cout << "Enter Contact Information: ";
        getline(cin, newSupplier.contact);
        suppliers[supplierCount++] = newSupplier;
    } else {
        cout << "Supplier list full\n";
    }
}

void deleteSupplier() {
    int id;
    cout << "Enter Supplier ID to delete: ";
    cin >> id;
    for (int i = 0; i < supplierCount; i++) {
        if (suppliers[i].id == id) {
            for (int j = i; j < supplierCount - 1; j++) {
                suppliers[j] = suppliers[j + 1];
            }
            supplierCount--;
            return;
        }
    }
    cout << "Supplier not found\n";
}

void updateSupplier() {
    int id;
    cout << "Enter Supplier ID to update: ";
    cin >> id;
    for (int i = 0; i < supplierCount; i++) {
        if (suppliers[i].id == id) {
            cout << "Enter new Supplier Name: ";
            cin.ignore();
            getline(cin, suppliers[i].name);
            cout << "Enter new Contact Information: ";
            getline(cin, suppliers[i].contact);
            return;
        }
    }
    cout << "Supplier not found\n";
}

void searchSupplier() {
    int id;
    cout << "Enter Supplier ID to search: ";
    cin >> id;
    for (int i = 0; i < supplierCount; i++) {
        if (suppliers[i].id == id) {
            cout << "Supplier ID: " << suppliers[i].id << endl;
            cout << "Supplier Name: " << suppliers[i].name << endl;
            cout << "Contact: " << suppliers[i].contact << endl;
            return;
        }
    }
    cout << "Supplier not found\n";
}

void displaySuppliers() {
    for (int i = 0; i < supplierCount; i++) {
        cout << "Supplier ID: " << suppliers[i].id << endl;
        cout << "Supplier Name: " << suppliers[i].name << endl;
        cout << "Contact: " << suppliers[i].contact << endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Item\n2. Delete Item\n3. Update Item\n4. Search Item\n5. Display Items\n";
        cout << "6. Add Supplier\n7. Delete Supplier\n8. Update Supplier\n9. Search Supplier\n10. Display Suppliers\n11. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        switch (choice) {
        case 1: addItem(); break;
        case 2: deleteItem(); break;
        case 3: updateItem(); break;
        case 4: searchItem(); break;
        case 5: displayItems(); break;
        case 6: addSupplier(); break;
        case 7: deleteSupplier(); break;
        case 8: updateSupplier(); break;
        case 9: searchSupplier(); break;
        case 10: displaySuppliers(); break;
        case 11: return 0;
        default: cout << "Invalid choice\n";
        }
    }
    return 0;
}