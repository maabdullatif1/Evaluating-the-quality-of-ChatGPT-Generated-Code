#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;
    int supplierId;

    Item(int id, const std::string& name, int quantity, double price, int supplierId)
        : id(id), name(name), quantity(quantity), price(price), supplierId(supplierId) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInfo;

    Supplier(int id, const std::string& name, const std::string& contactInfo)
        : id(id), name(name), contactInfo(contactInfo) {}
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;
    int itemCounter = 0;
    int supplierCounter = 0;

public:
    void addItem(const std::string& name, int quantity, double price, int supplierId) {
        items.emplace_back(++itemCounter, name, quantity, price, supplierId);
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, const std::string& name, int quantity, double price, int supplierId) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                item.supplierId = supplierId;
                break;
            }
        }
    }

    Item* searchItem(int id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item ID: " << item.id << "\nName: " << item.name << "\nQuantity: " << item.quantity << "\nPrice: " << item.price << "\nSupplier ID: " << item.supplierId << "\n\n";
        }
    }

    void addSupplier(const std::string& name, const std::string& contactInfo) {
        suppliers.emplace_back(++supplierCounter, name, contactInfo);
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << "\nName: " << supplier.name << "\nContact Info: " << supplier.contactInfo << "\n\n";
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier("Supplier 1", "contact1@example.com");
    ims.addItem("Item 1", 100, 2.5, 1);
    ims.displayItems();
    ims.displaySuppliers();
    return 0;
}