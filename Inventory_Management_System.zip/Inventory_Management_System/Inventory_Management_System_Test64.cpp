#include <iostream>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;

    Item() : id(0), name(""), quantity(0), price(0.0) {}

    void input() {
        std::cin >> id >> name >> quantity >> price;
    }

    void display() const {
        std::cout << id << " " << name << " " << quantity << " " << price << "\n";
    }
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier() : id(0), name(""), contact("") {}

    void input() {
        std::cin >> id >> name >> contact;
    }

    void display() const {
        std::cout << id << " " << name << " " << contact << "\n";
    }
};

template <typename T>
class Inventory {
private:
    T data[100];
    int count;

public:
    Inventory() : count(0) {}

    void add() {
        if (count < 100) {
            data[count].input();
            count++;
        }
    }

    void remove(int id) {
        for (int i = 0; i < count; ++i) {
            if (data[i].id == id) {
                for (int j = i; j < count - 1; ++j) {
                    data[j] = data[j + 1];
                }
                count--;
                return;
            }
        }
    }

    void update(int id) {
        for (int i = 0; i < count; ++i) {
            if (data[i].id == id) {
                data[i].input();
                return;
            }
        }
    }

    void search(int id) const {
        for (int i = 0; i < count; ++i) {
            if (data[i].id == id) {
                data[i].display();
                return;
            }
        }
        std::cout << "Not found\n";
    }

    void display() const {
        for (int i = 0; i < count; ++i) {
            data[i].display();
        }
    }
};

int main() {
    Inventory<Item> itemInventory;
    Inventory<Supplier> supplierInventory;
    int choice, id;

    while (true) {
        std::cout << "1. Add Item\n2. Add Supplier\n3. Delete Item\n4. Delete Supplier\n";
        std::cout << "5. Update Item\n6. Update Supplier\n7. Search Item\n8. Search Supplier\n";
        std::cout << "9. Display Items\n10. Display Suppliers\n11. Exit\n";
        std::cin >> choice;

        switch (choice) {
            case 1: itemInventory.add(); break;
            case 2: supplierInventory.add(); break;
            case 3: std::cin >> id; itemInventory.remove(id); break;
            case 4: std::cin >> id; supplierInventory.remove(id); break;
            case 5: std::cin >> id; itemInventory.update(id); break;
            case 6: std::cin >> id; supplierInventory.update(id); break;
            case 7: std::cin >> id; itemInventory.search(id); break;
            case 8: std::cin >> id; supplierInventory.search(id); break;
            case 9: itemInventory.display(); break;
            case 10: supplierInventory.display(); break;
            case 11: return 0;
        }
    }
}