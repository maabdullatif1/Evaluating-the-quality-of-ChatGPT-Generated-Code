#include <iostream>
#include <string>
#include <vector>

struct Item {
    int id;
    std::string name;
    int quantity;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventorySystem {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    int findItemIndex(int id) {
        for (size_t i = 0; i < items.size(); ++i)
            if (items[i].id == id) return i;
        return -1;
    }

    int findSupplierIndex(int id) {
        for (size_t i = 0; i < suppliers.size(); ++i)
            if (suppliers[i].id == id) return i;
        return -1;
    }

public:
    void addItem(int id, std::string name, int quantity, double price) {
        if (findItemIndex(id) == -1)
            items.push_back({id, name, quantity, price});
    }

    void deleteItem(int id) {
        int index = findItemIndex(id);
        if (index != -1)
            items.erase(items.begin() + index);
    }

    void updateItem(int id, std::string name, int quantity, double price) {
        int index = findItemIndex(id);
        if (index != -1)
            items[index] = {id, name, quantity, price};
    }

    Item* searchItem(int id) {
        int index = findItemIndex(id);
        if (index != -1) return &items[index];
        return nullptr;
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << '\n';
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        if (findSupplierIndex(id) == -1)
            suppliers.push_back({id, name, contact});
    }

    void deleteSupplier(int id) {
        int index = findSupplierIndex(id);
        if (index != -1)
            suppliers.erase(suppliers.begin() + index);
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        int index = findSupplierIndex(id);
        if (index != -1)
            suppliers[index] = {id, name, contact};
    }

    Supplier* searchSupplier(int id) {
        int index = findSupplierIndex(id);
        if (index != -1) return &suppliers[index];
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << '\n';
        }
    }
};

int main() {
    InventorySystem inventory;
    inventory.addItem(1, "Widget", 100, 2.5);
    inventory.displayItems();
    inventory.addSupplier(1, "Supplier A", "123-456-7890");
    inventory.displaySuppliers();
    return 0;
}