#include <iostream>
#include <string>

using namespace std;

struct Item {
    string id;
    string name;
    int quantity;
    double price;
};

struct Supplier {
    string id;
    string name;
    string contact;
};

Item items[100];
Supplier suppliers[100];
int itemCount = 0;
int supplierCount = 0;

void addItem(string id, string name, int quantity, double price) {
    items[itemCount].id = id;
    items[itemCount].name = name;
    items[itemCount].quantity = quantity;
    items[itemCount].price = price;
    itemCount++;
}

void deleteItem(string id) {
    for (int i = 0; i < itemCount; i++) {
        if (items[i].id == id) {
            for (int j = i; j < itemCount - 1; j++) {
                items[j] = items[j + 1];
            }
            itemCount--;
            break;
        }
    }
}

void updateItem(string id, string name, int quantity, double price) {
    for (int i = 0; i < itemCount; i++) {
        if (items[i].id == id) {
            items[i].name = name;
            items[i].quantity = quantity;
            items[i].price = price;
            break;
        }
    }
}

void searchItem(string id) {
    for (int i = 0; i < itemCount; i++) {
        if (items[i].id == id) {
            cout << "Item ID: " << items[i].id << "\n";
            cout << "Name: " << items[i].name << "\n";
            cout << "Quantity: " << items[i].quantity << "\n";
            cout << "Price: " << items[i].price << "\n";
            break;
        }
    }
}

void displayItems() {
    for (int i = 0; i < itemCount; i++) {
        cout << "Item ID: " << items[i].id << "\n";
        cout << "Name: " << items[i].name << "\n";
        cout << "Quantity: " << items[i].quantity << "\n";
        cout << "Price: " << items[i].price << "\n";
    }
}

void addSupplier(string id, string name, string contact) {
    suppliers[supplierCount].id = id;
    suppliers[supplierCount].name = name;
    suppliers[supplierCount].contact = contact;
    supplierCount++;
}

void deleteSupplier(string id) {
    for (int i = 0; i < supplierCount; i++) {
        if (suppliers[i].id == id) {
            for (int j = i; j < supplierCount - 1; j++) {
                suppliers[j] = suppliers[j + 1];
            }
            supplierCount--;
            break;
        }
    }
}

void updateSupplier(string id, string name, string contact) {
    for (int i = 0; i < supplierCount; i++) {
        if (suppliers[i].id == id) {
            suppliers[i].name = name;
            suppliers[i].contact = contact;
            break;
        }
    }
}

void searchSupplier(string id) {
    for (int i = 0; i < supplierCount; i++) {
        if (suppliers[i].id == id) {
            cout << "Supplier ID: " << suppliers[i].id << "\n";
            cout << "Name: " << suppliers[i].name << "\n";
            cout << "Contact: " << suppliers[i].contact << "\n";
            break;
        }
    }
}

void displaySuppliers() {
    for (int i = 0; i < supplierCount; i++) {
        cout << "Supplier ID: " << suppliers[i].id << "\n";
        cout << "Name: " << suppliers[i].name << "\n";
        cout << "Contact: " << suppliers[i].contact << "\n";
    }
}

int main() {
    addItem("001", "Laptop", 10, 999.99);
    addItem("002", "Keyboard", 50, 20.49);
    addSupplier("101", "Supplier A", "123456789");
    displayItems();
    displaySuppliers();
    updateItem("002", "Mechanical Keyboard", 45, 22.99);
    searchItem("002");
    deleteItem("001");
    displayItems();
    return 0;
}