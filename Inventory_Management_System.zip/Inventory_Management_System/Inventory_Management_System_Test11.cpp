#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact_info;

    Supplier(int supplierId, std::string supplierName, std::string supplierContact)
    : id(supplierId), name(supplierName), contact_info(supplierContact) {}
};

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;
    Supplier supplier;

    Item(int itemId, std::string itemName, int itemQuantity, double itemPrice, Supplier itemSupplier)
    : id(itemId), name(itemName), quantity(itemQuantity), price(itemPrice), supplier(itemSupplier) {}
};

class InventoryManagementSystem {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    Supplier* findSupplierById(int supplierId) {
        for(auto &supplier : suppliers) {
            if(supplier.id == supplierId) {
                return &supplier;
            }
        }
        return nullptr;
    }

    Item* findItemById(int itemId) {
        for(auto &item : items) {
            if(item.id == itemId) {
                return &item;
            }
        }
        return nullptr;
    }

public:
    void addSupplier(int id, std::string name, std::string contact_info) {
        suppliers.push_back(Supplier(id, name, contact_info));
    }

    void addItem(int id, std::string name, int quantity, double price, int supplierId) {
        Supplier* supplier = findSupplierById(supplierId);
        if(supplier != nullptr) {
            items.push_back(Item(id, name, quantity, price, *supplier));
        }
    }

    void deleteItem(int id) {
        for(auto it = items.begin(); it != items.end(); ++it) {
            if(it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, std::string name, int quantity, double price) {
        Item* item = findItemById(id);
        if(item != nullptr) {
            item->name = name;
            item->quantity = quantity;
            item->price = price;
        }
    }

    Supplier* searchSupplierById(int id) {
        return findSupplierById(id);
    }

    void searchItemById(int id) {
        Item* item = findItemById(id);
        if(item != nullptr) {
            std::cout << "Item ID: " << item->id << " Name: " << item->name 
                      << " Quantity: " << item->quantity << " Price: " << item->price 
                      << " Supplier: " << item->supplier.name << std::endl;
        }
    }

    void displayItems() {
        for(auto &item : items) {
            std::cout << "Item ID: " << item.id << " Name: " << item.name 
                      << " Quantity: " << item.quantity << " Price: " << item.price 
                      << " Supplier: " << item.supplier.name << std::endl;
        }
    }

    void displaySuppliers() {
        for(auto &supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << " Name: " << supplier.name 
                      << " Contact Info: " << supplier.contact_info << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addSupplier(1, "Supplier One", "contact1@example.com");
    ims.addSupplier(2, "Supplier Two", "contact2@example.com");

    ims.addItem(1, "Item A", 100, 10.5, 1);
    ims.addItem(2, "Item B", 200, 20.5, 2);

    ims.displayItems();
    ims.displaySuppliers();

    ims.updateItem(1, "Item A+", 150, 11.0);
    ims.searchItemById(1);

    ims.deleteItem(2);
    ims.displayItems();

    return 0;
}