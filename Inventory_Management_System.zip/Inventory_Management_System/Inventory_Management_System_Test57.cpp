#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;

    Item(int id, const std::string& name, int quantity, double price)
        : id(id), name(name), quantity(quantity), price(price) {}
};

class Supplier {
public:
    int id;
    std::string name;

    Supplier(int id, const std::string& name)
        : id(id), name(name) {}
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    Item* findItem(int id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    Supplier* findSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

public:
    void addItem(int id, const std::string& name, int quantity, double price) {
        items.emplace_back(id, name, quantity, price);
    }

    void deleteItem(int id) {
        items.erase(std::remove_if(items.begin(), items.end(), 
            [id](const Item& item) { return item.id == id; }), items.end());
    }

    void updateItem(int id, const std::string& name, int quantity, double price) {
        Item* item = findItem(id);
        if (item) {
            item->name = name;
            item->quantity = quantity;
            item->price = price;
        }
    }

    Item* searchItem(int id) {
        return findItem(id);
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item ID: " << item.id << ", Name: " << item.name
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << "\n";
        }
    }

    void addSupplier(int id, const std::string& name) {
        suppliers.emplace_back(id, name);
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(), 
            [id](const Supplier& supplier) { return supplier.id == id; }), suppliers.end());
    }

    Supplier* searchSupplier(int id) {
        return findSupplier(id);
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << "\n";
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addItem(1, "Widget", 100, 2.99);
    ims.addItem(2, "Gadget", 50, 4.99);
    ims.displayItems();

    ims.addSupplier(1, "Supplier A");
    ims.addSupplier(2, "Supplier B");
    ims.displaySuppliers();

    ims.updateItem(1, "Widget", 200, 2.89);
    ims.displayItems();

    ims.deleteItem(2);
    ims.displayItems();

    ims.deleteSupplier(1);
    ims.displaySuppliers();

    return 0;
}