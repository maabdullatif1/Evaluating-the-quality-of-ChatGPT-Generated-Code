#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;
    int supplierId;

    Item(int id, std::string name, int quantity, double price, int supplierId)
        : id(id), name(name), quantity(quantity), price(price), supplierId(supplierId) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInfo;

    Supplier(int id, std::string name, std::string contactInfo)
        : id(id), name(name), contactInfo(contactInfo) {}
};

class InventoryManagement {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    Item* findItemById(int id) {
        for (auto &item : items) {
            if (item.id == id) return &item;
        }
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) return &supplier;
        }
        return nullptr;
    }

public:
    void addItem(int id, std::string name, int quantity, double price, int supplierId) {
        if (findSupplierById(supplierId)) {
            items.push_back(Item(id, name, quantity, price, supplierId));
        }
    }

    void deleteItem(int id) {
        items.erase(std::remove_if(items.begin(), items.end(),
                                   [=](Item &item) { return item.id == id; }), items.end());
    }

    void updateItem(int id, std::string name, int quantity, double price, int supplierId) {
        Item* item = findItemById(id);
        if (item && findSupplierById(supplierId)) {
            item->name = name;
            item->quantity = quantity;
            item->price = price;
            item->supplierId = supplierId;
        }
    }

    Item* searchItem(int id) {
        return findItemById(id);
    }

    void displayItems() {
        for (const auto &item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name
                      << ", Quantity: " << item.quantity << ", Price: " << item.price
                      << ", Supplier ID: " << item.supplierId << std::endl;
        }
    }

    void addSupplier(int id, std::string name, std::string contactInfo) {
        suppliers.push_back(Supplier(id, name, contactInfo));
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(),
                                       [=](Supplier &supplier) { return supplier.id == id; }),
                        suppliers.end());
        items.erase(std::remove_if(items.begin(), items.end(),
                                   [=](Item &item) { return item.supplierId == id; }),
                    items.end());
    }

    void updateSupplier(int id, std::string name, std::string contactInfo) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contactInfo = contactInfo;
        }
    }

    Supplier* searchSupplier(int id) {
        return findSupplierById(id);
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact Info: " << supplier.contactInfo << std::endl;
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addSupplier(1, "Supplier1", "Contact1");
    inventory.addSupplier(2, "Supplier2", "Contact2");

    inventory.addItem(1, "Item1", 100, 10.5, 1);
    inventory.addItem(2, "Item2", 50, 20.0, 2);

    std::cout << "Items:" << std::endl;
    inventory.displayItems();

    std::cout << "Suppliers:" << std::endl;
    inventory.displaySuppliers();

    return 0;
}