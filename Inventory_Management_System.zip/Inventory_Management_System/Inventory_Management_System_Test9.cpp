#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;

    Item(int id, const std::string& name, int quantity) : id(id), name(name), quantity(quantity) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact_info;

    Supplier(int id, const std::string& name, const std::string& contact_info)
     : id(id), name(name), contact_info(contact_info) {}
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(int id, const std::string& name, int quantity) {
        items.push_back(Item(id, name, quantity));
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, const std::string& name, int quantity) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
            }
        }
    }

    void searchItem(int id) const {
        for (const auto& item : items) {
            if (item.id == id) {
                std::cout << "Item found: ID=" << item.id << ", Name=" << item.name << ", Quantity=" << item.quantity << "\n";
                return;
            }
        }
        std::cout << "Item not found\n";
    }

    void displayItems() const {
        for (const auto& item : items) {
            std::cout << "ID=" << item.id << ", Name=" << item.name << ", Quantity=" << item.quantity << "\n";
        }
    }

    void addSupplier(int id, const std::string& name, const std::string& contact_info) {
        suppliers.push_back(Supplier(id, name, contact_info));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact_info) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact_info = contact_info;
            }
        }
    }

    void searchSupplier(int id) const {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                std::cout << "Supplier found: ID=" << supplier.id << ", Name=" << supplier.name << ", Contact Info=" << supplier.contact_info << "\n";
                return;
            }
        }
        std::cout << "Supplier not found\n";
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            std::cout << "ID=" << supplier.id << ", Name=" << supplier.name << ", Contact Info=" << supplier.contact_info << "\n";
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem(1, "Item1", 100);
    ims.addSupplier(1, "Supplier1", "contact1@example.com");
    ims.displayItems();
    ims.displaySuppliers();
    ims.searchItem(1);
    ims.searchSupplier(1);
    ims.updateItem(1, "NewItem1", 150);
    ims.updateSupplier(1, "NewSupplier1", "newcontact1@example.com");
    ims.displayItems();
    ims.displaySuppliers();
    ims.deleteItem(1);
    ims.deleteSupplier(1);
    ims.displayItems();
    ims.displaySuppliers();
    return 0;
}