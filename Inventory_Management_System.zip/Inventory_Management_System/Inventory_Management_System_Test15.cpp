#include <iostream>
#include <vector>
#include <string>

struct Item {
    int id;
    std::string name;
    int quantity;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventoryManagement {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(int id, const std::string& name, int quantity, double price) {
        items.push_back({id, name, quantity, price});
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, const std::string& name, int quantity, double price) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    void searchItem(int id) {
        for (const auto& item : items) {
            if (item.id == id) {
                std::cout << "Item ID: " << item.id << ", Name: " << item.name 
                          << ", Quantity: " << item.quantity << ", Price: " 
                          << item.price << '\n';
                return;
            }
        }
        std::cout << "Item not found\n";
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item ID: " << item.id << ", Name: " << item.name 
                      << ", Quantity: " << item.quantity << ", Price: " 
                      << item.price << '\n';
        }
    }

    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.push_back({id, name, contact});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                std::cout << "Supplier ID: " << supplier.id << ", Name: " 
                          << supplier.name << ", Contact: " 
                          << supplier.contact << '\n';
                return;
            }
        }
        std::cout << "Supplier not found\n";
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " 
                      << supplier.name << ", Contact: " << supplier.contact << '\n';
        }
    }
};

int main() {
    InventoryManagement inv;
    inv.addItem(1, "Laptop", 10, 999.99);
    inv.displayItems();
    inv.searchItem(1);
    inv.updateItem(1, "Laptop", 8, 995.95);
    inv.searchItem(1);
    inv.deleteItem(1);
    inv.searchItem(1);
    inv.addSupplier(1, "ACME Corp.", "123-456-7890");
    inv.displaySuppliers();
    return 0;
}