#include <iostream>
#include <vector>
#include <string>

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

struct Item {
    int id;
    std::string name;
    int quantity;
    double price;
    int supplierId;
};

class InventorySystem {
    std::vector<Supplier> suppliers;
    std::vector<Item> items;

    Supplier* findSupplier(int supplierId) {
        for (auto &supplier : suppliers) {
            if (supplier.id == supplierId) {
                return &supplier;
            }
        }
        return nullptr;
    }

    Item* findItem(int itemId) {
        for (auto &item : items) {
            if (item.id == itemId) {
                return &item;
            }
        }
        return nullptr;
    }

public:
    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.push_back(Supplier{id, name, contact});
    }

    void addItem(int id, const std::string& name, int quantity, double price, int supplierId) {
        if (findSupplier(supplierId)) {
            items.push_back(Item{id, name, quantity, price, supplierId});
        } else {
            std::cout << "Supplier does not exist\n";
        }
    }

    void deleteSupplier(int supplierId) {
        suppliers.erase(
            std::remove_if(suppliers.begin(), suppliers.end(),
                           [&](Supplier &sup) { return sup.id == supplierId; }),
            suppliers.end());
    }

    void deleteItem(int itemId) {
        items.erase(
            std::remove_if(items.begin(), items.end(),
                           [&](Item &itm) { return itm.id == itemId; }),
            items.end());
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        Supplier* supplier = findSupplier(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void updateItem(int id, const std::string& name, int quantity, double price) {
        Item* item = findItem(id);
        if (item) {
            item->name = name;
            item->quantity = quantity;
            item->price = price;
        }
    }

    void searchSupplier(int id) {
        Supplier* supplier = findSupplier(id);
        if (supplier) {
            std::cout << "Supplier ID: " << supplier->id << ", Name: " << supplier->name << ", Contact: " << supplier->contact << "\n";
        } else {
            std::cout << "Supplier not found\n";
        }
    }

    void searchItem(int id) {
        Item* item = findItem(id);
        if (item) {
            std::cout << "Item ID: " << item->id << ", Name: " << item->name << ", Quantity: " << item->quantity << ", Price: " << item->price << ", Supplier ID: " << item->supplierId << "\n";
        } else {
            std::cout << "Item not found\n";
        }
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << "\n";
        }
    }

    void displayItems() {
        for (const auto &item : items) {
            std::cout << "Item ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity << ", Price: " << item.price << ", Supplier ID: " << item.supplierId << "\n";
        }
    }
};

int main() {
    InventorySystem inventory;

    inventory.addSupplier(1, "Supplier A", "12345");
    inventory.addSupplier(2, "Supplier B", "67890");

    inventory.addItem(1, "Item A", 100, 20.50, 1);
    inventory.addItem(2, "Item B", 200, 15.75, 2);

    inventory.displaySuppliers();
    inventory.displayItems();

    inventory.updateItem(1, "Item AA", 120, 21.00);
    inventory.searchItem(1);

    inventory.deleteSupplier(1);
    inventory.displaySuppliers();

    inventory.deleteItem(2);
    inventory.displayItems();

    return 0;
}