#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;

    Item(int i, std::string n, int q, double p) : id(i), name(n), quantity(q), price(p) {}
};

class Supplier {
public:
    int id;
    std::string name;

    Supplier(int i, std::string n) : id(i), name(n) {}
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(int id, std::string name, int quantity, double price) {
        items.push_back(Item(id, name, quantity, price));
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, std::string name, int quantity, double price) {
        for (auto &item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    void searchItem(int id) {
        for (const auto &item : items) {
            if (item.id == id) {
                std::cout << "Item ID: " << item.id << ", Name: " << item.name 
                          << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
                return;
            }
        }
        std::cout << "Item not found." << std::endl;
    }

    void displayItems() {
        for (const auto &item : items) {
            std::cout << "Item ID: " << item.id << ", Name: " << item.name 
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
        }
    }

    void addSupplier(int id, std::string name) {
        suppliers.push_back(Supplier(id, name));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addItem(1, "Laptop", 50, 999.99);
    ims.addItem(2, "Smartphone", 100, 599.99);
    ims.addSupplier(1, "Supplier A");
    ims.addSupplier(2, "Supplier B");

    std::cout << "Items in Inventory:" << std::endl;
    ims.displayItems();
    
    std::cout << "\nSuppliers:" << std::endl;
    ims.displaySuppliers();

    std::cout << "\nSearching for Item with ID 1:" << std::endl;
    ims.searchItem(1);

    ims.updateItem(1, "Laptop Pro", 45, 1299.99);

    std::cout << "\nItems after update:" << std::endl;
    ims.displayItems();

    return 0;
}