#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    float price;
    
    Item(int id, const std::string& name, int quantity, float price) 
        : id(id), name(name), quantity(quantity), price(price) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInformation;
    
    Supplier(int id, const std::string& name, const std::string& contactInformation) 
        : id(id), name(name), contactInformation(contactInformation) {}
};

class InventoryManagementSystem {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;
    
public:
    void addItem(int id, const std::string& name, int quantity, float price) {
        items.emplace_back(id, name, quantity, price);
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, const std::string& name, int quantity, float price) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    Item* searchItem(int id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
        }
    }

    void addSupplier(int id, const std::string& name, const std::string& contactInformation) {
        suppliers.emplace_back(id, name, contactInformation);
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contactInformation) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contactInformation = contactInformation;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contactInformation << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addItem(1, "Item1", 10, 99.9);
    ims.addItem(2, "Item2", 20, 199.9);
    ims.addSupplier(1, "Supplier1", "Contact1");
    ims.addSupplier(2, "Supplier2", "Contact2");

    ims.displayItems();
    ims.displaySuppliers();

    ims.updateItem(1, "UpdatedItem1", 15, 89.9);
    ims.updateSupplier(1, "UpdatedSupplier1", "UpdatedContact1");

    ims.displayItems();
    ims.displaySuppliers();

    ims.deleteItem(2);
    ims.deleteSupplier(2);

    ims.displayItems();
    ims.displaySuppliers();

    return 0;
}