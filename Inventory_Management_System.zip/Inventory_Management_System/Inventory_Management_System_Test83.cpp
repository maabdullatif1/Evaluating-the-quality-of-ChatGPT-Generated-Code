#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    Supplier(int id, std::string name) : id(id), name(name) {}
};

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;
    int supplierId;
    Item(int id, std::string name, int quantity, double price, int supplierId)
        : id(id), name(name), quantity(quantity), price(price), supplierId(supplierId) {}
};

class InventorySystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    Item* findItem(int id) {
        for (auto &item : items) {
            if (item.id == id) return &item;
        }
        return nullptr;
    }

    Supplier* findSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) return &supplier;
        }
        return nullptr;
    }

public:
    void addItem(int id, std::string name, int quantity, double price, int supplierId) {
        if (!findItem(id)) {
            items.push_back(Item(id, name, quantity, price, supplierId));
        }
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, std::string name, int quantity, double price, int supplierId) {
        Item* item = findItem(id);
        if (item) {
            item->name = name;
            item->quantity = quantity;
            item->price = price;
            item->supplierId = supplierId;
        }
    }

    void searchItem(int id) {
        Item* item = findItem(id);
        if (item) {
            std::cout << "Item ID: " << item->id << ", Name: " << item->name
                      << ", Quantity: " << item->quantity << ", Price: " << item->price 
                      << ", Supplier ID: " << item->supplierId << std::endl;
        } else {
            std::cout << "Item not found" << std::endl;
        }
    }

    void displayItems() {
        for (const auto &item : items) {
            std::cout << "Item ID: " << item.id << ", Name: " << item.name
                      << ", Quantity: " << item.quantity << ", Price: " << item.price 
                      << ", Supplier ID: " << item.supplierId << std::endl;
        }
    }

    void addSupplier(int id, std::string name) {
        if (!findSupplier(id)) {
            suppliers.push_back(Supplier(id, name));
        }
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, std::string name) {
        Supplier* supplier = findSupplier(id);
        if (supplier) {
            supplier->name = name;
        }
    }

    void searchSupplier(int id) {
        Supplier* supplier = findSupplier(id);
        if (supplier) {
            std::cout << "Supplier ID: " << supplier->id << ", Name: " << supplier->name << std::endl;
        } else {
            std::cout << "Supplier not found" << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addSupplier(1, "Supplier A");
    system.addItem(1, "Item 1", 100, 10.5, 1);
    system.displaySuppliers();
    system.displayItems();
    system.searchSupplier(1);
    system.searchItem(1);
    system.updateSupplier(1, "Supplier A Updated");
    system.updateItem(1, "Item 1 Updated", 150, 12.5, 1);
    system.displaySuppliers();
    system.displayItems();
    system.deleteItem(1);
    system.displayItems();
    system.deleteSupplier(1);
    system.displaySuppliers();

    return 0;
}