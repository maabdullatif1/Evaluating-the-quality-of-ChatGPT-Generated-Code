#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Item {
public:
    int id;
    string name;
    int quantity;
    double price;

    Item(int id, string name, int quantity, double price)
        : id(id), name(name), quantity(quantity), price(price) {}
};

class Supplier {
public:
    int id;
    string name;
    string contact;

    Supplier(int id, string name, string contact)
        : id(id), name(name), contact(contact) {}
};

class InventorySystem {
    vector<Item> items;
    vector<Supplier> suppliers;

public:
    void addItem(int id, string name, int quantity, double price) {
        items.push_back(Item(id, name, quantity, price));
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                return;
            }
        }
    }

    void updateItem(int id, string name, int quantity, double price) {
        for (auto &item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                return;
            }
        }
    }

    void searchItem(int id) {
        for (const auto &item : items) {
            if (item.id == id) {
                cout << "Item ID: " << item.id << " Name: " << item.name << " Quantity: " << item.quantity << " Price: " << item.price << endl;
                return;
            }
        }
        cout << "Item not found." << endl;
    }

    void displayItems() {
        for (const auto &item : items) {
            cout << "Item ID: " << item.id << " Name: " << item.name << " Quantity: " << item.quantity << " Price: " << item.price << endl;
        }
    }

    void addSupplier(int id, string name, string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                return;
            }
        }
    }

    void updateSupplier(int id, string name, string contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                return;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto &supplier : suppliers) {
            if (supplier.id == id) {
                cout << "Supplier ID: " << supplier.id << " Name: " << supplier.name << " Contact: " << supplier.contact << endl;
                return;
            }
        }
        cout << "Supplier not found." << endl;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            cout << "Supplier ID: " << supplier.id << " Name: " << supplier.name << " Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addItem(1, "Laptop", 10, 799.99);
    system.addItem(2, "Smartphone", 20, 499.99);
    system.addSupplier(1, "Tech Supplies Co.", "contact@techsupplies.com");
    system.addSupplier(2, "Gadget World", "info@gadgetworld.com");
    
    cout << "Items in Inventory:" << endl;
    system.displayItems();
    
    cout << "\nSuppliers:" << endl;
    system.displaySuppliers();
    
    cout << "\nSearching for Item ID 1:" << endl;
    system.searchItem(1);
    
    cout << "\nUpdating Item ID 1:" << endl;
    system.updateItem(1, "Gaming Laptop", 5, 1199.99);
    system.searchItem(1);
    
    cout << "\nDeleting Item ID 2:" << endl;
    system.deleteItem(2);
    system.displayItems();
    
    cout << "\nSearching for Supplier ID 2:" << endl;
    system.searchSupplier(2);
    
    cout << "\nUpdating Supplier ID 2:" << endl;
    system.updateSupplier(2, "Global Gadgets", "support@globalgadgets.com");
    system.searchSupplier(2);
    
    cout << "\nDeleting Supplier ID 1:" << endl;
    system.deleteSupplier(1);
    system.displaySuppliers();

    return 0;
}