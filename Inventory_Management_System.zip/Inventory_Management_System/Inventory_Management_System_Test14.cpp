#include <iostream>
#include <vector>
#include <string>

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

struct Item {
    int id;
    std::string name;
    int quantity;
    Supplier supplier;
};

class InventoryManagementSystem {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;
    int nextItemId;
    int nextSupplierId;

public:
    InventoryManagementSystem() : nextItemId(1), nextSupplierId(1) {}

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back({nextSupplierId++, name, contact});
    }

    void addItem(const std::string& name, int quantity, int supplierId) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == supplierId) {
                items.push_back({nextItemId++, name, quantity, supplier});
                return;
            }
        }
        std::cout << "Supplier not found\n";
    }

    void deleteItem(int itemId) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == itemId) {
                items.erase(it);
                return;
            }
        }
        std::cout << "Item not found\n";
    }

    void updateItem(int itemId, const std::string& name, int quantity, int supplierId) {
        for (auto& item : items) {
            if (item.id == itemId) {
                for (const auto& supplier : suppliers) {
                    if (supplier.id == supplierId) {
                        item.name = name;
                        item.quantity = quantity;
                        item.supplier = supplier;
                        return;
                    }
                }
                std::cout << "Supplier not found\n";
                return;
            }
        }
        std::cout << "Item not found\n";
    }

    void searchItem(const std::string& name) {
        for (const auto& item : items) {
            if (item.name == name) {
                std::cout << "Item found: ID " << item.id << ", Name: " << item.name 
                          << ", Quantity: " << item.quantity << ", Supplier: " << item.supplier.name << "\n";
                return;
            }
        }
        std::cout << "Item not found\n";
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item ID: " << item.id << ", Name: " << item.name 
                      << ", Quantity: " << item.quantity << ", Supplier: " << item.supplier.name << "\n";
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier("ABC Corp", "12345");
    ims.addSupplier("XYZ Ltd", "67890");
    ims.addItem("Item1", 100, 1);
    ims.addItem("Item2", 200, 2);
    ims.displayItems();
    ims.displaySuppliers();
    ims.searchItem("Item1");
    ims.updateItem(1, "Item1", 150, 2);
    ims.displayItems();
    ims.deleteItem(1);
    ims.displayItems();
    return 0;
}