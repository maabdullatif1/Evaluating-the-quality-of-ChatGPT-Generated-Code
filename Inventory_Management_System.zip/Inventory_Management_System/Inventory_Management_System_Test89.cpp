#include <iostream>
#include <vector>
#include <string>

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

struct Item {
    int id;
    std::string name;
    int quantity;
    int supplierId;
};

class InventoryManagementSystem {
    std::vector<Supplier> suppliers;
    std::vector<Item> items;
    
    Supplier* findSupplierById(int id) {
        for(auto& supplier : suppliers) {
            if(supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    Item* findItemById(int id) {
        for(auto& item : items) {
            if(item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

public:
    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back({id, name, contact});
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(),
                       [id](Supplier& supplier) { return supplier.id == id; }),
                       suppliers.end());
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        Supplier* supplier = findSupplierById(id);
        if(supplier != nullptr) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void addItem(int id, std::string name, int quantity, int supplierId) {
        items.push_back({id, name, quantity, supplierId});
    }

    void deleteItem(int id) {
        items.erase(std::remove_if(items.begin(), items.end(),
                    [id](Item& item) { return item.id == id; }),
                    items.end());
    }

    void updateItem(int id, std::string name, int quantity, int supplierId) {
        Item* item = findItemById(id);
        if(item != nullptr) {
            item->name = name;
            item->quantity = quantity;
            item->supplierId = supplierId;
        }
    }

    Supplier* searchSupplier(int id) {
        return findSupplierById(id);
    }

    Item* searchItem(int id) {
        return findItemById(id);
    }

    void displaySuppliers() {
        for(const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id 
                      << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }

    void displayItems() {
        for(const auto& item : items) {
            std::cout << "Item ID: " << item.id 
                      << ", Name: " << item.name 
                      << ", Quantity: " << item.quantity 
                      << ", Supplier ID: " << item.supplierId << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier(1, "Supplier One", "123456789");
    ims.addItem(1, "Item One", 100, 1);
    ims.displaySuppliers();
    ims.displayItems();
    return 0;
}