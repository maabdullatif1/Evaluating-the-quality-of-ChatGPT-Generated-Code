#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;

    Item(int itemId, std::string itemName, int itemQuantity, double itemPrice)
        : id(itemId), name(itemName), quantity(itemQuantity), price(itemPrice) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int supplierId, std::string supplierName, std::string supplierContact)
        : id(supplierId), name(supplierName), contact(supplierContact) {}
};

class InventoryManagement {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(int id, std::string name, int quantity, double price) {
        items.push_back(Item(id, name, quantity, price));
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, std::string name, int quantity, double price) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    void searchItem(int id) {
        for (const auto& item : items) {
            if (item.id == id) {
                std::cout << "Item ID: " << item.id 
                          << ", Name: " << item.name 
                          << ", Quantity: " << item.quantity 
                          << ", Price: " << item.price << '\n';
                return;
            }
        }
        std::cout << "Item not found.\n";
    }

    void displayAllItems() {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id 
                      << ", Name: " << item.name 
                      << ", Quantity: " << item.quantity 
                      << ", Price: $" << item.price << '\n';
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                std::cout << "Supplier ID: " << supplier.id 
                          << ", Name: " << supplier.name 
                          << ", Contact: " << supplier.contact << '\n';
                return;
            }
        }
        std::cout << "Supplier not found.\n";
    }

    void displayAllSuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id 
                      << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << '\n';
        }
    }
};

int main() {
    InventoryManagement ims;
    ims.addItem(1, "Item1", 10, 5.99);
    ims.addItem(2, "Item2", 20, 3.49);
    ims.addSupplier(1, "Supplier1", "123-456-7890");
    ims.addSupplier(2, "Supplier2", "987-654-3210");

    std::cout << "All Items:\n";
    ims.displayAllItems();
    std::cout << "\nAll Suppliers:\n";
    ims.displayAllSuppliers();

    std::cout << "\nSearching for Item with ID 1:\n";
    ims.searchItem(1);

    std::cout << "\nUpdating Item with ID 1:\n";
    ims.updateItem(1, "UpdatedItem1", 15, 5.49);
    ims.displayAllItems();

    std::cout << "\nDeleting Item with ID 2:\n";
    ims.deleteItem(2);
    ims.displayAllItems();

    return 0;
}