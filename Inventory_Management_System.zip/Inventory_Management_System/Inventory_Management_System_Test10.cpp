#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Item {
public:
    int itemId;
    string name;
    int quantity;
    double price;
    int supplierId;

    Item(int id, string n, int q, double p, int sid)
        : itemId(id), name(n), quantity(q), price(p), supplierId(sid) {}
};

class Supplier {
public:
    int supplierId;
    string name;
    string contact;

    Supplier(int id, string n, string c)
        : supplierId(id), name(n), contact(c) {}
};

class InventoryManagement {
private:
    vector<Item> items;
    vector<Supplier> suppliers;

    Item* findItemById(int id) {
        for (auto &item : items) {
            if (item.itemId == id)
                return &item;
        }
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.supplierId == id)
                return &supplier;
        }
        return nullptr;
    }

public:
    void addItem(int id, string name, int quantity, double price, int supplierId) {
        items.emplace_back(id, name, quantity, price, supplierId);
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->itemId == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, string newName, int newQuantity, double newPrice) {
        Item* item = findItemById(id);
        if (item) {
            item->name = newName;
            item->quantity = newQuantity;
            item->price = newPrice;
        }
    }

    Item* searchItem(int id) {
        return findItemById(id);
    }

    void displayItems() {
        for (const auto &item : items) {
            cout << "Item ID: " << item.itemId
                 << ", Name: " << item.name
                 << ", Quantity: " << item.quantity
                 << ", Price: " << item.price
                 << ", Supplier ID: " << item.supplierId << endl;
        }
    }

    void addSupplier(int id, string name, string contact) {
        suppliers.emplace_back(id, name, contact);
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->supplierId == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string newName, string newContact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = newName;
            supplier->contact = newContact;
        }
    }

    Supplier* searchSupplier(int id) {
        return findSupplierById(id);
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            cout << "Supplier ID: " << supplier.supplierId
                 << ", Name: " << supplier.name
                 << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    InventoryManagement inventory;

    inventory.addSupplier(1, "ABC Corp", "123-456-7890");
    inventory.addSupplier(2, "XYZ Inc", "987-654-3210");

    inventory.addItem(101, "Laptop", 50, 799.99, 1);
    inventory.addItem(102, "Mouse", 150, 19.99, 2);

    cout << "Display all items:" << endl;
    inventory.displayItems();

    cout << "Display all suppliers:" << endl;
    inventory.displaySuppliers();

    inventory.updateItem(102, "Wireless Mouse", 120, 24.99);
    cout << "Updated item 102:" << endl;
    Item* item = inventory.searchItem(102);
    if (item) {
        cout << "Item ID: " << item->itemId
             << ", Name: " << item->name
             << ", Quantity: " << item->quantity
             << ", Price: " << item->price << endl;
    }

    inventory.deleteSupplier(2);
    cout << "Suppliers after deletion:" << endl;
    inventory.displaySuppliers();

    return 0;
}