#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    float price;

    Item(int id, const std::string& name, int quantity, float price)
        : id(id), name(name), quantity(quantity), price(price) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInformation;

    Supplier(int id, const std::string& name, const std::string& contactInformation)
        : id(id), name(name), contactInformation(contactInformation) {}
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(int id, const std::string& name, int quantity, float price) {
        items.push_back(Item(id, name, quantity, price));
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, const std::string& name, int quantity, float price) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    void searchItem(int id) {
        for (const auto& item : items) {
            if (item.id == id) {
                std::cout << "Item ID: " << item.id
                          << ", Name: " << item.name
                          << ", Quantity: " << item.quantity
                          << ", Price: " << item.price << '\n';
                return;
            }
        }
        std::cout << "Item not found\n";
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item ID: " << item.id
                      << ", Name: " << item.name
                      << ", Quantity: " << item.quantity
                      << ", Price: " << item.price << '\n';
        }
    }

    void addSupplier(int id, const std::string& name, const std::string& contactInformation) {
        suppliers.push_back(Supplier(id, name, contactInformation));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contactInformation) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contactInformation = contactInformation;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                std::cout << "Supplier ID: " << supplier.id
                          << ", Name: " << supplier.name
                          << ", Contact Information: " << supplier.contactInformation << '\n';
                return;
            }
        }
        std::cout << "Supplier not found\n";
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id
                      << ", Name: " << supplier.name
                      << ", Contact Information: " << supplier.contactInformation << '\n';
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addItem(1, "Laptop", 10, 1500.0);
    ims.addItem(2, "Smartphone", 20, 800.0);

    ims.addSupplier(1, "Tech Supplies Co.", "contact@techsupplies.com");
    ims.addSupplier(2, "Gadget World", "info@gadgetworld.com");

    std::cout << "Items list:\n";
    ims.displayItems();

    std::cout << "\nSuppliers list:\n";
    ims.displaySuppliers();

    std::cout << "\nSearch for item ID 1:\n";
    ims.searchItem(1);

    std::cout << "\nSearch for supplier ID 2:\n";
    ims.searchSupplier(2);

    ims.updateItem(1, "Gaming Laptop", 5, 2000.0);
    ims.updateSupplier(1, "Tech Supplies Ltd.", "support@techsupplies.com");

    std::cout << "\nUpdated Items list:\n";
    ims.displayItems();

    std::cout << "\nUpdated Suppliers list:\n";
    ims.displaySuppliers();

    ims.deleteItem(2);
    ims.deleteSupplier(2);

    std::cout << "\nAfter deletion Items list:\n";
    ims.displayItems();

    std::cout << "\nAfter deletion Suppliers list:\n";
    ims.displaySuppliers();

    return 0;
}