#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Item {
public:
    int id;
    string name;
    int quantity;
    double price;
    int supplierId;

    Item(int id, string name, int quantity, double price, int supplierId) 
        : id(id), name(name), quantity(quantity), price(price), supplierId(supplierId) {}
};

class Supplier {
public:
    int id;
    string name;
    string contactInfo;

    Supplier(int id, string name, string contactInfo) 
        : id(id), name(name), contactInfo(contactInfo) {}
};

class InventoryManagement {
    vector<Item> items;
    vector<Supplier> suppliers;
    int itemCounter = 1;
    int supplierCounter = 1;

public:
    void addItem(string name, int quantity, double price, int supplierId) {
        items.push_back(Item(itemCounter++, name, quantity, price, supplierId));
    }

    void addSupplier(string name, string contactInfo) {
        suppliers.push_back(Supplier(supplierCounter++, name, contactInfo));
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, string name, int quantity, double price, int supplierId) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                item.supplierId = supplierId;
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    Item* searchItem(int id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for (const auto& item : items) {
            cout << "Item ID: " << item.id << ", Name: " << item.name 
                 << ", Quantity: " << item.quantity << ", Price: " << item.price 
                 << ", Supplier ID: " << item.supplierId << endl;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name 
                 << ", Contact Info: " << supplier.contactInfo << endl;
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addSupplier("Supplier1", "Contact1");
    inventory.addSupplier("Supplier2", "Contact2");
    inventory.addItem("Item1", 100, 9.99, 1);
    inventory.addItem("Item2", 200, 19.99, 2);

    inventory.displaySuppliers();
    inventory.displayItems();

    inventory.updateItem(1, "Item1Updated", 150, 14.99, 1);
    inventory.displayItems();

    inventory.deleteItem(2);
    inventory.displayItems();

    return 0;
}