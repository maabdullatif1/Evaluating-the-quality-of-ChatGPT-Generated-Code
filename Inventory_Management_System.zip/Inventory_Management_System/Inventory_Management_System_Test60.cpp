#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    std::string id;
    std::string name;
    std::string contact;
    
    Supplier(const std::string& id, const std::string& name, const std::string& contact)
        : id(id), name(name), contact(contact) {}
};

class Item {
public:
    std::string id;
    std::string name;
    int quantity;
    std::string supplierId;
    
    Item(const std::string& id, const std::string& name, int quantity, const std::string& supplierId)
        : id(id), name(name), quantity(quantity), supplierId(supplierId) {}
};

class InventoryManagementSystem {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(const std::string& id, const std::string& name, int quantity, const std::string& supplierId) {
        items.push_back(Item(id, name, quantity, supplierId));
    }
    
    void deleteItem(const std::string& id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                return;
            }
        }
    }
    
    void updateItem(const std::string& id, const std::string& name, int quantity, const std::string& supplierId) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.supplierId = supplierId;
                return;
            }
        }
    }
    
    Item* searchItem(const std::string& id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }
    
    void displayItems() {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name 
                      << ", Quantity: " << item.quantity << ", Supplier ID: " << item.supplierId << std::endl;
        }
    }
    
    void addSupplier(const std::string& id, const std::string& name, const std::string& contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }
    
    void deleteSupplier(const std::string& id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                return;
            }
        }
    }
    
    void updateSupplier(const std::string& id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                return;
            }
        }
    }
    
    Supplier* searchSupplier(const std::string& id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }
    
    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier("S001", "Supplier One", "123456789");
    ims.addItem("I001", "Item One", 100, "S001");
    ims.displayItems();
    ims.displaySuppliers();
    return 0;
}