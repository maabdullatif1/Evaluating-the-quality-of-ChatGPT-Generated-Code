#include <iostream>
#include <string>
#include <vector>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    float price;

    Item(int id, std::string name, int quantity, float price) 
        : id(id), name(name), quantity(quantity), price(price) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, std::string name, std::string contact) 
        : id(id), name(name), contact(contact) {}
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(int id, std::string name, int quantity, float price) {
        items.push_back(Item(id, name, quantity, price));
    }

    void deleteItem(int id) {
        for(auto it = items.begin(); it != items.end(); ++it) {
            if(it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, std::string name, int quantity, float price) {
        for(auto &item : items) {
            if(item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    Item* searchItem(int id) {
        for(auto &item : items) {
            if(item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for(const auto &item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name 
                      << ", Quantity: " << item.quantity << ", Price: $" 
                      << item.price << '\n';
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for(auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if(it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for(auto &supplier : suppliers) {
            if(supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for(const auto &supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << '\n';
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem(1, "Item 1", 100, 10.99);
    ims.addItem(2, "Item 2", 200, 5.49);
    ims.addSupplier(1, "Supplier 1", "123-456-7890");
    ims.addSupplier(2, "Supplier 2", "987-654-3210");

    std::cout << "Items:\n";
    ims.displayItems();
    
    std::cout << "\nSuppliers:\n";
    ims.displaySuppliers();
    
    ims.updateItem(2, "Item 2 Updated", 250, 6.99);
    
    std::cout << "\nUpdated Items:\n";
    ims.displayItems();
    
    ims.deleteItem(1);
    
    std::cout << "\nAfter Deletion Items:\n";
    ims.displayItems();
    
    return 0;
}