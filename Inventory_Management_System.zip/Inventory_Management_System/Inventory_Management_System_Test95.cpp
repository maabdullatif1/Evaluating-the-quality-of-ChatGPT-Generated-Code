#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Supplier {
public:
    int id;
    string name;
    string contact;
};

class Item {
public:
    int id;
    string name;
    int quantity;
    double price;
    Supplier supplier;
};

class InventoryManagementSystem {
private:
    vector<Item> items;
    vector<Supplier> suppliers;

public:
    void addSupplier(int id, const string& name, const string& contact) {
        Supplier supplier = { id, name, contact };
        suppliers.push_back(supplier);
    }
   
    void addItem(int id, const string& name, int quantity, double price, int supplierId) {
        for (auto& sup : suppliers) {
            if (sup.id == supplierId) {
                Item item = { id, name, quantity, price, sup };
                items.push_back(item);
                return;
            }
        }
        cout << "Supplier not found\n";
    }
   
    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                return;
            }
        }
        cout << "Item not found\n";
    }
   
    void updateItem(int id, const string& name, int quantity, double price) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                return;
            }
        }
        cout << "Item not found\n";
    }

    void searchItem(int id) {
        for (const auto& item : items) {
            if (item.id == id) {
                cout << "Item found: " << item.name << ", Qty: " << item.quantity << ", Price: " << item.price
                     << ", Supplier: " << item.supplier.name << "\n";
                return;
            }
        }
        cout << "Item not found\n";
    }

    void displayItems() {
        for (const auto& item : items) {
            cout << "Item ID: " << item.id << ", Name: " << item.name << ", Qty: " << item.quantity
                 << ", Price: " << item.price << ", Supplier: " << item.supplier.name << "\n";
        }
    }
    
    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier(1, "Supplier A", "123-456-7890");
    ims.addSupplier(2, "Supplier B", "234-567-8901");
    ims.addItem(1, "Item 1", 10, 99.99, 1);
    ims.addItem(2, "Item 2", 20, 49.99, 2);
    ims.displayItems();
    ims.searchItem(1);
    ims.updateItem(1, "Updated Item 1", 15, 89.99);
    ims.searchItem(1);
    ims.deleteItem(1);
    ims.displayItems();
    ims.displaySuppliers();
    return 0;
}