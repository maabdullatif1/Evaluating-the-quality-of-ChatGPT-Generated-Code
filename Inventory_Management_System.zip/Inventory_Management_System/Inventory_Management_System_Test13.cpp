#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    std::string itemName;
    int itemID;
    int quantity;
    double price;

    Item(std::string name, int id, int qty, double prc) : itemName(name), itemID(id), quantity(qty), price(prc) {}
};

class Supplier {
public:
    std::string supplierName;
    int supplierID;

    Supplier(std::string name, int id) : supplierName(name), supplierID(id) {}
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(const std::string& name, int id, int qty, double price) {
        items.push_back(Item(name, id, qty, price));
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->itemID == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, const std::string& name, int qty, double price) {
        for (auto& item : items) {
            if (item.itemID == id) {
                item.itemName = name;
                item.quantity = qty;
                item.price = price;
                break;
            }
        }
    }

    void searchItem(int id) {
        for (const auto& item : items) {
            if (item.itemID == id) {
                std::cout << "Item Found: " << item.itemName << ", ID: " << item.itemID
                          << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
                return;
            }
        }
        std::cout << "Item not found." << std::endl;
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item Name: " << item.itemName << ", ID: " << item.itemID
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
        }
    }

    void addSupplier(const std::string& name, int id) {
        suppliers.push_back(Supplier(name, id));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->supplierID == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name) {
        for (auto& supplier : suppliers) {
            if (supplier.supplierID == id) {
                supplier.supplierName = name;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.supplierID == id) {
                std::cout << "Supplier Found: " << supplier.supplierName << ", ID: " << supplier.supplierID << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found." << std::endl;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier Name: " << supplier.supplierName << ", ID: " << supplier.supplierID << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addItem("Apple", 1, 100, 0.99);
    ims.addItem("Orange", 2, 150, 1.29);

    ims.addSupplier("Fresh Fruits Ltd", 1);
    ims.addSupplier("Citrus Suppliers Inc", 2);

    ims.displayItems();
    ims.displaySuppliers();

    ims.searchItem(1);
    ims.searchSupplier(1);

    ims.updateItem(1, "Green Apple", 120, 1.09);
    ims.updateSupplier(1, "Fresh Fruits and Veggies Ltd");

    ims.displayItems();
    ims.displaySuppliers();

    ims.deleteItem(2);
    ims.deleteSupplier(2);

    ims.displayItems();
    ims.displaySuppliers();

    return 0;
}