#include <iostream>
#include <string>
#include <vector>

struct Item {
    std::string name;
    int quantity;
    double price;
};

struct Supplier {
    std::string name;
    std::string contact;
};

class InventoryManagementSystem {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(const std::string& name, int quantity, double price) {
        items.push_back({name, quantity, price});
    }

    void deleteItem(const std::string& name) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->name == name) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(const std::string& name, int quantity, double price) {
        for (auto& item : items) {
            if (item.name == name) {
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    Item* searchItem(const std::string& name) {
        for (auto& item : items) {
            if (item.name == name) {
                return &item;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item: " << item.name << ", Quantity: " << item.quantity 
                      << ", Price: $" << item.price << "\n";
        }
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back({name, contact});
    }

    void deleteSupplier(const std::string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    Supplier* searchSupplier(const std::string& name) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier: " << supplier.name << ", Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem("Widget", 100, 2.99);
    ims.addSupplier("ABC Corp", "123-4567");
    ims.displayItems();
    ims.displaySuppliers();
    Item* item = ims.searchItem("Widget");
    if (item) {
        std::cout << "Found item: " << item->name << "\n";
    }
    return 0;
}