#include <iostream>
#include <string>
#include <vector>

class Supplier {
public:
    std::string name;
    std::string contact;

    Supplier(std::string n, std::string c) : name(n), contact(c) {}
};

class Item {
public:
    std::string itemName;
    int quantity;
    double price;
    Supplier* supplier;

    Item(std::string n, int q, double p, Supplier* s) : itemName(n), quantity(q), price(p), supplier(s) {}
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addSupplier(std::string name, std::string contact) {
        suppliers.push_back(Supplier(name, contact));
    }

    void addItem(std::string itemName, int quantity, double price, std::string supplierName) {
        Supplier* supplier = findSupplier(supplierName);
        if (supplier) {
            items.push_back(Item(itemName, quantity, price, supplier));
        }
    }

    void deleteItem(std::string itemName) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->itemName == itemName) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(std::string itemName, int quantity, double price, std::string supplierName) {
        for (Item& item : items) {
            if (item.itemName == itemName) {
                item.quantity = quantity;
                item.price = price;
                item.supplier = findSupplier(supplierName);
                break;
            }
        }
    }

    void searchItem(std::string itemName) {
        for (const Item& item : items) {
            if (item.itemName == itemName) {
                std::cout << "Item Name: " << item.itemName << "\nQuantity: " << item.quantity << "\nPrice: " << item.price
                          << "\nSupplier: " << item.supplier->name << '\n';
                return;
            }
        }
        std::cout << "Item not found.\n";
    }

    void displayItems() {
        for (const Item& item : items) {
            std::cout << "Item Name: " << item.itemName << "\nQuantity: " << item.quantity << "\nPrice: " << item.price
                      << "\nSupplier: " << item.supplier->name << '\n';
        }
    }

    void displaySuppliers() {
        for (const Supplier& supplier : suppliers) {
            std::cout << "Supplier Name: " << supplier.name << "\nContact: " << supplier.contact << '\n';
        }
    }

private:
    Supplier* findSupplier(std::string supplierName) {
        for (Supplier& supplier : suppliers) {
            if (supplier.name == supplierName) {
                return &supplier;
            }
        }
        return nullptr;
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier("Supplier1", "123456789");
    ims.addSupplier("Supplier2", "987654321");
    ims.addItem("Item1", 10, 5.5, "Supplier1");
    ims.addItem("Item2", 20, 15.0, "Supplier2");
    ims.displayItems();
    ims.searchItem("Item1");
    ims.updateItem("Item1", 15, 6.0, "Supplier1");
    ims.displayItems();
    ims.deleteItem("Item2");
    ims.displayItems();
    ims.displaySuppliers();
    return 0;
}