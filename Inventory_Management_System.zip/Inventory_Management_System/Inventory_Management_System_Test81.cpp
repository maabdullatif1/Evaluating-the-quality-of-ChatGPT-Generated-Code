#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int itemID;
    std::string itemName;
    int quantity;
    
    Item(int id, std::string name, int qty)
        : itemID(id), itemName(name), quantity(qty) {}
};

class Supplier {
public:
    int supplierID;
    std::string supplierName;
    
    Supplier(int id, std::string name)
        : supplierID(id), supplierName(name) {}
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;
    
public:
    void addItem(int id, std::string name, int qty) {
        items.emplace_back(id, name, qty);
    }
    
    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->itemID == id) {
                items.erase(it);
                break;
            }
        }
    }
    
    void updateItem(int id, std::string name, int qty) {
        for (auto& item : items) {
            if (item.itemID == id) {
                item.itemName = name;
                item.quantity = qty;
                break;
            }
        }
    }
    
    void searchItem(int id) {
        for (const auto& item : items) {
            if (item.itemID == id) {
                std::cout << "Item ID: " << item.itemID
                          << ", Name: " << item.itemName
                          << ", Quantity: " << item.quantity << "\n";
                return;
            }
        }
        std::cout << "Item not found.\n";
    }
    
    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item ID: " << item.itemID
                      << ", Name: " << item.itemName
                      << ", Quantity: " << item.quantity << "\n";
        }
    }
    
    void addSupplier(int id, std::string name) {
        suppliers.emplace_back(id, name);
    }
    
    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->supplierID == id) {
                suppliers.erase(it);
                break;
            }
        }
    }
    
    void updateSupplier(int id, std::string name) {
        for (auto& supplier : suppliers) {
            if (supplier.supplierID == id) {
                supplier.supplierName = name;
                break;
            }
        }
    }
    
    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.supplierID == id) {
                std::cout << "Supplier ID: " << supplier.supplierID
                          << ", Name: " << supplier.supplierName << "\n";
                return;
            }
        }
        std::cout << "Supplier not found.\n";
    }
    
    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.supplierID
                      << ", Name: " << supplier.supplierName << "\n";
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    
    ims.addItem(1, "Laptop", 50);
    ims.addItem(2, "Mouse", 200);
    
    ims.addSupplier(1, "TechCorp");
    ims.addSupplier(2, "Gadget Supplies");
    
    std::cout << "Items:\n";
    ims.displayItems();
    
    std::cout << "\nSuppliers:\n";
    ims.displaySuppliers();
    
    ims.searchItem(1);
    ims.searchSupplier(2);
    
    ims.updateItem(1, "Gaming Laptop", 40);
    ims.updateSupplier(1, "TechX");
    
    ims.deleteItem(2);
    ims.deleteSupplier(2);
    
    std::cout << "\nUpdated Items:\n";
    ims.displayItems();
    
    std::cout << "\nUpdated Suppliers:\n";
    ims.displaySuppliers();
    
    return 0;
}