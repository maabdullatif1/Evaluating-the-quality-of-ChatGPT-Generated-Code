#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Item {
public:
    string id;
    string name;
    double price;
    int quantity;

    Item(string id, string name, double price, int quantity)
        : id(id), name(name), price(price), quantity(quantity) {}
};

class Supplier {
public:
    string id;
    string name;
    string contact;

    Supplier(string id, string name, string contact)
        : id(id), name(name), contact(contact) {}
};

class InventoryManagementSystem {
private:
    vector<Item> items;
    vector<Supplier> suppliers;

    int findItemIndexById(const string& itemId) {
        for (size_t i = 0; i < items.size(); ++i) {
            if (items[i].id == itemId) return i;
        }
        return -1;
    }

    int findSupplierIndexById(const string& supplierId) {
        for (size_t i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].id == supplierId) return i;
        }
        return -1;
    }
    
public:
    void addItem(const string& id, const string& name, double price, int quantity) {
        if (findItemIndexById(id) == -1) {
            items.emplace_back(id, name, price, quantity);
        }
    }

    void deleteItem(const string& id) {
        int index = findItemIndexById(id);
        if (index != -1) {
            items.erase(items.begin() + index);
        }
    }

    void updateItem(const string& id, const string& name, double price, int quantity) {
        int index = findItemIndexById(id);
        if (index != -1) {
            items[index].name = name;
            items[index].price = price;
            items[index].quantity = quantity;
        }
    }

    Item* searchItem(const string& id) {
        int index = findItemIndexById(id);
        if (index != -1) {
            return &items[index];
        }
        return nullptr;
    }

    void displayItems() {
        for (const auto& item : items) {
            cout << "ID: " << item.id << ", Name: " << item.name
                 << ", Price: " << item.price << ", Quantity: " << item.quantity << endl;
        }
    }

    void addSupplier(const string& id, const string& name, const string& contact) {
        if (findSupplierIndexById(id) == -1) {
            suppliers.emplace_back(id, name, contact);
        }
    }

    void deleteSupplier(const string& id) {
        int index = findSupplierIndexById(id);
        if (index != -1) {
            suppliers.erase(suppliers.begin() + index);
        }
    }

    void updateSupplier(const string& id, const string& name, const string& contact) {
        int index = findSupplierIndexById(id);
        if (index != -1) {
            suppliers[index].name = name;
            suppliers[index].contact = contact;
        }
    }

    Supplier* searchSupplier(const string& id) {
        int index = findSupplierIndexById(id);
        if (index != -1) {
            return &suppliers[index];
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name
                 << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem("1", "Widget", 19.99, 100);
    ims.addItem("2", "Gadget", 29.99, 50);
    ims.addSupplier("1", "Acme Corp", "123-456-7890");
    ims.addSupplier("2", "Globex Inc", "987-654-3210");

    ims.displayItems();
    ims.displaySuppliers();

    ims.updateItem("1", "Super Widget", 24.99, 120);
    ims.updateSupplier("1", "Acme Corporation", "111-222-3333");

    ims.displayItems();
    ims.displaySuppliers();

    ims.deleteItem("2");
    ims.deleteSupplier("2");

    ims.displayItems();
    ims.displaySuppliers();

    return 0;
}