#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Item {
    int id;
    string name;
    int quantity;
    double price;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

class InventoryManagementSystem {
    vector<Item> items;
    vector<Supplier> suppliers;

    Item* findItem(int id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    Supplier* findSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

public:
    void addItem(int id, const string& name, int quantity, double price) {
        if (findItem(id) == nullptr) {
            items.push_back({id, name, quantity, price});
        }
    }

    void deleteItem(int id) {
        items.erase(
            remove_if(items.begin(), items.end(), [id](Item& item) { return item.id == id; }),
            items.end());
    }

    void updateItem(int id, const string& name, int quantity, double price) {
        Item* item = findItem(id);
        if (item != nullptr) {
            item->name = name;
            item->quantity = quantity;
            item->price = price;
        }
    }

    Item* searchItem(int id) {
        return findItem(id);
    }

    void displayItems() {
        for (const auto& item : items) {
            cout << "ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity << ", Price: " << item.price << endl;
        }
    }

    void addSupplier(int id, const string& name, const string& contact) {
        if (findSupplier(id) == nullptr) {
            suppliers.push_back({id, name, contact});
        }
    }

    void deleteSupplier(int id) {
        suppliers.erase(
            remove_if(suppliers.begin(), suppliers.end(), [id](Supplier& supplier) { return supplier.id == id; }),
            suppliers.end());
    }

    void updateSupplier(int id, const string& name, const string& contact) {
        Supplier* supplier = findSupplier(id);
        if (supplier != nullptr) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    Supplier* searchSupplier(int id) {
        return findSupplier(id);
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem(1, "Item1", 10, 100.5);
    ims.addItem(2, "Item2", 5, 200.0);
    ims.updateItem(1, "UpdatedItem1", 15, 150.75);
    ims.displayItems();
    Item* item = ims.searchItem(1);
    if (item) {
        cout << "Found Item: " << item->name << endl;
    }
    ims.deleteItem(2);
    ims.displayItems();
    ims.addSupplier(1, "Supplier1", "Contact1");
    ims.addSupplier(2, "Supplier2", "Contact2");
    ims.updateSupplier(1, "UpdatedSupplier1", "UpdatedContact1");
    ims.displaySuppliers();
    Supplier* supplier = ims.searchSupplier(1);
    if (supplier) {
        cout << "Found Supplier: " << supplier->name << endl;
    }
    ims.deleteSupplier(2);
    ims.displaySuppliers();
    return 0;
}