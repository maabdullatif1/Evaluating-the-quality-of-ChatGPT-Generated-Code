#include <iostream>
#include <string>

struct Item {
    int id;
    std::string name;
    int quantity;
    float price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

const int MAX_ITEMS = 100;
const int MAX_SUPPLIERS = 50;
Item items[MAX_ITEMS];
Supplier suppliers[MAX_SUPPLIERS];
int itemCount = 0;
int supplierCount = 0;

void addItem() {
    if (itemCount < MAX_ITEMS) {
        std::cout << "Enter item id, name, quantity, and price: ";
        std::cin >> items[itemCount].id >> items[itemCount].name >> items[itemCount].quantity >> items[itemCount].price;
        itemCount++;
    } else {
        std::cout << "Inventory is full!\n";
    }
}

void deleteItem() {
    int id;
    std::cout << "Enter item id to delete: ";
    std::cin >> id;
    for(int i = 0; i < itemCount; i++) {
        if(items[i].id == id) {
            items[i] = items[itemCount - 1];
            itemCount--;
            std::cout << "Item deleted.\n";
            return;
        }
    }
    std::cout << "Item not found.\n";
}

void updateItem() {
    int id;
    std::cout << "Enter item id to update: ";
    std::cin >> id;
    for(int i = 0; i < itemCount; i++) {
        if(items[i].id == id) {
            std::cout << "Enter new name, quantity, and price: ";
            std::cin >> items[i].name >> items[i].quantity >> items[i].price;
            std::cout << "Item updated.\n";
            return;
        }
    }
    std::cout << "Item not found.\n";
}

void searchItem() {
    int id;
    std::cout << "Enter item id to search: ";
    std::cin >> id;
    for(int i = 0; i < itemCount; i++) {
        if(items[i].id == id) {
            std::cout << "Item: " << items[i].id << ", " << items[i].name << ", " << items[i].quantity << ", $" << items[i].price << "\n";
            return;
        }
    }
    std::cout << "Item not found.\n";
}

void displayItems() {
    for(int i = 0; i < itemCount; i++) {
        std::cout << "Item: " << items[i].id << ", " << items[i].name << ", " << items[i].quantity << ", $" << items[i].price << "\n";
    }
}

void addSupplier() {
    if (supplierCount < MAX_SUPPLIERS) {
        std::cout << "Enter supplier id, name, and contact: ";
        std::cin >> suppliers[supplierCount].id >> suppliers[supplierCount].name >> suppliers[supplierCount].contact;
        supplierCount++;
    } else {
        std::cout << "Suppliers list is full!\n";
    }
}

void deleteSupplier() {
    int id;
    std::cout << "Enter supplier id to delete: ";
    std::cin >> id;
    for(int i = 0; i < supplierCount; i++) {
        if(suppliers[i].id == id) {
            suppliers[i] = suppliers[supplierCount - 1];
            supplierCount--;
            std::cout << "Supplier deleted.\n";
            return;
        }
    }
    std::cout << "Supplier not found.\n";
}

void updateSupplier() {
    int id;
    std::cout << "Enter supplier id to update: ";
    std::cin >> id;
    for(int i = 0; i < supplierCount; i++) {
        if(suppliers[i].id == id) {
            std::cout << "Enter new name and contact: ";
            std::cin >> suppliers[i].name >> suppliers[i].contact;
            std::cout << "Supplier updated.\n";
            return;
        }
    }
    std::cout << "Supplier not found.\n";
}

void searchSupplier() {
    int id;
    std::cout << "Enter supplier id to search: ";
    std::cin >> id;
    for(int i = 0; i < supplierCount; i++) {
        if(suppliers[i].id == id) {
            std::cout << "Supplier: " << suppliers[i].id << ", " << suppliers[i].name << ", " << suppliers[i].contact << "\n";
            return;
        }
    }
    std::cout << "Supplier not found.\n";
}

void displaySuppliers() {
    for(int i = 0; i < supplierCount; i++) {
        std::cout << "Supplier: " << suppliers[i].id << ", " << suppliers[i].name << ", " << suppliers[i].contact << "\n";
    }
}

int main() {
    int choice;
    while (true) {
        std::cout << "\n1. Add Item\n2. Delete Item\n3. Update Item\n4. Search Item\n5. Display Items\n";
        std::cout << "6. Add Supplier\n7. Delete Supplier\n8. Update Supplier\n9. Search Supplier\n10. Display Suppliers\n11. Exit\n";
        std::cout << "Enter choice: ";
        std::cin >> choice;
        switch (choice) {
            case 1: addItem(); break;
            case 2: deleteItem(); break;
            case 3: updateItem(); break;
            case 4: searchItem(); break;
            case 5: displayItems(); break;
            case 6: addSupplier(); break;
            case 7: deleteSupplier(); break;
            case 8: updateSupplier(); break;
            case 9: searchSupplier(); break;
            case 10: displaySuppliers(); break;
            case 11: return 0;
            default: std::cout << "Invalid choice.\n";
        }
    }
}