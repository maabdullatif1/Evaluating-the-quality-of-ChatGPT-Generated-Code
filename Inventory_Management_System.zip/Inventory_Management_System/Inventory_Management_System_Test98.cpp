#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;
    std::string supplier;
    
    Item(int id, std::string name, int quantity, double price, std::string supplier)
    : id(id), name(name), quantity(quantity), price(price), supplier(supplier) {}
};

class Inventory {
private:
    std::vector<Item> items;
    
    Item* findItemById(int id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

public:
    void addItem(int id, std::string name, int quantity, double price, std::string supplier) {
        if (findItemById(id) == nullptr) {
            items.emplace_back(id, name, quantity, price, supplier);
        } else {
            std::cout << "Item with ID " << id << " already exists.\n";
        }
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                return;
            }
        }
        std::cout << "Item with ID " << id << " not found.\n";
    }

    void updateItem(int id, std::string name, int quantity, double price, std::string supplier) {
        Item* item = findItemById(id);
        if (item) {
            item->name = name;
            item->quantity = quantity;
            item->price = price;
            item->supplier = supplier;
        } else {
            std::cout << "Item with ID " << id << " not found.\n";
        }
    }
    
    void searchItem(int id) {
        Item* item = findItemById(id);
        if (item) {
            std::cout << "ID: " << item->id << ", Name: " << item->name << ", Quantity: " << item->quantity << ", Price: " << item->price << ", Supplier: " << item->supplier << "\n";
        } else {
            std::cout << "Item with ID " << id << " not found.\n";
        }
    }
    
    void displayItems() {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity << ", Price: " << item.price << ", Supplier: " << item.supplier << "\n";
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addItem(1, "Apple", 100, 0.5, "Supplier A");
    inventory.addItem(2, "Banana", 150, 0.3, "Supplier B");
    inventory.displayItems();
    inventory.updateItem(1, "Apple", 120, 0.55, "Supplier A");
    inventory.displayItems();
    inventory.searchItem(2);
    inventory.deleteItem(1);
    inventory.displayItems();
    return 0;
}