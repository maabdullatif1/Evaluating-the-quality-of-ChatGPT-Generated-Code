#include <iostream>
#include <string>
#include <vector>

class Item {
public:
    int itemID;
    std::string itemName;
    int quantity;
    double price;

    Item(int id, std::string name, int qty, double pr) 
        : itemID(id), itemName(name), quantity(qty), price(pr) {}
};

class Supplier {
public:
    int supplierID;
    std::string supplierName;
    std::string contactInfo;

    Supplier(int id, std::string name, std::string contact) 
        : supplierID(id), supplierName(name), contactInfo(contact) {}
};

class InventoryManagement {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(int id, std::string name, int qty, double price) {
        items.push_back(Item(id, name, qty, price));
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->itemID == id) {
                items.erase(it);
                break;
            }
        }
    }
    
    void updateItem(int id, std::string name, int qty, double price) {
        for (auto& item : items) {
            if (item.itemID == id) {
                item.itemName = name;
                item.quantity = qty;
                item.price = price;
                break;
            }
        }
    }

    void searchItem(int id) {
        for (const auto& item : items) {
            if (item.itemID == id) {
                std::cout << "Item ID: " << item.itemID << ", Name: " << item.itemName 
                          << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
                return;
            }
        }
        std::cout << "Item not found" << std::endl;
    }
    
    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item ID: " << item.itemID << ", Name: " << item.itemName 
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->supplierID == id) {
                suppliers.erase(it);
                break;
            }
        }
    }
    
    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto& supplier : suppliers) {
            if (supplier.supplierID == id) {
                supplier.supplierName = name;
                supplier.contactInfo = contact;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.supplierID == id) {
                std::cout << "Supplier ID: " << supplier.supplierID 
                          << ", Name: " << supplier.supplierName 
                          << ", Contact: " << supplier.contactInfo << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found" << std::endl;
    }
    
    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.supplierID 
                      << ", Name: " << supplier.supplierName 
                      << ", Contact: " << supplier.contactInfo << std::endl;
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addItem(1, "Widget", 25, 19.99);
    inventory.addItem(2, "Gadget", 50, 29.99);
    inventory.addSupplier(1, "Supplier A", "123-456-7890");
    inventory.addSupplier(2, "Supplier B", "098-765-4321");

    std::cout << "Inventory items:" << std::endl;
    inventory.displayItems();
    
    std::cout << "Suppliers:" << std::endl;
    inventory.displaySuppliers();

    return 0;
}