#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;

    Item(int i, const std::string &n, int q, double p) 
        : id(i), name(n), quantity(q), price(p) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int i, const std::string &n, const std::string &c)
        : id(i), name(n), contact(c) {}
};

class InventoryManagement {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(int id, const std::string& name, int quantity, double price) {
        items.emplace_back(id, name, quantity, price);
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, const std::string& name, int quantity, double price) {
        for (auto &item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    void searchItem(int id) {
        for (const auto &item : items) {
            if (item.id == id) {
                std::cout << "Item ID: " << item.id << ", Name: " << item.name 
                          << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
                return;
            }
        }
        std::cout << "Item not found." << std::endl;
    }

    void displayItems() {
        for (const auto &item : items) {
            std::cout << "Item ID: " << item.id << ", Name: " << item.name 
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
        }
    }

    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.emplace_back(id, name, contact);
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto &supplier : suppliers) {
            if (supplier.id == id) {
                std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name 
                          << ", Contact: " << supplier.contact << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found." << std::endl;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addItem(1, "Laptop", 10, 999.99);
    inventory.addItem(2, "Mouse", 50, 25.5);
    inventory.addSupplier(1, "Tech Corp", "123-456-7890");
    inventory.addSupplier(2, "Gadgets Ltd", "987-654-3210");

    inventory.displayItems();
    inventory.displaySuppliers();

    inventory.updateItem(1, "Gaming Laptop", 5, 1299.99);
    inventory.searchItem(1);

    inventory.deleteItem(2);
    inventory.displayItems();

    inventory.updateSupplier(2, "Gadgets Unlimited", "987-654-0000");
    inventory.searchSupplier(2);

    inventory.deleteSupplier(1);
    inventory.displaySuppliers();

    return 0;
}