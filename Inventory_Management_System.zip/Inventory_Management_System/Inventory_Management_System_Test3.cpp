#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    Item(int itemId, const std::string& itemName, int itemQuantity)
        : id(itemId), name(itemName), quantity(itemQuantity) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    Supplier(int supplierId, const std::string& supplierName, const std::string& supplierContact)
        : id(supplierId), name(supplierName), contact(supplierContact) {}
};

class InventoryManagementSystem {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    Item* findItemById(int id) {
        for (auto& item : items)
            if (item.id == id)
                return &item;
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for (auto& supplier : suppliers)
            if (supplier.id == id)
                return &supplier;
        return nullptr;
    }
    
public:
    void addItem(int id, const std::string& name, int quantity) {
        if (!findItemById(id))
            items.emplace_back(id, name, quantity);
    }

    void addSupplier(int id, const std::string& name, const std::string& contact) {
        if (!findSupplierById(id))
            suppliers.emplace_back(id, name, contact);
    }

    void deleteItem(int id) {
        items.erase(std::remove_if(items.begin(), items.end(),
            [id](const Item& item) { return item.id == id; }), items.end());
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(),
            [id](const Supplier& supplier) { return supplier.id == id; }), suppliers.end());
    }

    void updateItem(int id, const std::string& name, int quantity) {
        Item* item = findItemById(id);
        if (item) {
            item->name = name;
            item->quantity = quantity;
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    Item* searchItem(int id) {
        return findItemById(id);
    }

    Supplier* searchSupplier(int id) {
        return findSupplierById(id);
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "Item ID: " << item.id << ", Name: " << item.name 
                      << ", Quantity: " << item.quantity << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem(1, "Widget", 100);
    ims.addSupplier(1, "Supplier A", "123-456-7890");
    ims.displayItems();
    ims.displaySuppliers();
    return 0;
}