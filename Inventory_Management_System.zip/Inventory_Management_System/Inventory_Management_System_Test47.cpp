#include <iostream>
#include <vector>
#include <string>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;

    Item(int i, std::string n, int q, double p) : id(i), name(n), quantity(q), price(p) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int i, std::string n, std::string c) : id(i), name(n), contact(c) {}
};

class InventorySystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    Item* findItemById(int id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

public:
    void addItem(int id, std::string name, int quantity, double price) {
        items.push_back(Item(id, name, quantity, price));
    }
    
    void deleteItem(int id) {
        items.erase(remove_if(items.begin(), items.end(), [id](Item& item) { return item.id == id; }), items.end());
    }

    void updateItem(int id, std::string name, int quantity, double price) {
        Item* item = findItemById(id);
        if (item != nullptr) {
            item->name = name;
            item->quantity = quantity;
            item->price = price;
        }
    }

    void searchItem(int id) {
        Item* item = findItemById(id);
        if (item != nullptr) {
            std::cout << "Item found: ID=" << item->id << ", Name=" << item->name << ", Quantity=" << item->quantity << ", Price=" << item->price << std::endl;
        } else {
            std::cout << "Item not found" << std::endl;
        }
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "ID=" << item.id << ", Name=" << item.name << ", Quantity=" << item.quantity << ", Price=" << item.price << std::endl;
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        suppliers.erase(remove_if(suppliers.begin(), suppliers.end(), [id](Supplier& supplier) { return supplier.id == id; }), suppliers.end());
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier != nullptr) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void searchSupplier(int id) {
        Supplier* supplier = findSupplierById(id);
        if (supplier != nullptr) {
            std::cout << "Supplier found: ID=" << supplier->id << ", Name=" << supplier->name << ", Contact=" << supplier->contact << std::endl;
        } else {
            std::cout << "Supplier not found" << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID=" << supplier.id << ", Name=" << supplier.name << ", Contact=" << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    
    system.addItem(1, "Laptop", 10, 999.99);
    system.addItem(2, "Smartphone", 20, 699.99);
    system.displayItems();

    system.updateItem(1, "Laptop Pro", 8, 1299.99);
    system.searchItem(1);

    system.addSupplier(1, "ABC Supplies", "123-456-789");
    system.addSupplier(2, "XYZ Ltd.", "987-654-321");
    system.displaySuppliers();

    system.updateSupplier(2, "XYZ Corp.", "987-654-000");
    system.searchSupplier(2);

    return 0;
}