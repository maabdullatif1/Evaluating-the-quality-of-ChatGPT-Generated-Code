#include <iostream>
#include <string>
#include <vector>

class Item {
public:
    int id;
    std::string name;
    int quantity;
    double price;
    Item(int id, std::string name, int quantity, double price)
        : id(id), name(name), quantity(quantity), price(price) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    Supplier(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(Item item) {
        items.push_back(item);
    }

    void deleteItem(int id) {
        for(auto it = items.begin(); it != items.end(); ++it) {
            if(it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, std::string name, int quantity, double price) {
        for (auto &item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    Item* searchItem(int id) {
        for (auto &item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for (const auto &item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name 
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
        }
    }

    void addSupplier(Supplier supplier) {
        suppliers.push_back(supplier);
    }

    void deleteSupplier(int id) {
        for(auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if(it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem(Item(1, "Laptop", 10, 999.99));
    ims.addItem(Item(2, "Mouse", 50, 19.99));
    ims.addSupplier(Supplier(1, "TechSupplier", "123-456-7890"));
    ims.addSupplier(Supplier(2, "GadgetPro", "987-654-3210"));

    ims.displayItems();
    ims.displaySuppliers();

    ims.updateItem(1, "Gaming Laptop", 8, 1199.99);
    ims.updateSupplier(2, "GadgetPro", "contact@gadgetpro.com");

    ims.displayItems();
    ims.displaySuppliers();

    ims.deleteItem(2);
    ims.deleteSupplier(1);

    ims.displayItems();
    ims.displaySuppliers();

    return 0;
}