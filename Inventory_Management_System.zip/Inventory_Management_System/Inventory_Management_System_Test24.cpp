#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Item {
    int id;
    string name;
    int quantity;
    double price;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

class InventorySystem {
    vector<Item> items;
    vector<Supplier> suppliers;
    int item_id_counter = 0;
    int supplier_id_counter = 0;

public:
    void addItem(string name, int quantity, double price) {
        Item newItem;
        newItem.id = ++item_id_counter;
        newItem.name = name;
        newItem.quantity = quantity;
        newItem.price = price;
        items.push_back(newItem);
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, string name, int quantity, double price) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    Item* searchItem(int id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for (const auto& item : items) {
            cout << "ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity << ", Price: $" << item.price << endl;
        }
    }

    void addSupplier(string name, string contact) {
        Supplier newSupplier;
        newSupplier.id = ++supplier_id_counter;
        newSupplier.name = name;
        newSupplier.contact = contact;
        suppliers.push_back(newSupplier);
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }
    
    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addItem("Apple", 50, 0.5);
    system.addItem("Banana", 100, 0.3);
    system.addSupplier("Supplier A", "123-456-7890");
    system.addSupplier("Supplier B", "098-765-4321");
    system.displayItems();
    system.displaySuppliers();

    cout << "Updating item 1..." << endl;
    system.updateItem(1, "Green Apple", 60, 0.55);
    system.displayItems();

    cout << "Deleting supplier 2..." << endl;
    system.deleteSupplier(2);
    system.displaySuppliers();

    return 0;
}