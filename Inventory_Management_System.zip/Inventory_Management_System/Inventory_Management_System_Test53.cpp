#include <iostream>
#include <string>
#include <vector>

class Supplier {
public:
    int supplierId;
    std::string name;
    std::string contact;
    Supplier(int id, const std::string &name, const std::string &contact) 
        : supplierId(id), name(name), contact(contact) {}
};

class Item {
public:
    int itemId;
    std::string name;
    int quantity;
    Supplier supplier;
    Item(int id, const std::string &name, int qty, const Supplier &supp) 
        : itemId(id), name(name), quantity(qty), supplier(supp) {}
};

class InventoryManagement {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addSupplier(int id, const std::string &name, const std::string &contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void addItem(int id, const std::string &name, int quantity, int supplierId) {
        for (const auto &supp : suppliers) {
            if (supp.supplierId == supplierId) {
                items.push_back(Item(id, name, quantity, supp));
                break;
            }
        }
    }

    void deleteItem(int itemId) {
        items.erase(std::remove_if(items.begin(), items.end(),
                     [&itemId](const Item &item) { return item.itemId == itemId; }),
                     items.end());
    }

    void deleteSupplier(int supplierId) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(),
                       [&supplierId](const Supplier &supp) { return supp.supplierId == supplierId; }),
                       suppliers.end());

        items.erase(std::remove_if(items.begin(), items.end(),
                     [&supplierId](const Item &item) { return item.supplier.supplierId == supplierId; }),
                     items.end());
    }

    void updateItem(int itemId, const std::string &name, int quantity, int supplierId) {
        for (auto &item : items) {
            if (item.itemId == itemId) {
                item.name = name;
                item.quantity = quantity;
                for (const auto &supp : suppliers) {
                    if (supp.supplierId == supplierId) {
                        item.supplier = supp;
                        break;
                    }
                }
            }
        }
    }

    void displayItems() {
        for (const auto &item : items) {
            std::cout << "Item ID: " << item.itemId << ", Name: " << item.name
                      << ", Quantity: " << item.quantity << ", Supplier: " << item.supplier.name << '\n';
        }
    }

    void displaySuppliers() {
        for (const auto &supp : suppliers) {
            std::cout << "Supplier ID: " << supp.supplierId << ", Name: " << supp.name
                      << ", Contact: " << supp.contact << '\n';
        }
    }

    void searchItem(int itemId) {
        for (const auto &item : items) {
            if (item.itemId == itemId) {
                std::cout << "Item found: " << "ID: " << item.itemId
                          << ", Name: " << item.name << ", Quantity: " << item.quantity
                          << ", Supplier: " << item.supplier.name << '\n';
                return;
            }
        }
        std::cout << "Item not found\n";
    }

    void searchSupplier(int supplierId) {
        for (const auto &supp : suppliers) {
            if (supp.supplierId == supplierId) {
                std::cout << "Supplier found: " << "ID: " << supp.supplierId
                          << ", Name: " << supp.name << ", Contact: " << supp.contact << '\n';
                return;
            }
        }
        std::cout << "Supplier not found\n";
    }
};

int main() {
    InventoryManagement inv;

    inv.addSupplier(1, "Supplier A", "123-456-7890");
    inv.addSupplier(2, "Supplier B", "098-765-4321");

    inv.addItem(101, "Item 1", 50, 1);
    inv.addItem(102, "Item 2", 30, 2);
    
    inv.displayItems();
    inv.displaySuppliers();
    
    inv.searchItem(101);
    inv.searchSupplier(1);
    
    inv.updateItem(101, "Updated Item 1", 60, 2);
    
    inv.deleteItem(102);
    inv.deleteSupplier(1);
    
    inv.displayItems();
    inv.displaySuppliers();
    
    return 0;
}