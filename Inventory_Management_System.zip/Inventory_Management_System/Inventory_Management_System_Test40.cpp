#include <iostream>
#include <string>

struct Item {
    int id;
    std::string name;
    int quantity;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventoryManagementSystem {
    Item items[100];
    Supplier suppliers[100];
    int itemCount;
    int supplierCount;

public:
    InventoryManagementSystem() : itemCount(0), supplierCount(0) {}

    void addItem(int id, const std::string& name, int quantity, double price) {
        items[itemCount++] = {id, name, quantity, price};
    }

    void deleteItem(int id) {
        for (int i = 0; i < itemCount; ++i) {
            if (items[i].id == id) {
                for (int j = i; j < itemCount - 1; ++j) {
                    items[j] = items[j + 1];
                }
                --itemCount;
                break;
            }
        }
    }

    void updateItem(int id, const std::string& name, int quantity, double price) {
        for (int i = 0; i < itemCount; ++i) {
            if (items[i].id == id) {
                items[i].name = name;
                items[i].quantity = quantity;
                items[i].price = price;
                break;
            }
        }
    }

    Item* searchItem(int id) {
        for (int i = 0; i < itemCount; ++i) {
            if (items[i].id == id) return &items[i];
        }
        return nullptr;
    }

    void displayItems() {
        for (int i = 0; i < itemCount; ++i) {
            std::cout << "ID: " << items[i].id << ", Name: " << items[i].name
                      << ", Quantity: " << items[i].quantity << ", Price: $" 
                      << items[i].price << std::endl;
        }
    }

    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers[supplierCount++] = {id, name, contact};
    }

    void deleteSupplier(int id) {
        for (int i = 0; i < supplierCount; ++i) {
            if (suppliers[i].id == id) {
                for (int j = i; j < supplierCount - 1; ++j) {
                    suppliers[j] = suppliers[j + 1];
                }
                --supplierCount;
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (int i = 0; i < supplierCount; ++i) {
            if (suppliers[i].id == id) {
                suppliers[i].name = name;
                suppliers[i].contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (int i = 0; i < supplierCount; ++i) {
            if (suppliers[i].id == id) return &suppliers[i];
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (int i = 0; i < supplierCount; ++i) {
            std::cout << "ID: " << suppliers[i].id << ", Name: " << suppliers[i].name
                      << ", Contact: " << suppliers[i].contact << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem(1, "Widget", 50, 2.99);
    ims.addItem(2, "Gadget", 30, 5.99);
    ims.addSupplier(1, "Supplier A", "123-456-7890");
    ims.addSupplier(2, "Supplier B", "987-654-3210");
    ims.displayItems();
    ims.displaySuppliers();
    return 0;
}