#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int supplierID;
    std::string name;
    std::string contactInfo;

    Supplier(int id, std::string n, std::string contact) : supplierID(id), name(n), contactInfo(contact) {}
};

class Item {
public:
    int itemID;
    std::string itemName;
    int quantity;
    double price;
    int supplierID;

    Item(int id, std::string name, int qty, double p, int sid) 
        : itemID(id), itemName(name), quantity(qty), price(p), supplierID(sid) {}
};

class InventoryManagement {
private:
    std::vector<Supplier> suppliers;
    std::vector<Item> items;

public:
    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->supplierID == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void addItem(int id, std::string name, int qty, double price, int supplierID) {
        items.push_back(Item(id, name, qty, price, supplierID));
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->itemID == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, std::string name, int qty, double price, int supplierID) {
        for (auto &item : items) {
            if (item.itemID == id) {
                item.itemName = name;
                item.quantity = qty;
                item.price = price;
                item.supplierID = supplierID;
                break;
            }
        }
    }

    void searchItem(int id) {
        for (const auto &item : items) {
            if (item.itemID == id) {
                std::cout << "Item ID: " << item.itemID << ", Name: " << item.itemName
                          << ", Quantity: " << item.quantity << ", Price: " << item.price
                          << ", Supplier ID: " << item.supplierID << std::endl;
                return;
            }
        }
        std::cout << "Item not found!" << std::endl;
    }

    void displayItems() {
        for (const auto &item : items) {
            std::cout << "Item ID: " << item.itemID << ", Name: " << item.itemName
                      << ", Quantity: " << item.quantity << ", Price: " << item.price
                      << ", Supplier ID: " << item.supplierID << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.supplierID << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contactInfo << std::endl;
        }
    }
};

int main() {
    InventoryManagement im;

    im.addSupplier(1, "Supplier A", "contactA@mail.com");
    im.addSupplier(2, "Supplier B", "contactB@mail.com");

    im.addItem(101, "Item 1", 50, 19.99, 1);
    im.addItem(102, "Item 2", 30, 9.99, 2);

    im.displaySuppliers();
    std::cout << std::endl;
    im.displayItems();
    std::cout << std::endl;

    im.searchItem(101);
    std::cout << std::endl;

    im.updateItem(101, "Updated Item 1", 100, 29.99, 2);
    im.displayItems();
    std::cout << std::endl;

    im.deleteItem(102);
    im.displayItems();
    std::cout << std::endl;

    im.deleteSupplier(2);
    im.displaySuppliers();

    return 0;
}