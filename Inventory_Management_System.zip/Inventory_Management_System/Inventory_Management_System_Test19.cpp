#include <iostream>
#include <vector>
#include <string>

struct Item {
    int itemID;
    std::string name;
    int quantity;
    double price;
};

struct Supplier {
    int supplierID;
    std::string name;
    std::string contact;
};

class InventoryManagementSystem {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    int findItemIndex(int itemID) {
        for (int i = 0; i < items.size(); ++i) {
            if (items[i].itemID == itemID)
                return i;
        }
        return -1;
    }

    int findSupplierIndex(int supplierID) {
        for (int i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].supplierID == supplierID)
                return i;
        }
        return -1;
    }

public:
    void addItem(int itemID, std::string name, int quantity, double price) {
        if (findItemIndex(itemID) == -1) {
            items.push_back({itemID, name, quantity, price});
        }
    }

    void addSupplier(int supplierID, std::string name, std::string contact) {
        if (findSupplierIndex(supplierID) == -1) {
            suppliers.push_back({supplierID, name, contact});
        }
    }

    void deleteItem(int itemID) {
        int index = findItemIndex(itemID);
        if (index != -1) {
            items.erase(items.begin() + index);
        }
    }

    void deleteSupplier(int supplierID) {
        int index = findSupplierIndex(supplierID);
        if (index != -1) {
            suppliers.erase(suppliers.begin() + index);
        }
    }

    void updateItem(int itemID, std::string name, int quantity, double price) {
        int index = findItemIndex(itemID);
        if (index != -1) {
            items[index] = {itemID, name, quantity, price};
        }
    }

    void updateSupplier(int supplierID, std::string name, std::string contact) {
        int index = findSupplierIndex(supplierID);
        if (index != -1) {
            suppliers[index] = {supplierID, name, contact};
        }
    }

    void searchItem(int itemID) {
        int index = findItemIndex(itemID);
        if (index != -1) {
            std::cout << items[index].itemID << " " << items[index].name << " " 
                      << items[index].quantity << " " << items[index].price << "\n";
        } else {
            std::cout << "Item not found\n";
        }
    }

    void searchSupplier(int supplierID) {
        int index = findSupplierIndex(supplierID);
        if (index != -1) {
            std::cout << suppliers[index].supplierID << " " << suppliers[index].name << " " 
                      << suppliers[index].contact << "\n";
        } else {
            std::cout << "Supplier not found\n";
        }
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << item.itemID << " " << item.name << " " << item.quantity << " " << item.price << "\n";
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << supplier.supplierID << " " << supplier.name << " " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem(1, "Item1", 100, 10.99);
    ims.addSupplier(1, "Supplier1", "123-456-7890");
    ims.displayItems();
    ims.displaySuppliers();
    return 0;
}