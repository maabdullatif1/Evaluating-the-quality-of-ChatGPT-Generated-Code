#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Supplier {
public:
    int id;
    string name;
    string contact;

    Supplier(int id, string name, string contact) : id(id), name(name), contact(contact) {}
};

class Item {
public:
    int id;
    string name;
    int quantity;
    double price;
    Supplier supplier;

    Item(int id, string name, int quantity, double price, Supplier supplier) 
    : id(id), name(name), quantity(quantity), price(price), supplier(supplier) {}
};

class InventorySystem {
    vector<Item> items;
    vector<Supplier> suppliers;

public:
    void addSupplier(Supplier supplier) {
        suppliers.push_back(supplier);
    }

    void addItem(Item item) {
        items.push_back(item);
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void updateItem(int id, string name, int quantity, double price) {
        for (auto &item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
                return;
            }
        }
        cout << "Supplier not found." << endl;
    }

    void searchItem(int id) {
        for (auto &item : items) {
            if (item.id == id) {
                cout << "Item ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity << ", Price: " << item.price 
                     << ", Supplier: " << item.supplier.name << endl;
                return;
            }
        }
        cout << "Item not found." << endl;
    }

    void displaySuppliers() {
        for (auto &supplier : suppliers) {
            cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }

    void displayItems() {
        for (auto &item : items) {
            cout << "Item ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity << ", Price: " << item.price 
                 << ", Supplier: " << item.supplier.name << endl;
        }
    }
};

int main() {
    InventorySystem system;

    Supplier supplier1(1, "Supplier A", "1234567890");
    Supplier supplier2(2, "Supplier B", "0987654321");

    system.addSupplier(supplier1);
    system.addSupplier(supplier2);

    Item item1(1, "Item A", 100, 9.99, supplier1);
    Item item2(2, "Item B", 50, 19.99, supplier2);

    system.addItem(item1);
    system.addItem(item2);

    system.displaySuppliers();
    system.displayItems();

    return 0;
}