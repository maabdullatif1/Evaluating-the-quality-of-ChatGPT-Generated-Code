#include <iostream>
#include <vector>
#include <string>

struct Item {
    int id;
    std::string name;
    int quantity;
    float price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventorySystem {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

public:
    void addItem(int id, std::string name, int quantity, float price) {
        items.push_back({id, name, quantity, price});
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, std::string name, int quantity, float price) {
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                break;
            }
        }
    }

    void searchItem(int id) {
        for (const auto& item : items) {
            if (item.id == id) {
                std::cout << "Item found: " << item.name << ", Quantity: " 
                          << item.quantity << ", Price: " << item.price << std::endl;
                return;
            }
        }
        std::cout << "Item not found." << std::endl;
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back({id, name, contact});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                std::cout << "Supplier found: " << supplier.name << ", Contact: " 
                          << supplier.contact << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found." << std::endl;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    
    system.addItem(1, "Widget", 100, 50.5);
    system.addItem(2, "Gadget", 200, 75.0);

    system.displayItems();

    system.updateItem(1, "Widget", 150, 55.5);
    system.searchItem(1);

    system.deleteItem(2);
    system.displayItems();

    system.addSupplier(1, "Supplier A", "contactA@example.com");
    system.addSupplier(2, "Supplier B", "contactB@example.com");

    system.displaySuppliers();

    system.updateSupplier(1, "Supplier A Updated", "newcontactA@example.com");
    system.searchSupplier(1);

    system.deleteSupplier(2);
    system.displaySuppliers();

    return 0;
}