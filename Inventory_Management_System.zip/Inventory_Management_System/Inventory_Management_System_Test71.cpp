#include <iostream>
#include <vector>
#include <string>

struct Item {
    int id;
    std::string name;
    int quantity;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventoryManagement {
private:
    std::vector<Item> items;
    std::vector<Supplier> suppliers;

    int findItemById(int id) {
        for (int i = 0; i < items.size(); ++i) {
            if (items[i].id == id) {
                return i;
            }
        }
        return -1;
    }

    int findSupplierById(int id) {
        for (int i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addItem(int id, const std::string& name, int quantity, double price) {
        Item item = {id, name, quantity, price};
        items.push_back(item);
    }

    void removeItem(int id) {
        int index = findItemById(id);
        if (index != -1) {
            items.erase(items.begin() + index);
        }
    }

    void updateItem(int id, const std::string& name, int quantity, double price) {
        int index = findItemById(id);
        if (index != -1) {
            items[index] = {id, name, quantity, price};
        }
    }

    Item searchItem(int id) {
        int index = findItemById(id);
        if (index != -1) {
            return items[index];
        }
        return {-1, "", 0, 0.0};
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name
                      << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
        }
    }

    void addSupplier(int id, const std::string& name, const std::string& contact) {
        Supplier supplier = {id, name, contact};
        suppliers.push_back(supplier);
    }

    void removeSupplier(int id) {
        int index = findSupplierById(id);
        if (index != -1) {
            suppliers.erase(suppliers.begin() + index);
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        int index = findSupplierById(id);
        if (index != -1) {
            suppliers[index] = {id, name, contact};
        }
    }

    Supplier searchSupplier(int id) {
        int index = findSupplierById(id);
        if (index != -1) {
            return suppliers[index];
        }
        return {-1, "", ""};
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagement inv;

    inv.addItem(1, "Laptop", 10, 999.99);
    inv.addItem(2, "Mouse", 25, 19.99);
    inv.displayItems();

    inv.addSupplier(101, "Tech Corp", "tech.corp@example.com");
    inv.addSupplier(102, "Office Supplies Co", "office.supplies@example.com");
    inv.displaySuppliers();

    inv.updateItem(2, "Wireless Mouse", 30, 29.99);
    inv.displayItems();

    inv.removeItem(1);
    inv.displayItems();

    inv.updateSupplier(101, "Tech Corporation", "contact@techcorp.com");
    inv.displaySuppliers();

    inv.removeSupplier(102);
    inv.displaySuppliers();

    return 0;
}