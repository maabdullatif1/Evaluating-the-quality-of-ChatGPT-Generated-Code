#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, const std::string& name, const std::string& contact)
        : id(id), name(name), contact(contact) {}
};

class Item {
public:
    int id;
    std::string name;
    int quantity;
    float price;
    Supplier* supplier;

    Item(int id, const std::string& name, int quantity, float price, Supplier* supplier)
        : id(id), name(name), quantity(quantity), price(price), supplier(supplier) {}
};

class InventoryManagementSystem {
    std::vector<Supplier> suppliers;
    std::vector<Item> items;

public:
    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.emplace_back(id, name, contact);
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }

    void addItem(int id, const std::string& name, int quantity, float price, int supplierId) {
        Supplier* supplier = searchSupplier(supplierId);
        if (supplier != nullptr) {
            items.emplace_back(id, name, quantity, price, supplier);
        }
    }

    void deleteItem(int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                items.erase(it);
                break;
            }
        }
    }

    void updateItem(int id, const std::string& name, int quantity, float price, int supplierId) {
        Supplier* supplier = searchSupplier(supplierId);
        for (auto& item : items) {
            if (item.id == id) {
                item.name = name;
                item.quantity = quantity;
                item.price = price;
                item.supplier = supplier;
                break;
            }
        }
    }

    Item* searchItem(int id) {
        for (auto& item : items) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity
                      << ", Price: " << item.price << ", Supplier: " << item.supplier->name << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier(1, "Supplier A", "123456789");
    ims.addSupplier(2, "Supplier B", "987654321");

    ims.addItem(1, "Item A", 50, 10.5, 1);
    ims.addItem(2, "Item B", 70, 20.0, 2);

    ims.displaySuppliers();
    ims.displayItems();

    return 0;
}