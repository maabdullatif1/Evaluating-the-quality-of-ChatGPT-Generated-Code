#include <iostream>
#include <vector>
#include <string>

struct Item {
    int id;
    std::string name;
    int quantity;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventoryManagementSystem {
    std::vector<Item> items;
    std::vector<Supplier> suppliers;
    
    int findItemById(int id) {
        for (size_t i = 0; i < items.size(); ++i) {
            if (items[i].id == id) return i;
        }
        return -1;
    }

    int findSupplierById(int id) {
        for (size_t i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].id == id) return i;
        }
        return -1;
    }

public:
    void addItem(int id, std::string name, int quantity, double price) {
        if (findItemById(id) == -1) {
            items.push_back({id, name, quantity, price});
        }
    }

    void deleteItem(int id) {
        int index = findItemById(id);
        if (index != -1) {
            items.erase(items.begin() + index);
        }
    }

    void updateItem(int id, std::string name, int quantity, double price) {
        int index = findItemById(id);
        if (index != -1) {
            items[index] = {id, name, quantity, price};
        }
    }

    void searchItem(int id) {
        int index = findItemById(id);
        if (index != -1) {
            std::cout << "Item found: " << items[index].name << ", Quantity: " << items[index].quantity << ", Price: " << items[index].price << std::endl;
        } else {
            std::cout << "Item not found" << std::endl;
        }
    }

    void displayItems() {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity << ", Price: " << item.price << std::endl;
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        if (findSupplierById(id) == -1) {
            suppliers.push_back({id, name, contact});
        }
    }

    void deleteSupplier(int id) {
        int index = findSupplierById(id);
        if (index != -1) {
            suppliers.erase(suppliers.begin() + index);
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        int index = findSupplierById(id);
        if (index != -1) {
            suppliers[index] = {id, name, contact};
        }
    }

    void searchSupplier(int id) {
        int index = findSupplierById(id);
        if (index != -1) {
            std::cout << "Supplier found: " << suppliers[index].name << ", Contact: " << suppliers[index].contact << std::endl;
        } else {
            std::cout << "Supplier not found" << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addItem(1, "Widget", 100, 2.50);
    ims.addSupplier(1, "Supplier A", "123-456-7890");
    ims.displayItems();
    ims.displaySuppliers();
    ims.searchItem(1);
    ims.searchSupplier(1);
    ims.updateItem(1, "Widget", 150, 2.75);
    ims.updateSupplier(1, "Supplier A Updated", "098-765-4321");
    ims.displayItems();
    ims.displaySuppliers();
    ims.deleteItem(1);
    ims.deleteSupplier(1);
    ims.displayItems();
    ims.displaySuppliers();
    return 0;
}