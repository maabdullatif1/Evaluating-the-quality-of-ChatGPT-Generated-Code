#include <iostream>
#include <vector>
#include <string>

struct Entity {
    int id;
    std::string name;
    double electricityProducedOrConsumed;
};

class GridSystem {
private:
    std::vector<Entity> customers;
    std::vector<Entity> producers;

    Entity* searchEntity(std::vector<Entity>& list, int id) {
        for (auto& entity : list) {
            if (entity.id == id) return &entity;
        }
        return nullptr;
    }

    std::vector<Entity>::iterator findEntityIterator(std::vector<Entity>& list, int id) {
        for (auto it = list.begin(); it != list.end(); ++it) {
            if (it->id == id) return it;
        }
        return list.end();
    }

    void displayEntity(const Entity& entity) const {
        std::cout << "ID: " << entity.id
                  << ", Name: " << entity.name
                  << ", Electricity: " << entity.electricityProducedOrConsumed << "\n";
    }

    void displayEntities(const std::vector<Entity>& list) const {
        for (const auto& entity : list) {
            displayEntity(entity);
        }
    }

public:
    void addCustomer(int id, const std::string& name, double electricityConsumed) {
        customers.push_back({id, name, electricityConsumed});
    }

    void addProducer(int id, const std::string& name, double electricityProduced) {
        producers.push_back({id, name, electricityProduced});
    }

    void updateCustomer(int id, const std::string& name, double electricityConsumed) {
        Entity* entity = searchEntity(customers, id);
        if (entity) {
            entity->name = name;
            entity->electricityProducedOrConsumed = electricityConsumed;
        }
    }

    void updateProducer(int id, const std::string& name, double electricityProduced) {
        Entity* entity = searchEntity(producers, id);
        if (entity) {
            entity->name = name;
            entity->electricityProducedOrConsumed = electricityProduced;
        }
    }

    void deleteCustomer(int id) {
        auto it = findEntityIterator(customers, id);
        if (it != customers.end()) {
            customers.erase(it);
        }
    }

    void deleteProducer(int id) {
        auto it = findEntityIterator(producers, id);
        if (it != producers.end()) {
            producers.erase(it);
        }
    }

    void displayCustomers() const {
        displayEntities(customers);
    }

    void displayProducers() const {
        displayEntities(producers);
    }

    void searchAndDisplayCustomer(int id) const {
        const Entity* entity = searchEntity(customers, id);
        if (entity) {
            displayEntity(*entity);
        }
    }

    void searchAndDisplayProducer(int id) const {
        const Entity* entity = searchEntity(producers, id);
        if (entity) {
            displayEntity(*entity);
        }
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer(1, "Customer A", 100.0);
    grid.addProducer(1, "Producer A", 500.0);
    grid.displayCustomers();
    grid.displayProducers();
    grid.updateCustomer(1, "Customer A Updated", 150.0);
    grid.searchAndDisplayCustomer(1);
    grid.deleteProducer(1);
    grid.displayProducers();
    return 0;
}