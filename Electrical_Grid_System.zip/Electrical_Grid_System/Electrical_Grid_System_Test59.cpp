#include <iostream>
#include <string>
#include <vector>

class Entity {
public:
    int id;
    std::string name;
    double consumptionOrProduction;

    Entity(int id, const std::string& name, double consumptionOrProduction) 
        : id(id), name(name), consumptionOrProduction(consumptionOrProduction) {}
};

class GridSystem {
private:
    std::vector<Entity> customers;
    std::vector<Entity> producers;

    Entity* findEntity(std::vector<Entity>& entities, int id) {
        for (auto& entity : entities) {
            if (entity.id == id) {
                return &entity;
            }
        }
        return nullptr;
    }

public:
    void addCustomer(int id, const std::string& name, double consumption) {
        customers.emplace_back(id, name, consumption);
    }

    void addProducer(int id, const std::string& name, double production) {
        producers.emplace_back(id, name, production);
    }

    void deleteCustomer(int id) {
        customers.erase(std::remove_if(customers.begin(), customers.end(),
                                       [id](const Entity& c) { return c.id == id; }),
                        customers.end());
    }

    void deleteProducer(int id) {
        producers.erase(std::remove_if(producers.begin(), producers.end(),
                                       [id](const Entity& p) { return p.id == id; }),
                        producers.end());
    }

    void updateCustomer(int id, const std::string& name, double consumption) {
        Entity* customer = findEntity(customers, id);
        if (customer) {
            customer->name = name;
            customer->consumptionOrProduction = consumption;
        }
    }

    void updateProducer(int id, const std::string& name, double production) {
        Entity* producer = findEntity(producers, id);
        if (producer) {
            producer->name = name;
            producer->consumptionOrProduction = production;
        }
    }

    Entity* searchCustomer(int id) {
        return findEntity(customers, id);
    }

    Entity* searchProducer(int id) {
        return findEntity(producers, id);
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name
                      << ", Consumption: " << customer.consumptionOrProduction << "\n";
        }
    }

    void displayProducers() {
        for (const auto& producer : producers) {
            std::cout << "ID: " << producer.id << ", Name: " << producer.name
                      << ", Production: " << producer.consumptionOrProduction << "\n";
        }
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer(1, "Customer A", 100.5);
    grid.addProducer(1, "Producer X", 250.75);
    grid.displayCustomers();
    grid.displayProducers();
    grid.updateCustomer(1, "Customer A+", 150.0);
    grid.updateProducer(1, "Producer X+", 300.0);
    grid.displayCustomers();
    grid.displayProducers();
    grid.deleteCustomer(1);
    grid.deleteProducer(1);
    grid.displayCustomers();
    grid.displayProducers();
    return 0;
}