#include <iostream>
#include <vector>
#include <string>

class Participant {
protected:
    int id;
    std::string name;
    std::string contact;
public:
    Participant(int i, std::string n, std::string c) : id(i), name(n), contact(c) {}
    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getContact() const { return contact; }
    void setName(std::string n) { name = n; }
    void setContact(std::string c) { contact = c; }
    virtual void display() const = 0;
};

class Customer : public Participant {
    double usage;
public:
    Customer(int i, std::string n, std::string c, double u) : Participant(i, n, c), usage(u) {}
    double getUsage() const { return usage; }
    void setUsage(double u) { usage = u; }
    void display() const override {
        std::cout << "Customer ID: " << id << ", Name: " << name << ", Contact: " << contact << ", Usage: " << usage << std::endl;
    }
};

class Producer : public Participant {
    double production;
public:
    Producer(int i, std::string n, std::string c, double p) : Participant(i, n, c), production(p) {}
    double getProduction() const { return production; }
    void setProduction(double p) { production = p; }
    void display() const override {
        std::cout << "Producer ID: " << id << ", Name: " << name << ", Contact: " << contact << ", Production: " << production << std::endl;
    }
};

class GridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;
public:
    void addCustomer(int id, std::string name, std::string contact, double usage) {
        customers.push_back(Customer(id, name, contact, usage));
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == id) {
                customers.erase(it);
                return;
            }
        }
    }
    
    void updateCustomer(int id, std::string name, std::string contact, double usage) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                customer.setName(name);
                customer.setContact(contact);
                customer.setUsage(usage);
                return;
            }
        }
    }
    
    void searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                customer.display();
                return;
            }
        }
    }
    
    void displayCustomers() {
        for (auto& customer : customers) {
            customer.display();
        }
    }

    void addProducer(int id, std::string name, std::string contact, double production) {
        producers.push_back(Producer(id, name, contact, production));
    }
    
    void deleteProducer(int id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getId() == id) {
                producers.erase(it);
                return;
            }
        }
    }
    
    void updateProducer(int id, std::string name, std::string contact, double production) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                producer.setName(name);
                producer.setContact(contact);
                producer.setProduction(production);
                return;
            }
        }
    }
    
    void searchProducer(int id) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                producer.display();
                return;
            }
        }
    }
    
    void displayProducers() {
        for (auto& producer : producers) {
            producer.display();
        }
    }
};

int main() {
    GridSystem system;
    system.addCustomer(1, "Alice", "123-456-7890", 500);
    system.addProducer(1, "PowerCo", "987-654-3210", 1000);
    system.displayCustomers();
    system.displayProducers();
    return 0;
}