#include <iostream>
#include <vector>
#include <string>

class Person {
protected:
    int id;
    std::string name;
    std::string address;
public:
    Person(int id, std::string name, std::string address) : id(id), name(name), address(address) {}
    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getAddress() const { return address; }
    void setName(const std::string& newName) { name = newName; }
    void setAddress(const std::string& newAddress) { address = newAddress; }
    virtual void display() const = 0;
};

class Customer : public Person {
public:
    Customer(int id, std::string name, std::string address) : Person(id, name, address) {}
    void display() const override {
        std::cout << "Customer ID: " << id << ", Name: " << name << ", Address: " << address << std::endl;
    }
};

class Producer : public Person {
public:
    Producer(int id, std::string name, std::string address) : Person(id, name, address) {}
    void display() const override {
        std::cout << "Producer ID: " << id << ", Name: " << name << ", Address: " << address << std::endl;
    }
};

template <class T>
class GridSystem {
    std::vector<T> people;
public:
    void addPerson(T person) {
        people.push_back(person);
    }
    void deletePersonById(int id) {
        for (auto it = people.begin(); it != people.end(); ++it) {
            if (it->getId() == id) {
                people.erase(it);
                return;
            }
        }
    }
    T* searchPersonById(int id) {
        for (auto& person : people) {
            if (person.getId() == id) {
                return &person;
            }
        }
        return nullptr;
    }
    void updatePerson(int id, const std::string& newName, const std::string& newAddress) {
        T* person = searchPersonById(id);
        if (person) {
            person->setName(newName);
            person->setAddress(newAddress);
        }
    }
    void displayAll() const {
        for (const auto& person : people) {
            person.display();
        }
    }
};

int main() {
    GridSystem<Customer> customerSystem;
    GridSystem<Producer> producerSystem;

    customerSystem.addPerson(Customer(1, "John Doe", "123 Elm St"));
    producerSystem.addPerson(Producer(1, "Solar Corp", "456 Renewable Rd"));

    std::cout << "All Customers:" << std::endl;
    customerSystem.displayAll();

    std::cout << "All Producers:" << std::endl;
    producerSystem.displayAll();

    Customer* customer = customerSystem.searchPersonById(1);
    if (customer) {
        customerSystem.updatePerson(1, "John Smith", "789 Oak St");
    }

    std::cout << "Updated Customers:" << std::endl;
    customerSystem.displayAll();

    producerSystem.deletePersonById(1);

    std::cout << "Producers after deletion:" << std::endl;
    producerSystem.displayAll();

    return 0;
}