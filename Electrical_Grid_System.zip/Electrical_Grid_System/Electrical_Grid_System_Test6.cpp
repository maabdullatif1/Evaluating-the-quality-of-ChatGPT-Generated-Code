#include <iostream>
#include <vector>
#include <string>

class Entity {
public:
    std::string name;
    std::string id;

    Entity(const std::string& name, const std::string& id) : name(name), id(id) {}
};

class Customer : public Entity {
public:
    double consumedEnergy;

    Customer(const std::string& name, const std::string& id, double consumedEnergy)
        : Entity(name, id), consumedEnergy(consumedEnergy) {}
};

class Producer : public Entity {
public:
    double producedEnergy;

    Producer(const std::string& name, const std::string& id, double producedEnergy)
        : Entity(name, id), producedEnergy(producedEnergy) {}
};

class ElectricalGridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;

public:
    void addCustomer(const std::string& name, const std::string& id, double consumedEnergy) {
        customers.emplace_back(name, id, consumedEnergy);
    }

    void addProducer(const std::string& name, const std::string& id, double producedEnergy) {
        producers.emplace_back(name, id, producedEnergy);
    }

    void deleteCustomer(const std::string& id) {
        auto it = std::remove_if(customers.begin(), customers.end(), [&](const Customer& c) {
            return c.id == id;
        });
        customers.erase(it, customers.end());
    }

    void deleteProducer(const std::string& id) {
        auto it = std::remove_if(producers.begin(), producers.end(), [&](const Producer& p) {
            return p.id == id;
        });
        producers.erase(it, producers.end());
    }

    void updateCustomer(const std::string& id, const std::string& newName, double newConsumedEnergy) {
        for (auto& c : customers) {
            if (c.id == id) {
                c.name = newName;
                c.consumedEnergy = newConsumedEnergy;
                break;
            }
        }
    }

    void updateProducer(const std::string& id, const std::string& newName, double newProducedEnergy) {
        for (auto& p : producers) {
            if (p.id == id) {
                p.name = newName;
                p.producedEnergy = newProducedEnergy;
                break;
            }
        }
    }

    Customer* searchCustomer(const std::string& id) {
        for (auto& c : customers) {
            if (c.id == id) {
                return &c;
            }
        }
        return nullptr;
    }

    Producer* searchProducer(const std::string& id) {
        for (auto& p : producers) {
            if (p.id == id) {
                return &p;
            }
        }
        return nullptr;
    }

    void displayCustomers() const {
        for (const auto& c : customers) {
            std::cout << "Customer Name: " << c.name << ", ID: " << c.id << ", Consumed Energy: " << c.consumedEnergy << "\n";
        }
    }

    void displayProducers() const {
        for (const auto& p : producers) {
            std::cout << "Producer Name: " << p.name << ", ID: " << p.id << ", Produced Energy: " << p.producedEnergy << "\n";
        }
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addCustomer("John Doe", "C001", 1200.5);
    grid.addProducer("Solar Inc.", "P001", 3000.0);
    grid.displayCustomers();
    grid.displayProducers();
    return 0;
}