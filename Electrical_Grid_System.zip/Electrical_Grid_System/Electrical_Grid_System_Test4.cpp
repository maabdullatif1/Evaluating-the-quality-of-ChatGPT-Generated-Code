#include <iostream>
#include <vector>
#include <string>

class Entity {
public:
    std::string name;
    std::string address;
    virtual void display() = 0;
    virtual ~Entity() {}
};

class Customer : public Entity {
public:
    int customerID;
    double usage;

    Customer(int id, const std::string& customerName, const std::string& customerAddress, double customerUsage) {
        customerID = id;
        name = customerName;
        address = customerAddress;
        usage = customerUsage;
    }

    void display() override {
        std::cout << "Customer ID: " << customerID << ", Name: " << name
                  << ", Address: " << address << ", Usage: " << usage << std::endl;
    }
};

class Producer : public Entity {
public:
    int producerID;
    double productionCapacity;

    Producer(int id, const std::string& producerName, const std::string& producerAddress, double capacity) {
        producerID = id;
        name = producerName;
        address = producerAddress;
        productionCapacity = capacity;
    }

    void display() override {
        std::cout << "Producer ID: " << producerID << ", Name: " << name
                  << ", Address: " << address << ", Capacity: " << productionCapacity << std::endl;
    }
};

class ElectricalGridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;

public:
    void addCustomer(int id, const std::string& name, const std::string& address, double usage) {
        customers.emplace_back(id, name, address, usage);
    }

    void addProducer(int id, const std::string& name, const std::string& address, double capacity) {
        producers.emplace_back(id, name, address, capacity);
    }

    bool deleteCustomer(int id) {
        for(auto it = customers.begin(); it != customers.end(); ++it) {
            if(it->customerID == id) {
                customers.erase(it);
                return true;
            }
        }
        return false;
    }

    bool deleteProducer(int id) {
        for(auto it = producers.begin(); it != producers.end(); ++it) {
            if(it->producerID == id) {
                producers.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateCustomer(int id, const std::string& name, const std::string& address, double usage) {
        for(auto& customer : customers) {
            if(customer.customerID == id) {
                customer.name = name;
                customer.address = address;
                customer.usage = usage;
                return true;
            }
        }
        return false;
    }

    bool updateProducer(int id, const std::string& name, const std::string& address, double capacity) {
        for(auto& producer : producers) {
            if(producer.producerID == id) {
                producer.name = name;
                producer.address = address;
                producer.productionCapacity = capacity;
                return true;
            }
        }
        return false;
    }

    Customer* searchCustomer(int id) {
        for(auto& customer : customers) {
            if(customer.customerID == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Producer* searchProducer(int id) {
        for(auto& producer : producers) {
            if(producer.producerID == id) {
                return &producer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for(const auto& customer : customers) {
            customer.display();
        }
    }

    void displayProducers() {
        for(const auto& producer : producers) {
            producer.display();
        }
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addCustomer(1, "John Doe", "123 Elm St", 350.75);
    grid.addProducer(1, "Solar Inc", "456 Solar Rd", 5000.50);
    grid.displayCustomers();
    grid.displayProducers();

    return 0;
}