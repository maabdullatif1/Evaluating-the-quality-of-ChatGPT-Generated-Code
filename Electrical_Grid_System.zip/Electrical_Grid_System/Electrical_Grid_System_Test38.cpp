#include <iostream>
#include <vector>
#include <string>

struct Entity {
    std::string id;
    std::string name;
    std::string type;
    double power;
};

class ElectricalGridSystem {
    std::vector<Entity> entities;

public:
    void addEntity(const std::string& id, const std::string& name, const std::string& type, double power) {
        Entity entity = {id, name, type, power};
        entities.push_back(entity);
    }

    void deleteEntity(const std::string& id) {
        for (auto it = entities.begin(); it != entities.end(); ++it) {
            if (it->id == id) {
                entities.erase(it);
                break;
            }
        }
    }

    void updateEntity(const std::string& id, const std::string& name, const std::string& type, double power) {
        for (auto& entity : entities) {
            if (entity.id == id) {
                entity.name = name;
                entity.type = type;
                entity.power = power;
            }
        }
    }

    Entity* searchEntity(const std::string& id) {
        for (auto& entity : entities) {
            if (entity.id == id) {
                return &entity;
            }
        }
        return nullptr;
    }

    void displayEntities() {
        for (const auto& entity : entities) {
            std::cout << "ID: " << entity.id
                      << ", Name: " << entity.name
                      << ", Type: " << entity.type
                      << ", Power: " << entity.power << std::endl;
        }
    }
};

int main() {
    ElectricalGridSystem system;
    system.addEntity("1", "CustA", "Customer", 100.5);
    system.addEntity("2", "ProdA", "Producer", 200.0);
    system.displayEntities();

    system.updateEntity("1", "CustB", "Customer", 150.0);
    system.displayEntities();

    system.deleteEntity("2");
    system.displayEntities();

    Entity* found = system.searchEntity("1");
    if (found) {
        std::cout << "Found entity with ID 1: " << found->name << std::endl;
    }

    return 0;
}