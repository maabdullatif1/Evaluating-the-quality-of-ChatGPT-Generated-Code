#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Customer {
    int id;
    string name;
    double consumption;
};

struct Producer {
    int id;
    string name;
    double production;
};

class ElectricalGridSystem {
private:
    vector<Customer> customers;
    vector<Producer> producers;
    int nextCustomerId = 1;
    int nextProducerId = 1;

    template<typename T>
    void displayEntity(const T& entity) {
        cout << "ID: " << entity.id << " Name: " << entity.name;
        cout << " Value: " << (std::is_same<T, Customer>::value ? entity.consumption : entity.production) << endl;
    }

public:
    void addCustomer(const string& name, double consumption) {
        customers.push_back({nextCustomerId++, name, consumption});
    }

    void addProducer(const string& name, double production) {
        producers.push_back({nextProducerId++, name, production});
    }

    void deleteCustomer(int id) {
        customers.erase(remove_if(customers.begin(), customers.end(),
                    [id](Customer& c) { return c.id == id; }), customers.end());
    }

    void deleteProducer(int id) {
        producers.erase(remove_if(producers.begin(), producers.end(),
                    [id](Producer& p) { return p.id == id; }), producers.end());
    }

    void updateCustomer(int id, const string& name, double consumption) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.consumption = consumption;
                break;
            }
        }
    }

    void updateProducer(int id, const string& name, double production) {
        for (auto& producer : producers) {
            if (producer.id == id) {
                producer.name = name;
                producer.production = production;
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Producer* searchProducer(int id) {
        for (auto& producer : producers) {
            if (producer.id == id) {
                return &producer;
            }
        }
        return nullptr;
    }

    void displayAllCustomers() {
        for (const auto& customer : customers) {
            displayEntity(customer);
        }
    }

    void displayAllProducers() {
        for (const auto& producer : producers) {
            displayEntity(producer);
        }
    }
};

int main() {
    ElectricalGridSystem grid;

    grid.addCustomer("Alice", 350.75);
    grid.addCustomer("Bob", 225.50);
    grid.displayAllCustomers();

    grid.addProducer("Solar Farm", 1200.00);
    grid.addProducer("Wind Farm", 850.45);
    grid.displayAllProducers();

    grid.updateCustomer(1, "Alice Smith", 375.00);
    grid.displayAllCustomers();

    grid.deleteProducer(2);
    grid.displayAllProducers();

    Customer* customer = grid.searchCustomer(1);
    if (customer) cout << "Found Customer - ID: " << customer->id << " Name: " << customer->name << endl;

    grid.displayAllCustomers();
    grid.displayAllProducers();

    return 0;
}