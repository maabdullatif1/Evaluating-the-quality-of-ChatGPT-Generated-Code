#include <iostream>
#include <vector>
#include <string>

struct Entity {
    std::string id;
    std::string name;
    std::string address;
    std::string type;
};

class GridSystem {
private:
    std::vector<Entity> entities;

    int findEntityIndex(const std::string& id) {
        for (size_t i = 0; i < entities.size(); ++i) {
            if (entities[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addEntity(const std::string& id, const std::string& name, const std::string& address, const std::string& type) {
        if (findEntityIndex(id) == -1) {
            entities.push_back({id, name, address, type});
        }
    }

    void deleteEntity(const std::string& id) {
        int index = findEntityIndex(id);
        if (index != -1) {
            entities.erase(entities.begin() + index);
        }
    }

    void updateEntity(const std::string& id, const std::string& name, const std::string& address, const std::string& type) {
        int index = findEntityIndex(id);
        if (index != -1) {
            entities[index] = {id, name, address, type};
        }
    }

    Entity* searchEntity(const std::string& id) {
        int index = findEntityIndex(id);
        return index != -1 ? &entities[index] : nullptr;
    }

    void displayEntities() {
        for (const auto& entity : entities) {
            std::cout << "ID: " << entity.id << ", Name: " << entity.name << ", Address: " << entity.address << ", Type: " << entity.type << std::endl;
        }
    }
};

int main() {
    GridSystem grid;
    grid.addEntity("1", "Alice", "123 Main St", "Customer");
    grid.addEntity("2", "Bob", "456 Elm St", "Producer");
    grid.updateEntity("1", "Alice", "789 Maple St", "Customer");
    grid.displayEntities();
    grid.deleteEntity("2");
    grid.displayEntities();
    Entity* entity = grid.searchEntity("1");
    if (entity != nullptr) {
        std::cout << "Found entity: " << entity->name << std::endl;
    }
    return 0;
}