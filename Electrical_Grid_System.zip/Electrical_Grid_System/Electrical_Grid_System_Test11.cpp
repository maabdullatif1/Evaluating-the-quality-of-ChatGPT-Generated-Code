#include <iostream>
#include <string>
#include <vector>

class Entity {
public:
    virtual std::string getInfo() const = 0;
};

class Customer : public Entity {
private:
    std::string name;
    std::string address;
    int id;
public:
    Customer(int id, std::string name, std::string address) : id(id), name(name), address(address) {}
    int getId() const { return id; }
    std::string getInfo() const override { return "Customer ID: " + std::to_string(id) + ", Name: " + name + ", Address: " + address; }
    void update(std::string newName, std::string newAddress) { name = newName; address = newAddress; }
};

class Producer : public Entity {
private:
    std::string name;
    int capacity;
    int id;
public:
    Producer(int id, std::string name, int capacity) : id(id), name(name), capacity(capacity) {}
    int getId() const { return id; }
    std::string getInfo() const override { return "Producer ID: " + std::to_string(id) + ", Name: " + name + ", Capacity: " + std::to_string(capacity); }
    void update(std::string newName, int newCapacity) { name = newName; capacity = newCapacity; }
};

class ElectricalGridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;
public:
    void addCustomer(int id, std::string name, std::string address) { customers.emplace_back(id, name, address); }
    void addProducer(int id, std::string name, int capacity) { producers.emplace_back(id, name, capacity); }
    void deleteCustomer(int id) { customers.erase(std::remove_if(customers.begin(), customers.end(), [&](const Customer& c) { return c.getId() == id; }), customers.end()); }
    void deleteProducer(int id) { producers.erase(std::remove_if(producers.begin(), producers.end(), [&](const Producer& p) { return p.getId() == id; }), producers.end()); }
    void updateCustomer(int id, std::string newName, std::string newAddress) {
        auto it = std::find_if(customers.begin(), customers.end(), [&](const Customer& c) { return c.getId() == id; });
        if (it != customers.end()) it->update(newName, newAddress);
    }
    void updateProducer(int id, std::string newName, int newCapacity) {
        auto it = std::find_if(producers.begin(), producers.end(), [&](const Producer& p) { return p.getId() == id; });
        if (it != producers.end()) it->update(newName, newCapacity);
    }
    Entity* searchCustomer(int id) {
        auto it = std::find_if(customers.begin(), customers.end(), [&](const Customer& c) { return c.getId() == id; });
        return it != customers.end() ? &(*it) : nullptr;
    }
    Entity* searchProducer(int id) {
        auto it = std::find_if(producers.begin(), producers.end(), [&](const Producer& p) { return p.getId() == id; });
        return it != producers.end() ? &(*it) : nullptr;
    }
    void display() {
        for (const auto& customer : customers) std::cout << customer.getInfo() << std::endl;
        for (const auto& producer : producers) std::cout << producer.getInfo() << std::endl;
    }
};

int main() {
    ElectricalGridSystem system;
    system.addCustomer(1, "John Doe", "123 Elm St.");
    system.addProducer(1, "Solar Inc.", 500);
    system.display();
    system.updateCustomer(1, "John Smith", "456 Oak St.");
    system.display();
    Entity* customer = system.searchCustomer(1);
    if (customer) std::cout << customer->getInfo() << std::endl;
    system.deleteCustomer(1);
    system.display();
    return 0;
}