#include <iostream>
#include <string>

struct Customer {
    int id;
    std::string name;
    double consumption;
    Customer* next;
};

struct Producer {
    int id;
    std::string name;
    double generation;
    Producer* next;
};

class ElectricalGrid {
    Customer* customerHead;
    Producer* producerHead;

public:
    ElectricalGrid() : customerHead(nullptr), producerHead(nullptr) {}

    void addCustomer(int id, const std::string& name, double consumption) {
        Customer* newCustomer = new Customer{id, name, consumption, customerHead};
        customerHead = newCustomer;
    }

    void deleteCustomer(int id) {
        Customer* current = customerHead;
        Customer* prev = nullptr;
        while (current != nullptr && current->id != id) {
            prev = current;
            current = current->next;
        }
        if (current != nullptr) {
            if (prev != nullptr)
                prev->next = current->next;
            else
                customerHead = current->next;
            delete current;
        }
    }

    void updateCustomer(int id, const std::string& name, double consumption) {
        Customer* current = customerHead;
        while (current != nullptr && current->id != id) {
            current = current->next;
        }
        if (current != nullptr) {
            current->name = name;
            current->consumption = consumption;
        }
    }

    Customer* searchCustomer(int id) {
        Customer* current = customerHead;
        while (current != nullptr && current->id != id) {
            current = current->next;
        }
        return current;
    }

    void displayCustomers() {
        Customer* current = customerHead;
        while (current != nullptr) {
            std::cout << "Customer ID: " << current->id 
                      << ", Name: " << current->name 
                      << ", Consumption: " << current->consumption << '\n';
            current = current->next;
        }
    }

    void addProducer(int id, const std::string& name, double generation) {
        Producer* newProducer = new Producer{id, name, generation, producerHead};
        producerHead = newProducer;
    }

    void deleteProducer(int id) {
        Producer* current = producerHead;
        Producer* prev = nullptr;
        while (current != nullptr && current->id != id) {
            prev = current;
            current = current->next;
        }
        if (current != nullptr) {
            if (prev != nullptr)
                prev->next = current->next;
            else
                producerHead = current->next;
            delete current;
        }
    }

    void updateProducer(int id, const std::string& name, double generation) {
        Producer* current = producerHead;
        while (current != nullptr && current->id != id) {
            current = current->next;
        }
        if (current != nullptr) {
            current->name = name;
            current->generation = generation;
        }
    }

    Producer* searchProducer(int id) {
        Producer* current = producerHead;
        while (current != nullptr && current->id != id) {
            current = current->next;
        }
        return current;
    }

    void displayProducers() {
        Producer* current = producerHead;
        while (current != nullptr) {
            std::cout << "Producer ID: " << current->id 
                      << ", Name: " << current->name 
                      << ", Generation: " << current->generation << '\n';
            current = current->next;
        }
    }
};

int main() {
    ElectricalGrid grid;
    grid.addCustomer(1, "Alice", 150.0);
    grid.addCustomer(2, "Bob", 200.0);
    grid.addProducer(1, "Plant1", 500.0);
    grid.addProducer(2, "Plant2", 300.0);
    grid.displayCustomers();
    grid.displayProducers();
    return 0;
}