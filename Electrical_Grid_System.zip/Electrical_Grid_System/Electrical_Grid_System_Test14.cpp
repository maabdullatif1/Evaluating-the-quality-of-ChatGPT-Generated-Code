#include <iostream>
#include <vector>
#include <string>

class Entity {
protected:
    std::string id;
    std::string name;
public:
    Entity(const std::string& id, const std::string& name) : id(id), name(name) {}
    std::string getId() { return id; }
    std::string getName() { return name; }
    void setName(const std::string& name) { this->name = name; }
};

class Customer : public Entity {
public:
    Customer(const std::string& id, const std::string& name) : Entity(id, name) {}
};

class Producer : public Entity {
public:
    Producer(const std::string& id, const std::string& name) : Entity(id, name) {}
};

class GridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;
    
    template<typename T>
    void displayEntities(const std::vector<T>& entities) {
        for (const T& entity : entities) {
            std::cout << "ID: " << entity.getId() << ", Name: " << entity.getName() << std::endl;
        }
    }
    
    template<typename T>
    typename std::vector<T>::iterator findEntity(std::vector<T>& entities, const std::string& id) {
        for (auto it = entities.begin(); it != entities.end(); ++it) {
            if (it->getId() == id) {
                return it;
            }
        }
        return entities.end();
    }
    
public:
    void addCustomer(const std::string& id, const std::string& name) {
        customers.emplace_back(id, name);
    }
    
    void deleteCustomer(const std::string& id) {
        auto it = findEntity(customers, id);
        if (it != customers.end()) {
            customers.erase(it);
        }
    }
    
    void updateCustomer(const std::string& id, const std::string& name) {
        auto it = findEntity(customers, id);
        if (it != customers.end()) {
            it->setName(name);
        }
    }
    
    void searchCustomer(const std::string& id) {
        auto it = findEntity(customers, id);
        if (it != customers.end()) {
            std::cout << "Customer found: ID: " << it->getId() << ", Name: " << it->getName() << std::endl;
        } else {
            std::cout << "Customer not found." << std::endl;
        }
    }
    
    void displayCustomers() {
        displayEntities(customers);
    }
    
    void addProducer(const std::string& id, const std::string& name) {
        producers.emplace_back(id, name);
    }
    
    void deleteProducer(const std::string& id) {
        auto it = findEntity(producers, id);
        if (it != producers.end()) {
            producers.erase(it);
        }
    }
    
    void updateProducer(const std::string& id, const std::string& name) {
        auto it = findEntity(producers, id);
        if (it != producers.end()) {
            it->setName(name);
        }
    }
    
    void searchProducer(const std::string& id) {
        auto it = findEntity(producers, id);
        if (it != producers.end()) {
            std::cout << "Producer found: ID: " << it->getId() << ", Name: " << it->getName() << std::endl;
        } else {
            std::cout << "Producer not found." << std::endl;
        }
    }
    
    void displayProducers() {
        displayEntities(producers);
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer("C1", "Alice");
    grid.addProducer("P1", "Solar Inc.");
    grid.displayCustomers();
    grid.displayProducers();
    grid.updateCustomer("C1", "Alice Johnson");
    grid.updateProducer("P1", "Solar Power Co.");
    grid.searchCustomer("C1");
    grid.searchProducer("P1");
    grid.deleteCustomer("C1");
    grid.deleteProducer("P1");
    grid.displayCustomers();
    grid.displayProducers();
    
    return 0;
}