#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    std::string name;
    std::string address;
    double consumption;

    Customer(const std::string& n, const std::string& a, double c)
        : name(n), address(a), consumption(c) {}
};

class Producer {
public:
    std::string name;
    std::string type;
    double production;

    Producer(const std::string& n, const std::string& t, double p)
        : name(n), type(t), production(p) {}
};

class GridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;

public:
    void addCustomer(const std::string& name, const std::string& address, double consumption) {
        customers.emplace_back(name, address, consumption);
    }

    void deleteCustomer(const std::string& name) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->name == name) {
                customers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(const std::string& name, const std::string& address, double consumption) {
        for (auto& c : customers) {
            if (c.name == name) {
                c.address = address;
                c.consumption = consumption;
                break;
            }
        }
    }

    Customer* searchCustomer(const std::string& name) {
        for (auto& c : customers) {
            if (c.name == name) {
                return &c;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& c : customers) {
            std::cout << "Name: " << c.name << ", Address: " << c.address
                      << ", Consumption: " << c.consumption << " kWh" << std::endl;
        }
    }

    void addProducer(const std::string& name, const std::string& type, double production) {
        producers.emplace_back(name, type, production);
    }

    void deleteProducer(const std::string& name) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->name == name) {
                producers.erase(it);
                break;
            }
        }
    }

    void updateProducer(const std::string& name, const std::string& type, double production) {
        for (auto& p : producers) {
            if (p.name == name) {
                p.type = type;
                p.production = production;
                break;
            }
        }
    }

    Producer* searchProducer(const std::string& name) {
        for (auto& p : producers) {
            if (p.name == name) {
                return &p;
            }
        }
        return nullptr;
    }

    void displayProducers() {
        for (const auto& p : producers) {
            std::cout << "Name: " << p.name << ", Type: " << p.type
                      << ", Production: " << p.production << " MW" << std::endl;
        }
    }
};

int main() {
    GridSystem grid;

    grid.addCustomer("John Doe", "123 Elm St", 350.5);
    grid.addCustomer("Jane Smith", "456 Oak St", 200.0);
    
    grid.addProducer("Solar Plant", "Solar", 500.0);
    grid.addProducer("Wind Farm", "Wind", 800.0);

    grid.displayCustomers();
    grid.displayProducers();

    return 0;
}