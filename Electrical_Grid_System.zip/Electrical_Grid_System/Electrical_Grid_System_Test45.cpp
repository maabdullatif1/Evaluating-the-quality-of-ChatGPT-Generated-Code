#include <iostream>
#include <string>

class Entity {
protected:
    std::string id, name;
public:
    Entity(std::string id, std::string name) : id(id), name(name) {}
    virtual void display() = 0;
    std::string getId() { return id; }
};

class Customer : public Entity {
    double consumption;
public:
    Customer(std::string id, std::string name, double consumption)
        : Entity(id, name), consumption(consumption) {}
    void updateConsumption(double cons) { consumption = cons; }
    double getConsumption() { return consumption; }
    void display() override {
        std::cout << "Customer ID: " << id << ", Name: " << name << ", Consumption: " << consumption << std::endl;
    }
};

class Producer : public Entity {
    double production;
public:
    Producer(std::string id, std::string name, double production)
        : Entity(id, name), production(production) {}
    void updateProduction(double prod) { production = prod; }
    double getProduction() { return production; }
    void display() override {
        std::cout << "Producer ID: " << id << ", Name: " << name << ", Production: " << production << std::endl;
    }
};

class GridSystem {
    Customer* customers[100];
    Producer* producers[100];
    int custCount, prodCount;
public:
    GridSystem() : custCount(0), prodCount(0) {}
    void addCustomer(std::string id, std::string name, double consumption) {
        customers[custCount++] = new Customer(id, name, consumption);
    }
    void addProducer(std::string id, std::string name, double production) {
        producers[prodCount++] = new Producer(id, name, production);
    }
    void deleteCustomer(std::string id) {
        for (int i = 0; i < custCount; ++i) {
            if (customers[i]->getId() == id) {
                delete customers[i];
                for (int j = i; j < custCount - 1; ++j) {
                    customers[j] = customers[j + 1];
                }
                --custCount;
                break;
            }
        }
    }
    void deleteProducer(std::string id) {
        for (int i = 0; i < prodCount; ++i) {
            if (producers[i]->getId() == id) {
                delete producers[i];
                for (int j = i; j < prodCount - 1; ++j) {
                    producers[j] = producers[j + 1];
                }
                --prodCount;
                break;
            }
        }
    }
    void updateCustomer(std::string id, double consumption) {
        for (int i = 0; i < custCount; ++i) {
            if (customers[i]->getId() == id) {
                customers[i]->updateConsumption(consumption);
                break;
            }
        }
    }
    void updateProducer(std::string id, double production) {
        for (int i = 0; i < prodCount; ++i) {
            if (producers[i]->getId() == id) {
                producers[i]->updateProduction(production);
                break;
            }
        }
    }
    Entity* searchCustomer(std::string id) {
        for (int i = 0; i < custCount; ++i) {
            if (customers[i]->getId() == id) return customers[i];
        }
        return nullptr;
    }
    Entity* searchProducer(std::string id) {
        for (int i = 0; i < prodCount; ++i) {
            if (producers[i]->getId() == id) return producers[i];
        }
        return nullptr;
    }
    void displayCustomers() {
        for (int i = 0; i < custCount; ++i) customers[i]->display();
    }
    void displayProducers() {
        for (int i = 0; i < prodCount; ++i) producers[i]->display();
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer("C001", "Alice", 120.5);
    grid.addProducer("P001", "WindFarm", 1000.0);
    grid.displayCustomers();
    grid.displayProducers();
    grid.updateCustomer("C001", 130.0);
    grid.updateProducer("P001", 1050.0);
    grid.displayCustomers();
    grid.displayProducers();
    grid.deleteCustomer("C001");
    grid.deleteProducer("P001");
    grid.displayCustomers();
    grid.displayProducers();
    return 0;
}