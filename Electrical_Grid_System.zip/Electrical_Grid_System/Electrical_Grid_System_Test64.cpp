#include <iostream>
#include <vector>
#include <string>

class Entity {
protected:
    int id;
    std::string name;
public:
    Entity(int id, const std::string &name) : id(id), name(name) {}
    int getId() const { return id; }
    std::string getName() const { return name; }
    virtual void display() const = 0;
};

class Customer : public Entity {
    double consumption;
public:
    Customer(int id, const std::string &name, double consumption)
        : Entity(id, name), consumption(consumption) {}
    void display() const override {
        std::cout << "Customer ID: " << id << ", Name: " << name
                  << ", Consumption: " << consumption << " kWh\n";
    }
    void updateConsumption(double newConsumption) { consumption = newConsumption; }
};

class Producer : public Entity {
    double production;
public:
    Producer(int id, const std::string &name, double production)
        : Entity(id, name), production(production) {}
    void display() const override {
        std::cout << "Producer ID: " << id << ", Name: " << name
                  << ", Production: " << production << " kWh\n";
    }
    void updateProduction(double newProduction) { production = newProduction; }
};

class GridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;

    template<typename T>
    void removeEntity(std::vector<T>& entities, int id) {
        for (auto it = entities.begin(); it != entities.end(); ++it) {
            if (it->getId() == id) {
                entities.erase(it);
                return;
            }
        }
        std::cout << "Entity ID " << id << " not found.\n";
    }

    template<typename T>
    T* searchEntity(std::vector<T>& entities, int id) {
        for (auto& entity : entities) {
            if (entity.getId() == id) {
                return &entity;
            }
        }
        std::cout << "Entity ID " << id << " not found.\n";
        return nullptr;
    }

public:
    void addCustomer(int id, const std::string &name, double consumption) {
        customers.emplace_back(id, name, consumption);
    }

    void addProducer(int id, const std::string &name, double production) {
        producers.emplace_back(id, name, production);
    }

    void deleteCustomer(int id) {
        removeEntity(customers, id);
    }
    
    void deleteProducer(int id) {
        removeEntity(producers, id);
    }

    void updateCustomer(int id, double newConsumption) {
        Customer* customer = searchEntity(customers, id);
        if (customer) {
            customer->updateConsumption(newConsumption);
        }
    }

    void updateProducer(int id, double newProduction) {
        Producer* producer = searchEntity(producers, id);
        if (producer) {
            producer->updateProduction(newProduction);
        }
    }

    void searchCustomer(int id) {
        Customer* customer = searchEntity(customers, id);
        if (customer) {
            customer->display();
        }
    }

    void searchProducer(int id) {
        Producer* producer = searchEntity(producers, id);
        if (producer) {
            producer->display();
        }
    }

    void displayCustomers() const {
        for (const auto& customer : customers) {
            customer.display();
        }
    }

    void displayProducers() const {
        for (const auto& producer : producers) {
            producer.display();
        }
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer(1, "Alice", 150.5);
    grid.addProducer(1, "Plant A", 5000);
    grid.displayCustomers();
    grid.displayProducers();
    grid.updateCustomer(1, 200);
    grid.searchCustomer(1);
    grid.deleteProducer(1);
    grid.displayProducers();
    return 0;
}