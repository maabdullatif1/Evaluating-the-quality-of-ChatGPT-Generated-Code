#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Entity {
protected:
    string id;
    string name;
public:
    Entity(string id, string name) : id(id), name(name) {}
    string getId() { return id; }
    string getName() { return name; }
    void setName(string newName) { name = newName; }
};

class Customer : public Entity {
public:
    Customer(string id, string name) : Entity(id, name) {}
};

class Producer : public Entity {
public:
    Producer(string id, string name) : Entity(id, name) {}
};

class ElectricalGridSystem {
private:
    vector<Customer> customers;
    vector<Producer> producers;
public:
    void addCustomer(string id, string name) {
        customers.push_back(Customer(id, name));
    }
    
    void addProducer(string id, string name) {
        producers.push_back(Producer(id, name));
    }
    
    void deleteCustomer(string id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void deleteProducer(string id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getId() == id) {
                producers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(string id, string newName) {
        for (auto &customer : customers) {
            if (customer.getId() == id) {
                customer.setName(newName);
                break;
            }
        }
    }
    
    void updateProducer(string id, string newName) {
        for (auto &producer : producers) {
            if (producer.getId() == id) {
                producer.setName(newName);
                break;
            }
        }
    }
    
    Customer* searchCustomer(string id) {
        for (auto &customer : customers) {
            if (customer.getId() == id) {
                return &customer;
            }
        }
        return nullptr;
    }
    
    Producer* searchProducer(string id) {
        for (auto &producer : producers) {
            if (producer.getId() == id) {
                return &producer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            cout << "Customer ID: " << customer.getId() << ", Name: " << customer.getName() << endl;
        }
    }

    void displayProducers() {
        for (const auto &producer : producers) {
            cout << "Producer ID: " << producer.getId() << ", Name: " << producer.getName() << endl;
        }
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addCustomer("C001", "John Doe");
    grid.addProducer("P001", "Electric Co.");

    grid.displayCustomers();
    grid.displayProducers();

    grid.updateCustomer("C001", "Jane Doe");
    grid.updateProducer("P001", "New Electric Co.");

    grid.displayCustomers();
    grid.displayProducers();

    grid.deleteCustomer("C001");
    grid.deleteProducer("P001");

    grid.displayCustomers();
    grid.displayProducers();

    return 0;
}