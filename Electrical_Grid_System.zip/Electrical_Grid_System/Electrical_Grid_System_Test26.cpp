#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    std::string id;
    std::string name;
    Person(const std::string& id, const std::string& name) : id(id), name(name) {}
};

class Customer : public Person {
public:
    double consumption;
    Customer(const std::string& id, const std::string& name, double consumption)
        : Person(id, name), consumption(consumption) {}
};

class Producer : public Person {
public:
    double production;
    Producer(const std::string& id, const std::string& name, double production)
        : Person(id, name), production(production) {}
};

class ElectricalGridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;
public:
    void addCustomer(const std::string& id, const std::string& name, double consumption) {
        customers.push_back(Customer(id, name, consumption));
    }

    void addProducer(const std::string& id, const std::string& name, double production) {
        producers.push_back(Producer(id, name, production));
    }

    void deleteCustomer(const std::string& id) {
        customers.erase(remove_if(customers.begin(), customers.end(),
            [&id](const Customer& c) { return c.id == id; }), customers.end());
    }

    void deleteProducer(const std::string& id) {
        producers.erase(remove_if(producers.begin(), producers.end(),
            [&id](const Producer& p) { return p.id == id; }), producers.end());
    }

    void updateCustomer(const std::string& id, const std::string& newName, double newConsumption) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = newName;
                customer.consumption = newConsumption;
                break;
            }
        }
    }

    void updateProducer(const std::string& id, const std::string& newName, double newProduction) {
        for (auto& producer : producers) {
            if (producer.id == id) {
                producer.name = newName;
                producer.production = newProduction;
                break;
            }
        }
    }

    Customer* searchCustomer(const std::string& id) {
        for (auto& customer : customers) {
            if (customer.id == id) return &customer;
        }
        return nullptr;
    }

    Producer* searchProducer(const std::string& id) {
        for (auto& producer : producers) {
            if (producer.id == id) return &producer;
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id 
                      << ", Name: " << customer.name 
                      << ", Consumption: " << customer.consumption << " kWh" << std::endl;
        }
    }

    void displayProducers() {
        for (const auto& producer : producers) {
            std::cout << "ID: " << producer.id 
                      << ", Name: " << producer.name 
                      << ", Production: " << producer.production << " kWh" << std::endl;
        }
    }
};

int main() {
    ElectricalGridSystem egs;
    egs.addCustomer("C001", "Alice", 1200.5);
    egs.addProducer("P001", "Solar Plant", 5000.0);
    egs.displayCustomers();
    egs.displayProducers();
    egs.updateCustomer("C001", "Alice Smith", 1300.0);
    egs.displayCustomers();
    egs.deleteCustomer("C001");
    egs.displayCustomers();
    return 0;
}