#include <iostream>
#include <vector>
#include <string>

struct Entity {
    int id;
    std::string name;
    double power;
};

class ElectricalGridSystem {
private:
    std::vector<Entity> customers;
    std::vector<Entity> producers;

    Entity* findEntity(std::vector<Entity>& entities, int id) {
        for (auto& entity : entities) {
            if (entity.id == id) {
                return &entity;
            }
        }
        return nullptr;
    }
    
    void displayEntities(const std::vector<Entity>& entities) {
        for (const auto& entity : entities) {
            std::cout << "ID: " << entity.id << ", Name: " << entity.name << ", Power: " << entity.power << std::endl;
        }
    }

public:
    void addCustomer(int id, const std::string& name, double power) {
        customers.push_back({id, name, power});
    }

    void addProducer(int id, const std::string& name, double power) {
        producers.push_back({id, name, power});
    }

    void deleteCustomer(int id) {
        customers.erase(std::remove_if(customers.begin(), customers.end(),
                     [id](const Entity& c) { return c.id == id; }), customers.end());
    }

    void deleteProducer(int id) {
        producers.erase(std::remove_if(producers.begin(), producers.end(),
                     [id](const Entity& p) { return p.id == id; }), producers.end());
    }

    void updateCustomer(int id, const std::string& name, double power) {
        Entity* customer = findEntity(customers, id);
        if (customer) {
            customer->name = name;
            customer->power = power;
        }
    }

    void updateProducer(int id, const std::string& name, double power) {
        Entity* producer = findEntity(producers, id);
        if (producer) {
            producer->name = name;
            producer->power = power;
        }
    }

    Entity* searchCustomer(int id) {
        return findEntity(customers, id);
    }

    Entity* searchProducer(int id) {
        return findEntity(producers, id);
    }

    void displayCustomers() {
        displayEntities(customers);
    }

    void displayProducers() {
        displayEntities(producers);
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addCustomer(1, "John Doe", 1500.0);
    grid.addProducer(1, "Solar Plant", 3000.0);
    grid.displayCustomers();
    grid.displayProducers();
    return 0;
}