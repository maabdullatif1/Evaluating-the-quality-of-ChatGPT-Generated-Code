#include <iostream>
#include <vector>
#include <string>

class Participant {
protected:
    std::string name;
    std::string id;
    double powerRating;
public:
    Participant(const std::string& name, const std::string& id, double powerRating)
        : name(name), id(id), powerRating(powerRating) {}

    std::string getName() const {
        return name;
    }

    std::string getId() const {
        return id;
    }

    double getPowerRating() const {
        return powerRating;
    }

    virtual void display() const = 0;
};

class Customer : public Participant {
public:
    Customer(const std::string& name, const std::string& id, double powerRating)
        : Participant(name, id, powerRating) {}

    void display() const override {
        std::cout << "Customer ID: " << id << ", Name: " << name << ", Consumption: " << powerRating << " kW\n";
    }
};

class Producer : public Participant {
public:
    Producer(const std::string& name, const std::string& id, double powerRating)
        : Participant(name, id, powerRating) {}

    void display() const override {
        std::cout << "Producer ID: " << id << ", Name: " << name << ", Generation: " << powerRating << " kW\n";
    }
};

class ElectricalGrid {
    std::vector<Customer> customers;
    std::vector<Producer> producers;
public:
    void addCustomer(const std::string& name, const std::string& id, double consumption) {
        customers.push_back(Customer(name, id, consumption));
    }

    void removeCustomer(const std::string& id) {
        customers.erase(std::remove_if(customers.begin(), customers.end(), [&](const Customer& c) { return c.getId() == id; }), customers.end());
    }

    void updateCustomer(const std::string& id, const std::string& name, double consumption) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                customer = Customer(name, id, consumption);
                break;
            }
        }
    }

    void searchCustomer(const std::string& id) const {
        for (const auto& customer : customers) {
            if (customer.getId() == id) {
                customer.display();
                return;
            }
        }
        std::cout << "Customer not found.\n";
    }

    void addProducer(const std::string& name, const std::string& id, double generation) {
        producers.push_back(Producer(name, id, generation));
    }

    void removeProducer(const std::string& id) {
        producers.erase(std::remove_if(producers.begin(), producers.end(), [&](const Producer& p) { return p.getId() == id; }), producers.end());
    }

    void updateProducer(const std::string& id, const std::string& name, double generation) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                producer = Producer(name, id, generation);
                break;
            }
        }
    }

    void searchProducer(const std::string& id) const {
        for (const auto& producer : producers) {
            if (producer.getId() == id) {
                producer.display();
                return;
            }
        }
        std::cout << "Producer not found.\n";
    }

    void displayAll() const {
        std::cout << "Customers:\n";
        for (const auto& customer : customers) {
            customer.display();
        }
        std::cout << "Producers:\n";
        for (const auto& producer : producers) {
            producer.display();
        }
    }
};

int main() {
    ElectricalGrid grid;
    grid.addCustomer("John Doe", "C001", 150.0);
    grid.addCustomer("Jane Smith", "C002", 200.0);
    grid.addProducer("Wind Energy Co.", "P001", 500.0);
    grid.addProducer("Solar Power Inc.", "P002", 300.0);

    grid.displayAll();

    grid.updateCustomer("C001", "Johnathan Doe", 180.0);
    grid.updateProducer("P001", "Wind Energy Group", 550.0);

    grid.searchCustomer("C001");
    grid.searchProducer("P002");

    grid.removeCustomer("C002");
    grid.removeProducer("P002");

    grid.displayAll();

    return 0;
}