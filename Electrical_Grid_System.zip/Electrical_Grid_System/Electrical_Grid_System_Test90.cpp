#include <iostream>
#include <vector>
#include <string>

class Entity {
public:
    std::string id;
    std::string name;
    Entity(const std::string& id, const std::string& name) : id(id), name(name) {}
    virtual void display() const = 0;
};

class Customer : public Entity {
public:
    double consumedEnergy;
    Customer(const std::string& id, const std::string& name, double consumedEnergy) 
        : Entity(id, name), consumedEnergy(consumedEnergy) {}
    void display() const override {
        std::cout << "Customer ID: " << id << ", Name: " << name 
                  << ", Consumed Energy: " << consumedEnergy << std::endl;
    }
};

class Producer : public Entity {
public:
    double producedEnergy;
    Producer(const std::string& id, const std::string& name, double producedEnergy) 
        : Entity(id, name), producedEnergy(producedEnergy) {}
    void display() const override {
        std::cout << "Producer ID: " << id << ", Name: " << name 
                  << ", Produced Energy: " << producedEnergy << std::endl;
    }
};

class GridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;

public:
    void addCustomer(const std::string& id, const std::string& name, double consumedEnergy) {
        customers.push_back(Customer(id, name, consumedEnergy));
    }

    void addProducer(const std::string& id, const std::string& name, double producedEnergy) {
        producers.push_back(Producer(id, name, producedEnergy));
    }

    void deleteCustomer(const std::string& id) {
        customers.erase(remove_if(customers.begin(), customers.end(), 
                        [&](const Customer& c){ return c.id == id; }), customers.end());
    }

    void deleteProducer(const std::string& id) {
        producers.erase(remove_if(producers.begin(), producers.end(), 
                        [&](const Producer& p){ return p.id == id; }), producers.end());
    }

    void updateCustomer(const std::string& id, const std::string& name, double consumedEnergy) {
        for (auto& c : customers) {
            if (c.id == id) {
                c.name = name;
                c.consumedEnergy = consumedEnergy;
            }
        }
    }

    void updateProducer(const std::string& id, const std::string& name, double producedEnergy) {
        for (auto& p : producers) {
            if (p.id == id) {
                p.name = name;
                p.producedEnergy = producedEnergy;
            }
        }
    }

    Customer* searchCustomer(const std::string& id) {
        for (auto& c : customers) {
            if (c.id == id) return &c;
        }
        return nullptr;
    }

    Producer* searchProducer(const std::string& id) {
        for (auto& p : producers) {
            if (p.id == id) return &p;
        }
        return nullptr;
    }

    void displayAllCustomers() const {
        for (const auto& c : customers) {
            c.display();
        }
    }

    void displayAllProducers() const {
        for (const auto& p : producers) {
            p.display();
        }
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer("C001", "Alice", 150.5);
    grid.addProducer("P001", "Generator Corp", 1000.0);

    grid.displayAllCustomers();
    grid.displayAllProducers();

    grid.updateCustomer("C001", "Alice Wonderland", 200.0);
    grid.updateProducer("P001", "Generator Corp Ltd", 1100.0);

    grid.displayAllCustomers();
    grid.displayAllProducers();

    grid.deleteCustomer("C001");
    grid.deleteProducer("P001");

    grid.displayAllCustomers();
    grid.displayAllProducers();

    return 0;
}