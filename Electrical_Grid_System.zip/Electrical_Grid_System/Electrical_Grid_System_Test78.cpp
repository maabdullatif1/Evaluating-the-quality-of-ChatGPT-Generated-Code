#include <iostream>
#include <vector>
#include <string>

class Entity {
protected:
    std::string id;
    std::string name;
public:
    Entity(std::string id, std::string name) : id(id), name(name) {}
    std::string getId() const { return id; }
    std::string getName() const { return name; }
    void setName(const std::string& newName) { name = newName; }
};

class Customer : public Entity {
public:
    Customer(std::string id, std::string name) : Entity(id, name) {}
};

class Producer : public Entity {
public:
    Producer(std::string id, std::string name) : Entity(id, name) {}
};

class ElectricalGridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;

    template<typename T>
    void displayEntities(const std::vector<T>& entities) const {
        for (const auto& entity : entities) {
            std::cout << "ID: " << entity.getId() << ", Name: " << entity.getName() << std::endl;
        }
    }

public:
    void addCustomer(const Customer& customer) {
        customers.push_back(customer);
    }

    void addProducer(const Producer& producer) {
        producers.push_back(producer);
    }

    bool deleteCustomer(const std::string& id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == id) {
                customers.erase(it);
                return true;
            }
        }
        return false;
    }

    bool deleteProducer(const std::string& id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getId() == id) {
                producers.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateCustomer(const std::string& id, const std::string& newName) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                customer.setName(newName);
                return true;
            }
        }
        return false;
    }

    bool updateProducer(const std::string& id, const std::string& newName) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                producer.setName(newName);
                return true;
            }
        }
        return false;
    }

    const Customer* searchCustomer(const std::string& id) const {
        for (const auto& customer : customers) {
            if (customer.getId() == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    const Producer* searchProducer(const std::string& id) const {
        for (const auto& producer : producers) {
            if (producer.getId() == id) {
                return &producer;
            }
        }
        return nullptr;
    }

    void displayCustomers() const {
        displayEntities(customers);
    }

    void displayProducers() const {
        displayEntities(producers);
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addCustomer(Customer("C001", "John Doe"));
    grid.addProducer(Producer("P001", "ABC Power"));

    grid.updateCustomer("C001", "Jane Doe");
    grid.updateProducer("P001", "XYZ Energy");

    grid.displayCustomers();
    grid.displayProducers();

    const Customer* customer = grid.searchCustomer("C001");
    if (customer) {
        std::cout << "Found customer: " << customer->getName() << std::endl;
    }

    const Producer* producer = grid.searchProducer("P001");
    if (producer) {
        std::cout << "Found producer: " << producer->getName() << std::endl;
    }

    grid.deleteCustomer("C001");
    grid.deleteProducer("P001");

    grid.displayCustomers();
    grid.displayProducers();

    return 0;
}