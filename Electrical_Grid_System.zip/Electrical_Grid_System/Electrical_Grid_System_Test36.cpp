#include <iostream>
#include <string>

struct Customer {
    int id;
    std::string name;
    double consumption;
    Customer* next;
};

struct ElectricityProducer {
    int id;
    std::string name;
    double production;
    ElectricityProducer* next;
};

class GridSystem {
    Customer* customers;
    ElectricityProducer* producers;
    int customerCount;
    int producerCount;

public:
    GridSystem() : customers(nullptr), producers(nullptr), customerCount(0), producerCount(0) {}

    void addCustomer(int id, const std::string& name, double consumption) {
        Customer* newCustomer = new Customer{id, name, consumption, customers};
        customers = newCustomer;
        customerCount++;
    }

    void deleteCustomer(int id) {
        Customer** curr = &customers;
        while (*curr) {
            Customer* entry = *curr;
            if (entry->id == id) {
                *curr = entry->next;
                delete entry;
                customerCount--;
                return;
            }
            curr = &entry->next;
        }
    }

    void updateCustomer(int id, const std::string& name, double consumption) {
        Customer* current = customers;
        while (current) {
            if (current->id == id) {
                current->name = name;
                current->consumption = consumption;
                return;
            }
            current = current->next;
        }
    }

    Customer* searchCustomer(int id) {
        Customer* current = customers;
        while (current) {
            if (current->id == id) {
                return current;
            }
            current = current->next;
        }
        return nullptr;
    }

    void displayCustomers() {
        Customer* current = customers;
        while (current) {
            std::cout << "ID: " << current->id << ", Name: " << current->name << ", Consumption: " << current->consumption << std::endl;
            current = current->next;
        }
    }

    void addProducer(int id, const std::string& name, double production) {
        ElectricityProducer* newProducer = new ElectricityProducer{id, name, production, producers};
        producers = newProducer;
        producerCount++;
    }

    void deleteProducer(int id) {
        ElectricityProducer** curr = &producers;
        while (*curr) {
            ElectricityProducer* entry = *curr;
            if (entry->id == id) {
                *curr = entry->next;
                delete entry;
                producerCount--;
                return;
            }
            curr = &entry->next;
        }
    }

    void updateProducer(int id, const std::string& name, double production) {
        ElectricityProducer* current = producers;
        while (current) {
            if (current->id == id) {
                current->name = name;
                current->production = production;
                return;
            }
            current = current->next;
        }
    }

    ElectricityProducer* searchProducer(int id) {
        ElectricityProducer* current = producers;
        while (current) {
            if (current->id == id) {
                return current;
            }
            current = current->next;
        }
        return nullptr;
    }

    void displayProducers() {
        ElectricityProducer* current = producers;
        while (current) {
            std::cout << "ID: " << current->id << ", Name: " << current->name << ", Production: " << current->production << std::endl;
            current = current->next;
        }
    }
};

int main() {
    GridSystem gridSystem;

    gridSystem.addCustomer(1, "John Doe", 123.45);
    gridSystem.addCustomer(2, "Jane Smith", 678.90);
    gridSystem.displayCustomers();

    gridSystem.addProducer(1, "Solar Inc", 1000.50);
    gridSystem.addProducer(2, "Wind LLC", 2000.75);
    gridSystem.displayProducers();

    Customer* foundCustomer = gridSystem.searchCustomer(1);
    if (foundCustomer) {
        std::cout << "Found Customer: " << foundCustomer->name << std::endl;
    }

    gridSystem.updateCustomer(1, "John Famous", 543.21);
    gridSystem.displayCustomers();

    gridSystem.deleteCustomer(2);
    gridSystem.displayCustomers();

    ElectricityProducer* foundProducer = gridSystem.searchProducer(2);
    if (foundProducer) {
        std::cout << "Found Producer: " << foundProducer->name << std::endl;
    }

    gridSystem.updateProducer(2, "Wind Power LLC", 2300.85);
    gridSystem.displayProducers();

    gridSystem.deleteProducer(2);
    gridSystem.displayProducers();

    return 0;
}