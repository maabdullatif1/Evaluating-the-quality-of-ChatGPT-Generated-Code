#include <iostream>
#include <vector>
#include <string>

class Participant {
protected:
    int id;
    std::string name;
    std::string type;

public:
    Participant(int id, const std::string& name, const std::string& type)
        : id(id), name(name), type(type) {}

    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getType() const { return type; }

    void updateName(const std::string& newName) { name = newName; }
};

class Customer : public Participant {
public:
    Customer(int id, const std::string& name)
        : Participant(id, name, "Customer") {}
};

class Producer : public Participant {
public:
    Producer(int id, const std::string& name)
        : Participant(id, name, "Producer") {}
};

class ElectricalGridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;

public:
    void addCustomer(int id, const std::string& name) {
        customers.push_back(Customer(id, name));
    }

    void addProducer(int id, const std::string& name) {
        producers.push_back(Producer(id, name));
    }

    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void deleteProducer(int id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getId() == id) {
                producers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(int id, const std::string& newName) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                customer.updateName(newName);
                break;
            }
        }
    }

    void updateProducer(int id, const std::string& newName) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                producer.updateName(newName);
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Producer* searchProducer(int id) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                return &producer;
            }
        }
        return nullptr;
    }

    void displayAll() {
        std::cout << "Customers:" << std::endl;
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.getId() << ", Name: " << customer.getName() << std::endl;
        }

        std::cout << "Producers:" << std::endl;
        for (const auto& producer : producers) {
            std::cout << "ID: " << producer.getId() << ", Name: " << producer.getName() << std::endl;
        }
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addCustomer(1, "Alice");
    grid.addProducer(101, "SolarCo");
    grid.displayAll();
    grid.updateCustomer(1, "Alice A.");
    grid.displayAll();
    Customer* customer = grid.searchCustomer(1);
    if (customer) std::cout << "Found customer: " << customer->getName() << std::endl;
    grid.deleteCustomer(1);
    grid.displayAll();
    return 0;
}