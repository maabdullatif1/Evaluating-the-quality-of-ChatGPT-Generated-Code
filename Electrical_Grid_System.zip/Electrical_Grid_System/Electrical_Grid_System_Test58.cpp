#include <iostream>
#include <vector>
#include <string>

class Entity {
protected:
    int id;
    std::string name;
    std::string address;
public:
    Entity(int id, std::string name, std::string address) : id(id), name(name), address(address) {}
    int getId() { return id; }
    std::string getName() { return name; }
    std::string getAddress() { return address; }
    void setName(std::string newName) { name = newName; }
    void setAddress(std::string newAddress) { address = newAddress; }
    virtual void display() = 0;
};

class Customer : public Entity {
public:
    Customer(int id, std::string name, std::string address) : Entity(id, name, address) {}
    void display() override {
        std::cout << "Customer ID: " << id << ", Name: " << name << ", Address: " << address << std::endl;
    }
};

class ElectricityProducer : public Entity {
public:
    ElectricityProducer(int id, std::string name, std::string address) : Entity(id, name, address) {}
    void display() override {
        std::cout << "Producer ID: " << id << ", Name: " << name << ", Address: " << address << std::endl;
    }
};

class GridSystem {
    std::vector<Customer> customers;
    std::vector<ElectricityProducer> producers;
    
    template <typename T>
    int findIndex(std::vector<T> &entities, int id) {
        for (int i = 0; i < entities.size(); i++) {
            if (entities[i].getId() == id) return i;
        }
        return -1;
    }
public:
    void addCustomer(int id, std::string name, std::string address) {
        customers.emplace_back(id, name, address);
    }
    
    void addProducer(int id, std::string name, std::string address) {
        producers.emplace_back(id, name, address);
    }
    
    void deleteCustomer(int id) {
        int index = findIndex(customers, id);
        if (index != -1) customers.erase(customers.begin() + index);
    }
    
    void deleteProducer(int id) {
        int index = findIndex(producers, id);
        if (index != -1) producers.erase(producers.begin() + index);
    }
    
    void updateCustomer(int id, std::string newName, std::string newAddress) {
        int index = findIndex(customers, id);
        if (index != -1) {
            customers[index].setName(newName);
            customers[index].setAddress(newAddress);
        }
    }
    
    void updateProducer(int id, std::string newName, std::string newAddress) {
        int index = findIndex(producers, id);
        if (index != -1) {
            producers[index].setName(newName);
            producers[index].setAddress(newAddress);
        }
    }
    
    void displayCustomer(int id) {
        int index = findIndex(customers, id);
        if (index != -1) customers[index].display();
    }
    
    void displayProducer(int id) {
        int index = findIndex(producers, id);
        if (index != -1) producers[index].display();
    }
    
    void displayAllCustomers() {
        for (auto &customer : customers) customer.display();
    }
    
    void displayAllProducers() {
        for (auto &producer : producers) producer.display();
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer(1, "Alice", "123 Elm St");
    grid.addProducer(1, "Solar Inc.", "456 Oak St");
    grid.displayAllCustomers();
    grid.displayAllProducers();
    grid.updateCustomer(1, "Alice Smith", "789 Pine St");
    grid.displayCustomer(1);
    grid.deleteProducer(1);
    grid.displayAllProducers();
    return 0;
}