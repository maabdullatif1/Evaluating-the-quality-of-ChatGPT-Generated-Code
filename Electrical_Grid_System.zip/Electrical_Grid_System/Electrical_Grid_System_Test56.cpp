#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Entity {
public:
    string id;
    string name;
    string location;
};

class Customer : public Entity {
public:
    double consumption;
};

class Producer : public Entity {
public:
    double production;
};

class GridSystem {
public:
    vector<Customer> customers;
    vector<Producer> producers;

    void addCustomer(const Customer& cust) {
        customers.push_back(cust);
    }

    void addProducer(const Producer& prod) {
        producers.push_back(prod);
    }

    void deleteCustomer(const string& id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void deleteProducer(const string& id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->id == id) {
                producers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(const string& id, const Customer& updatedCust) {
        for (auto& cust : customers) {
            if (cust.id == id) {
                cust = updatedCust;
                break;
            }
        }
    }

    void updateProducer(const string& id, const Producer& updatedProd) {
        for (auto& prod : producers) {
            if (prod.id == id) {
                prod = updatedProd;
                break;
            }
        }
    }

    Customer* searchCustomer(const string& id) {
        for (auto& cust : customers) {
            if (cust.id == id) {
                return &cust;
            }
        }
        return nullptr;
    }

    Producer* searchProducer(const string& id) {
        for (auto& prod : producers) {
            if (prod.id == id) {
                return &prod;
            }
        }
        return nullptr;
    }

    void displayAllCustomers() {
        for (const auto& cust : customers) {
            cout << "ID: " << cust.id << ", Name: " << cust.name << ", Location: " << cust.location << ", Consumption: " << cust.consumption << endl;
        }
    }

    void displayAllProducers() {
        for (const auto& prod : producers) {
            cout << "ID: " << prod.id << ", Name: " << prod.name << ", Location: " << prod.location << ", Production: " << prod.production << endl;
        }
    }
};

int main() {
    GridSystem grid;
    Customer cust1 = {"C123", "John Doe", "City A", 150.5};
    Customer cust2 = {"C456", "Jane Smith", "City B", 220.7};
    Producer prod1 = {"P789", "Sun Power", "City C", 300.0};
    Producer prod2 = {"P012", "Wind Energy", "City D", 450.0};
    
    grid.addCustomer(cust1);
    grid.addCustomer(cust2);
    grid.addProducer(prod1);
    grid.addProducer(prod2);
    
    grid.displayAllCustomers();
    grid.displayAllProducers();
    
    grid.deleteCustomer("C123");
    grid.deleteProducer("P012");
    
    Customer cust3 = {"C456", "Jane Doe", "City B", 230.9};
    grid.updateCustomer("C456", cust3);
    
    grid.displayAllCustomers();
    grid.displayAllProducers();
    
    return 0;
}