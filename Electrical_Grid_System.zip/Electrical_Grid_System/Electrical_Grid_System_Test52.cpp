#include <iostream>
#include <string>
using namespace std;

struct Entity {
    int id;
    string name;
    double powerConsumption;
};

class GridSystem {
private:
    Entity customers[100];
    Entity producers[100];
    int customerCount;
    int producerCount;

public:
    GridSystem() : customerCount(0), producerCount(0) {}

    void addCustomer(int id, string name, double powerConsumption) {
        if (customerCount < 100) {
            customers[customerCount] = {id, name, powerConsumption};
            customerCount++;
        }
    }

    void deleteCustomer(int id) {
        for (int i = 0; i < customerCount; i++) {
            if (customers[i].id == id) {
                customers[i] = customers[customerCount - 1];
                customerCount--;
                break;
            }
        }
    }

    void updateCustomer(int id, string name, double powerConsumption) {
        for (int i = 0; i < customerCount; i++) {
            if (customers[i].id == id) {
                customers[i].name = name;
                customers[i].powerConsumption = powerConsumption;
                break;
            }
        }
    }

    Entity* searchCustomer(int id) {
        for (int i = 0; i < customerCount; i++) {
            if (customers[i].id == id) {
                return &customers[i];
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (int i = 0; i < customerCount; i++) {
            cout << "ID: " << customers[i].id << " Name: " << customers[i].name << " Consumption: " << customers[i].powerConsumption << endl;
        }
    }

    void addProducer(int id, string name, double powerOutput) {
        if (producerCount < 100) {
            producers[producerCount] = {id, name, powerOutput};
            producerCount++;
        }
    }

    void deleteProducer(int id) {
        for (int i = 0; i < producerCount; i++) {
            if (producers[i].id == id) {
                producers[i] = producers[producerCount - 1];
                producerCount--;
                break;
            }
        }
    }

    void updateProducer(int id, string name, double powerOutput) {
        for (int i = 0; i < producerCount; i++) {
            if (producers[i].id == id) {
                producers[i].name = name;
                producers[i].powerOutput = powerOutput;
                break;
            }
        }
    }

    Entity* searchProducer(int id) {
        for (int i = 0; i < producerCount; i++) {
            if (producers[i].id == id) {
                return &producers[i];
            }
        }
        return nullptr;
    }

    void displayProducers() {
        for (int i = 0; i < producerCount; i++) {
            cout << "ID: " << producers[i].id << " Name: " << producers[i].name << " Output: " << producers[i].powerOutput << endl;
        }
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer(1, "Alice", 150.5);
    grid.addCustomer(2, "Bob", 130.2);
    grid.addProducer(101, "Solar Farm A", 5000);
    grid.addProducer(102, "Wind Plant B", 3000);

    grid.displayCustomers();
    grid.displayProducers();

    return 0;
}