#include <iostream>
#include <vector>
#include <string>

class Entity {
protected:
    int id;
    std::string name;
    std::string address;
public:
    Entity(int id, std::string name, std::string address)
        : id(id), name(name), address(address) {}
    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getAddress() const { return address; }
    virtual void display() const = 0;
};

class Customer : public Entity {
    double consumption;
public:
    Customer(int id, std::string name, std::string address, double consumption)
        : Entity(id, name, address), consumption(consumption) {}
    void updateConsumption(double newConsumption) { consumption = newConsumption; }
    double getConsumption() const { return consumption; }
    void display() const override {
        std::cout << "Customer ID: " << id << ", Name: " << name 
                  << ", Address: " << address << ", Consumption: " << consumption << std::endl;
    }
};

class Producer : public Entity {
    double production;
public:
    Producer(int id, std::string name, std::string address, double production)
        : Entity(id, name, address), production(production) {}
    void updateProduction(double newProduction) { production = newProduction; }
    double getProduction() const { return production; }
    void display() const override {
        std::cout << "Producer ID: " << id << ", Name: " << name 
                  << ", Address: " << address << ", Production: " << production << std::endl;
    }
};

class Grid {
    std::vector<Customer> customers;
    std::vector<Producer> producers;
public:
    void addCustomer(int id, std::string name, std::string address, double consumption) {
        customers.emplace_back(id, name, address, consumption);
    }
    void deleteCustomer(int id) {
        customers.erase(std::remove_if(customers.begin(), customers.end(),
           [id](const Customer& c){ return c.getId() == id; }), customers.end());
    }
    void updateCustomer(int id, std::string name, std::string address, double consumption) {
        for (auto& c : customers) {
            if (c.getId() == id) {
                c = Customer(id, name, address, consumption);
                break;
            }
        }
    }
    void searchCustomer(int id) const {
        for (const auto& c : customers) {
            if (c.getId() == id) {
                c.display();
                return;
            }
        }
        std::cout << "Customer not found" << std::endl;
    }
    void displayCustomers() const {
        for (const auto& c : customers) {
            c.display();
        }
    }
    void addProducer(int id, std::string name, std::string address, double production) {
        producers.emplace_back(id, name, address, production);
    }
    void deleteProducer(int id) {
        producers.erase(std::remove_if(producers.begin(), producers.end(),
           [id](const Producer& p){ return p.getId() == id; }), producers.end());
    }
    void updateProducer(int id, std::string name, std::string address, double production) {
        for (auto& p : producers) {
            if (p.getId() == id) {
                p = Producer(id, name, address, production);
                break;
            }
        }
    }
    void searchProducer(int id) const {
        for (const auto& p : producers) {
            if (p.getId() == id) {
                p.display();
                return;
            }
        }
        std::cout << "Producer not found" << std::endl;
    }
    void displayProducers() const {
        for (const auto& p : producers) {
            p.display();
        }
    }
};

int main() {
    Grid grid;
    grid.addCustomer(1, "John Doe", "123 Elm St", 200.5);
    grid.addProducer(2, "Solar Inc.", "789 Maple Ave", 500.0);
    grid.displayCustomers();
    grid.displayProducers();
    grid.searchCustomer(1);
    grid.updateCustomer(1, "John Doe", "123 Elm St", 300.0);
    grid.searchCustomer(1);
    grid.deleteCustomer(1);
    grid.displayCustomers();
    return 0;
}