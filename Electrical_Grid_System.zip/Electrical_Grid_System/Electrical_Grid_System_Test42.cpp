#include <iostream>
#include <vector>
#include <string>

class Entity {
protected:
    int id;
    std::string name;
    std::string address;
public:
    Entity(int id, const std::string& name, const std::string& address) 
        : id(id), name(name), address(address) {}
    int getId() const {
        return id;
    }
    std::string getName() const {
        return name;
    }
    std::string getAddress() const {
        return address;
    }
    void setName(const std::string& newName) {
        name = newName;
    }
    void setAddress(const std::string& newAddress) {
        address = newAddress;
    }
};

class Customer : public Entity {
public:
    Customer(int id, const std::string& name, const std::string& address)
        : Entity(id, name, address) {}
};

class Producer : public Entity {
public:
    Producer(int id, const std::string& name, const std::string& address)
        : Entity(id, name, address) {}
};

class GridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;
public:
    void addCustomer(int id, const std::string& name, const std::string& address) {
        customers.push_back(Customer(id, name, address));
    }
    void addProducer(int id, const std::string& name, const std::string& address) {
        producers.push_back(Producer(id, name, address));
    }
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == id) {
                customers.erase(it);
                break;
            }
        }
    }
    void deleteProducer(int id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getId() == id) {
                producers.erase(it);
                break;
            }
        }
    }
    void updateCustomer(int id, const std::string& newName, const std::string& newAddress) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                customer.setName(newName);
                customer.setAddress(newAddress);
                break;
            }
        }
    }
    void updateProducer(int id, const std::string& newName, const std::string& newAddress) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                producer.setName(newName);
                producer.setAddress(newAddress);
                break;
            }
        }
    }
    Entity* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                return &customer;
            }
        }
        return nullptr;
    }
    Entity* searchProducer(int id) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                return &producer;
            }
        }
        return nullptr;
    }
    void displayCustomers() {
        std::cout << "Customers: \n";
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.getId() << ", Name: " << customer.getName()
                      << ", Address: " << customer.getAddress() << "\n";
        }
    }
    void displayProducers() {
        std::cout << "Producers: \n";
        for (const auto& producer : producers) {
            std::cout << "ID: " << producer.getId() << ", Name: " << producer.getName()
                      << ", Address: " << producer.getAddress() << "\n";
        }
    }
};

int main() {
    GridSystem grid;

    grid.addCustomer(1, "John Doe", "123 Main St");
    grid.addCustomer(2, "Jane Smith", "456 Elm St");
    
    grid.addProducer(1, "Local Electric", "789 Energy Ave");
    grid.addProducer(2, "Green Power", "101 Renewable Rd");

    grid.displayCustomers();
    grid.displayProducers();

    grid.updateCustomer(1, "John A. Doe", "123 Main St, Apt 1");
    grid.updateProducer(2, "Green Energy", "202 Sustainable St");

    grid.displayCustomers();
    grid.displayProducers();

    grid.deleteCustomer(2);
    grid.deleteProducer(1);

    grid.displayCustomers();
    grid.displayProducers();

    return 0;
}