#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Participant {
protected:
    int id;
    string name;
    string type;
public:
    Participant(int id, string name, string type) : id(id), name(name), type(type) {}
    int getId() const { return id; }
    string getName() const { return name; }
    string getType() const { return type; }
    void setName(string newName) { name = newName; }
    virtual void display() const = 0;
};

class Customer : public Participant {
public:
    Customer(int id, string name) : Participant(id, name, "Customer") {}
    void display() const override {
        cout << "Customer ID: " << id << ", Name: " << name << endl;
    }
};

class Producer : public Participant {
public:
    Producer(int id, string name) : Participant(id, name, "Producer") {}
    void display() const override {
        cout << "Producer ID: " << id << ", Name: " << name << endl;
    }
};

class GridSystem {
    vector<Participant*> participants;
    int nextId;

    Participant* search(int id) {
        for (auto& participant : participants) {
            if (participant->getId() == id) return participant;
        }
        return nullptr;
    }

public:
    GridSystem() : nextId(1) {}

    void addParticipant(string name, string type) {
        if (type == "Customer") {
            participants.push_back(new Customer(nextId++, name));
        } else if (type == "Producer") {
            participants.push_back(new Producer(nextId++, name));
        }
    }

    void deleteParticipant(int id) {
        for (auto it = participants.begin(); it != participants.end(); ++it) {
            if ((*it)->getId() == id) {
                delete *it;
                participants.erase(it);
                return;
            }
        }
    }

    void updateParticipant(int id, string newName) {
        Participant* participant = search(id);
        if (participant) {
            participant->setName(newName);
        }
    }

    void searchParticipant(int id) const {
        for (const auto& participant : participants) {
            if (participant->getId() == id) {
                participant->display();
                return;
            }
        }
        cout << "Participant not found" << endl;
    }

    void displayAll() const {
        for (const auto& participant : participants) {
            participant->display();
        }
    }

    ~GridSystem() {
        for (auto participant : participants) {
            delete participant;
        }
    }
};

int main() {
    GridSystem grid;
    grid.addParticipant("Alice", "Customer");
    grid.addParticipant("Bob", "Producer");
    grid.displayAll();
    grid.updateParticipant(1, "Alice Smith");
    grid.searchParticipant(1);
    grid.deleteParticipant(2);
    grid.displayAll();
    return 0;
}