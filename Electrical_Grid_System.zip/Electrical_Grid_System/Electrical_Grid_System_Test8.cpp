#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Customer {
public:
    string id;
    string name;
    double consumption;

    Customer(string id, string name, double consumption)
        : id(id), name(name), consumption(consumption) {}
};

class Producer {
public:
    string id;
    string name;
    double production;

    Producer(string id, string name, double production)
        : id(id), name(name), production(production) {}
};

class ElectricalGridSystem {
    vector<Customer> customers;
    vector<Producer> producers;

public:
    void addCustomer(string id, string name, double consumption) {
        customers.push_back(Customer(id, name, consumption));
    }
    
    void deleteCustomer(string id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(string id, string name, double consumption) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.consumption = consumption;
                break;
            }
        }
    }
    
    void searchCustomer(string id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                cout << "Customer ID: " << customer.id << endl;
                cout << "Name: " << customer.name << endl;
                cout << "Consumption: " << customer.consumption << " kWh" << endl;
                return;
            }
        }
        cout << "Customer not found." << endl;
    }
    
    void displayCustomers() {
        for (auto &customer : customers) {
            cout << "Customer ID: " << customer.id << endl;
            cout << "Name: " << customer.name << endl;
            cout << "Consumption: " << customer.consumption << " kWh" << endl;
        }
    }
    
    void addProducer(string id, string name, double production) {
        producers.push_back(Producer(id, name, production));
    }
    
    void deleteProducer(string id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->id == id) {
                producers.erase(it);
                break;
            }
        }
    }

    void updateProducer(string id, string name, double production) {
        for (auto &producer : producers) {
            if (producer.id == id) {
                producer.name = name;
                producer.production = production;
                break;
            }
        }
    }

    void searchProducer(string id) {
        for (auto &producer : producers) {
            if (producer.id == id) {
                cout << "Producer ID: " << producer.id << endl;
                cout << "Name: " << producer.name << endl;
                cout << "Production: " << producer.production << " MW" << endl;
                return;
            }
        }
        cout << "Producer not found." << endl;
    }
    
    void displayProducers() {
        for (auto &producer : producers) {
            cout << "Producer ID: " << producer.id << endl;
            cout << "Name: " << producer.name << endl;
            cout << "Production: " << producer.production << " MW" << endl;
        }
    }
};

int main() {
    ElectricalGridSystem gridSystem;
    gridSystem.addCustomer("C001", "John Doe", 500.0);
    gridSystem.addCustomer("C002", "Jane Smith", 750.0);
    gridSystem.displayCustomers();

    gridSystem.addProducer("P001", "Green Energy Inc.", 1000.0);
    gridSystem.addProducer("P002", "Solar Corp.", 1500.0);
    gridSystem.displayProducers();

    gridSystem.updateCustomer("C001", "John Updated", 800.0);
    gridSystem.searchCustomer("C001");

    gridSystem.deleteProducer("P002");
    gridSystem.displayProducers();

    return 0;
}