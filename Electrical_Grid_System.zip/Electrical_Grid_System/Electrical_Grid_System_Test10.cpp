#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Entity {
public:
    string name;
    string id;
    Entity(string n, string i) : name(n), id(i) {}
};

class Customer : public Entity {
public:
    Customer(string n, string i) : Entity(n, i) {}
};

class Producer : public Entity {
public:
    Producer(string n, string i) : Entity(n, i) {}
};

class ElectricalGridSystem {
private:
    vector<Customer> customers;
    vector<Producer> producers;
    
    template <typename T>
    int findIndex(const vector<T>& vec, const string& id) {
        for (int i = 0; i < vec.size(); ++i) {
            if (vec[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCustomer(const string& name, const string& id) {
        customers.push_back(Customer(name, id));
    }

    void addProducer(const string& name, const string& id) {
        producers.push_back(Producer(name, id));
    }

    void deleteCustomer(const string& id) {
        int index = findIndex(customers, id);
        if (index != -1) {
            customers.erase(customers.begin() + index);
        }
    }

    void deleteProducer(const string& id) {
        int index = findIndex(producers, id);
        if (index != -1) {
            producers.erase(producers.begin() + index);
        }
    }

    void updateCustomer(const string& id, const string& newName) {
        int index = findIndex(customers, id);
        if (index != -1) {
            customers[index].name = newName;
        }
    }

    void updateProducer(const string& id, const string& newName) {
        int index = findIndex(producers, id);
        if (index != -1) {
            producers[index].name = newName;
        }
    }

    void searchCustomer(const string& id) {
        int index = findIndex(customers, id);
        if (index != -1) {
            cout << "Customer Found: " << customers[index].name << ", ID: " << customers[index].id << endl;
        } else {
            cout << "Customer Not Found" << endl;
        }
    }

    void searchProducer(const string& id) {
        int index = findIndex(producers, id);
        if (index != -1) {
            cout << "Producer Found: " << producers[index].name << ", ID: " << producers[index].id << endl;
        } else {
            cout << "Producer Not Found" << endl;
        }
    }

    void displayCustomers() {
        cout << "Customers:" << endl;
        for (const auto& customer : customers) {
            cout << "Name: " << customer.name << ", ID: " << customer.id << endl;
        }
    }

    void displayProducers() {
        cout << "Producers:" << endl;
        for (const auto& producer : producers) {
            cout << "Name: " << producer.name << ", ID: " << producer.id << endl;
        }
    }
};

int main() {
    ElectricalGridSystem grid;
    
    grid.addCustomer("John Doe", "C001");
    grid.addCustomer("Jane Smith", "C002");
    grid.addProducer("Solar Co", "P001");
    grid.addProducer("Wind Co", "P002");
    
    grid.displayCustomers();
    grid.displayProducers();
    
    grid.searchCustomer("C001");
    grid.searchProducer("P002");
    
    grid.updateCustomer("C001", "Johnathan Doe");
    grid.updateProducer("P002", "Wind Company Ltd.");
    
    grid.displayCustomers();
    grid.displayProducers();
    
    grid.deleteCustomer("C002");
    grid.deleteProducer("P001");
    
    grid.displayCustomers();
    grid.displayProducers();
    
    return 0;
}