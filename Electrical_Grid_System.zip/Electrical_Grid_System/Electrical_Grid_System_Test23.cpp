#include <iostream>
#include <vector>
#include <string>

class Entity {
protected:
    std::string name;
    std::string id;
public:
    Entity(std::string name, std::string id) : name(name), id(id) {}

    virtual void display() const = 0;

    std::string getId() const { return id; }
};

class Customer : public Entity {
private:
    double electricityUsage;
public:
    Customer(std::string name, std::string id, double usage) 
        : Entity(name, id), electricityUsage(usage) {}

    void display() const override {
        std::cout << "Customer: " << name << ", ID: " << id 
                  << ", Usage: " << electricityUsage << " kWh" << std::endl;
    }

    void updateUsage(double usage) { this->electricityUsage = usage; }
};

class Producer : public Entity {
private:
    double electricityOutput;
public:
    Producer(std::string name, std::string id, double output) 
        : Entity(name, id), electricityOutput(output) {}

    void display() const override {
        std::cout << "Producer: " << name << ", ID: " << id 
                  << ", Output: " << electricityOutput << " kWh" << std::endl;
    }

    void updateOutput(double output) { this->electricityOutput = output; }
};

class ElectricalGrid {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;

    template<typename T>
    void removeEntity(std::vector<T> &entities, const std::string& id) {
        for (auto it = entities.begin(); it != entities.end(); ++it) {
            if (it->getId() == id) {
                entities.erase(it);
                return;
            }
        }
    }

    template<typename T>
    T* searchEntity(std::vector<T> &entities, const std::string& id) {
        for (auto &entity : entities) {
            if (entity.getId() == id) {
                return &entity;
            }
        }
        return nullptr;
    }

    template<typename T>
    void displayEntities(const std::vector<T> &entities) const {
        for (const auto &entity : entities) {
            entity.display();
        }
    }

public:
    void addCustomer(const std::string& name, const std::string& id, double usage) {
        customers.emplace_back(name, id, usage);
    }

    void deleteCustomer(const std::string& id) {
        removeEntity(customers, id);
    }

    void updateCustomer(const std::string& id, double usage) {
        Customer* customer = searchEntity(customers, id);
        if (customer) {
            customer->updateUsage(usage);
        }
    }

    void searchCustomer(const std::string& id) {
        Customer* customer = searchEntity(customers, id);
        if (customer) {
            customer->display();
        } else {
            std::cout << "Customer not found." << std::endl;
        }
    }

    void displayCustomers() const {
        displayEntities(customers);
    }

    void addProducer(const std::string& name, const std::string& id, double output) {
        producers.emplace_back(name, id, output);
    }

    void deleteProducer(const std::string& id) {
        removeEntity(producers, id);
    }

    void updateProducer(const std::string& id, double output) {
        Producer* producer = searchEntity(producers, id);
        if (producer) {
            producer->updateOutput(output);
        }
    }

    void searchProducer(const std::string& id) {
        Producer* producer = searchEntity(producers, id);
        if (producer) {
            producer->display();
        } else {
            std::cout << "Producer not found." << std::endl;
        }
    }

    void displayProducers() const {
        displayEntities(producers);
    }
};

int main() {
    ElectricalGrid grid;

    grid.addCustomer("John Doe", "C001", 250.5);
    grid.addCustomer("Jane Smith", "C002", 180.0);
    grid.addProducer("EnergyPro", "P001", 5000.0);
    grid.addProducer("GreenPower", "P002", 8000.5);

    std::cout << "Current Customers:" << std::endl;
    grid.displayCustomers();
    
    std::cout << "\nCurrent Producers:" << std::endl;
    grid.displayProducers();

    std::cout << "\nSearching for Customer C001:" << std::endl;
    grid.searchCustomer("C001");

    std::cout << "\nUpdating Customer C001 Usage to 275.0:" << std::endl;
    grid.updateCustomer("C001", 275.0);
    grid.searchCustomer("C001");

    std::cout << "\nDeleting Producer P001:" << std::endl;
    grid.deleteProducer("P001");
    grid.displayProducers();

    return 0;
}