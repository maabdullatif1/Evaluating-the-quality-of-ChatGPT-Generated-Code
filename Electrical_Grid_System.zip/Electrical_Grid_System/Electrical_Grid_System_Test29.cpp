#include <iostream>
#include <vector>
#include <string>

class Entity {
protected:
    int id;
    std::string name;
public:
    Entity(int id, const std::string& name) : id(id), name(name) {}
    virtual ~Entity() {}
    int getId() const { return id; }
    const std::string& getName() const { return name; }
    virtual std::string getInfo() const = 0;
};

class Customer : public Entity {
    double consumption;
public:
    Customer(int id, const std::string& name, double consumption)
        : Entity(id, name), consumption(consumption) {}
    void updateConsumption(double newConsumption) { consumption = newConsumption; }
    std::string getInfo() const override {
        return "Customer ID: " + std::to_string(id) + ", Name: " + name + 
               ", Consumption: " + std::to_string(consumption);
    }
};

class Producer : public Entity {
    double production;
public:
    Producer(int id, const std::string& name, double production)
        : Entity(id, name), production(production) {}
    void updateProduction(double newProduction) { production = newProduction; }
    std::string getInfo() const override {
        return "Producer ID: " + std::to_string(id) + ", Name: " + name + 
               ", Production: " + std::to_string(production);
    }
};

class GridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;
public:
    void addCustomer(int id, const std::string& name, double consumption) {
        customers.emplace_back(id, name, consumption);
    }

    void deleteCustomer(int id) {
        customers.erase(std::remove_if(customers.begin(), customers.end(), 
                                       [&](const Customer& c) { return c.getId() == id; }), 
                        customers.end());
    }

    void updateCustomer(int id, double newConsumption) {
        for (auto& customer : customers)
            if (customer.getId() == id)
                customer.updateConsumption(newConsumption);
    }

    void addProducer(int id, const std::string& name, double production) {
        producers.emplace_back(id, name, production);
    }

    void deleteProducer(int id) {
        producers.erase(std::remove_if(producers.begin(), producers.end(), 
                                       [&](const Producer& p) { return p.getId() == id; }), 
                        producers.end());
    }

    void updateProducer(int id, double newProduction) {
        for (auto& producer : producers)
            if (producer.getId() == id)
                producer.updateProduction(newProduction);
    }
    
    void searchEntityById(int id) const {
        for (const auto& customer : customers)
            if (customer.getId() == id) {
                std::cout << customer.getInfo() << std::endl;
                return;
            }
        for (const auto& producer : producers)
            if (producer.getId() == id) {
                std::cout << producer.getInfo() << std::endl;
                return;
            }
        std::cout << "Entity not found." << std::endl;
    }

    void displayAllEntities() const {
        std::cout << "Customers:\n";
        for (const auto& customer : customers)
            std::cout << customer.getInfo() << std::endl;

        std::cout << "Producers:\n";
        for (const auto& producer : producers)
            std::cout << producer.getInfo() << std::endl;
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer(1, "Customer1", 100.5);
    grid.addProducer(101, "Producer1", 200.0);

    grid.displayAllEntities();
    grid.searchEntityById(1);
    grid.updateCustomer(1, 150.0);

    grid.searchEntityById(1);
    grid.deleteCustomer(1);
    grid.displayAllEntities();

    return 0;
}