#include <iostream>
#include <vector>
#include <string>

class Participant {
protected:
    int id;
    std::string name;
    std::string address;

public:
    Participant(int id, std::string name, std::string address) 
        : id(id), name(name), address(address) {}

    virtual void display() const = 0;
    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getAddress() const { return address; }
    void setName(const std::string& newName) { name = newName; }
    void setAddress(const std::string& newAddress) { address = newAddress; }
};

class Customer : public Participant {
    double consumption;

public:
    Customer(int id, std::string name, std::string address, double consumption) 
        : Participant(id, name, address), consumption(consumption) {}

    void display() const override {
        std::cout << "Customer [ID: " << id << ", Name: " << name 
                  << ", Address: " << address << ", Consumption: " 
                  << consumption << "]\n";
    }

    double getConsumption() const { return consumption; }
    void setConsumption(double newConsumption) { consumption = newConsumption; }
};

class Producer : public Participant {
    double production;

public:
    Producer(int id, std::string name, std::string address, double production) 
        : Participant(id, name, address), production(production) {}

    void display() const override {
        std::cout << "Producer [ID: " << id << ", Name: " << name 
                  << ", Address: " << address << ", Production: " 
                  << production << "]\n";
    }

    double getProduction() const { return production; }
    void setProduction(double newProduction) { production = newProduction; }
};

class ElectricalGridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;

public:
    void addCustomer(int id, std::string name, std::string address, double consumption) {
        customers.emplace_back(id, name, address, consumption);
    }

    void addProducer(int id, std::string name, std::string address, double production) {
        producers.emplace_back(id, name, address, production);
    }

    void deleteCustomer(int id) {
        customers.erase(std::remove_if(customers.begin(), customers.end(), 
                    [&](const Customer& c) { return c.getId() == id; }), customers.end());
    }

    void deleteProducer(int id) {
        producers.erase(std::remove_if(producers.begin(), producers.end(), 
                    [&](const Producer& p) { return p.getId() == id; }), producers.end());
    }

    Customer* searchCustomer(int id) {
        for (auto& c : customers) {
            if (c.getId() == id) return &c;
        }
        return nullptr;
    }

    Producer* searchProducer(int id) {
        for (auto& p : producers) {
            if (p.getId() == id) return &p;
        }
        return nullptr;
    }

    void displayAllCustomers() const {
        for (const auto& c : customers) {
            c.display();
        }
    }

    void displayAllProducers() const {
        for (const auto& p : producers) {
            p.display();
        }
    }
};

int main() {
    ElectricalGridSystem grid;

    grid.addCustomer(1, "John Doe", "123 Elm St", 1200.5);
    grid.addProducer(10, "Solar Farm Inc.", "456 Pine St", 3000.0);

    grid.displayAllCustomers();
    grid.displayAllProducers();

    Customer* customer = grid.searchCustomer(1);
    if (customer) {
        customer->setConsumption(1300.0);
    }

    grid.displayAllCustomers();

    grid.deleteCustomer(1);
    grid.displayAllCustomers();

    return 0;
}