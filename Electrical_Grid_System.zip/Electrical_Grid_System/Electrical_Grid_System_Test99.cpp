#include <iostream>
#include <vector>
#include <string>

class Entity {
public:
    Entity(int id, std::string name) : id(id), name(name) {}
    int getId() const { return id; }
    std::string getName() const { return name; }
    void setName(std::string name) { this->name = name; }
    
private:
    int id;
    std::string name;
};

class GridSystem {
public:
    void addCustomer(int id, std::string name) {
        customers.push_back(Entity(id, name));
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, std::string name) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                customer.setName(name);
                break;
            }
        }
    }
    
    Entity* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                return &customer;
            }
        }
        return nullptr;
    }
    
    void displayCustomers() const {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.getId() << ", Name: " << customer.getName() << '\n';
        }
    }
    
    void addProducer(int id, std::string name) {
        producers.push_back(Entity(id, name));
    }
    
    void deleteProducer(int id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getId() == id) {
                producers.erase(it);
                break;
            }
        }
    }
    
    void updateProducer(int id, std::string name) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                producer.setName(name);
                break;
            }
        }
    }
    
    Entity* searchProducer(int id) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                return &producer;
            }
        }
        return nullptr;
    }
    
    void displayProducers() const {
        for (const auto& producer : producers) {
            std::cout << "Producer ID: " << producer.getId() << ", Name: " << producer.getName() << '\n';
        }
    }

private:
    std::vector<Entity> customers;
    std::vector<Entity> producers;
};

int main() {
    GridSystem grid;
    grid.addCustomer(1, "Customer A");
    grid.addProducer(1, "Producer A");
    grid.displayCustomers();
    grid.displayProducers();
    grid.updateCustomer(1, "Customer A Updated");
    grid.updateProducer(1, "Producer A Updated");
    grid.displayCustomers();
    grid.displayProducers();
    grid.deleteCustomer(1);
    grid.deleteProducer(1);
    grid.displayCustomers();
    grid.displayProducers();
    return 0;
}