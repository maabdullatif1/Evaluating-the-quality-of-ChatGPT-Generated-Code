#include <iostream>
#include <string>
#include <vector>

struct Entity {
    std::string id;
    std::string name;
    std::string type;
    double energy_supply;
    double energy_consumption;
};

class GridSystem {
public:
    void addEntity(const std::string& id, const std::string& name, const std::string& type, double energy_supply, double energy_consumption) {
        Entity entity = {id, name, type, energy_supply, energy_consumption};
        entities.push_back(entity);
    }

    void deleteEntity(const std::string& id) {
        for (auto it = entities.begin(); it != entities.end(); ++it) {
            if (it->id == id) {
                entities.erase(it);
                break;
            }
        }
    }

    void updateEntity(const std::string& id, const std::string& name, const std::string& type, double energy_supply, double energy_consumption) {
        for (auto& entity : entities) {
            if (entity.id == id) {
                entity.name = name;
                entity.type = type;
                entity.energy_supply = energy_supply;
                entity.energy_consumption = energy_consumption;
                break;
            }
        }
    }

    Entity* searchEntity(const std::string& id) {
        for (auto& entity : entities) {
            if (entity.id == id) {
                return &entity;
            }
        }
        return nullptr;
    }

    void displayEntities() const {
        for (const auto& entity : entities) {
            std::cout << "ID: " << entity.id << ", Name: " << entity.name
                      << ", Type: " << entity.type << ", Supply: " << entity.energy_supply
                      << ", Consumption: " << entity.energy_consumption << std::endl;
        }
    }

private:
    std::vector<Entity> entities;
};

int main() {
    GridSystem grid;

    grid.addEntity("C001", "John Doe", "Customer", 0.0, 500.0);
    grid.addEntity("P001", "Wind Farm A", "Producer", 1000.0, 0.0);

    grid.displayEntities();

    grid.updateEntity("C001", "John Smith", "Customer", 0.0, 550.0);
    grid.displayEntities();

    grid.deleteEntity("P001");
    grid.displayEntities();

    Entity* found = grid.searchEntity("C001");
    if (found) {
        std::cout << "Found entity: " << found->name << std::endl;
    }

    return 0;
}