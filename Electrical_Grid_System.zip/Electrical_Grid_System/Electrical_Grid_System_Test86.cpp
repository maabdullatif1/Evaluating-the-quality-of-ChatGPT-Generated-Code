#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Entity {
    int id;
    string name;
    string type;
    double power;
};

class ElectricalGrid {
    vector<Entity> entities;
    int nextId = 1;

    public:
    void addEntity(const string& name, const string& type, double power) {
        entities.push_back({nextId++, name, type, power});
    }

    void deleteEntity(int id) {
        for (auto it = entities.begin(); it != entities.end(); ++it) {
            if (it->id == id) {
                entities.erase(it);
                return;
            }
        }
    }

    void updateEntity(int id, const string& name, const string& type, double power) {
        for (auto& entity : entities) {
            if (entity.id == id) {
                entity.name = name;
                entity.type = type;
                entity.power = power;
                return;
            }
        }
    }

    Entity* searchEntity(int id) {
        for (auto& entity : entities) {
            if (entity.id == id) {
                return &entity;
            }
        }
        return nullptr;
    }

    void displayEntities() {
        for (const auto& entity : entities) {
            cout << "ID: " << entity.id << ", Name: " << entity.name 
                 << ", Type: " << entity.type << ", Power: " << entity.power << endl;
        }
    }
};

int main() {
    ElectricalGrid grid;
    grid.addEntity("Consumer A", "Customer", 120.5);
    grid.addEntity("Producer B", "Producer", 300.0);
    grid.displayEntities();
    grid.updateEntity(1, "Consumer A", "Customer", 150.0);
    grid.displayEntities();
    grid.deleteEntity(1);
    grid.displayEntities();
    
    return 0;
}