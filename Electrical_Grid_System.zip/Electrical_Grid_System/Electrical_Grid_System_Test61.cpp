#include <iostream>
#include <string>

const int MAX_ENTRIES = 100;

struct Entity {
    std::string id;
    std::string name;
    std::string type;
};

class ElectricalGridSystem {
private:
    Entity entries[MAX_ENTRIES];
    int entryCount = 0;

    int findIndexById(const std::string& id) {
        for (int i = 0; i < entryCount; ++i) {
            if (entries[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    bool addEntity(const std::string& id, const std::string& name, const std::string& type) {
        if (entryCount >= MAX_ENTRIES || findIndexById(id) != -1) return false;
        entries[entryCount++] = {id, name, type};
        return true;
    }

    bool deleteEntity(const std::string& id) {
        int index = findIndexById(id);
        if (index == -1) return false;
        for (int i = index; i < entryCount - 1; ++i) {
            entries[i] = entries[i + 1];
        }
        --entryCount;
        return true;
    }

    bool updateEntity(const std::string& id, const std::string& name, const std::string& type) {
        int index = findIndexById(id);
        if (index == -1) return false;
        entries[index] = {id, name, type};
        return true;
    }

    Entity* searchEntity(const std::string& id) {
        int index = findIndexById(id);
        return (index != -1) ? &entries[index] : nullptr;
    }

    void displayEntities() {
        for (int i = 0; i < entryCount; ++i) {
            std::cout << "ID: " << entries[i].id
                      << ", Name: " << entries[i].name
                      << ", Type: " << entries[i].type << std::endl;
        }
    }
};

int main() {
    ElectricalGridSystem grid;

    grid.addEntity("C001", "Customer1", "Customer");
    grid.addEntity("P001", "Producer1", "Producer");
    grid.displayEntities();

    Entity* entity = grid.searchEntity("C001");
    if (entity) {
        std::cout << "Found: " << entity->name << std::endl;
    }

    grid.updateEntity("C001", "CustomerOne", "Customer");
    grid.deleteEntity("P001");
    grid.displayEntities();

    return 0;
}