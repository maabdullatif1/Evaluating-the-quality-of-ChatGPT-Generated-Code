#include <iostream>
#include <vector>
#include <string>

struct Customer {
    int id;
    std::string name;
    double consumption;
};

struct Producer {
    int id;
    std::string name;
    double production;
};

class ElectricalGridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;

    template<typename T>
    void displayInfo(const std::vector<T>& entities) {
        for (const auto& entity : entities) {
            std::cout << "ID: " << entity.id << ", Name: " << entity.name;
            if constexpr (std::is_same_v<T, Customer>)
                std::cout << ", Consumption: " << entity.consumption << "\n";
            else
                std::cout << ", Production: " << entity.production << "\n";
        }
    }
    
    template<typename T>
    bool entityExists(int id, const std::vector<T>& entities, int& index) {
        for (size_t i = 0; i < entities.size(); ++i) {
            if (entities[i].id == id) {
                index = i;
                return true;
            }
        }
        return false;
    }
    
public:
    void addCustomer(int id, const std::string& name, double consumption) {
        customers.push_back({id, name, consumption});
    }
    
    void deleteCustomer(int id) {
        int index = -1;
        if (entityExists(id, customers, index))
            customers.erase(customers.begin() + index);
    }
    
    void updateCustomer(int id, const std::string& name, double consumption) {
        int index = -1;
        if (entityExists(id, customers, index)) {
            customers[index].name = name;
            customers[index].consumption = consumption;
        }
    }

    void searchCustomer(int id) {
        int index = -1;
        if (entityExists(id, customers, index))
            std::cout << "Customer found - ID: " << customers[index].id << ", Name: " << customers[index].name << ", Consumption: " << customers[index].consumption << "\n";
        else
            std::cout << "Customer not found\n";
    }

    void displayCustomers() {
        displayInfo(customers);
    }

    void addProducer(int id, const std::string& name, double production) {
        producers.push_back({id, name, production});
    }
    
    void deleteProducer(int id) {
        int index = -1;
        if (entityExists(id, producers, index))
            producers.erase(producers.begin() + index);
    }
    
    void updateProducer(int id, const std::string& name, double production) {
        int index = -1;
        if (entityExists(id, producers, index)) {
            producers[index].name = name;
            producers[index].production = production;
        }
    }

    void searchProducer(int id) {
        int index = -1;
        if (entityExists(id, producers, index))
            std::cout << "Producer found - ID: " << producers[index].id << ", Name: " << producers[index].name << ", Production: " << producers[index].production << "\n";
        else
            std::cout << "Producer not found\n";
    }

    void displayProducers() {
        displayInfo(producers);
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addCustomer(1, "Alice", 300.5);
    grid.addCustomer(2, "Bob", 400.75);
    grid.displayCustomers();
    
    grid.updateCustomer(1, "Alice Updated", 350.5);
    grid.searchCustomer(1);
    
    grid.deleteCustomer(2);
    grid.displayCustomers();
    
    grid.addProducer(1, "Power Plant A", 1000.0);
    grid.addProducer(2, "Solar Field B", 500.5);
    grid.displayProducers();
    
    grid.updateProducer(1, "Power Plant A Updated", 1100.5);
    grid.searchProducer(1);
    
    grid.deleteProducer(2);
    grid.displayProducers();
    
    return 0;
}