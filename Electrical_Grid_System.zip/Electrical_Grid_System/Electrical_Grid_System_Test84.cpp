#include <iostream>
#include <vector>
#include <string>

class Entity {
protected:
    int id;
    std::string name;
    std::string address;

public:
    Entity(int id, std::string name, std::string address) 
        : id(id), name(name), address(address) {}
    
    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getAddress() const { return address; }
    void setName(const std::string& newName) { name = newName; }
    void setAddress(const std::string& newAddress) { address = newAddress; }

    virtual void display() const {
        std::cout << "ID: " << id << ", Name: " << name << ", Address: " << address;
    }
};

class Customer : public Entity {
public:
    Customer(int id, std::string name, std::string address) 
        : Entity(id, name, address) {}

    void display() const override {
        std::cout << "Customer - ";
        Entity::display();
        std::cout << std::endl;
    }
};

class Producer : public Entity {
public:
    Producer(int id, std::string name, std::string address) 
        : Entity(id, name, address) {}

    void display() const override {
        std::cout << "Producer - ";
        Entity::display();
        std::cout << std::endl;
    }
};

class ElectricalGridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;

    template<typename T>
    typename std::vector<T>::iterator findEntityById(std::vector<T>& entities, int id) {
        return std::find_if(entities.begin(), entities.end(), 
            [id](const T& entity) { return entity.getId() == id; }
        );
    }

public:
    void addCustomer(int id, std::string name, std::string address) {
        customers.emplace_back(id, std::move(name), std::move(address));
    }
    
    void addProducer(int id, std::string name, std::string address) {
        producers.emplace_back(id, std::move(name), std::move(address));
    }

    void deleteCustomer(int id) {
        auto it = findEntityById(customers, id);
        if (it != customers.end()) {
            customers.erase(it);
        }
    }

    void deleteProducer(int id) {
        auto it = findEntityById(producers, id);
        if (it != producers.end()) {
            producers.erase(it);
        }
    }

    void updateCustomer(int id, std::string name, std::string address) {
        auto it = findEntityById(customers, id);
        if (it != customers.end()) {
            it->setName(name);
            it->setAddress(address);
        }
    }

    void updateProducer(int id, std::string name, std::string address) {
        auto it = findEntityById(producers, id);
        if (it != producers.end()) {
            it->setName(name);
            it->setAddress(address);
        }
    }

    void searchCustomer(int id) const {
        auto it = std::find_if(customers.begin(), customers.end(), 
            [id](const Customer& customer) { return customer.getId() == id; }
        );
        if (it != customers.end()) {
            it->display();
        } else {
            std::cout << "Customer not found" << std::endl;
        }
    }

    void searchProducer(int id) const {
        auto it = std::find_if(producers.begin(), producers.end(), 
            [id](const Producer& producer) { return producer.getId() == id; }
        );
        if (it != producers.end()) {
            it->display();
        } else {
            std::cout << "Producer not found" << std::endl;
        }
    }

    void displayCustomers() const {
        for (const auto& customer : customers) {
            customer.display();
        }
    }

    void displayProducers() const {
        for (const auto& producer : producers) {
            producer.display();
        }
    }
};

int main() {
    ElectricalGridSystem gridSystem;
    gridSystem.addCustomer(1, "John Doe", "123 Elm Street");
    gridSystem.addProducer(1, "Solar Co", "321 Solar Way");
    gridSystem.displayCustomers();
    gridSystem.displayProducers();
    gridSystem.searchCustomer(1);
    gridSystem.updateCustomer(1, "Jane Doe", "456 Maple Street");
    gridSystem.searchCustomer(1);
    gridSystem.deleteCustomer(1);
    gridSystem.displayCustomers();
    return 0;
}