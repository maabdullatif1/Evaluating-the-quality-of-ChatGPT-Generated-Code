#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Entity {
protected:
    string name;
    string address;
    string id;
public:
    Entity(string n, string a, string i) : name(n), address(a), id(i) {}
    string getId() { return id; }
    virtual void display() = 0;
    virtual void update(string n, string a) {
        name = n;
        address = a;
    }
};

class Customer : public Entity {
public:
    Customer(string n, string a, string i) : Entity(n, a, i){}
    void display() {
        cout << "Customer Name: " << name << ", Address: " << address << ", ID: " << id << endl;
    }
};

class Producer : public Entity {
public:
    Producer(string n, string a, string i) : Entity(n, a, i){}
    void display() {
        cout << "Producer Name: " << name << ", Address: " << address << ", ID: " << id << endl;
    }
};

class GridSystem {
private:
    vector<Customer> customers;
    vector<Producer> producers;
public:
    void addCustomer(string n, string a, string i) {
        customers.push_back(Customer(n, a, i));
    }
    
    void addProducer(string n, string a, string i) {
        producers.push_back(Producer(n, a, i));
    }
    
    void deleteCustomer(string i) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == i) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void deleteProducer(string i) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getId() == i) {
                producers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(string i, string n, string a) {
        for (auto &customer : customers) {
            if (customer.getId() == i) {
                customer.update(n, a);
                break;
            }
        }
    }
    
    void updateProducer(string i, string n, string a) {
        for (auto &producer : producers) {
            if (producer.getId() == i) {
                producer.update(n, a);
                break;
            }
        }
    }
    
    void searchCustomer(string i) {
        for (auto &customer : customers) {
            if (customer.getId() == i) {
                customer.display();
                return;
            }
        }
        cout << "Customer not found." << endl;
    }
    
    void searchProducer(string i) {
        for (auto &producer : producers) {
            if (producer.getId() == i) {
                producer.display();
                return;
            }
        }
        cout << "Producer not found." << endl;
    }
    
    void displayCustomers() {
        for (auto &customer : customers) {
            customer.display();
        }
    }
    
    void displayProducers() {
        for (auto &producer : producers) {
            producer.display();
        }
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer("Alice", "123 Elm St", "C001");
    grid.addProducer("SolarCorp", "45 Sun Blvd", "P001");
    grid.displayCustomers();
    grid.displayProducers();
    grid.updateCustomer("C001", "Alice Smith", "123 Elm St, Apt 4");
    grid.searchCustomer("C001");
    grid.deleteProducer("P001");
    grid.searchProducer("P001");
    return 0;
}