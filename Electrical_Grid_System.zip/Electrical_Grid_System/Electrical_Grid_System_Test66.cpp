#include <iostream>
#include <vector>
#include <string>

class Participant {
protected:
    std::string id;
    std::string name;
    std::string type;
public:
    Participant(std::string id, std::string name, std::string type) : id(id), name(name), type(type) {}
    std::string getId() { return id; }
    std::string getName() { return name; }
    std::string getType() { return type; }
    virtual void display() = 0;
};

class Customer : public Participant {
public:
    Customer(std::string id, std::string name) : Participant(id, name, "Customer") {}
    void display() {
        std::cout << "Customer ID: " << id << ", Name: " << name << "\n";
    }
};

class Producer : public Participant {
public:
    Producer(std::string id, std::string name) : Participant(id, name, "Producer") {}
    void display() {
        std::cout << "Producer ID: " << id << ", Name: " << name << "\n";
    }
};

class GridSystem {
    std::vector<Participant*> participants;
public:
    void addParticipant(Participant* p) {
        participants.push_back(p);
    }
    
    void deleteParticipant(std::string id) {
        for (size_t i = 0; i < participants.size(); ++i) {
            if (participants[i]->getId() == id) {
                delete participants[i];
                participants.erase(participants.begin() + i);
                break;
            }
        }
    }

    void updateParticipant(std::string id, std::string newName) {
        for (auto& p : participants) {
            if (p->getId() == id) {
                p->name = newName;
                break;
            }
        }
    }

    Participant* searchParticipant(std::string id) {
        for (auto& p : participants) {
            if (p->getId() == id) {
                return p;
            }
        }
        return nullptr;
    }

    void displayParticipants() {
        for (auto& p : participants) {
            p->display();
        }
    }

    ~GridSystem() {
        for (auto& p : participants) {
            delete p;
        }
    }
};

int main() {
    GridSystem grid;
    grid.addParticipant(new Customer("C001", "Customer 1"));
    grid.addParticipant(new Producer("P001", "Producer 1"));
    
    grid.displayParticipants();
    
    grid.updateParticipant("C001", "Customer Updated");
    Participant* p = grid.searchParticipant("C001");
    if (p) {
        p->display();
    }
    
    grid.deleteParticipant("P001");
    grid.displayParticipants();
    
    return 0;
}