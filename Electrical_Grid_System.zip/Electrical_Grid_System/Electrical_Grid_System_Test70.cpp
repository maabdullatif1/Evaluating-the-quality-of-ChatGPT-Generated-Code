#include <iostream>
#include <string>
#include <vector>

class Entity {
protected:
    int id;
    std::string name;
    std::string address;

public:
    Entity(int i, std::string n, std::string a) : id(i), name(n), address(a) {}
    virtual void display() const {
        std::cout << "ID: " << id << ", Name: " << name << ", Address: " << address;
    }
    virtual int getId() const { return id; }
    virtual void update(std::string n, std::string a) {
        name = n;
        address = a;
    }
    virtual ~Entity() {}
};

class Customer : public Entity {
public:
    Customer(int i, std::string n, std::string a) : Entity(i, n, a) {}
    void display() const override {
        std::cout << "Customer - ";
        Entity::display();
        std::cout << std::endl;
    }
};

class Producer : public Entity {
public:
    Producer(int i, std::string n, std::string a) : Entity(i, n, a) {}
    void display() const override {
        std::cout << "Producer - ";
        Entity::display();
        std::cout << std::endl;
    }
};

class ElectricalGridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;

    template<typename T>
    void displayEntities(const std::vector<T>& entities) const {
        for (const auto& entity : entities) {
            entity.display();
        }
    }

    template<typename T>
    void addEntity(std::vector<T>& entities, T entity) {
        entities.push_back(entity);
    }

    template<typename T>
    bool deleteEntity(std::vector<T>& entities, int id) {
        for (size_t i = 0; i < entities.size(); ++i) {
            if (entities[i].getId() == id) {
                entities.erase(entities.begin() + i);
                return true;
            }
        }
        return false;
    }

    template<typename T>
    T* searchEntity(std::vector<T>& entities, int id) {
        for (size_t i = 0; i < entities.size(); ++i) {
            if (entities[i].getId() == id) {
                return &entities[i];
            }
        }
        return nullptr;
    }

public:
    void addCustomer(int id, std::string name, std::string address) {
        addEntity(customers, Customer(id, name, address));
    }

    void addProducer(int id, std::string name, std::string address) {
        addEntity(producers, Producer(id, name, address));
    }

    bool deleteCustomer(int id) {
        return deleteEntity(customers, id);
    }

    bool deleteProducer(int id) {
        return deleteEntity(producers, id);
    }

    void updateCustomer(int id, std::string name, std::string address) {
        Customer* customer = searchEntity(customers, id);
        if (customer) {
            customer->update(name, address);
        }
    }

    void updateProducer(int id, std::string name, std::string address) {
        Producer* producer = searchEntity(producers, id);
        if (producer) {
            producer->update(name, address);
        }
    }

    void searchCustomer(int id) const {
        const Customer* customer = searchEntity(customers, id);
        if (customer) {
            customer->display();
        }
    }

    void searchProducer(int id) const {
        const Producer* producer = searchEntity(producers, id);
        if (producer) {
            producer->display();
        }
    }

    void displayAllCustomers() const {
        displayEntities(customers);
    }

    void displayAllProducers() const {
        displayEntities(producers);
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addCustomer(1, "John Doe", "123 Elm St");
    grid.addProducer(1, "Power Inc", "456 Oak St");
    std::cout << "All Customers:" << std::endl;
    grid.displayAllCustomers();
    std::cout << "All Producers:" << std::endl;
    grid.displayAllProducers();
    return 0;
}