#include <iostream>
#include <vector>
#include <string>

class Participant {
public:
    std::string id;
    std::string name;
    std::string type;
    double powerUsageOrGeneration;

    Participant(std::string id, std::string name, std::string type, double power)
        : id(id), name(name), type(type), powerUsageOrGeneration(power) {}
};

class ElectricalGrid {
    std::vector<Participant> participants;

public:
    void addParticipant(const std::string& id, const std::string& name, const std::string& type, double power) {
        participants.emplace_back(id, name, type, power);
    }

    void deleteParticipant(const std::string& id) {
        for (auto it = participants.begin(); it != participants.end(); ++it) {
            if (it->id == id) {
                participants.erase(it);
                return;
            }
        }
    }

    void updateParticipant(const std::string& id, const std::string& name, const std::string& type, double power) {
        for (auto& participant : participants) {
            if (participant.id == id) {
                participant.name = name;
                participant.type = type;
                participant.powerUsageOrGeneration = power;
                return;
            }
        }
    }

    Participant* searchParticipant(const std::string& id) {
        for (auto& participant : participants) {
            if (participant.id == id) {
                return &participant;
            }
        }
        return nullptr;
    }

    void displayParticipants() {
        for (const auto& participant : participants) {
            std::cout << "ID: " << participant.id
                      << ", Name: " << participant.name
                      << ", Type: " << participant.type
                      << ", Power: " << participant.powerUsageOrGeneration << "\n";
        }
    }
};

int main() {
    ElectricalGrid grid;
    grid.addParticipant("1", "John Doe", "Customer", 150.0);
    grid.addParticipant("2", "Green Energy", "Producer", 2000.0);
    grid.displayParticipants();

    grid.updateParticipant("1", "John Doe", "Customer", 175.0);
    grid.displayParticipants();

    Participant* searchResult = grid.searchParticipant("1");
    if (searchResult) {
        std::cout << "Found participant - ID: " << searchResult->id << ", Name: " << searchResult->name << "\n";
    }

    grid.deleteParticipant("1");
    grid.displayParticipants();

    return 0;
}