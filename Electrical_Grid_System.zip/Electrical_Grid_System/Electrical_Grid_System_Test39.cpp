#include <iostream>
#include <string>

struct Entity {
    std::string id;
    std::string name;
    std::string type;
};

class GridSystem {
    Entity customers[100];
    Entity producers[100];
    int customerCount;
    int producerCount;

public:
    GridSystem() : customerCount(0), producerCount(0) {}

    void addEntity(const std::string& id, const std::string& name, const std::string& type) {
        if (type == "customer" && customerCount < 100) {
            customers[customerCount++] = {id, name, type};
        } else if (type == "producer" && producerCount < 100) {
            producers[producerCount++] = {id, name, type};
        }
    }

    void deleteEntity(const std::string& id, const std::string& type) {
        if (type == "customer") {
            for (int i = 0; i < customerCount; ++i) {
                if (customers[i].id == id) {
                    for (int j = i; j < customerCount - 1; ++j) {
                        customers[j] = customers[j + 1];
                    }
                    --customerCount;
                    break;
                }
            }
        } else if (type == "producer") {
            for (int i = 0; i < producerCount; ++i) {
                if (producers[i].id == id) {
                    for (int j = i; j < producerCount - 1; ++j) {
                        producers[j] = producers[j + 1];
                    }
                    --producerCount;
                    break;
                }
            }
        }
    }

    void updateEntity(const std::string& id, const std::string& newName, const std::string& type) {
        if (type == "customer") {
            for (int i = 0; i < customerCount; ++i) {
                if (customers[i].id == id) {
                    customers[i].name = newName;
                    break;
                }
            }
        } else if (type == "producer") {
            for (int i = 0; i < producerCount; ++i) {
                if (producers[i].id == id) {
                    producers[i].name = newName;
                    break;
                }
            }
        }
    }

    Entity* searchEntity(const std::string& id, const std::string& type) {
        if (type == "customer") {
            for (int i = 0; i < customerCount; ++i) {
                if (customers[i].id == id) return &customers[i];
            }
        } else if (type == "producer") {
            for (int i = 0; i < producerCount; ++i) {
                if (producers[i].id == id) return &producers[i];
            }
        }
        return nullptr;
    }

    void displayEntities(const std::string& type) {
        if (type == "customer") {
            for (int i = 0; i < customerCount; ++i) {
                std::cout << "Customer ID: " << customers[i].id << ", Name: " << customers[i].name << "\n";
            }
        } else if (type == "producer") {
            for (int i = 0; i < producerCount; ++i) {
                std::cout << "Producer ID: " << producers[i].id << ", Name: " << producers[i].name << "\n";
            }
        }
    }
};

int main() {
    GridSystem grid;
    grid.addEntity("C001", "John Doe", "customer");
    grid.addEntity("P001", "ABC Corp", "producer");

    grid.displayEntities("customer");
    grid.displayEntities("producer");

    grid.updateEntity("C001", "Jane Doe", "customer");
    grid.updateEntity("P001", "XYZ Corp", "producer");

    grid.displayEntities("customer");
    grid.displayEntities("producer");

    grid.deleteEntity("C001", "customer");
    grid.deleteEntity("P001", "producer");

    grid.displayEntities("customer");
    grid.displayEntities("producer");

    return 0;
}