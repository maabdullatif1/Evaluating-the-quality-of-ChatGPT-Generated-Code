#include <iostream>
#include <vector>
#include <string>

struct Entity {
    std::string id;
    std::string name;
    std::string address;
    double electricityAmount;
};

class ElectricalGridSystem {
private:
    std::vector<Entity> customers;
    std::vector<Entity> producers;

    std::vector<Entity>& selectEntityType(const std::string& type) {
        return (type == "customer") ? customers : producers;
    }

public:
    void addEntity(const std::string& type, const std::string& id, const std::string& name, const std::string& address, double electricityAmount) {
        Entity entity = {id, name, address, electricityAmount};
        selectEntityType(type).push_back(entity);
    }

    void deleteEntity(const std::string& type, const std::string& id) {
        auto& entities = selectEntityType(type);
        entities.erase(
            std::remove_if(entities.begin(), entities.end(), [&id](const Entity& e) { return e.id == id; }),
            entities.end()
        );
    }

    void updateEntity(const std::string& type, const std::string& id, const std::string& name, const std::string& address, double electricityAmount) {
        for (auto& e : selectEntityType(type)) {
            if (e.id == id) {
                e.name = name;
                e.address = address;
                e.electricityAmount = electricityAmount;
                break;
            }
        }
    }

    void searchEntity(const std::string& type, const std::string& id) {
        for (const auto& e : selectEntityType(type)) {
            if (e.id == id) {
                std::cout << "ID: " << e.id << ", Name: " << e.name << ", Address: " << e.address << ", Electricity Amount: " << e.electricityAmount << "\n";
                return;
            }
        }
        std::cout << "Entity not found\n";
    }

    void displayEntities(const std::string& type) {
        const auto& entities = selectEntityType(type);
        for (const auto& e : entities) {
            std::cout << "ID: " << e.id << ", Name: " << e.name << ", Address: " << e.address << ", Electricity Amount: " << e.electricityAmount << "\n";
        }
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addEntity("customer", "C001", "Alice", "123 Main St", 300.5);
    grid.addEntity("producer", "P001", "WindFarm A", "Windy Valley", 5000.0);

    grid.displayEntities("customer");
    grid.displayEntities("producer");

    grid.updateEntity("customer", "C001", "Alice B", "123 Main St", 320.5);
    grid.searchEntity("customer", "C001");

    grid.deleteEntity("producer", "P001");
    grid.displayEntities("producer");

    return 0;
}