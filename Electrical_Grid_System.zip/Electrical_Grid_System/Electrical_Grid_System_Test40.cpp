#include <iostream>
#include <vector>
#include <string>

class Entity {
public:
    std::string id;
    std::string name;
    std::string address;

    Entity(const std::string& id, const std::string& name, const std::string& address)
        : id(id), name(name), address(address) {}

    virtual void display() const = 0;
};

class Customer : public Entity {
public:
    Customer(const std::string& id, const std::string& name, const std::string& address)
        : Entity(id, name, address) {}

    void display() const override {
        std::cout << "Customer ID: " << id << ", Name: " << name << ", Address: " << address << std::endl;
    }
};

class Producer : public Entity {
public:
    Producer(const std::string& id, const std::string& name, const std::string& address)
        : Entity(id, name, address) {}

    void display() const override {
        std::cout << "Producer ID: " << id << ", Name: " << name << ", Address: " << address << std::endl;
    }
};

class GridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;

public:
    void addCustomer(const std::string& id, const std::string& name, const std::string& address) {
        customers.emplace_back(id, name, address);
    }

    void addProducer(const std::string& id, const std::string& name, const std::string& address) {
        producers.emplace_back(id, name, address);
    }

    void deleteCustomer(const std::string& id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }

    void deleteProducer(const std::string& id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->id == id) {
                producers.erase(it);
                break;
            }
        }
    }

    void updateCustomer(const std::string& id, const std::string& name, const std::string& address) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                break;
            }
        }
    }

    void updateProducer(const std::string& id, const std::string& name, const std::string& address) {
        for (auto& producer : producers) {
            if (producer.id == id) {
                producer.name = name;
                producer.address = address;
                break;
            }
        }
    }

    void searchCustomer(const std::string& id) const {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                customer.display();
                return;
            }
        }
        std::cout << "Customer not found." << std::endl;
    }

    void searchProducer(const std::string& id) const {
        for (const auto& producer : producers) {
            if (producer.id == id) {
                producer.display();
                return;
            }
        }
        std::cout << "Producer not found." << std::endl;
    }

    void displayAllCustomers() const {
        for (const auto& customer : customers) {
            customer.display();
        }
    }

    void displayAllProducers() const {
        for (const auto& producer : producers) {
            producer.display();
        }
    }
};

int main() {
    GridSystem grid;

    grid.addCustomer("C001", "John Doe", "123 Elm St");
    grid.addProducer("P001", "Solar Inc", "456 Oak St");

    grid.displayAllCustomers();
    grid.displayAllProducers();

    grid.updateCustomer("C001", "John Smith", "123 Elm St");
    grid.searchCustomer("C001");

    grid.deleteProducer("P001");
    grid.searchProducer("P001");

    return 0;
}