#include <iostream>
#include <vector>
#include <string>

class Entity {
public:
    std::string name;
    std::string address;
    int id;
    
    Entity(std::string n, std::string a, int i) : name(n), address(a), id(i) {}
};

class Customer : public Entity {
public:
    double consumption;
    Customer(std::string n, std::string a, int i, double c) : Entity(n, a, i), consumption(c) {}
};

class Producer : public Entity {
public:
    double production;
    Producer(std::string n, std::string a, int i, double p) : Entity(n, a, i), production(p) {}
};

class ElectricalGridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;
    
    template <typename T>
    typename std::vector<T>::iterator findEntityById(std::vector<T>& entities, int id) {
        return std::find_if(entities.begin(), entities.end(), [id](T& entity) { return entity.id == id; });
    }
    
public:
    void addCustomer(std::string name, std::string address, int id, double consumption) {
        customers.push_back(Customer(name, address, id, consumption));
    }
    
    void addProducer(std::string name, std::string address, int id, double production) {
        producers.push_back(Producer(name, address, id, production));
    }

    void deleteCustomer(int id) {
        auto it = findEntityById(customers, id);
        if (it != customers.end()) customers.erase(it);
    }

    void deleteProducer(int id) {
        auto it = findEntityById(producers, id);
        if (it != producers.end()) producers.erase(it);
    }

    void updateCustomer(int id, std::string name, std::string address, double consumption) {
        auto it = findEntityById(customers, id);
        if (it != customers.end()) {
            (*it).name = name;
            (*it).address = address;
            (*it).consumption = consumption;
        }
    }

    void updateProducer(int id, std::string name, std::string address, double production) {
        auto it = findEntityById(producers, id);
        if (it != producers.end()) {
            (*it).name = name;
            (*it).address = address;
            (*it).production = production;
        }
    }

    void searchCustomer(int id) {
        auto it = findEntityById(customers, id);
        if (it != customers.end()) {
            std::cout << "Customer Found: " << it->name << ", " << it->address << ", Consumption: " << it->consumption << "\n";
        } else {
            std::cout << "Customer not found.\n";
        }
    }

    void searchProducer(int id) {
        auto it = findEntityById(producers, id);
        if (it != producers.end()) {
            std::cout << "Producer Found: " << it->name << ", " << it->address << ", Production: " << it->production << "\n";
        } else {
            std::cout << "Producer not found.\n";
        }
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer: " << customer.name << ", " << customer.address << ", Consumption: " << customer.consumption << "\n";
        }
    }

    void displayProducers() {
        for (const auto& producer : producers) {
            std::cout << "Producer: " << producer.name << ", " << producer.address << ", Production: " << producer.production << "\n";
        }
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addCustomer("John Doe", "123 Elm St", 101, 150.5);
    grid.addProducer("Solar Inc.", "456 Solar St", 201, 1000.0);
    grid.displayCustomers();
    grid.displayProducers();
    grid.updateCustomer(101, "Johnathan Doe", "123 Elm St", 200.0);
    grid.searchCustomer(101);
    grid.deleteCustomer(101);
    grid.displayCustomers();
    return 0;
}