#include <iostream>
#include <vector>
#include <string>

struct Customer {
    std::string id;
    std::string name;
    double consumption;
};

struct Producer {
    std::string id;
    std::string name;
    double production;
};

class ElectricalGrid {
    std::vector<Customer> customers;
    std::vector<Producer> producers;

public:
    void addCustomer(const std::string& id, const std::string& name, double consumption) {
        customers.push_back({id, name, consumption});
    }

    void addProducer(const std::string& id, const std::string& name, double production) {
        producers.push_back({id, name, production});
    }

    void deleteCustomer(const std::string& id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void deleteProducer(const std::string& id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->id == id) {
                producers.erase(it);
                return;
            }
        }
    }

    void updateCustomer(const std::string& id, const std::string& name, double consumption) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.consumption = consumption;
                return;
            }
        }
    }

    void updateProducer(const std::string& id, const std::string& name, double production) {
        for (auto& producer : producers) {
            if (producer.id == id) {
                producer.name = name;
                producer.production = production;
                return;
            }
        }
    }

    void searchCustomer(const std::string& id) {
        for (const auto& customer : customers) {
            if (customer.id == id) {
                std::cout << "Customer found: ID=" << customer.id << ", Name=" << customer.name << ", Consumption=" << customer.consumption << std::endl;
                return;
            }
        }
        std::cout << "Customer not found." << std::endl;
    }

    void searchProducer(const std::string& id) {
        for (const auto& producer : producers) {
            if (producer.id == id) {
                std::cout << "Producer found: ID=" << producer.id << ", Name=" << producer.name << ", Production=" << producer.production << std::endl;
                return;
            }
        }
        std::cout << "Producer not found." << std::endl;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Consumption: " << customer.consumption << std::endl;
        }
    }

    void displayProducers() {
        for (const auto& producer : producers) {
            std::cout << "ID: " << producer.id << ", Name: " << producer.name << ", Production: " << producer.production << std::endl;
        }
    }
};

int main() {
    ElectricalGrid grid;

    grid.addCustomer("C001", "Alice", 150.5);
    grid.addCustomer("C002", "Bob", 300.0);
    grid.addProducer("P001", "Electric Co.", 5000.0);
    
    grid.displayCustomers();
    grid.displayProducers();

    grid.searchCustomer("C002");
    grid.updateCustomer("C002", "Bob Smith", 330.0);
    grid.searchCustomer("C002");

    grid.deleteCustomer("C001");
    grid.displayCustomers();

    return 0;
}