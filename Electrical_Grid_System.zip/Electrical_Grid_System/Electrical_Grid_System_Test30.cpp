#include <iostream>
#include <vector>
#include <string>

class User {
public:
    std::string name;
    std::string id;
    std::string address;

    User(std::string name, std::string id, std::string address)
        : name(name), id(id), address(address) {}
};

class Customer : public User {
public:
    double consumption;

    Customer(std::string name, std::string id, std::string address, double consumption)
        : User(name, id, address), consumption(consumption) {}
};

class Producer : public User {
public:
    double production;

    Producer(std::string name, std::string id, std::string address, double production)
        : User(name, id, address), production(production) {}
};

class ElectricalGridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;

public:
    void addCustomer(std::string name, std::string id, std::string address, double consumption) {
        customers.push_back(Customer(name, id, address, consumption));
    }

    void deleteCustomer(std::string id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void updateCustomer(std::string id, std::string name, std::string address, double consumption) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                customer.consumption = consumption;
                return;
            }
        }
    }

    Customer* searchCustomer(std::string id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "Customer ID: " << customer.id
                      << ", Name: " << customer.name
                      << ", Address: " << customer.address
                      << ", Consumption: " << customer.consumption << std::endl;
        }
    }

    void addProducer(std::string name, std::string id, std::string address, double production) {
        producers.push_back(Producer(name, id, address, production));
    }

    void deleteProducer(std::string id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->id == id) {
                producers.erase(it);
                return;
            }
        }
    }

    void updateProducer(std::string id, std::string name, std::string address, double production) {
        for (auto &producer : producers) {
            if (producer.id == id) {
                producer.name = name;
                producer.address = address;
                producer.production = production;
                return;
            }
        }
    }

    Producer* searchProducer(std::string id) {
        for (auto &producer : producers) {
            if (producer.id == id) {
                return &producer;
            }
        }
        return nullptr;
    }

    void displayProducers() {
        for (const auto &producer : producers) {
            std::cout << "Producer ID: " << producer.id
                      << ", Name: " << producer.name
                      << ", Address: " << producer.address
                      << ", Production: " << producer.production << std::endl;
        }
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addCustomer("Alice", "C001", "123 Main St", 150.0);
    grid.addProducer("Solar Inc", "P001", "456 Solar Rd", 1000.0);
    std::cout << "Customers:" << std::endl;
    grid.displayCustomers();
    std::cout << "Producers:" << std::endl;
    grid.displayProducers();
    return 0;
}