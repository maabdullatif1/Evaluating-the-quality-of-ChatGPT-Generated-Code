#include <iostream>
#include <string>
using namespace std;

struct Customer {
    int id;
    string name;
    string address;
    double consumption;
    Customer* next;
};

struct Producer {
    int id;
    string name;
    string location;
    double production;
    Producer* next;
};

class ElectricalGridSystem {
    Customer* customers;
    Producer* producers;
    int customerIdCounter;
    int producerIdCounter;
    
public:
    ElectricalGridSystem() : customers(nullptr), producers(nullptr), customerIdCounter(1), producerIdCounter(1) {}

    void addCustomer(const string& name, const string& address, double consumption) {
        Customer* newCustomer = new Customer{customerIdCounter++, name, address, consumption, customers};
        customers = newCustomer;
    }

    void deleteCustomer(int id) {
        Customer** current = &customers;
        while (*current && (*current)->id != id) {
            current = &((*current)->next);
        }
        if (*current) {
            Customer* temp = *current;
            *current = (*current)->next;
            delete temp;
        }
    }

    void updateCustomer(int id, const string& name, const string& address, double consumption) {
        Customer* current = customers;
        while (current && current->id != id) {
            current = current->next;
        }
        if (current) {
            current->name = name;
            current->address = address;
            current->consumption = consumption;
        }
    }

    void searchCustomer(int id) {
        Customer* current = customers;
        while (current && current->id != id) {
            current = current->next;
        }
        if (current) {
            cout << "Customer ID: " << current->id << ", Name: " << current->name 
                 << ", Address: " << current->address << ", Consumption: " << current->consumption << endl;
        } else {
            cout << "Customer not found.\n";
        }
    }

    void displayCustomers() {
        Customer* current = customers;
        while (current) {
            cout << "Customer ID: " << current->id << ", Name: " << current->name 
                 << ", Address: " << current->address << ", Consumption: " << current->consumption << endl;
            current = current->next;
        }
    }

    void addProducer(const string& name, const string& location, double production) {
        Producer* newProducer = new Producer{producerIdCounter++, name, location, production, producers};
        producers = newProducer;
    }

    void deleteProducer(int id) {
        Producer** current = &producers;
        while (*current && (*current)->id != id) {
            current = &((*current)->next);
        }
        if (*current) {
            Producer* temp = *current;
            *current = (*current)->next;
            delete temp;
        }
    }

    void updateProducer(int id, const string& name, const string& location, double production) {
        Producer* current = producers;
        while (current && current->id != id) {
            current = current->next;
        }
        if (current) {
            current->name = name;
            current->location = location;
            current->production = production;
        }
    }

    void searchProducer(int id) {
        Producer* current = producers;
        while (current && current->id != id) {
            current = current->next;
        }
        if (current) {
            cout << "Producer ID: " << current->id << ", Name: " << current->name 
                 << ", Location: " << current->location << ", Production: " << current->production << endl;
        } else {
            cout << "Producer not found.\n";
        }
    }

    void displayProducers() {
        Producer* current = producers;
        while (current) {
            cout << "Producer ID: " << current->id << ", Name: " << current->name 
                 << ", Location: " << current->location << ", Production: " << current->production << endl;
            current = current->next;
        }
    }
};

int main() {
    ElectricalGridSystem grid;
    
    grid.addCustomer("John Doe", "123 Elm St", 150.5);
    grid.addCustomer("Jane Smith", "456 Oak St", 200.75);
    grid.displayCustomers();
    grid.updateCustomer(1, "John Doe", "123 Elm St", 180.6);
    grid.searchCustomer(1);
    grid.deleteCustomer(2);
    grid.displayCustomers();
    
    grid.addProducer("Solar Farm A", "North Valley", 5000.0);
    grid.addProducer("Wind Turbine B", "South Ridge", 3000.0);
    grid.displayProducers();
    grid.updateProducer(1, "Solar Farm A", "North Valley", 5500.0);
    grid.searchProducer(1);
    grid.deleteProducer(2);
    grid.displayProducers();
    
    return 0;
}