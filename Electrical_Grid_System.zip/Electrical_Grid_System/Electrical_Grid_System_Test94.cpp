#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Person {
    string name;
    string id;
};

class ElectricalGridSystem {
    vector<Person> customers;
    vector<Person> producers;

public:
    void addCustomer(const string& name, const string& id) {
        customers.push_back({name, id});
    }

    void addProducer(const string& name, const string& id) {
        producers.push_back({name, id});
    }

    void deleteCustomer(const string& id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void deleteProducer(const string& id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->id == id) {
                producers.erase(it);
                return;
            }
        }
    }

    void updateCustomer(const string& id, const string& newName) {
        for (auto& c : customers) {
            if (c.id == id) {
                c.name = newName;
                return;
            }
        }
    }

    void updateProducer(const string& id, const string& newName) {
        for (auto& p : producers) {
            if (p.id == id) {
                p.name = newName;
                return;
            }
        }
    }

    Person* searchCustomer(const string& id) {
        for (auto& c : customers) {
            if (c.id == id) {
                return &c;
            }
        }
        return nullptr;
    }

    Person* searchProducer(const string& id) {
        for (auto& p : producers) {
            if (p.id == id) {
                return &p;
            }
        }
        return nullptr;
    }

    void displayCustomers() const {
        for (const auto& c : customers) {
            cout << "Customer Name: " << c.name << ", ID: " << c.id << endl;
        }
    }

    void displayProducers() const {
        for (const auto& p : producers) {
            cout << "Producer Name: " << p.name << ", ID: " << p.id << endl;
        }
    }
};

int main() {
    ElectricalGridSystem system;

    system.addCustomer("Alice", "C001");
    system.addCustomer("Bob", "C002");

    system.addProducer("PowerCo", "P001");
    system.addProducer("GreenEnergy", "P002");

    system.displayCustomers();
    system.displayProducers();

    system.updateCustomer("C001", "Alice Smith");
    system.updateProducer("P002", "Green Energy Inc");

    system.displayCustomers();
    system.displayProducers();

    system.deleteCustomer("C002");
    system.deleteProducer("P001");

    system.displayCustomers();
    system.displayProducers();

    return 0;
}