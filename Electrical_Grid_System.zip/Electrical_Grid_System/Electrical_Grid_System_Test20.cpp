#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Entity {
protected:
    int id;
    string name;
    int powerConsumptionOrSupply;
public:
    Entity(int id, string name, int power) : id(id), name(name), powerConsumptionOrSupply(power) {}
    int getId() { return id; }
    string getName() { return name; }
    int getPower() { return powerConsumptionOrSupply; }
    void setName(string newName) { name = newName; }
    void setPower(int newPower) { powerConsumptionOrSupply = newPower; }
};

class Customer : public Entity {
public:
    Customer(int id, string name, int consumption) : Entity(id, name, consumption) {}
};

class Producer : public Entity {
public:
    Producer(int id, string name, int supply) : Entity(id, name, supply) {}
};

class GridSystem {
    vector<Customer> customers;
    vector<Producer> producers;

    template <typename T>
    void displayEntities(const vector<T>& entities) {
        for (const auto& entity : entities) {
            cout << "ID: " << entity.getId()
                 << ", Name: " << entity.getName()
                 << ", Power: " << entity.getPower() << endl;
        }
    }

    template <typename T>
    typename vector<T>::iterator findEntityById(vector<T>& entities, int id) {
        return find_if(entities.begin(), entities.end(), [id](const T& entity) { return entity.getId() == id; });
    }

public:
    void addCustomer(int id, string name, int consumption) {
        customers.emplace_back(id, name, consumption);
    }

    void addProducer(int id, string name, int supply) {
        producers.emplace_back(id, name, supply);
    }

    void deleteCustomer(int id) {
        auto it = findEntityById(customers, id);
        if (it != customers.end()) customers.erase(it);
    }

    void deleteProducer(int id) {
        auto it = findEntityById(producers, id);
        if (it != producers.end()) producers.erase(it);
    }

    void updateCustomer(int id, string name, int consumption) {
        auto it = findEntityById(customers, id);
        if (it != customers.end()) {
            it->setName(name);
            it->setPower(consumption);
        }
    }

    void updateProducer(int id, string name, int supply) {
        auto it = findEntityById(producers, id);
        if (it != producers.end()) {
            it->setName(name);
            it->setPower(supply);
        }
    }

    Customer* searchCustomer(int id) {
        auto it = findEntityById(customers, id);
        return (it != customers.end()) ? &(*it) : nullptr;
    }

    Producer* searchProducer(int id) {
        auto it = findEntityById(producers, id);
        return (it != producers.end()) ? &(*it) : nullptr;
    }

    void displayCustomers() {
        displayEntities(customers);
    }

    void displayProducers() {
        displayEntities(producers);
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer(1, "Alice", 100);
    grid.addCustomer(2, "Bob", 200);
    grid.addProducer(1, "Electric Co", 500);
    grid.displayCustomers();
    grid.displayProducers();
    grid.updateCustomer(1, "Alice Updated", 150);
    grid.deleteProducer(1);
    grid.displayCustomers();
    grid.displayProducers();
    return 0;
}