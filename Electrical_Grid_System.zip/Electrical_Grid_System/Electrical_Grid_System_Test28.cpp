#include <iostream>
#include <vector>
#include <string>

class Entity {
protected:
    std::string name;
    std::string id;
public:
    Entity(std::string n, std::string i) : name(n), id(i) {}
    std::string getName() { return name; }
    std::string getId() { return id; }
    void setName(std::string n) { name = n; }
    void setId(std::string i) { id = i; }
    virtual void display() = 0;
};

class Customer : public Entity {
public:
    Customer(std::string n, std::string i) : Entity(n, i) {}
    void display() override {
        std::cout << "Customer Name: " << name << ", ID: " << id << "\n";
    }
};

class Producer : public Entity {
public:
    Producer(std::string n, std::string i) : Entity(n, i) {}
    void display() override {
        std::cout << "Producer Name: " << name << ", ID: " << id << "\n";
    }
};

class GridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;
public:
    void addCustomer(Customer c) { customers.push_back(c); }
    void deleteCustomer(std::string id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == id) {
                customers.erase(it);
                break;
            }
        }
    }
    void updateCustomer(std::string id, std::string newName) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                customer.setName(newName);
                break;
            }
        }
    }
    Customer* searchCustomer(std::string id) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                return &customer;
            }
        }
        return nullptr;
    }
    void displayCustomers() {
        for (const auto& customer : customers)
            customer.display();
    }
    void addProducer(Producer p) { producers.push_back(p); }
    void deleteProducer(std::string id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getId() == id) {
                producers.erase(it);
                break;
            }
        }
    }
    void updateProducer(std::string id, std::string newName) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                producer.setName(newName);
                break;
            }
        }
    }
    Producer* searchProducer(std::string id) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                return &producer;
            }
        }
        return nullptr;
    }
    void displayProducers() {
        for (const auto& producer : producers)
            producer.display();
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer(Customer("Alice", "C001"));
    grid.addProducer(Producer("PowerCo", "P001"));
    grid.displayCustomers();
    grid.displayProducers();
    return 0;
}