#include <iostream>
#include <vector>
#include <string>

struct Entity {
    std::string name;
    std::string type;
    double power;
    int id;
};

class ElectricalGridSystem {
    std::vector<Entity> entities;
    int next_id = 1;

    int findEntityById(int id) {
        for (int i = 0; i < entities.size(); i++) {
            if (entities[i].id == id) return i;
        }
        return -1;
    }

    int findEntityByName(const std::string& name) {
        for (int i = 0; i < entities.size(); i++) {
            if (entities[i].name == name) return i;
        }
        return -1;
    }

public:
    void addEntity(const std::string& name, const std::string& type, double power) {
        Entity entity = {name, type, power, next_id++};
        entities.push_back(entity);
    }

    void deleteEntity(int id) {
        int index = findEntityById(id);
        if (index != -1) {
            entities.erase(entities.begin() + index);
        }
    }

    void updateEntity(int id, const std::string& name, const std::string& type, double power) {
        int index = findEntityById(id);
        if (index != -1) {
            entities[index] = {name, type, power, id};
        }
    }

    void searchEntity(const std::string& name) {
        int index = findEntityByName(name);
        if (index != -1) {
            std::cout << "ID: " << entities[index].id
                      << ", Name: " << entities[index].name
                      << ", Type: " << entities[index].type
                      << ", Power: " << entities[index].power << std::endl;
        } else {
            std::cout << "Entity not found" << std::endl;
        }
    }

    void displayAllEntities() {
        for (const auto& entity : entities) {
            std::cout << "ID: " << entity.id
                      << ", Name: " << entity.name
                      << ", Type: " << entity.type
                      << ", Power: " << entity.power << std::endl;
        }
    }
};

int main() {
    ElectricalGridSystem grid;
    grid.addEntity("CustomerA", "Customer", 100.5);
    grid.addEntity("ProducerA", "Producer", 500.0);
    grid.displayAllEntities();
    grid.searchEntity("CustomerA");
    grid.updateEntity(1, "CustomerA_Updated", "Customer", 110.0);
    grid.displayAllEntities();
    grid.deleteEntity(1);
    grid.displayAllEntities();
    return 0;
}