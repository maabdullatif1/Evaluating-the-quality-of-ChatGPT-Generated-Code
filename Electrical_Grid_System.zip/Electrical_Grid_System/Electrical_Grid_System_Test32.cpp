#include <iostream>
#include <vector>
#include <string>

class Entity {
public:
    std::string id;
    std::string name;
    double power;

    Entity(const std::string& id, const std::string& name, double power)
        : id(id), name(name), power(power) {}
};

class GridSystem {
private:
    std::vector<Entity> customers;
    std::vector<Entity> producers;

    Entity* findEntityById(std::vector<Entity>& entities, const std::string& id) {
        for (auto& entity : entities) {
            if (entity.id == id) {
                return &entity;
            }
        }
        return nullptr;
    }

public:
    void addCustomer(const std::string& id, const std::string& name, double power) {
        customers.emplace_back(id, name, power);
    }

    void addProducer(const std::string& id, const std::string& name, double power) {
        producers.emplace_back(id, name, power);
    }

    bool deleteCustomer(const std::string& id) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].id == id) {
                customers.erase(customers.begin() + i);
                return true;
            }
        }
        return false;
    }

    bool deleteProducer(const std::string& id) {
        for (size_t i = 0; i < producers.size(); ++i) {
            if (producers[i].id == id) {
                producers.erase(producers.begin() + i);
                return true;
            }
        }
        return false;
    }

    bool updateCustomer(const std::string& id, const std::string& name, double power) {
        Entity* customer = findEntityById(customers, id);
        if (customer) {
            customer->name = name;
            customer->power = power;
            return true;
        }
        return false;
    }

    bool updateProducer(const std::string& id, const std::string& name, double power) {
        Entity* producer = findEntityById(producers, id);
        if (producer) {
            producer->name = name;
            producer->power = power;
            return true;
        }
        return false;
    }

    Entity* searchCustomerById(const std::string& id) {
        return findEntityById(customers, id);
    }

    Entity* searchProducerById(const std::string& id) {
        return findEntityById(producers, id);
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name << ", Power: " << customer.power << '\n';
        }
    }

    void displayProducers() {
        for (const auto& producer : producers) {
            std::cout << "ID: " << producer.id << ", Name: " << producer.name << ", Power: " << producer.power << '\n';
        }
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer("C001", "CustomerA", 150.0);
    grid.addProducer("P001", "ProducerA", 500.0);
    grid.displayCustomers();
    grid.displayProducers();
    grid.updateCustomer("C001", "CustomerA1", 180.0);
    grid.updateProducer("P001", "ProducerA1", 600.0);
    grid.displayCustomers();
    grid.displayProducers();
    grid.deleteCustomer("C001");
    grid.deleteProducer("P001");
    grid.displayCustomers();
    grid.displayProducers();
    return 0;
}