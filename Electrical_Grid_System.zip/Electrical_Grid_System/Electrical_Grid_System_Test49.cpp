#include <iostream>
#include <vector>
#include <string>

class Customer {
    int id;
    std::string name;
    std::string address;
    double consumption;

public:
    Customer(int id, std::string name, std::string address, double consumption)
        : id(id), name(std::move(name)), address(std::move(address)), consumption(consumption) {}

    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getAddress() const { return address; }
    double getConsumption() const { return consumption; }

    void updateCustomer(std::string name, std::string address, double consumption) {
        this->name = std::move(name);
        this->address = std::move(address);
        this->consumption = consumption;
    }
};

class Producer {
    int id;
    std::string name;
    double production;

public:
    Producer(int id, std::string name, double production)
        : id(id), name(std::move(name)), production(production) {}

    int getId() const { return id; }
    std::string getName() const { return name; }
    double getProduction() const { return production; }

    void updateProducer(std::string name, double production) {
        this->name = std::move(name);
        this->production = production;
    }
};

class ElectricalGridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;

public:
    void addCustomer(int id, std::string name, std::string address, double consumption) {
        customers.emplace_back(id, std::move(name), std::move(address), consumption);
    }

    void deleteCustomer(int id) {
        customers.erase(std::remove_if(customers.begin(), customers.end(), [id](const Customer& c) { return c.getId() == id; }), customers.end());
    }

    void updateCustomer(int id, std::string name, std::string address, double consumption) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                customer.updateCustomer(std::move(name), std::move(address), consumption);
                break;
            }
        }
    }

    Customer* searchCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() const {
        for (const auto& customer : customers) {
            std::cout << "ID: " << customer.getId() << ", Name: " << customer.getName()
                      << ", Address: " << customer.getAddress() << ", Consumption: " << customer.getConsumption() << "\n";
        }
    }

    void addProducer(int id, std::string name, double production) {
        producers.emplace_back(id, std::move(name), production);
    }

    void deleteProducer(int id) {
        producers.erase(std::remove_if(producers.begin(), producers.end(), [id](const Producer& p) { return p.getId() == id; }), producers.end());
    }

    void updateProducer(int id, std::string name, double production) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                producer.updateProducer(std::move(name), production);
                break;
            }
        }
    }

    Producer* searchProducer(int id) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                return &producer;
            }
        }
        return nullptr;
    }

    void displayProducers() const {
        for (const auto& producer : producers) {
            std::cout << "ID: " << producer.getId() << ", Name: " << producer.getName()
                      << ", Production: " << producer.getProduction() << "\n";
        }
    }
};

int main() {
    ElectricalGridSystem system;
    system.addCustomer(1, "John Doe", "123 Elm St", 120.5);
    system.addProducer(1, "Solar Inc.", 1000.0);
    system.displayCustomers();
    system.displayProducers();
    return 0;
}