#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Entity {
protected:
    string id;
    string name;
    string address;

public:
    Entity(string id, string name, string address) : id(id), name(name), address(address) {}
    string getId() const { return id; }
    string getName() const { return name; }
    string getAddress() const { return address; }
    void setName(string newName) { name = newName; }
    void setAddress(string newAddress) { address = newAddress; }
};

class Customer : public Entity {
    double consumption;
    
public:
    Customer(string id, string name, string address, double consumption) 
    : Entity(id, name, address), consumption(consumption) {}
    double getConsumption() const { return consumption; }
    void setConsumption(double newConsumption) { consumption = newConsumption; }
};

class Producer : public Entity {
    double production;

public:
    Producer(string id, string name, string address, double production) 
    : Entity(id, name, address), production(production) {}
    double getProduction() const { return production; }
    void setProduction(double newProduction) { production = newProduction; }
};

class GridSystem {
    vector<Customer> customers;
    vector<Producer> producers;

public:
    void addCustomer(string id, string name, string address, double consumption) {
        customers.push_back(Customer(id, name, address, consumption));
    }
    
    void addProducer(string id, string name, string address, double production) {
        producers.push_back(Producer(id, name, address, production));
    }
    
    void deleteCustomer(string id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void deleteProducer(string id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getId() == id) {
                producers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(string id, string name, string address, double consumption) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                customer.setName(name);
                customer.setAddress(address);
                customer.setConsumption(consumption);
                break;
            }
        }
    }
    
    void updateProducer(string id, string name, string address, double production) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                producer.setName(name);
                producer.setAddress(address);
                producer.setProduction(production);
                break;
            }
        }
    }
    
    Customer* searchCustomer(string id) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                return &customer;
            }
        }
        return nullptr;
    }
    
    Producer* searchProducer(string id) {
        for (auto& producer : producers) {
            if (producer.getId() == id) {
                return &producer;
            }
        }
        return nullptr;
    }
    
    void displayCustomers() {
        for (const auto& customer : customers) {
            cout << "ID: " << customer.getId() << ", Name: " << customer.getName()
                 << ", Address: " << customer.getAddress() 
                 << ", Consumption: " << customer.getConsumption() << endl;
        }
    }
    
    void displayProducers() {
        for (const auto& producer : producers) {
            cout << "ID: " << producer.getId() << ", Name: " << producer.getName() 
                 << ", Address: " << producer.getAddress() 
                 << ", Production: " << producer.getProduction() << endl;
        }
    }
};

int main() {
    GridSystem grid;
    
    grid.addCustomer("C001", "Alice", "123 Lane", 500.0);
    grid.addCustomer("C002", "Bob", "456 Road", 300.0);
    grid.addProducer("P001", "Solar Inc.", "789 Ave", 1000.0);
    grid.addProducer("P002", "Wind Corp", "321 Blvd", 1500.0);
    
    grid.displayCustomers();
    grid.displayProducers();

    return 0;
}