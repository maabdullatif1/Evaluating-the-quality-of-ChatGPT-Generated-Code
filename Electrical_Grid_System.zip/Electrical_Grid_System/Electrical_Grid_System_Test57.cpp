#include <iostream>
#include <vector>
#include <string>

class Entity {
public:
    std::string id;
    std::string name;
    double power;
    
    Entity(const std::string& id_, const std::string& name_, double power_)
        : id(id_), name(name_), power(power_) {}
};

class GridSystem {
private:
    std::vector<Entity> customers;
    std::vector<Entity> producers;

public:
    void addCustomer(const std::string& id, const std::string& name, double power) {
        customers.emplace_back(id, name, power);
    }

    void deleteCustomer(const std::string& id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }

    void updateCustomer(const std::string& id, const std::string& name, double power) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.power = power;
                return;
            }
        }
    }

    Entity* searchCustomer(const std::string& id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name 
                      << ", Power: " << customer.power << std::endl;
        }
    }

    void addProducer(const std::string& id, const std::string& name, double power) {
        producers.emplace_back(id, name, power);
    }

    void deleteProducer(const std::string& id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->id == id) {
                producers.erase(it);
                return;
            }
        }
    }

    void updateProducer(const std::string& id, const std::string& name, double power) {
        for (auto& producer : producers) {
            if (producer.id == id) {
                producer.name = name;
                producer.power = power;
                return;
            }
        }
    }

    Entity* searchProducer(const std::string& id) {
        for (auto& producer : producers) {
            if (producer.id == id) {
                return &producer;
            }
        }
        return nullptr;
    }

    void displayProducers() {
        for (const auto& producer : producers) {
            std::cout << "Producer ID: " << producer.id << ", Name: " << producer.name 
                      << ", Power: " << producer.power << std::endl;
        }
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer("C001", "Alice", 150.0);
    grid.addCustomer("C002", "Bob", 200.0);
    grid.addProducer("P001", "Solar Inc.", 500.0);
    grid.addProducer("P002", "Wind LLC", 750.0);

    grid.displayCustomers();
    grid.displayProducers();
    
    Entity* customer = grid.searchCustomer("C001");
    if (customer) {
        std::cout << "Found Customer: " << customer->name << std::endl;
    }

    grid.updateCustomer("C001", "Alice Cooper", 180.0);
    grid.displayCustomers();

    grid.deleteProducer("P002");
    grid.displayProducers();

    return 0;
}