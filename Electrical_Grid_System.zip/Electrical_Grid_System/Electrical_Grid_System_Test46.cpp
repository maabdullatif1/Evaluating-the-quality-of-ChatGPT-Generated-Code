#include <iostream>
#include <string>

class Entity {
public:
    virtual void display() const = 0;
    virtual const std::string& getID() const = 0;
};

class Customer : public Entity {
private:
    std::string id;
    std::string name;
    std::string address;
    double consumption;

public:
    Customer(const std::string& id, const std::string& name, const std::string& address, double consumption)
        : id(id), name(name), address(address), consumption(consumption) {}

    const std::string& getID() const override { return id; }

    void display() const override {
        std::cout << "Customer ID: " << id << ", Name: " << name
                  << ", Address: " << address << ", Consumption: " << consumption << std::endl;
    }
};

class Producer : public Entity {
private:
    std::string id;
    std::string name;
    double production;

public:
    Producer(const std::string& id, const std::string& name, double production)
        : id(id), name(name), production(production) {}

    const std::string& getID() const override { return id; }

    void display() const override {
        std::cout << "Producer ID: " << id << ", Name: " << name 
                  << ", Production: " << production << std::endl;
    }
};

class GridSystem {
private:
    Entity* entities[100];
    int count;

public:
    GridSystem() : count(0) {}

    void addEntity(Entity* entity) {
        if (count < 100) {
            entities[count++] = entity;
        }
    }

    void deleteEntity(const std::string& id) {
        for (int i = 0; i < count; ++i) {
            if (entities[i]->getID() == id) {
                delete entities[i];
                for (int j = i; j < count - 1; ++j) {
                    entities[j] = entities[j + 1];
                }
                --count;
                break;
            }
        }
    }

    void updateEntity(const std::string& id, Entity* newEntity) {
        for (int i = 0; i < count; ++i) {
            if (entities[i]->getID() == id) {
                delete entities[i];
                entities[i] = newEntity;
                break;
            }
        }
    }

    Entity* searchEntity(const std::string& id) {
        for (int i = 0; i < count; ++i) {
            if (entities[i]->getID() == id) {
                return entities[i];
            }
        }
        return nullptr;
    }

    void displayEntities() const {
        for (int i = 0; i < count; ++i) {
            entities[i]->display();
        }
    }

    ~GridSystem() {
        for (int i = 0; i < count; ++i) {
            delete entities[i];
        }
    }
};

int main() {
    GridSystem grid;

    grid.addEntity(new Customer("C001", "John Doe", "123 Elm St", 1300.0));
    grid.addEntity(new Producer("P001", "Wind Farm", 5000.0));

    grid.displayEntities();

    Entity* e = grid.searchEntity("C001");
    if (e) {
        e->display();
    }

    grid.updateEntity("C001", new Customer("C001", "Jane Doe", "456 Maple St", 1500.0));
    grid.deleteEntity("P001");

    grid.displayEntities();

    return 0;
}