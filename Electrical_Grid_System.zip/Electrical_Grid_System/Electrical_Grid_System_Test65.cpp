#include <iostream>
#include <vector>
#include <string>

class Entity {
public:
    std::string id;
    std::string name;
};

class Customer : public Entity {
public:
    double currentUsage;
};

class Producer : public Entity {
public:
    double currentProduction;
};

class GridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;

public:
    void addCustomer(const std::string& id, const std::string& name, double usage) {
        Customer customer;
        customer.id = id;
        customer.name = name;
        customer.currentUsage = usage;
        customers.push_back(customer);
    }

    void addProducer(const std::string& id, const std::string& name, double production) {
        Producer producer;
        producer.id = id;
        producer.name = name;
        producer.currentProduction = production;
        producers.push_back(producer);
    }

    bool deleteCustomer(const std::string& id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return true;
            }
        }
        return false;
    }

    bool deleteProducer(const std::string& id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->id == id) {
                producers.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateCustomer(const std::string& id, const std::string& name, double usage) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.currentUsage = usage;
                return true;
            }
        }
        return false;
    }

    bool updateProducer(const std::string& id, const std::string& name, double production) {
        for (auto& producer : producers) {
            if (producer.id == id) {
                producer.name = name;
                producer.currentProduction = production;
                return true;
            }
        }
        return false;
    }

    Customer* searchCustomer(const std::string& id) {
        for (auto& customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Producer* searchProducer(const std::string& id) {
        for (auto& producer : producers) {
            if (producer.id == id) {
                return &producer;
            }
        }
        return nullptr;
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id 
                      << ", Name: " << customer.name 
                      << ", Current Usage: " << customer.currentUsage 
                      << "\n";
        }
    }

    void displayProducers() {
        for (const auto& producer : producers) {
            std::cout << "Producer ID: " << producer.id 
                      << ", Name: " << producer.name 
                      << ", Current Production: " << producer.currentProduction 
                      << "\n";
        }
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer("C001", "John Doe", 1500);
    grid.addProducer("P001", "Solar Inc.", 3000);
    grid.displayCustomers();
    grid.displayProducers();
    grid.updateCustomer("C001", "John Doe", 1900);
    grid.updateProducer("P001", "Wind Inc.", 3500);
    grid.displayCustomers();
    grid.displayProducers();
    grid.deleteCustomer("C001");
    grid.displayCustomers();
    return 0;
}