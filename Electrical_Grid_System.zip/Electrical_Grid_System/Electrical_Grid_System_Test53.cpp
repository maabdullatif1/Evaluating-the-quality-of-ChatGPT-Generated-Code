#include <iostream>
#include <vector>
#include <string>

class Entity {
protected:
    std::string id;
    std::string name;
public:
    Entity(std::string id, std::string name) : id(id), name(name) {}
    std::string getId() const { return id; }
    std::string getName() const { return name; }
    void setName(std::string newName) { name = newName; }
};

class Customer : public Entity {
public:
    Customer(std::string id, std::string name) : Entity(id, name) {}
};

class Producer : public Entity {
public:
    Producer(std::string id, std::string name) : Entity(id, name) {}
};

class GridSystem {
private:
    std::vector<Customer> customers;
    std::vector<Producer> producers;

    template<typename T>
    T* search(std::vector<T>& list, const std::string& id) {
        for (auto& entity : list) {
            if (entity.getId() == id) {
                return &entity;
            }
        }
        return nullptr;
    }

public:
    void addCustomer(const std::string& id, const std::string& name) {
        customers.emplace_back(id, name);
    }

    void addProducer(const std::string& id, const std::string& name) {
        producers.emplace_back(id, name);
    }

    bool deleteCustomer(const std::string& id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->getId() == id) {
                customers.erase(it);
                return true;
            }
        }
        return false;
    }

    bool deleteProducer(const std::string& id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->getId() == id) {
                producers.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateCustomer(const std::string& id, const std::string& name) {
        Customer* customer = search(customers, id);
        if (customer) {
            customer->setName(name);
            return true;
        }
        return false;
    }

    bool updateProducer(const std::string& id, const std::string& name) {
        Producer* producer = search(producers, id);
        if (producer) {
            producer->setName(name);
            return true;
        }
        return false;
    }

    Customer* searchCustomer(const std::string& id) {
        return search(customers, id);
    }

    Producer* searchProducer(const std::string& id) {
        return search(producers, id);
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.getId()
                      << ", Name: " << customer.getName() << std::endl;
        }
    }

    void displayProducers() {
        for (const auto& producer : producers) {
            std::cout << "Producer ID: " << producer.getId()
                      << ", Name: " << producer.getName() << std::endl;
        }
    }
};

int main() {
    GridSystem grid;
    grid.addCustomer("C001", "Customer One");
    grid.addProducer("P001", "Producer One");
    grid.displayCustomers();
    grid.displayProducers();

    if (grid.updateCustomer("C001", "Customer1 Updated")) {
        std::cout << "Customer updated successfully." << std::endl;
    }

    if (grid.deleteProducer("P001")) {
        std::cout << "Producer deleted successfully." << std::endl;
    }

    grid.displayCustomers();
    grid.displayProducers();

    return 0;
}