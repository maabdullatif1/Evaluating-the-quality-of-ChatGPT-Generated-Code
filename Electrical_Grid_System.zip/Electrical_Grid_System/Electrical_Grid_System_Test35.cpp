#include <iostream>
#include <vector>
#include <string>

class Customer {
public:
    int id;
    std::string name;
    std::string address;
    double electricityConsumed;
    
    Customer(int id, std::string name, std::string address, double electricityConsumed)
        : id(id), name(name), address(address), electricityConsumed(electricityConsumed) {}
};

class Producer {
public:
    int id;
    std::string name;
    std::string address;
    double electricityProduced;
    
    Producer(int id, std::string name, std::string address, double electricityProduced)
        : id(id), name(name), address(address), electricityProduced(electricityProduced) {}
};

class GridSystem {
    std::vector<Customer> customers;
    std::vector<Producer> producers;

public:
    void addCustomer(int id, std::string name, std::string address, double electricityConsumed) {
        customers.push_back(Customer(id, name, address, electricityConsumed));
    }
    
    void addProducer(int id, std::string name, std::string address, double electricityProduced) {
        producers.push_back(Producer(id, name, address, electricityProduced));
    }
    
    void deleteCustomer(int id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                break;
            }
        }
    }
    
    void deleteProducer(int id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->id == id) {
                producers.erase(it);
                break;
            }
        }
    }
    
    void updateCustomer(int id, std::string name, std::string address, double electricityConsumed) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                customer.name = name;
                customer.address = address;
                customer.electricityConsumed = electricityConsumed;
                break;
            }
        }
    }
    
    void updateProducer(int id, std::string name, std::string address, double electricityProduced) {
        for (auto &producer : producers) {
            if (producer.id == id) {
                producer.name = name;
                producer.address = address;
                producer.electricityProduced = electricityProduced;
                break;
            }
        }
    }
    
    Customer* searchCustomer(int id) {
        for (auto &customer : customers) {
            if (customer.id == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    Producer* searchProducer(int id) {
        for (auto &producer : producers) {
            if (producer.id == id) {
                return &producer;
            }
        }
        return nullptr;
    }
    
    void displayCustomers() {
        for (const auto &customer : customers) {
            std::cout << "ID: " << customer.id << ", Name: " << customer.name
                      << ", Address: " << customer.address 
                      << ", Electricity Consumed: " << customer.electricityConsumed << std::endl;
        }
    }
    
    void displayProducers() {
        for (const auto &producer : producers) {
            std::cout << "ID: " << producer.id << ", Name: " << producer.name
                      << ", Address: " << producer.address 
                      << ", Electricity Produced: " << producer.electricityProduced << std::endl;
        }
    }
};

int main() {
    GridSystem grid;
    
    grid.addCustomer(1, "John Doe", "123 Elm St", 1200.5);
    grid.addProducer(1, "Alpha Power", "456 Maple St", 2500.0);

    std::cout << "Initial Customers:" << std::endl;
    grid.displayCustomers();
    std::cout << "Initial Producers:" << std::endl;
    grid.displayProducers();
    
    grid.updateCustomer(1, "John Doe", "123 Elm St", 1300.0);
    grid.updateProducer(1, "Alpha Power", "456 Maple St", 2600.0);

    std::cout << "Updated Customers:" << std::endl;
    grid.displayCustomers();
    std::cout << "Updated Producers:" << std::endl;
    grid.displayProducers();
    
    grid.deleteCustomer(1);
    grid.deleteProducer(1);

    std::cout << "After Deletion - Customers:" << std::endl;
    grid.displayCustomers();
    std::cout << "After Deletion - Producers:" << std::endl;
    grid.displayProducers();

    return 0;
}