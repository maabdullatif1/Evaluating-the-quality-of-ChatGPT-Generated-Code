#include <iostream>
#include <vector>
#include <string>

class Participant {
protected:
    int id;
    std::string name;
    std::string type;
public:
    Participant(int id, std::string name, std::string type) : id(id), name(name), type(type) {}
    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getType() const { return type; }
    virtual void display() const = 0;
};

class Customer : public Participant {
public:
    Customer(int id, std::string name) : Participant(id, name, "Customer") {}
    void display() const override {
        std::cout << "Customer ID: " << id << ", Name: " << name << std::endl;
    }
};

class Producer : public Participant {
public:
    Producer(int id, std::string name) : Participant(id, name, "Producer") {}
    void display() const override {
        std::cout << "Producer ID: " << id << ", Name: " << name << std::endl;
    }
};

class GridSystem {
private:
    std::vector<Participant*> participants;
public:
    ~GridSystem() {
        for (auto& participant : participants) {
            delete participant;
        }
    }
    void addParticipant(Participant* participant) {
        participants.push_back(participant);
    }
    void deleteParticipant(int id) {
        for (auto it = participants.begin(); it != participants.end(); ++it) {
            if ((*it)->getId() == id) {
                delete *it;
                participants.erase(it);
                break;
            }
        }
    }
    void updateParticipant(int id, std::string new_name) {
        for (auto& participant : participants) {
            if (participant->getId() == id) {
                if (participant->getType() == "Customer") {
                    delete participant;
                    participant = new Customer(id, new_name);
                } else if (participant->getType() == "Producer") {
                    delete participant;
                    participant = new Producer(id, new_name);
                }
                break;
            }
        }
    }
    Participant* searchParticipant(int id) {
        for (auto& participant : participants) {
            if (participant->getId() == id) {
                return participant;
            }
        }
        return nullptr;
    }
    void displayParticipants() const {
        for (const auto& participant : participants) {
            participant->display();
        }
    }
};

int main() {
    GridSystem grid;
    grid.addParticipant(new Customer(1, "Alice"));
    grid.addParticipant(new Producer(2, "PowerCo"));
    grid.displayParticipants();
    std::cout << "Updating participant with ID 1." << std::endl;
    grid.updateParticipant(1, "New Alice");
    grid.displayParticipants();
    std::cout << "Searching for participant with ID 1." << std::endl;
    Participant* p = grid.searchParticipant(1);
    if (p) p->display();
    std::cout << "Deleting participant with ID 1." << std::endl;
    grid.deleteParticipant(1);
    grid.displayParticipants();
    return 0;
}