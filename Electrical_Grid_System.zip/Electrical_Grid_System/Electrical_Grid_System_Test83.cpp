#include <iostream>
#include <vector>
#include <string>

class Entity {
protected:
    int id;
    std::string name;
    std::string type;

public:
    Entity(int id, const std::string& name, const std::string& type) : id(id), name(name), type(type) {}

    int getID() const { return id; }
    std::string getName() const { return name; }
    std::string getType() const { return type; }

    void setName(const std::string& newName) { name = newName; }
    void setType(const std::string& newType) { type = newType; }

    virtual void display() const {
        std::cout << "ID: " << id << ", Name: " << name << ", Type: " << type;
    }
};

class Customer : public Entity {
public:
    Customer(int id, const std::string& name) : Entity(id, name, "Customer") {}
    
    void display() const override {
        Entity::display();
        std::cout << std::endl;
    }
};

class ElectricityProducer : public Entity {
public:
    ElectricityProducer(int id, const std::string& name) : Entity(id, name, "ElectricityProducer") {}

    void display() const override {
        Entity::display();
        std::cout << std::endl;
    }
};

class ElectricalGridSystem {
private:
    std::vector<Entity*> entities;
    int nextID;

public:
    ElectricalGridSystem() : nextID(0) {}

    ~ElectricalGridSystem() {
        for (Entity* entity : entities) {
            delete entity;
        }
    }

    void addCustomer(const std::string& name) {
        entities.push_back(new Customer(nextID++, name));
    }

    void addElectricityProducer(const std::string& name) {
        entities.push_back(new ElectricityProducer(nextID++, name));
    }

    void deleteEntity(int id) {
        for (size_t i = 0; i < entities.size(); ++i) {
            if (entities[i]->getID() == id) {
                delete entities[i];
                entities.erase(entities.begin() + i);
                return;
            }
        }
    }

    void updateEntity(int id, const std::string& newName) {
        for (Entity* entity : entities) {
            if (entity->getID() == id) {
                entity->setName(newName);
                return;
            }
        }
    }

    Entity* searchEntity(int id) {
        for (Entity* entity : entities) {
            if (entity->getID() == id) {
                return entity;
            }
        }
        return nullptr;
    }

    void displayEntities() const {
        for (const Entity* entity : entities) {
            entity->display();
        }
    }
};

int main() {
    ElectricalGridSystem gridSystem;
    gridSystem.addCustomer("John Doe");
    gridSystem.addElectricityProducer("Solar Plant 1");
    gridSystem.displayEntities();
    Entity* entity = gridSystem.searchEntity(0);
    if (entity) {
        entity->display();
        std::cout << std::endl;
    }
    gridSystem.updateEntity(0, "Johnathan Doe");
    gridSystem.displayEntities();
    gridSystem.deleteEntity(1);
    gridSystem.displayEntities();
    return 0;
}