#include <iostream>
#include <vector>
#include <string>

struct Entity {
    std::string id;
    std::string name;
    std::string address;
    double energy;
};

class ElectricalGrid {
    std::vector<Entity> customers;
    std::vector<Entity> producers;
    
    Entity* findEntityById(std::vector<Entity>& entities, const std::string& id) {
        for (auto& entity : entities) {
            if (entity.id == id) {
                return &entity;
            }
        }
        return nullptr;
    }

public:
    void addCustomer(const std::string& id, const std::string& name, const std::string& address, double energy) {
        customers.push_back({id, name, address, energy});
    }
    
    void deleteCustomer(const std::string& id) {
        for (auto it = customers.begin(); it != customers.end(); ++it) {
            if (it->id == id) {
                customers.erase(it);
                return;
            }
        }
    }
    
    void updateCustomer(const std::string& id, const std::string& name, const std::string& address, double energy) {
        Entity* customer = findEntityById(customers, id);
        if (customer) {
            customer->name = name;
            customer->address = address;
            customer->energy = energy;
        }
    }

    void addProducer(const std::string& id, const std::string& name, const std::string& address, double energy) {
        producers.push_back({id, name, address, energy});
    }
    
    void deleteProducer(const std::string& id) {
        for (auto it = producers.begin(); it != producers.end(); ++it) {
            if (it->id == id) {
                producers.erase(it);
                return;
            }
        }
    }
    
    void updateProducer(const std::string& id, const std::string& name, const std::string& address, double energy) {
        Entity* producer = findEntityById(producers, id);
        if (producer) {
            producer->name = name;
            producer->address = address;
            producer->energy = energy;
        }
    }

    Entity* searchCustomer(const std::string& id) {
        return findEntityById(customers, id);
    }

    Entity* searchProducer(const std::string& id) {
        return findEntityById(producers, id);
    }

    void displayCustomers() {
        for (const auto& customer : customers) {
            std::cout << "Customer ID: " << customer.id << ", Name: " << customer.name
                      << ", Address: " << customer.address << ", Energy: " << customer.energy << std::endl;
        }
    }

    void displayProducers() {
        for (const auto& producer : producers) {
            std::cout << "Producer ID: " << producer.id << ", Name: " << producer.name
                      << ", Address: " << producer.address << ", Energy: " << producer.energy << std::endl;
        }
    }
};

int main() {
    ElectricalGrid grid;

    grid.addCustomer("C001", "Alice", "123 Main St", 100.5);
    grid.addCustomer("C002", "Bob", "456 Elm St", 200.0);
    grid.addProducer("P001", "Solar Inc.", "789 Solar Rd", 500.0);

    grid.displayCustomers();
    grid.displayProducers();

    grid.updateCustomer("C001", "Alice Smith", "123 Main St", 150.75);
    grid.updateProducer("P001", "SolarTech", "789 Solar Rd", 600.5);

    grid.displayCustomers();
    grid.displayProducers();

    grid.deleteCustomer("C002");

    grid.displayCustomers();
    
    return 0;
}