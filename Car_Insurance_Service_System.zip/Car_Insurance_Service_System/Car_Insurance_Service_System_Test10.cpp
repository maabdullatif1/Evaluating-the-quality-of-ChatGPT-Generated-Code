#include <iostream>
#include <vector>
#include <string>

class InsuranceCompany {
public:
    std::string name;
    std::string address;
    void display() const {
        std::cout << "Name: " << name << ", Address: " << address << std::endl;
    }
};

class Car {
public:
    std::string licensePlate;
    std::string model;
    std::string owner;
    void display() const {
        std::cout << "License Plate: " << licensePlate << ", Model: " << model << ", Owner: " << owner << std::endl;
    }
};

class InsuranceSystem {
private:
    std::vector<InsuranceCompany> companies;
    std::vector<Car> cars;

public:
    void addCompany(const std::string& name, const std::string& address) {
        companies.push_back({name, address});
    }

    void deleteCompany(const std::string& name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCompany(const std::string& name, const std::string& newAddress) {
        for (auto& company : companies) {
            if (company.name == name) {
                company.address = newAddress;
                break;
            }
        }
    }

    void searchCompany(const std::string& name) const {
        for (const auto& company : companies) {
            if (company.name == name) {
                company.display();
                return;
            }
        }
        std::cout << "Company not found!" << std::endl;
    }

    void displayCompanies() const {
        for (const auto& company : companies) {
            company.display();
        }
    }

    void addCar(const std::string& licensePlate, const std::string& model, const std::string& owner) {
        cars.push_back({licensePlate, model, owner});
    }

    void deleteCar(const std::string& licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string& licensePlate, const std::string& newModel, const std::string& newOwner) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                car.model = newModel;
                car.owner = newOwner;
                break;
            }
        }
    }

    void searchCar(const std::string& licensePlate) const {
        for (const auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                car.display();
                return;
            }
        }
        std::cout << "Car not found!" << std::endl;
    }

    void displayCars() const {
        for (const auto& car : cars) {
            car.display();
        }
    }
};

int main() {
    InsuranceSystem system;
    system.addCompany("CompanyA", "123 Street A");
    system.addCar("ABC123", "Toyota", "John Doe");

    std::cout << "Initial State:" << std::endl;
    system.displayCompanies();
    system.displayCars();

    system.updateCompany("CompanyA", "456 Street B");
    system.updateCar("ABC123", "Honda", "Jane Doe");

    std::cout << "\nAfter Updates:" << std::endl;
    system.displayCompanies();
    system.displayCars();

    std::cout << "\nSearching for CompanyA:" << std::endl;
    system.searchCompany("CompanyA");

    std::cout << "\nSearching for Car with License Plate ABC123:" << std::endl;
    system.searchCar("ABC123");

    system.deleteCompany("CompanyA");
    system.deleteCar("ABC123");

    std::cout << "\nFinal State:" << std::endl;
    system.displayCompanies();
    system.displayCars();

    return 0;
}