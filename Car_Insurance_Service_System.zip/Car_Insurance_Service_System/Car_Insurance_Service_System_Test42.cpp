#include <iostream>
#include <vector>
#include <string>

struct Car {
    std::string licensePlate;
    std::string model;
    std::string ownerName;
};

struct InsuranceCompany {
    std::string name;
    std::string policyNumber;
    std::string contactInfo;
};

class InsuranceService {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(const Car& car) {
        cars.push_back(car);
    }

    void deleteCar(const std::string& licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                return;
            }
        }
    }

    void updateCar(const std::string& licensePlate, const Car& updatedCar) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                car = updatedCar;
                return;
            }
        }
    }

    Car* searchCar(const std::string& licensePlate) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "License Plate: " << car.licensePlate 
                      << ", Model: " << car.model 
                      << ", Owner: " << car.ownerName << std::endl;
        }
    }

    void addInsuranceCompany(const InsuranceCompany& company) {
        companies.push_back(company);
    }

    void deleteInsuranceCompany(const std::string& name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                return;
            }
        }
    }

    void updateInsuranceCompany(const std::string& name, const InsuranceCompany& updatedCompany) {
        for (auto& company : companies) {
            if (company.name == name) {
                company = updatedCompany;
                return;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(const std::string& name) {
        for (auto& company : companies) {
            if (company.name == name) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto& company : companies) {
            std::cout << "Name: " << company.name 
                      << ", Policy Number: " << company.policyNumber 
                      << ", Contact Info: " << company.contactInfo << std::endl;
        }
    }
};

int main() {
    InsuranceService service;
    Car car1 = {"ABC123", "Toyota Corolla", "John Doe"};
    Car car2 = {"XYZ321", "Honda Accord", "Jane Smith"};
    service.addCar(car1);
    service.addCar(car2);
    service.displayCars();

    InsuranceCompany company1 = {"InsureCo", "POL123", "123-456-7890"};
    InsuranceCompany company2 = {"SecureIns", "POL456", "098-765-4321"};
    service.addInsuranceCompany(company1);
    service.addInsuranceCompany(company2);
    service.displayInsuranceCompanies();

    return 0;
}