#include <iostream>
#include <vector>
#include <string>

struct Car {
    std::string licensePlate;
    std::string ownerName;
    std::string model;
};

struct InsuranceCompany {
    std::string name;
    std::string address;
    std::string contactNumber;
};

class InsuranceServiceSystem {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(const std::string& licensePlate, const std::string& ownerName, const std::string& model) {
        cars.push_back({licensePlate, ownerName, model});
    }

    void addCompany(const std::string& name, const std::string& address, const std::string& contactNumber) {
        companies.push_back({name, address, contactNumber});
    }

    void deleteCar(const std::string& licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                break;
            }
        }
    }

    void deleteCompany(const std::string& name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string& licensePlate, const std::string& ownerName, const std::string& model) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                car.ownerName = ownerName;
                car.model = model;
            }
        }
    }

    void updateCompany(const std::string& name, const std::string& address, const std::string& contactNumber) {
        for (auto& company : companies) {
            if (company.name == name) {
                company.address = address;
                company.contactNumber = contactNumber;
            }
        }
    }

    void searchCar(const std::string& licensePlate) {
        for (const auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                std::cout << "Car details - License Plate: " << car.licensePlate << ", Owner: " << car.ownerName << ", Model: " << car.model << std::endl;
            }
        }
    }

    void searchCompany(const std::string& name) {
        for (const auto& company : companies) {
            if (company.name == name) {
                std::cout << "Company details - Name: " << company.name << ", Address: " << company.address << ", Contact: " << company.contactNumber << std::endl;
            }
        }
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "License Plate: " << car.licensePlate << ", Owner: " << car.ownerName << ", Model: " << car.model << std::endl;
        }
    }

    void displayCompanies() {
        for (const auto& company : companies) {
            std::cout << "Name: " << company.name << ", Address: " << company.address << ", Contact: " << company.contactNumber << std::endl;
        }
    }
};

int main() {
    InsuranceServiceSystem system;
    
    system.addCar("ABC123", "John Doe", "Toyota Corolla");
    system.addCar("XYZ789", "Jane Smith", "Honda Civic");
    system.addCompany("InsureCo", "123 Main St", "555-1234");
    system.addCompany("CoverAll", "456 Elm St", "555-5678");

    system.displayCars();
    system.displayCompanies();

    system.searchCar("ABC123");
    system.searchCompany("InsureCo");

    system.updateCar("XYZ789", "Jane Smith", "Honda Accord");
    system.updateCompany("CoverAll", "789 Oak St", "555-6789");

    system.displayCars();
    system.displayCompanies();

    system.deleteCar("ABC123");
    system.deleteCompany("InsureCo");

    system.displayCars();
    system.displayCompanies();
    
    return 0;
}