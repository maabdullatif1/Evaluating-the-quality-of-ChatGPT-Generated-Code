#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    string registrationNumber;
    string ownerName;
    string model;
};

struct InsuranceCompany {
    string name;
    string address;
};

class InsuranceService {
private:
    vector<Car> cars;
    vector<InsuranceCompany> companies;

    int findCarIndex(const string& registrationNumber) {
        for (size_t i = 0; i < cars.size(); ++i) {
            if (cars[i].registrationNumber == registrationNumber) {
                return i;
            }
        }
        return -1;
    }

    int findCompanyIndex(const string& name) {
        for (size_t i = 0; i < companies.size(); ++i) {
            if (companies[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addCar(const string& registrationNumber, const string& ownerName, const string& model) {
        cars.push_back({registrationNumber, ownerName, model});
    }

    void deleteCar(const string& registrationNumber) {
        int index = findCarIndex(registrationNumber);
        if (index != -1) {
            cars.erase(cars.begin() + index);
        }
    }

    void updateCar(const string& registrationNumber, const string& newOwnerName, const string& newModel) {
        int index = findCarIndex(registrationNumber);
        if (index != -1) {
            cars[index].ownerName = newOwnerName;
            cars[index].model = newModel;
        }
    }

    void searchCar(const string& registrationNumber) {
        int index = findCarIndex(registrationNumber);
        if (index != -1) {
            cout << "Car Found: " << cars[index].registrationNumber << ", " << cars[index].ownerName << ", " << cars[index].model << endl;
        } else {
            cout << "Car Not Found" << endl;
        }
    }

    void displayCars() {
        for (const auto& car : cars) {
            cout << "Car: " << car.registrationNumber << ", " << car.ownerName << ", " << car.model << endl;
        }
    }

    void addInsuranceCompany(const string& name, const string& address) {
        companies.push_back({name, address});
    }

    void deleteInsuranceCompany(const string& name) {
        int index = findCompanyIndex(name);
        if (index != -1) {
            companies.erase(companies.begin() + index);
        }
    }

    void updateInsuranceCompany(const string& name, const string& newAddress) {
        int index = findCompanyIndex(name);
        if (index != -1) {
            companies[index].address = newAddress;
        }
    }

    void searchInsuranceCompany(const string& name) {
        int index = findCompanyIndex(name);
        if (index != -1) {
            cout << "Insurance Company Found: " << companies[index].name << ", " << companies[index].address << endl;
        } else {
            cout << "Insurance Company Not Found" << endl;
        }
    }

    void displayInsuranceCompanies() {
        for (const auto& company : companies) {
            cout << "Insurance Company: " << company.name << ", " << company.address << endl;
        }
    }
};

int main() {
    InsuranceService service;
    service.addCar("123ABC", "John Doe", "Toyota");
    service.addInsuranceCompany("XYZ Insurance", "123 Elm St");
    
    service.displayCars();
    service.displayInsuranceCompanies();
    
    service.searchCar("123ABC");
    service.searchInsuranceCompany("XYZ Insurance");
    
    service.updateCar("123ABC", "Jane Doe", "Honda");
    service.updateInsuranceCompany("XYZ Insurance", "456 Maple St");
    
    service.displayCars();
    service.displayInsuranceCompanies();
    
    service.deleteCar("123ABC");
    service.deleteInsuranceCompany("XYZ Insurance");
    
    service.displayCars();
    service.displayInsuranceCompanies();
    
    return 0;
}