#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string make;
    std::string model;
    int year;

    Car(std::string lp, std::string m, std::string mdl, int y)
    : licensePlate(lp), make(m), model(mdl), year(y) {}
};

class InsuranceCompany {
public:
    std::string name;
    std::string policyNumber;
    std::string insuredCar;

    InsuranceCompany(std::string n, std::string pn, std::string ic)
    : name(n), policyNumber(pn), insuredCar(ic) {}
};

class InsuranceServiceSystem {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> insuranceCompanies;

public:
    void addCar(const std::string& lp, const std::string& make, const std::string& model, int year) {
        cars.push_back(Car(lp, make, model, year));
    }

    void addInsuranceCompany(const std::string& name, const std::string& pn, const std::string& ic) {
        insuranceCompanies.push_back(InsuranceCompany(name, pn, ic));
    }

    void deleteCar(const std::string& lp) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == lp) {
                cars.erase(it);
                break;
            }
        }
    }

    void deleteInsuranceCompany(const std::string& pn) {
        for (auto it = insuranceCompanies.begin(); it != insuranceCompanies.end(); ++it) {
            if (it->policyNumber == pn) {
                insuranceCompanies.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string& lp, const std::string& make, const std::string& model, int year) {
        for (auto& car : cars) {
            if (car.licensePlate == lp) {
                car.make = make;
                car.model = model;
                car.year = year;
                break;
            }
        }
    }

    void updateInsuranceCompany(const std::string& pn, const std::string& name, const std::string& ic) {
        for (auto& company : insuranceCompanies) {
            if (company.policyNumber == pn) {
                company.name = name;
                company.insuredCar = ic;
                break;
            }
        }
    }

    Car* searchCar(const std::string& lp) {
        for (auto& car : cars) {
            if (car.licensePlate == lp) {
                return &car;
            }
        }
        return nullptr;
    }

    InsuranceCompany* searchInsuranceCompany(const std::string& pn) {
        for (auto& company : insuranceCompanies) {
            if (company.policyNumber == pn) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "License Plate: " << car.licensePlate
                      << ", Make: " << car.make
                      << ", Model: " << car.model
                      << ", Year: " << car.year << std::endl;
        }
    }

    void displayInsuranceCompanies() {
        for (const auto& company : insuranceCompanies) {
            std::cout << "Name: " << company.name
                      << ", Policy Number: " << company.policyNumber
                      << ", Insured Car: " << company.insuredCar << std::endl;
        }
    }
};

int main() {
    InsuranceServiceSystem system;
    system.addCar("ABC123", "Toyota", "Corolla", 2018);
    system.addInsuranceCompany("XYZ Insurance", "POL123", "ABC123");
    system.displayCars();
    system.displayInsuranceCompanies();

    system.updateCar("ABC123", "Honda", "Civic", 2020);
    system.updateInsuranceCompany("POL123", "ABC Insurance", "ABC123");
    system.displayCars();
    system.displayInsuranceCompanies();

    system.deleteCar("ABC123");
    system.deleteInsuranceCompany("POL123");
    system.displayCars();
    system.displayInsuranceCompanies();
    
    return 0;
}