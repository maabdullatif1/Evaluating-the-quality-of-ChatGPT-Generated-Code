#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    string registrationNo;
    string brand;
    string model;

    Car(string regNo, string br, string mod) {
        registrationNo = regNo;
        brand = br;
        model = mod;
    }
};

class InsuranceCompany {
public:
    string name;
    vector<Car> insuredCars;

    InsuranceCompany(string n) {
        name = n;
    }

    void addCar(Car car) {
        insuredCars.push_back(car);
    }

    void removeCar(string regNo) {
        for (auto it = insuredCars.begin(); it != insuredCars.end(); ++it) {
            if (it->registrationNo == regNo) {
                insuredCars.erase(it);
                break;
            }
        }
    }

    void updateCar(string regNo, string newBrand, string newModel) {
        for (auto &car : insuredCars) {
            if (car.registrationNo == regNo) {
                car.brand = newBrand;
                car.model = newModel;
            }
        }
    }

    Car* searchCar(string regNo) {
        for (auto &car : insuredCars) {
            if (car.registrationNo == regNo) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (auto &car : insuredCars) {
            cout << "Registration No: " << car.registrationNo << ", Brand: " << car.brand << ", Model: " << car.model << endl;
        }
    }
};

int main() {
    vector<InsuranceCompany> companies;

    companies.push_back(InsuranceCompany("InsuranceCo1"));
    companies.push_back(InsuranceCompany("InsuranceCo2"));

    companies[0].addCar(Car("ABC123", "Toyota", "Corolla"));
    companies[0].addCar(Car("XYZ789", "Honda", "Civic"));
    
    companies[1].addCar(Car("LMN456", "Ford", "Focus"));
    
    cout << "Displaying cars for InsuranceCo1:" << endl;
    companies[0].displayCars();

    Car* car = companies[0].searchCar("ABC123");
    if (car != nullptr) {
        cout << "Found car: " << car->registrationNo << endl;
    }

    companies[0].updateCar("XYZ789", "Honda", "Accord");

    companies[0].removeCar("ABC123");
    
    cout << "Displaying cars after update and remove for InsuranceCo1:" << endl;
    companies[0].displayCars();

    return 0;
}