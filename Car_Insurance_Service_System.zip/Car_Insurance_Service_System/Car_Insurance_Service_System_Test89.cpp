#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int carId;
    std::string make;
    std::string model;
    int year;

    Car(int id, const std::string& mk, const std::string& mdl, int yr) 
        : carId(id), make(mk), model(mdl), year(yr) {}
};

class InsuranceCompany {
public:
    int companyId;
    std::string name;
    std::string address;

    InsuranceCompany(int id, const std::string& nm, const std::string& addr) 
        : companyId(id), name(nm), address(addr) {}
};

class System {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;
    
public:
    void addCar(int id, const std::string& make, const std::string& model, int year) {
        cars.push_back(Car(id, make, model, year));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->carId == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, const std::string& newMake, const std::string& newModel, int newYear) {
        for (auto& car : cars) {
            if (car.carId == id) {
                car.make = newMake;
                car.model = newModel;
                car.year = newYear;
                break;
            }
        }
    }

    void searchCar(int id) {
        for (const auto& car : cars) {
            if (car.carId == id) {
                std::cout << "Car ID: " << car.carId << ", Make: " << car.make 
                          << ", Model: " << car.model << ", Year: " << car.year << std::endl;
                return;
            }
        }
        std::cout << "Car not found." << std::endl;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Car ID: " << car.carId << ", Make: " << car.make 
                      << ", Model: " << car.model << ", Year: " << car.year << std::endl;
        }
    }

    void addInsuranceCompany(int id, const std::string& name, const std::string& address) {
        companies.push_back(InsuranceCompany(id, name, address));
    }

    void deleteInsuranceCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->companyId == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(int id, const std::string& newName, const std::string& newAddress) {
        for (auto& company : companies) {
            if (company.companyId == id) {
                company.name = newName;
                company.address = newAddress;
                break;
            }
        }
    }

    void searchInsuranceCompany(int id) {
        for (const auto& company : companies) {
            if (company.companyId == id) {
                std::cout << "Company ID: " << company.companyId 
                          << ", Name: " << company.name << ", Address: " << company.address << std::endl;
                return;
            }
        }
        std::cout << "Company not found." << std::endl;
    }

    void displayInsuranceCompanies() {
        for (const auto& company : companies) {
            std::cout << "Company ID: " << company.companyId 
                      << ", Name: " << company.name << ", Address: " << company.address << std::endl;
        }
    }
};

int main() {
    System sys;
    
    sys.addCar(1, "Toyota", "Camry", 2020);
    sys.addCar(2, "Ford", "Focus", 2018);
    
    sys.addInsuranceCompany(1, "ABC Insurance", "123 Main St");
    sys.addInsuranceCompany(2, "XYZ Insurance", "456 Elm St");
    
    std::cout << "All Cars:\n";
    sys.displayCars();

    std::cout << "\nAll Insurance Companies:\n";
    sys.displayInsuranceCompanies();
    
    return 0;
}