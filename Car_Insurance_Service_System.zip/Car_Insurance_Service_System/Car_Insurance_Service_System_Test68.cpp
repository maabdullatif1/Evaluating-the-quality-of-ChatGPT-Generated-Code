#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int carId;
    string carModel;
    string ownerName;
    
    Car(int id, string model, string owner) : carId(id), carModel(model), ownerName(owner) {}
};

class InsuranceCompany {
public:
    int companyId;
    string companyName;
    
    InsuranceCompany(int id, string name) : companyId(id), companyName(name) {}
};

class InsuranceServiceSystem {
private:
    vector<Car> cars;
    vector<InsuranceCompany> companies;
    
public:
    void addCar(int id, string model, string owner) {
        cars.push_back(Car(id, model, owner));
    }

    void addInsuranceCompany(int id, string name) {
        companies.push_back(InsuranceCompany(id, name));
    }
    
    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->carId == id) {
                cars.erase(it);
                break;
            }
        }
    }
    
    void deleteInsuranceCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->companyId == id) {
                companies.erase(it);
                break;
            }
        }
    }
    
    void updateCar(int id, string model, string owner) {
        for (auto& car : cars) {
            if (car.carId == id) {
                car.carModel = model;
                car.ownerName = owner;
                break;
            }
        }
    }

    void updateInsuranceCompany(int id, string name) {
        for (auto& company : companies) {
            if (company.companyId == id) {
                company.companyName = name;
                break;
            }
        }
    }
    
    void searchCar(int id) {
        for (const auto& car : cars) {
            if (car.carId == id) {
                cout << "Car ID: " << car.carId << ", Model: " << car.carModel << ", Owner: " << car.ownerName << endl;
                return;
            }
        }
        cout << "Car not found.\n";
    }
    
    void searchInsuranceCompany(int id) {
        for (const auto& company : companies) {
            if (company.companyId == id) {
                cout << "Company ID: " << company.companyId << ", Name: " << company.companyName << endl;
                return;
            }
        }
        cout << "Company not found.\n";
    }
    
    void displayCars() {
        for (const auto& car : cars) {
            cout << "Car ID: " << car.carId << ", Model: " << car.carModel << ", Owner: " << car.ownerName << endl;
        }
    }
    
    void displayInsuranceCompanies() {
        for (const auto& company : companies) {
            cout << "Company ID: " << company.companyId << ", Name: " << company.companyName << endl;
        }
    }
};

int main() {
    InsuranceServiceSystem system;

    system.addCar(1, "Toyota Corolla", "John Doe");
    system.addCar(2, "Honda Civic", "Jane Smith");
    
    system.addInsuranceCompany(1, "XYZ Insurance");
    system.addInsuranceCompany(2, "ABC Assurance");

    system.displayCars();
    system.displayInsuranceCompanies();

    system.updateCar(1, "Toyota Camry", "John Doe Jr.");
    system.updateInsuranceCompany(1, "XYZ Global Insurance");

    system.searchCar(1);
    system.searchInsuranceCompany(1);

    system.deleteCar(2);
    system.deleteInsuranceCompany(2);

    system.displayCars();
    system.displayInsuranceCompanies();

    return 0;
}