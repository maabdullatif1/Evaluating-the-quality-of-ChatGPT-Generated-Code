#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    string plate_number;
    string brand;
    string model;
};

struct InsuranceCompany {
    string company_name;
    string contact_number;
};

vector<Car> cars;
vector<InsuranceCompany> insuranceCompanies;

void displayCars() {
    for (const auto& car : cars) {
        cout << "Plate Number: " << car.plate_number 
             << ", Brand: " << car.brand 
             << ", Model: " << car.model << endl;
    }
}

void displayInsuranceCompanies() {
    for (const auto& company : insuranceCompanies) {
        cout << "Company Name: " << company.company_name 
             << ", Contact Number: " << company.contact_number << endl;
    }
}

void addCar() {
    Car car;
    cout << "Enter Plate Number: "; cin >> car.plate_number;
    cout << "Enter Brand: "; cin >> car.brand;
    cout << "Enter Model: "; cin >> car.model;
    cars.push_back(car);
}

void addInsuranceCompany() {
    InsuranceCompany company;
    cout << "Enter Company Name: "; cin >> company.company_name;
    cout << "Enter Contact Number: "; cin >> company.contact_number;
    insuranceCompanies.push_back(company);
}

void updateCar() {
    string plate;
    cout << "Enter Plate Number of Car to Update: ";
    cin >> plate;
    for (auto& car : cars) {
        if (car.plate_number == plate) {
            cout << "Enter New Brand: "; cin >> car.brand;
            cout << "Enter New Model: "; cin >> car.model;
            return;
        }
    }
    cout << "Car not found.\n";
}

void updateInsuranceCompany() {
    string name;
    cout << "Enter Name of Company to Update: ";
    cin >> name;
    for (auto& company : insuranceCompanies) {
        if (company.company_name == name) {
            cout << "Enter New Contact Number: "; cin >> company.contact_number;
            return;
        }
    }
    cout << "Company not found.\n";
}

void deleteCar() {
    string plate;
    cout << "Enter Plate Number of Car to Delete: ";
    cin >> plate;
    for (auto it = cars.begin(); it != cars.end(); ++it) {
        if (it->plate_number == plate) {
            cars.erase(it);
            return;
        }
    }
    cout << "Car not found.\n";
}

void deleteInsuranceCompany() {
    string name;
    cout << "Enter Name of Company to Delete: ";
    cin >> name;
    for (auto it = insuranceCompanies.begin(); it != insuranceCompanies.end(); ++it) {
        if (it->company_name == name) {
            insuranceCompanies.erase(it);
            return;
        }
    }
    cout << "Company not found.\n";
}

void searchCar() {
    string plate;
    cout << "Enter Plate Number to Search: ";
    cin >> plate;
    for (const auto& car : cars) {
        if (car.plate_number == plate) {
            cout << "Found Car - Brand: " << car.brand 
                 << ", Model: " << car.model << endl;
            return;
        }
    }
    cout << "Car not found.\n";
}

void searchInsuranceCompany() {
    string name;
    cout << "Enter Company Name to Search: ";
    cin >> name;
    for (const auto& company : insuranceCompanies) {
        if (company.company_name == name) {
            cout << "Found Company - Contact Number: " << company.contact_number << endl;
            return;
        }
    }
    cout << "Company not found.\n";
}

int main() {
    int choice;
    while (true) {
        cout << "\nMenu:\n1. Add Car\n2. Update Car\n3. Delete Car\n4. Display Cars\n5. Search Car"
             << "\n6. Add Insurance Company\n7. Update Insurance Company\n8. Delete Insurance Company"
             << "\n9. Display Insurance Companies\n10. Search Insurance Company\n11. Exit\nChoice: ";
        cin >> choice;
        switch (choice) {
            case 1: addCar(); break;
            case 2: updateCar(); break;
            case 3: deleteCar(); break;
            case 4: displayCars(); break;
            case 5: searchCar(); break;
            case 6: addInsuranceCompany(); break;
            case 7: updateInsuranceCompany(); break;
            case 8: deleteInsuranceCompany(); break;
            case 9: displayInsuranceCompanies(); break;
            case 10: searchInsuranceCompany(); break;
            case 11: return 0;
            default: cout << "Invalid choice.\n";
        }
    }
    return 0;
}