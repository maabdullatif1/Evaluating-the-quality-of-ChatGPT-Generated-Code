#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    string make;
    string model;
    int year;
    string registrationNumber;

    Car(string mk, string mdl, int yr, string reg) 
        : make(mk), model(mdl), year(yr), registrationNumber(reg) {}
};

class InsuranceCompany {
public:
    string name;
    string policyNumber;
    string coverageType;

    InsuranceCompany(string nm, string policy, string coverage)
        : name(nm), policyNumber(policy), coverageType(coverage) {}
};

class CarInsuranceSystem {
    vector<Car> cars;
    vector<InsuranceCompany> companies;
public:
    void addCar(string mk, string mdl, int yr, string reg) {
        cars.push_back(Car(mk, mdl, yr, reg));
    }

    void deleteCar(string reg) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->registrationNumber == reg) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(string reg, string mk, string mdl, int yr) {
        for (auto &car : cars) {
            if (car.registrationNumber == reg) {
                car.make = mk;
                car.model = mdl;
                car.year = yr;
            }
        }
    }

    Car* searchCar(string reg) {
        for (auto &car : cars) {
            if (car.registrationNumber == reg) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (auto &car : cars) {
            cout << "Make: " << car.make << ", Model: " << car.model 
                 << ", Year: " << car.year << ", Registration Number: " 
                 << car.registrationNumber << endl;
        }
    }

    void addInsuranceCompany(string nm, string policy, string coverage) {
        companies.push_back(InsuranceCompany(nm, policy, coverage));
    }

    void deleteInsuranceCompany(string policy) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->policyNumber == policy) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(string policy, string nm, string coverage) {
        for (auto &company : companies) {
            if (company.policyNumber == policy) {
                company.name = nm;
                company.coverageType = coverage;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(string policy) {
        for (auto &company : companies) {
            if (company.policyNumber == policy) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (auto &company : companies) {
            cout << "Name: " << company.name << ", Policy Number: " 
                 << company.policyNumber << ", Coverage Type: " 
                 << company.coverageType << endl;
        }
    }
};

int main() {
    CarInsuranceSystem system;
    system.addCar("Toyota", "Camry", 2020, "ABC123");
    system.addInsuranceCompany("InsureCo", "P123456", "Full Coverage");
    system.displayCars();
    system.displayInsuranceCompanies();
    return 0;
}