#include <iostream>
#include <string>
using namespace std;

struct Car {
    int id;
    string make;
    string model;
    string owner;
};

struct InsuranceCompany {
    int id;
    string name;
    string contactNumber;
};

class InsuranceService {
    Car cars[100];
    InsuranceCompany companies[100];
    int carCount, companyCount;

public:
    InsuranceService() : carCount(0), companyCount(0) {}

    void addCar(int id, string make, string model, string owner) {
        cars[carCount++] = {id, make, model, owner};
    }

    void deleteCar(int id) {
        for (int i = 0; i < carCount; ++i) {
            if (cars[i].id == id) {
                for (int j = i; j < carCount - 1; ++j) {
                    cars[j] = cars[j + 1];
                }
                carCount--;
                break;
            }
        }
    }

    void updateCar(int id, string make, string model, string owner) {
        for (int i = 0; i < carCount; ++i) {
            if (cars[i].id == id) {
                cars[i] = {id, make, model, owner};
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (int i = 0; i < carCount; ++i) {
            if (cars[i].id == id) {
                return &cars[i];
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (int i = 0; i < carCount; ++i) {
            cout << "ID: " << cars[i].id << ", Make: " << cars[i].make << ", Model: " << cars[i].model << ", Owner: " << cars[i].owner << endl;
        }
    }

    void addCompany(int id, string name, string contactNumber) {
        companies[companyCount++] = {id, name, contactNumber};
    }

    void deleteCompany(int id) {
        for (int i = 0; i < companyCount; ++i) {
            if (companies[i].id == id) {
                for (int j = i; j < companyCount - 1; ++j) {
                    companies[j] = companies[j + 1];
                }
                companyCount--;
                break;
            }
        }
    }

    void updateCompany(int id, string name, string contactNumber) {
        for (int i = 0; i < companyCount; ++i) {
            if (companies[i].id == id) {
                companies[i] = {id, name, contactNumber};
                break;
            }
        }
    }

    InsuranceCompany* searchCompany(int id) {
        for (int i = 0; i < companyCount; ++i) {
            if (companies[i].id == id) {
                return &companies[i];
            }
        }
        return nullptr;
    }

    void displayCompanies() {
        for (int i = 0; i < companyCount; ++i) {
            cout << "ID: " << companies[i].id << ", Name: " << companies[i].name << ", Contact: " << companies[i].contactNumber << endl;
        }
    }
};

int main() {
    InsuranceService service;
    
    service.addCar(1, "Toyota", "Camry", "John Doe");
    service.addCar(2, "Honda", "Civic", "Jane Smith");
    
    service.addCompany(1, "ABC Insurance", "123-456-7890");
    service.addCompany(2, "XYZ Insurance", "987-654-3210");
    
    service.displayCars();
    service.displayCompanies();
    
    service.updateCar(1, "Toyota", "Corolla", "John Doe");
    service.updateCompany(1, "ABC Corp", "123-456-7890");
    
    service.displayCars();
    service.displayCompanies();
    
    service.deleteCar(2);
    service.deleteCompany(2);
    
    service.displayCars();
    service.displayCompanies();
    
    return 0;
}