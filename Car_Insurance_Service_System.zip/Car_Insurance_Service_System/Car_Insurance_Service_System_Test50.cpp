#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Car {
public:
    string plateNumber;
    string model;
    string owner;

    Car(string p, string m, string o) : plateNumber(p), model(m), owner(o) {}
};

class InsuranceCompany {
public:
    string name;
    string policyNumber;

    InsuranceCompany(string n, string p) : name(n), policyNumber(p) {}
};

class InsuranceService {
private:
    vector<Car> cars;
    vector<InsuranceCompany> companies;

public:
    void addCar(string p, string m, string o) {
        cars.push_back(Car(p, m, o));
    }

    void addCompany(string n, string p) {
        companies.push_back(InsuranceCompany(n, p));
    }

    void deleteCar(string p) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->plateNumber == p) {
                cars.erase(it);
                break;
            }
        }
    }

    void deleteCompany(string n) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == n) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCar(string p, string m, string o) {
        for (auto& car : cars) {
            if (car.plateNumber == p) {
                car.model = m;
                car.owner = o;
                break;
            }
        }
    }

    void updateCompany(string n, string p) {
        for (auto& company : companies) {
            if (company.name == n) {
                company.policyNumber = p;
                break;
            }
        }
    }

    void searchCar(string p) {
        for (auto& car : cars) {
            if (car.plateNumber == p) {
                cout << "Car Found: " << car.plateNumber << ", " << car.model << ", " << car.owner << endl;
                return;
            }
        }
        cout << "Car Not Found" << endl;
    }

    void searchCompany(string n) {
        for (auto& company : companies) {
            if (company.name == n) {
                cout << "Company Found: " << company.name << ", " << company.policyNumber << endl;
                return;
            }
        }
        cout << "Company Not Found" << endl;
    }

    void displayCars() {
        for (auto& car : cars) {
            cout << "Car: " << car.plateNumber << ", " << car.model << ", " << car.owner << endl;
        }
    }

    void displayCompanies() {
        for (auto& company : companies) {
            cout << "Company: " << company.name << ", " << company.policyNumber << endl;
        }
    }
};

int main() {
    InsuranceService service;
    service.addCar("ABC123", "Toyota Camry", "John Doe");
    service.addCompany("SafeGuard", "POL12345");

    cout << "Cars:" << endl;
    service.displayCars();

    cout << "Companies:" << endl;
    service.displayCompanies();

    service.updateCar("ABC123", "Honda Accord", "Jane Doe");
    service.updateCompany("SafeGuard", "POL67890");

    cout << "\nAfter Update:" << endl;
    service.displayCars();
    service.displayCompanies();

    service.searchCar("ABC123");
    service.searchCompany("SafeGuard");

    service.deleteCar("ABC123");
    service.deleteCompany("SafeGuard");

    cout << "\nAfter Deletion:" << endl;
    service.displayCars();
    service.displayCompanies();

    return 0;
}