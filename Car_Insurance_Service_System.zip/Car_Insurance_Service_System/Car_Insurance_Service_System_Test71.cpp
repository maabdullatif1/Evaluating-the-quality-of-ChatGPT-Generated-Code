#include <iostream>
#include <string>
#include <vector>

class Car {
public:
    std::string licensePlate;
    std::string model;
    std::string owner;

    Car() {}

    Car(const std::string &licensePlate, const std::string &model, const std::string &owner)
        : licensePlate(licensePlate), model(model), owner(owner) {}
};

class InsuranceCompany {
public:
    std::string companyName;
    std::string policyNumber;

    InsuranceCompany() {}

    InsuranceCompany(const std::string &companyName, const std::string &policyNumber)
        : companyName(companyName), policyNumber(policyNumber) {}
};

class InsuranceService {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(const Car &car) {
        cars.push_back(car);
    }

    void addInsuranceCompany(const InsuranceCompany &company) {
        companies.push_back(company);
    }

    void deleteCar(const std::string &licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                return;
            }
        }
    }

    void deleteInsuranceCompany(const std::string &companyName) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->companyName == companyName) {
                companies.erase(it);
                return;
            }
        }
    }

    void updateCar(const std::string &licensePlate, const Car &newData) {
        for (auto &car : cars) {
            if (car.licensePlate == licensePlate) {
                car = newData;
                return;
            }
        }
    }

    void updateInsuranceCompany(const std::string &companyName, const InsuranceCompany &newData) {
        for (auto &company : companies) {
            if (company.companyName == companyName) {
                company = newData;
                return;
            }
        }
    }

    Car* searchCar(const std::string &licensePlate) {
        for (auto &car : cars) {
            if (car.licensePlate == licensePlate) {
                return &car;
            }
        }
        return nullptr;
    }

    InsuranceCompany* searchInsuranceCompany(const std::string &companyName) {
        for (auto &company : companies) {
            if (company.companyName == companyName) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayCars() const {
        for (const auto &car : cars) {
            std::cout << "License Plate: " << car.licensePlate
                      << ", Model: " << car.model
                      << ", Owner: " << car.owner << std::endl;
        }
    }

    void displayInsuranceCompanies() const {
        for (const auto &company : companies) {
            std::cout << "Company Name: " << company.companyName
                      << ", Policy Number: " << company.policyNumber << std::endl;
        }
    }
};

int main() {
    InsuranceService service;

    service.addCar(Car("ABC123", "Toyota Camry", "John Doe"));
    service.addCar(Car("XYZ789", "Honda Civic", "Jane Smith"));

    service.addInsuranceCompany(InsuranceCompany("GoodInsure", "P1234567"));
    service.addInsuranceCompany(InsuranceCompany("SafeCover", "P7654321"));

    service.displayCars();
    service.displayInsuranceCompanies();

    Car* car = service.searchCar("ABC123");
    if (car) {
        std::cout << "Found car: " << car->licensePlate << std::endl;
    }

    InsuranceCompany* company = service.searchInsuranceCompany("GoodInsure");
    if (company) {
        std::cout << "Found company: " << company->companyName << std::endl;
    }

    service.updateCar("XYZ789", Car("XYZ789", "Honda Accord", "Jane Smith"));
    service.updateInsuranceCompany("SafeCover", InsuranceCompany("SafeCover", "P7654322"));

    service.deleteCar("ABC123");
    service.deleteInsuranceCompany("GoodInsure");

    service.displayCars();
    service.displayInsuranceCompanies();

    return 0;
}