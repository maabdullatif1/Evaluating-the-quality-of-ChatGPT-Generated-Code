#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string model;
    string owner;

    Car(int id, const string& model, const string& owner) : id(id), model(model), owner(owner) {}
};

class InsuranceCompany {
public:
    int id;
    string name;
    string address;

    InsuranceCompany(int id, const string& name, const string& address) : id(id), name(name), address(address) {}
};

class InsuranceService {
    vector<Car> cars;
    vector<InsuranceCompany> companies;

public:
    void addCar(int id, const string& model, const string& owner) {
        cars.push_back(Car(id, model, owner));
    }

    void deleteCar(int id) {
        cars.erase(remove_if(cars.begin(), cars.end(), [id](Car& car) { return car.id == id; }), cars.end());
    }

    void updateCar(int id, const string& model, const string& owner) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.model = model;
                car.owner = owner;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) return &car;
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << endl;
        }
    }

    void addCompany(int id, const string& name, const string& address) {
        companies.push_back(InsuranceCompany(id, name, address));
    }

    void deleteCompany(int id) {
        companies.erase(remove_if(companies.begin(), companies.end(), [id](InsuranceCompany& company) { return company.id == id; }), companies.end());
    }

    void updateCompany(int id, const string& name, const string& address) {
        for (auto& company : companies) {
            if (company.id == id) {
                company.name = name;
                company.address = address;
            }
        }
    }

    InsuranceCompany* searchCompany(int id) {
        for (auto& company : companies) {
            if (company.id == id) return &company;
        }
        return nullptr;
    }

    void displayCompanies() {
        for (const auto& company : companies) {
            cout << "Company ID: " << company.id << ", Name: " << company.name << ", Address: " << company.address << endl;
        }
    }
};

int main() {
    InsuranceService service;
    service.addCar(1, "Toyota", "Alice");
    service.addCar(2, "Honda", "Bob");
    service.addCompany(1, "InsureCo", "123 Elm St");
    service.addCompany(2, "CoverAll", "456 Oak Rd");

    cout << "Cars:\n";
    service.displayCars();

    cout << "\nCompanies:\n";
    service.displayCompanies();

    return 0;
}