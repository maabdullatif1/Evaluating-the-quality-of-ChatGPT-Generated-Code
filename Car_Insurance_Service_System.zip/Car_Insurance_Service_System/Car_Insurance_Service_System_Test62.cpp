#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string vin;
    std::string model;
    std::string owner;

    Car(std::string v, std::string m, std::string o) : vin(v), model(m), owner(o) {}
};

class InsuranceCompany {
public:
    std::string name;
    std::string address;

    InsuranceCompany(std::string n, std::string a) : name(n), address(a) {}
};

class InsuranceServiceSystem {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(const std::string& vin, const std::string& model, const std::string& owner) {
        cars.push_back(Car(vin, model, owner));
    }

    void deleteCar(const std::string& vin) {
        for (size_t i = 0; i < cars.size(); ++i) {
            if (cars[i].vin == vin) {
                cars.erase(cars.begin() + i);
                break;
            }
        }
    }

    void updateCar(const std::string& vin, const std::string& newModel, const std::string& newOwner) {
        for (auto& car : cars) {
            if (car.vin == vin) {
                car.model = newModel;
                car.owner = newOwner;
                break;
            }
        }
    }

    Car* searchCar(const std::string& vin) {
        for (auto& car : cars) {
            if (car.vin == vin) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "VIN: " << car.vin << ", Model: " << car.model << ", Owner: " << car.owner << std::endl;
        }
    }

    void addCompany(const std::string& name, const std::string& address) {
        companies.push_back(InsuranceCompany(name, address));
    }

    void deleteCompany(const std::string& name) {
        for (size_t i = 0; i < companies.size(); ++i) {
            if (companies[i].name == name) {
                companies.erase(companies.begin() + i);
                break;
            }
        }
    }

    void updateCompany(const std::string& name, const std::string& newAddress) {
        for (auto& company : companies) {
            if (company.name == name) {
                company.address = newAddress;
                break;
            }
        }
    }

    InsuranceCompany* searchCompany(const std::string& name) {
        for (auto& company : companies) {
            if (company.name == name) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayCompanies() {
        for (const auto& company : companies) {
            std::cout << "Name: " << company.name << ", Address: " << company.address << std::endl;
        }
    }
};

int main() {
    InsuranceServiceSystem system;
    system.addCar("1HGCM82633A004352", "Honda Accord", "John Doe");
    system.addCompany("InsureCo", "123 Insurance Ave");
    system.displayCars();
    system.displayCompanies();
    return 0;
}