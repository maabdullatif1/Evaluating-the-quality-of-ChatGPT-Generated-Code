#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string ownerName;

    Car(std::string lp, std::string owner) : licensePlate(lp), ownerName(owner) {}
};

class InsuranceCompany {
public:
    std::string companyName;
    std::string contactInfo;

    InsuranceCompany(std::string name, std::string contact) : companyName(name), contactInfo(contact) {}
};

class CarInsuranceServiceSystem {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

    int findCar(const std::string& licensePlate) {
        for (size_t i = 0; i < cars.size(); ++i) {
            if (cars[i].licensePlate == licensePlate) return i;
        }
        return -1;
    }

    int findCompany(const std::string& companyName) {
        for (size_t i = 0; i < companies.size(); ++i) {
            if (companies[i].companyName == companyName) return i;
        }
        return -1;
    }

public:
    void addCar(const std::string& licensePlate, const std::string& ownerName) {
        if (findCar(licensePlate) == -1) {
            cars.emplace_back(licensePlate, ownerName);
        }
    }

    void deleteCar(const std::string& licensePlate) {
        int index = findCar(licensePlate);
        if (index != -1) {
            cars.erase(cars.begin() + index);
        }
    }

    void updateCar(const std::string& licensePlate, const std::string& newOwnerName) {
        int index = findCar(licensePlate);
        if (index != -1) {
            cars[index].ownerName = newOwnerName;
        }
    }

    void searchCar(const std::string& licensePlate) {
        int index = findCar(licensePlate);
        if (index != -1) {
            std::cout << "License Plate: " << cars[index].licensePlate << ", Owner: " << cars[index].ownerName << "\n";
        } else {
            std::cout << "Car not found\n";
        }
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "License Plate: " << car.licensePlate << ", Owner: " << car.ownerName << "\n";
        }
    }

    void addCompany(const std::string& companyName, const std::string& contactInfo) {
        if (findCompany(companyName) == -1) {
            companies.emplace_back(companyName, contactInfo);
        }
    }

    void deleteCompany(const std::string& companyName) {
        int index = findCompany(companyName);
        if (index != -1) {
            companies.erase(companies.begin() + index);
        }
    }

    void updateCompany(const std::string& companyName, const std::string& newContactInfo) {
        int index = findCompany(companyName);
        if (index != -1) {
            companies[index].contactInfo = newContactInfo;
        }
    }

    void searchCompany(const std::string& companyName) {
        int index = findCompany(companyName);
        if (index != -1) {
            std::cout << "Company: " << companies[index].companyName << ", Contact: " << companies[index].contactInfo << "\n";
        } else {
            std::cout << "Company not found\n";
        }
    }

    void displayCompanies() {
        for (const auto& company : companies) {
            std::cout << "Company: " << company.companyName << ", Contact: " << company.contactInfo << "\n";
        }
    }
};

int main() {
    CarInsuranceServiceSystem system;
    system.addCar("123ABC", "John Doe");
    system.addCar("456DEF", "Jane Smith");
    system.addCompany("InsureCorp", "123-456-7890");
    system.addCompany("SafeDrive", "098-765-4321");

    system.displayCars();
    system.displayCompanies();

    system.searchCar("123ABC");
    system.searchCompany("InsureCorp");

    system.updateCar("123ABC", "Johnathan Doe");
    system.updateCompany("InsureCorp", "111-222-3333");

    system.displayCars();
    system.displayCompanies();

    system.deleteCar("456DEF");
    system.deleteCompany("SafeDrive");

    system.displayCars();
    system.displayCompanies();

    return 0;
}