#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    string plateNumber;
    string model;
    string owner;
};

struct InsuranceCompany {
    string name;
    string address;
    string contactNumber;
};

vector<Car> cars;
vector<InsuranceCompany> companies;

void addCar() {
    Car car;
    cout << "Enter Plate Number: ";
    cin >> car.plateNumber;
    cout << "Enter Model: ";
    cin >> car.model;
    cout << "Enter Owner: ";
    cin >> car.owner;
    cars.push_back(car);
}

void addCompany() {
    InsuranceCompany company;
    cout << "Enter Company Name: ";
    cin.ignore();
    getline(cin, company.name);
    cout << "Enter Address: ";
    getline(cin, company.address);
    cout << "Enter Contact Number: ";
    getline(cin, company.contactNumber);
    companies.push_back(company);
}

void deleteCar() {
    string plateNumber;
    cout << "Enter Plate Number of Car to Delete: ";
    cin >> plateNumber;
    for (auto it = cars.begin(); it != cars.end(); ++it) {
        if (it->plateNumber == plateNumber) {
            cars.erase(it);
            cout << "Car deleted successfully.\n";
            return;
        }
    }
    cout << "Car not found.\n";
}

void deleteCompany() {
    string companyName;
    cout << "Enter Name of Company to Delete: ";
    cin.ignore();
    getline(cin, companyName);
    for (auto it = companies.begin(); it != companies.end(); ++it) {
        if (it->name == companyName) {
            companies.erase(it);
            cout << "Company deleted successfully.\n";
            return;
        }
    }
    cout << "Company not found.\n";
}

void updateCar() {
    string plateNumber;
    cout << "Enter Plate Number of Car to Update: ";
    cin >> plateNumber;
    for (auto &car : cars) {
        if (car.plateNumber == plateNumber) {
            cout << "Enter New Model: ";
            cin >> car.model;
            cout << "Enter New Owner: ";
            cin >> car.owner;
            cout << "Car updated successfully.\n";
            return;
        }
    }
    cout << "Car not found.\n";
}

void updateCompany() {
    string companyName;
    cout << "Enter Name of Company to Update: ";
    cin.ignore();
    getline(cin, companyName);
    for (auto &company : companies) {
        if (company.name == companyName) {
            cout << "Enter New Address: ";
            getline(cin, company.address);
            cout << "Enter New Contact Number: ";
            getline(cin, company.contactNumber);
            cout << "Company updated successfully.\n";
            return;
        }
    }
    cout << "Company not found.\n";
}

void searchCar() {
    string plateNumber;
    cout << "Enter Plate Number of Car to Search: ";
    cin >> plateNumber;
    for (const auto &car : cars) {
        if (car.plateNumber == plateNumber) {
            cout << "Plate Number: " << car.plateNumber
                 << " Model: " << car.model
                 << " Owner: " << car.owner << endl;
            return;
        }
    }
    cout << "Car not found.\n";
}

void searchCompany() {
    string companyName;
    cout << "Enter Name of Company to Search: ";
    cin.ignore();
    getline(cin, companyName);
    for (const auto &company : companies) {
        if (company.name == companyName) {
            cout << "Name: " << company.name
                 << " Address: " << company.address
                 << " Contact Number: " << company.contactNumber << endl;
            return;
        }
    }
    cout << "Company not found.\n";
}

void displayCars() {
    for (const auto &car : cars) {
        cout << "Plate Number: " << car.plateNumber
             << " Model: " << car.model
             << " Owner: " << car.owner << endl;
    }
}

void displayCompanies() {
    for (const auto &company : companies) {
        cout << "Name: " << company.name
             << " Address: " << company.address
             << " Contact Number: " << company.contactNumber << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "Car Insurance Service System\n"
             << "1. Add Car\n"
             << "2. Add Insurance Company\n"
             << "3. Delete Car\n"
             << "4. Delete Insurance Company\n"
             << "5. Update Car\n"
             << "6. Update Insurance Company\n"
             << "7. Search Car\n"
             << "8. Search Insurance Company\n"
             << "9. Display All Cars\n"
             << "10. Display All Insurance Companies\n"
             << "11. Exit\n"
             << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addCar(); break;
            case 2: addCompany(); break;
            case 3: deleteCar(); break;
            case 4: deleteCompany(); break;
            case 5: updateCar(); break;
            case 6: updateCompany(); break;
            case 7: searchCar(); break;
            case 8: searchCompany(); break;
            case 9: displayCars(); break;
            case 10: displayCompanies(); break;
        }
    } while (choice != 11);
    return 0;
}