#include <iostream>
#include <string>
using namespace std;

struct Car {
    string registrationNumber;
    string model;
    int year;
};

struct InsuranceCompany {
    string name;
    string policyNumber;
    string coverage;
    Car car;
};

class CarInsuranceSystem {
private:
    InsuranceCompany companies[100];
    int companyCount;

public:
    CarInsuranceSystem() : companyCount(0) {}

    void addCompany(const string& companyName, const string& policyNumber, const string& coverage, const Car& car) {
        if (companyCount < 100) {
            companies[companyCount].name = companyName;
            companies[companyCount].policyNumber = policyNumber;
            companies[companyCount].coverage = coverage;
            companies[companyCount].car = car;
            companyCount++;
        }
    }

    void deleteCompany(const string& policyNumber) {
        for (int i = 0; i < companyCount; i++) {
            if (companies[i].policyNumber == policyNumber) {
                for (int j = i; j < companyCount - 1; j++) {
                    companies[j] = companies[j + 1];
                }
                companyCount--;
                break;
            }
        }
    }

    void updateCompany(const string& policyNumber, const string& newCoverage) {
        for (int i = 0; i < companyCount; i++) {
            if (companies[i].policyNumber == policyNumber) {
                companies[i].coverage = newCoverage;
                break;
            }
        }
    }

    InsuranceCompany* searchCompany(const string& policyNumber) {
        for (int i = 0; i < companyCount; i++) {
            if (companies[i].policyNumber == policyNumber) {
                return &companies[i];
            }
        }
        return nullptr;
    }

    void displayCompanies() {
        for (int i = 0; i < companyCount; i++) {
            cout << "Company Name: " << companies[i].name << endl;
            cout << "Policy Number: " << companies[i].policyNumber << endl;
            cout << "Coverage: " << companies[i].coverage << endl;
            cout << "Car Registration Number: " << companies[i].car.registrationNumber << endl;
            cout << "Car Model: " << companies[i].car.model << endl;
            cout << "Car Year: " << companies[i].car.year << endl << endl;
        }
    }
};

int main() {
    CarInsuranceSystem system;

    Car car1 = {"123ABC", "Toyota Corolla", 2010};
    system.addCompany("Company A", "POL123", "Full Coverage", car1);

    Car car2 = {"456DEF", "Honda Civic", 2015};
    system.addCompany("Company B", "POL456", "Third Party", car2);

    system.displayCompanies();

    system.updateCompany("POL123", "Third Party, Fire and Theft");
    system.displayCompanies();

    system.deleteCompany("POL456");
    system.displayCompanies();

    return 0;
}