#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string make;
    string model;
    int year;

    Car(int id, string make, string model, int year)
        : id(id), make(make), model(model), year(year) {}
};

class InsuranceCompany {
public:
    int id;
    string name;
    string address;

    InsuranceCompany(int id, string name, string address)
        : id(id), name(name), address(address) {}
};

class InsuranceServiceSystem {
public:
    vector<Car> cars;
    vector<InsuranceCompany> companies;

    void addCar(int id, string make, string model, int year) {
        cars.push_back(Car(id, make, model, year));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string make, string model, int year) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.year = year;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) return &car;
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << ", Year: " << car.year << endl;
        }
    }

    void addCompany(int id, string name, string address) {
        companies.push_back(InsuranceCompany(id, name, address));
    }

    void deleteCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCompany(int id, string name, string address) {
        for (auto &company : companies) {
            if (company.id == id) {
                company.name = name;
                company.address = address;
                break;
            }
        }
    }

    InsuranceCompany* searchCompany(int id) {
        for (auto &company : companies) {
            if (company.id == id) return &company;
        }
        return nullptr;
    }

    void displayCompanies() {
        for (const auto &company : companies) {
            cout << "ID: " << company.id << ", Name: " << company.name << ", Address: " << company.address << endl;
        }
    }
};

int main() {
    InsuranceServiceSystem system;

    system.addCar(1, "Toyota", "Camry", 2020);
    system.addCar(2, "Honda", "Civic", 2019);
    system.addCompany(1, "InsureCo", "123 Main St");
    system.addCompany(2, "SafeDrive", "456 Elm St");

    cout << "All Cars:" << endl;
    system.displayCars();

    cout << "\nAll Companies:" << endl;
    system.displayCompanies();

    system.updateCar(1, "Toyota", "Corolla", 2021);
    system.updateCompany(1, "InsureCo", "789 Oak St");

    cout << "\nUpdated Cars:" << endl;
    system.displayCars();

    cout << "\nUpdated Companies:" << endl;
    system.displayCompanies();

    Car* searchedCar = system.searchCar(2);
    if (searchedCar) {
        cout << "\nSearched Car ID 2: " << searchedCar->make << " " << searchedCar->model << endl;
    }

    InsuranceCompany* searchedCompany = system.searchCompany(2);
    if (searchedCompany) {
        cout << "Searched Company ID 2: " << searchedCompany->name << endl;
    }

    system.deleteCar(1);
    system.deleteCompany(1);

    cout << "\nCars after deletion:" << endl;
    system.displayCars();

    cout << "\nCompanies after deletion:" << endl;
    system.displayCompanies();

    return 0;
}