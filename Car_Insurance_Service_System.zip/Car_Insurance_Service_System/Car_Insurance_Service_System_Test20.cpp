#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string make;
    std::string model;
    int year;
    
    Car(int i, std::string mk, std::string mdl, int yr) 
        : id(i), make(mk), model(mdl), year(yr) {}
};

class InsuranceCompany {
public:
    int id;
    std::string name;
    std::string contact;
    
    InsuranceCompany(int i, std::string nm, std::string cnt) 
        : id(i), name(nm), contact(cnt) {}
};

class InsuranceService {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;
    
public:
    void addCar(int id, std::string make, std::string model, int year) {
        cars.push_back(Car(id, make, model, year));
    }
    
    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }
    
    void updateCar(int id, std::string make, std::string model, int year) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.year = year;
                break;
            }
        }
    }
    
    void searchCar(int id) {
        for (const auto &car : cars) {
            if (car.id == id) {
                std::cout << "Car ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << ", Year: " << car.year << "\n";
                return;
            }
        }
        std::cout << "Car not found\n";
    }
    
    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "Car ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << ", Year: " << car.year << "\n";
        }
    }
    
    void addCompany(int id, std::string name, std::string contact) {
        companies.push_back(InsuranceCompany(id, name, contact));
    }
    
    void deleteCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }
    
    void updateCompany(int id, std::string name, std::string contact) {
        for (auto &company : companies) {
            if (company.id == id) {
                company.name = name;
                company.contact = contact;
                break;
            }
        }
    }
    
    void searchCompany(int id) {
        for (const auto &company : companies) {
            if (company.id == id) {
                std::cout << "Company ID: " << company.id << ", Name: " << company.name << ", Contact: " << company.contact << "\n";
                return;
            }
        }
        std::cout << "Company not found\n";
    }
    
    void displayCompanies() {
        for (const auto &company : companies) {
            std::cout << "Company ID: " << company.id << ", Name: " << company.name << ", Contact: " << company.contact << "\n";
        }
    }
};

int main() {
    InsuranceService service;
    service.addCar(1, "Toyota", "Camry", 2020);
    service.addCar(2, "Honda", "Civic", 2019);
    service.addCompany(1, "AllState", "123-456-7890");
    service.addCompany(2, "Geico", "098-765-4321");
    
    service.displayCars();
    service.displayCompanies();
    
    service.updateCar(1, "Toyota", "Corolla", 2021);
    service.searchCar(1);
    
    service.deleteCar(2);
    service.displayCars();
    
    service.updateCompany(1, "AllState Insurance", "111-222-3333");
    service.searchCompany(1);
    
    service.deleteCompany(2);
    service.displayCompanies();
    
    return 0;
}