#include <iostream>
#include <string>
using namespace std;

struct Car {
    int id;
    string ownerName;
    string model;
    string insuranceCompany;
};

struct InsuranceCompany {
    int id;
    string name;
    string contact;
};

class CarInsuranceService {
private:
    Car cars[100];
    InsuranceCompany companies[100];
    int carCount;
    int companyCount;

public:
    CarInsuranceService() : carCount(0), companyCount(0) {}

    void addCar(int id, string ownerName, string model, string insuranceCompany) {
        cars[carCount++] = {id, ownerName, model, insuranceCompany};
    }

    void addInsuranceCompany(int id, string name, string contact) {
        companies[companyCount++] = {id, name, contact};
    }

    void deleteCar(int id) {
        for (int i = 0; i < carCount; ++i) {
            if (cars[i].id == id) {
                for (int j = i; j < carCount - 1; ++j) {
                    cars[j] = cars[j + 1];
                }
                --carCount;
                break;
            }
        }
    }

    void deleteInsuranceCompany(int id) {
        for (int i = 0; i < companyCount; ++i) {
            if (companies[i].id == id) {
                for (int j = i; j < companyCount - 1; ++j) {
                    companies[j] = companies[j + 1];
                }
                --companyCount;
                break;
            }
        }
    }

    void updateCar(int id, string newOwnerName, string newModel, string newInsuranceCompany) {
        for (int i = 0; i < carCount; ++i) {
            if (cars[i].id == id) {
                cars[i] = {id, newOwnerName, newModel, newInsuranceCompany};
                break;
            }
        }
    }

    void updateInsuranceCompany(int id, string newName, string newContact) {
        for (int i = 0; i < companyCount; ++i) {
            if (companies[i].id == id) {
                companies[i] = {id, newName, newContact};
                break;
            }
        }
    }

    void searchCar(int id) {
        for (int i = 0; i < carCount; ++i) {
            if (cars[i].id == id) {
                displayCar(cars[i]);
                return;
            }
        }
        cout << "Car not found.\n";
    }

    void searchInsuranceCompany(int id) {
        for (int i = 0; i < companyCount; ++i) {
            if (companies[i].id == id) {
                displayInsuranceCompany(companies[i]);
                return;
            }
        }
        cout << "Insurance Company not found.\n";
    }

    void displayCar(const Car &car) {
        cout << "Car ID: " << car.id
             << ", Owner: " << car.ownerName
             << ", Model: " << car.model
             << ", Insurance Company: " << car.insuranceCompany << endl;
    }

    void displayInsuranceCompany(const InsuranceCompany &company) {
        cout << "Company ID: " << company.id
             << ", Name: " << company.name
             << ", Contact: " << company.contact << endl;
    }

    void displayAllCars() {
        for (int i = 0; i < carCount; ++i) {
            displayCar(cars[i]);
        }
    }

    void displayAllInsuranceCompanies() {
        for (int i = 0; i < companyCount; ++i) {
            displayInsuranceCompany(companies[i]);
        }
    }
};

int main() {
    CarInsuranceService service;
    service.addCar(1, "John Doe", "Toyota Camry", "ABC Insurance");
    service.addCar(2, "Jane Smith", "Honda Accord", "XYZ Insurance");
    service.addInsuranceCompany(1, "ABC Insurance", "123-456-7890");
    service.addInsuranceCompany(2, "XYZ Insurance", "098-765-4321");

    service.displayAllCars();
    service.displayAllInsuranceCompanies();

    service.searchCar(1);
    service.updateCar(1, "John Doe", "Toyota Corolla", "ABC Insurance");
    service.searchCar(1);

    service.deleteCar(2);
    service.displayAllCars();

    service.searchInsuranceCompany(1);
    service.updateInsuranceCompany(1, "ABC Insurance Ltd.", "123-456-7899");
    service.searchInsuranceCompany(1);

    service.deleteInsuranceCompany(2);
    service.displayAllInsuranceCompanies();

    return 0;
}