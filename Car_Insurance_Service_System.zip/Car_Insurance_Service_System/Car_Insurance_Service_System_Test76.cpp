#include <iostream>
#include <vector>
#include <string>

struct Car {
    std::string licensePlate;
    std::string ownerName;
    std::string model;
};

struct InsuranceCompany {
    std::string companyName;
    std::string policyNumber;
};

class InsuranceServiceSystem {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(const std::string& licensePlate, const std::string& ownerName, const std::string& model) {
        cars.push_back({licensePlate, ownerName, model});
    }

    void deleteCar(const std::string& licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string& licensePlate, const std::string& newOwnerName, const std::string& newModel) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                car.ownerName = newOwnerName;
                car.model = newModel;
                break;
            }
        }
    }

    void searchCar(const std::string& licensePlate) {
        for (const auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                std::cout << "License Plate: " << car.licensePlate << ", Owner: " << car.ownerName << ", Model: " << car.model << std::endl;
                return;
            }
        }
        std::cout << "Car not found." << std::endl;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "License Plate: " << car.licensePlate << ", Owner: " << car.ownerName << ", Model: " << car.model << std::endl;
        }
    }

    void addCompany(const std::string& companyName, const std::string& policyNumber) {
        companies.push_back({companyName, policyNumber});
    }

    void deleteCompany(const std::string& companyName) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->companyName == companyName) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCompany(const std::string& companyName, const std::string& newPolicyNumber) {
        for (auto& company : companies) {
            if (company.companyName == companyName) {
                company.policyNumber = newPolicyNumber;
                break;
            }
        }
    }

    void searchCompany(const std::string& companyName) {
        for (const auto& company : companies) {
            if (company.companyName == companyName) {
                std::cout << "Company Name: " << company.companyName << ", Policy Number: " << company.policyNumber << std::endl;
                return;
            }
        }
        std::cout << "Company not found." << std::endl;
    }

    void displayCompanies() {
        for (const auto& company : companies) {
            std::cout << "Company Name: " << company.companyName << ", Policy Number: " << company.policyNumber << std::endl;
        }
    }
};

int main() {
    InsuranceServiceSystem system;
    system.addCar("ABC123", "John Doe", "Toyota Corolla");
    system.addCompany("XYZ Insurance", "POL12345");
    system.displayCars();
    system.displayCompanies();
    system.searchCar("ABC123");
    system.searchCompany("XYZ Insurance");
    system.updateCar("ABC123", "Jane Smith", "Honda Civic");
    system.updateCompany("XYZ Insurance", "POL54321");
    system.displayCars();
    system.displayCompanies();
    system.deleteCar("ABC123");
    system.deleteCompany("XYZ Insurance");
    system.displayCars();
    system.displayCompanies();
    return 0;
}