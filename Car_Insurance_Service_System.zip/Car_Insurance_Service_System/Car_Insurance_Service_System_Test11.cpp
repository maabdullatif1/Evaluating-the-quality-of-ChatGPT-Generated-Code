#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string make;
    std::string model;
    int year;
    std::string vin;

    Car(const std::string& make, const std::string& model, int year, const std::string& vin)
        : make(make), model(model), year(year), vin(vin) {}
};

class InsuranceCompany {
public:
    std::string name;
    std::string policyNumber;
    std::string customerName;

    InsuranceCompany(const std::string& name, const std::string& policyNumber, const std::string& customerName)
        : name(name), policyNumber(policyNumber), customerName(customerName) {}
};

class System {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(const std::string& make, const std::string& model, int year, const std::string& vin) {
        cars.push_back(Car(make, model, year, vin));
    }
    
    void deleteCar(const std::string& vin) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->vin == vin) {
                cars.erase(it);
                return;
            }
        }
    }

    void updateCar(const std::string& vin, const std::string& newMake, const std::string& newModel, int newYear) {
        for (auto& car : cars) {
            if (car.vin == vin) {
                car.make = newMake;
                car.model = newModel;
                car.year = newYear;
                return;
            }
        }
    }

    Car* searchCar(const std::string& vin) {
        for (auto& car : cars) {
            if (car.vin == vin) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Make: " << car.make << ", Model: " << car.model << ", Year: " << car.year << ", VIN: " << car.vin << "\n";
        }
    }

    void addInsuranceCompany(const std::string& name, const std::string& policyNumber, const std::string& customerName) {
        companies.push_back(InsuranceCompany(name, policyNumber, customerName));
    }

    void deleteInsuranceCompany(const std::string& policyNumber) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->policyNumber == policyNumber) {
                companies.erase(it);
                return;
            }
        }
    }

    void updateInsuranceCompany(const std::string& policyNumber, const std::string& newName, const std::string& newCustomerName) {
        for (auto& company : companies) {
            if (company.policyNumber == policyNumber) {
                company.name = newName;
                company.customerName = newCustomerName;
                return;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(const std::string& policyNumber) {
        for (auto& company : companies) {
            if (company.policyNumber == policyNumber) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto& company : companies) {
            std::cout << "Name: " << company.name << ", Policy Number: " << company.policyNumber << ", Customer Name: " << company.customerName << "\n";
        }
    }
};

int main() {
    System system;
    system.addCar("Toyota", "Camry", 2020, "123ABC");
    system.addCar("Ford", "Fiesta", 2018, "456DEF");
    system.addInsuranceCompany("InsureCo", "POL123", "John Doe");
    system.addInsuranceCompany("CoveragePlus", "POL456", "Jane Smith");

    system.displayCars();
    system.displayInsuranceCompanies();

    return 0;
}