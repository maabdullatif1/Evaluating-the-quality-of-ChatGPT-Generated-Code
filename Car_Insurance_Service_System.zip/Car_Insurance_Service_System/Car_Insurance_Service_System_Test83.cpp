#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string model;
    std::string owner;
    Car(int id, std::string model, std::string owner)
        : id(id), model(model), owner(owner) {}
};

class InsuranceCompany {
public:
    int id;
    std::string name;
    std::string contactNumber;
    InsuranceCompany(int id, std::string name, std::string contactNumber)
        : id(id), name(name), contactNumber(contactNumber) {}
};

std::vector<Car> cars;
std::vector<InsuranceCompany> insuranceCompanies;

void addCar(int id, std::string model, std::string owner) {
    cars.push_back(Car(id, model, owner));
}

void deleteCar(int id) {
    for (auto it = cars.begin(); it != cars.end(); ++it) {
        if (it->id == id) {
            cars.erase(it);
            break;
        }
    }
}

void updateCar(int id, std::string model, std::string owner) {
    for (auto& car : cars) {
        if (car.id == id) {
            car.model = model;
            car.owner = owner;
            break;
        }
    }
}

Car* searchCar(int id) {
    for (auto& car : cars) {
        if (car.id == id) {
            return &car;
        }
    }
    return nullptr;
}

void displayCars() {
    for (const auto& car : cars) {
        std::cout << "Car ID: " << car.id 
                  << ", Model: " << car.model 
                  << ", Owner: " << car.owner << std::endl;
    }
}

void addInsuranceCompany(int id, std::string name, std::string contactNumber) {
    insuranceCompanies.push_back(InsuranceCompany(id, name, contactNumber));
}

void deleteInsuranceCompany(int id) {
    for (auto it = insuranceCompanies.begin(); it != insuranceCompanies.end(); ++it) {
        if (it->id == id) {
            insuranceCompanies.erase(it);
            break;
        }
    }
}

void updateInsuranceCompany(int id, std::string name, std::string contactNumber) {
    for (auto& company : insuranceCompanies) {
        if (company.id == id) {
            company.name = name;
            company.contactNumber = contactNumber;
            break;
        }
    }
}

InsuranceCompany* searchInsuranceCompany(int id) {
    for (auto& company : insuranceCompanies) {
        if (company.id == id) {
            return &company;
        }
    }
    return nullptr;
}

void displayInsuranceCompanies() {
    for (const auto& company : insuranceCompanies) {
        std::cout << "Company ID: " << company.id 
                  << ", Name: " << company.name 
                  << ", Contact Number: " << company.contactNumber << std::endl;
    }
}

int main() {
    addCar(1, "Toyota Camry", "John Doe");
    addCar(2, "Honda Accord", "Jane Smith");

    addInsuranceCompany(1, "InsureSafe", "123-456-7890");
    addInsuranceCompany(2, "CarCover", "098-765-4321");

    displayCars();
    displayInsuranceCompanies();

    updateCar(1, "Toyota Corolla", "John Doe");
    updateInsuranceCompany(2, "CarProtect", "111-222-3333");

    displayCars();
    displayInsuranceCompanies();

    return 0;
}