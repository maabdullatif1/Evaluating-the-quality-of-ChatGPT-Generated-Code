#include <iostream>
#include <string>
#include <vector>

struct Car {
    std::string plateNumber;
    std::string owner;
    std::string model;
};

struct InsuranceCompany {
    std::string name;
    std::string contactNumber;
};

class CarInsuranceService {
public:
    void addCar(const Car& car) {
        cars.push_back(car);
    }

    void deleteCar(const std::string& plateNumber) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->plateNumber == plateNumber) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string& plateNumber, const Car& updatedCar) {
        for (auto& car : cars) {
            if (car.plateNumber == plateNumber) {
                car = updatedCar;
                break;
            }
        }
    }

    Car* searchCar(const std::string& plateNumber) {
        for (auto& car : cars) {
            if (car.plateNumber == plateNumber) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Plate Number: " << car.plateNumber << ", Owner: " << car.owner << ", Model: " << car.model << "\n";
        }
    }

    void addInsuranceCompany(const InsuranceCompany& company) {
        companies.push_back(company);
    }

    void deleteInsuranceCompany(const std::string& name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(const std::string& name, const InsuranceCompany& updatedCompany) {
        for (auto& company : companies) {
            if (company.name == name) {
                company = updatedCompany;
                break;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(const std::string& name) {
        for (auto& company : companies) {
            if (company.name == name) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto& company : companies) {
            std::cout << "Company Name: " << company.name << ", Contact Number: " << company.contactNumber << "\n";
        }
    }

private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;
};

int main() {
    CarInsuranceService service;

    service.addCar({"ABC123", "John Doe", "Toyota Camry"});
    service.addCar({"XYZ789", "Jane Smith", "Honda Accord"});
    service.displayCars();

    service.addInsuranceCompany({"Acme Insurance", "123-456-7890"});
    service.addInsuranceCompany({"Best Insurance", "987-654-3210"});
    service.displayInsuranceCompanies();

    service.deleteCar("ABC123");
    service.displayCars();

    service.deleteInsuranceCompany("Best Insurance");
    service.displayInsuranceCompanies();

    service.updateCar("XYZ789", {"XYZ789", "Jane Doe", "Honda Civic"});
    service.displayCars();

    service.updateInsuranceCompany("Acme Insurance", {"Acme Insurance", "111-222-3333"});
    service.displayInsuranceCompanies();

    Car* foundCar = service.searchCar("XYZ789");
    if (foundCar) {
        std::cout << "Found Car: " << foundCar->plateNumber << "\n";
    }

    InsuranceCompany* foundCompany = service.searchInsuranceCompany("Acme Insurance");
    if (foundCompany) {
        std::cout << "Found Company: " << foundCompany->name << "\n";
    }

    return 0;
}