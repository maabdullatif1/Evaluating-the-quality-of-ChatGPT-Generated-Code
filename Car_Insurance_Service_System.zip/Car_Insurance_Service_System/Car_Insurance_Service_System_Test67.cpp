#include<iostream>
#include<string>
#include<vector>

class Car {
public:
    std::string plate;
    std::string owner;

    Car(std::string p, std::string o) : plate(p), owner(o) {}
};

class InsuranceCompany {
public:
    std::string name;
    std::string policyNumber;

    InsuranceCompany(std::string n, std::string p) : name(n), policyNumber(p) {}
};

class CarInsuranceService {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;
    
public:
    void addCar(std::string plate, std::string owner) {
        cars.push_back(Car(plate, owner));
    }
    
    void deleteCar(std::string plate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->plate == plate) {
                cars.erase(it);
                break;
            }
        }
    }
    
    void updateCar(std::string plate, std::string newOwner) {
        for (auto &car : cars) {
            if (car.plate == plate) {
                car.owner = newOwner;
            }
        }
    }
    
    Car* searchCar(std::string plate) {
        for (auto &car : cars) {
            if (car.plate == plate) {
                return &car;
            }
        }
        return nullptr;
    }
    
    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "Plate: " << car.plate << ", Owner: " << car.owner << std::endl;
        }
    }
    
    void addCompany(std::string name, std::string policyNumber) {
        companies.push_back(InsuranceCompany(name, policyNumber));
    }
    
    void deleteCompany(std::string name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }
    
    void updateCompany(std::string name, std::string newPolicyNumber) {
        for (auto &company : companies) {
            if (company.name == name) {
                company.policyNumber = newPolicyNumber;
            }
        }
    }
    
    InsuranceCompany* searchCompany(std::string name) {
        for (auto &company : companies) {
            if (company.name == name) {
                return &company;
            }
        }
        return nullptr;
    }
    
    void displayCompanies() {
        for (const auto &company : companies) {
            std::cout << "Name: " << company.name << ", Policy Number: " << company.policyNumber << std::endl;
        }
    }
};

int main() {
    CarInsuranceService service;
    service.addCar("ABC123", "John Doe");
    service.addCar("XYZ789", "Jane Smith");
    service.updateCar("XYZ789", "Jane Doe");
    service.displayCars();
    service.addCompany("Insurance Corp", "IC123456");
    service.addCompany("Secure Life", "SL654321");
    service.updateCompany("Secure Life", "SL654322");
    service.displayCompanies();
    return 0;
}