#include <iostream>
#include <string>
using namespace std;

const int MAX_ENTRIES = 100;

struct Car {
    string plateNumber;
    string brand;
    string model;
};

struct InsuranceCompany {
    string name;
    string policyNumber;
};

struct Entry {
    Car car;
    InsuranceCompany insurance;
};

class CarInsuranceSystem {
    Entry entries[MAX_ENTRIES];
    int entryCount;

public:
    CarInsuranceSystem() : entryCount(0) {}

    void addEntry() {
        if (entryCount < MAX_ENTRIES) {
            cout << "Enter plate number: ";
            cin >> entries[entryCount].car.plateNumber;
            cout << "Enter car brand: ";
            cin >> entries[entryCount].car.brand;
            cout << "Enter car model: ";
            cin >> entries[entryCount].car.model;
            cout << "Enter insurance company name: ";
            cin >> entries[entryCount].insurance.name;
            cout << "Enter policy number: ";
            cin >> entries[entryCount].insurance.policyNumber;
            entryCount++;
        } else {
            cout << "Maximum entries reached." << endl;
        }
    }

    void deleteEntry() {
        string plateNumber;
        cout << "Enter plate number to delete: ";
        cin >> plateNumber;
        for (int i = 0; i < entryCount; i++) {
            if (entries[i].car.plateNumber == plateNumber) {
                for (int j = i; j < entryCount - 1; j++) {
                    entries[j] = entries[j + 1];
                }
                entryCount--;
                cout << "Entry deleted." << endl;
                return;
            }
        }
        cout << "Entry not found." << endl;
    }

    void updateEntry() {
        string plateNumber;
        cout << "Enter plate number to update: ";
        cin >> plateNumber;
        for (int i = 0; i < entryCount; i++) {
            if (entries[i].car.plateNumber == plateNumber) {
                cout << "Enter new car brand: ";
                cin >> entries[i].car.brand;
                cout << "Enter new car model: ";
                cin >> entries[i].car.model;
                cout << "Enter new insurance company name: ";
                cin >> entries[i].insurance.name;
                cout << "Enter new policy number: ";
                cin >> entries[i].insurance.policyNumber;
                cout << "Entry updated." << endl;
                return;
            }
        }
        cout << "Entry not found." << endl;
    }

    void searchEntry() {
        string plateNumber;
        cout << "Enter plate number to search: ";
        cin >> plateNumber;
        for (int i = 0; i < entryCount; i++) {
            if (entries[i].car.plateNumber == plateNumber) {
                cout << "Brand: " << entries[i].car.brand << ", Model: " << entries[i].car.model
                     << ", Insurance: " << entries[i].insurance.name
                     << ", Policy: " << entries[i].insurance.policyNumber << endl;
                return;
            }
        }
        cout << "Entry not found." << endl;
    }

    void displayEntries() {
        for (int i = 0; i < entryCount; i++) {
            cout << "Plate: " << entries[i].car.plateNumber
                 << ", Brand: " << entries[i].car.brand
                 << ", Model: " << entries[i].car.model
                 << ", Insurance: " << entries[i].insurance.name
                 << ", Policy: " << entries[i].insurance.policyNumber << endl;
        }
    }
};

int main() {
    CarInsuranceSystem system;
    int choice;
    do {
        cout << "Car Insurance System" << endl;
        cout << "1. Add Entry" << endl;
        cout << "2. Delete Entry" << endl;
        cout << "3. Update Entry" << endl;
        cout << "4. Search Entry" << endl;
        cout << "5. Display Entries" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: system.addEntry(); break;
            case 2: system.deleteEntry(); break;
            case 3: system.updateEntry(); break;
            case 4: system.searchEntry(); break;
            case 5: system.displayEntries(); break;
        }
    } while (choice != 6);
    return 0;
}