#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Car {
public:
    int id;
    string make;
    string model;
    int year;
    
    Car(int id, string make, string model, int year)
        : id(id), make(make), model(model), year(year) {}
};

class InsuranceCompany {
public:
    int id;
    string name;
    string address;
    
    InsuranceCompany(int id, string name, string address)
        : id(id), name(name), address(address) {}
};

class CarInsuranceService {
private:
    vector<Car> cars;
    vector<InsuranceCompany> companies;
    
    template <typename T>
    int findIndexById(const vector<T>& vec, int id) {
        for (int i = 0; i < vec.size(); i++) {
            if (vec[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCar(int id, string make, string model, int year) {
        cars.push_back(Car(id, make, model, year));
    }
    
    void deleteCar(int id) {
        int index = findIndexById(cars, id);
        if (index != -1) cars.erase(cars.begin() + index);
    }
    
    void updateCar(int id, string make, string model, int year) {
        int index = findIndexById(cars, id);
        if (index != -1) cars[index] = Car(id, make, model, year);
    }
    
    void addInsuranceCompany(int id, string name, string address) {
        companies.push_back(InsuranceCompany(id, name, address));
    }
    
    void deleteInsuranceCompany(int id) {
        int index = findIndexById(companies, id);
        if (index != -1) companies.erase(companies.begin() + index);
    }
    
    void updateInsuranceCompany(int id, string name, string address) {
        int index = findIndexById(companies, id);
        if (index != -1) companies[index] = InsuranceCompany(id, name, address);
    }
    
    Car* searchCar(int id) {
        int index = findIndexById(cars, id);
        if (index != -1) return &cars[index];
        return nullptr;
    }
    
    InsuranceCompany* searchInsuranceCompany(int id) {
        int index = findIndexById(companies, id);
        if (index != -1) return &companies[index];
        return nullptr;
    }
    
    void displayCars() {
        for (auto& car : cars) {
            cout << "ID: " << car.id << ", Make: " << car.make
                 << ", Model: " << car.model << ", Year: " << car.year << endl;
        }
    }
    
    void displayInsuranceCompanies() {
        for (auto& company : companies) {
            cout << "ID: " << company.id << ", Name: " << company.name
                 << ", Address: " << company.address << endl;
        }
    }
};

int main() {
    CarInsuranceService service;
    service.addCar(1, "Toyota", "Corolla", 2019);
    service.addCar(2, "Honda", "Civic", 2020);
    service.addInsuranceCompany(1, "XYZ Insurance", "123 Main St");
    service.displayCars();
    service.displayInsuranceCompanies();
    service.updateCar(1, "Toyota", "Corolla LE", 2019);
    service.displayCars();
    service.deleteCar(2);
    service.displayCars();
    return 0;
}