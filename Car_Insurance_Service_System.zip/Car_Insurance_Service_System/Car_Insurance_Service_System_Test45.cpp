#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Car {
    int id;
    string model;
    string owner;
};

struct InsuranceCompany {
    int id;
    string name;
    string contactInfo;
};

class InsuranceServiceSystem {
    vector<Car> cars;
    vector<InsuranceCompany> companies;
    
public:
    void addCar(int id, string model, string owner) {
        cars.push_back({id, model, owner});
    }
    
    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }
    
    void updateCar(int id, string newModel, string newOwner) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.model = newModel;
                car.owner = newOwner;
                break;
            }
        }
    }
    
    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }
    
    void displayCars() {
        for (const auto &car : cars) {
            cout << "ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << endl;
        }
    }

    void addInsuranceCompany(int id, string name, string contactInfo) {
        companies.push_back({id, name, contactInfo});
    }

    void deleteInsuranceCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }
    
    void updateInsuranceCompany(int id, string newName, string newContactInfo) {
        for (auto &company : companies) {
            if (company.id == id) {
                company.name = newName;
                company.contactInfo = newContactInfo;
                break;
            }
        }
    }
    
    InsuranceCompany* searchInsuranceCompany(int id) {
        for (auto &company : companies) {
            if (company.id == id) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto &company : companies) {
            cout << "ID: " << company.id << ", Name: " << company.name << ", Contact: " << company.contactInfo << endl;
        }
    }
};

int main() {
    InsuranceServiceSystem system;

    system.addCar(1, "Toyota", "Alice");
    system.addCar(2, "Honda", "Bob");
    system.displayCars();
    
    system.addInsuranceCompany(1, "InsureCo", "123456");
    system.addInsuranceCompany(2, "SafeGuard", "789012");
    system.displayInsuranceCompanies();
    
    Car* car = system.searchCar(1);
    if (car) {
        cout << "Found car: " << car->model << ", " << car->owner << endl;
    }
    
    InsuranceCompany* company = system.searchInsuranceCompany(2);
    if (company) {
        cout << "Found insurance company: " << company->name << ", " << company->contactInfo << endl;
    }
    
    system.updateCar(2, "Nissan", "Charlie");
    system.updateInsuranceCompany(1, "InsurePlus", "654321");
    system.displayCars();
    system.displayInsuranceCompanies();

    return 0;
}