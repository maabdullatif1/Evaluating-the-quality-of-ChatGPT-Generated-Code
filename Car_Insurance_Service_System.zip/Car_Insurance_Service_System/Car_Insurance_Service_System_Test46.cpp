#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int carID;
    string ownerName;
    string model;
    string registrationNumber;

    Car(int id, string owner, string mdl, string regNo) : carID(id), ownerName(owner), model(mdl), registrationNumber(regNo) {}
};

class InsuranceCompany {
public:
    int companyID;
    string companyName;
    string contactNumber;

    InsuranceCompany(int id, string name, string contact) : companyID(id), companyName(name), contactNumber(contact) {}
};

class CarInsuranceService {
private:
    vector<Car> cars;
    vector<InsuranceCompany> companies;

public:
    void addCar(int id, string owner, string model, string regNo) {
        cars.push_back(Car(id, owner, model, regNo));
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->carID == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, string owner, string model, string regNo) {
        for (auto &car : cars) {
            if (car.carID == id) {
                car.ownerName = owner;
                car.model = model;
                car.registrationNumber = regNo;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.carID == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "Car ID: " << car.carID
                 << ", Owner: " << car.ownerName
                 << ", Model: " << car.model
                 << ", Reg No: " << car.registrationNumber
                 << endl;
        }
    }

    void addInsuranceCompany(int id, string name, string contact) {
        companies.push_back(InsuranceCompany(id, name, contact));
    }

    void deleteInsuranceCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->companyID == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(int id, string name, string contact) {
        for (auto &company : companies) {
            if (company.companyID == id) {
                company.companyName = name;
                company.contactNumber = contact;
                break;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(int id) {
        for (auto &company : companies) {
            if (company.companyID == id) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto &company : companies) {
            cout << "Company ID: " << company.companyID
                 << ", Name: " << company.companyName
                 << ", Contact: " << company.contactNumber
                 << endl;
        }
    }
};

int main() {
    CarInsuranceService service;
    service.addCar(1, "John Doe", "Toyota Camry", "ABC123");
    service.displayCars();

    service.addInsuranceCompany(1, "XYZ Insurance", "123-456-7890");
    service.displayInsuranceCompanies();

    Car* car = service.searchCar(1);
    if (car) {
        cout << "Found Car: " << car->ownerName << endl;
    }

    InsuranceCompany* company = service.searchInsuranceCompany(1);
    if (company) {
        cout << "Found Company: " << company->companyName << endl;
    }

    service.updateCar(1, "John Doe", "Honda Accord", "XYZ789");
    service.displayCars();

    service.updateInsuranceCompany(1, "ABC Insurance", "987-654-3210");
    service.displayInsuranceCompanies();

    service.deleteCar(1);
    service.displayCars();

    service.deleteInsuranceCompany(1);
    service.displayInsuranceCompanies();

    return 0;
}