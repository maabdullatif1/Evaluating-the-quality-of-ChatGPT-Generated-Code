#include <iostream>
#include <vector>
#include <string>

class InsuranceCompany {
public:
    std::string name;
    std::string address;
    std::string phone;
    
    InsuranceCompany(std::string n, std::string a, std::string p)
        : name(n), address(a), phone(p) {}
    
    void display() {
        std::cout << "Company Name: " << name << "\nAddress: " << address << "\nPhone: " << phone << "\n";
    }
};

class Car {
public:
    std::string make;
    std::string model;
    int year;
    std::string insuranceCompany;
    
    Car(std::string m, std::string mo, int y, std::string i)
        : make(m), model(mo), year(y), insuranceCompany(i) {}
    
    void display() {
        std::cout << "Car Make: " << make << "\nModel: " << model << "\nYear: " << year << "\nInsurance Company: " << insuranceCompany << "\n";
    }
};

class CarInsuranceService {
    std::vector<InsuranceCompany> companies;
    std::vector<Car> cars;

public:
    void addCompany(std::string name, std::string address, std::string phone) {
        companies.push_back(InsuranceCompany(name, address, phone));
    }
    
    void addCar(std::string make, std::string model, int year, std::string insuranceCompany) {
        cars.push_back(Car(make, model, year, insuranceCompany));
    }
    
    void deleteCompany(std::string name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }
    
    void deleteCar(std::string make, std::string model) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->make == make && it->model == model) {
                cars.erase(it);
                break;
            }
        }
    }
    
    void updateCompany(std::string oldName, std::string newName, std::string address, std::string phone) {
        for (auto & company : companies) {
            if (company.name == oldName) {
                company.name = newName;
                company.address = address;
                company.phone = phone;
                break;
            }
        }
    }
    
    void updateCar(std::string oldMake, std::string oldModel, std::string make, std::string model, int year, std::string insuranceCompany) {
        for (auto & car : cars) {
            if (car.make == oldMake && car.model == oldModel) {
                car.make = make;
                car.model = model;
                car.year = year;
                car.insuranceCompany = insuranceCompany;
                break;
            }
        }
    }

    void searchCompany(std::string name) {
        for (auto & company : companies) {
            if (company.name == name) {
                company.display();
                return;
            }
        }
        std::cout << "Insurance Company not found.\n";
    }
    
    void searchCar(std::string make, std::string model) {
        for (auto & car : cars) {
            if (car.make == make && car.model == model) {
                car.display();
                return;
            }
        }
        std::cout << "Car not found.\n";
    }
    
    void displayAllCompanies() {
        for (auto & company : companies) {
            company.display();
        }
    }
    
    void displayAllCars() {
        for (auto & car : cars) {
            car.display();
        }
    }
};

int main() {
    CarInsuranceService service;
    
    service.addCompany("ABC Insurance", "123 Main St", "555-1234");
    service.addCar("Toyota", "Corolla", 2020, "ABC Insurance");
    
    service.displayAllCompanies();
    service.displayAllCars();
    
    service.updateCompany("ABC Insurance", "XYZ Insurance", "456 Elm St", "555-5678");
    service.searchCompany("XYZ Insurance");
    
    service.updateCar("Toyota", "Corolla", "Honda", "Civic", 2021, "XYZ Insurance");
    service.searchCar("Honda", "Civic");
    
    service.deleteCompany("XYZ Insurance");
    service.displayAllCompanies();
    
    service.deleteCar("Honda", "Civic");
    service.displayAllCars();

    return 0;
}