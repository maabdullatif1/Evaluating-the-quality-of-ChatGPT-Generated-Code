#include <iostream>
#include <string>
#include <vector>

class Car {
public:
    std::string licensePlate;
    std::string ownerName;
    std::string model;

    Car(const std::string& lp, const std::string& on, const std::string& m)
        : licensePlate(lp), ownerName(on), model(m) {}
};

class InsuranceCompany {
public:
    std::string name;
    std::string contactNumber;

    InsuranceCompany(const std::string& n, const std::string& cn)
        : name(n), contactNumber(cn) {}
};

class CarInsuranceSystem {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(const std::string& licensePlate, const std::string& ownerName, const std::string& model) {
        cars.emplace_back(licensePlate, ownerName, model);
    }

    void deleteCar(const std::string& licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string& licensePlate, const std::string& newOwnerName, const std::string& newModel) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                car.ownerName = newOwnerName;
                car.model = newModel;
                break;
            }
        }
    }

    Car* searchCar(const std::string& licensePlate) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "License Plate: " << car.licensePlate << ", Owner Name: " << car.ownerName 
                      << ", Model: " << car.model << std::endl;
        }
    }

    void addInsuranceCompany(const std::string& name, const std::string& contactNumber) {
        companies.emplace_back(name, contactNumber);
    }

    void deleteInsuranceCompany(const std::string& name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(const std::string& name, const std::string& newContactNumber) {
        for (auto& company : companies) {
            if (company.name == name) {
                company.contactNumber = newContactNumber;
                break;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(const std::string& name) {
        for (auto& company : companies) {
            if (company.name == name) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto& company : companies) {
            std::cout << "Name: " << company.name << ", Contact Number: " << company.contactNumber << std::endl;
        }
    }
};

int main() {
    CarInsuranceSystem system;
    system.addCar("ABC123", "John Doe", "Toyota Corolla");
    system.addCar("XYZ789", "Jane Smith", "Honda Civic");
    system.addInsuranceCompany("InsureIt", "555-1234");
    system.addInsuranceCompany("CoverMe", "555-5678");
    
    system.displayCars();
    system.displayInsuranceCompanies();
    
    system.updateCar("ABC123", "John Updated", "Toyota Updated");
    system.updateInsuranceCompany("InsureIt", "555-0000");
    
    Car* car = system.searchCar("ABC123");
    if (car) std::cout << "Found Car: " << car->licensePlate << ", " << car->ownerName << ", " << car->model << std::endl;
    
    InsuranceCompany* company = system.searchInsuranceCompany("CoverMe");
    if (company) std::cout << "Found Company: " << company->name << ", " << company->contactNumber << std::endl;

    system.deleteCar("XYZ789");
    system.deleteInsuranceCompany("CoverMe");

    system.displayCars();
    system.displayInsuranceCompanies();
    
    return 0;
}