#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    int id;
    string make;
    string model;
    int year;
};

class InsuranceCompany {
public:
    int id;
    string name;
    string contact;
};

class CarInsuranceService {
    vector<Car> cars;
    vector<InsuranceCompany> companies;
public:
    void addCar(int id, string make, string model, int year) {
        cars.push_back({id, make, model, year});
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                return;
            }
        }
    }

    void updateCar(int id, string make, string model, int year) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.year = year;
                return;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (auto &car : cars) {
            cout << "ID: " << car.id << ", Make: " << car.make
                 << ", Model: " << car.model << ", Year: " << car.year << endl;
        }
    }

    void addInsuranceCompany(int id, string name, string contact) {
        companies.push_back({id, name, contact});
    }

    void deleteInsuranceCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                return;
            }
        }
    }

    void updateInsuranceCompany(int id, string name, string contact) {
        for (auto &company : companies) {
            if (company.id == id) {
                company.name = name;
                company.contact = contact;
                return;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(int id) {
        for (auto &company : companies) {
            if (company.id == id) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (auto &company : companies) {
            cout << "ID: " << company.id << ", Name: " << company.name
                 << ", Contact: " << company.contact << endl;
        }
    }
};

int main() {
    CarInsuranceService service;
    service.addCar(1, "Toyota", "Camry", 2020);
    service.addCar(2, "Honda", "Accord", 2019);
    service.displayCars();

    service.addInsuranceCompany(1, "Allianz", "123-456-7890");
    service.addInsuranceCompany(2, "Geico", "098-765-4321");
    service.displayInsuranceCompanies();

    return 0;
}