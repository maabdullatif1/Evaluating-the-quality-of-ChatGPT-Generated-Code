#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string make;
    std::string model;
    int year;
    std::string registrationNumber;
    
    Car(std::string make, std::string model, int year, std::string regNo)
        : make(make), model(model), year(year), registrationNumber(regNo) {}
};

class InsuranceCompany {
public:
    std::string name;
    std::string policyNumber;
    std::string insuredCarRegNum;
    
    InsuranceCompany(std::string name, std::string policyNum, std::string carReg)
        : name(name), policyNumber(policyNum), insuredCarRegNum(carReg) {}
};

class InsuranceServiceSystem {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

    int findCarIndex(const std::string& regNum) {
        for (int i = 0; i < cars.size(); ++i) {
            if (cars[i].registrationNumber == regNum) return i;
        }
        return -1;
    }

    int findCompanyIndex(const std::string& policyNum) {
        for (int i = 0; i < companies.size(); ++i) {
            if (companies[i].policyNumber == policyNum) return i;
        }
        return -1;
    }

public:
    void addCar(std::string make, std::string model, int year, std::string regNo) {
        if (findCarIndex(regNo) == -1) {
            cars.emplace_back(make, model, year, regNo);
        }
    }

    void deleteCar(std::string regNo) {
        int index = findCarIndex(regNo);
        if (index != -1) {
            cars.erase(cars.begin() + index);
        }
    }

    void updateCar(std::string regNo, std::string make, std::string model, int year) {
        int index = findCarIndex(regNo);
        if (index != -1) {
            cars[index] = Car(make, model, year, regNo);
        }
    }

    Car* searchCar(std::string regNo) {
        int index = findCarIndex(regNo);
        if (index != -1) {
            return &cars[index];
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Make: " << car.make << ", Model: " << car.model
                      << ", Year: " << car.year << ", RegNo: " << car.registrationNumber << "\n";
        }
    }

    void addInsuranceCompany(std::string name, std::string policyNum, std::string carReg) {
        if (findCompanyIndex(policyNum) == -1) {
            companies.emplace_back(name, policyNum, carReg);
        }
    }

    void deleteInsuranceCompany(std::string policyNum) {
        int index = findCompanyIndex(policyNum);
        if (index != -1) {
            companies.erase(companies.begin() + index);
        }
    }

    void updateInsuranceCompany(std::string policyNum, std::string name, std::string carReg) {
        int index = findCompanyIndex(policyNum);
        if (index != -1) {
            companies[index] = InsuranceCompany(name, policyNum, carReg);
        }
    }

    InsuranceCompany* searchInsuranceCompany(std::string policyNum) {
        int index = findCompanyIndex(policyNum);
        if (index != -1) {
            return &companies[index];
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto& company : companies) {
            std::cout << "Name: " << company.name << ", Policy Number: " << company.policyNumber
                      << ", Insured Car RegNo: " << company.insuredCarRegNum << "\n";
        }
    }
};

int main() {
    InsuranceServiceSystem system;

    system.addCar("Toyota", "Corolla", 2020, "ABC123");
    system.addCar("Honda", "Civic", 2019, "XYZ789");
    system.updateCar("XYZ789", "Honda", "Accord", 2021);
    system.displayCars();

    system.addInsuranceCompany("InsuranceCorp", "POL123", "ABC123");
    system.addInsuranceCompany("SureSafe", "POL456", "XYZ789");
    system.updateInsuranceCompany("POL456", "SureSafe Ltd", "ABC123");
    system.displayInsuranceCompanies();

    system.deleteCar("XYZ789");
    system.displayCars();

    system.deleteInsuranceCompany("POL456");
    system.displayInsuranceCompanies();

    return 0;
}