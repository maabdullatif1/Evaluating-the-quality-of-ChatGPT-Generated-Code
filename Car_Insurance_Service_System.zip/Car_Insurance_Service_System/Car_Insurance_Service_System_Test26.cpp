#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string ownerName;

    Car(std::string lp, std::string on) : licensePlate(lp), ownerName(on) {}
};

class InsuranceCompany {
public:
    std::string name;
    std::string policyNumber;

    InsuranceCompany(std::string n, std::string pn) : name(n), policyNumber(pn) {}
};

class InsuranceService {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(const std::string& licensePlate, const std::string& ownerName) {
        cars.emplace_back(licensePlate, ownerName);
    }

    void deleteCar(const std::string& licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string& licensePlate, const std::string& newOwnerName) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                car.ownerName = newOwnerName;
                break;
            }
        }
    }

    void searchCar(const std::string& licensePlate) {
        for (const auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                std::cout << "Car found: License Plate: " << car.licensePlate << ", Owner Name: " << car.ownerName << std::endl;
                return;
            }
        }
        std::cout << "Car not found!" << std::endl;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "License Plate: " << car.licensePlate << ", Owner Name: " << car.ownerName << std::endl;
        }
    }

    void addCompany(const std::string& name, const std::string& policyNumber) {
        companies.emplace_back(name, policyNumber);
    }

    void deleteCompany(const std::string& policyNumber) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->policyNumber == policyNumber) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCompany(const std::string& policyNumber, const std::string& newName) {
        for (auto& company : companies) {
            if (company.policyNumber == policyNumber) {
                company.name = newName;
                break;
            }
        }
    }

    void searchCompany(const std::string& policyNumber) {
        for (const auto& company : companies) {
            if (company.policyNumber == policyNumber) {
                std::cout << "Company found: Name: " << company.name << ", Policy Number: " << company.policyNumber << std::endl;
                return;
            }
        }
        std::cout << "Company not found!" << std::endl;
    }

    void displayCompanies() {
        for (const auto& company : companies) {
            std::cout << "Name: " << company.name << ", Policy Number: " << company.policyNumber << std::endl;
        }
    }
};

int main() {
    InsuranceService service;
    service.addCar("ABC123", "John Doe");
    service.addCar("XYZ789", "Jane Smith");
    service.displayCars();
    service.searchCar("ABC123");
    service.updateCar("ABC123", "Michael Johnson");
    service.displayCars();
    service.deleteCar("XYZ789");
    service.displayCars();

    service.addCompany("InsureCo", "POL123");
    service.addCompany("SafeGuard", "POL456");
    service.displayCompanies();
    service.searchCompany("POL123");
    service.updateCompany("POL123", "InsurePlus");
    service.displayCompanies();
    service.deleteCompany("POL456");
    service.displayCompanies();
    
    return 0;
}