#include <iostream>
#include <vector>
#include <string>

class InsuranceCompany {
public:
    std::string name;
    std::string address;

    InsuranceCompany(std::string n, std::string a) : name(n), address(a) {}
};

class Car {
public:
    std::string model;
    std::string licensePlate;
    std::string owner;

    Car(std::string m, std::string lp, std::string o) : model(m), licensePlate(lp), owner(o) {}
};

class InsuranceService {
private:
    std::vector<InsuranceCompany> companies;
    std::vector<Car> cars;

public:
    void addInsuranceCompany(const std::string& name, const std::string& address) {
        companies.push_back(InsuranceCompany(name, address));
    }

    void addCar(const std::string& model, const std::string& licensePlate, const std::string& owner) {
        cars.push_back(Car(model, licensePlate, owner));
    }

    void deleteInsuranceCompany(const std::string& name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }

    void deleteCar(const std::string& licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(const std::string& name, const std::string& newAddress) {
        for (auto& company : companies) {
            if (company.name == name) {
                company.address = newAddress;
                break;
            }
        }
    }

    void updateCar(const std::string& licensePlate, const std::string& newModel, const std::string& newOwner) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                car.model = newModel;
                car.owner = newOwner;
                break;
            }
        }
    }

    void searchInsuranceCompany(const std::string& name) {
        for (const auto& company : companies) {
            if (company.name == name) {
                std::cout << "Company Found: " << company.name << ", Address: " << company.address << std::endl;
                return;
            }
        }
        std::cout << "Company not found." << std::endl;
    }

    void searchCar(const std::string& licensePlate) {
        for (const auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                std::cout << "Car Found: " << car.model << ", License Plate: " << car.licensePlate << ", Owner: " << car.owner << std::endl;
                return;
            }
        }
        std::cout << "Car not found." << std::endl;
    }

    void displayInsuranceCompanies() {
        for (const auto& company : companies) {
            std::cout << "Company: " << company.name << ", Address: " << company.address << std::endl;
        }
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Car: " << car.model << ", License Plate: " << car.licensePlate << ", Owner: " << car.owner << std::endl;
        }
    }
};

int main() {
    InsuranceService service;
    service.addInsuranceCompany("InsureCo", "123 Main St");
    service.addCar("Toyota Camry", "ABC123", "John Doe");

    service.displayInsuranceCompanies();
    service.displayCars();

    service.updateCar("ABC123", "Honda Civic", "Jane Doe");
    service.searchCar("ABC123");

    service.deleteCar("ABC123");
    service.displayCars();

    return 0;
}