#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string plateNumber;
    std::string model;
    std::string owner;

    Car(std::string p, std::string m, std::string o) : plateNumber(p), model(m), owner(o) {}
};

class InsuranceCompany {
public:
    std::string name;
    std::string contact;
    std::string address;

    InsuranceCompany(std::string n, std::string c, std::string a) : name(n), contact(c), address(a) {}
};

class InsuranceServiceSystem {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(const Car& car) {
        cars.push_back(car);
    }

    void addCompany(const InsuranceCompany& company) {
        companies.push_back(company);
    }

    void deleteCar(const std::string& plateNumber) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->plateNumber == plateNumber) {
                cars.erase(it);
                break;
            }
        }
    }

    void deleteCompany(const std::string& name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string& plateNumber, const Car& updatedCar) {
        for (auto& car : cars) {
            if (car.plateNumber == plateNumber) {
                car = updatedCar;
                break;
            }
        }
    }

    void updateCompany(const std::string& name, const InsuranceCompany& updatedCompany) {
        for (auto& company : companies) {
            if (company.name == name) {
                company = updatedCompany;
                break;
            }
        }
    }

    Car searchCar(const std::string& plateNumber) {
        for (const auto& car : cars) {
            if (car.plateNumber == plateNumber) {
                return car;
            }
        }
        return Car("", "", "");
    }

    InsuranceCompany searchCompany(const std::string& name) {
        for (const auto& company : companies) {
            if (company.name == name) {
                return company;
            }
        }
        return InsuranceCompany("", "", "");
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Plate: " << car.plateNumber << ", Model: " << car.model << ", Owner: " << car.owner << std::endl;
        }
    }

    void displayCompanies() {
        for (const auto& company : companies) {
            std::cout << "Name: " << company.name << ", Contact: " << company.contact << ", Address: " << company.address << std::endl;
        }
    }
};

int main() {
    InsuranceServiceSystem system;
    
    system.addCar(Car("XYZ123", "Toyota", "Alice"));
    system.addCompany(InsuranceCompany("InsureCo", "123-456-7890", "123 Elm St"));

    system.displayCars();
    system.displayCompanies();

    system.updateCar("XYZ123", Car("XYZ123", "Honda", "Bob"));
    system.updateCompany("InsureCo", InsuranceCompany("InsureCo", "098-765-4321", "456 Oak St"));

    Car foundCar = system.searchCar("XYZ123");
    std::cout << "Found Car: " << foundCar.model << ", Owner: " << foundCar.owner << std::endl;

    InsuranceCompany foundCompany = system.searchCompany("InsureCo");
    std::cout << "Found Company: " << foundCompany.contact << ", Address: " << foundCompany.address << std::endl;

    system.deleteCar("XYZ123");
    system.deleteCompany("InsureCo");

    system.displayCars();
    system.displayCompanies();

    return 0;
}