#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string plate_number;
    std::string model;
    
    Car(const std::string& plate, const std::string& mod) : plate_number(plate), model(mod) {}
};

class InsuranceCompany {
public:
    std::string name;
    std::string address;

    InsuranceCompany(const std::string& n, const std::string& addr) : name(n), address(addr) {}
};

class CarInsuranceService {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;
    
public:
    void addCar(const std::string& plate, const std::string& model) {
        cars.emplace_back(plate, model);
    }

    void deleteCar(const std::string& plate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->plate_number == plate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string& plate, const std::string& newModel) {
        for (auto& car : cars) {
            if (car.plate_number == plate) {
                car.model = newModel;
                break;
            }
        }
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "Plate: " << car.plate_number << ", Model: " << car.model << std::endl;
        }
    }

    Car* searchCar(const std::string& plate) {
        for (auto& car : cars) {
            if (car.plate_number == plate) {
                return &car;
            }
        }
        return nullptr;
    }

    void addCompany(const std::string& name, const std::string& address) {
        companies.emplace_back(name, address);
    }

    void deleteCompany(const std::string& name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCompany(const std::string& name, const std::string& newAddress) {
        for (auto& company : companies) {
            if (company.name == name) {
                company.address = newAddress;
                break;
            }
        }
    }

    void displayCompanies() {
        for (const auto& company : companies) {
            std::cout << "Name: " << company.name << ", Address: " << company.address << std::endl;
        }
    }

    InsuranceCompany* searchCompany(const std::string& name) {
        for (auto& company : companies) {
            if (company.name == name) {
                return &company;
            }
        }
        return nullptr;
    }
};

int main() {
    CarInsuranceService service;
    service.addCar("ABC123", "Toyota");
    service.addCompany("InsureCo", "123 Elm St");

    std::cout << "Cars in the system:" << std::endl;
    service.displayCars();

    std::cout << "Companies in the system:" << std::endl;
    service.displayCompanies();

    return 0;
}