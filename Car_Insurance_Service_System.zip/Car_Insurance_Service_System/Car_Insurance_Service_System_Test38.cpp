#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Car {
public:
    string registrationNumber;
    string ownerName;
    string model;

    Car(string regNum, string owner, string mdl) : registrationNumber(regNum), ownerName(owner), model(mdl) {}
};

class InsuranceCompany {
public:
    string companyName;
    string insurancePolicy;

    InsuranceCompany(string name, string policy) : companyName(name), insurancePolicy(policy) {}
};

vector<Car> cars;
vector<InsuranceCompany> insuranceCompanies;

void addCar() {
    string regNum, owner, model;
    cout << "Enter Registration Number: ";
    cin >> regNum;
    cout << "Enter Owner Name: ";
    cin >> owner;
    cout << "Enter Model: ";
    cin >> model;
    cars.push_back(Car(regNum, owner, model));
}

void deleteCar() {
    string regNum;
    cout << "Enter Registration Number of car to delete: ";
    cin >> regNum;
    for (auto it = cars.begin(); it != cars.end(); ++it) {
        if (it->registrationNumber == regNum) {
            cars.erase(it);
            cout << "Car deleted." << endl;
            return;
        }
    }
    cout << "Car not found." << endl;
}

void updateCar() {
    string regNum;
    cout << "Enter Registration Number of car to update: ";
    cin >> regNum;
    for (auto& car : cars) {
        if (car.registrationNumber == regNum) {
            cout << "Enter New Owner Name: ";
            cin >> car.ownerName;
            cout << "Enter New Model: ";
            cin >> car.model;
            cout << "Car updated." << endl;
            return;
        }
    }
    cout << "Car not found." << endl;
}

void searchCar() {
    string regNum;
    cout << "Enter Registration Number to search: ";
    cin >> regNum;
    for (const auto& car : cars) {
        if (car.registrationNumber == regNum) {
            cout << "Owner: " << car.ownerName << ", Model: " << car.model << endl;
            return;
        }
    }
    cout << "Car not found." << endl;
}

void displayCars() {
    for (const auto& car : cars) {
        cout << "Reg Num: " << car.registrationNumber << ", Owner: " << car.ownerName << ", Model: " << car.model << endl;
    }
}

void addInsuranceCompany() {
    string name, policy;
    cout << "Enter Company Name: ";
    cin >> name;
    cout << "Enter Insurance Policy: ";
    cin >> policy;
    insuranceCompanies.push_back(InsuranceCompany(name, policy));
}

void deleteInsuranceCompany() {
    string name;
    cout << "Enter Company Name to delete: ";
    cin >> name;
    for (auto it = insuranceCompanies.begin(); it != insuranceCompanies.end(); ++it) {
        if (it->companyName == name) {
            insuranceCompanies.erase(it);
            cout << "Company deleted." << endl;
            return;
        }
    }
    cout << "Company not found." << endl;
}

void updateInsuranceCompany() {
    string name;
    cout << "Enter Company Name to update: ";
    cin >> name;
    for (auto& company : insuranceCompanies) {
        if (company.companyName == name) {
            cout << "Enter New Insurance Policy: ";
            cin >> company.insurancePolicy;
            cout << "Company updated." << endl;
            return;
        }
    }
    cout << "Company not found." << endl;
}

void searchInsuranceCompany() {
    string name;
    cout << "Enter Company Name to search: ";
    cin >> name;
    for (const auto& company : insuranceCompanies) {
        if (company.companyName == name) {
            cout << "Policy: " << company.insurancePolicy << endl;
            return;
        }
    }
    cout << "Company not found." << endl;
}

void displayInsuranceCompanies() {
    for (const auto& company : insuranceCompanies) {
        cout << "Name: " << company.companyName << ", Policy: " << company.insurancePolicy << endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Car\n2. Delete Car\n3. Update Car\n4. Search Car\n5. Display Cars\n6. Add Insurance Company\n7. Delete Insurance Company\n8. Update Insurance Company\n9. Search Insurance Company\n10. Display Insurance Companies\n0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1: addCar(); break;
            case 2: deleteCar(); break;
            case 3: updateCar(); break;
            case 4: searchCar(); break;
            case 5: displayCars(); break;
            case 6: addInsuranceCompany(); break;
            case 7: deleteInsuranceCompany(); break;
            case 8: updateInsuranceCompany(); break;
            case 9: searchInsuranceCompany(); break;
            case 10: displayInsuranceCompanies(); break;
            case 0: return 0;
            default: cout << "Invalid choice." << endl;
        }
    }
}