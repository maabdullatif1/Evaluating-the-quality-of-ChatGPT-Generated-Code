#include <iostream>
#include <vector>
using namespace std;

struct Car {
    int id;
    string make;
    string model;
    int year;
};

struct InsuranceCompany {
    int id;
    string name;
    string address;
};

class CarInsuranceSystem {
    vector<Car> cars;
    vector<InsuranceCompany> companies;
    int carIdCounter = 1;
    int companyIdCounter = 1;

public:
    void addCar(string make, string model, int year) {
        cars.push_back({ carIdCounter++, make, model, year });
    }

    void addInsuranceCompany(string name, string address) {
        companies.push_back({ companyIdCounter++, name, address });
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                return;
            }
        }
    }

    void deleteInsuranceCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                return;
            }
        }
    }

    void updateCar(int id, string make, string model, int year) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.year = year;
                return;
            }
        }
    }

    void updateInsuranceCompany(int id, string name, string address) {
        for (auto& company : companies) {
            if (company.id == id) {
                company.name = name;
                company.address = address;
                return;
            }
        }
    }

    void searchCar(int id) {
        for (const auto& car : cars) {
            if (car.id == id) {
                displayCar(car);
                return;
            }
        }
        cout << "Car not found" << endl;
    }

    void searchInsuranceCompany(int id) {
        for (const auto& company : companies) {
            if (company.id == id) {
                displayInsuranceCompany(company);
                return;
            }
        }
        cout << "Insurance company not found" << endl;
    }

    void displayCars() {
        for (const auto& car : cars) {
            displayCar(car);
        }
    }

    void displayInsuranceCompanies() {
        for (const auto& company : companies) {
            displayInsuranceCompany(company);
        }
    }

private:
    void displayCar(const Car& car) {
        cout << "Car ID: " << car.id << ", Make: " << car.make 
             << ", Model: " << car.model << ", Year: " << car.year << endl;
    }

    void displayInsuranceCompany(const InsuranceCompany& company) {
        cout << "Company ID: " << company.id << ", Name: " << company.name 
             << ", Address: " << company.address << endl;
    }
};

int main() {
    CarInsuranceSystem system;
    system.addCar("Toyota", "Corolla", 2020);
    system.addCar("Ford", "Mustang", 2018);
    system.addInsuranceCompany("Geico", "123 Insurance St");
    system.addInsuranceCompany("State Farm", "456 Coverage Rd");

    cout << "All Cars:" << endl;
    system.displayCars();

    cout << "\nAll Insurance Companies:" << endl;
    system.displayInsuranceCompanies();

    cout << "\nSearching for Car with ID 1:" << endl;
    system.searchCar(1);

    cout << "\nSearching for Insurance Company with ID 2:" << endl;
    system.searchInsuranceCompany(2);

    cout << "\nUpdating Car with ID 1:" << endl;
    system.updateCar(1, "Honda", "Civic", 2021);
    system.searchCar(1);

    return 0;
}