#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    string licensePlate;
    string model;
    string owner;
};

struct InsuranceCompany {
    string name;
    string policyNumber;
    vector<Car> insuredCars;
};

class InsuranceService {
    vector<InsuranceCompany> companies;

public:
    void addCompany(const string& name, const string& policyNumber) {
        companies.push_back({name, policyNumber, {}});
    }

    void deleteCompany(const string& name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCompany(const string& name, const string& newName, const string& newPolicyNumber) {
        for (auto& company : companies) {
            if (company.name == name) {
                company.name = newName;
                company.policyNumber = newPolicyNumber;
                break;
            }
        }
    }

    InsuranceCompany* searchCompany(const string& name) {
        for (auto& company : companies) {
            if (company.name == name) {
                return &company;
            }
        }
        return nullptr;
    }

    void addCarToCompany(const string& companyName, const Car& car) {
        for (auto& company : companies) {
            if (company.name == companyName) {
                company.insuredCars.push_back(car);
                break;
            }
        }
    }

    void displayCompanies() {
        for (const auto& company : companies) {
            cout << "Company: " << company.name << ", Policy Number: " << company.policyNumber << endl;
            for (const auto& car : company.insuredCars) {
                cout << "\tCar License Plate: " << car.licensePlate << ", Model: " << car.model << ", Owner: " << car.owner << endl;
            }
        }
    }
};

int main() {
    InsuranceService service;

    service.addCompany("InsureCo", "P12345");
    service.addCompany("ProtectAll", "P67890");

    Car car1 = {"XYZ123", "Toyota Corolla", "Alice"};
    Car car2 = {"ABC789", "Honda Civic", "Bob"};

    service.addCarToCompany("InsureCo", car1);
    service.addCarToCompany("ProtectAll", car2);

    service.displayCompanies();

    service.updateCompany("InsureCo", "NewInsureCo", "P54321");
    service.displayCompanies();

    service.deleteCompany("ProtectAll");
    service.displayCompanies();

    return 0;
}