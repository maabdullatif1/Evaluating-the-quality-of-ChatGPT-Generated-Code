#include <iostream>
#include <vector>
#include <string>

class InsuranceCompany {
public:
    int id;
    std::string name;
    std::string address;
};

class Car {
public:
    int id;
    std::string model;
    std::string owner;
};

class System {
private:
    std::vector<InsuranceCompany> insuranceCompanies;
    std::vector<Car> cars;
    int companyCounter = 0;
    int carCounter = 0;

public:
    void addInsuranceCompany(std::string name, std::string address) {
        InsuranceCompany ic;
        ic.id = ++companyCounter;
        ic.name = name;
        ic.address = address;
        insuranceCompanies.push_back(ic);
    }

    void deleteInsuranceCompany(int id) {
        for (auto it = insuranceCompanies.begin(); it != insuranceCompanies.end(); ++it) {
            if (it->id == id) {
                insuranceCompanies.erase(it);
                return;
            }
        }
    }

    void updateInsuranceCompany(int id, std::string name, std::string address) {
        for (auto &ic : insuranceCompanies) {
            if (ic.id == id) {
                ic.name = name;
                ic.address = address;
                return;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(int id) {
        for (auto &ic : insuranceCompanies) {
            if (ic.id == id) {
                return &ic;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto &ic : insuranceCompanies) {
            std::cout << "ID: " << ic.id << " Name: " << ic.name << " Address: " << ic.address << std::endl;
        }
    }

    void addCar(std::string model, std::string owner) {
        Car c;
        c.id = ++carCounter;
        c.model = model;
        c.owner = owner;
        cars.push_back(c);
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                return;
            }
        }
    }

    void updateCar(int id, std::string model, std::string owner) {
        for (auto &c : cars) {
            if (c.id == id) {
                c.model = model;
                c.owner = owner;
                return;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &c : cars) {
            if (c.id == id) {
                return &c;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &c : cars) {
            std::cout << "ID: " << c.id << " Model: " << c.model << " Owner: " << c.owner << std::endl;
        }
    }
};

int main() {
    System system;
    system.addInsuranceCompany("InsureCo", "123 Elm St.");
    system.addCar("Toyota", "John Doe");
    system.displayInsuranceCompanies();
    system.displayCars();

    return 0;
}