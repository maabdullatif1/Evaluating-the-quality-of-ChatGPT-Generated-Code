#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    int id;
    string model;
    string owner;
};

struct InsuranceCompany {
    int id;
    string name;
    string contact;
};

class CarInsuranceService {
    vector<Car> cars;
    vector<InsuranceCompany> companies;

    Car* findCarById(int id) {
        for (auto &car : cars) {
            if (car.id == id) return &car;
        }
        return nullptr;
    }

    InsuranceCompany* findCompanyById(int id) {
        for (auto &company : companies) {
            if (company.id == id) return &company;
        }
        return nullptr;
    }

public:
    void addCar(int id, string model, string owner) {
        if (findCarById(id) == nullptr) {
            cars.push_back({id, model, owner});
        }
    }

    void deleteCar(int id) {
        cars.erase(remove_if(cars.begin(), cars.end(), [id](Car &car) { return car.id == id; }), cars.end());
    }

    void updateCar(int id, string model, string owner) {
        Car* car = findCarById(id);
        if (car != nullptr) {
            car->model = model;
            car->owner = owner;
        }
    }

    void searchCar(int id) {
        Car* car = findCarById(id);
        if (car != nullptr) {
            cout << "Car ID: " << car->id << ", Model: " << car->model << ", Owner: " << car->owner << endl;
        } else {
            cout << "Car not found." << endl;
        }
    }

    void displayCars() {
        for (const auto &car : cars) {
            cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << endl;
        }
    }

    void addCompany(int id, string name, string contact) {
        if (findCompanyById(id) == nullptr) {
            companies.push_back({id, name, contact});
        }
    }

    void deleteCompany(int id) {
        companies.erase(remove_if(companies.begin(), companies.end(), [id](InsuranceCompany &company) { return company.id == id; }), companies.end());
    }

    void updateCompany(int id, string name, string contact) {
        InsuranceCompany* company = findCompanyById(id);
        if (company != nullptr) {
            company->name = name;
            company->contact = contact;
        }
    }

    void searchCompany(int id) {
        InsuranceCompany* company = findCompanyById(id);
        if (company != nullptr) {
            cout << "Company ID: " << company->id << ", Name: " << company->name << ", Contact: " << company->contact << endl;
        } else {
            cout << "Company not found." << endl;
        }
    }

    void displayCompanies() {
        for (const auto &company : companies) {
            cout << "Company ID: " << company.id << ", Name: " << company.name << ", Contact: " << company.contact << endl;
        }
    }
};

int main() {
    CarInsuranceService service;
    service.addCar(1, "Toyota", "John");
    service.addCar(2, "Honda", "Jane");
    service.displayCars();
    service.updateCar(2, "Honda Civic", "Jane Doe");
    service.searchCar(2);
    service.deleteCar(1);
    service.displayCars();
    service.addCompany(1, "ABC Insurance", "123-456-7890");
    service.addCompany(2, "XYZ Insurance", "987-654-3210");
    service.displayCompanies();
    service.updateCompany(1, "ABC Insurance LLC", "111-222-3333");
    service.searchCompany(1);
    service.deleteCompany(2);
    service.displayCompanies();
    return 0;
}