#include <iostream>
#include <string>
#include <vector>

class Car {
public:
    int id;
    std::string model;
    int year;

    Car(int i, const std::string& m, int y) : id(i), model(m), year(y) {}
};

class InsuranceCompany {
public:
    int id;
    std::string name;
    std::string contact;

    InsuranceCompany(int i, const std::string& n, const std::string& c) : id(i), name(n), contact(c) {}
};

class InsuranceServiceSystem {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

    int findCarIndex(int id) {
        for (size_t i = 0; i < cars.size(); ++i) {
            if (cars[i].id == id) return i;
        }
        return -1;
    }

    int findCompanyIndex(int id) {
        for (size_t i = 0; i < companies.size(); ++i) {
            if (companies[i].id == id) return i;
        }
        return -1;
    }

public:
    void addCar(int id, const std::string& model, int year) {
        if (findCarIndex(id) == -1)
            cars.emplace_back(id, model, year);
    }

    void deleteCar(int id) {
        int index = findCarIndex(id);
        if (index != -1)
            cars.erase(cars.begin() + index);
    }

    void updateCar(int id, const std::string& model, int year) {
        int index = findCarIndex(id);
        if (index != -1) {
            cars[index].model = model;
            cars[index].year = year;
        }
    }

    Car* searchCar(int id) {
        int index = findCarIndex(id);
        if (index != -1)
            return &cars[index];
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "ID: " << car.id << ", Model: " << car.model << ", Year: " << car.year << "\n";
        }
    }

    void addInsuranceCompany(int id, const std::string& name, const std::string& contact) {
        if (findCompanyIndex(id) == -1)
            companies.emplace_back(id, name, contact);
    }

    void deleteInsuranceCompany(int id) {
        int index = findCompanyIndex(id);
        if (index != -1)
            companies.erase(companies.begin() + index);
    }

    void updateInsuranceCompany(int id, const std::string& name, const std::string& contact) {
        int index = findCompanyIndex(id);
        if (index != -1) {
            companies[index].name = name;
            companies[index].contact = contact;
        }
    }

    InsuranceCompany* searchInsuranceCompany(int id) {
        int index = findCompanyIndex(id);
        if (index != -1)
            return &companies[index];
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto& company : companies) {
            std::cout << "ID: " << company.id << ", Name: " << company.name << ", Contact: " << company.contact << "\n";
        }
    }
};

int main() {
    InsuranceServiceSystem system;
    system.addCar(1, "Toyota Camry", 2020);
    system.addInsuranceCompany(1, "ABC Insurance", "123-456-7890");
    system.displayCars();
    system.displayInsuranceCompanies();
    return 0;
}