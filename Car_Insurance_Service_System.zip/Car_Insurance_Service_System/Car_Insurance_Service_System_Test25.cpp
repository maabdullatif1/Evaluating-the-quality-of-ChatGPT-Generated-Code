#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string ownerName;
    std::string model;

    Car(std::string lp, std::string on, std::string m) : licensePlate(lp), ownerName(on), model(m) {}
};

class InsuranceCompany {
public:
    std::string companyName;
    std::string policyNumber;
    std::string contactNumber;

    InsuranceCompany(std::string cn, std::string pn, std::string cnbr) : companyName(cn), policyNumber(pn), contactNumber(cnbr) {}
};

class InsuranceSystem {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(std::string lp, std::string on, std::string m) {
        cars.push_back(Car(lp, on, m));
    }

    void addCompany(std::string cn, std::string pn, std::string cnbr) {
        companies.push_back(InsuranceCompany(cn, pn, cnbr));
    }

    void deleteCar(std::string lp) {
        cars.erase(std::remove_if(cars.begin(), cars.end(), [&](Car& c) { return c.licensePlate == lp; }), cars.end());
    }

    void deleteCompany(std::string cn) {
        companies.erase(std::remove_if(companies.begin(), companies.end(), [&](InsuranceCompany& comp) { return comp.companyName == cn; }), companies.end());
    }

    Car* searchCar(std::string lp) {
        for (auto& car : cars) {
            if (car.licensePlate == lp) {
                return &car;
            }
        }
        return nullptr;
    }

    InsuranceCompany* searchCompany(std::string cn) {
        for (auto& company : companies) {
            if (company.companyName == cn) {
                return &company;
            }
        }
        return nullptr;
    }

    void updateCar(std::string lp, std::string newOwner, std::string newModel) {
        Car* car = searchCar(lp);
        if (car) {
            car->ownerName = newOwner;
            car->model = newModel;
        }
    }

    void updateCompany(std::string cn, std::string newPolicy, std::string newContact) {
        InsuranceCompany* company = searchCompany(cn);
        if (company) {
            company->policyNumber = newPolicy;
            company->contactNumber = newContact;
        }
    }

    void displayCars() {
        for (auto& car : cars) {
            std::cout << "License Plate: " << car.licensePlate << ", Owner: " << car.ownerName << ", Model: " << car.model << "\n";
        }
    }

    void displayCompanies() {
        for (auto& company : companies) {
            std::cout << "Company Name: " << company.companyName << ", Policy Number: " << company.policyNumber << ", Contact: " << company.contactNumber << "\n";
        }
    }
};

int main() {
    InsuranceSystem system;
    system.addCar("XYZ 123", "Alice", "Toyota");
    system.addCar("ABC 987", "Bob", "Honda");
    system.addCompany("InsureCo", "P123", "555-1111");
    system.addCompany("SafeGuard", "P456", "555-2222");

    system.displayCars();
    system.displayCompanies();

    system.updateCar("XYZ 123", "Alice Johnson", "Toyota Corolla");
    system.updateCompany("InsureCo", "P789", "555-3333");

    system.displayCars();
    system.displayCompanies();

    system.deleteCar("ABC 987");
    system.deleteCompany("SafeGuard");

    system.displayCars();
    system.displayCompanies();

    return 0;
}