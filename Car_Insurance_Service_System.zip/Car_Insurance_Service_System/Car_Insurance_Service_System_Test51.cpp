#include <iostream>
#include <vector>
#include <string>

// Car structure
struct Car {
    int id;
    std::string make;
    std::string model;
    int year;
};

// InsuranceCompany structure
struct InsuranceCompany {
    int id;
    std::string name;
    std::string address;
    std::string phoneNumber;
};

// CarInsuranceSystem class
class CarInsuranceSystem {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(int id, const std::string &make, const std::string &model, int year) {
        cars.push_back({id, make, model, year});
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(int id, const std::string &make, const std::string &model, int year) {
        for (auto &car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.year = year;
                break;
            }
        }
    }

    Car* searchCar(int id) {
        for (auto &car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto &car : cars) {
            std::cout << "ID: " << car.id << ", Make: " << car.make 
                      << ", Model: " << car.model << ", Year: " << car.year << std::endl;
        }
    }

    void addInsuranceCompany(int id, const std::string &name, const std::string &address, const std::string &phoneNumber) {
        companies.push_back({id, name, address, phoneNumber});
    }

    void deleteInsuranceCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(int id, const std::string &name, const std::string &address, const std::string &phoneNumber) {
        for (auto &company : companies) {
            if (company.id == id) {
                company.name = name;
                company.address = address;
                company.phoneNumber = phoneNumber;
                break;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(int id) {
        for (auto &company : companies) {
            if (company.id == id) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto &company : companies) {
            std::cout << "ID: " << company.id << ", Name: " << company.name 
                      << ", Address: " << company.address 
                      << ", Phone Number: " << company.phoneNumber << std::endl;
        }
    }
};

int main() {
    CarInsuranceSystem system;
    system.addCar(1, "Toyota", "Corolla", 2020);
    system.addCar(2, "Honda", "Civic", 2019);
    system.updateCar(2, "Honda", "Accord", 2021);
    system.displayCars();
    system.addInsuranceCompany(1, "ABC Insurance", "123 Elm St", "123-456-7890");
    system.addInsuranceCompany(2, "XYZ Insure", "456 Oak Ave", "987-654-3210");
    system.displayInsuranceCompanies();
    return 0;
}