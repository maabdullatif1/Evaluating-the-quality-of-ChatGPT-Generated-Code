#include <iostream>
#include <string>
#include <vector>

class Car {
public:
    int id;
    std::string model;
    std::string owner;

    Car(int i, std::string m, std::string o) : id(i), model(m), owner(o) {}
};

class InsuranceCompany {
public:
    int id;
    std::string name;
    std::string address;

    InsuranceCompany(int i, std::string n, std::string a) : id(i), name(n), address(a) {}
};

class CarInsuranceService {
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

    template<typename T>
    void displayList(const std::vector<T>& list) {
        for (const auto& item : list) {
            std::cout << "ID: " << item.id << " Info: " << item.name << std::endl;
        }
    }

    template<typename T>
    typename std::vector<T>::iterator findItem(std::vector<T>& list, int id) {
        return std::find_if(list.begin(), list.end(), [id](const T& item) { return item.id == id; });
    }

public:
    void addCar(int id, std::string model, std::string owner) {
        cars.emplace_back(id, model, owner);
    }

    void deleteCar(int id) {
        auto it = findItem(cars, id);
        if (it != cars.end()) cars.erase(it);
    }

    void updateCar(int id, std::string model, std::string owner) {
        auto it = findItem(cars, id);
        if (it != cars.end()) {
            it->model = model;
            it->owner = owner;
        }
    }

    void searchCar(int id) {
        auto it = findItem(cars, id);
        if (it != cars.end()) {
            std::cout << "Car found - ID: " << it->id << ", Model: " << it->model << ", Owner: " << it->owner << std::endl;
        } else {
            std::cout << "Car not found" << std::endl;
        }
    }

    void displayCars() {
        displayList(cars);
    }

    void addInsuranceCompany(int id, std::string name, std::string address) {
        companies.emplace_back(id, name, address);
    }

    void deleteInsuranceCompany(int id) {
        auto it = findItem(companies, id);
        if (it != companies.end()) companies.erase(it);
    }

    void updateInsuranceCompany(int id, std::string name, std::string address) {
        auto it = findItem(companies, id);
        if (it != companies.end()) {
            it->name = name;
            it->address = address;
        }
    }

    void searchInsuranceCompany(int id) {
        auto it = findItem(companies, id);
        if (it != companies.end()) {
            std::cout << "Company found - ID: " << it->id << ", Name: " << it->name << ", Address: " << it->address << std::endl;
        } else {
            std::cout << "Company not found" << std::endl;
        }
    }

    void displayInsuranceCompanies() {
        displayList(companies);
    }
};

int main() {
    CarInsuranceService service;
    service.addCar(1, "Toyota Corolla", "John Doe");
    service.addCar(2, "Honda Civic", "Jane Doe");
    service.addInsuranceCompany(1, "ABC Insurance", "123 Street");
    service.addInsuranceCompany(2, "XYZ Insurance", "456 Avenue");
    service.displayCars();
    service.displayInsuranceCompanies();
    service.searchCar(1);
    service.searchInsuranceCompany(1);
    service.updateCar(1, "Toyota Camry", "John Smith");
    service.updateInsuranceCompany(1, "ABC Insurance Ltd.", "789 Boulevard");
    service.displayCars();
    service.displayInsuranceCompanies();
    service.deleteCar(2);
    service.deleteInsuranceCompany(2);
    service.displayCars();
    service.displayInsuranceCompanies();
    return 0;
}