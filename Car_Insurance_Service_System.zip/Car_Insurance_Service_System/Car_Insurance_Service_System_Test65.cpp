#include <iostream>
#include <string>
#include <vector>

class InsuranceCompany {
public:
    int id;
    std::string name;
    std::string address;
    std::string contact;

    InsuranceCompany(int id, const std::string& name, const std::string& address, const std::string& contact)
        : id(id), name(name), address(address), contact(contact) {}
};

class Car {
public:
    int id;
    std::string make;
    std::string model;
    int year;
    int companyId;

    Car(int id, const std::string& make, const std::string& model, int year, int companyId)
        : id(id), make(make), model(model), year(year), companyId(companyId) {}
};

class InsuranceService {
private:
    std::vector<InsuranceCompany> companies;
    std::vector<Car> cars;

public:
    void addCompany(int id, const std::string& name, const std::string& address, const std::string& contact) {
        companies.push_back(InsuranceCompany(id, name, address, contact));
    }

    void addCar(int id, const std::string& make, const std::string& model, int year, int companyId) {
        cars.push_back(Car(id, make, model, year, companyId));
    }

    void deleteCompany(int id) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->id == id) {
                companies.erase(it);
                break;
            }
        }
    }

    void deleteCar(int id) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->id == id) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCompany(int id, const std::string& name, const std::string& address, const std::string& contact) {
        for (auto& company : companies) {
            if (company.id == id) {
                company.name = name;
                company.address = address;
                company.contact = contact;
                break;
            }
        }
    }

    void updateCar(int id, const std::string& make, const std::string& model, int year, int companyId) {
        for (auto& car : cars) {
            if (car.id == id) {
                car.make = make;
                car.model = model;
                car.year = year;
                car.companyId = companyId;
                break;
            }
        }
    }

    InsuranceCompany* searchCompany(int id) {
        for (auto& company : companies) {
            if (company.id == id) {
                return &company;
            }
        }
        return nullptr;
    }

    Car* searchCar(int id) {
        for (auto& car : cars) {
            if (car.id == id) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCompanies() {
        for (const auto& company : companies) {
            std::cout << "ID: " << company.id << ", Name: " << company.name << ", Address: " << company.address << ", Contact: " << company.contact << std::endl;
        }
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "ID: " << car.id << ", Make: " << car.make << ", Model: " << car.model << ", Year: " << car.year << ", Company ID: " << car.companyId << std::endl;
        }
    }
};

int main() {
    InsuranceService service;

    service.addCompany(1, "Company A", "123 Street", "123-456-7890");
    service.addCar(1, "Toyota", "Camry", 2020, 1);

    service.displayCompanies();
    service.displayCars();

    return 0;
}