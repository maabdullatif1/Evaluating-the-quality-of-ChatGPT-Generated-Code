#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    int id;
    string make;
    string model;
    int year;
};

struct InsuranceCompany {
    int id;
    string name;
    string policyNumber;
};

vector<Car> carList;
vector<InsuranceCompany> insuranceCompanyList;

void addCar() {
    Car car;
    cout << "Enter Car ID: ";
    cin >> car.id;
    cout << "Enter Car Make: ";
    cin >> car.make;
    cout << "Enter Car Model: ";
    cin >> car.model;
    cout << "Enter Car Year: ";
    cin >> car.year;
    carList.push_back(car);
}

void deleteCar() {
    int id;
    cout << "Enter Car ID to delete: ";
    cin >> id;
    for (auto it = carList.begin(); it != carList.end(); ++it) {
        if (it->id == id) {
            carList.erase(it);
            return;
        }
    }
    cout << "Car not found." << endl;
}

void updateCar() {
    int id;
    cout << "Enter Car ID to update: ";
    cin >> id;
    for (auto &car : carList) {
        if (car.id == id) {
            cout << "Enter new Car Make: ";
            cin >> car.make;
            cout << "Enter new Car Model: ";
            cin >> car.model;
            cout << "Enter new Car Year: ";
            cin >> car.year;
            return;
        }
    }
    cout << "Car not found." << endl;
}

void searchCar() {
    int id;
    cout << "Enter Car ID to search: ";
    cin >> id;
    for (const auto &car : carList) {
        if (car.id == id) {
            cout << "Car ID: " << car.id << ", Make: " << car.make
                 << ", Model: " << car.model << ", Year: " << car.year << endl;
            return;
        }
    }
    cout << "Car not found." << endl;
}

void displayCars() {
    for (const auto &car : carList) {
        cout << "Car ID: " << car.id << ", Make: " << car.make
             << ", Model: " << car.model << ", Year: " << car.year << endl;
    }
}

void addInsuranceCompany() {
    InsuranceCompany company;
    cout << "Enter Insurance Company ID: ";
    cin >> company.id;
    cout << "Enter Insurance Company Name: ";
    cin >> company.name;
    cout << "Enter Policy Number: ";
    cin >> company.policyNumber;
    insuranceCompanyList.push_back(company);
}

void deleteInsuranceCompany() {
    int id;
    cout << "Enter Insurance Company ID to delete: ";
    cin >> id;
    for (auto it = insuranceCompanyList.begin(); it != insuranceCompanyList.end(); ++it) {
        if (it->id == id) {
            insuranceCompanyList.erase(it);
            return;
        }
    }
    cout << "Insurance Company not found." << endl;
}

void updateInsuranceCompany() {
    int id;
    cout << "Enter Insurance Company ID to update: ";
    cin >> id;
    for (auto &company : insuranceCompanyList) {
        if (company.id == id) {
            cout << "Enter new Insurance Company Name: ";
            cin >> company.name;
            cout << "Enter new Policy Number: ";
            cin >> company.policyNumber;
            return;
        }
    }
    cout << "Insurance Company not found." << endl;
}

void searchInsuranceCompany() {
    int id;
    cout << "Enter Insurance Company ID to search: ";
    cin >> id;
    for (const auto &company : insuranceCompanyList) {
        if (company.id == id) {
            cout << "Company ID: " << company.id << ", Name: " << company.name
                 << ", Policy Number: " << company.policyNumber << endl;
            return;
        }
    }
    cout << "Insurance Company not found." << endl;
}

void displayInsuranceCompanies() {
    for (const auto &company : insuranceCompanyList) {
        cout << "Company ID: " << company.id << ", Name: " << company.name
             << ", Policy Number: " << company.policyNumber << endl;
    }
}

int main() {
    int choice = 0;
    while (choice != 9) {
        cout << "Menu: 1. Add Car 2. Delete Car 3. Update Car 4. Search Car 5. Display Cars\n";
        cout << "6. Add Insurance Company 7. Delete Insurance Company 8. Update Insurance Company\n";
        cout << "9. Search Insurance Company 10. Display Insurance Companies 11. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addCar(); break;
            case 2: deleteCar(); break;
            case 3: updateCar(); break;
            case 4: searchCar(); break;
            case 5: displayCars(); break;
            case 6: addInsuranceCompany(); break;
            case 7: deleteInsuranceCompany(); break;
            case 8: updateInsuranceCompany(); break;
            case 9: searchInsuranceCompany(); break;
            case 10: displayInsuranceCompanies(); break;
            case 11: choice = 9; break;
            default: cout << "Invalid choice." << endl; break;
        }
    }
    return 0;
}