#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    std::string licensePlate;
    std::string owner;
    std::string model;

    Car(std::string lp, std::string o, std::string m)
        : licensePlate(lp), owner(o), model(m) {}
};

class InsuranceCompany {
public:
    std::string name;
    std::string policyNumber;

    InsuranceCompany(std::string n, std::string p)
        : name(n), policyNumber(p) {}
};

class CarInsuranceSystem {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(std::string lp, std::string o, std::string m) {
        cars.push_back(Car(lp, o, m));
    }

    void deleteCar(std::string lp) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == lp) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(std::string lp, std::string newOwner, std::string newModel) {
        for (auto& car : cars) {
            if (car.licensePlate == lp) {
                car.owner = newOwner;
                car.model = newModel;
                break;
            }
        }
    }

    Car* searchCar(std::string lp) {
        for (auto& car : cars) {
            if (car.licensePlate == lp) {
                return &car;
            }
        }
        return nullptr;
    }

    void addCompany(std::string n, std::string p) {
        companies.push_back(InsuranceCompany(n, p));
    }

    void deleteCompany(std::string n) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == n) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCompany(std::string n, std::string newPolicyNumber) {
        for (auto& company : companies) {
            if (company.name == n) {
                company.policyNumber = newPolicyNumber;
                break;
            }
        }
    }

    InsuranceCompany* searchCompany(std::string n) {
        for (auto& company : companies) {
            if (company.name == n) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            std::cout << "License Plate: " << car.licensePlate
                      << ", Owner: " << car.owner
                      << ", Model: " << car.model << std::endl;
        }
    }

    void displayCompanies() {
        for (const auto& company : companies) {
            std::cout << "Company Name: " << company.name
                      << ", Policy Number: " << company.policyNumber << std::endl;
        }
    }
};

int main() {
    CarInsuranceSystem system;

    system.addCar("ABC123", "John Doe", "Toyota Camry");
    system.addCar("XYZ789", "Jane Smith", "Honda Accord");
    system.addCompany("Acme Insurance", "POL12345");

    system.displayCars();
    system.displayCompanies();

    Car* car = system.searchCar("ABC123");
    if (car != nullptr) {
        std::cout << "Found car with license plate: " << car->licensePlate << std::endl;
    }

    InsuranceCompany* company = system.searchCompany("Acme Insurance");
    if (company != nullptr) {
        std::cout << "Found company: " << company->name << std::endl;
    }

    system.updateCar("ABC123", "John A. Doe", "Toyota Corolla");
    system.updateCompany("Acme Insurance", "POL54321");

    system.displayCars();
    system.displayCompanies();

    system.deleteCar("XYZ789");
    system.deleteCompany("Acme Insurance");

    system.displayCars();
    system.displayCompanies();

    return 0;
}