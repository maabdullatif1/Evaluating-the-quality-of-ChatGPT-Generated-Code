#include <iostream>
#include <vector>
#include <string>

class Car {
public:
    int id;
    std::string model;
    std::string owner;
    Car(int id, std::string model, std::string owner) : id(id), model(model), owner(owner) {}
};

class InsuranceCompany {
public:
    int id;
    std::string name;
    std::string address;
    InsuranceCompany(int id, std::string name, std::string address) : id(id), name(name), address(address) {}
};

std::vector<Car> cars;
std::vector<InsuranceCompany> companies;

void addCar(int id, std::string model, std::string owner) {
    cars.push_back(Car(id, model, owner));
}

void deleteCar(int id) {
    for (auto it = cars.begin(); it != cars.end(); ++it) {
        if (it->id == id) {
            cars.erase(it);
            break;
        }
    }
}

void updateCar(int id, std::string model, std::string owner) {
    for (auto &car : cars) {
        if (car.id == id) {
            car.model = model;
            car.owner = owner;
            break;
        }
    }
}

Car* searchCar(int id) {
    for (auto &car : cars) {
        if (car.id == id) {
            return &car;
        }
    }
    return nullptr;
}

void displayCars() {
    for (const auto &car : cars) {
        std::cout << "Car ID: " << car.id << ", Model: " << car.model << ", Owner: " << car.owner << "\n";
    }
}

void addInsuranceCompany(int id, std::string name, std::string address) {
    companies.push_back(InsuranceCompany(id, name, address));
}

void deleteInsuranceCompany(int id) {
    for (auto it = companies.begin(); it != companies.end(); ++it) {
        if (it->id == id) {
            companies.erase(it);
            break;
        }
    }
}

void updateInsuranceCompany(int id, std::string name, std::string address) {
    for (auto &company : companies) {
        if (company.id == id) {
            company.name = name;
            company.address = address;
            break;
        }
    }
}

InsuranceCompany* searchInsuranceCompany(int id) {
    for (auto &company : companies) {
        if (company.id == id) {
            return &company;
        }
    }
    return nullptr;
}

void displayInsuranceCompanies() {
    for (const auto &company : companies) {
        std::cout << "Company ID: " << company.id << ", Name: " << company.name << ", Address: " << company.address << "\n";
    }
}

int main() {
    addCar(1, "Toyota Camry", "Alice");
    addCar(2, "Honda Civic", "Bob");
    displayCars();
    
    addInsuranceCompany(1, "ABC Insurance", "123 Main St");
    addInsuranceCompany(2, "XYZ Insurance", "456 Elm St");
    displayInsuranceCompanies();
    
    updateCar(1, "Toyota Corolla", "Alice Johnson");
    updateInsuranceCompany(1, "ABC Insurance", "789 Park Ave");
    
    displayCars();
    displayInsuranceCompanies();
    
    deleteCar(2);
    deleteInsuranceCompany(2);
    
    displayCars();
    displayInsuranceCompanies();
    
    return 0;
}