#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Car {
    string licensePlate;
    string owner;
    string model;
};

struct InsuranceCompany {
    string name;
    string address;
    vector<Car> insuredCars;
};

class InsuranceService {
private:
    vector<InsuranceCompany> companies;

public:
    void addCompany(const string& name, const string& address) {
        companies.push_back({name, address});
    }

    void deleteCompany(const string& name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateCompany(const string& name, const string& newAddress) {
        for (auto& company : companies) {
            if (company.name == name) {
                company.address = newAddress;
                break;
            }
        }
    }

    InsuranceCompany* searchCompany(const string& name) {
        for (auto& company : companies) {
            if (company.name == name) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayCompanies() {
        for (const auto& company : companies) {
            cout << "Name: " << company.name << ", Address: " << company.address << endl;
            for (const auto& car : company.insuredCars) {
                cout << "  Car License: " << car.licensePlate << ", Owner: " << car.owner << ", Model: " << car.model << endl;
            }
        }
    }

    void addCarToCompany(const string& companyName, const Car& car) {
        for (auto& company : companies) {
            if (company.name == companyName) {
                company.insuredCars.push_back(car);
                break;
            }
        }
    }

    void deleteCarFromCompany(const string& companyName, const string& licensePlate) {
        for (auto& company : companies) {
            if (company.name == companyName) {
                for (auto it = company.insuredCars.begin(); it != company.insuredCars.end(); ++it) {
                    if (it->licensePlate == licensePlate) {
                        company.insuredCars.erase(it);
                        break;
                    }
                }
                break;
            }
        }
    }

    void updateCarInCompany(const string& companyName, const string& licensePlate, const Car& newCarInfo) {
        for (auto& company : companies) {
            if (company.name == companyName) {
                for (auto& car : company.insuredCars) {
                    if (car.licensePlate == licensePlate) {
                        car = newCarInfo;
                        break;
                    }
                }
                break;
            }
        }
    }

    Car* searchCarInCompany(const string& companyName, const string& licensePlate) {
        for (auto& company : companies) {
            if (company.name == companyName) {
                for (auto& car : company.insuredCars) {
                    if (car.licensePlate == licensePlate) {
                        return &car;
                    }
                }
            }
        }
        return nullptr;
    }
};

int main() {
    InsuranceService service;
    
    service.addCompany("ABC Insurance", "123 Street");
    service.addCarToCompany("ABC Insurance", {"XYZ123", "John Doe", "Toyota Corolla"});
    service.displayCompanies();
    
    service.updateCarInCompany("ABC Insurance", "XYZ123", {"XYZ124", "John Doe", "Toyota Camry"});
    service.displayCompanies();
    
    service.deleteCarFromCompany("ABC Insurance", "XYZ124");
    service.displayCompanies();
    
    service.deleteCompany("ABC Insurance");
    service.displayCompanies();

    return 0;
}