#include <iostream>
#include <string>
#include <vector>

struct Car {
    std::string licensePlate;
    std::string model;
    std::string ownerName;
};

struct InsuranceCompany {
    std::string name;
    std::string address;
    std::string contactNumber;
};

class CarInsuranceServiceSystem {
private:
    std::vector<Car> cars;
    std::vector<InsuranceCompany> companies;

public:
    void addCar(const std::string& licensePlate, const std::string& model, const std::string& ownerName) {
        cars.push_back({licensePlate, model, ownerName});
    }

    void deleteCar(const std::string& licensePlate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->licensePlate == licensePlate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const std::string& licensePlate, const std::string& model, const std::string& ownerName) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                car.model = model;
                car.ownerName = ownerName;
                break;
            }
        }
    }

    Car* searchCar(const std::string& licensePlate) {
        for (auto& car : cars) {
            if (car.licensePlate == licensePlate) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() const {
        for (const auto& car : cars) {
            std::cout << "License Plate: " << car.licensePlate << ", Model: " << car.model << ", Owner: " << car.ownerName << std::endl;
        }
    }

    void addInsuranceCompany(const std::string& name, const std::string& address, const std::string& contactNumber) {
        companies.push_back({name, address, contactNumber});
    }

    void deleteInsuranceCompany(const std::string& name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(const std::string& name, const std::string& address, const std::string& contactNumber) {
        for (auto& company : companies) {
            if (company.name == name) {
                company.address = address;
                company.contactNumber = contactNumber;
                break;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(const std::string& name) {
        for (auto& company : companies) {
            if (company.name == name) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() const {
        for (const auto& company : companies) {
            std::cout << "Name: " << company.name << ", Address: " << company.address << ", Contact: " << company.contactNumber << std::endl;
        }
    }
};

int main() {
    CarInsuranceServiceSystem system;
    system.addCar("ABC123", "Toyota Camry", "John Doe");
    system.addCar("XYZ789", "Honda Civic", "Jane Smith");

    system.addInsuranceCompany("SafeAuto", "123 Safe St", "555-1234");
    system.addInsuranceCompany("AutoInsure", "124 Safe St", "555-5678");

    std::cout << "Cars:" << std::endl;
    system.displayCars();

    std::cout << std::endl << "Insurance Companies:" << std::endl;
    system.displayInsuranceCompanies();

    return 0;
}