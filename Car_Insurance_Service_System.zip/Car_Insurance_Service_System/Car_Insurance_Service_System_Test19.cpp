#include <iostream>
#include <vector>
#include <string>

struct CarInsurance {
    std::string carModel;
    std::string carNumber;
    std::string insuranceCompanyName;
    std::string insurancePolicyNumber;
    float insuranceAmount;
};

class CarInsuranceService {
private:
    std::vector<CarInsurance> records;

public:
    void addRecord(const CarInsurance& record) {
        records.push_back(record);
    }

    bool deleteRecord(const std::string& carNumber) {
        for (size_t i = 0; i < records.size(); ++i) {
            if (records[i].carNumber == carNumber) {
                records.erase(records.begin() + i);
                return true;
            }
        }
        return false;
    }

    bool updateRecord(const std::string& carNumber, const CarInsurance& newRecord) {
        for (size_t i = 0; i < records.size(); ++i) {
            if (records[i].carNumber == carNumber) {
                records[i] = newRecord;
                return true;
            }
        }
        return false;
    }

    CarInsurance* searchRecord(const std::string& carNumber) {
        for (size_t i = 0; i < records.size(); ++i) {
            if (records[i].carNumber == carNumber) {
                return &records[i];
            }
        }
        return nullptr;
    }

    void displayRecords() {
        for (const auto& record : records) {
            std::cout << "Car Model: " << record.carModel << std::endl;
            std::cout << "Car Number: " << record.carNumber << std::endl;
            std::cout << "Insurance Company: " << record.insuranceCompanyName << std::endl;
            std::cout << "Policy Number: " << record.insurancePolicyNumber << std::endl;
            std::cout << "Insurance Amount: " << record.insuranceAmount << std::endl << std::endl;
        }
    }
};

int main() {
    CarInsuranceService service;

    service.addRecord({"Tesla Model 3", "ABC123", "Tesla Insurance", "POL123456", 1500.0f});
    service.addRecord({"Ford Mustang", "XYZ789", "Ford Protect", "POL654321", 2000.0f});

    CarInsurance* searchResult = service.searchRecord("ABC123");
    if (searchResult) {
        std::cout << "Record Found: " << searchResult->carModel << std::endl;
    } else {
        std::cout << "Record Not Found" << std::endl;
    }

    service.updateRecord("ABC123", {"Tesla Model S", "ABC123", "Tesla Insurance", "POL123456", 1600.0f});
    
    service.deleteRecord("XYZ789");

    service.displayRecords();

    return 0;
}