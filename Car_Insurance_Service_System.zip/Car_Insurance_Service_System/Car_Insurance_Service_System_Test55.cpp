#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Car {
public:
    string license_plate;
    string owner_name;
    string model;
};

class InsuranceCompany {
public:
    string name;
    string contact_number;
};

class InsuranceService {
    vector<Car> cars;
    vector<InsuranceCompany> companies;

public:
    void addCar(const string& license_plate, const string& owner_name, const string& model) {
        cars.push_back({license_plate, owner_name, model});
    }

    void deleteCar(const string& license_plate) {
        for (auto it = cars.begin(); it != cars.end(); ++it) {
            if (it->license_plate == license_plate) {
                cars.erase(it);
                break;
            }
        }
    }

    void updateCar(const string& license_plate, const string& new_owner, const string& new_model) {
        for (auto& car : cars) {
            if (car.license_plate == license_plate) {
                car.owner_name = new_owner;
                car.model = new_model;
                break;
            }
        }
    }

    Car* searchCar(const string& license_plate) {
        for (auto& car : cars) {
            if (car.license_plate == license_plate) {
                return &car;
            }
        }
        return nullptr;
    }

    void displayCars() {
        for (const auto& car : cars) {
            cout << "License Plate: " << car.license_plate 
                 << ", Owner: " << car.owner_name 
                 << ", Model: " << car.model << endl;
        }
    }

    void addInsuranceCompany(const string& name, const string& contact_number) {
        companies.push_back({name, contact_number});
    }

    void deleteInsuranceCompany(const string& name) {
        for (auto it = companies.begin(); it != companies.end(); ++it) {
            if (it->name == name) {
                companies.erase(it);
                break;
            }
        }
    }

    void updateInsuranceCompany(const string& name, const string& new_contact_number) {
        for (auto& company : companies) {
            if (company.name == name) {
                company.contact_number = new_contact_number;
                break;
            }
        }
    }

    InsuranceCompany* searchInsuranceCompany(const string& name) {
        for (auto& company : companies) {
            if (company.name == name) {
                return &company;
            }
        }
        return nullptr;
    }

    void displayInsuranceCompanies() {
        for (const auto& company : companies) {
            cout << "Name: " << company.name 
                 << ", Contact: " << company.contact_number << endl;
        }
    }
};

int main() {
    InsuranceService service;

    service.addCar("ABC123", "John Doe", "Toyota Camry");
    service.addCar("XYZ789", "Jane Smith", "Honda Civic");
    service.displayCars();

    service.addInsuranceCompany("InsureCo", "123-456-7890");
    service.addInsuranceCompany("CoverPlus", "098-765-4321");
    service.displayInsuranceCompanies();

    return 0;
}