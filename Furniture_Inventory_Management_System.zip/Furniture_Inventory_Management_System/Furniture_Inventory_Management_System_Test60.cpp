#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Supplier {
    int id;
    string name;
    string contact;
};

struct Furniture {
    int id;
    string type;
    string material;
    int supplierId;
};

class Inventory {
private:
    vector<Supplier> suppliers;
    vector<Furniture> furniture;

    Supplier* findSupplierById(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    Furniture* findFurnitureById(int id) {
        for (auto& item : furniture) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

public:
    void addSupplier(int id, const string& name, const string& contact) {
        if (findSupplierById(id) == nullptr) {
            suppliers.push_back({id, name, contact});
        }
    }

    void addFurniture(int id, const string& type, const string& material, int supplierId) {
        if (findSupplierById(supplierId) != nullptr && findFurnitureById(id) == nullptr) {
            furniture.push_back({id, type, material, supplierId});
        }
    }

    void deleteSupplier(int id) {
        suppliers.erase(remove_if(suppliers.begin(), suppliers.end(), [id](Supplier& s) {
            return s.id == id;
        }), suppliers.end());
    }

    void deleteFurniture(int id) {
        furniture.erase(remove_if(furniture.begin(), furniture.end(), [id](Furniture& f) {
            return f.id == id;
        }), furniture.end());
    }

    void updateSupplier(int id, const string& name, const string& contact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void updateFurniture(int id, const string& type, const string& material, int supplierId) {
        Furniture* item = findFurnitureById(id);
        if (item && findSupplierById(supplierId) != nullptr) {
            item->type = type;
            item->material = material;
            item->supplierId = supplierId;
        }
    }

    Supplier* searchSupplier(int id) {
        return findSupplierById(id);
    }

    Furniture* searchFurniture(int id) {
        return findFurnitureById(id);
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }

    void displayFurniture() {
        for (const auto& item : furniture) {
            cout << "Furniture ID: " << item.id << ", Type: " << item.type << ", Material: " << item.material << ", Supplier ID: " << item.supplierId << endl;
        }
    }
};

int main() {
    Inventory inventory;

    inventory.addSupplier(1, "ABC Corp", "123-456-7890");
    inventory.addSupplier(2, "XYZ Inc", "987-654-3210");

    inventory.addFurniture(1, "Chair", "Wood", 1);
    inventory.addFurniture(2, "Table", "Metal", 2);

    inventory.displaySuppliers();
    inventory.displayFurniture();

    inventory.updateSupplier(1, "ABC Corporation", "123-456-7891");
    inventory.updateFurniture(1, "Chair", "Metal", 2);

    inventory.displaySuppliers();
    inventory.displayFurniture();

    inventory.deleteSupplier(2);
    inventory.deleteFurniture(2);

    inventory.displaySuppliers();
    inventory.displayFurniture();

    return 0;
}