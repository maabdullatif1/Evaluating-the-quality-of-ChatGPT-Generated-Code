#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    double price;
    int quantity;

    Furniture(int i, std::string n, std::string t, double p, int q)
        : id(i), name(n), type(t), price(p), quantity(q) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int i, std::string n, std::string c) 
        : id(i), name(n), contact(c) {}
};

class InventoryManagement {
private:
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

    Furniture* findFurniture(int id) {
        for (auto& f : furnitureList) {
            if (f.id == id) return &f;
        }
        return nullptr;
    }

    Supplier* findSupplier(int id) {
        for (auto& s : supplierList) {
            if (s.id == id) return &s;
        }
        return nullptr;
    }

public:
    void addFurniture(int id, std::string name, std::string type, double price, int quantity) {
        furnitureList.push_back(Furniture(id, name, type, price, quantity));
    }

    void deleteFurniture(int id) {
        furnitureList.erase(std::remove_if(furnitureList.begin(),
                             furnitureList.end(),
                             [=](Furniture& f) { return f.id == id; }),
                            furnitureList.end());
    }

    void updateFurniture(int id, std::string name, std::string type, double price, int quantity) {
        Furniture* f = findFurniture(id);
        if (f) {
            f->name = name;
            f->type = type;
            f->price = price;
            f->quantity = quantity;
        }
    }

    void searchFurniture(int id) {
        Furniture* f = findFurniture(id);
        if (f) {
            std::cout << "ID: " << f->id << ", Name: " << f->name 
                      << ", Type: " << f->type << ", Price: " << f->price 
                      << ", Quantity: " << f->quantity << std::endl;
        } else {
            std::cout << "Furniture not found." << std::endl;
        }
    }

    void displayFurniture() {
        for (const auto& f : furnitureList) {
            std::cout << "ID: " << f.id << ", Name: " << f.name 
                      << ", Type: " << f.type << ", Price: " << f.price 
                      << ", Quantity: " << f.quantity << std::endl;
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        supplierList.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        supplierList.erase(std::remove_if(supplierList.begin(),
                             supplierList.end(),
                             [=](Supplier& s) { return s.id == id; }),
                            supplierList.end());
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        Supplier* s = findSupplier(id);
        if (s) {
            s->name = name;
            s->contact = contact;
        }
    }

    void searchSupplier(int id) {
        Supplier* s = findSupplier(id);
        if (s) {
            std::cout << "ID: " << s->id << ", Name: " << s->name 
                      << ", Contact: " << s->contact << std::endl;
        } else {
            std::cout << "Supplier not found." << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto& s : supplierList) {
            std::cout << "ID: " << s.id << ", Name: " << s.name 
                      << ", Contact: " << s.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagement inventory;

    inventory.addFurniture(1, "Chair", "Seating", 49.99, 20);
    inventory.addFurniture(2, "Table", "Dining", 149.99, 10);
    inventory.addSupplier(1, "Supplier A", "123-456-7890");
    inventory.addSupplier(2, "Supplier B", "098-765-4321");

    inventory.displayFurniture();
    inventory.displaySuppliers();

    inventory.updateFurniture(1, "Chair", "Seating", 45.99, 25);
    inventory.searchFurniture(1);
    
    inventory.deleteSupplier(1);
    inventory.displaySuppliers();

    return 0;
}