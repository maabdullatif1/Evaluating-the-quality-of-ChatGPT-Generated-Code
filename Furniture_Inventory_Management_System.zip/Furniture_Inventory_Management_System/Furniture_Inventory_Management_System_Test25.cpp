#include <iostream>
#include <vector>
#include <string>

struct Furniture {
    int id;
    std::string name;
    std::string type;
    int quantity;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventorySystem {
private:
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;
    int furnitureIdCounter = 1;
    int supplierIdCounter = 1;

public:
    void addFurniture() {
        Furniture f;
        f.id = furnitureIdCounter++;
        std::cout << "Enter furniture name: ";
        std::cin >> f.name;
        std::cout << "Enter furniture type: ";
        std::cin >> f.type;
        std::cout << "Enter quantity: ";
        std::cin >> f.quantity;
        furnitureList.push_back(f);
    }

    void deleteFurniture() {
        int id;
        std::cout << "Enter furniture ID to delete: ";
        std::cin >> id;
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture() {
        int id;
        std::cout << "Enter furniture ID to update: ";
        std::cin >> id;
        for (auto &f : furnitureList) {
            if (f.id == id) {
                std::cout << "Enter new furniture name: ";
                std::cin >> f.name;
                std::cout << "Enter new furniture type: ";
                std::cin >> f.type;
                std::cout << "Enter new quantity: ";
                std::cin >> f.quantity;
                break;
            }
        }
    }

    void searchFurniture() {
        std::string name;
        std::cout << "Enter furniture name to search: ";
        std::cin >> name;
        for (const auto &f : furnitureList) {
            if (f.name == name) {
                std::cout << "ID: " << f.id << " Name: " << f.name << " Type: " << f.type << " Quantity: " << f.quantity << std::endl;
            }
        }
    }

    void displayFurniture() {
        for (const auto &f : furnitureList) {
            std::cout << "ID: " << f.id << " Name: " << f.name << " Type: " << f.type << " Quantity: " << f.quantity << std::endl;
        }
    }

    void addSupplier() {
        Supplier s;
        s.id = supplierIdCounter++;
        std::cout << "Enter supplier name: ";
        std::cin >> s.name;
        std::cout << "Enter supplier contact: ";
        std::cin >> s.contact;
        supplierList.push_back(s);
    }

    void deleteSupplier() {
        int id;
        std::cout << "Enter supplier ID to delete: ";
        std::cin >> id;
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->id == id) {
                supplierList.erase(it);
                break;
            }
        }
    }

    void updateSupplier() {
        int id;
        std::cout << "Enter supplier ID to update: ";
        std::cin >> id;
        for (auto &s : supplierList) {
            if (s.id == id) {
                std::cout << "Enter new supplier name: ";
                std::cin >> s.name;
                std::cout << "Enter new supplier contact: ";
                std::cin >> s.contact;
                break;
            }
        }
    }

    void searchSupplier() {
        std::string name;
        std::cout << "Enter supplier name to search: ";
        std::cin >> name;
        for (const auto &s : supplierList) {
            if (s.name == name) {
                std::cout << "ID: " << s.id << " Name: " << s.name << " Contact: " << s.contact << std::endl;
            }
        }
    }

    void displaySuppliers() {
        for (const auto &s : supplierList) {
            std::cout << "ID: " << s.id << " Name: " << s.name << " Contact: " << s.contact << std::endl;
        }
    }
};

int main() {
    InventorySystem is;
    int choice;
    do {
        std::cout << "1. Add Furniture\n2. Delete Furniture\n3. Update Furniture\n4. Search Furniture\n5. Display Furniture\n";
        std::cout << "6. Add Supplier\n7. Delete Supplier\n8. Update Supplier\n9. Search Supplier\n10. Display Suppliers\n0. Exit\n";
        std::cout << "Enter choice: ";
        std::cin >> choice;
        switch (choice) {
            case 1: is.addFurniture(); break;
            case 2: is.deleteFurniture(); break;
            case 3: is.updateFurniture(); break;
            case 4: is.searchFurniture(); break;
            case 5: is.displayFurniture(); break;
            case 6: is.addSupplier(); break;
            case 7: is.deleteSupplier(); break;
            case 8: is.updateSupplier(); break;
            case 9: is.searchSupplier(); break;
            case 10: is.displaySuppliers(); break;
            case 0: break;
            default: std::cout << "Invalid choice." << std::endl;
        }
    } while (choice != 0);
    return 0;
}