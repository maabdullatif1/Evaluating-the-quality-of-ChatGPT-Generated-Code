#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    int quantity;

    Furniture(int id, std::string name, std::string type, int quantity)
        : id(id), name(name), type(type), quantity(quantity) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string address;

    Supplier(int id, std::string name, std::string address)
        : id(id), name(name), address(address) {}
};

class InventoryManagementSystem {
    std::vector<Furniture> furnitures;
    std::vector<Supplier> suppliers;

    Furniture* findFurnitureById(int id) {
        for (auto& f : furnitures) {
            if (f.id == id) return &f;
        }
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for (auto& s : suppliers) {
            if (s.id == id) return &s;
        }
        return nullptr;
    }

public:
    void addFurniture(int id, std::string name, std::string type, int quantity) {
        if (findFurnitureById(id) == nullptr) {
            furnitures.emplace_back(id, name, type, quantity);
        }
    }

    void addSupplier(int id, std::string name, std::string address) {
        if (findSupplierById(id) == nullptr) {
            suppliers.emplace_back(id, name, address);
        }
    }

    void deleteFurniture(int id) {
        furnitures.erase(std::remove_if(furnitures.begin(), furnitures.end(),
                                        [&](Furniture& f) { return f.id == id; }),
                         furnitures.end());
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(),
                                       [&](Supplier& s) { return s.id == id; }),
                        suppliers.end());
    }

    void updateFurniture(int id, std::string name, std::string type, int quantity) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture) {
            furniture->name = name;
            furniture->type = type;
            furniture->quantity = quantity;
        }
    }

    void updateSupplier(int id, std::string name, std::string address) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->address = address;
        }
    }

    Furniture* searchFurniture(int id) {
        return findFurnitureById(id);
    }

    Supplier* searchSupplier(int id) {
        return findSupplierById(id);
    }

    void displayFurnitures() {
        for (const auto& f : furnitures) {
            std::cout << "ID: " << f.id << ", Name: " << f.name
                      << ", Type: " << f.type << ", Qty: " << f.quantity << "\n";
        }
    }

    void displaySuppliers() {
        for (const auto& s : suppliers) {
            std::cout << "ID: " << s.id << ", Name: " << s.name
                      << ", Address: " << s.address << "\n";
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addFurniture(1, "Chair", "Seating", 10);
    ims.addSupplier(1, "Supplier A", "123 Street");
    ims.displayFurnitures();
    ims.displaySuppliers();
    return 0;
}