#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Furniture {
    int id;
    string name;
    string type;
    string supplierName;
    int quantity;
    double price;
};

class Inventory {
private:
    vector<Furniture> furnitures;
    int nextId = 1;

public:
    void addFurniture(string name, string type, string supplierName, int quantity, double price) {
        Furniture furniture = {nextId++, name, type, supplierName, quantity, price};
        furnitures.push_back(furniture);
        cout << "Furniture added successfully.\n";
    }

    void deleteFurniture(int id) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->id == id) {
                furnitures.erase(it);
                cout << "Furniture deleted successfully.\n";
                return;
            }
        }
        cout << "Furniture not found.\n";
    }

    void updateFurniture(int id, string name, string type, string supplierName, int quantity, double price) {
        for (auto &furniture : furnitures) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.supplierName = supplierName;
                furniture.quantity = quantity;
                furniture.price = price;
                cout << "Furniture updated successfully.\n";
                return;
            }
        }
        cout << "Furniture not found.\n";
    }

    void searchFurniture(string name) {
        for (const auto &furniture : furnitures) {
            if (furniture.name == name) {
                displayFurnitureInfo(furniture);
                return;
            }
        }
        cout << "Furniture not found.\n";
    }

    void displayAllFurniture() {
        for (const auto &furniture : furnitures) {
            displayFurnitureInfo(furniture);
        }
    }

    void displayFurnitureInfo(const Furniture &furniture) {
        cout << "ID: " << furniture.id << "\n";
        cout << "Name: " << furniture.name << "\n";
        cout << "Type: " << furniture.type << "\n";
        cout << "Supplier: " << furniture.supplierName << "\n";
        cout << "Quantity: " << furniture.quantity << "\n";
        cout << "Price: " << furniture.price << "\n";
        cout << "--------------------------\n";
    }
};

int main() {
    Inventory inventory;
    int choice, id, quantity;
    string name, type, supplierName;
    double price;

    while (true) {
        cout << "1. Add Furniture\n";
        cout << "2. Delete Furniture\n";
        cout << "3. Update Furniture\n";
        cout << "4. Search Furniture\n";
        cout << "5. Display All Furniture\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter name: ";
                cin >> name;
                cout << "Enter type: ";
                cin >> type;
                cout << "Enter supplier name: ";
                cin >> supplierName;
                cout << "Enter quantity: ";
                cin >> quantity;
                cout << "Enter price: ";
                cin >> price;
                inventory.addFurniture(name, type, supplierName, quantity, price);
                break;
            case 2:
                cout << "Enter furniture ID to delete: ";
                cin >> id;
                inventory.deleteFurniture(id);
                break;
            case 3:
                cout << "Enter furniture ID to update: ";
                cin >> id;
                cout << "Enter new name: ";
                cin >> name;
                cout << "Enter new type: ";
                cin >> type;
                cout << "Enter new supplier name: ";
                cin >> supplierName;
                cout << "Enter new quantity: ";
                cin >> quantity;
                cout << "Enter new price: ";
                cin >> price;
                inventory.updateFurniture(id, name, type, supplierName, quantity, price);
                break;
            case 4:
                cout << "Enter furniture name to search: ";
                cin >> name;
                inventory.searchFurniture(name);
                break;
            case 5:
                inventory.displayAllFurniture();
                break;
            case 6:
                return 0;
            default:
                cout << "Invalid choice. Please try again.\n";
                break;
        }
    }
}