#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInformation;

    Supplier(int id, const std::string& name, const std::string& contactInformation)
        : id(id), name(name), contactInformation(contactInformation) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    double price;
    int supplierId;

    Furniture(int id, const std::string& name, const std::string& type, double price, int supplierId)
        : id(id), name(name), type(type), price(price), supplierId(supplierId) {}
};

class InventoryManagementSystem {
    std::vector<Furniture> furnitures;
    std::vector<Supplier> suppliers;
    int nextFurnitureId = 1;
    int nextSupplierId = 1;

public:
    void addFurniture(const std::string& name, const std::string& type, double price, int supplierId) {
        furnitures.emplace_back(nextFurnitureId++, name, type, price, supplierId);
    }

    void deleteFurniture(int id) {
        furnitures.erase(remove_if(furnitures.begin(), furnitures.end(),
                                   [id](const Furniture& f) { return f.id == id; }),
                         furnitures.end());
    }

    void updateFurniture(int id, const std::string& name, const std::string& type, double price, int supplierId) {
        for (auto& furniture : furnitures) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.price = price;
                furniture.supplierId = supplierId;
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto& furniture : furnitures) {
            if (furniture.id == id) return &furniture;
        }
        return nullptr;
    }

    void displayFurnitures() {
        for (const auto& furniture : furnitures) {
            std::cout << "ID: " << furniture.id
                      << ", Name: " << furniture.name
                      << ", Type: " << furniture.type
                      << ", Price: " << furniture.price
                      << ", Supplier ID: " << furniture.supplierId
                      << std::endl;
        }
    }

    void addSupplier(const std::string& name, const std::string& contactInformation) {
        suppliers.emplace_back(nextSupplierId++, name, contactInformation);
    }

    void deleteSupplier(int id) {
        suppliers.erase(remove_if(suppliers.begin(), suppliers.end(),
                                  [id](const Supplier& s) { return s.id == id; }),
                        suppliers.end());
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) return &supplier;
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id
                      << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contactInformation
                      << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    int choice, id, supplierId;
    std::string name, type, contact;
    double price;

    while (true) {
        std::cout << "1: Add Furniture\n2: Delete Furniture\n3: Update Furniture\n4: Search Furniture\n5: Display All Furnitures\n"
                  << "6: Add Supplier\n7: Delete Supplier\n8: Search Supplier\n9: Display All Suppliers\n10: Exit\n";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter Furniture Name, Type, Price, Supplier ID: ";
                std::cin >> name >> type >> price >> supplierId;
                ims.addFurniture(name, type, price, supplierId);
                break;
            case 2:
                std::cout << "Enter Furniture ID to delete: ";
                std::cin >> id;
                ims.deleteFurniture(id);
                break;
            case 3:
                std::cout << "Enter Furniture ID, New Name, Type, Price, Supplier ID: ";
                std::cin >> id >> name >> type >> price >> supplierId;
                ims.updateFurniture(id, name, type, price, supplierId);
                break;
            case 4:
                std::cout << "Enter Furniture ID to search: ";
                std::cin >> id;
                if (Furniture* f = ims.searchFurniture(id)) {
                    std::cout << "ID: " << f->id << ", Name: " << f->name << ", Type: " << f->type << ", Price: " << f->price
                              << ", Supplier ID: " << f->supplierId << std::endl;
                } else {
                    std::cout << "Furniture not found." << std::endl;
                }
                break;
            case 5:
                ims.displayFurnitures();
                break;
            case 6:
                std::cout << "Enter Supplier Name, Contact: ";
                std::cin >> name >> contact;
                ims.addSupplier(name, contact);
                break;
            case 7:
                std::cout << "Enter Supplier ID to delete: ";
                std::cin >> id;
                ims.deleteSupplier(id);
                break;
            case 8:
                std::cout << "Enter Supplier ID to search: ";
                std::cin >> id;
                if (Supplier* s = ims.searchSupplier(id)) {
                    std::cout << "ID: " << s->id << ", Name: " << s->name << ", Contact: " << s->contactInformation << std::endl;
                } else {
                    std::cout << "Supplier not found." << std::endl;
                }
                break;
            case 9:
                ims.displaySuppliers();
                break;
            case 10:
                return 0;
        }
    }
}