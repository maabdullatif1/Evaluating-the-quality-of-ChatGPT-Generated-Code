#include<iostream>
#include<string>
#include<vector>

class Supplier {
public:
    std::string id;
    std::string name;
    std::string contact;
    Supplier(std::string i, std::string n, std::string c) : id(i), name(n), contact(c) {}
};

class Furniture {
public:
    std::string id;
    std::string name;
    std::string type;
    int quantity;
    std::string supplierId;
    Furniture(std::string i, std::string n, std::string t, int q, std::string sId)
        : id(i), name(n), type(t), quantity(q), supplierId(sId) {}
};

class Inventory {
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furnitures;

public:
    void addSupplier(const std::string& id, const std::string& name, const std::string& contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(const std::string& id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(), [&](Supplier& s){ return s.id == id; }), suppliers.end());
    }

    void updateSupplier(const std::string& id, const std::string& name, const std::string& contact) {
        for(auto& s : suppliers) {
            if(s.id == id) {
                s.name = name;
                s.contact = contact;
            }
        }
    }

    void searchSupplier(const std::string& id) {
        for(const auto& s : suppliers) {
            if(s.id == id) {
                std::cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << "\n";
            }
        }
    }

    void addFurniture(const std::string& id, const std::string& name, const std::string& type, int quantity, const std::string& supplierId) {
        furnitures.push_back(Furniture(id, name, type, quantity, supplierId));
    }

    void deleteFurniture(const std::string& id) {
        furnitures.erase(std::remove_if(furnitures.begin(), furnitures.end(), [&](Furniture& f){ return f.id == id; }), furnitures.end());
    }

    void updateFurniture(const std::string& id, const std::string& name, const std::string& type, int quantity, const std::string& supplierId) {
        for(auto& f : furnitures) {
            if(f.id == id) {
                f.name = name;
                f.type = type;
                f.quantity = quantity;
                f.supplierId = supplierId;
            }
        }
    }

    void searchFurniture(const std::string& id) {
        for(const auto& f : furnitures) {
            if(f.id == id) {
                std::cout << "ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type << ", Quantity: " << f.quantity << ", Supplier ID: " << f.supplierId << "\n";
            }
        }
    }

    void displayFurnitures() {
        for(const auto& f : furnitures) {
            std::cout << "ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type << ", Quantity: " << f.quantity << ", Supplier ID: " << f.supplierId << "\n";
        }
    }

    void displaySuppliers() {
        for(const auto& s : suppliers) {
            std::cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << "\n";
        }
    }
};

int main() {
    Inventory inv;
    inv.addSupplier("S1", "Supplier One", "123456789");
    inv.addSupplier("S2", "Supplier Two", "987654321");
    inv.addFurniture("F1", "Chair", "Seating", 10, "S1");
    inv.addFurniture("F2", "Table", "Surface", 5, "S2");
    inv.displaySuppliers();
    inv.displayFurnitures();
    inv.searchFurniture("F1");
    inv.updateFurniture("F1", "Chair Mod", "Seating", 12, "S1");
    inv.deleteSupplier("S2");
    inv.displayFurnitures();
    inv.displaySuppliers();
    return 0;
}