#include <iostream>
#include <vector>
#include <string>

struct Supplier {
    int id;
    std::string name;
};

struct Furniture {
    int id;
    std::string name;
    int quantity;
    Supplier supplier;
};

class InventorySystem {
private:
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;
    
    Supplier* findSupplierById(int id) {
        for (auto& supplier : supplierList) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }
    
    Furniture* findFurnitureById(int id) {
        for (auto& item : furnitureList) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

public:
    void addSupplier(int id, std::string name) {
        supplierList.push_back({id, name});
    }

    void addFurniture(int id, std::string name, int quantity, int supplierId) {
        Supplier* supplier = findSupplierById(supplierId);
        if (supplier) {
            furnitureList.push_back({id, name, quantity, *supplier});
        }
    }
    
    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }
    
    void updateFurniture(int id, std::string name, int quantity, int supplierId) {
        Furniture* furniture = findFurnitureById(id);
        Supplier* supplier = findSupplierById(supplierId);
        if (furniture && supplier) {
            furniture->name = name;
            furniture->quantity = quantity;
            furniture->supplier = *supplier;
        }
    }
    
    Furniture* searchFurnitureById(int id) {
        return findFurnitureById(id);
    }
    
    void displayFurniture() {
        for (const auto& item : furnitureList) {
            std::cout << "ID: " << item.id << " Name: " << item.name
                      << " Quantity: " << item.quantity << " Supplier: " << item.supplier.name << std::endl;
        }
    }
    
    void displaySuppliers() {
        for (const auto& supplier : supplierList) {
            std::cout << "ID: " << supplier.id << " Name: " << supplier.name << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addSupplier(1, "Supplier A");
    system.addSupplier(2, "Supplier B");

    system.addFurniture(100, "Chair", 50, 1);
    system.addFurniture(101, "Table", 30, 2);

    system.displaySuppliers();
    std::cout << std::endl;
    system.displayFurniture();
    
    system.updateFurniture(100, "Armchair", 40, 1);
    std::cout << std::endl;
    system.displayFurniture();

    Furniture* searchResult = system.searchFurnitureById(101);
    if (searchResult) {
        std::cout << "Found furniture: " << searchResult->name << std::endl;
    }

    system.deleteFurniture(100);
    std::cout << std::endl;
    system.displayFurniture();

    return 0;
}