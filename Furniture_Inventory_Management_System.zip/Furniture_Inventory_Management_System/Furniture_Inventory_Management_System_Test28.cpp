#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    std::string name;
    std::string address;
    std::string contact;
    Supplier(std::string n, std::string a, std::string c) : name(n), address(a), contact(c) {}
};

class Furniture {
public:
    std::string name;
    int stock;
    double price;
    Supplier* supplier;
    Furniture(std::string n, int s, double p, Supplier* supp) : name(n), stock(s), price(p), supplier(supp) {}
};

class Inventory {
private:
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

public:
    void addSupplier(std::string name, std::string address, std::string contact) {
        supplierList.push_back(Supplier(name, address, contact));
    }

    Supplier* findSupplier(std::string name) {
        for (auto& supplier : supplierList) {
            if (supplier.name == name)
                return &supplier;
        }
        return nullptr;
    }

    void addFurniture(std::string name, int stock, double price, std::string supplierName) {
        Supplier* supplier = findSupplier(supplierName);
        if (supplier) {
            furnitureList.push_back(Furniture(name, stock, price, supplier));
        }
    }

    void deleteFurniture(std::string name) {
        furnitureList.erase(std::remove_if(furnitureList.begin(), furnitureList.end(), 
                                           [&](Furniture& f) { return f.name == name; }),
                            furnitureList.end());
    }

    void updateFurniture(std::string name, int stock, double price) {
        for (auto& f : furnitureList) {
            if (f.name == name) {
                f.stock = stock;
                f.price = price;
                break;
            }
        }
    }

    Furniture* searchFurniture(std::string name) {
        for (auto& f : furnitureList) {
            if (f.name == name)
                return &f;
        }
        return nullptr;
    }

    void displayFurniture() {
        for (const auto& f : furnitureList) {
            std::cout << "Furniture Name: " << f.name << ", Stock: " << f.stock
                      << ", Price: " << f.price << ", Supplier: " << f.supplier->name << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto& s : supplierList) {
            std::cout << "Supplier Name: " << s.name << ", Address: " << s.address
                      << ", Contact: " << s.contact << std::endl;
        }
    }
};

int main() {
    Inventory inv;
    inv.addSupplier("ABC Furniture Supplies", "123 Main St", "555-0102");
    inv.addSupplier("XYZ Wholesale", "456 Elm St", "555-0199");
    inv.addFurniture("Chair", 50, 49.99, "ABC Furniture Supplies");
    inv.addFurniture("Table", 20, 89.99, "XYZ Wholesale");
    inv.displayFurniture();
    inv.displaySuppliers();
    inv.updateFurniture("Chair", 60, 54.99);
    Furniture* searchResult = inv.searchFurniture("Chair");
    if (searchResult)
        std::cout << "Found Furniture: " << searchResult->name << ", Stock: " << searchResult->stock << std::endl;
    inv.deleteFurniture("Table");
    inv.displayFurniture();
    return 0;
}