#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Supplier {
public:
    string name;
    string contact;

    Supplier(string n, string c) : name(n), contact(c) {}
};

class Furniture {
public:
    string name;
    string category;
    double price;
    string supplier;

    Furniture(string n, string c, double p, string s) : name(n), category(c), price(p), supplier(s) {}
};

class InventoryManagement {
    vector<Supplier> suppliers;
    vector<Furniture> furnitures;

public:
    void addSupplier(const string& name, const string& contact) {
        suppliers.push_back(Supplier(name, contact));
    }

    void addFurniture(const string& name, const string& category, double price, const string& supplier) {
        furnitures.push_back(Furniture(name, category, price, supplier));
    }

    void deleteFurniture(const string& name) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->name == name) {
                furnitures.erase(it);
                return;
            }
        }
    }

    void updateFurniture(const string& name, const string& newName, const string& newCategory, double newPrice, const string& newSupplier) {
        for (auto& furniture : furnitures) {
            if (furniture.name == name) {
                furniture.name = newName;
                furniture.category = newCategory;
                furniture.price = newPrice;
                furniture.supplier = newSupplier;
                return;
            }
        }
    }

    Furniture* searchFurniture(const string& name) {
        for (auto& furniture : furnitures) {
            if (furniture.name == name) {
                return &furniture;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "Supplier Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }

    void displayFurnitures() {
        for (const auto& furniture : furnitures) {
            cout << "Furniture Name: " << furniture.name << ", Category: " << furniture.category 
                 << ", Price: $" << furniture.price << ", Supplier: " << furniture.supplier << endl;
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addSupplier("Supplier1", "123-456-7890");
    inventory.addSupplier("Supplier2", "098-765-4321");
    inventory.addFurniture("Chair", "Seating", 49.99, "Supplier1");
    inventory.addFurniture("Table", "Dining", 89.99, "Supplier2");

    cout << "Initial Inventory:" << endl;
    inventory.displayFurnitures();
    cout << endl;

    cout << "Update Chair Details:" << endl;
    inventory.updateFurniture("Chair", "Armchair", "Seating", 99.99, "Supplier1");
    inventory.displayFurnitures();
    cout << endl;

    cout << "Search for Armchair:" << endl;
    Furniture* found = inventory.searchFurniture("Armchair");
    if (found) {
        cout << "Found Furniture - Name: " << found->name << ", Category: " << found->category 
             << ", Price: $" << found->price << ", Supplier: " << found->supplier << endl;
    } else {
        cout << "Furniture not found." << endl;
    }
    cout << endl;

    cout << "Delete Table and Display Inventory Again:" << endl;
    inventory.deleteFurniture("Table");
    inventory.displayFurnitures();
    cout << endl;

    cout << "Suppliers List:" << endl;
    inventory.displaySuppliers();

    return 0;
}