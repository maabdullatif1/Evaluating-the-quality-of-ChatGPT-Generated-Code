#include <iostream>
#include <vector>
#include <string>

struct Furniture {
    std::string name;
    std::string type;
    double price;
    int quantity;
    std::string supplier;
};

class InventoryManagement {
    std::vector<Furniture> inventory;

    int findFurnitureIndex(const std::string& name) {
        for (size_t i = 0; i < inventory.size(); ++i)
            if (inventory[i].name == name)
                return i;
        return -1;
    }

public:
    void addFurniture(const std::string& name, const std::string& type, double price, int quantity, const std::string& supplier) {
        inventory.push_back({name, type, price, quantity, supplier});
    }

    void deleteFurniture(const std::string& name) {
        int index = findFurnitureIndex(name);
        if (index != -1)
            inventory.erase(inventory.begin() + index);
    }

    void updateFurniture(const std::string& name, const std::string& type, double price, int quantity, const std::string& supplier) {
        int index = findFurnitureIndex(name);
        if (index != -1)
            inventory[index] = {name, type, price, quantity, supplier};
    }

    Furniture* searchFurniture(const std::string& name) {
        int index = findFurnitureIndex(name);
        if (index != -1)
            return &inventory[index];
        return nullptr;
    }

    void displayFurniture() {
        for (const auto& furn : inventory)
            std::cout << "Name: " << furn.name << " Type: " << furn.type << " Price: $" << furn.price << " Quantity: " << furn.quantity << " Supplier: " << furn.supplier << std::endl;
    }
};

int main() {
    InventoryManagement system;
    system.addFurniture("Chair", "Wooden", 50.0, 10, "BestFurnitureCo");
    system.addFurniture("Table", "Metal", 120.0, 5, "QualityTablesInc");

    system.displayFurniture();

    Furniture* searchResult = system.searchFurniture("Chair");
    if (searchResult)
        std::cout << searchResult->name << " found." << std::endl;

    system.updateFurniture("Table", "Metal", 100.0, 8, "QualityTablesInc");

    system.deleteFurniture("Chair");
    system.displayFurniture();

    return 0;
}