#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Supplier {
public:
    int id;
    string name;
    string contact;

    Supplier(int id, string name, string contact)
        : id(id), name(name), contact(contact) {}
};

class Furniture {
public:
    int id;
    string name;
    int quantity;
    float price;
    int supplierId;

    Furniture(int id, string name, int quantity, float price, int supplierId)
        : id(id), name(name), quantity(quantity), price(price), supplierId(supplierId) {}
};

class InventoryManagementSystem {
    vector<Supplier> suppliers;
    vector<Furniture> furnitureList;

public:
    void addSupplier(int id, string name, string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void addFurniture(int id, string name, int quantity, float price, int supplierId) {
        furnitureList.push_back(Furniture(id, name, quantity, price, supplierId));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
            }
        }
    }

    void updateFurniture(int id, string name, int quantity, float price, int supplierId) {
        for (auto &furniture : furnitureList) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.quantity = quantity;
                furniture.price = price;
                furniture.supplierId = supplierId;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto &supplier : suppliers) {
            if (supplier.id == id) {
                cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
            }
        }
    }

    void searchFurniture(int id) {
        for (const auto &furniture : furnitureList) {
            if (furniture.id == id) {
                cout << "Furniture ID: " << furniture.id << ", Name: " << furniture.name
                     << ", Quantity: " << furniture.quantity << ", Price: " << furniture.price
                     << ", Supplier ID: " << furniture.supplierId << endl;
            }
        }
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }

    void displayFurniture() {
        for (const auto &furniture : furnitureList) {
            cout << "Furniture ID: " << furniture.id << ", Name: " << furniture.name
                 << ", Quantity: " << furniture.quantity << ", Price: " << furniture.price
                 << ", Supplier ID: " << furniture.supplierId << endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier(1, "Supplier A", "123-456-7890");
    ims.addFurniture(101, "Chair", 50, 29.99, 1);
    ims.displaySuppliers();
    ims.displayFurniture();
    ims.searchSupplier(1);
    ims.searchFurniture(101);
    ims.updateSupplier(1, "Supplier A+", "098-765-4321");
    ims.updateFurniture(101, "Office Chair", 100, 39.99, 1);
    ims.displaySuppliers();
    ims.displayFurniture();
    ims.deleteSupplier(1);
    ims.deleteFurniture(101);
    ims.displaySuppliers();
    ims.displayFurniture();
    return 0;
}