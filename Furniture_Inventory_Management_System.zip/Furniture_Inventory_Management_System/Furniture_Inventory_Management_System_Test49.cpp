#include <iostream>
#include <vector>
#include <string>

class Furniture {
    std::string name;
    std::string type;
    int quantity;
public:
    Furniture(std::string n, std::string t, int q) : name(n), type(t), quantity(q) {}
    std::string getName() const { return name; }
    std::string getType() const { return type; }
    int getQuantity() const { return quantity; }
    void setQuantity(int q) { quantity = q; }
};

class Supplier {
    std::string name;
    std::string contact;
public:
    Supplier(std::string n, std::string c) : name(n), contact(c) {}
    std::string getName() const { return name; }
    std::string getContact() const { return contact; }
};

class InventorySystem {
    std::vector<Furniture> furnitures;
    std::vector<Supplier> suppliers;
public:
    void addFurniture(const Furniture& furniture) { furnitures.push_back(furniture); }
    void deleteFurniture(const std::string& name) {
        furnitures.erase(
            std::remove_if(furnitures.begin(), furnitures.end(),
                           [&](Furniture& f) { return f.getName() == name; }),
            furnitures.end());
    }
    void updateFurniture(const std::string& name, int quantity) {
        for (auto& f : furnitures)
            if (f.getName() == name)
                f.setQuantity(quantity);
    }
    Furniture* searchFurniture(const std::string& name) {
        for (auto& f : furnitures)
            if (f.getName() == name)
                return &f;
        return nullptr;
    }
    void displayFurnitures() const {
        for (const auto& f : furnitures)
            std::cout << "Name: " << f.getName() << ", Type: " << f.getType()
                      << ", Quantity: " << f.getQuantity() << std::endl;
    }
    void addSupplier(const Supplier& supplier) { suppliers.push_back(supplier); }
    void deleteSupplier(const std::string& name) {
        suppliers.erase(
            std::remove_if(suppliers.begin(), suppliers.end(),
                           [&](Supplier& s) { return s.getName() == name; }),
            suppliers.end());
    }
    Supplier* searchSupplier(const std::string& name) {
        for (auto& s : suppliers)
            if (s.getName() == name) 
                return &s;
        return nullptr;
    }
    void displaySuppliers() const {
        for (const auto& s : suppliers)
            std::cout << "Name: " << s.getName() << ", Contact: " << s.getContact() << std::endl;
    }
};

int main() {
    InventorySystem system;
    system.addFurniture(Furniture("Chair", "Wood", 50));
    system.addFurniture(Furniture("Table", "Metal", 20));
    system.updateFurniture("Chair", 60);
    Furniture* searchedFurniture = system.searchFurniture("Table");
    if (searchedFurniture)
        std::cout << "Found Furniture: " << searchedFurniture->getName() << std::endl;
    system.displayFurnitures();

    system.addSupplier(Supplier("ABC Supplies", "123-456-7890"));
    system.addSupplier(Supplier("XYZ Traders", "098-765-4321"));
    system.deleteSupplier("ABC Supplies");
    Supplier* searchedSupplier = system.searchSupplier("XYZ Traders");
    if (searchedSupplier)
        std::cout << "Found Supplier: " << searchedSupplier->getName() << std::endl;
    system.displaySuppliers();

    return 0;
}