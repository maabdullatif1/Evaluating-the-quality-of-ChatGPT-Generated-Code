#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    int id;
    std::string name;
    int quantity;
    double price;
    int supplierId;

    Furniture(int id, const std::string& name, int quantity, double price, int supplierId)
        : id(id), name(name), quantity(quantity), price(price), supplierId(supplierId) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInfo;

    Supplier(int id, const std::string& name, const std::string& contactInfo)
        : id(id), name(name), contactInfo(contactInfo) {}
};

class InventoryManagementSystem {
    std::vector<Furniture> furnitures;
    std::vector<Supplier> suppliers;

    Furniture* findFurnitureById(int id) {
        for (auto& furniture : furnitures) {
            if (furniture.id == id) {
                return &furniture;
            }
        }
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

public:
    void addFurniture(int id, const std::string& name, int quantity, double price, int supplierId) {
        furnitures.push_back(Furniture(id, name, quantity, price, supplierId));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->id == id) {
                furnitures.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, const std::string& name, int quantity, double price, int supplierId) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture) {
            furniture->name = name;
            furniture->quantity = quantity;
            furniture->price = price;
            furniture->supplierId = supplierId;
        }
    }

    void searchFurniture(int id) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture) {
            std::cout << "Furniture ID: " << furniture->id << "\n"
                      << "Name: " << furniture->name << "\n"
                      << "Quantity: " << furniture->quantity << "\n"
                      << "Price: " << furniture->price << "\n"
                      << "Supplier ID: " << furniture->supplierId << "\n";
        } else {
            std::cout << "Furniture not found.\n";
        }
    }

    void displayAllFurnitures() {
        for (const auto& furniture : furnitures) {
            std::cout << "ID: " << furniture.id
                      << ", Name: " << furniture.name
                      << ", Quantity: " << furniture.quantity
                      << ", Price: " << furniture.price
                      << ", Supplier ID: " << furniture.supplierId << "\n";
        }
    }

    void addSupplier(int id, const std::string& name, const std::string& contactInfo) {
        suppliers.push_back(Supplier(id, name, contactInfo));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contactInfo) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contactInfo = contactInfo;
        }
    }

    void searchSupplier(int id) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            std::cout << "Supplier ID: " << supplier->id << "\n"
                      << "Name: " << supplier->name << "\n"
                      << "Contact Info: " << supplier->contactInfo << "\n";
        } else {
            std::cout << "Supplier not found.\n";
        }
    }

    void displayAllSuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id
                      << ", Name: " << supplier.name
                      << ", Contact Info: " << supplier.contactInfo << "\n";
        }
    }
};

int main() {
    InventoryManagementSystem system;

    system.addSupplier(1, "Supplier One", "contact@one.com");
    system.addSupplier(2, "Supplier Two", "contact@two.com");

    system.addFurniture(101, "Chair", 50, 49.99, 1);
    system.addFurniture(102, "Table", 20, 149.99, 2);

    system.displayAllFurnitures();
    system.displayAllSuppliers();

    return 0;
}