#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int i, std::string n, std::string c) : id(i), name(n), contact(c) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    int quantity;
    double price;
    int supplierId;

    Furniture(int i, std::string n, std::string t, int q, double p, int sId) 
        : id(i), name(n), type(t), quantity(q), price(p), supplierId(sId) {}
};

class InventorySystem {
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

public:
    void addFurniture(int id, std::string name, std::string type, int quantity, double price, int supplierId) {
        furnitureList.push_back(Furniture(id, name, type, quantity, price, supplierId));
    }

    void addSupplier(int id, std::string name, std::string contact) {
        supplierList.push_back(Supplier(id, name, contact));
    }

    void deleteFurniture(int id) {
        furnitureList.erase(std::remove_if(furnitureList.begin(), furnitureList.end(), [id](Furniture &f) {
            return f.id == id;
        }), furnitureList.end());
    }

    void deleteSupplier(int id) {
        supplierList.erase(std::remove_if(supplierList.begin(), supplierList.end(), [id](Supplier &s) {
            return s.id == id;
        }), supplierList.end());
    }

    void updateFurniture(int id, std::string name, std::string type, int quantity, double price, int supplierId) {
        for (auto &f : furnitureList) {
            if (f.id == id) {
                f.name = name;
                f.type = type;
                f.quantity = quantity;
                f.price = price;
                f.supplierId = supplierId;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto &s : supplierList) {
            if (s.id == id) {
                s.name = name;
                s.contact = contact;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto &f : furnitureList) {
            if (f.id == id) return &f;
        }
        return nullptr;
    }

    Supplier* searchSupplier(int id) {
        for (auto &s : supplierList) {
            if (s.id == id) return &s;
        }
        return nullptr;
    }

    void displayFurniture() {
        for (const auto &f : furnitureList) {
            std::cout << "Furniture ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type
                      << ", Quantity: " << f.quantity << ", Price: $" << f.price 
                      << ", Supplier ID: " << f.supplierId << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto &s : supplierList) {
            std::cout << "Supplier ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addSupplier(1, "Supplier A", "123-456-7890");
    system.addSupplier(2, "Supplier B", "098-765-4321");
    system.addFurniture(1, "Chair", "Seating", 50, 29.99, 1);
    system.addFurniture(2, "Table", "Dining", 20, 99.99, 2);
    system.displayFurniture();
    system.displaySuppliers();
    system.updateFurniture(1, "Chair", "Seating", 45, 29.99, 1);
    system.deleteSupplier(2);
    system.displayFurniture();
    system.displaySuppliers();

    return 0;
}