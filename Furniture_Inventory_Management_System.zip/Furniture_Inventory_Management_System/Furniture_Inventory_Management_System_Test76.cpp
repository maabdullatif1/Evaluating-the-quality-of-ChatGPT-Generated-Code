#include <iostream>
#include <vector>
#include <string>

struct Supplier {
    int supplierID;
    std::string name;
    std::string contact;
};

struct Furniture {
    int furnitureID;
    std::string name;
    std::string type;
    int quantity;
    Supplier supplier;
};

class InventoryManagement {
private:
    std::vector<Furniture> inventory;
    std::vector<Supplier> suppliers;

    Supplier* findSupplier(int supplierID) {
        for (auto& supplier : suppliers) {
            if (supplier.supplierID == supplierID) {
                return &supplier;
            }
        }
        return nullptr;
    }

    Furniture* findFurniture(int furnitureID) {
        for (auto& furniture : inventory) {
            if (furniture.furnitureID == furnitureID) {
                return &furniture;
            }
        }
        return nullptr;
    }

public:
    void addSupplier(int supplierID, const std::string& name, const std::string& contact) {
        suppliers.push_back({supplierID, name, contact});
    }

    void addFurniture(int furnitureID, const std::string& name, const std::string& type, int quantity, int supplierID) {
        Supplier* supplier = findSupplier(supplierID);
        if (supplier) {
            inventory.push_back({furnitureID, name, type, quantity, *supplier});
        }
    }

    void deleteFurniture(int furnitureID) {
        for (auto it = inventory.begin(); it != inventory.end(); ++it) {
            if (it->furnitureID == furnitureID) {
                inventory.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int furnitureID, const std::string& name, const std::string& type, int quantity, int supplierID) {
        Furniture* furniture = findFurniture(furnitureID);
        Supplier* supplier = findSupplier(supplierID);
        if (furniture && supplier) {
            furniture->name = name;
            furniture->type = type;
            furniture->quantity = quantity;
            furniture->supplier = *supplier;
        }
    }

    Furniture* searchFurniture(int furnitureID) {
        return findFurniture(furnitureID);
    }

    void displayFurniture() {
        std::cout << "Furniture List:\n";
        for (const auto& furniture : inventory) {
            std::cout << "ID: " << furniture.furnitureID << " Name: " << furniture.name
                      << " Type: " << furniture.type << " Quantity: " << furniture.quantity
                      << " Supplier: " << furniture.supplier.name << "\n";
        }
    }

    void displaySuppliers() {
        std::cout << "Supplier List:\n";
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.supplierID << " Name: " << supplier.name
                      << " Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventoryManagement system;
    system.addSupplier(1, "Supplier A", "123-456-7890");
    system.addSupplier(2, "Supplier B", "098-765-4321");
    system.addFurniture(101, "Chair", "Seating", 50, 1);
    system.addFurniture(102, "Table", "Surface", 20, 2);
    system.displaySuppliers();
    system.displayFurniture();
    system.updateFurniture(101, "Chair", "Seating", 60, 1);
    system.displayFurniture();
    system.deleteFurniture(102);
    system.displayFurniture();
    return 0;
}