#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Supplier {
public:
    int id;
    string name;
    string contact;

    Supplier(int i, string n, string c) : id(i), name(n), contact(c) {}
};

class Furniture {
public:
    int id;
    string name;
    string type;
    double price;
    int supplierId;

    Furniture(int i, string n, string t, double p, int sId) : id(i), name(n), type(t), price(p), supplierId(sId) {}
};

class Inventory {
private:
    vector<Supplier> suppliers;
    vector<Furniture> furnitures;

    Supplier* findSupplierById(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    Furniture* findFurnitureById(int id) {
        for (auto &furniture : furnitures) {
            if (furniture.id == id) {
                return &furniture;
            }
        }
        return nullptr;
    }

public:
    void addSupplier(int id, string name, string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    Supplier* searchSupplier(int id) {
        return findSupplierById(id);
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }

    void addFurniture(int id, string name, string type, double price, int supplierId) {
        furnitures.push_back(Furniture(id, name, type, price, supplierId));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->id == id) {
                furnitures.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, string name, string type, double price, int supplierId) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture) {
            furniture->name = name;
            furniture->type = type;
            furniture->price = price;
            furniture->supplierId = supplierId;
        }
    }

    Furniture* searchFurniture(int id) {
        return findFurnitureById(id);
    }

    void displayFurnitures() {
        for (const auto &furniture : furnitures) {
            cout << "ID: " << furniture.id << ", Name: " << furniture.name
                 << ", Type: " << furniture.type << ", Price: " << furniture.price
                 << ", Supplier ID: " << furniture.supplierId << endl;
        }
    }
};

int main() {
    Inventory inventory;
    
    inventory.addSupplier(1, "Supplier A", "123-456-7890");
    inventory.addSupplier(2, "Supplier B", "098-765-4321");
    
    inventory.addFurniture(1, "Chair", "Seating", 49.99, 1);
    inventory.addFurniture(2, "Table", "Surface", 89.99, 2);
    
    cout << "Suppliers:" << endl;
    inventory.displaySuppliers();
    
    cout << "\nFurnitures:" << endl;
    inventory.displayFurnitures();
    
    return 0;
}