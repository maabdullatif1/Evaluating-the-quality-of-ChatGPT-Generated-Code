#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Furniture {
public:
    int id;
    string name;
    string type;
    int quantity;

    Furniture(int id, const string &name, const string &type, int qty)
            : id(id), name(name), type(type), quantity(qty) {}
};

class Supplier {
public:
    int id;
    string name;
    string contact;

    Supplier(int id, const string &name, const string &contact)
            : id(id), name(name), contact(contact) {}
};

class InventoryManagement {
private:
    vector<Furniture> furnitureList;
    vector<Supplier> supplierList;

public:
    void addFurniture(int id, const string &name, const string &type, int quantity) {
        furnitureList.emplace_back(id, name, type, quantity);
    }

    void deleteFurniture(int id) {
        furnitureList.erase(remove_if(furnitureList.begin(), furnitureList.end(),
                                [id](const Furniture &f) { return f.id == id; }),
                      furnitureList.end());
    }

    void updateFurniture(int id, const string &name, const string &type, int quantity) {
        for (auto &f : furnitureList) {
            if (f.id == id) {
                f.name = name;
                f.type = type;
                f.quantity = quantity;
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto &f : furnitureList) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayFurniture() {
        for (const auto &f : furnitureList) {
            cout << "ID: " << f.id << ", Name: " << f.name
                 << ", Type: " << f.type << ", Quantity: " << f.quantity << endl;
        }
    }

    void addSupplier(int id, const string &name, const string &contact) {
        supplierList.emplace_back(id, name, contact);
    }

    void deleteSupplier(int id) {
        supplierList.erase(remove_if(supplierList.begin(), supplierList.end(),
                               [id](const Supplier &s) { return s.id == id; }),
                     supplierList.end());
    }

    void updateSupplier(int id, const string &name, const string &contact) {
        for (auto &s : supplierList) {
            if (s.id == id) {
                s.name = name;
                s.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &s : supplierList) {
            if (s.id == id) {
                return &s;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto &s : supplierList) {
            cout << "ID: " << s.id << ", Name: " << s.name
                 << ", Contact: " << s.contact << endl;
        }
    }
};

int main() {
    InventoryManagement inv;
    inv.addFurniture(1, "Chair", "Wood", 50);
    inv.addFurniture(2, "Table", "Metal", 20);
    inv.displayFurniture();
    inv.updateFurniture(1, "Arm Chair", "Wood", 60);
    inv.displayFurniture();

    inv.addSupplier(1, "Supplier A", "123-456-7890");
    inv.addSupplier(2, "Supplier B", "098-765-4321");
    inv.displaySuppliers();
    inv.deleteSupplier(1);
    inv.displaySuppliers();

    return 0;
}