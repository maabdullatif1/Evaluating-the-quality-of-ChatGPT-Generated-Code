#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Furniture {
public:
    int id;
    string name;
    string type;
    double price;

    Furniture(int i, string n, string t, double p): id(i), name(n), type(t), price(p) {}
};

class Supplier {
public:
    int id;
    string name;
    string contact;

    Supplier(int i, string n, string c): id(i), name(n), contact(c) {}
};

class InventoryManagement {
private:
    vector<Furniture> furnitureList;
    vector<Supplier> supplierList;

public:
    void addFurniture(int id, string name, string type, double price) {
        furnitureList.push_back(Furniture(id, name, type, price));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, string name, string type, double price) {
        for (auto &furniture : furnitureList) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.price = price;
                break;
            }
        }
    }

    void searchFurniture(int id) {
        for (const auto &furniture : furnitureList) {
            if (furniture.id == id) {
                cout << "Furniture ID: " << furniture.id << ", Name: " << furniture.name
                     << ", Type: " << furniture.type << ", Price: " << furniture.price << endl;
                return;
            }
        }
        cout << "Furniture not found!" << endl;
    }

    void displayFurniture() {
        for (const auto &furniture : furnitureList) {
            cout << "Furniture ID: " << furniture.id << ", Name: " << furniture.name
                 << ", Type: " << furniture.type << ", Price: " << furniture.price << endl;
        }
    }

    void addSupplier(int id, string name, string contact) {
        supplierList.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->id == id) {
                supplierList.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contact) {
        for (auto &supplier : supplierList) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto &supplier : supplierList) {
            if (supplier.id == id) {
                cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name
                     << ", Contact: " << supplier.contact << endl;
                return;
            }
        }
        cout << "Supplier not found!" << endl;
    }

    void displaySuppliers() {
        for (const auto &supplier : supplierList) {
            cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name
                 << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    InventoryManagement inventory;

    inventory.addFurniture(1, "Chair", "Seating", 49.99);
    inventory.addFurniture(2, "Table", "Dining", 89.99);
    inventory.displayFurniture();

    inventory.addSupplier(1, "Supplier One", "123-456-7890");
    inventory.addSupplier(2, "Supplier Two", "098-765-4321");
    inventory.displaySuppliers();

    return 0;
}