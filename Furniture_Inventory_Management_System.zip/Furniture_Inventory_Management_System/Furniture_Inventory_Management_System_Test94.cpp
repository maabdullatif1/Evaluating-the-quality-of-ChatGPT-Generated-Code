#include <iostream>
#include <vector>
#include <string>

struct Supplier {
    int id;
    std::string name;
    std::string contact_info;
};

struct Furniture {
    int id;
    std::string name;
    std::string type;
    int quantity;
    float price;
    int supplier_id;
};

std::vector<Supplier> suppliers;
std::vector<Furniture> furniture_list;

void addSupplier(int id, const std::string& name, const std::string& contact_info) {
    suppliers.push_back({id, name, contact_info});
}

void deleteSupplier(int id) {
    for(auto it = suppliers.begin(); it != suppliers.end(); ++it) {
        if (it->id == id) {
            suppliers.erase(it);
            break;
        }
    }
}

void updateSupplier(int id, const std::string& name, const std::string& contact_info) {
    for(auto& supplier : suppliers) {
        if (supplier.id == id) {
            supplier.name = name;
            supplier.contact_info = contact_info;
            break;
        }
    }
}

Supplier* searchSupplier(int id) {
    for(auto& supplier : suppliers) {
        if (supplier.id == id) {
            return &supplier;
        }
    }
    return nullptr;
}

void displaySuppliers() {
    for(const auto& supplier : suppliers) {
        std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                  << ", Contact Info: " << supplier.contact_info << std::endl;
    }
}

void addFurniture(int id, const std::string& name, const std::string& type, 
                  int quantity, float price, int supplier_id) {
    furniture_list.push_back({id, name, type, quantity, price, supplier_id});
}

void deleteFurniture(int id) {
    for(auto it = furniture_list.begin(); it != furniture_list.end(); ++it) {
        if (it->id == id) {
            furniture_list.erase(it);
            break;
        }
    }
}

void updateFurniture(int id, const std::string& name, const std::string& type, 
                     int quantity, float price, int supplier_id) {
    for(auto& furniture : furniture_list) {
        if (furniture.id == id) {
            furniture.name = name;
            furniture.type = type;
            furniture.quantity = quantity;
            furniture.price = price;
            furniture.supplier_id = supplier_id;
            break;
        }
    }
}

Furniture* searchFurniture(int id) {
    for(auto& furniture : furniture_list) {
        if (furniture.id == id) {
            return &furniture;
        }
    }
    return nullptr;
}

void displayFurniture() {
    for(const auto& furniture : furniture_list) {
        std::cout << "ID: " << furniture.id << ", Name: " << furniture.name
                  << ", Type: " << furniture.type << ", Quantity: " << furniture.quantity
                  << ", Price: " << furniture.price << ", Supplier ID: " << furniture.supplier_id 
                  << std::endl;
    }
}

int main() {
    addSupplier(1, "Supplier A", "contactA@example.com");
    addSupplier(2, "Supplier B", "contactB@example.com");
    addFurniture(1, "Table", "Wooden", 10, 150.0, 1);
    addFurniture(2, "Chair", "Metal", 20, 45.0, 2);
    
    displaySuppliers();
    displayFurniture();

    Supplier* supplier = searchSupplier(1);
    if (supplier) {
        std::cout << "Found Supplier: " << supplier->name << std::endl;
    }

    Furniture* furniture = searchFurniture(1);
    if (furniture) {
        std::cout << "Found Furniture: " << furniture->name << std::endl;
    }

    updateSupplier(1, "Updated Supplier A", "newcontactA@example.com");
    updateFurniture(1, "Updated Table", "Metal", 12, 160.0, 1);

    displaySuppliers();
    displayFurniture();

    deleteSupplier(2);
    deleteFurniture(2);

    displaySuppliers();
    displayFurniture();

    return 0;
}