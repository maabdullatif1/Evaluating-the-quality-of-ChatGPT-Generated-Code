#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    Supplier(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    double price;
    int supplierId;
    Furniture(int id, std::string name, std::string type, double price, int supplierId)
        : id(id), name(name), type(type), price(price), supplierId(supplierId) {}
};

class InventoryManagement {
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furnitures;

public:
    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }
    
    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }
    
    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }
    
    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }
    
    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << '\n';
        }
    }
    
    void addFurniture(int id, std::string name, std::string type, double price, int supplierId) {
        furnitures.push_back(Furniture(id, name, type, price, supplierId));
    }
    
    void deleteFurniture(int id) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->id == id) {
                furnitures.erase(it);
                break;
            }
        }
    }
    
    void updateFurniture(int id, std::string name, std::string type, double price, int supplierId) {
        for (auto& furniture : furnitures) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.price = price;
                furniture.supplierId = supplierId;
                break;
            }
        }
    }
    
    Furniture* searchFurniture(int id) {
        for (auto& furniture : furnitures) {
            if (furniture.id == id) {
                return &furniture;
            }
        }
        return nullptr;
    }
    
    void displayFurnitures() {
        for (const auto& furniture : furnitures) {
            std::cout << "ID: " << furniture.id << ", Name: " << furniture.name
                      << ", Type: " << furniture.type << ", Price: " << furniture.price
                      << ", Supplier ID: " << furniture.supplierId << '\n';
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addSupplier(1, "Supplier A", "123456");
    inventory.addSupplier(2, "Supplier B", "654321");
    inventory.addFurniture(101, "Chair", "Seating", 49.99, 1);
    inventory.addFurniture(102, "Table", "Surface", 89.99, 2);
    
    inventory.displaySuppliers();
    inventory.displayFurnitures();
    
    inventory.updateSupplier(1, "Supplier A Updated", "987654");
    inventory.updateFurniture(101, "Chair Deluxe", "Seating", 59.99, 1);
    
    inventory.displaySuppliers();
    inventory.displayFurnitures();
    
    Supplier* foundSupplier = inventory.searchSupplier(1);
    if (foundSupplier) std::cout << "Found Supplier: " << foundSupplier->name << '\n';

    Furniture* foundFurniture = inventory.searchFurniture(101);
    if (foundFurniture) std::cout << "Found Furniture: " << foundFurniture->name << '\n';

    inventory.deleteSupplier(2);
    inventory.deleteFurniture(102);
    
    inventory.displaySuppliers();
    inventory.displayFurnitures();

    return 0;
}