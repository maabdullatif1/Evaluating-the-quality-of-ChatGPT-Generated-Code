#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInfo;

    Supplier(int id, const std::string &name, const std::string &contactInfo)
        : id(id), name(name), contactInfo(contactInfo) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    int quantity;
    int supplierId;

    Furniture(int id, const std::string &name, const std::string &type, int quantity, int supplierId)
        : id(id), name(name), type(type), quantity(quantity), supplierId(supplierId) {}
};

class InventorySystem {
private:
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

public:
    void addFurniture(int id, const std::string &name, const std::string &type, int quantity, int supplierId) {
        furnitureList.emplace_back(id, name, type, quantity, supplierId);
    }

    void removeFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, const std::string &name, const std::string &type, int quantity, int supplierId) {
        for (auto &furn : furnitureList) {
            if (furn.id == id) {
                furn.name = name;
                furn.type = type;
                furn.quantity = quantity;
                furn.supplierId = supplierId;
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto &furn : furnitureList) {
            if (furn.id == id) return &furn;
        }
        return nullptr;
    }

    void addSupplier(int id, const std::string &name, const std::string &contactInfo) {
        supplierList.emplace_back(id, name, contactInfo);
    }

    void removeSupplier(int id) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->id == id) {
                supplierList.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string &name, const std::string &contactInfo) {
        for (auto &sup : supplierList) {
            if (sup.id == id) {
                sup.name = name;
                sup.contactInfo = contactInfo;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &sup : supplierList) {
            if (sup.id == id) return &sup;
        }
        return nullptr;
    }

    void displayFurniture() {
        for (const auto &furn : furnitureList) {
            std::cout << "ID: " << furn.id << ", Name: " << furn.name << ", Type: " << furn.type
                      << ", Quantity: " << furn.quantity << ", Supplier ID: " << furn.supplierId << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto &sup : supplierList) {
            std::cout << "ID: " << sup.id << ", Name: " << sup.name << ", Contact Info: " << sup.contactInfo << std::endl;
        }
    }
};

int main() {
    InventorySystem inventory;
    inventory.addSupplier(1, "ABC Supplies", "abc@example.com");
    inventory.addFurniture(1, "Chair", "Seating", 10, 1);
    inventory.displaySuppliers();
    inventory.displayFurniture();

    return 0;
}