#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Furniture {
public:
    int id;
    string name;
    string type;
    int quantity;
    double price;

    Furniture(int i, string n, string t, int q, double p) 
    : id(i), name(n), type(t), quantity(q), price(p) {}
};

class Supplier {
public:
    int id;
    string name;
    string contact;

    Supplier(int i, string n, string c) 
    : id(i), name(n), contact(c) {}
};

class InventoryManagementSystem {
private:
    vector<Furniture> furnitureList;
    vector<Supplier> supplierList;

    int findFurnitureIndexById(int id) {
        for (int i = 0; i < furnitureList.size(); i++) {
            if (furnitureList[i].id == id) {
                return i;
            }
        }
        return -1;
    }

    int findSupplierIndexById(int id) {
        for (int i = 0; i < supplierList.size(); i++) {
            if (supplierList[i].id == id) {
                return i;
            }
        }
        return -1;
    }

public:
    void addFurniture(int id, string name, string type, int quantity, double price) {
        if (findFurnitureIndexById(id) == -1) {
            furnitureList.push_back(Furniture(id, name, type, quantity, price));
        } else {
            cout << "Furniture with ID " << id << " already exists." << endl;
        }
    }

    void deleteFurniture(int id) {
        int index = findFurnitureIndexById(id);
        if (index != -1) {
            furnitureList.erase(furnitureList.begin() + index);
        } else {
            cout << "Furniture with ID " << id << " not found." << endl;
        }
    }

    void updateFurniture(int id, string name, string type, int quantity, double price) {
        int index = findFurnitureIndexById(id);
        if (index != -1) {
            furnitureList[index] = Furniture(id, name, type, quantity, price);
        } else {
            cout << "Furniture with ID " << id << " not found." << endl;
        }
    }

    void searchFurniture(int id) {
        int index = findFurnitureIndexById(id);
        if (index != -1) {
            Furniture &f = furnitureList[index];
            cout << "ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type 
                 << ", Quantity: " << f.quantity << ", Price: " << f.price << endl;
        } else {
            cout << "Furniture with ID " << id << " not found." << endl;
        }
    }

    void displayFurniture() {
        for (Furniture &f : furnitureList) {
            cout << "ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type 
                 << ", Quantity: " << f.quantity << ", Price: " << f.price << endl;
        }
    }

    void addSupplier(int id, string name, string contact) {
        if (findSupplierIndexById(id) == -1) {
            supplierList.push_back(Supplier(id, name, contact));
        } else {
            cout << "Supplier with ID " << id << " already exists." << endl;
        }
    }

    void deleteSupplier(int id) {
        int index = findSupplierIndexById(id);
        if (index != -1) {
            supplierList.erase(supplierList.begin() + index);
        } else {
            cout << "Supplier with ID " << id << " not found." << endl;
        }
    }

    void updateSupplier(int id, string name, string contact) {
        int index = findSupplierIndexById(id);
        if (index != -1) {
            supplierList[index] = Supplier(id, name, contact);
        } else {
            cout << "Supplier with ID " << id << " not found." << endl;
        }
    }

    void searchSupplier(int id) {
        int index = findSupplierIndexById(id);
        if (index != -1) {
            Supplier &s = supplierList[index];
            cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << endl;
        } else {
            cout << "Supplier with ID " << id << " not found." << endl;
        }
    }

    void displaySuppliers() {
        for (Supplier &s : supplierList) {
            cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addFurniture(1, "Sofa", "Seating", 5, 499.99);
    ims.addSupplier(1, "ABC Supplies", "123-4567");
    ims.displayFurniture();
    ims.displaySuppliers();
    return 0;
}