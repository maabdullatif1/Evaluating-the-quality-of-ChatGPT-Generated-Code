#include <iostream>
#include <string>
#include <vector>

struct Supplier {
    int id;
    std::string name;
    std::string contactInfo;
};

struct Furniture {
    int id;
    std::string name;
    std::string type;
    float price;
    int supplierId;
};

class InventorySystem {
private:
    std::vector<Furniture> furnitures;
    std::vector<Supplier> suppliers;

public:
    void addFurniture(int id, const std::string& name, const std::string& type, float price, int supplierId) {
        furnitures.push_back({id, name, type, price, supplierId});
    }

    void addSupplier(int id, const std::string& name, const std::string& contactInfo) {
        suppliers.push_back({id, name, contactInfo});
    }

    void deleteFurniture(int id) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->id == id) {
                furnitures.erase(it);
                return;
            }
        }
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                return;
            }
        }
    }

    void updateFurniture(int id, const std::string& name, const std::string& type, float price, int supplierId) {
        for (auto& furniture : furnitures) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.price = price;
                furniture.supplierId = supplierId;
                return;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contactInfo = contactInfo;
                return;
            }
        }
    }

    void searchFurniture(int id) {
        for (const auto& furniture : furnitures) {
            if (furniture.id == id) {
                std::cout << "Furniture ID: " << furniture.id << ", Name: " << furniture.name 
                          << ", Type: " << furniture.type << ", Price: " << furniture.price 
                          << ", Supplier ID: " << furniture.supplierId << std::endl;
                return;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name 
                          << ", Contact Info: " << supplier.contactInfo << std::endl;
                return;
            }
        }
    }

    void displayFurnitures() {
        for (const auto& furniture : furnitures) {
            std::cout << "Furniture ID: " << furniture.id << ", Name: " << furniture.name 
                      << ", Type: " << furniture.type << ", Price: " << furniture.price 
                      << ", Supplier ID: " << furniture.supplierId << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name 
                      << ", Contact Info: " << supplier.contactInfo << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addSupplier(1, "Supplier A", "123-456-7890");
    system.addFurniture(1, "Chair", "Office", 49.99, 1);
    system.displaySuppliers();
    system.displayFurnitures();
    system.searchFurniture(1);
    system.searchSupplier(1);
    system.updateFurniture(1, "Chair", "Gaming", 89.99, 1);
    system.updateSupplier(1, "Supplier A1", "123-456-0000");
    system.displaySuppliers();
    system.displayFurnitures();
    system.deleteFurniture(1);
    system.deleteSupplier(1);
    system.displaySuppliers();
    system.displayFurnitures();
    return 0;
}