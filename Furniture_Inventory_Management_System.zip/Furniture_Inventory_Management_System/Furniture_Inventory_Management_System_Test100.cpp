#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    double price;
    int supplierId;

    Furniture(int id, std::string name, std::string type, double price, int supplierId)
        : id(id), name(name), type(type), price(price), supplierId(supplierId) {}
};

class InventorySystem {
private:
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furnitureItems;

public:
    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto &s : suppliers) {
            if (s.id == id) {
                s.name = name;
                s.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &s : suppliers) {
            if (s.id == id) {
                return &s;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto &s : suppliers) {
            std::cout << "Supplier ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << std::endl;
        }
    }

    void addFurniture(int id, std::string name, std::string type, double price, int supplierId) {
        furnitureItems.push_back(Furniture(id, name, type, price, supplierId));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureItems.begin(); it != furnitureItems.end(); ++it) {
            if (it->id == id) {
                furnitureItems.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, std::string name, std::string type, double price, int supplierId) {
        for (auto &f : furnitureItems) {
            if (f.id == id) {
                f.name = name;
                f.type = type;
                f.price = price;
                f.supplierId = supplierId;
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto &f : furnitureItems) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayFurniture() {
        for (const auto &f : furnitureItems) {
            std::cout << "Furniture ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type 
                      << ", Price: " << f.price << ", Supplier ID: " << f.supplierId << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addSupplier(1, "Supplier One", "123-456-7890");
    system.addSupplier(2, "Supplier Two", "987-654-3210");

    system.addFurniture(1, "Chair", "Seating", 49.99, 1);
    system.addFurniture(2, "Table", "Dining", 149.99, 2);
    
    system.displaySuppliers();
    system.displayFurniture();

    return 0;
}