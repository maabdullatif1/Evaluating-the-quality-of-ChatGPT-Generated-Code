#include <iostream>
#include <string>
#include <vector>

class Supplier {
public:
    Supplier(std::string name, std::string contact) : name(name), contact(contact) {}
    std::string getName() const { return name; }
    std::string getContact() const { return contact; }
    void setName(const std::string& newName) { name = newName; }
    void setContact(const std::string& newContact) { contact = newContact; }
private:
    std::string name;
    std::string contact;
};

class Furniture {
public:
    Furniture(std::string name, std::string type, double price, Supplier supplier)
        : name(name), type(type), price(price), supplier(supplier) {}
    std::string getName() const { return name; }
    std::string getType() const { return type; }
    double getPrice() const { return price; }
    Supplier getSupplier() const { return supplier; }
    void setName(const std::string& newName) { name = newName; }
    void setType(const std::string& newType) { type = newType; }
    void setPrice(double newPrice) { price = newPrice; }
    void setSupplier(const Supplier& newSupplier) { supplier = newSupplier; }
private:
    std::string name;
    std::string type;
    double price;
    Supplier supplier;
};

class InventoryManagement {
public:
    void addFurniture(const Furniture& furniture) { furnitures.push_back(furniture); }
    void deleteFurniture(const std::string& name) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->getName() == name) {
                furnitures.erase(it);
                break;
            }
        }
    }
    void updateFurniture(const std::string& name, const Furniture& newFurniture) {
        for (auto& furniture : furnitures) {
            if (furniture.getName() == name) {
                furniture = newFurniture;
                break;
            }
        }
    }
    Furniture* searchFurniture(const std::string& name) {
        for (auto& furniture : furnitures) {
            if (furniture.getName() == name) {
                return &furniture;
            }
        }
        return nullptr;
    }
    void displayFurniture() {
        for (const auto& furniture : furnitures) {
            std::cout << "Name: " << furniture.getName() << ", Type: " << furniture.getType()
                      << ", Price: " << furniture.getPrice() << ", Supplier: " << furniture.getSupplier().getName()
                      << ", Contact: " << furniture.getSupplier().getContact() << std::endl;
        }
    }
    void addSupplier(const Supplier& supplier) { suppliers.push_back(supplier); }
    void deleteSupplier(const std::string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->getName() == name) {
                suppliers.erase(it);
                break;
            }
        }
    }
    void updateSupplier(const std::string& name, const Supplier& newSupplier) {
        for (auto& supplier : suppliers) {
            if (supplier.getName() == name) {
                supplier = newSupplier;
                break;
            }
        }
    }
    Supplier* searchSupplier(const std::string& name) {
        for (auto& supplier : suppliers) {
            if (supplier.getName() == name) {
                return &supplier;
            }
        }
        return nullptr;
    }
    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Name: " << supplier.getName() << ", Contact: " << supplier.getContact() << std::endl;
        }
    }
private:
    std::vector<Furniture> furnitures;
    std::vector<Supplier> suppliers;
};

int main() {
    InventoryManagement inventory;
    Supplier supplierA("Supplier One", "123-456-7890");
    Supplier supplierB("Supplier Two", "098-765-4321");
    inventory.addSupplier(supplierA);
    inventory.addSupplier(supplierB);
    Furniture table("Dining Table", "Table", 299.99, supplierA);
    Furniture chair("Office Chair", "Chair", 89.99, supplierB);
    inventory.addFurniture(table);
    inventory.addFurniture(chair);
    inventory.displayFurniture();
    inventory.displaySuppliers();
    return 0;
}