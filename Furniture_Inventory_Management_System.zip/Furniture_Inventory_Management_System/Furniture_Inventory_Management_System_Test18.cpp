#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Furniture {
public:
    int id;
    string name;
    string type;
    double price;

    Furniture(int id, string name, string type, double price)
        : id(id), name(name), type(type), price(price) {}
};

class Supplier {
public:
    int id;
    string name;
    string contact;

    Supplier(int id, string name, string contact)
        : id(id), name(name), contact(contact) {}
};

class InventoryManagementSystem {
private:
    vector<Furniture> furnitureList;
    vector<Supplier> supplierList;

public:
    void addFurniture(int id, string name, string type, double price) {
        furnitureList.push_back(Furniture(id, name, type, price));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, string name, string type, double price) {
        for (auto &furniture : furnitureList) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.price = price;
                break;
            }
        }
    }

    void searchFurniture(int id) {
        for (auto &furniture : furnitureList) {
            if (furniture.id == id) {
                cout << "ID: " << furniture.id << ", Name: " << furniture.name
                     << ", Type: " << furniture.type << ", Price: " << furniture.price << endl;
                return;
            }
        }
        cout << "Furniture not found." << endl;
    }

    void displayFurniture() {
        if (furnitureList.empty()) {
            cout << "No furniture available." << endl;
            return;
        }
        for (auto &furniture : furnitureList) {
            cout << "ID: " << furniture.id << ", Name: " << furniture.name
                 << ", Type: " << furniture.type << ", Price: " << furniture.price << endl;
        }
    }

    void addSupplier(int id, string name, string contact) {
        supplierList.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->id == id) {
                supplierList.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contact) {
        for (auto &supplier : supplierList) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (auto &supplier : supplierList) {
            if (supplier.id == id) {
                cout << "ID: " << supplier.id << ", Name: " << supplier.name
                     << ", Contact: " << supplier.contact << endl;
                return;
            }
        }
        cout << "Supplier not found." << endl;
    }

    void displaySuppliers() {
        if (supplierList.empty()) {
            cout << "No suppliers available." << endl;
            return;
        }
        for (auto &supplier : supplierList) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name
                 << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addFurniture(1, "Chair", "Wooden", 49.99);
    ims.addFurniture(2, "Table", "Glass", 129.99);
    
    ims.addSupplier(1, "Supplier A", "123-456-7890");
    ims.addSupplier(2, "Supplier B", "098-765-4321");

    ims.displayFurniture();
    ims.displaySuppliers();

    ims.searchFurniture(1);
    ims.searchSupplier(2);

    ims.updateFurniture(1, "Chair", "Metal", 59.99);
    ims.updateSupplier(1, "Supplier A", "111-222-3333");

    ims.deleteFurniture(2);
    ims.deleteSupplier(2);

    ims.displayFurniture();
    ims.displaySuppliers();

    return 0;
}