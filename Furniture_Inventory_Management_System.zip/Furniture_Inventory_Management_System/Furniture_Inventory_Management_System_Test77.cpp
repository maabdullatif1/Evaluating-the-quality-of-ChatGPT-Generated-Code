#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    Furniture(int id, std::string name, std::string type, int qty)
        : id(id), name(name), type(type), qty(qty) {}

    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getType() const { return type; }
    int getQuantity() const { return qty; }

    void setName(const std::string &newName) { name = newName; }
    void setType(const std::string &newType) { type = newType; }
    void setQuantity(int newQty) { qty = newQty; }

private:
    int id;
    std::string name;
    std::string type;
    int qty;
};

class Supplier {
public:
    Supplier(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}

    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getContact() const { return contact; }

    void setName(const std::string &newName) { name = newName; }
    void setContact(const std::string &newContact) { contact = newContact; }

private:
    int id;
    std::string name;
    std::string contact;
};

class FurnitureInventorySystem {
public:
    void addFurniture(int id, const std::string &name, const std::string &type, int qty) {
        furniture.push_back(Furniture(id, name, type, qty));
    }

    void deleteFurniture(int id) {
        for (auto it = furniture.begin(); it != furniture.end(); ++it) {
            if (it->getId() == id) {
                furniture.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, const std::string &name, const std::string &type, int qty) {
        for (auto &f : furniture) {
            if (f.getId() == id) {
                f.setName(name);
                f.setType(type);
                f.setQuantity(qty);
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto &f : furniture) {
            if (f.getId() == id) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayFurniture() const {
        for (const auto &f : furniture) {
            std::cout << "ID: " << f.getId() << ", Name: " << f.getName()
                      << ", Type: " << f.getType() << ", Quantity: " << f.getQuantity() << std::endl;
        }
    }

    void addSupplier(int id, const std::string &name, const std::string &contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->getId() == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string &name, const std::string &contact) {
        for (auto &s : suppliers) {
            if (s.getId() == id) {
                s.setName(name);
                s.setContact(contact);
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &s : suppliers) {
            if (s.getId() == id) {
                return &s;
            }
        }
        return nullptr;
    }

    void displaySuppliers() const {
        for (const auto &s : suppliers) {
            std::cout << "ID: " << s.getId() << ", Name: " << s.getName()
                      << ", Contact: " << s.getContact() << std::endl;
        }
    }

private:
    std::vector<Furniture> furniture;
    std::vector<Supplier> suppliers;
};

int main() {
    FurnitureInventorySystem system;

    system.addFurniture(1, "Chair", "Seating", 10);
    system.addFurniture(2, "Table", "Dining", 5);

    system.addSupplier(1, "SupplierA", "123-456");
    system.addSupplier(2, "SupplierB", "987-654");

    system.displayFurniture();
    system.displaySuppliers();

    Furniture* f = system.searchFurniture(1);
    if (f != nullptr) {
        std::cout << "Found furniture: " << f->getName() << std::endl;
    }

    Supplier* s = system.searchSupplier(1);
    if (s != nullptr) {
        std::cout << "Found supplier: " << s->getName() << std::endl;
    }

    return 0;
}