#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int supplierID;
    std::string name;
    std::string contact;
};

class Furniture {
public:
    int furnitureID;
    std::string name;
    std::string type;
    float price;
    int supplierID;
};

class InventorySystem {
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furnitureItems;

public:
    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.push_back(Supplier{id, name, contact});
    }
    
    void addFurniture(int id, const std::string& name, const std::string& type,
                      float price, int supplierID) {
        furnitureItems.push_back(Furniture{id, name, type, price, supplierID});
    }
    
    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(),
                                       [id](const Supplier& s) { return s.supplierID == id; }),
                        suppliers.end());
    }
    
    void deleteFurniture(int id) {
        furnitureItems.erase(std::remove_if(furnitureItems.begin(), furnitureItems.end(),
                                            [id](const Furniture& f) { return f.furnitureID == id; }),
                             furnitureItems.end());
    }
    
    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.supplierID == id) {
                supplier.name = name;
                supplier.contact = contact;
            }
        }
    }

    void updateFurniture(int id, const std::string& name, const std::string& type, 
                         float price, int supplierID) {
        for (auto& furniture : furnitureItems) {
            if (furniture.furnitureID == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.price = price;
                furniture.supplierID = supplierID;
            }
        }
    }
    
    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.supplierID == id) {
                std::cout << "Supplier ID: " << supplier.supplierID
                          << "\nName: " << supplier.name
                          << "\nContact: " << supplier.contact << "\n";
            }
        }
    }
    
    void searchFurniture(int id) {
        for (const auto& furniture : furnitureItems) {
            if (furniture.furnitureID == id) {
                std::cout << "Furniture ID: " << furniture.furnitureID
                          << "\nName: " << furniture.name
                          << "\nType: " << furniture.type
                          << "\nPrice: " << furniture.price
                          << "\nSupplier ID: " << furniture.supplierID << "\n";
            }
        }
    }
    
    void displayAllSuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.supplierID
                      << "\nName: " << supplier.name
                      << "\nContact: " << supplier.contact << "\n\n";
        }
    }

    void displayAllFurniture() {
        for (const auto& furniture : furnitureItems) {
            std::cout << "Furniture ID: " << furniture.furnitureID
                      << "\nName: " << furniture.name
                      << "\nType: " << furniture.type
                      << "\nPrice: " << furniture.price
                      << "\nSupplier ID: " << furniture.supplierID << "\n\n";
        }
    }
};

int main() {
    InventorySystem inventory;

    inventory.addSupplier(1, "Supplier A", "123-456-7890");
    inventory.addSupplier(2, "Supplier B", "987-654-3210");

    inventory.addFurniture(1, "Chair", "Seating", 49.99, 1);
    inventory.addFurniture(2, "Table", "Dining", 89.99, 2);

    inventory.displayAllSuppliers();
    inventory.displayAllFurniture();

    inventory.updateSupplier(1, "Updated Supplier A", "111-222-3333");
    inventory.updateFurniture(1, "Updated Chair", "Seating", 59.99, 2);

    inventory.displayAllSuppliers();
    inventory.displayAllFurniture();

    inventory.deleteFurniture(2);
    inventory.deleteSupplier(2);

    inventory.displayAllSuppliers();
    inventory.displayAllFurniture();
}