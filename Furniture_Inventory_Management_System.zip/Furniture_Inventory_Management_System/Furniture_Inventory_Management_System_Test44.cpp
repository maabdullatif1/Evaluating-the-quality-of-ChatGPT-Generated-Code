#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, const std::string& name, const std::string& contact)
        : id(id), name(name), contact(contact) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    int supplierId;

    Furniture(int id, const std::string& name, const std::string& type, int supplierId)
        : id(id), name(name), type(type), supplierId(supplierId) {}
};

class InventoryManagement {
private:
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furniture;

public:
    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found" << std::endl;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }

    void addFurniture(int id, const std::string& name, const std::string& type, int supplierId) {
        furniture.push_back(Furniture(id, name, type, supplierId));
    }

    void deleteFurniture(int id) {
        for (auto it = furniture.begin(); it != furniture.end(); ++it) {
            if (it->id == id) {
                furniture.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, const std::string& name, const std::string& type, int supplierId) {
        for (auto& furn : furniture) {
            if (furn.id == id) {
                furn.name = name;
                furn.type = type;
                furn.supplierId = supplierId;
                break;
            }
        }
    }

    void searchFurniture(int id) {
        for (const auto& furn : furniture) {
            if (furn.id == id) {
                std::cout << "Furniture ID: " << furn.id << ", Name: " << furn.name << ", Type: " << furn.type << ", Supplier ID: " << furn.supplierId << std::endl;
                return;
            }
        }
        std::cout << "Furniture not found" << std::endl;
    }

    void displayFurniture() {
        for (const auto& furn : furniture) {
            std::cout << "Furniture ID: " << furn.id << ", Name: " << furn.name << ", Type: " << furn.type << ", Supplier ID: " << furn.supplierId << std::endl;
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addSupplier(1, "Supplier A", "123456789");
    inventory.addSupplier(2, "Supplier B", "987654321");
    inventory.addFurniture(1, "Chair", "Wooden", 1);
    inventory.addFurniture(2, "Table", "Metal", 2);
    inventory.displaySuppliers();
    inventory.displayFurniture();
    inventory.searchSupplier(1);
    inventory.searchFurniture(2);
    inventory.updateSupplier(1, "Supplier A Updated", "111111111");
    inventory.updateFurniture(2, "Table Updated", "Plastic", 1);
    inventory.displaySuppliers();
    inventory.displayFurniture();
    inventory.deleteSupplier(2);
    inventory.deleteFurniture(1);
    inventory.displaySuppliers();
    inventory.displayFurniture();
    return 0;
}