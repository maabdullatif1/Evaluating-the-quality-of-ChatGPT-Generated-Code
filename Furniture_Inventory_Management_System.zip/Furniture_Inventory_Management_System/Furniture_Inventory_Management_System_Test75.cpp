#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Supplier {
public:
    int id;
    string name;
    string contact;
};

class Furniture {
public:
    int id;
    string name;
    string type;
    int quantity;
    double price;
    int supplierId;
};

class InventoryManagementSystem {
private:
    vector<Supplier> suppliers;
    vector<Furniture> furniture;

    Supplier* findSupplierById(int id) {
        for (auto& s : suppliers) {
            if (s.id == id) return &s;
        }
        return nullptr;
    }

    Furniture* findFurnitureById(int id) {
        for (auto& f : furniture) {
            if (f.id == id) return &f;
        }
        return nullptr;
    }

public:
    void addSupplier(int id, const string& name, const string& contact) {
        suppliers.push_back({id, name, contact});
    }

    void deleteSupplier(int id) {
        suppliers.erase(
            remove_if(suppliers.begin(), suppliers.end(),
                      [id](Supplier& s) { return s.id == id; }),
            suppliers.end());
    }

    void updateSupplier(int id, const string& name, const string& contact) {
        Supplier* s = findSupplierById(id);
        if (s) {
            s->name = name;
            s->contact = contact;
        }
    }

    void displaySuppliers() {
        for (const auto& s : suppliers) {
            cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << endl;
        }
    }

    void addFurniture(int id, const string& name, const string& type, int quantity, double price, int supplierId) {
        if (findSupplierById(supplierId)) {
            furniture.push_back({id, name, type, quantity, price, supplierId});
        }
    }

    void deleteFurniture(int id) {
        furniture.erase(
            remove_if(furniture.begin(), furniture.end(),
                      [id](Furniture& f) { return f.id == id; }),
            furniture.end());
    }

    void updateFurniture(int id, const string& name, const string& type, int quantity, double price, int supplierId) {
        Furniture* f = findFurnitureById(id);
        if (f && findSupplierById(supplierId)) {
            f->name = name;
            f->type = type;
            f->quantity = quantity;
            f->price = price;
            f->supplierId = supplierId;
        }
    }

    void displayFurniture() {
        for (const auto& f : furniture) {
            cout << "ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type
                 << ", Quantity: " << f.quantity << ", Price: " << f.price
                 << ", Supplier ID: " << f.supplierId << endl;
        }
    }

    void searchFurnitureByName(const string& name) {
        for (const auto& f : furniture) {
            if (f.name == name) {
                cout << "ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type
                     << ", Quantity: " << f.quantity << ", Price: " << f.price
                     << ", Supplier ID: " << f.supplierId << endl;
            }
        }
    }

    void searchSupplierByName(const string& name) {
        for (const auto& s : suppliers) {
            if (s.name == name) {
                cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << endl;
            }
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier(1, "John's Supplies", "123-456-7890");
    ims.addSupplier(2, "Furniture Co", "987-654-3210");
    ims.addFurniture(1, "Chair", "Seating", 50, 29.99, 1);
    ims.addFurniture(2, "Table", "Dining", 20, 89.99, 2);
    ims.displaySuppliers();
    ims.displayFurniture();
    ims.searchFurnitureByName("Chair");
    ims.searchSupplierByName("Furniture Co");
    return 0;
}