#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Supplier {
public:
    int id;
    string name;
    string contactInfo;

    Supplier(int id, string name, string contactInfo) : id(id), name(name), contactInfo(contactInfo) {}
};

class Furniture {
public:
    int id;
    string name;
    double price;
    Supplier supplier;

    Furniture(int id, string name, double price, Supplier supplier) 
    : id(id), name(name), price(price), supplier(supplier) {}
};

class InventoryManagementSystem {
public:
    vector<Furniture> furnitureList;
    vector<Supplier> supplierList;

    void addSupplier(int id, string name, string contactInfo) {
        supplierList.emplace_back(id, name, contactInfo);
    }

    void addFurniture(int id, string name, double price, int supplierId) {
        for (auto& supplier : supplierList) {
            if (supplier.id == supplierId) {
                furnitureList.emplace_back(id, name, price, supplier);
                return;
            }
        }
        cout << "Supplier ID not found." << endl;
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                return;
            }
        }
        cout << "Furniture ID not found." << endl;
    }

    void updateFurniture(int id, string name, double price, int supplierId) {
        for (auto& furniture : furnitureList) {
            if (furniture.id == id) {
                for (auto& supplier : supplierList) {
                    if (supplier.id == supplierId) {
                        furniture.name = name;
                        furniture.price = price;
                        furniture.supplier = supplier;
                        return;
                    }
                }
                cout << "Supplier ID not found." << endl;
                return;
            }
        }
        cout << "Furniture ID not found." << endl;
    }

    void searchFurniture(int id) {
        for (auto& furniture : furnitureList) {
            if (furniture.id == id) {
                cout << "Furniture ID: " << furniture.id << ", Name: " << furniture.name
                     << ", Price: " << furniture.price << ", Supplier: " << furniture.supplier.name << endl;
                return;
            }
        }
        cout << "Furniture ID not found." << endl;
    }

    void displayFurniture() {
        for (auto& furniture : furnitureList) {
            cout << "ID: " << furniture.id << ", Name: " << furniture.name
                 << ", Price: " << furniture.price << ", Supplier: " << furniture.supplier.name << endl;
        }
    }

    void displaySuppliers() {
        for (auto& supplier : supplierList) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name
                 << ", Contact Info: " << supplier.contactInfo << endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier(1, "Supplier A", "contactA@example.com");
    ims.addSupplier(2, "Supplier B", "contactB@example.com");

    ims.addFurniture(101, "Chair", 29.99, 1);
    ims.addFurniture(102, "Table", 89.99, 2);

    ims.displayFurniture();
    ims.searchFurniture(101);
    ims.updateFurniture(101, "Office Chair", 39.99, 1);
    ims.displayFurniture();
    ims.deleteFurniture(101);
    ims.displayFurniture();
    ims.displaySuppliers();

    return 0;
}