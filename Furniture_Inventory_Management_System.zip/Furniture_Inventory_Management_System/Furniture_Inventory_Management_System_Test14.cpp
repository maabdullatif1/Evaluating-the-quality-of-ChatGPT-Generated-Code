#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int supplierID;
    std::string name;
    std::string contactInfo;

    Supplier(int id, const std::string& n, const std::string& c)
        : supplierID(id), name(n), contactInfo(c) {}
};

class Furniture {
public:
    int furnitureID;
    std::string name;
    std::string type;
    double price;
    int supplierID;

    Furniture(int id, const std::string& n, const std::string& t, double p, int sID)
        : furnitureID(id), name(n), type(t), price(p), supplierID(sID) {}
};

class InventorySystem {
public:
    void addSupplier(int id, const std::string& name, const std::string& contact);
    void deleteSupplier(int id);
    void updateSupplier(int id, const std::string& name, const std::string& contact);
    Supplier* searchSupplier(int id);
    void displaySuppliers();

    void addFurniture(int id, const std::string& name, const std::string& type, double price, int supplierID);
    void deleteFurniture(int id);
    void updateFurniture(int id, const std::string& name, const std::string& type, double price, int supplierID);
    Furniture* searchFurniture(int id);
    void displayFurniture();

private:
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furnitureItems;
};

void InventorySystem::addSupplier(int id, const std::string& name, const std::string& contact) {
    suppliers.emplace_back(id, name, contact);
}

void InventorySystem::deleteSupplier(int id) {
    for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
        if (it->supplierID == id) {
            suppliers.erase(it);
            break;
        }
    }
}

void InventorySystem::updateSupplier(int id, const std::string& name, const std::string& contact) {
    for (auto& supplier : suppliers) {
        if (supplier.supplierID == id) {
            supplier.name = name;
            supplier.contactInfo = contact;
            break;
        }
    }
}

Supplier* InventorySystem::searchSupplier(int id) {
    for (auto& supplier : suppliers) {
        if (supplier.supplierID == id) {
            return &supplier;
        }
    }
    return nullptr;
}

void InventorySystem::displaySuppliers() {
    for (const auto& supplier : suppliers) {
        std::cout << "Supplier ID: " << supplier.supplierID << ", Name: " << supplier.name 
                  << ", Contact Info: " << supplier.contactInfo << std::endl;
    }
}

void InventorySystem::addFurniture(int id, const std::string& name, const std::string& type, double price, int supplierID) {
    furnitureItems.emplace_back(id, name, type, price, supplierID);
}

void InventorySystem::deleteFurniture(int id) {
    for (auto it = furnitureItems.begin(); it != furnitureItems.end(); ++it) {
        if (it->furnitureID == id) {
            furnitureItems.erase(it);
            break;
        }
    }
}

void InventorySystem::updateFurniture(int id, const std::string& name, const std::string& type, double price, int supplierID) {
    for (auto& item : furnitureItems) {
        if (item.furnitureID == id) {
            item.name = name;
            item.type = type;
            item.price = price;
            item.supplierID = supplierID;
            break;
        }
    }
}

Furniture* InventorySystem::searchFurniture(int id) {
    for (auto& item : furnitureItems) {
        if (item.furnitureID == id) {
            return &item;
        }
    }
    return nullptr;
}

void InventorySystem::displayFurniture() {
    for (const auto& item : furnitureItems) {
        std::cout << "Furniture ID: " << item.furnitureID << ", Name: " << item.name 
                  << ", Type: " << item.type << ", Price: " << item.price 
                  << ", Supplier ID: " << item.supplierID << std::endl;
    }
}

int main() {
    InventorySystem system;
    system.addSupplier(1, "Supplier A", "123-456-7890");
    system.addFurniture(1, "Chair", "Seating", 49.99, 1);
    system.displaySuppliers();
    system.displayFurniture();
    return 0;
}