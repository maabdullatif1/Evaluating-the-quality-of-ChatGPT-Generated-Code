#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    
    Supplier(int id, const std::string& name, const std::string& contact)
        : id(id), name(name), contact(contact) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string category;
    double price;
    int supplierId;

    Furniture(int id, const std::string& name, const std::string& category, double price, int supplierId)
        : id(id), name(name), category(category), price(price), supplierId(supplierId) {}
};

class InventorySystem {
private:
    std::vector<Furniture> furnitures;
    std::vector<Supplier> suppliers;
    
    Supplier* findSupplierById(int id) {
        for (auto& supplier : suppliers)
            if (supplier.id == id)
                return &supplier;
        return nullptr;
    }
    
    Furniture* findFurnitureById(int id) {
        for (auto& furniture : furnitures)
            if (furniture.id == id)
                return &furniture;
        return nullptr;
    }

public:
    void addSupplier(int id, const std::string& name, const std::string& contact) {
        if (findSupplierById(id) == nullptr)
            suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void searchSupplier(int id) {
        Supplier* supplier = findSupplierById(id);
        if (supplier)
            std::cout << "Supplier ID: " << supplier->id << ", Name: " << supplier->name << ", Contact: " << supplier->contact << "\n";
        else
            std::cout << "Supplier not found\n";
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers)
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << "\n";
    }

    void addFurniture(int id, const std::string& name, const std::string& category, double price, int supplierId) {
        if (findSupplierById(supplierId) && findFurnitureById(id) == nullptr)
            furnitures.push_back(Furniture(id, name, category, price, supplierId));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->id == id) {
                furnitures.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, const std::string& name, const std::string& category, double price, int supplierId) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture && findSupplierById(supplierId)) {
            furniture->name = name;
            furniture->category = category;
            furniture->price = price;
            furniture->supplierId = supplierId;
        }
    }

    void searchFurniture(int id) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture) {
            std::cout << "Furniture ID: " << furniture->id << ", Name: " << furniture->name << ", Category: " 
                      << furniture->category << ", Price: $" << furniture->price << ", Supplier ID: " << furniture->supplierId << "\n";
        } else {
            std::cout << "Furniture not found\n";
        }
    }

    void displayFurnitures() {
        for (const auto& furniture : furnitures)
            std::cout << "Furniture ID: " << furniture.id << ", Name: " << furniture.name 
                      << ", Category: " << furniture.category << ", Price: $" << furniture.price 
                      << ", Supplier ID: " << furniture.supplierId << "\n";
    }
};

int main() {
    InventorySystem system;
    system.addSupplier(1, "ABC Corp", "abc@corp.com");
    system.addSupplier(2, "XYZ Ltd", "xyz@ltd.com");
    system.addFurniture(101, "Chair", "Seating", 49.99, 1);
    system.addFurniture(102, "Table", "Seating", 89.99, 2);

    system.displaySuppliers();
    system.displayFurnitures();

    system.searchSupplier(1);
    system.searchFurniture(101);

    system.updateSupplier(1, "ABC Incorporated", "contact@abcinc.com");
    system.updateFurniture(101, "Office Chair", "Office Supplies", 59.99, 1);

    system.displaySuppliers();
    system.displayFurnitures();

    system.deleteSupplier(2);
    system.deleteFurniture(102);

    system.displaySuppliers();
    system.displayFurnitures();

    return 0;
}