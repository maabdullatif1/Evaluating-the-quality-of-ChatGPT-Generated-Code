#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInfo;
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    double price;
    int supplierId;
};

class InventorySystem {
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furniture;
    
public:
    void addSupplier(int id, const std::string& name, const std::string& contactInfo) {
        suppliers.push_back({id, name, contactInfo});
    }
    
    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(),
                                       [id](const Supplier& s) { return s.id == id; }), suppliers.end());
    }
    
    void updateSupplier(int id, const std::string& name, const std::string& contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contactInfo = contactInfo;
            }
        }
    }
    
    void addFurniture(int id, const std::string& name, const std::string& type, double price, int supplierId) {
        furniture.push_back({id, name, type, price, supplierId});
    }
    
    void deleteFurniture(int id) {
        furniture.erase(std::remove_if(furniture.begin(), furniture.end(),
                                       [id](const Furniture& f) { return f.id == id; }), furniture.end());
    }
    
    void updateFurniture(int id, const std::string& name, const std::string& type, double price, int supplierId) {
        for (auto& f : furniture) {
            if (f.id == id) {
                f.name = name;
                f.type = type;
                f.price = price;
                f.supplierId = supplierId;
            }
        }
    }
    
    void searchFurnitureByName(const std::string& name) {
        for (const auto& f : furniture) {
            if (f.name == name) {
                std::cout << "Furniture ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type 
                          << ", Price: " << f.price << ", Supplier ID: " << f.supplierId << "\n";
            }
        }
    }
    
    void searchSupplierByName(const std::string& name) {
        for (const auto& s : suppliers) {
            if (s.name == name) {
                std::cout << "Supplier ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contactInfo << "\n";
            }
        }
    }
    
    void displayAllFurniture() {
        for (const auto& f : furniture) {
            std::cout << "Furniture ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type 
                      << ", Price: " << f.price << ", Supplier ID: " << f.supplierId << "\n";
        }
    }
    
    void displayAllSuppliers() {
        for (const auto& s : suppliers) {
            std::cout << "Supplier ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contactInfo << "\n";
        }
    }
};

int main() {
    InventorySystem inventory;
    inventory.addSupplier(1, "Supplier A", "123-456-7890");
    inventory.addSupplier(2, "Supplier B", "987-654-3210");
    inventory.addFurniture(1, "Chair", "Seating", 49.99, 1);
    inventory.addFurniture(2, "Table", "Dining", 149.99, 1);
    inventory.addFurniture(3, "Sofa", "Living Room", 399.99, 2);
    std::cout << "All Suppliers:\n";
    inventory.displayAllSuppliers();
    std::cout << "\nAll Furniture:\n";
    inventory.displayAllFurniture();
    std::cout << "\nSearch for 'Chair':\n";
    inventory.searchFurnitureByName("Chair");
    return 0;
}