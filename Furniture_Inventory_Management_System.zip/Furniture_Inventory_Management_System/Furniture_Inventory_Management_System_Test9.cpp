#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Supplier {
    int id;
    string name;
    string contact;
};

struct Furniture {
    int id;
    string name;
    float price;
    int supplierId;
};

class InventoryManagement {
private:
    vector<Furniture> furnitures;
    vector<Supplier> suppliers;

public:
    void addFurniture(int id, const string &name, float price, int supplierId) {
        furnitures.push_back({id, name, price, supplierId});
    }

    void deleteFurniture(int id) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->id == id) {
                furnitures.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, const string &name, float price, int supplierId) {
        for (auto &furniture : furnitures) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.price = price;
                furniture.supplierId = supplierId;
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto &furniture : furnitures) {
            if (furniture.id == id) {
                return &furniture;
            }
        }
        return nullptr;
    }

    void displayFurnitures() {
        for (const auto &furniture : furnitures) {
            cout << "Furniture ID: " << furniture.id 
                 << ", Name: " << furniture.name 
                 << ", Price: " << furniture.price 
                 << ", Supplier ID: " << furniture.supplierId << endl;
        }
    }

    void addSupplier(int id, const string &name, const string &contact) {
        suppliers.push_back({id, name, contact});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const string &name, const string &contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            cout << "Supplier ID: " << supplier.id 
                 << ", Name: " << supplier.name 
                 << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addFurniture(1, "Chair", 49.99, 101);
    inventory.addFurniture(2, "Table", 89.99, 102);
    inventory.addSupplier(101, "Supplier A", "123-456-7890");
    inventory.addSupplier(102, "Supplier B", "098-765-4321");
    inventory.displayFurnitures();
    inventory.displaySuppliers();
    return 0;
}