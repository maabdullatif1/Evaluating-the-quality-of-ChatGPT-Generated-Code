#include <iostream>
#include <vector>
#include <string>

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

struct Furniture {
    int id;
    std::string type;
    std::string material;
    double price;
    int supplierId;
};

class InventorySystem {
private:
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furnitureList;
    
    Supplier* findSupplierById(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) return &supplier;
        }
        return nullptr;
    }
    
    Furniture* findFurnitureById(int id) {
        for (auto &furniture : furnitureList) {
            if (furniture.id == id) return &furniture;
        }
        return nullptr;
    }

public:
    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back({id, name, contact});
    }
    
    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(),
                                       [&id](Supplier s) { return s.id == id; }),
                        suppliers.end());
    }
    
    void updateSupplier(int id, std::string name, std::string contact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }
    
    void searchSupplier(int id) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            std::cout << "Supplier ID: " << supplier->id << ", Name: " << supplier->name 
                      << ", Contact: " << supplier->contact << std::endl;
        } else {
            std::cout << "Supplier not found." << std::endl;
        }
    }
    
    void addFurniture(int id, std::string type, std::string material, double price, int supplierId) {
        furnitureList.push_back({id, type, material, price, supplierId});
    }
    
    void deleteFurniture(int id) {
        furnitureList.erase(std::remove_if(furnitureList.begin(), furnitureList.end(),
                                           [&id](Furniture f) { return f.id == id; }),
                            furnitureList.end());
    }
    
    void updateFurniture(int id, std::string type, std::string material, double price, int supplierId) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture) {
            furniture->type = type;
            furniture->material = material;
            furniture->price = price;
            furniture->supplierId = supplierId;
        }
    }
    
    void searchFurniture(int id) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture) {
            Supplier* supplier = findSupplierById(furniture->supplierId);
            std::cout << "Furniture ID: " << furniture->id << ", Type: " << furniture->type 
                      << ", Material: " << furniture->material << ", Price: " << furniture->price 
                      << ", Supplier Name: " << (supplier ? supplier->name : "Unknown") << std::endl;
        } else {
            std::cout << "Furniture not found." << std::endl;
        }
    }
    
    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
    
    void displayFurniture() {
        for (const auto &furniture : furnitureList) {
            Supplier* supplier = findSupplierById(furniture.supplierId);
            std::cout << "Furniture ID: " << furniture.id << ", Type: " << furniture.type 
                      << ", Material: " << furniture.material << ", Price: " << furniture.price 
                      << ", Supplier Name: " << (supplier ? supplier->name : "Unknown") << std::endl;
        }
    }
};

int main() {
    InventorySystem inventory;

    inventory.addSupplier(1, "ABC Supplies", "123-456-7890");
    inventory.addSupplier(2, "XYZ Furnishings", "987-654-3210");
    
    inventory.addFurniture(101, "Chair", "Wood", 49.99, 1);
    inventory.addFurniture(102, "Table", "Metal", 89.99, 2);
    
    std::cout << "Suppliers:\n";
    inventory.displaySuppliers();

    std::cout << "\nFurniture:\n";
    inventory.displayFurniture();

    inventory.searchSupplier(1);
    inventory.searchFurniture(101);

    return 0;
}