#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Supplier {
public:
    int id;
    string name;
    string contact;

    Supplier(int i, string n, string c) : id(i), name(n), contact(c) {}
};

class Furniture {
public:
    int id;
    string name;
    int quantity;
    Supplier supplier;

    Furniture(int i, string n, int q, Supplier s) : id(i), name(n), quantity(q), supplier(s) {}
};

class InventoryManagement {
private:
    vector<Furniture> furnitures;
    vector<Supplier> suppliers;

    Supplier* findSupplier(int id) {
        for (auto& s : suppliers) {
            if (s.id == id) return &s;
        }
        return nullptr;
    }

public:
    void addSupplier(int id, string name, string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void addFurniture(int id, string name, int quantity, int supplierId) {
        Supplier* supplier = findSupplier(supplierId);
        if (supplier) {
            furnitures.push_back(Furniture(id, name, quantity, *supplier));
        }
    }

    void deleteFurniture(int id) {
        for (size_t i = 0; i < furnitures.size(); ++i) {
            if (furnitures[i].id == id) {
                furnitures.erase(furnitures.begin() + i);
                break;
            }
        }
    }

    void updateFurniture(int id, string name, int quantity, int supplierId) {
        for (auto& f : furnitures) {
            if (f.id == id) {
                f.name = name;
                f.quantity = quantity;
                Supplier* supplier = findSupplier(supplierId);
                if (supplier) f.supplier = *supplier;
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto& f : furnitures) {
            if (f.id == id) return &f;
        }
        return nullptr;
    }

    Supplier* searchSupplier(int id) {
        for (auto& s : suppliers) {
            if (s.id == id) return &s;
        }
        return nullptr;
    }

    void displayFurniture() {
        for (auto& f : furnitures) {
            cout << "Furniture ID: " << f.id << ", Name: " << f.name << ", Quantity: " << f.quantity
                << ", Supplier: " << f.supplier.name << endl;
        }
    }

    void displaySuppliers() {
        for (auto& s : suppliers) {
            cout << "Supplier ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << endl;
        }
    }
};

int main() {
    InventoryManagement inv;

    inv.addSupplier(1, "Supplier A", "123-456-7890");
    inv.addSupplier(2, "Supplier B", "098-765-4321");

    inv.addFurniture(101, "Table", 10, 1);
    inv.addFurniture(102, "Chair", 20, 2);

    Furniture* f = inv.searchFurniture(101);
    if (f) {
        cout << "Found Furniture: " << f->name << endl;
    }

    inv.updateFurniture(101, "Large Table", 15, 1);
    inv.deleteFurniture(102);

    inv.displayFurniture();
    inv.displaySuppliers();

    return 0;
}