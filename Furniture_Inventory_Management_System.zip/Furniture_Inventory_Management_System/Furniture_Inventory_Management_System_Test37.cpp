#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Supplier {
public:
    string name;
    string contact;

    Supplier(string n, string c) : name(n), contact(c) {}
};

class Furniture {
public:
    string name;
    string type;
    int quantity;
    Supplier* supplier;

    Furniture(string n, string t, int q, Supplier* s) : name(n), type(t), quantity(q), supplier(s) {}
};

class Inventory {
private:
    vector<Furniture> furnitureList;
    vector<Supplier> supplierList;

public:
    void addSupplier(string name, string contact) {
        supplierList.push_back(Supplier(name, contact));
    }

    void addFurniture(string name, string type, int quantity, string supplierName) {
        for(Supplier& sup : supplierList) {
            if(sup.name == supplierName) {
                furnitureList.push_back(Furniture(name, type, quantity, &sup));
                return;
            }
        }
        cout << "Supplier not found.\n";
    }

    void deleteFurniture(string name) {
        for(auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if(it->name == name) {
                furnitureList.erase(it);
                cout << "Furniture deleted.\n";
                return;
            }
        }
        cout << "Furniture not found.\n";
    }

    void updateFurniture(string name, string type, int quantity) {
        for(Furniture& furn : furnitureList) {
            if(furn.name == name) {
                furn.type = type;
                furn.quantity = quantity;
                cout << "Furniture updated.\n";
                return;
            }
        }
        cout << "Furniture not found.\n";
    }

    void searchFurniture(string name) {
        for(Furniture& furn : furnitureList) {
            if(furn.name == name) {
                cout << "Found Furniture: " << furn.name << ", Type: " << furn.type << ", Quantity: " << furn.quantity 
                     << ", Supplier: " << furn.supplier->name << endl;
                return;
            }
        }
        cout << "Furniture not found.\n";
    }

    void displayAllFurniture() {
        for(Furniture& furn : furnitureList) {
            cout << "Furniture Name: " << furn.name << ", Type: " << furn.type << ", Quantity: " 
                 << furn.quantity << ", Supplier: " << furn.supplier->name << endl;
        }
    }

    void displayAllSuppliers() {
        for(Supplier& sup : supplierList) {
            cout << "Supplier Name: " << sup.name << ", Contact: " << sup.contact << endl;
        }
    }
};

int main() {
    Inventory inventory;

    inventory.addSupplier("Supplier1", "Contact1");
    inventory.addSupplier("Supplier2", "Contact2");

    inventory.addFurniture("Chair", "Office", 50, "Supplier1");
    inventory.addFurniture("Desk", "Home", 30, "Supplier1");
    inventory.addFurniture("Couch", "Living Room", 20, "Supplier2");

    inventory.displayAllFurniture();
    inventory.displayAllSuppliers();

    inventory.searchFurniture("Desk");

    inventory.updateFurniture("Desk", "Office", 25);
    inventory.displayAllFurniture();

    inventory.deleteFurniture("Chair");
    inventory.displayAllFurniture();

    return 0;
}