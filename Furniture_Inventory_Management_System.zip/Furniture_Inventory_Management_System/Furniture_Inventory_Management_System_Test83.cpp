#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Supplier {
public:
    int id;
    string name;
    Supplier(int id, string name) : id(id), name(name) {}
};

class Furniture {
public:
    int id;
    string name;
    double price;
    int supplierId;
    Furniture(int id, string name, double price, int supplierId)
        : id(id), name(name), price(price), supplierId(supplierId) {}
};

class Inventory {
private:
    vector<Furniture> furnitureList;
    vector<Supplier> supplierList;

public:
    void addFurniture(int id, string name, double price, int supplierId) {
        furnitureList.emplace_back(id, name, price, supplierId);
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, string name, double price, int supplierId) {
        for (auto &f : furnitureList) {
            if (f.id == id) {
                f.name = name;
                f.price = price;
                f.supplierId = supplierId;
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto &f : furnitureList) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayFurnitures() {
        cout << "Furniture List:\n";
        for (const auto &f : furnitureList) {
            cout << "ID: " << f.id << ", Name: " << f.name
                 << ", Price: " << f.price << ", Supplier ID: " << f.supplierId << endl;
        }
    }

    void addSupplier(int id, string name) {
        supplierList.emplace_back(id, name);
    }

    void deleteSupplier(int id) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->id == id) {
                supplierList.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name) {
        for (auto &s : supplierList) {
            if (s.id == id) {
                s.name = name;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &s : supplierList) {
            if (s.id == id) {
                return &s;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        cout << "Supplier List:\n";
        for (const auto &s : supplierList) {
            cout << "ID: " << s.id << ", Name: " << s.name << endl;
        }
    }
};

int main() {
    Inventory inventory;
    
    inventory.addSupplier(1, "Supplier A");
    inventory.addSupplier(2, "Supplier B");
    
    inventory.addFurniture(1, "Table", 120.50, 1);
    inventory.addFurniture(2, "Chair", 50.25, 2);

    inventory.displaySuppliers();
    cout << endl;
    inventory.displayFurnitures();
    
    return 0;
}