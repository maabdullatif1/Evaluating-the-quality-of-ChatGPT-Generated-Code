#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    int quantity;

    Furniture(int i, std::string n, std::string t, int q) : id(i), name(n), type(t), quantity(q) {}
};

class Supplier {
public:
    int id;
    std::string name;

    Supplier(int i, std::string n) : id(i), name(n) {}
};

class InventorySystem {
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

public:
    void addFurniture(int id, std::string name, std::string type, int quantity) {
        furnitureList.push_back(Furniture(id, name, type, quantity));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ) {
            if (it->id == id) {
                it = furnitureList.erase(it);
            } else {
                ++it;
            }
        }
    }

    void updateFurniture(int id, std::string name, std::string type, int quantity) {
        for (auto &f : furnitureList) {
            if (f.id == id) {
                f.name = name;
                f.type = type;
                f.quantity = quantity;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto &f : furnitureList) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayFurniture() {
        for (const auto &f : furnitureList) {
            std::cout << "Furniture ID: " << f.id << ", Name: " << f.name
                      << ", Type: " << f.type << ", Quantity: " << f.quantity << std::endl;
        }
    }

    void addSupplier(int id, std::string name) {
        supplierList.push_back(Supplier(id, name));
    }

    void deleteSupplier(int id) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ) {
            if (it->id == id) {
                it = supplierList.erase(it);
            } else {
                ++it;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &s : supplierList) {
            if (s.id == id) {
                return &s;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto &s : supplierList) {
            std::cout << "Supplier ID: " << s.id << ", Name: " << s.name << std::endl;
        }
    }
};

int main() {
    InventorySystem system;

    system.addFurniture(1, "Chair", "Seating", 10);
    system.addFurniture(2, "Table", "Dining", 5);
    system.addSupplier(1, "ABC Suppliers");

    system.displayFurniture();
    system.displaySuppliers();

    return 0;
}