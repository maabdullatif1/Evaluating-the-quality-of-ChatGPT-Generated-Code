#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int supplierId;
    std::string name;
    std::string address;
    std::string contactNumber;

    Supplier(int id, std::string n, std::string addr, std::string contact)
        : supplierId(id), name(n), address(addr), contactNumber(contact) {}
};

class Furniture {
public:
    int furnitureId;
    std::string name;
    std::string type;
    int quantity;
    double price;
    int supplierId;

    Furniture(int id, std::string n, std::string t, int q, double p, int sId)
        : furnitureId(id), name(n), type(t), quantity(q), price(p), supplierId(sId) {}
};

class Inventory {
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

public:
    void addFurniture(int id, std::string name, std::string type, int quantity, double price, int supplierId) {
        furnitureList.push_back(Furniture(id, name, type, quantity, price, supplierId));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->furnitureId == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, std::string name, std::string type, int quantity, double price, int supplierId) {
        for (auto& furniture : furnitureList) {
            if (furniture.furnitureId == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.quantity = quantity;
                furniture.price = price;
                furniture.supplierId = supplierId;
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto& furniture : furnitureList) {
            if (furniture.furnitureId == id) {
                return &furniture;
            }
        }
        return nullptr;
    }

    void displayFurniture() {
        for (const auto& furniture : furnitureList) {
            std::cout << "ID: " << furniture.furnitureId << " Name: " << furniture.name
                      << " Type: " << furniture.type << " Quantity: " << furniture.quantity
                      << " Price: " << furniture.price << " Supplier ID: " << furniture.supplierId << "\n";
        }
    }

    void addSupplier(int id, std::string name, std::string address, std::string contactNumber) {
        supplierList.push_back(Supplier(id, name, address, contactNumber));
    }

    void deleteSupplier(int id) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->supplierId == id) {
                supplierList.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string address, std::string contactNumber) {
        for (auto& supplier : supplierList) {
            if (supplier.supplierId == id) {
                supplier.name = name;
                supplier.address = address;
                supplier.contactNumber = contactNumber;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : supplierList) {
            if (supplier.supplierId == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : supplierList) {
            std::cout << "ID: " << supplier.supplierId << " Name: " << supplier.name
                      << " Address: " << supplier.address << " Contact: " << supplier.contactNumber << "\n";
        }
    }
};

int main() {
    Inventory inventory;

    inventory.addSupplier(1, "ABC Furniture", "123 Street", "1234567890");
    inventory.addSupplier(2, "XYZ Furnishings", "456 Road", "0987654321");

    inventory.addFurniture(101, "Chair", "Seating", 5, 49.99, 1);
    inventory.addFurniture(102, "Table", "Dining", 3, 199.99, 2);

    inventory.displaySuppliers();
    std::cout << "\n";
    inventory.displayFurniture();

    return 0;
}