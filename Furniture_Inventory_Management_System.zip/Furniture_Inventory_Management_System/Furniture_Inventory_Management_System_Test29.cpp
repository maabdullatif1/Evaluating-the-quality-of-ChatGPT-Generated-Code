#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    std::string name;
    std::string type;
    int quantity;

    Furniture(std::string n, std::string t, int q) : name(n), type(t), quantity(q) {}
};

class Supplier {
public:
    std::string name;
    std::string contact;

    Supplier(std::string n, std::string c) : name(n), contact(c) {}
};

class FurnitureInventory {
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

public:
    void addFurniture(std::string name, std::string type, int quantity) {
        furnitureList.push_back(Furniture(name, type, quantity));
    }

    void deleteFurniture(std::string name) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->name == name) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(std::string name, int quantity) {
        for (auto& furniture : furnitureList) {
            if (furniture.name == name) {
                furniture.quantity = quantity;
                break;
            }
        }
    }

    void searchFurniture(std::string name) {
        for (auto& furniture : furnitureList) {
            if (furniture.name == name) {
                std::cout << "Furniture: " << furniture.name 
                          << ", Type: " << furniture.type 
                          << ", Quantity: " << furniture.quantity << std::endl;
                return;
            }
        }
        std::cout << "Furniture not found." << std::endl;
    }

    void displayFurniture() {
        for (auto& furniture : furnitureList) {
            std::cout << "Furniture: " << furniture.name 
                      << ", Type: " << furniture.type 
                      << ", Quantity: " << furniture.quantity << std::endl;
        }
    }

    void addSupplier(std::string name, std::string contact) {
        supplierList.push_back(Supplier(name, contact));
    }

    void deleteSupplier(std::string name) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->name == name) {
                supplierList.erase(it);
                break;
            }
        }
    }

    void searchSupplier(std::string name) {
        for (auto& supplier : supplierList) {
            if (supplier.name == name) {
                std::cout << "Supplier: " << supplier.name 
                          << ", Contact: " << supplier.contact << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found." << std::endl;
    }

    void displaySuppliers() {
        for (auto& supplier : supplierList) {
            std::cout << "Supplier: " << supplier.name 
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    FurnitureInventory inventory;
    inventory.addFurniture("Chair", "Seating", 10);
    inventory.addFurniture("Table", "Surface", 5);
    inventory.addSupplier("FurnitureMart", "123-456-789");
    inventory.addSupplier("WoodWorks", "987-654-321");

    inventory.displayFurniture();
    inventory.displaySuppliers();

    inventory.searchFurniture("Chair");
    inventory.updateFurniture("Chair", 15);
    inventory.searchFurniture("Chair");

    inventory.deleteFurniture("Table");
    inventory.displayFurniture();

    inventory.searchSupplier("WoodWorks");
    inventory.deleteSupplier("WoodWorks");
    inventory.displaySuppliers();

    return 0;
}