#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    int quantity;
    double price;

    Furniture(int id, std::string name, std::string type, int quantity, double price)
        : id(id), name(name), type(type), quantity(quantity), price(price) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class InventoryManagementSystem {
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

public:
    void addFurniture(int id, std::string name, std::string type, int quantity, double price) {
        furnitureList.push_back(Furniture(id, name, type, quantity, price));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, std::string name, std::string type, int quantity, double price) {
        for (auto &furniture : furnitureList) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.quantity = quantity;
                furniture.price = price;
                break;
            }
        }
    }

    void searchFurniture(int id) {
        for (const auto &furniture : furnitureList) {
            if (furniture.id == id) {
                std::cout << "Furniture ID: " << furniture.id << "\nName: " << furniture.name 
                          << "\nType: " << furniture.type << "\nQuantity: " << furniture.quantity 
                          << "\nPrice: " << furniture.price << std::endl;
                return;
            }
        }
        std::cout << "Furniture not found." << std::endl;
    }

    void displayAllFurniture() {
        for (const auto &furniture : furnitureList) {
            std::cout << "ID: " << furniture.id << ", Name: " << furniture.name 
                      << ", Type: " << furniture.type << ", Quantity: " << furniture.quantity 
                      << ", Price: " << furniture.price << std::endl;
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        supplierList.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->id == id) {
                supplierList.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto &supplier : supplierList) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto &supplier : supplierList) {
            if (supplier.id == id) {
                std::cout << "Supplier ID: " << supplier.id << "\nName: " << supplier.name 
                          << "\nContact: " << supplier.contact << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found." << std::endl;
    }

    void displayAllSuppliers() {
        for (const auto &supplier : supplierList) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addFurniture(1, "Chair", "Office", 50, 49.99);
    ims.addFurniture(2, "Table", "Dining", 30, 99.99);
    
    ims.addSupplier(1, "Supplier A", "123-456-7890");
    ims.addSupplier(2, "Supplier B", "098-765-4321");

    ims.displayAllFurniture();
    ims.displayAllSuppliers();

    ims.searchFurniture(1);
    ims.searchSupplier(2);

    ims.updateFurniture(1, "Chair", "Lounge", 40, 59.99);
    ims.updateSupplier(1, "Supplier A", "111-222-3333");

    ims.displayAllFurniture();
    ims.displayAllSuppliers();

    ims.deleteFurniture(2);
    ims.deleteSupplier(2);

    ims.displayAllFurniture();
    ims.displayAllSuppliers();

    return 0;
}