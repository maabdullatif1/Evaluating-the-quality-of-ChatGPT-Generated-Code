#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    int id;
    std::string name;
    int quantity;
    double price;
    
    Furniture(int id, const std::string& name, int quantity, double price)
        : id(id), name(name), quantity(quantity), price(price) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    
    Supplier(int id, const std::string& name, const std::string& contact)
        : id(id), name(name), contact(contact) {}
};

class InventoryManagementSystem {
private:
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

    template<typename T>
    bool removeById(std::vector<T>& list, int id) {
        for (auto it = list.begin(); it != list.end(); ++it) {
            if (it->id == id) {
                list.erase(it);
                return true;
            }
        }
        return false;
    }

public:
    void addFurniture(const Furniture& furniture) {
        furnitureList.push_back(furniture);
    }

    void deleteFurniture(int id) {
        if (!removeById(furnitureList, id)) {
            std::cout << "Furniture with id " << id << " not found.\n";
        }
    }

    void updateFurniture(int id, const std::string& name, int quantity, double price) {
        for (auto& f : furnitureList) {
            if (f.id == id) {
                f.name = name;
                f.quantity = quantity;
                f.price = price;
                return;
            }
        }
        std::cout << "Furniture with id " << id << " not found.\n";
    }

    void searchFurniture(int id) {
        for (const auto& f : furnitureList) {
            if (f.id == id) {
                std::cout << "Furniture ID: " << f.id << ", Name: " << f.name << ", Quantity: " << f.quantity << ", Price: " << f.price << "\n";
                return;
            }
        }
        std::cout << "Furniture with id " << id << " not found.\n";
    }

    void displayFurniture() {
        for (const auto& f : furnitureList) {
            std::cout << "Furniture ID: " << f.id << ", Name: " << f.name << ", Quantity: " << f.quantity << ", Price: " << f.price << "\n";
        }
    }

    void addSupplier(const Supplier& supplier) {
        supplierList.push_back(supplier);
    }

    void deleteSupplier(int id) {
        if (!removeById(supplierList, id)) {
            std::cout << "Supplier with id " << id << " not found.\n";
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& s : supplierList) {
            if (s.id == id) {
                s.name = name;
                s.contact = contact;
                return;
            }
        }
        std::cout << "Supplier with id " << id << " not found.\n";
    }

    void searchSupplier(int id) {
        for (const auto& s : supplierList) {
            if (s.id == id) {
                std::cout << "Supplier ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << "\n";
                return;
            }
        }
        std::cout << "Supplier with id " << id << " not found.\n";
    }

    void displaySuppliers() {
        for (const auto& s : supplierList) {
            std::cout << "Supplier ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << "\n";
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addFurniture(Furniture(1, "Chair", 10, 99.99));
    ims.addSupplier(Supplier(1, "ABC Corp.", "abc@example.com"));

    ims.displayFurniture();
    ims.displaySuppliers();

    ims.updateFurniture(1, "Office Chair", 15, 109.99);
    ims.updateSupplier(1, "XYZ Corp.", "xyz@example.com");

    ims.searchFurniture(1);
    ims.searchSupplier(1);

    ims.deleteFurniture(1);
    ims.deleteSupplier(1);

    ims.displayFurniture();
    ims.displaySuppliers();

    return 0;
}