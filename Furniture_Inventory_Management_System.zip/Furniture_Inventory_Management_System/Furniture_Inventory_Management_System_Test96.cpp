#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    std::string name;
    std::string contact;

    Supplier(std::string n, std::string c) : name(n), contact(c) {}
};

class Furniture {
public:
    std::string name;
    std::string type;
    int quantity;
    double price;
    Supplier supplier;

    Furniture(std::string n, std::string t, int q, double p, Supplier s) 
        : name(n), type(t), quantity(q), price(p), supplier(s) {}
};

class Inventory {
private:
    std::vector<Furniture> furnitures;

public:
    void addFurniture(const std::string& name, const std::string& type, int quantity, double price, const Supplier& supplier) {
        furnitures.push_back(Furniture(name, type, quantity, price, supplier));
    }

    void deleteFurniture(const std::string& name) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->name == name) {
                furnitures.erase(it);
                return;
            }
        }
        std::cout << "Furniture not found.\n";
    }

    void updateFurniture(const std::string& name, const std::string& type, int quantity, double price, const Supplier& supplier) {
        for (auto& furniture : furnitures) {
            if (furniture.name == name) {
                furniture.type = type;
                furniture.quantity = quantity;
                furniture.price = price;
                furniture.supplier = supplier;
                return;
            }
        }
        std::cout << "Furniture not found.\n";
    }

    void searchFurniture(const std::string& name) {
        for (const auto& furniture : furnitures) {
            if (furniture.name == name) {
                std::cout << "Furniture found: " << furniture.name
                          << ", Type: " << furniture.type
                          << ", Quantity: " << furniture.quantity
                          << ", Price: " << furniture.price
                          << ", Supplier: " << furniture.supplier.name
                          << ", Contact: " << furniture.supplier.contact << "\n";
                return;
            }
        }
        std::cout << "Furniture not found.\n";
    }

    void displayInventory() {
        for (const auto& furniture : furnitures) {
            std::cout << "Furniture: " << furniture.name
                      << ", Type: " << furniture.type
                      << ", Quantity: " << furniture.quantity
                      << ", Price: " << furniture.price
                      << ", Supplier: " << furniture.supplier.name
                      << ", Contact: " << furniture.supplier.contact << "\n";
        }
    }
};

int main() {
    Inventory inventory;
    Supplier supplier1("ABC Furnishings", "123-456-7890");
    Supplier supplier2("XYZ Interiors", "098-765-4321");

    inventory.addFurniture("Chair", "Wooden", 20, 50.0, supplier1);
    inventory.addFurniture("Table", "Glass", 15, 200.0, supplier2);

    inventory.displayInventory();

    inventory.searchFurniture("Chair");

    inventory.updateFurniture("Table", "Glass", 10, 180.0, supplier1);
    
    inventory.displayInventory();

    inventory.deleteFurniture("Chair");

    inventory.displayInventory();

    return 0;
}