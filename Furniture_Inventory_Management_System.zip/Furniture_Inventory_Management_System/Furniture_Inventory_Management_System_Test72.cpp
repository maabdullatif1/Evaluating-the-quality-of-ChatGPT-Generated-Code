#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Supplier {
public:
    int id;
    string name;
    string contact;
    
    Supplier(int id, string name, string contact) : id(id), name(name), contact(contact) {}
};

class Furniture {
public:
    int id;
    string name;
    string type;
    int supplier_id;
    int quantity;
    
    Furniture(int id, string name, string type, int supplier_id, int quantity)
    : id(id), name(name), type(type), supplier_id(supplier_id), quantity(quantity) {}
};

class InventoryManagementSystem {
private:
    vector<Supplier> suppliers;
    vector<Furniture> furniture;
    
public:
    void addSupplier(int id, string name, string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }
    
    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                return;
            }
        }
    }
    
    void updateSupplier(int id, string name, string contact) {
        for (auto &supp : suppliers) {
            if (supp.id == id) {
                supp.name = name;
                supp.contact = contact;
                return;
            }
        }
    }
    
    bool searchSupplier(int id) {
        for (auto &supp : suppliers) {
            if (supp.id == id) {
                cout << "Supplier ID: " << supp.id << ", Name: " << supp.name << ", Contact: " << supp.contact << endl;
                return true;
            }
        }
        return false;
    }
    
    void displaySuppliers() {
        for (auto &supp : suppliers) {
            cout << "Supplier ID: " << supp.id << ", Name: " << supp.name << ", Contact: " << supp.contact << endl;
        }
    }
    
    void addFurniture(int id, string name, string type, int supplier_id, int quantity) {
        furniture.push_back(Furniture(id, name, type, supplier_id, quantity));
    }
    
    void deleteFurniture(int id) {
        for (auto it = furniture.begin(); it != furniture.end(); ++it) {
            if (it->id == id) {
                furniture.erase(it);
                return;
            }
        }
    }
    
    void updateFurniture(int id, string name, string type, int supplier_id, int quantity) {
        for (auto &furn : furniture) {
            if (furn.id == id) {
                furn.name = name;
                furn.type = type;
                furn.supplier_id = supplier_id;
                furn.quantity = quantity;
                return;
            }
        }
    }
    
    bool searchFurniture(int id) {
        for (auto &furn : furniture) {
            if (furn.id == id) {
                cout << "Furniture ID: " << furn.id << ", Name: " << furn.name << ", Type: " << furn.type
                     << ", Supplier ID: " << furn.supplier_id << ", Quantity: " << furn.quantity << endl;
                return true;
            }
        }
        return false;
    }
    
    void displayFurniture() {
        for (auto &furn : furniture) {
            cout << "Furniture ID: " << furn.id << ", Name: " << furn.name << ", Type: " << furn.type
                 << ", Supplier ID: " << furn.supplier_id << ", Quantity: " << furn.quantity << endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier(1, "SupplierA", "123-456-7890");
    ims.addFurniture(1, "Chair", "Seating", 1, 50);
    ims.addFurniture(2, "Table", "Dining", 1, 20);
    
    ims.displaySuppliers();
    ims.displayFurniture();
    
    ims.updateFurniture(1, "Office Chair", "Seating", 1, 45);
    ims.displayFurniture();
    
    ims.searchSupplier(1);
    ims.searchFurniture(2);
    
    ims.deleteFurniture(2);
    ims.displayFurniture();
    
    return 0;
}