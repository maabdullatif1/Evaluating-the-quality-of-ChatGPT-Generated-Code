#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    int quantity;
    Furniture(int id, std::string name, std::string type, int quantity)
        : id(id), name(name), type(type), quantity(quantity) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    Supplier(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class InventorySystem {
private:
    std::vector<Furniture> furnitureInventory;
    std::vector<Supplier> suppliers;
    
    Furniture* findFurnitureById(int id) {
        for (auto& furniture : furnitureInventory) {
            if (furniture.id == id) return &furniture;
        }
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) return &supplier;
        }
        return nullptr;
    }

public:
    void addFurniture(int id, std::string name, std::string type, int quantity) {
        furnitureInventory.push_back(Furniture(id, name, type, quantity));
    }

    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteFurniture(int id) {
        furnitureInventory.erase(std::remove_if(furnitureInventory.begin(), furnitureInventory.end(),
            [&](Furniture& f) { return f.id == id; }), furnitureInventory.end());
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(),
            [&](Supplier& s) { return s.id == id; }), suppliers.end());
    }

    void updateFurniture(int id, std::string name, std::string type, int quantity) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture) {
            furniture->name = name;
            furniture->type = type;
            furniture->quantity = quantity;
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void searchFurniture(int id) {
        Furniture* furniture = findFurnitureById(id);
        if (furniture) {
            std::cout << "ID: " << furniture->id << ", Name: " << furniture->name
                      << ", Type: " << furniture->type << ", Quantity: " << furniture->quantity << std::endl;
        } else {
            std::cout << "Furniture not found." << std::endl;
        }
    }

    void searchSupplier(int id) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            std::cout << "ID: " << supplier->id << ", Name: " << supplier->name
                      << ", Contact: " << supplier->contact << std::endl;
        } else {
            std::cout << "Supplier not found." << std::endl;
        }
    }

    void displayFurniture() {
        for (const auto& furniture : furnitureInventory) {
            std::cout << "ID: " << furniture.id << ", Name: " << furniture.name
                      << ", Type: " << furniture.type << ", Quantity: " << furniture.quantity << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addFurniture(1, "Chair", "Office", 100);
    system.addSupplier(1, "Supplier A", "123-456-7890");
    system.displayFurniture();
    system.displaySuppliers();
    system.searchFurniture(1);
    system.updateFurniture(1, "Chair", "Office", 150);
    system.searchFurniture(1);
    system.deleteFurniture(1);
    system.displayFurniture();
    return 0;
}