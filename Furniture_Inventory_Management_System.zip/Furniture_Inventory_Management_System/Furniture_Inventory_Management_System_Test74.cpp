#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Supplier {
public:
    int id;
    string name;
    string contact;
    Supplier(int i, string n, string c) : id(i), name(n), contact(c) {}
};

class Furniture {
public:
    int id;
    string name;
    string type;
    int quantity;
    int supplierId;
    Furniture(int i, string n, string t, int q, int s) : id(i), name(n), type(t), quantity(q), supplierId(s) {}
};

class InventoryManagementSystem {
    vector<Supplier> suppliers;
    vector<Furniture> furnitureItems;

public:
    void addSupplier(int id, string name, string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto &supplier : suppliers) {
            if (supplier.id == id) {
                cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
                return;
            }
        }
        cout << "Supplier not found" << endl;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }

    void addFurniture(int id, string name, string type, int quantity, int supplierId) {
        furnitureItems.push_back(Furniture(id, name, type, quantity, supplierId));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureItems.begin(); it != furnitureItems.end(); ++it) {
            if (it->id == id) {
                furnitureItems.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, string name, string type, int quantity, int supplierId) {
        for (auto &furniture : furnitureItems) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.quantity = quantity;
                furniture.supplierId = supplierId;
                break;
            }
        }
    }

    void searchFurniture(int id) {
        for (const auto &furniture : furnitureItems) {
            if (furniture.id == id) {
                cout << "Furniture ID: " << furniture.id << ", Name: " << furniture.name << ", Type: " << furniture.type << ", Quantity: " << furniture.quantity << ", Supplier ID: " << furniture.supplierId << endl;
                return;
            }
        }
        cout << "Furniture not found" << endl;
    }

    void displayFurniture() {
        for (const auto &furniture : furnitureItems) {
            cout << "Furniture ID: " << furniture.id << ", Name: " << furniture.name << ", Type: " << furniture.type << ", Quantity: " << furniture.quantity << ", Supplier ID: " << furniture.supplierId << endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier(1, "Supplier1", "Contact1");
    ims.addFurniture(1, "Chair", "Seating", 20, 1);
    ims.displaySuppliers();
    ims.displayFurniture();
    ims.searchSupplier(1);
    ims.searchFurniture(1);
    ims.updateSupplier(1, "UpdatedSupplier1", "UpdatedContact1");
    ims.updateFurniture(1, "UpdatedChair", "UpdatedSeating", 25, 1);
    ims.displaySuppliers();
    ims.displayFurniture();
    ims.deleteSupplier(1);
    ims.deleteFurniture(1);
    ims.displaySuppliers();
    ims.displayFurniture();
    return 0;
}