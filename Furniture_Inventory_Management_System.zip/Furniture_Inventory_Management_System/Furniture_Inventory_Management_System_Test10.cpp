#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    
    Supplier(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    double price;
    Supplier* supplier;
    
    Furniture(int id, std::string name, std::string type, double price, Supplier* supplier)
        : id(id), name(name), type(type), price(price), supplier(supplier) {}
};

class Inventory {
private:
    std::vector<Furniture> furnitures;
    std::vector<Supplier> suppliers;
    
    Furniture* searchFurnitureById(int id) {
        for (auto& furniture : furnitures) {
            if (furniture.id == id) {
                return &furniture;
            }
        }
        return nullptr;
    }
    
    Supplier* searchSupplierById(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

public:
    void addFurniture(int id, std::string name, std::string type, double price, int supplierId) {
        Supplier* supplier = searchSupplierById(supplierId);
        if (supplier != nullptr) {
            furnitures.push_back(Furniture(id, name, type, price, supplier));
        }
    }
    
    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }
    
    void deleteFurniture(int id) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->id == id) {
                furnitures.erase(it);
                break;
            }
        }
    }
    
    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }
    
    void updateFurniture(int id, std::string name, std::string type, double price, int supplierId) {
        Furniture* furniture = searchFurnitureById(id);
        if (furniture != nullptr) {
            furniture->name = name;
            furniture->type = type;
            furniture->price = price;
            Supplier* supplier = searchSupplierById(supplierId);
            if (supplier != nullptr) {
                furniture->supplier = supplier;
            }
        }
    }
    
    void updateSupplier(int id, std::string name, std::string contact) {
        Supplier* supplier = searchSupplierById(id);
        if (supplier != nullptr) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }
    
    void searchAndDisplayFurniture(int id) {
        Furniture* furniture = searchFurnitureById(id);
        if (furniture != nullptr) {
            std::cout << "Furniture ID: " << furniture->id << std::endl;
            std::cout << "Name: " << furniture->name << std::endl;
            std::cout << "Type: " << furniture->type << std::endl;
            std::cout << "Price: $" << furniture->price << std::endl;
            std::cout << "Supplier: " << furniture->supplier->name << std::endl;
        } else {
            std::cout << "Furniture not found." << std::endl;
        }
    }
    
    void searchAndDisplaySupplier(int id) {
        Supplier* supplier = searchSupplierById(id);
        if (supplier != nullptr) {
            std::cout << "Supplier ID: " << supplier->id << std::endl;
            std::cout << "Name: " << supplier->name << std::endl;
            std::cout << "Contact: " << supplier->contact << std::endl;
        } else {
            std::cout << "Supplier not found." << std::endl;
        }
    }
    
    void displayAllFurniture() {
        for (const auto& furniture : furnitures) {
            std::cout << "Furniture ID: " << furniture.id << " Name: " << furniture.name << " Type: " << furniture.type << " Price: $" << furniture.price << " Supplier: " << furniture.supplier->name << std::endl;
        }
    }
    
    void displayAllSuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << " Name: " << supplier.name << " Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addSupplier(1, "Supplier A", "1234567890");
    inventory.addFurniture(101, "Chair", "Office", 49.99, 1);
    inventory.searchAndDisplayFurniture(101);
    inventory.displayAllSuppliers();
    inventory.updateFurniture(101, "Luxury Chair", "Office", 99.99, 1);
    inventory.searchAndDisplayFurniture(101);
    inventory.deleteFurniture(101);
    inventory.searchAndDisplayFurniture(101);
    return 0;
}