#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    int quantity;
    Furniture(int id, std::string name, std::string type, int quantity)
        : id(id), name(name), type(type), quantity(quantity) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    Supplier(int id, std::string name, std::string contact)
        : id(id), name(name), contact(contact) {}
};

class InventoryManagement {
private:
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

    Furniture* findFurniture(int id) {
        for (auto& item : furnitureList) {
            if (item.id == id) return &item;
        }
        return nullptr;
    }

    Supplier* findSupplier(int id) {
        for (auto& supplier : supplierList) {
            if (supplier.id == id) return &supplier;
        }
        return nullptr;
    }

public:
    void addFurniture(int id, std::string name, std::string type, int quantity) {
        furnitureList.push_back(Furniture(id, name, type, quantity));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, std::string name, std::string type, int quantity) {
        Furniture* item = findFurniture(id);
        if (item) {
            item->name = name;
            item->type = type;
            item->quantity = quantity;
        }
    }

    void searchFurniture(int id) {
        Furniture* item = findFurniture(id);
        if (item) {
            std::cout << "Furniture ID: " << item->id << ", Name: " << item->name 
                      << ", Type: " << item->type << ", Quantity: " << item->quantity << std::endl;
        } else {
            std::cout << "Furniture not found." << std::endl;
        }
    }

    void displayFurniture() {
        for (const auto& item : furnitureList) {
            std::cout << "ID: " << item.id << ", Name: " << item.name 
                      << ", Type: " << item.type << ", Quantity: " << item.quantity << std::endl;
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        supplierList.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->id == id) {
                supplierList.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        Supplier* supplier = findSupplier(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void searchSupplier(int id) {
        Supplier* supplier = findSupplier(id);
        if (supplier) {
            std::cout << "Supplier ID: " << supplier->id << ", Name: " << supplier->name 
                      << ", Contact: " << supplier->contact << std::endl;
        } else {
            std::cout << "Supplier not found." << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : supplierList) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagement inventory;

    inventory.addFurniture(1, "Chair", "Seating", 50);
    inventory.addFurniture(2, "Table", "Dining", 20);

    inventory.addSupplier(1, "Supplies Inc.", "123456789");
    inventory.addSupplier(2, "Furniture Co.", "987654321");

    inventory.displayFurniture();
    inventory.displaySuppliers();

    inventory.searchFurniture(1);
    inventory.searchSupplier(2);

    inventory.updateFurniture(1, "Arm Chair", "Seating", 40);
    inventory.deleteSupplier(1);

    inventory.displayFurniture();
    inventory.displaySuppliers();

    return 0;
}