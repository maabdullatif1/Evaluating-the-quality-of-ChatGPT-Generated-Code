#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    std::string name;
    std::string type;
    double price;
    int quantity;
    
    Furniture(std::string n, std::string t, double p, int q) 
        : name(n), type(t), price(p), quantity(q) {}
};

class Supplier {
public:
    std::string name;
    std::string contact;
    
    Supplier(std::string n, std::string c) 
        : name(n), contact(c) {}
};

class InventoryManagement {
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

public:
    void addFurniture(std::string name, std::string type, double price, int quantity) {
        furnitureList.push_back(Furniture(name, type, price, quantity));
    }

    void deleteFurniture(std::string name) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->name == name) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(std::string name, std::string type, double price, int quantity) {
        for (auto& furn : furnitureList) {
            if (furn.name == name) {
                furn.type = type;
                furn.price = price;
                furn.quantity = quantity;
                break;
            }
        }
    }

    Furniture* searchFurniture(std::string name) {
        for (auto& furn : furnitureList) {
            if (furn.name == name) {
                return &furn;
            }
        }
        return nullptr;
    }

    void displayFurniture() {
        for (const auto& furn : furnitureList) {
            std::cout << "Name: " << furn.name << ", Type: " << furn.type 
                      << ", Price: " << furn.price << ", Quantity: " << furn.quantity << std::endl;
        }
    }

    void addSupplier(std::string name, std::string contact) {
        supplierList.push_back(Supplier(name, contact));
    }

    void deleteSupplier(std::string name) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->name == name) {
                supplierList.erase(it);
                break;
            }
        }
    }

    Supplier* searchSupplier(std::string name) {
        for (auto& supplier : supplierList) {
            if (supplier.name == name) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : supplierList) {
            std::cout << "Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagement system;
    system.addFurniture("Chair", "Seating", 49.99, 20);
    system.addFurniture("Table", "Dining", 150.00, 10);
    system.displayFurniture();
    
    system.addSupplier("WoodWorks", "111-222-3333");
    system.addSupplier("FurnitureCo", "444-555-6666");
    system.displaySuppliers();

    if(Furniture* f = system.searchFurniture("Table")) {
        std::cout << "Found furniture: " << f->name << std::endl;
    }
    
    system.updateFurniture("Chair", "Office Seating", 45.00, 15);
    system.displayFurniture();

    system.deleteFurniture("Table");
    system.displayFurniture();

    if(Supplier* s = system.searchSupplier("WoodWorks")) {
        std::cout << "Found supplier: " << s->name << std::endl;
    }
    
    system.deleteSupplier("FurnitureCo");
    system.displaySuppliers();

    return 0;
}