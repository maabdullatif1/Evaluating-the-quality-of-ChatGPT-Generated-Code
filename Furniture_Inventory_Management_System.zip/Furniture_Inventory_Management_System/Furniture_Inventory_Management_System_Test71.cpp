#include <iostream>
#include <vector>
#include <string>

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

struct Furniture {
    int id;
    std::string name;
    std::string type;
    double price;
    int supplierId;
};

class InventoryManagement {
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furnitureItems;

public:
    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.push_back({id, name, contact});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) return &supplier;
        }
        return nullptr;
    }

    void addFurniture(int id, const std::string& name, const std::string& type, double price, int supplierId) {
        furnitureItems.push_back({id, name, type, price, supplierId});
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureItems.begin(); it != furnitureItems.end(); ++it) {
            if (it->id == id) {
                furnitureItems.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, const std::string& name, const std::string& type, double price, int supplierId) {
        for (auto& furniture : furnitureItems) {
            if (furniture.id == id) {
                furniture.name = name;
                furniture.type = type;
                furniture.price = price;
                furniture.supplierId = supplierId;
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto& furniture : furnitureItems) {
            if (furniture.id == id) return &furniture;
        }
        return nullptr;
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }

    void displayFurniture() const {
        for (const auto& furniture : furnitureItems) {
            std::cout << "ID: " << furniture.id << ", Name: " << furniture.name
                      << ", Type: " << furniture.type << ", Price: " << furniture.price
                      << ", Supplier ID: " << furniture.supplierId << std::endl;
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addSupplier(1, "ABC Supplies", "123-456-7890");
    inventory.addSupplier(2, "XYZ Furnishings", "098-765-4321");
    inventory.addFurniture(1, "Chair", "Office", 49.99, 1);
    inventory.addFurniture(2, "Desk", "Office", 129.99, 2);

    inventory.displaySuppliers();
    inventory.displayFurniture();

    return 0;
}