#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    Supplier(int id, std::string name, std::string contact) : id(id), name(name), contact(contact) {}
};

class Furniture {
public:
    int id;
    std::string name;
    double price;
    int supplierId;
    Furniture(int id, std::string name, double price, int supplierId) : id(id), name(name), price(price), supplierId(supplierId) {}
};

class Inventory {
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furnitures;

public:
    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, std::string newName, std::string newContact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = newName;
                supplier.contact = newContact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }

    void addFurniture(int id, std::string name, double price, int supplierId) {
        furnitures.push_back(Furniture(id, name, price, supplierId));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitures.begin(); it != furnitures.end(); ++it) {
            if (it->id == id) {
                furnitures.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, std::string newName, double newPrice, int newSupplierId) {
        for (auto &furniture : furnitures) {
            if (furniture.id == id) {
                furniture.name = newName;
                furniture.price = newPrice;
                furniture.supplierId = newSupplierId;
                break;
            }
        }
    }

    Furniture* searchFurniture(int id) {
        for (auto &furniture : furnitures) {
            if (furniture.id == id) {
                return &furniture;
            }
        }
        return nullptr;
    }

    void displayFurnitures() {
        for (const auto &furniture : furnitures) {
            std::cout << "ID: " << furniture.id << ", Name: " << furniture.name
                      << ", Price: " << furniture.price << ", Supplier ID: " << furniture.supplierId << std::endl;
        }
    }
};

int main() {
    Inventory inventory;

    inventory.addSupplier(1, "Supplier A", "123-456-7890");
    inventory.addFurniture(101, "Chair", 49.99, 1);
    inventory.displaySuppliers();
    inventory.displayFurnitures();

    inventory.updateSupplier(1, "Supplier AA", "098-765-4321");
    inventory.updateFurniture(101, "Arm Chair", 59.99, 1);
    inventory.displaySuppliers();
    inventory.displayFurnitures();

    Supplier* supplier = inventory.searchSupplier(1);
    if (supplier) std::cout << "Found Supplier: " << supplier->name << std::endl;

    Furniture* furniture = inventory.searchFurniture(101);
    if (furniture) std::cout << "Found Furniture: " << furniture->name << std::endl;

    inventory.deleteSupplier(1);
    inventory.deleteFurniture(101);
    inventory.displaySuppliers();
    inventory.displayFurnitures();

    return 0;
}