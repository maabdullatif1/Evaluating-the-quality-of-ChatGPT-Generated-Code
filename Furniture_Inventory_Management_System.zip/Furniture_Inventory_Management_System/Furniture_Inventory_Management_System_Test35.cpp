#include <iostream>
#include <vector>
#include <string>

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    int quantity;

    Furniture(int i, std::string n, std::string t, int q) : id(i), name(n), type(t), quantity(q) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInfo;

    Supplier(int i, std::string n, std::string c) : id(i), name(n), contactInfo(c) {}
};

class InventorySystem {
private:
    std::vector<Furniture> furnitureList;
    std::vector<Supplier> supplierList;

public:
    void addFurniture(int id, std::string name, std::string type, int quantity) {
        furnitureList.push_back(Furniture(id, name, type, quantity));
    }

    void deleteFurniture(int id) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if (it->id == id) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void updateFurniture(int id, std::string name, std::string type, int quantity) {
        for (auto &f : furnitureList) {
            if (f.id == id) {
                f.name = name;
                f.type = type;
                f.quantity = quantity;
                break;
            }
        }
    }

    void searchFurniture(int id) {
        for (const auto &f : furnitureList) {
            if (f.id == id) {
                std::cout << "Furniture ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type << ", Quantity: " << f.quantity << std::endl;
                return;
            }
        }
        std::cout << "Furniture not found." << std::endl;
    }

    void displayFurniture() {
        for (const auto &f : furnitureList) {
            std::cout << "Furniture ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type << ", Quantity: " << f.quantity << std::endl;
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        supplierList.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = supplierList.begin(); it != supplierList.end(); ++it) {
            if (it->id == id) {
                supplierList.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto &s : supplierList) {
            if (s.id == id) {
                s.name = name;
                s.contactInfo = contact;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto &s : supplierList) {
            if (s.id == id) {
                std::cout << "Supplier ID: " << s.id << ", Name: " << s.name << ", Contact Info: " << s.contactInfo << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found." << std::endl;
    }

    void displaySuppliers() {
        for (const auto &s : supplierList) {
            std::cout << "Supplier ID: " << s.id << ", Name: " << s.name << ", Contact Info: " << s.contactInfo << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addFurniture(1, "Chair", "Seating", 50);
    system.addFurniture(2, "Table", "Dining", 20);
    system.addSupplier(1, "John Supplies", "123-456-7890");
    system.addSupplier(2, "Furniture Co.", "987-654-3210");

    system.displayFurniture();
    system.displaySuppliers();

    system.searchFurniture(1);
    system.searchSupplier(2);

    system.updateFurniture(1, "Chair", "Seating", 100);
    system.updateSupplier(2, "Furniture Company", "987-654-3211");

    system.displayFurniture();
    system.displaySuppliers();

    system.deleteFurniture(2);
    system.deleteSupplier(1);

    system.displayFurniture();
    system.displaySuppliers();

    return 0;
}