#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    Supplier(int i, const std::string& n, const std::string& c) : id(i), name(n), contact(c) {}
};

class Furniture {
public:
    int id;
    std::string name;
    std::string type;
    int supplierId;
    Furniture(int i, const std::string& n, const std::string& t, int s) : id(i), name(n), type(t), supplierId(s) {}
};

class InventoryManagement {
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furniture;

    Supplier* findSupplierById(int id) {
        for(auto &s : suppliers) {
            if(s.id == id) return &s;
        }
        return nullptr;
    }

    Furniture* findFurnitureById(int id) {
        for(auto &f : furniture) {
            if(f.id == id) return &f;
        }
        return nullptr;
    }

public:
    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.emplace_back(id, name, contact);
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(),
                        [&](Supplier& s) { return s.id == id; }), suppliers.end());
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        Supplier* s = findSupplierById(id);
        if(s) {
            s->name = name;
            s->contact = contact;
        }
    }

    void addFurniture(int id, const std::string& name, const std::string& type, int supplierId) {
        furniture.emplace_back(id, name, type, supplierId);
    }

    void deleteFurniture(int id) {
        furniture.erase(std::remove_if(furniture.begin(), furniture.end(),
                       [&](Furniture& f) { return f.id == id; }), furniture.end());
    }

    void updateFurniture(int id, const std::string& name, const std::string& type, int supplierId) {
        Furniture* f = findFurnitureById(id);
        if(f) {
            f->name = name;
            f->type = type;
            f->supplierId = supplierId;
        }
    }

    void searchFurniture(int id) {
        Furniture* f = findFurnitureById(id);
        if(f) {
            std::cout << "Furniture ID: " << f->id << ", Name: " << f->name << ", Type: " << f->type 
                      << ", Supplier ID: " << f->supplierId << std::endl;
        }
    }

    void displayFurniture() {
        for(const auto& f : furniture) {
            std::cout << "ID: " << f.id << ", Name: " << f.name << ", Type: " << f.type 
                      << ", SupplierID: " << f.supplierId << std::endl;
        }
    }

    void displaySuppliers() {
        for(const auto& s : suppliers) {
            std::cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagement im;
    im.addSupplier(1, "Supplier A", "123-456-7890");
    im.addSupplier(2, "Supplier B", "098-765-4321");
    im.addFurniture(101, "Chair", "Seating", 1);
    im.addFurniture(102, "Table", "Dining", 2);
    im.updateSupplier(1, "Updated Supplier A", "111-222-3333");
    im.updateFurniture(101, "Updated Chair", "Updated Seating", 1);
    im.searchFurniture(101);
    im.displaySuppliers();
    im.displayFurniture();
    im.deleteSupplier(2);
    im.deleteFurniture(102);
    im.displaySuppliers();
    im.displayFurniture();
    return 0;
}