#include <iostream>
#include <vector>
#include <string>

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

struct Furniture {
    int id;
    std::string name;
    std::string type;
    double price;
    int supplierId;
};

class Inventory {
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furnitureItems;

public:
    void addSupplier(const Supplier& supplier) {
        suppliers.push_back(supplier);
    }

    void deleteSupplier(int supplierId) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(), [&](Supplier& s) { return s.id == supplierId; }), suppliers.end());
    }

    void updateSupplier(int supplierId, const Supplier& newSupplier) {
        for (auto& supplier : suppliers) {
            if (supplier.id == supplierId) {
                supplier = newSupplier;
                return;
            }
        }
    }

    void addFurniture(const Furniture& furniture) {
        furnitureItems.push_back(furniture);
    }

    void deleteFurniture(int furnitureId) {
        furnitureItems.erase(std::remove_if(furnitureItems.begin(), furnitureItems.end(), [&](Furniture& f) { return f.id == furnitureId; }), furnitureItems.end());
    }

    void updateFurniture(int furnitureId, const Furniture& newFurniture) {
        for (auto& furniture : furnitureItems) {
            if (furniture.id == furnitureId) {
                furniture = newFurniture;
                return;
            }
        }
    }

    Furniture* searchFurniture(int furnitureId) {
        for (auto& furniture : furnitureItems) {
            if (furniture.id == furnitureId) {
                return &furniture;
            }
        }
        return nullptr;
    }

    Supplier* searchSupplier(int supplierId) {
        for (auto& supplier : suppliers) {
            if (supplier.id == supplierId) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displayFurniture() const {
        for (const auto& furniture : furnitureItems) {
            std::cout << "Furniture ID: " << furniture.id << ", Name: " << furniture.name
                      << ", Type: " << furniture.type << ", Price: " << furniture.price
                      << ", Supplier ID: " << furniture.supplierId << std::endl;
        }
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    Inventory inventory;

    inventory.addSupplier({1, "Supplier A", "123-456-789"});
    inventory.addSupplier({2, "Supplier B", "987-654-321"});

    inventory.addFurniture({1, "Chair", "Seating", 49.99, 1});
    inventory.addFurniture({2, "Table", "Dining", 149.99, 2});

    inventory.displaySuppliers();
    std::cout << std::endl;
    inventory.displayFurniture();
    std::cout << std::endl;

    inventory.updateSupplier(1, {1, "Updated Supplier A", "333-333-333"});
    inventory.updateFurniture(2, {2, "Updated Table", "Dining", 199.99, 2});

    inventory.displaySuppliers();
    std::cout << std::endl;
    inventory.displayFurniture();
    std::cout << std::endl;

    inventory.deleteSupplier(2);
    inventory.deleteFurniture(1);

    inventory.displaySuppliers();
    std::cout << std::endl;
    inventory.displayFurniture();

    return 0;
}