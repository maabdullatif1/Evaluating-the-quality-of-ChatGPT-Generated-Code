#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Furniture {
    int id;
    string name;
    int quantity;
    double price;
};

struct Supplier {
    int id;
    string name;
    string contact;
    vector<int> furnitureIDs;
};

vector<Furniture> furnitureList;
vector<Supplier> supplierList;

int generateFurnitureID() {
    static int id = 0;
    return ++id;
}

int generateSupplierID() {
    static int id = 0;
    return ++id;
}

void addFurniture() {
    Furniture f;
    f.id = generateFurnitureID();
    cout << "Enter furniture name: ";
    cin >> f.name;
    cout << "Enter quantity: ";
    cin >> f.quantity;
    cout << "Enter price: ";
    cin >> f.price;
    furnitureList.push_back(f);
}

void addSupplier() {
    Supplier s;
    s.id = generateSupplierID();
    cout << "Enter supplier name: ";
    cin >> s.name;
    cout << "Enter contact: ";
    cin >> s.contact;
    cout << "Enter number of furniture IDs: ";
    int n, furnitureID;
    cin >> n;
    for(int i = 0; i < n; ++i) {
        cout << "Enter furniture ID: ";
        cin >> furnitureID;
        s.furnitureIDs.push_back(furnitureID);
    }
    supplierList.push_back(s);
}

void deleteFurniture() {
    int id;
    cout << "Enter furniture ID to delete: ";
    cin >> id;
    for(auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
        if(it->id == id) {
            furnitureList.erase(it);
            break;
        }
    }
}

void deleteSupplier() {
    int id;
    cout << "Enter supplier ID to delete: ";
    cin >> id;
    for(auto it = supplierList.begin(); it != supplierList.end(); ++it) {
        if(it->id == id) {
            supplierList.erase(it);
            break;
        }
    }
}

void updateFurniture() {
    int id;
    cout << "Enter furniture ID to update: ";
    cin >> id;
    for(auto &f : furnitureList) {
        if(f.id == id) {
            cout << "Enter new furniture name: ";
            cin >> f.name;
            cout << "Enter new quantity: ";
            cin >> f.quantity;
            cout << "Enter new price: ";
            cin >> f.price;
            break;
        }
    }
}

void updateSupplier() {
    int id;
    cout << "Enter supplier ID to update: ";
    cin >> id;
    for(auto &s : supplierList) {
        if(s.id == id) {
            cout << "Enter new supplier name: ";
            cin >> s.name;
            cout << "Enter new contact: ";
            cin >> s.contact;
            s.furnitureIDs.clear();
            cout << "Enter number of furniture IDs: ";
            int n, furnitureID;
            cin >> n;
            for(int i = 0; i < n; ++i) {
                cout << "Enter furniture ID: ";
                cin >> furnitureID;
                s.furnitureIDs.push_back(furnitureID);
            }
            break;
        }
    }
}

void searchFurniture() {
    int id;
    cout << "Enter furniture ID to search: ";
    cin >> id;
    for(const auto &f : furnitureList) {
        if(f.id == id) {
            cout << "Furniture ID: " << f.id << ", Name: " << f.name << ", Quantity: " << f.quantity << ", Price: " << f.price << endl;
            return;
        }
    }
    cout << "Furniture not found." << endl;
}

void searchSupplier() {
    int id;
    cout << "Enter supplier ID to search: ";
    cin >> id;
    for(const auto &s : supplierList) {
        if(s.id == id) {
            cout << "Supplier ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << endl;
            return;
        }
    }
    cout << "Supplier not found." << endl;
}

void displayFurniture() {
    for(const auto &f : furnitureList) {
        cout << "Furniture ID: " << f.id << ", Name: " << f.name << ", Quantity: " << f.quantity << ", Price: " << f.price << endl;
    }
}

void displaySuppliers() {
    for(const auto &s : supplierList) {
        cout << "Supplier ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << ", Furniture IDs: ";
        for(int id : s.furnitureIDs) {
            cout << id << " ";
        }
        cout << endl;
    }
}

int main() {
    int choice;
    while(true) {
        cout << "1. Add Furniture\n2. Add Supplier\n3. Delete Furniture\n4. Delete Supplier\n5. Update Furniture\n6. Update Supplier\n7. Search Furniture\n8. Search Supplier\n9. Display All Furniture\n10. Display All Suppliers\n11. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch(choice) {
            case 1: addFurniture(); break;
            case 2: addSupplier(); break;
            case 3: deleteFurniture(); break;
            case 4: deleteSupplier(); break;
            case 5: updateFurniture(); break;
            case 6: updateSupplier(); break;
            case 7: searchFurniture(); break;
            case 8: searchSupplier(); break;
            case 9: displayFurniture(); break;
            case 10: displaySuppliers(); break;
            case 11: exit(0);
            default: cout << "Invalid choice!" << endl;
        }
    }
    return 0;
}