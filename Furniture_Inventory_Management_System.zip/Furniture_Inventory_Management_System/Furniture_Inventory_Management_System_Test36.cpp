#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    int supplierId;
    std::string name;
    std::string contact;
    
    Supplier(int id, std::string n, std::string c) : supplierId(id), name(n), contact(c) {}
};

class Furniture {
public:
    int furnitureId;
    std::string name;
    std::string type;
    int supplierId;
    
    Furniture(int id, std::string n, std::string t, int sid) : furnitureId(id), name(n), type(t), supplierId(sid) {}
};

class InventoryManagementSystem {
private:
    std::vector<Supplier> suppliers;
    std::vector<Furniture> furnitures;

public:
    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }
    
    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(), [&](Supplier& s) { return s.supplierId == id; }), suppliers.end());
    }
    
    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto &s : suppliers) {
            if (s.supplierId == id) {
                s.name = name;
                s.contact = contact;
                break;
            }
        }
    }
    
    Supplier searchSupplier(int id) {
        for (auto &s : suppliers) {
            if (s.supplierId == id) {
                return s;
            }
        }
        return Supplier(-1, "", "");
    }
    
    void displaySuppliers() {
        for (auto &s : suppliers) {
            std::cout << "Supplier ID: " << s.supplierId << ", Name: " << s.name << ", Contact: " << s.contact << std::endl;
        }
    }
    
    void addFurniture(int id, std::string name, std::string type, int supplierId) {
        furnitures.push_back(Furniture(id, name, type, supplierId));
    }
    
    void deleteFurniture(int id) {
        furnitures.erase(std::remove_if(furnitures.begin(), furnitures.end(), [&](Furniture& f) { return f.furnitureId == id; }), furnitures.end());
    }
    
    void updateFurniture(int id, std::string name, std::string type, int supplierId) {
        for (auto &f : furnitures) {
            if (f.furnitureId == id) {
                f.name = name;
                f.type = type;
                f.supplierId = supplierId;
                break;
            }
        }
    }
    
    Furniture searchFurniture(int id) {
        for (auto &f : furnitures) {
            if (f.furnitureId == id) {
                return f;
            }
        }
        return Furniture(-1, "", "", -1);
    }
    
    void displayFurnitures() {
        for (auto &f : furnitures) {
            std::cout << "Furniture ID: " << f.furnitureId << ", Name: " << f.name << ", Type: " << f.type << ", Supplier ID: " << f.supplierId << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addSupplier(1, "Supplier A", "123-456-789");
    ims.addSupplier(2, "Supplier B", "987-654-321");
    
    ims.addFurniture(101, "Chair", "Seating", 1);
    ims.addFurniture(102, "Table", "Surface", 2);

    ims.displaySuppliers();
    ims.displayFurnitures();
    
    ims.updateSupplier(1, "Supplier A+", "111-222-333");
    ims.updateFurniture(101, "Armchair", "Seating", 1);

    ims.displaySuppliers();
    ims.displayFurnitures();

    ims.deleteSupplier(2);
    ims.deleteFurniture(102);

    ims.displaySuppliers();
    ims.displayFurnitures();

    return 0;
}