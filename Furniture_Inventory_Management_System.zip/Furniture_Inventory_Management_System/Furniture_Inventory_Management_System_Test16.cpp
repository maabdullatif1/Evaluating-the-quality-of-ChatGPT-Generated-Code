#include <iostream>
#include <vector>
#include <string>

class Supplier {
public:
    std::string name;
    std::string contactInfo;

    Supplier(std::string n, std::string c) : name(n), contactInfo(c) {}
};

class Furniture {
public:
    std::string name;
    std::string type;
    int quantity;
    Supplier* supplier;

    Furniture(std::string n, std::string t, int q, Supplier* s) : name(n), type(t), quantity(q), supplier(s) {}
};

class Inventory {
private:
    std::vector<Furniture*> furnitureList;
    std::vector<Supplier*> supplierList;

public:
    void addSupplier(std::string name, std::string contact) {
        Supplier* newSupplier = new Supplier(name, contact);
        supplierList.push_back(newSupplier);
    }

    void addFurniture(std::string name, std::string type, int quantity, std::string supplierName) {
        Supplier* s = nullptr;
        for (auto& supplier : supplierList) {
            if (supplier->name == supplierName) {
                s = supplier;
                break;
            }
        }
        if (s) {
            Furniture* newFurniture = new Furniture(name, type, quantity, s);
            furnitureList.push_back(newFurniture);
        }
    }

    void updateFurniture(std::string name, std::string type, int quantity) {
        for (auto& furniture : furnitureList) {
            if (furniture->name == name && furniture->type == type) {
                furniture->quantity = quantity;
                break;
            }
        }
    }

    void deleteFurniture(std::string name, std::string type) {
        for (auto it = furnitureList.begin(); it != furnitureList.end(); ++it) {
            if ((*it)->name == name && (*it)->type == type) {
                furnitureList.erase(it);
                break;
            }
        }
    }

    void searchFurniture(std::string name) {
        for (auto& furniture : furnitureList) {
            if (furniture->name == name) {
                std::cout << "Furniture: " << furniture->name << ", Type: " << furniture->type << ", Quantity: " << furniture->quantity << ", Supplier: " << furniture->supplier->name << std::endl;
            }
        }
    }

    void displayFurniture() {
        for (auto& furniture : furnitureList) {
            std::cout << "Furniture: " << furniture->name << ", Type: " << furniture->type << ", Quantity: " << furniture->quantity << ", Supplier: " << furniture->supplier->name << std::endl;
        }
    }

    void displaySuppliers() {
        for (auto& supplier : supplierList) {
            std::cout << "Supplier: " << supplier->name << ", Contact: " << supplier->contactInfo << std::endl;
        }
    }
};

int main() {
    Inventory inv;
    inv.addSupplier("Acme Furniture", "123-456-7890");
    inv.addSupplier("Furniture Co", "987-654-3210");

    inv.addFurniture("Chair", "Wooden", 50, "Acme Furniture");
    inv.addFurniture("Table", "Glass", 20, "Furniture Co");

    std::cout << "Furniture Inventory:" << std::endl;
    inv.displayFurniture();

    std::cout << "\nSuppliers:" << std::endl;
    inv.displaySuppliers();

    std::cout << "\nSearch Furniture by name 'Chair':" << std::endl;
    inv.searchFurniture("Chair");

    std::cout << "\nUpdate furniture 'Chair', Type 'Wooden', Quantity 70" << std::endl;
    inv.updateFurniture("Chair", "Wooden", 70);
    inv.displayFurniture();

    std::cout << "\nDelete furniture 'Table', Type 'Glass'" << std::endl;
    inv.deleteFurniture("Table", "Glass");
    inv.displayFurniture();

    return 0;
}