#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    std::string name;
    int quantity;
    double price;

    Drink(std::string n, int q, double p) : name(n), quantity(q), price(p) {}
};

class Supplier {
public:
    std::string name;
    std::string contact_info;

    Supplier(std::string n, std::string c) : name(n), contact_info(c) {}
};

class Inventory {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(const std::string& name, int quantity, double price) {
        drinks.push_back(Drink(name, quantity, price));
    }
    
    void deleteDrink(const std::string& name) {
        drinks.erase(std::remove_if(drinks.begin(), drinks.end(), [&](Drink& d) { return d.name == name; }), drinks.end());
    }
    
    void updateDrink(const std::string& name, int new_quantity, double new_price) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.quantity = new_quantity;
                drink.price = new_price;
                break;
            }
        }
    }
    
    void searchDrink(const std::string& name) {
        for (const auto& drink : drinks) {
            if (drink.name == name) {
                std::cout << "Drink: " << drink.name << " Quantity: " << drink.quantity << " Price: " << drink.price << std::endl;
                return;
            }
        }
        std::cout << "Drink not found" << std::endl;
    }
    
    void displayDrinks() {
        for (const auto& drink : drinks) {
            std::cout << "Drink: " << drink.name << " Quantity: " << drink.quantity << " Price: " << drink.price << std::endl;
        }
    }
    
    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back(Supplier(name, contact));
    }

    void deleteSupplier(const std::string& name) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(), [&](Supplier& s) { return s.name == name; }), suppliers.end());
    }

    void updateSupplier(const std::string& name, const std::string& new_contact) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contact_info = new_contact;
                break;
            }
        }
    }

    void searchSupplier(const std::string& name) {
        for (const auto& supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Supplier: " << supplier.name << " Contact: " << supplier.contact_info << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found" << std::endl;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier: " << supplier.name << " Contact: " << supplier.contact_info << std::endl;
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addDrink("Latte", 10, 3.5);
    inventory.addDrink("Espresso", 20, 2.5);
    inventory.displayDrinks();
    inventory.searchDrink("Latte");
    inventory.updateDrink("Latte", 15, 4.0);
    inventory.displayDrinks();
    inventory.deleteDrink("Espresso");
    inventory.displayDrinks();
    inventory.addSupplier("CoffeeSupplier", "contact@coffeesupplier.com");
    inventory.addSupplier("BeansRUs", "info@beansrus.com");
    inventory.displaySuppliers();
    inventory.searchSupplier("CoffeeSupplier");
    inventory.updateSupplier("CoffeeSupplier", "support@coffeesupplier.com");
    inventory.displaySuppliers();
    inventory.deleteSupplier("BeansRUs");
    inventory.displaySuppliers();
    return 0;
}