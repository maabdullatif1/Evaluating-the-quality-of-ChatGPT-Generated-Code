#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    std::string name;
    double price;
    int stock;

    Drink(std::string n, double p, int s) : name(n), price(p), stock(s) {}
};

class Supplier {
public:
    std::string name;
    std::string contact;

    Supplier(std::string n, std::string c) : name(n), contact(c) {}
};

class CoffeeShopInventory {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(std::string name, double price, int stock) {
        drinks.push_back(Drink(name, price, stock));
    }

    void deleteDrink(std::string name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(std::string name, double price, int stock) {
        for (auto &drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.stock = stock;
                break;
            }
        }
    }

    void searchDrink(std::string name) {
        for (const auto &drink : drinks) {
            if (drink.name == name) {
                std::cout << "Drink found: " << drink.name << ", Price: " << drink.price << ", Stock: " << drink.stock << "\n";
                return;
            }
        }
        std::cout << "Drink not found.\n";
    }

    void displayDrinks() {
        for (const auto &drink : drinks) {
            std::cout << "Drink: " << drink.name << ", Price: " << drink.price << ", Stock: " << drink.stock << "\n";
        }
    }

    void addSupplier(std::string name, std::string contact) {
        suppliers.push_back(Supplier(name, contact));
    }

    void deleteSupplier(std::string name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(std::string name, std::string contact) {
        for (auto &supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(std::string name) {
        for (const auto &supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Supplier found: " << supplier.name << ", Contact: " << supplier.contact << "\n";
                return;
            }
        }
        std::cout << "Supplier not found.\n";
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "Supplier: " << supplier.name << ", Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    CoffeeShopInventory inventory;

    inventory.addDrink("Espresso", 2.5, 100);
    inventory.addDrink("Latte", 3.5, 50);
    inventory.addSupplier("BestBeans", "123-456-7890");
    inventory.addSupplier("CoffeeCo", "098-765-4321");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    inventory.searchDrink("Latte");
    inventory.searchSupplier("CoffeeCo");

    inventory.updateDrink("Latte", 3.75, 55);
    inventory.updateSupplier("BestBeans", "111-222-3333");

    inventory.deleteDrink("Espresso");
    inventory.deleteSupplier("CoffeeCo");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    return 0;
}