#include <iostream>
#include <string>
#include <vector>

struct Drink {
    std::string name;
    double price;
    int quantity;
};

struct Supplier {
    std::string name;
    std::string contactInfo;
};

class InventoryManagementSystem {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

    int findDrinkIndex(const std::string& drinkName) {
        for (std::size_t i = 0; i < drinks.size(); ++i) {
            if (drinks[i].name == drinkName) return i;
        }
        return -1;
    }

    int findSupplierIndex(const std::string& supplierName) {
        for (std::size_t i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].name == supplierName) return i;
        }
        return -1;
    }

public:
    void addDrink(const std::string& name, double price, int quantity) {
        drinks.push_back({name, price, quantity});
    }

    void deleteDrink(const std::string& name) {
        int index = findDrinkIndex(name);
        if (index != -1) {
            drinks.erase(drinks.begin() + index);
        }
    }

    void updateDrink(const std::string& name, double price, int quantity) {
        int index = findDrinkIndex(name);
        if (index != -1) {
            drinks[index].price = price;
            drinks[index].quantity = quantity;
        }
    }

    void searchDrink(const std::string& name) {
        int index = findDrinkIndex(name);
        if (index != -1) {
            std::cout << "Drink found: " << drinks[index].name
                      << ", Price: " << drinks[index].price
                      << ", Quantity: " << drinks[index].quantity << "\n";
        } else {
            std::cout << "Drink not found.\n";
        }
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            std::cout << "Name: " << drink.name
                      << ", Price: " << drink.price
                      << ", Quantity: " << drink.quantity << "\n";
        }
    }

    void addSupplier(const std::string& name, const std::string& contactInfo) {
        suppliers.push_back({name, contactInfo});
    }

    void deleteSupplier(const std::string& name) {
        int index = findSupplierIndex(name);
        if (index != -1) {
            suppliers.erase(suppliers.begin() + index);
        }
    }

    void updateSupplier(const std::string& name, const std::string& contactInfo) {
        int index = findSupplierIndex(name);
        if (index != -1) {
            suppliers[index].contactInfo = contactInfo;
        }
    }

    void searchSupplier(const std::string& name) {
        int index = findSupplierIndex(name);
        if (index != -1) {
            std::cout << "Supplier found: " << suppliers[index].name
                      << ", Contact Info: " << suppliers[index].contactInfo << "\n";
        } else {
            std::cout << "Supplier not found.\n";
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Name: " << supplier.name
                      << ", Contact Info: " << supplier.contactInfo << "\n";
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addDrink("Cappuccino", 3.5, 100);
    ims.addDrink("Espresso", 2.0, 150);
    ims.displayDrinks();

    ims.addSupplier("CoffeeCo", "123-456-7890");
    ims.addSupplier("BeansRUs", "987-654-3210");
    ims.displaySuppliers();

    ims.updateDrink("Cappuccino", 3.75, 90);
    ims.searchDrink("Espresso");

    ims.updateSupplier("CoffeeCo", "111-222-3333");
    ims.searchSupplier("BeansRUs");

    ims.deleteDrink("Cappuccino");
    ims.displayDrinks();

    ims.deleteSupplier("BeansRUs");
    ims.displaySuppliers();

    return 0;
}