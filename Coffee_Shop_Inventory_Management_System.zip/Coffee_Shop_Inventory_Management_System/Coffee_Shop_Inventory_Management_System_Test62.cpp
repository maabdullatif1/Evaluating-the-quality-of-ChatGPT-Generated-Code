#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Drink {
public:
    int id;
    string name;
    double price;

    Drink(int id, const string &name, double price) : id(id), name(name), price(price) {}
};

class Supplier {
public:
    int id;
    string name;
    string contact;

    Supplier(int id, const string &name, const string &contact) : id(id), name(name), contact(contact) {}
};

class Inventory {
private:
    vector<Drink> drinks;
    vector<Supplier> suppliers;

public:
    void addDrink(int id, const string &name, double price) {
        drinks.emplace_back(id, name, price);
    }

    void addSupplier(int id, const string &name, const string &contact) {
        suppliers.emplace_back(id, name, contact);
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                return;
            }
        }
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                return;
            }
        }
    }

    void updateDrink(int id, const string &name, double price) {
        for (auto &drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                return;
            }
        }
    }

    void updateSupplier(int id, const string &name, const string &contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                return;
            }
        }
    }

    void searchDrink(int id) const {
        for (const auto &drink : drinks) {
            if (drink.id == id) {
                cout << "Drink ID: " << drink.id << ", Name: " << drink.name << ", Price: $" << drink.price << endl;
                return;
            }
        }
        cout << "Drink not found." << endl;
    }

    void searchSupplier(int id) const {
        for (const auto &supplier : suppliers) {
            if (supplier.id == id) {
                cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
                return;
            }
        }
        cout << "Supplier not found." << endl;
    }

    void displayDrinks() const {
        cout << "Drinks:" << endl;
        for (const auto &drink : drinks) {
            cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: $" << drink.price << endl;
        }
    }

    void displaySuppliers() const {
        cout << "Suppliers:" << endl;
        for (const auto &supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    Inventory inventory;

    inventory.addDrink(1, "Espresso", 2.50);
    inventory.addDrink(2, "Cappuccino", 3.00);
    inventory.addSupplier(1, "Coffee Beans Co.", "contact@beans.com");
    inventory.addSupplier(2, "Dairy Supplies Inc.", "info@dairy.com");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    inventory.updateDrink(1, "Double Espresso", 2.75);
    inventory.updateSupplier(2, "Dairy Supplies Ltd.", "support@dairy.com");

    inventory.searchDrink(1);
    inventory.searchSupplier(2);

    inventory.deleteDrink(1);
    inventory.deleteSupplier(1);

    inventory.displayDrinks();
    inventory.displaySuppliers();

    return 0;
}