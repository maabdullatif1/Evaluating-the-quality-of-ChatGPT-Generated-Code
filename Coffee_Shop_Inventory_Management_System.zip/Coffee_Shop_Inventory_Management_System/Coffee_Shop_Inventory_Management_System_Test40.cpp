#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    std::string name;
    double price;

    Drink(std::string n, double p) : name(n), price(p) {}

    void update(std::string n, double p) {
        name = n;
        price = p;
    }

    void display() const {
        std::cout << "Drink Name: " << name << ", Price: $" << price << "\n";
    }
};

class Supplier {
public:
    std::string name;
    std::string contact;

    Supplier(std::string n, std::string c) : name(n), contact(c) {}

    void update(std::string n, std::string c) {
        name = n;
        contact = c;
    }

    void display() const {
        std::cout << "Supplier Name: " << name << ", Contact: " << contact << "\n";
    }
};

class CoffeeShopInventory {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(const Drink& drink) {
        drinks.push_back(drink);
    }

    void deleteDrink(const std::string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(const std::string& name, const std::string& newName, double newPrice) {
        for(auto& drink : drinks) {
            if(drink.name == name) {
                drink.update(newName, newPrice);
                break;
            }
        }
    }

    void searchDrink(const std::string& name) const {
        for(const auto& drink : drinks) {
            if(drink.name == name) {
                drink.display();
                return;
            }
        }
        std::cout << "Drink not found.\n";
    }

    void displayDrinks() const {
        for(const auto& drink : drinks) {
            drink.display();
        }
    }

    void addSupplier(const Supplier& supplier) {
        suppliers.push_back(supplier);
    }

    void deleteSupplier(const std::string& name) {
        for(auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if(it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(const std::string& name, const std::string& newName, const std::string& newContact) {
        for(auto& supplier : suppliers) {
            if(supplier.name == name) {
                supplier.update(newName, newContact);
                break;
            }
        }
    }

    void searchSupplier(const std::string& name) const {
        for(const auto& supplier : suppliers) {
            if(supplier.name == name) {
                supplier.display();
                return;
            }
        }
        std::cout << "Supplier not found.\n";
    }

    void displaySuppliers() const {
        for(const auto& supplier : suppliers) {
            supplier.display();
        }
    }
};

int main() {
    CoffeeShopInventory inventory;

    inventory.addDrink(Drink("Espresso", 2.5));
    inventory.addDrink(Drink("Latte", 3.5));
    inventory.addSupplier(Supplier("Coffee Beans Ltd", "123-456-789"));
    inventory.addSupplier(Supplier("Dairy Suppliers Inc", "987-654-321"));

    std::cout << "Drinks:\n";
    inventory.displayDrinks();

    std::cout << "\nSuppliers:\n";
    inventory.displaySuppliers();

    std::cout << "\nSearching for 'Latte':\n";
    inventory.searchDrink("Latte");

    std::cout << "\nUpdating 'Latte' to 'Vanilla Latte':\n";
    inventory.updateDrink("Latte", "Vanilla Latte", 4.0);

    std::cout << "\nDeleting 'Espresso':\n";
    inventory.deleteDrink("Espresso");

    inventory.displayDrinks();

    return 0;
}