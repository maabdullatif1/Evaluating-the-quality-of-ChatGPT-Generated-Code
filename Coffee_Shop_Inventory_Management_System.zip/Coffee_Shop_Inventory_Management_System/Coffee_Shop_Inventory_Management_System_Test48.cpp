#include <iostream>
#include <string>
#include <vector>

struct Drink {
    int id;
    std::string name;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventoryManagement {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    int drinkIdCounter;
    int supplierIdCounter;

public:
    InventoryManagement() : drinkIdCounter(1), supplierIdCounter(1) {}

    void addDrink(const std::string& name, double price) {
        drinks.push_back({drinkIdCounter++, name, price});
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(int id, const std::string& name, double price) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                break;
            }
        }
    }

    Drink* searchDrink(int id) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                return &drink;
            }
        }
        return nullptr;
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            std::cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: $" << drink.price << std::endl;
        }
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back({supplierIdCounter++, name, contact});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagement system;

    system.addDrink("Espresso", 2.5);
    system.addDrink("Latte", 3.5);
    system.displayDrinks();

    system.addSupplier("Coffee Beans Supplier", "contact@beans.com");
    system.addSupplier("Milk Supplier", "contact@milk.com");
    system.displaySuppliers();

    Drink* drink = system.searchDrink(1);
    if (drink) {
        std::cout << "Found Drink: " << drink->name << ", Price: $" << drink->price << std::endl;
    }

    system.updateDrink(1, "Espresso Shot", 2.75);
    system.displayDrinks();

    Supplier* supplier = system.searchSupplier(1);
    if (supplier) {
        std::cout << "Found Supplier: " << supplier->name << ", Contact: " << supplier->contact << std::endl;
    }

    system.deleteDrink(2);
    system.displayDrinks();

    system.deleteSupplier(2);
    system.displaySuppliers();

    return 0;
}