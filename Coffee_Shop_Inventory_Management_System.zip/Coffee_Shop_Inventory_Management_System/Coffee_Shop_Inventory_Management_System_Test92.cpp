#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    int id;
    string name;
    double price;
    int supplierId;
};

struct Supplier {
    int id;
    string name;
    string contactInfo;
};

class CoffeeShopInventory {
    vector<Drink> drinks;
    vector<Supplier> suppliers;
    int drinkIdCounter;
    int supplierIdCounter;
public:
    CoffeeShopInventory() : drinkIdCounter(1), supplierIdCounter(1) {}

    void addDrink(string name, double price, int supplierId) {
        drinks.push_back({drinkIdCounter++, name, price, supplierId});
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(int id, string name, double price, int supplierId) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                drink.supplierId = supplierId;
                break;
            }
        }
    }

    Drink* searchDrink(int id) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                return &drink;
            }
        }
        return nullptr;
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            cout << "ID: " << drink.id << ", Name: " << drink.name 
                 << ", Price: $" << drink.price << ", Supplier ID: " << drink.supplierId << endl;
        }
    }

    void addSupplier(string name, string contactInfo) {
        suppliers.push_back({supplierIdCounter++, name, contactInfo});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name 
                 << ", Contact Info: " << supplier.contactInfo << endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    
    inventory.addSupplier("Best Beans Co.", "contact@bestbeans.com");
    inventory.addSupplier("Coffee Delight", "info@coffeedelight.com");
    
    inventory.addDrink("Espresso", 2.50, 1);
    inventory.addDrink("Latte", 3.75, 2);
    
    inventory.displayDrinks();
    inventory.displaySuppliers();
    
    Drink* drink = inventory.searchDrink(1);
    if (drink) {
        cout << "Found Drink: " << drink->name << endl;
    }

    Supplier* supplier = inventory.searchSupplier(2);
    if (supplier) {
        cout << "Found Supplier: " << supplier->name << endl;
    }

    inventory.updateDrink(1, "Double Espresso", 3.00, 1);
    inventory.updateSupplier(1, "Premium Beans Co.", "contact@premiumbeans.com");
    
    inventory.displayDrinks();
    inventory.displaySuppliers();
    
    inventory.deleteDrink(2);
    inventory.deleteSupplier(2);

    inventory.displayDrinks();
    inventory.displaySuppliers();

    return 0;
}