#include <iostream>
#include <string>
#include <vector>

class Drink {
public:
    int id;
    std::string name;
    double price;
    int quantity;

    Drink(int i, std::string n, double p, int q) : id(i), name(n), price(p), quantity(q) {}
};

class Supplier {
public:
    int id;
    std::string name;

    Supplier(int i, std::string n) : id(i), name(n) {}
};

class InventoryManagementSystem {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(int id, std::string name, double price, int quantity) {
        drinks.push_back(Drink(id, name, price, quantity));
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                return;
            }
        }
    }

    void updateDrink(int id, std::string name, double price, int quantity) {
        for (auto &drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                drink.quantity = quantity;
                return;
            }
        }
    }

    Drink* searchDrink(int id) {
        for (auto &drink : drinks) {
            if (drink.id == id) {
                return &drink;
            }
        }
        return nullptr;
    }

    void addSupplier(int id, std::string name) {
        suppliers.push_back(Supplier(id, name));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                return;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displayDrinks() {
        for (const auto &drink : drinks) {
            std::cout << "Drink ID: " << drink.id << ", Name: " << drink.name 
                      << ", Price: $" << drink.price << ", Quantity: " << drink.quantity << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    
    ims.addDrink(1, "Espresso", 2.50, 30);
    ims.addDrink(2, "Cappuccino", 3.00, 20);
    ims.updateDrink(1, "Espresso", 2.75, 25);
    ims.deleteDrink(2);
    
    ims.addSupplier(1, "Coffee Beans Co.");
    ims.addSupplier(2, "Dairy Supplies Inc.");
    ims.deleteSupplier(2);
    
    ims.displayDrinks();
    ims.displaySuppliers();
    
    Drink *d = ims.searchDrink(1);
    if (d) {
        std::cout << "Found Drink: " << d->name << ", Price: $" << d->price << std::endl;
    }
    
    Supplier *s = ims.searchSupplier(1);
    if (s) {
        std::cout << "Found Supplier: " << s->name << std::endl;
    }
    
    return 0;
}