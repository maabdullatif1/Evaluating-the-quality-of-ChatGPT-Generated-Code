#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Drink {
public:
    string name;
    double price;
    int stock;
    
    Drink(string n, double p, int s) : name(n), price(p), stock(s) {}
};

class Supplier {
public:
    string name;
    string contact;
    
    Supplier(string n, string c) : name(n), contact(c) {}
};

class CoffeeShop {
private:
    vector<Drink> drinks;
    vector<Supplier> suppliers;
    
    int findDrinkIndex(string name) {
        for (size_t i = 0; i < drinks.size(); ++i)
            if (drinks[i].name == name)
                return i;
        return -1;
    }
    
    int findSupplierIndex(string name) {
        for (size_t i = 0; i < suppliers.size(); ++i)
            if (suppliers[i].name == name)
                return i;
        return -1;
    }
    
public:
    void addDrink(string name, double price, int stock) {
        drinks.push_back(Drink(name, price, stock));
    }
    
    void deleteDrink(string name) {
        int idx = findDrinkIndex(name);
        if (idx != -1)
            drinks.erase(drinks.begin() + idx);
    }
    
    void updateDrink(string name, double price, int stock) {
        int idx = findDrinkIndex(name);
        if (idx != -1) {
            drinks[idx].price = price;
            drinks[idx].stock = stock;
        }
    }
    
    Drink* searchDrink(string name) {
        int idx = findDrinkIndex(name);
        if (idx != -1)
            return &drinks[idx];
        return nullptr;
    }
    
    void displayDrinks() {
        for (const auto& drink : drinks)
            cout << "Name: " << drink.name << ", Price: " << drink.price << ", Stock: " << drink.stock << endl;
    }
    
    void addSupplier(string name, string contact) {
        suppliers.push_back(Supplier(name, contact));
    }
    
    void deleteSupplier(string name) {
        int idx = findSupplierIndex(name);
        if (idx != -1)
            suppliers.erase(suppliers.begin() + idx);
    }
    
    void updateSupplier(string name, string contact) {
        int idx = findSupplierIndex(name);
        if (idx != -1)
            suppliers[idx].contact = contact;
    }
    
    Supplier* searchSupplier(string name) {
        int idx = findSupplierIndex(name);
        if (idx != -1)
            return &suppliers[idx];
        return nullptr;
    }
    
    void displaySuppliers() {
        for (const auto& supplier : suppliers)
            cout << "Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
    }
};

int main() {
    CoffeeShop shop;
    
    shop.addDrink("Espresso", 2.5, 100);
    shop.addDrink("Latte", 3.5, 80);
    shop.displayDrinks();
    
    shop.addSupplier("Coffee Co", "555-1234");
    shop.addSupplier("Beans Supply", "555-9876");
    shop.displaySuppliers();
    
    return 0;
}