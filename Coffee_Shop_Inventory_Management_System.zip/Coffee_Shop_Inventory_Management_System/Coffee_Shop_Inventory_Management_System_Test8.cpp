#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    int id;
    string name;
    double price;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

class CoffeeShopInventory {
private:
    vector<Drink> drinks;
    vector<Supplier> suppliers;
    int drinkIDCounter = 1;
    int supplierIDCounter = 1;

public:
    void addDrink(string name, double price) {
        drinks.push_back({drinkIDCounter++, name, price});
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(int id, string name, double price) {
        for (auto &drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                break;
            }
        }
    }

    void searchAndDisplayDrink(int id) {
        for (const auto &drink : drinks) {
            if (drink.id == id) {
                cout << "Drink ID: " << drink.id << ", Name: " << drink.name << ", Price: $" << drink.price << endl;
                return;
            }
        }
        cout << "Drink not found" << endl;
    }

    void displayAllDrinks() {
        for (const auto &drink : drinks) {
            cout << "Drink ID: " << drink.id << ", Name: " << drink.name << ", Price: $" << drink.price << endl;
        }
    }

    void addSupplier(string name, string contact) {
        suppliers.push_back({supplierIDCounter++, name, contact});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchAndDisplaySupplier(int id) {
        for (const auto &supplier : suppliers) {
            if (supplier.id == id) {
                cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
                return;
            }
        }
        cout << "Supplier not found" << endl;
    }

    void displayAllSuppliers() {
        for (const auto &supplier : suppliers) {
            cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink("Espresso", 3.50);
    inventory.addDrink("Latte", 4.00);
    inventory.addSupplier("Beans Supplier", "123-456-7890");
    inventory.addSupplier("Milk Supplier", "987-654-3210");

    inventory.displayAllDrinks();
    inventory.displayAllSuppliers();

    inventory.updateDrink(1, "Double Espresso", 4.00);
    inventory.searchAndDisplayDrink(1);

    inventory.updateSupplier(2, "Organic Milk Supplier", "987-654-3210");
    inventory.searchAndDisplaySupplier(2);

    inventory.deleteDrink(2);
    inventory.displayAllDrinks();

    inventory.deleteSupplier(1);
    inventory.displayAllSuppliers();

    return 0;
}