#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Drink {
    string name;
    double price;
    int quantity;
};

struct Supplier {
    string name;
    string contactInfo;
};

class CoffeeShopInventory {
private:
    vector<Drink> drinks;
    vector<Supplier> suppliers;

public:
    void addDrink(const string& name, double price, int quantity) {
        drinks.push_back({name, price, quantity});
    }

    void deleteDrink(const string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(const string& name, double price, int quantity) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = quantity;
                break;
            }
        }
    }

    void searchDrink(const string& name) const {
        for (const auto& drink : drinks) {
            if (drink.name == name) {
                cout << "Drink found: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
                return;
            }
        }
        cout << "Drink not found" << endl;
    }

    void displayDrinks() const {
        cout << "Drinks:\n";
        for (const auto& drink : drinks) {
            cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
        }
    }

    void addSupplier(const string& name, const string& contactInfo) {
        suppliers.push_back({name, contactInfo});
    }

    void deleteSupplier(const string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(const string& name, const string& contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    void searchSupplier(const string& name) const {
        for (const auto& supplier : suppliers) {
            if (supplier.name == name) {
                cout << "Supplier found: " << supplier.name << ", Contact Info: " << supplier.contactInfo << endl;
                return;
            }
        }
        cout << "Supplier not found" << endl;
    }

    void displaySuppliers() const {
        cout << "Suppliers:\n";
        for (const auto& supplier : suppliers) {
            cout << "Name: " << supplier.name << ", Contact Info: " << supplier.contactInfo << endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;

    inventory.addDrink("Espresso", 2.5, 30);
    inventory.addDrink("Cappuccino", 3.0, 20);
    inventory.updateDrink("Espresso", 2.75, 25);
    inventory.searchDrink("Latte");
    inventory.searchDrink("Espresso");
    inventory.displayDrinks();

    inventory.addSupplier("Best Beans Co", "123-456-7890");
    inventory.addSupplier("Coffee King", "987-654-3210");
    inventory.updateSupplier("Best Beans Co", "111-222-3333");
    inventory.searchSupplier("Bean Masters");
    inventory.searchSupplier("Best Beans Co");
    inventory.displaySuppliers();

    return 0;
}