#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    std::string name;
    double price;
    Drink(const std::string& n, double p) : name(n), price(p) {}
};

class Supplier {
public:
    std::string name;
    std::string contact;
    Supplier(const std::string& n, const std::string& c) : name(n), contact(c) {}
};

class InventoryManagementSystem {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(const std::string& name, double price) {
        drinks.push_back(Drink(name, price));
    }
    
    void deleteDrink(const std::string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                return;
            }
        }
    }

    void updateDrink(const std::string& name, double price) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                return;
            }
        }
    }

    void searchDrink(const std::string& name) const {
        for (const auto& drink : drinks) {
            if (drink.name == name) {
                std::cout << "Drink found: " << drink.name << ", Price: $" << drink.price << std::endl;
                return;
            }
        }
        std::cout << "Drink not found" << std::endl;
    }

    void displayDrinks() const {
        for (const auto& drink : drinks) {
            std::cout << "Name: " << drink.name << ", Price: $" << drink.price << std::endl;
        }
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back(Supplier(name, contact));
    }
    
    void deleteSupplier(const std::string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                return;
            }
        }
    }

    void updateSupplier(const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contact = contact;
                return;
            }
        }
    }

    void searchSupplier(const std::string& name) const {
        for (const auto& supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Supplier found: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found" << std::endl;
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            std::cout << "Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addDrink("Espresso", 2.5);
    ims.addDrink("Latte", 3.5);
    ims.displayDrinks();
    
    ims.searchDrink("Latte");
    ims.updateDrink("Latte", 4.0);
    ims.searchDrink("Latte");
    ims.deleteDrink("Latte");
    ims.displayDrinks();
    
    ims.addSupplier("Best Beans Co", "123-456-7890");
    ims.displaySuppliers();
    ims.searchSupplier("Best Beans Co");
    ims.updateSupplier("Best Beans Co", "098-765-4321");
    ims.searchSupplier("Best Beans Co");
    ims.deleteSupplier("Best Beans Co");
    ims.displaySuppliers();

    return 0;
}