#include <iostream>
#include <string>
#include <vector>

struct Drink {
    std::string name;
    double price;
    int stock;
};

struct Supplier {
    std::string name;
    std::string contact;
};

class InventoryManagementSystem {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

    int findDrinkIndex(const std::string& name) {
        for (size_t i = 0; i < drinks.size(); ++i)
            if (drinks[i].name == name)
                return i;
        return -1;
    }

    int findSupplierIndex(const std::string& name) {
        for (size_t i = 0; i < suppliers.size(); ++i)
            if (suppliers[i].name == name)
                return i;
        return -1;
    }

public:
    void addDrink(const std::string& name, double price, int stock) {
        drinks.push_back({name, price, stock});
    }

    void deleteDrink(const std::string& name) {
        int index = findDrinkIndex(name);
        if (index != -1)
            drinks.erase(drinks.begin() + index);
    }

    void updateDrink(const std::string& name, double price, int stock) {
        int index = findDrinkIndex(name);
        if (index != -1) {
            drinks[index].price = price;
            drinks[index].stock = stock;
        }
    }

    Drink* searchDrink(const std::string& name) {
        int index = findDrinkIndex(name);
        if (index != -1)
            return &drinks[index];
        return nullptr;
    }

    void displayDrinks() {
        for (const auto& drink : drinks)
            std::cout << "Name: " << drink.name << ", Price: " << drink.price << ", Stock: " << drink.stock << std::endl;
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back({name, contact});
    }

    void deleteSupplier(const std::string& name) {
        int index = findSupplierIndex(name);
        if (index != -1)
            suppliers.erase(suppliers.begin() + index);
    }

    void updateSupplier(const std::string& name, const std::string& contact) {
        int index = findSupplierIndex(name);
        if (index != -1)
            suppliers[index].contact = contact;
    }

    Supplier* searchSupplier(const std::string& name) {
        int index = findSupplierIndex(name);
        if (index != -1)
            return &suppliers[index];
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers)
            std::cout << "Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addDrink("Espresso", 2.5, 100);
    ims.addDrink("Latte", 3.0, 50);
    ims.displayDrinks();

    ims.addSupplier("Best Coffee Beans", "123-456-7890");
    ims.addSupplier("Dairy Direct", "098-765-4321");
    ims.displaySuppliers();

    ims.updateDrink("Espresso", 2.5, 80);
    ims.updateSupplier("Best Coffee Beans", "321-654-0987");
    ims.displayDrinks();
    ims.displaySuppliers();

    ims.deleteDrink("Latte");
    ims.deleteSupplier("Dairy Direct");
    ims.displayDrinks();
    ims.displaySuppliers();

    return 0;
}