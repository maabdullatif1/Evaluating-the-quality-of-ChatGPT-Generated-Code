#include <iostream>
#include <string>

struct Drink {
    int id;
    std::string name;
    double price;
    int quantity;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

const int MAX_ITEMS = 100;
Drink drinks[MAX_ITEMS];
Supplier suppliers[MAX_ITEMS];
int drinkCount = 0;
int supplierCount = 0;

void addDrink() {
    if (drinkCount < MAX_ITEMS) {
        std::cout << "Enter Drink ID: ";
        std::cin >> drinks[drinkCount].id;
        std::cout << "Enter Drink Name: ";
        std::cin >> drinks[drinkCount].name;
        std::cout << "Enter Drink Price: ";
        std::cin >> drinks[drinkCount].price;
        std::cout << "Enter Drink Quantity: ";
        std::cin >> drinks[drinkCount].quantity;
        drinkCount++;
    } else {
        std::cout << "Drink inventory is full.\n";
    }
}

void deleteDrink() {
    int id;
    std::cout << "Enter Drink ID to delete: ";
    std::cin >> id;
    for (int i = 0; i < drinkCount; i++) {
        if (drinks[i].id == id) {
            for (int j = i; j < drinkCount - 1; j++) {
                drinks[j] = drinks[j + 1];
            }
            drinkCount--;
            return;
        }
    }
    std::cout << "Drink not found.\n";
}

void updateDrink() {
    int id;
    std::cout << "Enter Drink ID to update: ";
    std::cin >> id;
    for (int i = 0; i < drinkCount; i++) {
        if (drinks[i].id == id) {
            std::cout << "Enter new Drink Name: ";
            std::cin >> drinks[i].name;
            std::cout << "Enter new Drink Price: ";
            std::cin >> drinks[i].price;
            std::cout << "Enter new Drink Quantity: ";
            std::cin >> drinks[i].quantity;
            return;
        }
    }
    std::cout << "Drink not found.\n";
}

void searchDrink() {
    int id;
    std::cout << "Enter Drink ID to search: ";
    std::cin >> id;
    for (int i = 0; i < drinkCount; i++) {
        if (drinks[i].id == id) {
            std::cout << "Drink ID: " << drinks[i].id << "\n";
            std::cout << "Drink Name: " << drinks[i].name << "\n";
            std::cout << "Drink Price: " << drinks[i].price << "\n";
            std::cout << "Drink Quantity: " << drinks[i].quantity << "\n";
            return;
        }
    }
    std::cout << "Drink not found.\n";
}

void displayDrinks() {
    std::cout << "Drinks Inventory:\n";
    for (int i = 0; i < drinkCount; i++) {
        std::cout << "ID: " << drinks[i].id << ", Name: " << drinks[i].name
                  << ", Price: " << drinks[i].price << ", Quantity: " << drinks[i].quantity << "\n";
    }
}

void addSupplier() {
    if (supplierCount < MAX_ITEMS) {
        std::cout << "Enter Supplier ID: ";
        std::cin >> suppliers[supplierCount].id;
        std::cout << "Enter Supplier Name: ";
        std::cin >> suppliers[supplierCount].name;
        std::cout << "Enter Supplier Contact: ";
        std::cin >> suppliers[supplierCount].contact;
        supplierCount++;
    } else {
        std::cout << "Supplier list is full.\n";
    }
}

void deleteSupplier() {
    int id;
    std::cout << "Enter Supplier ID to delete: ";
    std::cin >> id;
    for (int i = 0; i < supplierCount; i++) {
        if (suppliers[i].id == id) {
            for (int j = i; j < supplierCount - 1; j++) {
                suppliers[j] = suppliers[j + 1];
            }
            supplierCount--;
            return;
        }
    }
    std::cout << "Supplier not found.\n";
}

void updateSupplier() {
    int id;
    std::cout << "Enter Supplier ID to update: ";
    std::cin >> id;
    for (int i = 0; i < supplierCount; i++) {
        if (suppliers[i].id == id) {
            std::cout << "Enter new Supplier Name: ";
            std::cin >> suppliers[i].name;
            std::cout << "Enter new Supplier Contact: ";
            std::cin >> suppliers[i].contact;
            return;
        }
    }
    std::cout << "Supplier not found.\n";
}

void searchSupplier() {
    int id;
    std::cout << "Enter Supplier ID to search: ";
    std::cin >> id;
    for (int i = 0; i < supplierCount; i++) {
        if (suppliers[i].id == id) {
            std::cout << "Supplier ID: " << suppliers[i].id << "\n";
            std::cout << "Supplier Name: " << suppliers[i].name << "\n";
            std::cout << "Supplier Contact: " << suppliers[i].contact << "\n";
            return;
        }
    }
    std::cout << "Supplier not found.\n";
}

void displaySuppliers() {
    std::cout << "Suppliers List:\n";
    for (int i = 0; i < supplierCount; i++) {
        std::cout << "ID: " << suppliers[i].id << ", Name: " << suppliers[i].name
                  << ", Contact: " << suppliers[i].contact << "\n";
    }
}

int main() {
    int choice;
    do {
        std::cout << "1. Add Drink\n2. Delete Drink\n3. Update Drink\n4. Search Drink\n5. Display Drinks\n";
        std::cout << "6. Add Supplier\n7. Delete Supplier\n8. Update Supplier\n9. Search Supplier\n10. Display Suppliers\n";
        std::cout << "11. Exit\n";
        std::cout << "Enter choice: ";
        std::cin >> choice;
        switch (choice) {
            case 1: addDrink(); break;
            case 2: deleteDrink(); break;
            case 3: updateDrink(); break;
            case 4: searchDrink(); break;
            case 5: displayDrinks(); break;
            case 6: addSupplier(); break;
            case 7: deleteSupplier(); break;
            case 8: updateSupplier(); break;
            case 9: searchSupplier(); break;
            case 10: displaySuppliers(); break;
            case 11: std::cout << "Exiting...\n"; break;
            default: std::cout << "Invalid choice.\n";
        }
    } while (choice != 11);
    return 0;
}