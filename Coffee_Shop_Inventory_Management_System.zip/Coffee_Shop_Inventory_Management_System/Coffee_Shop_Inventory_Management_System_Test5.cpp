#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    int id;
    std::string name;
    double price;

    Drink(int id, std::string name, double price) : id(id), name(name), price(price) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, std::string name, std::string contact) : id(id), name(name), contact(contact) {}
};

class InventorySystem {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    int drinkIDCounter = 0;
    int supplierIDCounter = 0;

    int findDrinkIndexById(int id) {
        for (size_t i = 0; i < drinks.size(); i++) {
            if (drinks[i].id == id) return i;
        }
        return -1;
    }

    int findSupplierIndexById(int id) {
        for (size_t i = 0; i < suppliers.size(); i++) {
            if (suppliers[i].id == id) return i;
        }
        return -1;
    }

public:
    void addDrink(std::string name, double price) {
        drinks.push_back(Drink(drinkIDCounter++, name, price));
    }

    void deleteDrink(int id) {
        int index = findDrinkIndexById(id);
        if (index != -1) drinks.erase(drinks.begin() + index);
    }

    void updateDrink(int id, std::string name, double price) {
        int index = findDrinkIndexById(id);
        if (index != -1) {
            drinks[index].name = name;
            drinks[index].price = price;
        }
    }

    void searchDrink(int id) {
        int index = findDrinkIndexById(id);
        if (index != -1) {
            std::cout << "Drink ID: " << drinks[index].id
                      << ", Name: " << drinks[index].name
                      << ", Price: $" << drinks[index].price << "\n";
        }
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            std::cout << "Drink ID: " << drink.id
                      << ", Name: " << drink.name
                      << ", Price: $" << drink.price << "\n";
        }
    }

    void addSupplier(std::string name, std::string contact) {
        suppliers.push_back(Supplier(supplierIDCounter++, name, contact));
    }

    void deleteSupplier(int id) {
        int index = findSupplierIndexById(id);
        if (index != -1) suppliers.erase(suppliers.begin() + index);
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        int index = findSupplierIndexById(id);
        if (index != -1) {
            suppliers[index].name = name;
            suppliers[index].contact = contact;
        }
    }

    void searchSupplier(int id) {
        int index = findSupplierIndexById(id);
        if (index != -1) {
            std::cout << "Supplier ID: " << suppliers[index].id
                      << ", Name: " << suppliers[index].name
                      << ", Contact: " << suppliers[index].contact << "\n";
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id
                      << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventorySystem system;
    system.addDrink("Espresso", 3.5);
    system.addDrink("Latte", 4.0);
    system.displayDrinks();
    system.addSupplier("ABC Coffee Co.", "123-456-7890");
    system.addSupplier("XYZ Suppliers", "098-765-4321");
    system.displaySuppliers();
    system.searchDrink(0);
    system.searchSupplier(1);
    system.updateDrink(0, "Espresso", 3.75);
    system.updateSupplier(1, "XYZ Suppliers", "111-222-3333");
    system.deleteDrink(1);
    system.deleteSupplier(0);
    system.displayDrinks();
    system.displaySuppliers();
    return 0;
}