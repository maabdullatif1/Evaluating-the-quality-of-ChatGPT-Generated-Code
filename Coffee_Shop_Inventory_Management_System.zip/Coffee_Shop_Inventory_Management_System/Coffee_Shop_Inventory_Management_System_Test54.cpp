#include <iostream>
#include <vector>
#include <string>

struct Drink {
    int id;
    std::string name;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class CoffeeShopInventory {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    int nextDrinkId = 1;
    int nextSupplierId = 1;

    template<typename T>
    void displayItems(const std::vector<T>& items) {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << ", Name: " << item.name;
            if constexpr (std::is_same<T, Drink>::value) {
                std::cout << ", Price: " << item.price;
            } else {
                std::cout << ", Contact: " << item.contact;
            }
            std::cout << std::endl;
        }
    }

public:
    void addDrink(const std::string& name, double price) {
        drinks.push_back({nextDrinkId++, name, price});
    }
    
    void deleteDrink(int id) {
        drinks.erase(std::remove_if(drinks.begin(), drinks.end(), [id](const Drink& d) { return d.id == id; }), drinks.end());
    }

    void updateDrink(int id, const std::string& name, double price) {
        for (auto& d : drinks) {
            if (d.id == id) {
                d.name = name;
                d.price = price;
                return;
            }
        }
    }

    void searchDrink(const std::string& name) {
        for (const auto& d : drinks) {
            if (d.name == name) {
                std::cout << "ID: " << d.id << ", Name: " << d.name << ", Price: " << d.price << std::endl;
                return;
            }
        }
        std::cout << "Drink not found." << std::endl;
    }

    void displayDrinks() {
        displayItems(drinks);
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back({nextSupplierId++, name, contact});
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(), [id](const Supplier& s) { return s.id == id; }), suppliers.end());
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& s : suppliers) {
            if (s.id == id) {
                s.name = name;
                s.contact = contact;
                return;
            }
        }
    }

    void searchSupplier(const std::string& name) {
        for (const auto& s : suppliers) {
            if (s.name == name) {
                std::cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found." << std::endl;
    }

    void displaySuppliers() {
        displayItems(suppliers);
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink("Espresso", 2.5);
    inventory.addDrink("Latte", 3.5);
    inventory.displayDrinks();

    inventory.addSupplier("Supplier1", "123-456-7890");
    inventory.addSupplier("Supplier2", "098-765-4321");
    inventory.displaySuppliers();

    inventory.updateDrink(1, "Cappuccino", 3.0);
    inventory.displayDrinks();

    inventory.searchSupplier("Supplier1");
    inventory.deleteSupplier(2);
    inventory.displaySuppliers();

    return 0;
}