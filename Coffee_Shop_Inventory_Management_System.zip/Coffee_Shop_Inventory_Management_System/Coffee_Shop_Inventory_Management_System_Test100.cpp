#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    std::string name;
    double price;
    int quantity;

    Drink(std::string n, double p, int q) : name(n), price(p), quantity(q) {}
};

class Supplier {
public:
    std::string name;
    std::string contactInfo;

    Supplier(std::string n, std::string c) : name(n), contactInfo(c) {}
};

class InventorySystem {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

    int findDrinkIndex(const std::string& name) {
        for (size_t i = 0; i < drinks.size(); ++i) {
            if (drinks[i].name == name) return i;
        }
        return -1;
    }

    int findSupplierIndex(const std::string& name) {
        for (size_t i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].name == name) return i;
        }
        return -1;
    }

public:
    void addDrink(const Drink& drink) {
        if (findDrinkIndex(drink.name) == -1) {
            drinks.push_back(drink);
        }
    }

    void deleteDrink(const std::string& name) {
        int index = findDrinkIndex(name);
        if (index != -1) {
            drinks.erase(drinks.begin() + index);
        }
    }

    void updateDrink(const std::string& name, double price, int quantity) {
        int index = findDrinkIndex(name);
        if (index != -1) {
            drinks[index].price = price;
            drinks[index].quantity = quantity;
        }
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            std::cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << "\n";
        }
    }

    void addSupplier(const Supplier& supplier) {
        if (findSupplierIndex(supplier.name) == -1) {
            suppliers.push_back(supplier);
        }
    }

    void deleteSupplier(const std::string& name) {
        int index = findSupplierIndex(name);
        if (index != -1) {
            suppliers.erase(suppliers.begin() + index);
        }
    }

    void updateSupplier(const std::string& name, const std::string& contactInfo) {
        int index = findSupplierIndex(name);
        if (index != -1) {
            suppliers[index].contactInfo = contactInfo;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Name: " << supplier.name << ", Contact: " << supplier.contactInfo << "\n";
        }
    }

    void searchDrink(const std::string& name) {
        int index = findDrinkIndex(name);
        if (index != -1) {
            std::cout << "Found Drink - Name: " << drinks[index].name << ", Price: " << drinks[index].price << ", Quantity: " << drinks[index].quantity << "\n";
        } else {
            std::cout << "Drink not found\n";
        }
    }

    void searchSupplier(const std::string& name) {
        int index = findSupplierIndex(name);
        if (index != -1) {
            std::cout << "Found Supplier - Name: " << suppliers[index].name << ", Contact: " << suppliers[index].contactInfo << "\n";
        } else {
            std::cout << "Supplier not found\n";
        }
    }
};

int main() {
    InventorySystem system;

    system.addDrink(Drink("Espresso", 2.50, 100));
    system.addDrink(Drink("Cappuccino", 3.00, 50));
    system.displayDrinks();

    system.addSupplier(Supplier("Coffee Co", "123-456-7890"));
    system.addSupplier(Supplier("Beans Express", "987-654-3210"));
    system.displaySuppliers();

    system.updateDrink("Espresso", 2.75, 90);
    system.displayDrinks();

    system.deleteDrink("Cappuccino");
    system.displayDrinks();

    system.searchDrink("Espresso");
    system.searchDrink("Latte");

    system.updateSupplier("Coffee Co", "111-222-3333");
    system.displaySuppliers();

    system.deleteSupplier("Beans Express");
    system.displaySuppliers();

    system.searchSupplier("Coffee Co");
    system.searchSupplier("Beans Express");

    return 0;
}