#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Drink {
public:
    int id;
    string name;
    double price;
    int quantity;

    Drink(int id, string name, double price, int quantity)
        : id(id), name(name), price(price), quantity(quantity) {}
};

class Supplier {
public:
    int id;
    string name;
    string contact;

    Supplier(int id, string name, string contact)
        : id(id), name(name), contact(contact) {}
};

class CoffeeShopInventory {
public:
    vector<Drink> drinks;
    vector<Supplier> suppliers;

    void addDrink(int id, string name, double price, int quantity) {
        drinks.push_back(Drink(id, name, price, quantity));
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(int id, string name, double price, int quantity) {
        for (auto &drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                drink.quantity = quantity;
                break;
            }
        }
    }

    Drink* searchDrink(int id) {
        for (auto &drink : drinks) {
            if (drink.id == id) {
                return &drink;
            }
        }
        return nullptr;
    }

    void displayDrinks() {
        for (const auto &drink : drinks) {
            cout << "ID: " << drink.id << ", Name: " << drink.name
                 << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
        }
    }

    void addSupplier(int id, string name, string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name
                 << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;

    inventory.addDrink(1, "Latte", 4.5, 100);
    inventory.addDrink(2, "Espresso", 3.0, 150);
    inventory.displayDrinks();

    inventory.updateDrink(1, "Latte", 5.0, 90);
    inventory.displayDrinks();

    Drink* drink = inventory.searchDrink(2);
    if (drink) {
        cout << "Found Drink - ID: " << drink->id << ", Name: " << drink->name << endl;
    }

    inventory.deleteDrink(2);
    inventory.displayDrinks();

    inventory.addSupplier(1, "ABC Suppliers", "123-456-7890");
    inventory.addSupplier(2, "XYZ Suppliers", "987-654-3210");
    inventory.displaySuppliers();

    inventory.updateSupplier(1, "ABC Suppliers Inc.", "123-999-7890");
    inventory.displaySuppliers();

    Supplier* supplier = inventory.searchSupplier(2);
    if (supplier) {
        cout << "Found Supplier - ID: " << supplier->id << ", Name: " << supplier->name << endl;
    }

    inventory.deleteSupplier(2);
    inventory.displaySuppliers();

    return 0;
}