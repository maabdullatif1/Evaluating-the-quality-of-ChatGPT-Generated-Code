#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    int id;
    string name;
    double price;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

vector<Drink> drinks;
vector<Supplier> suppliers;

void addDrink() {
    Drink drink;
    cout << "Enter Drink ID: ";
    cin >> drink.id;
    cout << "Enter Drink Name: ";
    cin.ignore();
    getline(cin, drink.name);
    cout << "Enter Drink Price: ";
    cin >> drink.price;
    drinks.push_back(drink);
}

void addSupplier() {
    Supplier supplier;
    cout << "Enter Supplier ID: ";
    cin >> supplier.id;
    cout << "Enter Supplier Name: ";
    cin.ignore();
    getline(cin, supplier.name);
    cout << "Enter Supplier Contact: ";
    getline(cin, supplier.contact);
    suppliers.push_back(supplier);
}

void deleteDrink() {
    int id;
    cout << "Enter Drink ID to Delete: ";
    cin >> id;
    for (auto it = drinks.begin(); it != drinks.end(); ++it) {
        if (it->id == id) {
            drinks.erase(it);
            cout << "Drink Deleted\n";
            return;
        }
    }
    cout << "Drink Not Found\n";
}

void deleteSupplier() {
    int id;
    cout << "Enter Supplier ID to Delete: ";
    cin >> id;
    for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
        if (it->id == id) {
            suppliers.erase(it);
            cout << "Supplier Deleted\n";
            return;
        }
    }
    cout << "Supplier Not Found\n";
}

void updateDrink() {
    int id;
    cout << "Enter Drink ID to Update: ";
    cin >> id;
    for (auto& drink : drinks) {
        if (drink.id == id) {
            cout << "Enter New Name: ";
            cin.ignore();
            getline(cin, drink.name);
            cout << "Enter New Price: ";
            cin >> drink.price;
            cout << "Drink Updated\n";
            return;
        }
    }
    cout << "Drink Not Found\n";
}

void updateSupplier() {
    int id;
    cout << "Enter Supplier ID to Update: ";
    cin >> id;
    for (auto& supplier : suppliers) {
        if (supplier.id == id) {
            cout << "Enter New Name: ";
            cin.ignore();
            getline(cin, supplier.name);
            cout << "Enter New Contact: ";
            getline(cin, supplier.contact);
            cout << "Supplier Updated\n";
            return;
        }
    }
    cout << "Supplier Not Found\n";
}

void searchDrink() {
    int id;
    cout << "Enter Drink ID to Search: ";
    cin >> id;
    for (const auto& drink : drinks) {
        if (drink.id == id) {
            cout << "Name: " << drink.name << ", Price: " << drink.price << endl;
            return;
        }
    }
    cout << "Drink Not Found\n";
}

void searchSupplier() {
    int id;
    cout << "Enter Supplier ID to Search: ";
    cin >> id;
    for (const auto& supplier : suppliers) {
        if (supplier.id == id) {
            cout << "Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
            return;
        }
    }
    cout << "Supplier Not Found\n";
}

void displayDrinks() {
    cout << "Drinks List:\n";
    for (const auto& drink : drinks) {
        cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: " << drink.price << endl;
    }
}

void displaySuppliers() {
    cout << "Suppliers List:\n";
    for (const auto& supplier : suppliers) {
        cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Drink\n2. Add Supplier\n3. Delete Drink\n4. Delete Supplier\n";
        cout << "5. Update Drink\n6. Update Supplier\n7. Search Drink\n8. Search Supplier\n";
        cout << "9. Display Drinks\n10. Display Suppliers\n11. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addDrink(); break;
            case 2: addSupplier(); break;
            case 3: deleteDrink(); break;
            case 4: deleteSupplier(); break;
            case 5: updateDrink(); break;
            case 6: updateSupplier(); break;
            case 7: searchDrink(); break;
            case 8: searchSupplier(); break;
            case 9: displayDrinks(); break;
            case 10: displaySuppliers(); break;
            case 11: return 0;
            default: cout << "Invalid Choice\n";
        }
    }
}