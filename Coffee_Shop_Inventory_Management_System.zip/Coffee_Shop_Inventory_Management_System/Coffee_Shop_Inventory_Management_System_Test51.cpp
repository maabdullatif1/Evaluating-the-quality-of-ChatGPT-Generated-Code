#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    int id;
    string name;
    double price;
    int quantity;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

class InventoryManagementSystem {
    vector<Drink> drinks;
    vector<Supplier> suppliers;
    int drinkIdCounter = 0;
    int supplierIdCounter = 0;

public:
    void addDrink(const string& name, double price, int quantity) {
        Drink newDrink = { drinkIdCounter++, name, price, quantity };
        drinks.push_back(newDrink);
        cout << "Drink added successfully.\n";
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                cout << "Drink deleted successfully.\n";
                return;
            }
        }
        cout << "Drink not found.\n";
    }

    void updateDrink(int id, const string& name, double price, int quantity) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                drink.quantity = quantity;
                cout << "Drink updated successfully.\n";
                return;
            }
        }
        cout << "Drink not found.\n";
    }

    void searchDrink(int id) const {
        for (const auto& drink : drinks) {
            if (drink.id == id) {
                cout << "Drink ID: " << drink.id << ", Name: " << drink.name << ", Price: " 
                     << drink.price << ", Quantity: " << drink.quantity << "\n";
                return;
            }
        }
        cout << "Drink not found.\n";
    }

    void displayDrinks() const {
        cout << "Drinks:\n";
        for (const auto& drink : drinks) {
            cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: " 
                 << drink.price << ", Quantity: " << drink.quantity << "\n";
        }
    }

    void addSupplier(const string& name, const string& contact) {
        Supplier newSupplier = { supplierIdCounter++, name, contact };
        suppliers.push_back(newSupplier);
        cout << "Supplier added successfully.\n";
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                cout << "Supplier deleted successfully.\n";
                return;
            }
        }
        cout << "Supplier not found.\n";
    }

    void updateSupplier(int id, const string& name, const string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                cout << "Supplier updated successfully.\n";
                return;
            }
        }
        cout << "Supplier not found.\n";
    }

    void searchSupplier(int id) const {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name 
                     << ", Contact: " << supplier.contact << "\n";
                return;
            }
        }
        cout << "Supplier not found.\n";
    }

    void displaySuppliers() const {
        cout << "Suppliers:\n";
        for (const auto& supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name 
                 << ", Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addDrink("Espresso", 2.5, 30);
    ims.addDrink("Latte", 3.5, 20);
    ims.displayDrinks();
    ims.addSupplier("Coffee Beans Inc.", "123-456-7890");
    ims.displaySuppliers();
    ims.updateDrink(1, "Cappuccino", 3.0, 25);
    ims.searchDrink(0);
    ims.deleteDrink(0);
    ims.displayDrinks();
    return 0;
}