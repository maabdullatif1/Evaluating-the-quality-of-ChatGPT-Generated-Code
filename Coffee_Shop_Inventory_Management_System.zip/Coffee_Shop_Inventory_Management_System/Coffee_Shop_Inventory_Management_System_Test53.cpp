#include <iostream>
#include <vector>
#include <string>

struct Drink {
    int id;
    std::string name;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contactInfo;
};

class InventoryManagement {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    int drinkCounter = 0;
    int supplierCounter = 0;

public:
    void addDrink(const std::string& name, double price) {
        drinks.push_back({++drinkCounter, name, price});
    }

    void addSupplier(const std::string& name, const std::string& contactInfo) {
        suppliers.push_back({++supplierCounter, name, contactInfo});
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateDrink(int id, const std::string& name, double price) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    void searchDrink(int id) const {
        for (const auto& drink : drinks) {
            if (drink.id == id) {
                std::cout << "Drink ID: " << drink.id << ", Name: " << drink.name << ", Price: $" << drink.price << '\n';
                return;
            }
        }
        std::cout << "Drink not found\n";
    }

    void searchSupplier(int id) const {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contactInfo << '\n';
                return;
            }
        }
        std::cout << "Supplier not found\n";
    }

    void displayDrinks() const {
        std::cout << "Drinks List:\n";
        for (const auto& drink : drinks) {
            std::cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: $" << drink.price << '\n';
        }
    }

    void displaySuppliers() const {
        std::cout << "Suppliers List:\n";
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contactInfo << '\n';
        }
    }
};

int main() {
    InventoryManagement im;
    im.addDrink("Espresso", 2.5);
    im.addDrink("Cappuccino", 3.5);
    im.addSupplier("Coffee Beans Inc.", "contact@coffeebeans.com");
    im.addSupplier("Dairy Supplies Co.", "contact@dairysupplies.com");
    im.displayDrinks();
    im.displaySuppliers();
    im.updateDrink(1, "Espresso", 2.75);
    im.searchDrink(1);
    im.deleteSupplier(1);
    im.displaySuppliers();

    return 0;
}