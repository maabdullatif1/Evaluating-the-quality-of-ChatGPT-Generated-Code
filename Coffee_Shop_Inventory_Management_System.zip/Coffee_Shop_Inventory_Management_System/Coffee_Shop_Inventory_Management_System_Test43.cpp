#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    string name;
    double price;
    int quantity;
};

struct Supplier {
    string name;
    string contact;
};

class Inventory {
    vector<Drink> drinks;
    vector<Supplier> suppliers;

public:
    void addDrink(const string &name, double price, int quantity) {
        drinks.push_back({name, price, quantity});
    }

    void deleteDrink(const string &name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(const string &name, double price, int quantity) {
        for (auto &drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = quantity;
                break;
            }
        }
    }

    void searchDrink(const string &name) {
        for (const auto &drink : drinks) {
            if (drink.name == name) {
                cout << "Drink found: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
                return;
            }
        }
        cout << "Drink not found." << endl;
    }

    void displayDrinks() {
        cout << "Drinks List:" << endl;
        for (const auto &drink : drinks) {
            cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
        }
    }

    void addSupplier(const string &name, const string &contact) {
        suppliers.push_back({name, contact});
    }

    void deleteSupplier(const string &name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(const string &name, const string &contact) {
        for (auto &supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contact = contact;
                break;
            }
        }
    }
    
    void searchSupplier(const string &name) {
        for (const auto &supplier : suppliers) {
            if (supplier.name == name) {
                cout << "Supplier found: " << supplier.name << ", Contact: " << supplier.contact << endl;
                return;
            }
        }
        cout << "Supplier not found." << endl;
    }

    void displaySuppliers() {
        cout << "Suppliers List:" << endl;
        for (const auto &supplier : suppliers) {
            cout << "Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addDrink("Espresso", 2.5, 20);
    inventory.addDrink("Latte", 3.0, 30);
    inventory.displayDrinks();
    inventory.searchDrink("Espresso");
    inventory.updateDrink("Espresso", 2.75, 25);
    inventory.displayDrinks();
    inventory.deleteDrink("Latte");
    inventory.displayDrinks();

    inventory.addSupplier("Coffee Co", "123-456-7890");
    inventory.addSupplier("Beans Ltd", "987-654-3210");
    inventory.displaySuppliers();
    inventory.searchSupplier("Coffee Co");
    inventory.updateSupplier("Coffee Co", "111-222-3333");
    inventory.displaySuppliers();
    inventory.deleteSupplier("Beans Ltd");
    inventory.displaySuppliers();

    return 0;
}