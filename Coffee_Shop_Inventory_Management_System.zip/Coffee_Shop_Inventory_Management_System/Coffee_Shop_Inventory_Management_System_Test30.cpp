#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    Drink(int id, std::string name, double price) : id(id), name(name), price(price) {}
    int getId() const { return id; }
    std::string getName() const { return name; }
    double getPrice() const { return price; }
    void setName(std::string newName) { name = newName; }
    void setPrice(double newPrice) { price = newPrice; }

private:
    int id;
    std::string name;
    double price;
};

class Supplier {
public:
    Supplier(int id, std::string name, std::string contact) : id(id), name(name), contact(contact) {}
    int getId() const { return id; }
    std::string getName() const { return name; }
    std::string getContact() const { return contact; }
    void setName(std::string newName) { name = newName; }
    void setContact(std::string newContact) { contact = newContact; }

private:
    int id;
    std::string name;
    std::string contact;
};

class InventoryManagement {
public:
    void addDrink(int id, std::string name, double price) {
        drinks.push_back(Drink(id, name, price));
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->getId() == id) {
                drinks.erase(it);
                return;
            }
        }
    }

    void updateDrink(int id, std::string newName, double newPrice) {
        for (auto &drink : drinks) {
            if (drink.getId() == id) {
                drink.setName(newName);
                drink.setPrice(newPrice);
            }
        }
    }

    Drink* searchDrink(int id) {
        for (auto &drink : drinks) {
            if (drink.getId() == id) {
                return &drink;
            }
        }
        return nullptr;
    }

    void displayDrinks() {
        for (const auto &drink : drinks) {
            std::cout << "Drink ID: " << drink.getId() << ", Name: " << drink.getName() << ", Price: $" << drink.getPrice() << std::endl;
        }
    }

    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->getId() == id) {
                suppliers.erase(it);
                return;
            }
        }
    }

    void updateSupplier(int id, std::string newName, std::string newContact) {
        for (auto &supplier : suppliers) {
            if (supplier.getId() == id) {
                supplier.setName(newName);
                supplier.setContact(newContact);
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.getId() == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.getId() << ", Name: " << supplier.getName() << ", Contact: " << supplier.getContact() << std::endl;
        }
    }

private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
};

int main() {
    InventoryManagement inventory;
    inventory.addDrink(1, "Espresso", 2.50);
    inventory.addDrink(2, "Latte", 3.50);
    inventory.addSupplier(1, "CoffeeBeans Ltd.", "123-456-7890");
    inventory.addSupplier(2, "MilkServices Inc.", "098-765-4321");
    
    inventory.displayDrinks();
    inventory.displaySuppliers();
    
    return 0;
}