#include <iostream>
#include <vector>
#include <string>

struct Drink {
    std::string name;
    double price;
    int quantity;
};

struct Supplier {
    std::string name;
    std::string contactInfo;
};

class InventoryManagementSystem {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(const std::string& name, double price, int quantity) {
        drinks.push_back({name, price, quantity});
    }

    void deleteDrink(const std::string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(const std::string& name, double newPrice, int newQuantity) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = newPrice;
                drink.quantity = newQuantity;
                break;
            }
        }
    }

    void searchDrink(const std::string& name) const {
        for (const auto& drink : drinks) {
            if (drink.name == name) {
                std::cout << "Drink: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << std::endl;
                return;
            }
        }
        std::cout << "Drink not found" << std::endl;
    }

    void displayDrinks() const {
        for (const auto& drink : drinks) {
            std::cout << "Drink: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << std::endl;
        }
    }

    void addSupplier(const std::string& name, const std::string& contactInfo) {
        suppliers.push_back({name, contactInfo});
    }

    void deleteSupplier(const std::string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(const std::string& name, const std::string& newContactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contactInfo = newContactInfo;
                break;
            }
        }
    }

    void searchSupplier(const std::string& name) const {
        for (const auto& supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Supplier: " << supplier.name << ", Contact Info: " << supplier.contactInfo << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found" << std::endl;
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier: " << supplier.name << ", Contact Info: " << supplier.contactInfo << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addDrink("Espresso", 2.50, 100);
    ims.addDrink("Latte", 3.50, 150);
    ims.displayDrinks();

    ims.addSupplier("Coffee World", "coffee@world.com");
    ims.addSupplier("Bean Brothers", "beans@brothers.com");
    ims.displaySuppliers();

    ims.searchDrink("Espresso");
    ims.updateDrink("Espresso", 2.75, 90);
    ims.searchDrink("Espresso");

    ims.searchSupplier("Coffee World");
    ims.updateSupplier("Coffee World", "world@coffee.com");
    ims.searchSupplier("Coffee World");

    ims.deleteDrink("Latte");
    ims.displayDrinks();

    ims.deleteSupplier("Bean Brothers");
    ims.displaySuppliers();

    return 0;
}