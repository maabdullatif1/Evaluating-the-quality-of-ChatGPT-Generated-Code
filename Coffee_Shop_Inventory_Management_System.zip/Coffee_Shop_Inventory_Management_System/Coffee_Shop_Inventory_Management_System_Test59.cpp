#include <iostream>
#include <vector>
#include <string>

struct Drink {
    std::string name;
    double price;
    int quantity;
};

struct Supplier {
    std::string name;
    std::string contact_info;
};

class CoffeeShopInventory {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(const std::string& name, double price, int quantity) {
        drinks.push_back({name, price, quantity});
    }

    void deleteDrink(const std::string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(const std::string& name, double price, int quantity) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = quantity;
                break;
            }
        }
    }

    Drink* searchDrink(const std::string& name) {
        for (auto& drink : drinks) {
            if (drink.name == name) return &drink;
        }
        return nullptr;
    }

    void addSupplier(const std::string& name, const std::string& contact_info) {
        suppliers.push_back({name, contact_info});
    }

    void deleteSupplier(const std::string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    Supplier* searchSupplier(const std::string& name) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) return &supplier;
        }
        return nullptr;
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            std::cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << '\n';
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Name: " << supplier.name << ", Contact Info: " << supplier.contact_info << '\n';
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink("Latte", 3.50, 20);
    inventory.addDrink("Espresso", 2.00, 30);
    inventory.addSupplier("Acme Coffee Supplies", "acme@example.com");
    inventory.addSupplier("Bean Traders", "contact@beantraders.com");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    return 0;
}