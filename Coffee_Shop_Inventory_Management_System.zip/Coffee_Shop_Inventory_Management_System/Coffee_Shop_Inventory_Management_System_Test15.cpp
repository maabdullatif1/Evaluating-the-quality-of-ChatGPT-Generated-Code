#include <iostream>
#include <vector>
#include <string>

struct Drink {
    std::string name;
    double price;
    int stock;
};

struct Supplier {
    std::string name;
    std::string contactInfo;
};

class CoffeeShopInventory {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(const std::string& name, double price, int stock) {
        drinks.push_back({name, price, stock});
    }

    void deleteDrink(const std::string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(const std::string& name, double price, int stock) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.stock = stock;
                break;
            }
        }
    }

    void searchDrink(const std::string& name) const {
        for (const auto& drink : drinks) {
            if (drink.name == name) {
                std::cout << "Drink: " << drink.name << ", Price: " << drink.price << ", Stock: " << drink.stock << std::endl;
                return;
            }
        }
        std::cout << "Drink not found" << std::endl;
    }

    void displayDrinks() const {
        for (const auto& drink : drinks) {
            std::cout << "Drink: " << drink.name << ", Price: " << drink.price << ", Stock: " << drink.stock << std::endl;
        }
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back({name, contact});
    }

    void deleteSupplier(const std::string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contactInfo = contact;
                break;
            }
        }
    }

    void searchSupplier(const std::string& name) const {
        for (const auto& supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Supplier: " << supplier.name << ", Contact: " << supplier.contactInfo << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found" << std::endl;
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier: " << supplier.name << ", Contact: " << supplier.contactInfo << std::endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink("Espresso", 2.5, 100);
    inventory.addDrink("Latte", 3.5, 50);
    inventory.addSupplier("ACME Supplies", "acme@example.com");
    inventory.addSupplier("Coffee Co.", "contact@coffeeco.com");
    std::cout << "Initial Inventory:" << std::endl;
    inventory.displayDrinks();
    std::cout << "\nSuppliers List:" << std::endl;
    inventory.displaySuppliers();
    inventory.searchDrink("Espresso");
    inventory.updateDrink("Espresso", 2.75, 120);
    inventory.displayDrinks();
    inventory.searchSupplier("Coffee Co.");
    inventory.deleteSupplier("ACME Supplies");
    inventory.displaySuppliers();
    return 0;
}