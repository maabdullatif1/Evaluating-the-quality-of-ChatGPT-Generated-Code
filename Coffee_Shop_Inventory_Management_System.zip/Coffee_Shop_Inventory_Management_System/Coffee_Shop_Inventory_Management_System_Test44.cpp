#include <iostream>
#include <string>
#include <vector>

struct Drink {
    int id;
    std::string name;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class CoffeeShopInventory {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    int nextDrinkId;
    int nextSupplierId;

    Drink* findDrink(int id) {
        for (auto& drink : drinks) {
            if (drink.id == id) return &drink;
        }
        return nullptr;
    }

    Supplier* findSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) return &supplier;
        }
        return nullptr;
    }

public:
    CoffeeShopInventory() : nextDrinkId(1), nextSupplierId(1) {}

    void addDrink(const std::string& name, double price) {
        drinks.push_back({nextDrinkId++, name, price});
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(int id, const std::string& name, double price) {
        Drink* drink = findDrink(id);
        if (drink) {
            drink->name = name;
            drink->price = price;
        }
    }

    void displayDrinks() const {
        for (const auto& drink : drinks) {
            std::cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: " << drink.price << std::endl;
        }
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back({nextSupplierId++, name, contact});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        Supplier* supplier = findSupplier(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink("Espresso", 2.5);
    inventory.addDrink("Latte", 3.0);
    inventory.addSupplier("Supplier1", "supplier1@example.com");
    inventory.addSupplier("Supplier2", "supplier2@example.com");

    std::cout << "Drinks:" << std::endl;
    inventory.displayDrinks();

    std::cout << "Suppliers:" << std::endl;
    inventory.displaySuppliers();

    inventory.updateDrink(1, "Double Espresso", 2.8);
    inventory.deleteSupplier(1);

    std::cout << "Updated Drinks:" << std::endl;
    inventory.displayDrinks();

    std::cout << "Updated Suppliers:" << std::endl;
    inventory.displaySuppliers();

    return 0;
}