#include <iostream>
#include <vector>
#include <string>

struct Drink {
    int id;
    std::string name;
    double price;
    int quantity;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventoryManagement {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    int drinkCounter;
    int supplierCounter;

public:
    InventoryManagement() : drinkCounter(0), supplierCounter(0) {}

    void addDrink(const std::string& name, double price, int quantity) {
        drinks.push_back({++drinkCounter, name, price, quantity});
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(int id, const std::string& name, double price, int quantity) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                drink.quantity = quantity;
                break;
            }
        }
    }

    Drink* searchDrink(int id) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                return &drink;
            }
        }
        return nullptr;
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            std::cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << std::endl;
        }
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back({++supplierCounter, name, contact});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagement inventory;

    inventory.addDrink("Espresso", 2.5, 100);
    inventory.addDrink("Latte", 3.5, 80);
    inventory.displayDrinks();

    inventory.addSupplier("Beans Co", "123-456-7890");
    inventory.addSupplier("Milk Suppliers", "098-765-4321");
    inventory.displaySuppliers();

    return 0;
}