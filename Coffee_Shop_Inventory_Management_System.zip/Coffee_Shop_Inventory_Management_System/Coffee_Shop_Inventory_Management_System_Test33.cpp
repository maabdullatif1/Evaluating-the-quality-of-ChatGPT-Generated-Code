#include <iostream>
#include <vector>
#include <string>

struct Drink {
    int id;
    std::string name;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventoryManagement {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    int drinkIdCounter = 0;
    int supplierIdCounter = 0;

    template <typename T>
    T* searchById(std::vector<T>& list, int id) {
        for (auto& item : list) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

public:
    void addDrink(const std::string& name, double price) {
        drinks.push_back({drinkIdCounter++, name, price});
    }

    void deleteDrink(int id) {
        drinks.erase(std::remove_if(drinks.begin(), drinks.end(), [id](const Drink& d) { return d.id == id; }), drinks.end());
    }

    void updateDrink(int id, const std::string& name, double price) {
        Drink* drink = searchById(drinks, id);
        if (drink) {
            drink->name = name;
            drink->price = price;
        }
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back({supplierIdCounter++, name, contact});
    }

    void deleteSupplier(int id) {
        suppliers.erase(std::remove_if(suppliers.begin(), suppliers.end(), [id](const Supplier& s) { return s.id == id; }), suppliers.end());
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        Supplier* supplier = searchById(suppliers, id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    Drink* searchDrink(int id) {
        return searchById(drinks, id);
    }

    Supplier* searchSupplier(int id) {
        return searchById(suppliers, id);
    }

    void displayDrinks() const {
        for (const auto& drink : drinks) {
            std::cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: " << drink.price << "\n";
        }
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addDrink("Espresso", 2.5);
    inventory.addDrink("Latte", 3.0);
    inventory.displayDrinks();
    inventory.addSupplier("Acme Supplies", "contact@acme.com");
    inventory.displaySuppliers();
    return 0;
}