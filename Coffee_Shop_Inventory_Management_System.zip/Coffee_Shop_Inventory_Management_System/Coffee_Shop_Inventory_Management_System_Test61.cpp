#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    std::string name;
    double price;
    int quantity;

    Drink(std::string n, double p, int q) : name(n), price(p), quantity(q) {}
};

class Supplier {
public:
    std::string name;
    std::string contact;

    Supplier(std::string n, std::string c) : name(n), contact(c) {}
};

class Inventory {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(const std::string& name, double price, int quantity) {
        drinks.push_back(Drink(name, price, quantity));
    }

    void deleteDrink(const std::string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                return;
            }
        }
    }

    void updateDrink(const std::string& name, double price, int quantity) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = quantity;
                return;
            }
        }
    }

    Drink* searchDrink(const std::string& name) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                return &drink;
            }
        }
        return nullptr;
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            std::cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << std::endl;
        }
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back(Supplier(name, contact));
    }

    void deleteSupplier(const std::string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                return;
            }
        }
    }

    Supplier* searchSupplier(const std::string& name) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    Inventory inventory;

    inventory.addDrink("Espresso", 2.5, 100);
    inventory.addDrink("Latte", 3.5, 50);
    inventory.addSupplier("Coffee Beans Ltd", "123-456-7890");
    inventory.addSupplier("Dairy Supplies Inc", "098-765-4321");

    std::cout << "Drinks:" << std::endl;
    inventory.displayDrinks();

    std::cout << "Suppliers:" << std::endl;
    inventory.displaySuppliers();

    return 0;
}