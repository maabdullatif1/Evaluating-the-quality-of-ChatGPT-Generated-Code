#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    int id;
    string name;
    double price;
};

struct Supplier {
    int id;
    string name;
    string contactInfo;
};

vector<Drink> drinks;
vector<Supplier> suppliers;

int generateId() {
    static int id = 0;
    return ++id;
}

void addDrink() {
    Drink drink;
    drink.id = generateId();
    cout << "Enter drink name: ";
    cin >> drink.name;
    cout << "Enter drink price: ";
    cin >> drink.price;
    drinks.push_back(drink);
}

void deleteDrink() {
    int id;
    cout << "Enter drink ID to delete: ";
    cin >> id;
    for (auto it = drinks.begin(); it != drinks.end(); ++it) {
        if (it->id == id) {
            drinks.erase(it);
            break;
        }
    }
}

void updateDrink() {
    int id;
    cout << "Enter drink ID to update: ";
    cin >> id;
    for (auto& drink : drinks) {
        if (drink.id == id) {
            cout << "Enter new name: ";
            cin >> drink.name;
            cout << "Enter new price: ";
            cin >> drink.price;
            break;
        }
    }
}

void searchDrink() {
    int id;
    cout << "Enter drink ID to search: ";
    cin >> id;
    for (const auto& drink : drinks) {
        if (drink.id == id) {
            cout << "Drink ID: " << drink.id << " Name: " << drink.name << " Price: " << drink.price << endl;
            return;
        }
    }
    cout << "Drink not found" << endl;
}

void displayDrinks() {
    for (const auto& drink : drinks) {
        cout << "Drink ID: " << drink.id << " Name: " << drink.name << " Price: " << drink.price << endl;
    }
}

void addSupplier() {
    Supplier supplier;
    supplier.id = generateId();
    cout << "Enter supplier name: ";
    cin >> supplier.name;
    cout << "Enter supplier contact info: ";
    cin >> supplier.contactInfo;
    suppliers.push_back(supplier);
}

void deleteSupplier() {
    int id;
    cout << "Enter supplier ID to delete: ";
    cin >> id;
    for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
        if (it->id == id) {
            suppliers.erase(it);
            break;
        }
    }
}

void updateSupplier() {
    int id;
    cout << "Enter supplier ID to update: ";
    cin >> id;
    for (auto& supplier : suppliers) {
        if (supplier.id == id) {
            cout << "Enter new name: ";
            cin >> supplier.name;
            cout << "Enter new contact info: ";
            cin >> supplier.contactInfo;
            break;
        }
    }
}

void searchSupplier() {
    int id;
    cout << "Enter supplier ID to search: ";
    cin >> id;
    for (const auto& supplier : suppliers) {
        if (supplier.id == id) {
            cout << "Supplier ID: " << supplier.id << " Name: " << supplier.name << " Contact Info: " << supplier.contactInfo << endl;
            return;
        }
    }
    cout << "Supplier not found" << endl;
}

void displaySuppliers() {
    for (const auto& supplier : suppliers) {
        cout << "Supplier ID: " << supplier.id << " Name: " << supplier.name << " Contact Info: " << supplier.contactInfo << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Drink\n2. Delete Drink\n3. Update Drink\n4. Search Drink\n5. Display Drinks\n";
        cout << "6. Add Supplier\n7. Delete Supplier\n8. Update Supplier\n9. Search Supplier\n10. Display Suppliers\n11. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addDrink(); break;
            case 2: deleteDrink(); break;
            case 3: updateDrink(); break;
            case 4: searchDrink(); break;
            case 5: displayDrinks(); break;
            case 6: addSupplier(); break;
            case 7: deleteSupplier(); break;
            case 8: updateSupplier(); break;
            case 9: searchSupplier(); break;
            case 10: displaySuppliers(); break;
        }
    } while (choice != 11);
    
    return 0;
}