#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    std::string name;
    double price;
    int quantity;
    Drink(std::string name, double price, int quantity) : name(name), price(price), quantity(quantity) {}
};

class Supplier {
public:
    std::string name;
    std::string contact;
    Supplier(std::string name, std::string contact) : name(name), contact(contact) {}
};

class InventoryManagement {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(std::string name, double price, int quantity) {
        drinks.push_back(Drink(name, price, quantity));
    }
    
    void deleteDrink(std::string name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }
    
    void updateDrink(std::string name, double price, int quantity) {
        for (auto &drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = quantity;
            }
        }
    }
    
    void searchDrink(std::string name) {
        for (auto &drink : drinks) {
            if (drink.name == name) {
                std::cout << "Drink found: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << std::endl;
                return;
            }
        }
        std::cout << "Drink not found." << std::endl;
    }
    
    void displayDrinks() {
        for (auto &drink : drinks) {
            std::cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << std::endl;
        }
    }
    
    void addSupplier(std::string name, std::string contact) {
        suppliers.push_back(Supplier(name, contact));
    }
    
    void deleteSupplier(std::string name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(std::string name, std::string contact) {
        for (auto &supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contact = contact;
            }
        }
    }
    
    void searchSupplier(std::string name) {
        for (auto &supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Supplier found: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found." << std::endl;
    }
    
    void displaySuppliers() {
        for (auto &supplier : suppliers) {
            std::cout << "Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagement inventory;
    inventory.addDrink("Latte", 3.5, 30);
    inventory.addDrink("Cappuccino", 3.0, 20);
    inventory.displayDrinks();
    
    inventory.updateDrink("Latte", 3.7, 25);
    inventory.searchDrink("Latte");
    
    inventory.addSupplier("Coffee Beans Inc.", "123-456-7890");
    inventory.displaySuppliers();
    
    inventory.updateSupplier("Coffee Beans Inc.", "987-654-3210");
    inventory.searchSupplier("Coffee Beans Inc.");

    inventory.deleteDrink("Cappuccino");
    inventory.displayDrinks();
    
    return 0;
}