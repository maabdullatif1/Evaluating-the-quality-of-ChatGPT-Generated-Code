#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    int id;
    std::string name;
    double price;

    Drink(int i, std::string n, double p) : id(i), name(n), price(p) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInfo;

    Supplier(int i, std::string n, std::string c) : id(i), name(n), contactInfo(c) {}
};

class InventoryManagement {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    int drinkIdCounter = 1;
    int supplierIdCounter = 1;

public:
    void addDrink(std::string name, double price) {
        drinks.push_back(Drink(drinkIdCounter++, name, price));
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                return;
            }
        }
    }

    void updateDrink(int id, std::string newName, double newPrice) {
        for (auto &drink : drinks) {
            if (drink.id == id) {
                drink.name = newName;
                drink.price = newPrice;
                return;
            }
        }
    }

    Drink* searchDrink(int id) {
        for (auto &drink : drinks) {
            if (drink.id == id) {
                return &drink;
            }
        }
        return nullptr;
    }

    void displayDrinks() {
        for (const auto &drink : drinks) {
            std::cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: $" << drink.price << "\n";
        }
    }

    void addSupplier(std::string name, std::string contactInfo) {
        suppliers.push_back(Supplier(supplierIdCounter++, name, contactInfo));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                return;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact Info: " << supplier.contactInfo << "\n";
        }
    }
};

int main() {
    InventoryManagement inventory;

    inventory.addDrink("Espresso", 2.50);
    inventory.addDrink("Latte", 3.50);
    inventory.addSupplier("Premium Beans Co.", "contact@beans.com");
    inventory.displayDrinks();
    inventory.displaySuppliers();

    inventory.updateDrink(1, "Double Espresso", 3.00);
    inventory.displayDrinks();

    return 0;
}