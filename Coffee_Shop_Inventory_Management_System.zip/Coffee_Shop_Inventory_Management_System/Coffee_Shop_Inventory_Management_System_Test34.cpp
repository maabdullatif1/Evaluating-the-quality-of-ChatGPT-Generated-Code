#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Drink {
public:
    int id;
    string name;
    double price;
    int quantity;
    
    Drink(int id, string name, double price, int quantity)
        : id(id), name(name), price(price), quantity(quantity) {}
};

class Supplier {
public:
    int id;
    string name;
    string contactInfo;
    
    Supplier(int id, string name, string contactInfo)
        : id(id), name(name), contactInfo(contactInfo) {}
};

class CoffeeShopInventory {
    vector<Drink> drinks;
    vector<Supplier> suppliers;

public:
    void addDrink(int id, string name, double price, int quantity) {
        drinks.push_back(Drink(id, name, price, quantity));
    }
    
    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }
    
    void updateDrink(int id, string name, double price, int quantity) {
        for (auto &drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                drink.quantity = quantity;
                break;
            }
        }
    }
    
    void searchDrink(int id) {
        for (const auto &drink : drinks) {
            if (drink.id == id) {
                cout << "Drink ID: " << drink.id << ", Name: " << drink.name;
                cout << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
                return;
            }
        }
        cout << "Drink not found!" << endl;
    }
    
    void displayDrinks() {
        if (drinks.empty()) {
            cout << "No drinks available." << endl;
        } else {
            for (const auto &drink : drinks) {
                cout << "Drink ID: " << drink.id << ", Name: " << drink.name;
                cout << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
            }
        }
    }
    
    void addSupplier(int id, string name, string contactInfo) {
        suppliers.push_back(Supplier(id, name, contactInfo));
    }
    
    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }
    
    void updateSupplier(int id, string name, string contactInfo) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }
    
    void searchSupplier(int id) {
        for (const auto &supplier : suppliers) {
            if (supplier.id == id) {
                cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name;
                cout << ", Contact Info: " << supplier.contactInfo << endl;
                return;
            }
        }
        cout << "Supplier not found!" << endl;
    }
    
    void displaySuppliers() {
        if (suppliers.empty()) {
            cout << "No suppliers available." << endl;
        } else {
            for (const auto &supplier : suppliers) {
                cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name;
                cout << ", Contact Info: " << supplier.contactInfo << endl;
            }
        }
    }
};

int main() {
    CoffeeShopInventory inventory;

    inventory.addDrink(1, "Espresso", 2.50, 100);
    inventory.addDrink(2, "Latte", 3.50, 80);
    inventory.addSupplier(1, "Coffee Beans Inc.", "contact@coffeebeans.com");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    inventory.searchDrink(1);
    inventory.searchSupplier(1);

    inventory.updateDrink(2, "Latte", 3.75, 90);
    inventory.updateSupplier(1, "Beans Supply Co.", "info@beansco.com");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    inventory.deleteDrink(1);
    inventory.deleteSupplier(1);

    inventory.displayDrinks();
    inventory.displaySuppliers();

    return 0;
}