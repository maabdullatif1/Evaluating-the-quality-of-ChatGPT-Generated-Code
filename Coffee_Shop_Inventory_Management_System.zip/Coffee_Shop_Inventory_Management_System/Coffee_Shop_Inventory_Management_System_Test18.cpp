#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    int id;
    std::string name;
    double price;

    Drink(int id, std::string name, double price) : id(id), name(name), price(price) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int id, std::string name, std::string contact) : id(id), name(name), contact(contact) {}
};

class Inventory {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    int drinkIdCounter = 0;
    int supplierIdCounter = 0;

    int findDrinkIndexById(int id) {
        for (size_t i = 0; i < drinks.size(); ++i) {
            if (drinks[i].id == id) return i;
        }
        return -1;
    }

    int findSupplierIndexById(int id) {
        for (size_t i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].id == id) return i;
        }
        return -1;
    }

public:
    void addDrink(std::string name, double price) {
        drinks.push_back(Drink(drinkIdCounter++, name, price));
    }

    void deleteDrink(int id) {
        int index = findDrinkIndexById(id);
        if (index != -1) drinks.erase(drinks.begin() + index);
    }

    void updateDrink(int id, std::string name, double price) {
        int index = findDrinkIndexById(id);
        if (index != -1) {
            drinks[index].name = name;
            drinks[index].price = price;
        }
    }

    void searchDrink(int id) {
        int index = findDrinkIndexById(id);
        if (index != -1) {
            std::cout << "Drink Found: ID=" << drinks[index].id
                      << ", Name=" << drinks[index].name
                      << ", Price=" << drinks[index].price << std::endl;
        } else {
            std::cout << "Drink not found" << std::endl;
        }
    }

    void displayDrinks() {
        for (const auto &drink : drinks) {
            std::cout << "ID: " << drink.id << ", Name: " << drink.name
                      << ", Price: " << drink.price << std::endl;
        }
    }

    void addSupplier(std::string name, std::string contact) {
        suppliers.push_back(Supplier(supplierIdCounter++, name, contact));
    }

    void deleteSupplier(int id) {
        int index = findSupplierIndexById(id);
        if (index != -1) suppliers.erase(suppliers.begin() + index);
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        int index = findSupplierIndexById(id);
        if (index != -1) {
            suppliers[index].name = name;
            suppliers[index].contact = contact;
        }
    }

    void searchSupplier(int id) {
        int index = findSupplierIndexById(id);
        if (index != -1) {
            std::cout << "Supplier Found: ID=" << suppliers[index].id
                      << ", Name=" << suppliers[index].name
                      << ", Contact=" << suppliers[index].contact << std::endl;
        } else {
            std::cout << "Supplier not found" << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    Inventory inventory;
    
    inventory.addDrink("Latte", 3.5);
    inventory.addDrink("Espresso", 2.0);
    inventory.displayDrinks();

    inventory.addSupplier("Coffee Beans Co", "123-456-7890");
    inventory.addSupplier("Fresh Milk Ltd", "555-678-1234");
    inventory.displaySuppliers();

    inventory.updateDrink(0, "Vanilla Latte", 3.75);
    inventory.searchDrink(0);

    inventory.deleteSupplier(1);
    inventory.displaySuppliers();

    return 0;
}