#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    string name;
    double price;
    int quantity;

    Drink(string n, double p, int q) : name(n), price(p), quantity(q) {}
};

struct Supplier {
    string name;
    string contact;

    Supplier(string n, string c) : name(n), contact(c) {}
};

class CoffeeShopInventory {
private:
    vector<Drink> drinks;
    vector<Supplier> suppliers;

public:
    void addDrink(string name, double price, int quantity) {
        drinks.push_back(Drink(name, price, quantity));
    }

    void deleteDrink(string name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(string name, double price, int quantity) {
        for (auto &drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = quantity;
                break;
            }
        }
    }

    void searchDrink(string name) {
        for (const auto &drink : drinks) {
            if (drink.name == name) {
                cout << "Drink: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
                return;
            }
        }
        cout << "Drink not found" << endl;
    }

    void displayDrinks() {
        for (const auto &drink : drinks) {
            cout << "Drink: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
        }
    }

    void addSupplier(string name, string contact) {
        suppliers.push_back(Supplier(name, contact));
    }

    void deleteSupplier(string name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(string name, string contact) {
        for (auto &supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(string name) {
        for (const auto &supplier : suppliers) {
            if (supplier.name == name) {
                cout << "Supplier: " << supplier.name << ", Contact: " << supplier.contact << endl;
                return;
            }
        }
        cout << "Supplier not found" << endl;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            cout << "Supplier: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;

    inventory.addDrink("Espresso", 2.5, 100);
    inventory.addDrink("Latte", 3.5, 80);
    inventory.addSupplier("CoffeeCo", "123-456-7890");
    inventory.addSupplier("BeanSupplies", "098-765-4321");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    inventory.searchDrink("Latte");
    inventory.searchSupplier("CoffeeCo");

    inventory.updateDrink("Latte", 4.0, 70);
    inventory.updateSupplier("CoffeeCo", "111-222-3333");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    inventory.deleteDrink("Espresso");
    inventory.deleteSupplier("BeanSupplies");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    return 0;
}