#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Drink {
    int id;
    string name;
    double price;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

class CoffeeShopInventory {
private:
    vector<Drink> drinks;
    vector<Supplier> suppliers;
    int nextDrinkId = 1;
    int nextSupplierId = 1;

    Drink* findDrinkById(int id) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                return &drink;
            }
        }
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

public:
    void addDrink(const string& name, double price) {
        drinks.push_back({nextDrinkId++, name, price});
    }
    
    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }
    
    void updateDrink(int id, const string& name, double price) {
        Drink* drink = findDrinkById(id);
        if (drink) {
            drink->name = name;
            drink->price = price;
        }
    }
    
    Drink* searchDrink(int id) {
        return findDrinkById(id);
    }
    
    void displayDrinks() {
        for (const auto& drink : drinks) {
            cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: " << drink.price << endl;
        }
    }
    
    void addSupplier(const string& name, const string& contact) {
        suppliers.push_back({nextSupplierId++, name, contact});
    }
    
    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const string& name, const string& contact) {
        Supplier* supplier = findSupplierById(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    Supplier* searchSupplier(int id) {
        return findSupplierById(id);
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink("Espresso", 2.5);
    inventory.addDrink("Latte", 3.5);
    inventory.addSupplier("ABC Coffee Beans", "123-456-7890");
    inventory.addSupplier("XYZ Milk Co.", "987-654-3210");
    
    cout << "Drinks in the inventory:" << endl;
    inventory.displayDrinks();
    
    cout << "\nSuppliers in the inventory:" << endl;
    inventory.displaySuppliers();

    inventory.updateDrink(1, "Strong Espresso", 2.75);
    inventory.updateSupplier(1, "ABC Premium Coffee Beans", "123-456-7899");

    cout << "\nUpdated drinks in the inventory:" << endl;
    inventory.displayDrinks();

    cout << "\nUpdated suppliers in the inventory:" << endl;
    inventory.displaySuppliers();

    inventory.deleteDrink(2);
    inventory.deleteSupplier(2);

    cout << "\nDrinks after deletions:" << endl;
    inventory.displayDrinks();

    cout << "\nSuppliers after deletions:" << endl;
    inventory.displaySuppliers();

    return 0;
}