#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Drink {
    int id;
    string name;
    double price;
    int quantity;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

vector<Drink> drinks;
vector<Supplier> suppliers;

int getNextDrinkId() {
    return drinks.empty() ? 1 : drinks.back().id + 1;
}

int getNextSupplierId() {
    return suppliers.empty() ? 1 : suppliers.back().id + 1;
}

void addDrink() {
    Drink drink;
    drink.id = getNextDrinkId();
    cout << "Enter drink name: ";
    cin >> drink.name;
    cout << "Enter drink price: ";
    cin >> drink.price;
    cout << "Enter drink quantity: ";
    cin >> drink.quantity;
    drinks.push_back(drink);
}

void deleteDrink(int id) {
    for (auto it = drinks.begin(); it != drinks.end(); ++it) {
        if (it->id == id) {
            drinks.erase(it);
            break;
        }
    }
}

void updateDrink(int id) {
    for (auto &drink : drinks) {
        if (drink.id == id) {
            cout << "Enter new name: ";
            cin >> drink.name;
            cout << "Enter new price: ";
            cin >> drink.price;
            cout << "Enter new quantity: ";
            cin >> drink.quantity;
            break;
        }
    }
}

void searchDrink(int id) {
    for (const auto &drink : drinks) {
        if (drink.id == id) {
            cout << "ID: " << drink.id << ", Name: " << drink.name
                 << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
        }
    }
}

void displayDrinks() {
    for (const auto &drink : drinks) {
        cout << "ID: " << drink.id << ", Name: " << drink.name
             << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
    }
}

void addSupplier() {
    Supplier supplier;
    supplier.id = getNextSupplierId();
    cout << "Enter supplier name: ";
    cin >> supplier.name;
    cout << "Enter supplier contact: ";
    cin >> supplier.contact;
    suppliers.push_back(supplier);
}

void deleteSupplier(int id) {
    for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
        if (it->id == id) {
            suppliers.erase(it);
            break;
        }
    }
}

void updateSupplier(int id) {
    for (auto &supplier : suppliers) {
        if (supplier.id == id) {
            cout << "Enter new name: ";
            cin >> supplier.name;
            cout << "Enter new contact: ";
            cin >> supplier.contact;
            break;
        }
    }
}

void searchSupplier(int id) {
    for (const auto &supplier : suppliers) {
        if (supplier.id == id) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name
                 << ", Contact: " << supplier.contact << endl;
        }
    }
}

void displaySuppliers() {
    for (const auto &supplier : suppliers) {
        cout << "ID: " << supplier.id << ", Name: " << supplier.name
             << ", Contact: " << supplier.contact << endl;
    }
}

int main() {
    int choice, id;
    do {
        cout << "1. Add Drink\n"
             << "2. Delete Drink\n"
             << "3. Update Drink\n"
             << "4. Search Drink\n"
             << "5. Display Drinks\n"
             << "6. Add Supplier\n"
             << "7. Delete Supplier\n"
             << "8. Update Supplier\n"
             << "9. Search Supplier\n"
             << "10. Display Suppliers\n"
             << "11. Exit\n"
             << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1:
                addDrink();
                break;
            case 2:
                cout << "Enter drink ID to delete: ";
                cin >> id;
                deleteDrink(id);
                break;
            case 3:
                cout << "Enter drink ID to update: ";
                cin >> id;
                updateDrink(id);
                break;
            case 4:
                cout << "Enter drink ID to search: ";
                cin >> id;
                searchDrink(id);
                break;
            case 5:
                displayDrinks();
                break;
            case 6:
                addSupplier();
                break;
            case 7:
                cout << "Enter supplier ID to delete: ";
                cin >> id;
                deleteSupplier(id);
                break;
            case 8:
                cout << "Enter supplier ID to update: ";
                cin >> id;
                updateSupplier(id);
                break;
            case 9:
                cout << "Enter supplier ID to search: ";
                cin >> id;
                searchSupplier(id);
                break;
            case 10:
                displaySuppliers();
                break;
            case 11:
                break;
            default:
                cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 11);

    return 0;
}