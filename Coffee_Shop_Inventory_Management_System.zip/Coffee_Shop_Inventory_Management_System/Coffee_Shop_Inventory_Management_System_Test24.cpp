#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Drink {
public:
    string name;
    double price;
    
    Drink(string n, double p) : name(n), price(p) {}
};

class Supplier {
public:
    string name;
    string contact_info;
    
    Supplier(string n, string c) : name(n), contact_info(c) {}
};

class CoffeeShopInventory {
private:
    vector<Drink> drinks;
    vector<Supplier> suppliers;
    
public:
    void addDrink(string name, double price) {
        drinks.push_back(Drink(name, price));
    }
    
    void deleteDrink(string name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }
    
    void updateDrink(string name, double newPrice) {
        for (auto &drink : drinks) {
            if (drink.name == name) {
                drink.price = newPrice;
                break;
            }
        }
    }
    
    Drink* searchDrink(string name) {
        for (auto &drink : drinks) {
            if (drink.name == name) {
                return &drink;
            }
        }
        return nullptr;
    }
    
    void displayDrinks() {
        for (const auto &drink : drinks) {
            cout << "Name: " << drink.name << ", Price: $" << drink.price << endl;
        }
    }
    
    void addSupplier(string name, string contact) {
        suppliers.push_back(Supplier(name, contact));
    }
    
    void deleteSupplier(string name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }
    
    void updateSupplier(string name, string newContact) {
        for (auto &supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contact_info = newContact;
                break;
            }
        }
    }
    
    Supplier* searchSupplier(string name) {
        for (auto &supplier : suppliers) {
            if (supplier.name == name) {
                return &supplier;
            }
        }
        return nullptr;
    }
    
    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            cout << "Name: " << supplier.name << ", Contact: " << supplier.contact_info << endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink("Espresso", 2.5);
    inventory.addDrink("Latte", 3.0);
    inventory.displayDrinks();
    inventory.updateDrink("Latte", 3.5);
    inventory.displayDrinks();
    inventory.addSupplier("Best Beans", "contact@bestbeans.com");
    inventory.displaySuppliers();
    inventory.updateSupplier("Best Beans", "info@bestbeans.com");
    inventory.displaySuppliers();
    
    return 0;
}