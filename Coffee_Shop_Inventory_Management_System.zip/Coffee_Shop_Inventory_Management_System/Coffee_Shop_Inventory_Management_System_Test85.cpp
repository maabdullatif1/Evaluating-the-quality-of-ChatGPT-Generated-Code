#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    std::string name;
    double price;
    int quantity;

    Drink(std::string name, double price, int quantity) : name(name), price(price), quantity(quantity) {}
};

class Supplier {
public:
    std::string name;
    std::string contactInfo;

    Supplier(std::string name, std::string contactInfo) : name(name), contactInfo(contactInfo) {}
};

class Inventory {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(const std::string& name, double price, int quantity) {
        drinks.push_back(Drink(name, price, quantity));
    }

    void deleteDrink(const std::string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(const std::string& name, double price, int quantity) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = quantity;
                return;
            }
        }
    }

    void searchDrink(const std::string& name) {
        for (const auto& drink : drinks) {
            if (drink.name == name) {
                std::cout << "Drink found: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << std::endl;
                return;
            }
        }
        std::cout << "Drink not found." << std::endl;
    }

    void displayDrinks() {
        std::cout << "Drinks in inventory:" << std::endl;
        for (const auto& drink : drinks) {
            std::cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << std::endl;
        }
    }

    void addSupplier(const std::string& name, const std::string& contactInfo) {
        suppliers.push_back(Supplier(name, contactInfo));
    }

    void deleteSupplier(const std::string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(const std::string& name, const std::string& contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contactInfo = contactInfo;
                return;
            }
        }
    }

    void searchSupplier(const std::string& name) {
        for (const auto& supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Supplier found: " << supplier.name << ", Contact Info: " << supplier.contactInfo << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found." << std::endl;
    }

    void displaySuppliers() {
        std::cout << "Suppliers in system:" << std::endl;
        for (const auto& supplier : suppliers) {
            std::cout << "Name: " << supplier.name << ", Contact Info: " << supplier.contactInfo << std::endl;
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addDrink("Espresso", 2.5, 100);
    inventory.addDrink("Latte", 3.0, 80);
    inventory.addSupplier("CoffeeBeans Co.", "contact@coffeebeansco.com");
    inventory.addSupplier("Milk Suppliers LLC", "info@milsuppliers.com");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    inventory.updateDrink("Latte", 3.5, 75);
    inventory.updateSupplier("CoffeeBeans Co.", "support@coffeebeansco.com");

    inventory.searchDrink("Espresso");
    inventory.searchSupplier("Milk Suppliers LLC");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    inventory.deleteDrink("Espresso");
    inventory.deleteSupplier("Milk Suppliers LLC");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    return 0;
}