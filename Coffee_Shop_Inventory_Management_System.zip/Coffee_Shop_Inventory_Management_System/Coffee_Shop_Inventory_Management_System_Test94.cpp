#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    string name;
    double price;
    int stock;
};

struct Supplier {
    string name;
    string contact;
};

class InventorySystem {
private:
    vector<Drink> drinks;
    vector<Supplier> suppliers;

    int findDrinkIndex(const string &name) {
        for (int i = 0; i < drinks.size(); i++) {
            if (drinks[i].name == name) return i;
        }
        return -1;
    }

    int findSupplierIndex(const string &name) {
        for (int i = 0; i < suppliers.size(); i++) {
            if (suppliers[i].name == name) return i;
        }
        return -1;
    }

public:
    void addDrink(const string &name, double price, int stock) {
        drinks.push_back({name, price, stock});
    }

    void deleteDrink(const string &name) {
        int index = findDrinkIndex(name);
        if (index != -1) drinks.erase(drinks.begin() + index);
    }

    void updateDrink(const string &name, double price, int stock) {
        int index = findDrinkIndex(name);
        if (index != -1) {
            drinks[index].price = price;
            drinks[index].stock = stock;
        }
    }

    void searchDrink(const string &name) {
        int index = findDrinkIndex(name);
        if (index != -1) {
            cout << "Drink found: " << drinks[index].name << ", Price: " 
                 << drinks[index].price << ", Stock: " << drinks[index].stock << endl;
        } else {
            cout << "Drink not found" << endl;
        }
    }

    void displayDrinks() {
        cout << "Drinks Inventory:" << endl;
        for (const auto &drink : drinks) {
            cout << "Name: " << drink.name << ", Price: " 
                 << drink.price << ", Stock: " << drink.stock << endl;
        }
    }

    void addSupplier(const string &name, const string &contact) {
        suppliers.push_back({name, contact});
    }

    void deleteSupplier(const string &name) {
        int index = findSupplierIndex(name);
        if (index != -1) suppliers.erase(suppliers.begin() + index);
    }

    void updateSupplier(const string &name, const string &contact) {
        int index = findSupplierIndex(name);
        if (index != -1) {
            suppliers[index].contact = contact;
        }
    }

    void searchSupplier(const string &name) {
        int index = findSupplierIndex(name);
        if (index != -1) {
            cout << "Supplier found: " << suppliers[index].name 
                 << ", Contact: " << suppliers[index].contact << endl;
        } else {
            cout << "Supplier not found" << endl;
        }
    }

    void displaySuppliers() {
        cout << "Suppliers List:" << endl;
        for (const auto &supplier : suppliers) {
            cout << "Name: " << supplier.name << ", Contact: " 
                 << supplier.contact << endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addDrink("Latte", 3.50, 50);
    system.addDrink("Espresso", 2.50, 75);
    system.addSupplier("Coffee Beans Co.", "123-456-7890");
    system.addSupplier("Milk Suppliers Inc.", "098-765-4321");
    system.displayDrinks();
    system.displaySuppliers();
    system.searchDrink("Latte");
    system.searchSupplier("Coffee Beans Co.");
    system.updateDrink("Latte", 3.75, 60);
    system.updateSupplier("Coffee Beans Co.", "111-222-3333");
    system.displayDrinks();
    system.displaySuppliers();
    system.deleteDrink("Espresso");
    system.deleteSupplier("Milk Suppliers Inc.");
    system.displayDrinks();
    system.displaySuppliers();
    return 0;
}