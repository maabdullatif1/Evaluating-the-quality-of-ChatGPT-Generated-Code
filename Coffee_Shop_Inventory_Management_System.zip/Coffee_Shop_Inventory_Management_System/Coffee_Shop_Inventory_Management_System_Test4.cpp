#include <iostream>
#include <vector>
#include <string>

struct Drink {
    int id;
    std::string name;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class CoffeeShopInventory {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    int drinkIdCounter = 0;
    int supplierIdCounter = 0;

public:
    void addDrink(const std::string& name, double price) {
        drinks.push_back({drinkIdCounter++, name, price});
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(int id, const std::string& name, double price) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                break;
            }
        }
    }

    Drink* searchDrink(int id) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                return &drink;
            }
        }
        return nullptr;
    }

    void displayDrinks() const {
        for (const auto& drink : drinks) {
            std::cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: " << drink.price << "\n";
        }
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back({supplierIdCounter++, name, contact});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink("Espresso", 2.5);
    inventory.addDrink("Latte", 3.5);
    inventory.addSupplier("CoffeeBeans Inc.", "123-456-789");
    inventory.displayDrinks();
    inventory.displaySuppliers();

    inventory.updateDrink(0, "Espresso", 2.75);
    inventory.updateSupplier(0, "CoffeeBeans Inc.", "987-654-321");
    inventory.displayDrinks();
    inventory.displaySuppliers();

    Drink* drink = inventory.searchDrink(1);
    if (drink) {
        std::cout << "Found Drink: " << drink->name << "\n";
    }

    Supplier* supplier = inventory.searchSupplier(0);
    if (supplier) {
        std::cout << "Found Supplier: " << supplier->name << "\n";
    }

    inventory.deleteDrink(0);
    inventory.deleteSupplier(0);
    inventory.displayDrinks();
    inventory.displaySuppliers();

    return 0;
}