#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    int id;
    string name;
    double price;
    int stock;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

class CoffeeShopInventory {
    vector<Drink> drinks;
    vector<Supplier> suppliers;

    Drink* findDrink(int id) {
        for (auto &drink : drinks) {
            if (drink.id == id)
                return &drink;
        }
        return nullptr;
    }

    Supplier* findSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id)
                return &supplier;
        }
        return nullptr;
    }

public:
    void addDrink(int id, string name, double price, int stock) {
        if (findDrink(id) == nullptr)
            drinks.push_back({id, name, price, stock});
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(int id, string name, double price, int stock) {
        Drink* drink = findDrink(id);
        if (drink) {
            drink->name = name;
            drink->price = price;
            drink->stock = stock;
        }
    }

    void searchDrink(int id) {
        Drink* drink = findDrink(id);
        if (drink) {
            cout << "Drink ID: " << drink->id << ", Name: " << drink->name
                 << ", Price: " << drink->price << ", Stock: " << drink->stock << endl;
        } else {
            cout << "Drink not found." << endl;
        }
    }

    void displayDrinks() {
        for (auto &drink : drinks) {
            cout << "ID: " << drink.id << ", Name: " << drink.name
                 << ", Price: " << drink.price << ", Stock: " << drink.stock << endl;
        }
    }

    void addSupplier(int id, string name, string contact) {
        if (findSupplier(id) == nullptr)
            suppliers.push_back({id, name, contact});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contact) {
        Supplier* supplier = findSupplier(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void searchSupplier(int id) {
        Supplier* supplier = findSupplier(id);
        if (supplier) {
            cout << "Supplier ID: " << supplier->id << ", Name: " << supplier->name
                 << ", Contact: " << supplier->contact << endl;
        } else {
            cout << "Supplier not found." << endl;
        }
    }

    void displaySuppliers() {
        for (auto &supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name
                 << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink(1, "Latte", 2.5, 100);
    inventory.addDrink(2, "Cappuccino", 3.5, 50);
    inventory.addSupplier(1, "Coffee Beans Co.", "123-456-7890");
    inventory.addSupplier(2, "Milk Supplier Inc.", "098-765-4321");

    cout << "All Drinks:" << endl;
    inventory.displayDrinks();
    cout << "All Suppliers:" << endl;
    inventory.displaySuppliers();

    cout << "Searching for Drink ID 1:" << endl;
    inventory.searchDrink(1);

    cout << "Searching for Supplier ID 2:" << endl;
    inventory.searchSupplier(2);

    inventory.updateDrink(1, "Espresso", 2.8, 80);
    inventory.updateSupplier(1, "Coffee Beans Ltd.", "321-654-0987");

    cout << "All Drinks after update:" << endl;
    inventory.displayDrinks();
    cout << "All Suppliers after update:" << endl;
    inventory.displaySuppliers();

    inventory.deleteDrink(2);
    inventory.deleteSupplier(2);

    cout << "All Drinks after delete:" << endl;
    inventory.displayDrinks();
    cout << "All Suppliers after delete:" << endl;
    inventory.displaySuppliers();

    return 0;
}