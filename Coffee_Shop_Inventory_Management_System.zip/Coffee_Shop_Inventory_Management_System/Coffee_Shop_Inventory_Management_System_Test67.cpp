#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    int id;
    std::string name;
    double price;

    Drink(int id, std::string name, double price) : id(id), name(name), price(price) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInfo;

    Supplier(int id, std::string name, std::string contactInfo) : id(id), name(name), contactInfo(contactInfo) {}
};

class InventorySystem {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    
public:
    void addDrink(int id, std::string name, double price) {
        drinks.push_back(Drink(id, name, price));
    }
    
    void deleteDrink(int id) {
        for(size_t i = 0; i < drinks.size(); ++i) {
            if(drinks[i].id == id) {
                drinks.erase(drinks.begin() + i);
                break;
            }
        }
    }
    
    void updateDrink(int id, std::string name, double price) {
        for(size_t i = 0; i < drinks.size(); ++i) {
            if(drinks[i].id == id) {
                drinks[i].name = name;
                drinks[i].price = price;
                break;
            }
        }
    }
    
    Drink* searchDrink(int id) {
        for(size_t i = 0; i < drinks.size(); ++i) {
            if(drinks[i].id == id) {
                return &drinks[i];
            }
        }
        return nullptr;
    }
    
    void displayDrinks() {
        for (const auto& drink : drinks) {
            std::cout << "Drink ID: " << drink.id << ", Name: " << drink.name << ", Price: " << drink.price << std::endl;
        }
    }

    void addSupplier(int id, std::string name, std::string contactInfo) {
        suppliers.push_back(Supplier(id, name, contactInfo));
    }
    
    void deleteSupplier(int id) {
        for(size_t i = 0; i < suppliers.size(); ++i) {
            if(suppliers[i].id == id) {
                suppliers.erase(suppliers.begin() + i);
                break;
            }
        }
    }
    
    void updateSupplier(int id, std::string name, std::string contactInfo) {
        for(size_t i = 0; i < suppliers.size(); ++i) {
            if(suppliers[i].id == id) {
                suppliers[i].name = name;
                suppliers[i].contactInfo = contactInfo;
                break;
            }
        }
    }
    
    Supplier* searchSupplier(int id) {
        for(size_t i = 0; i < suppliers.size(); ++i) {
            if(suppliers[i].id == id) {
                return &suppliers[i];
            }
        }
        return nullptr;
    }
    
    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contactInfo << std::endl;
        }
    }
};

int main() {
    InventorySystem system;

    system.addDrink(1, "Latte", 4.5);
    system.addDrink(2, "Espresso", 3.0);
    system.displayDrinks();
    
    Drink* d = system.searchDrink(1);
    if (d != nullptr) {
        std::cout << "Found Drink: " << d->name << std::endl;
    }

    system.updateDrink(1, "Cappuccino", 5.0);
    system.displayDrinks();
    
    system.deleteDrink(2);
    system.displayDrinks();
    
    system.addSupplier(1, "CoffeeBeans Inc.", "contact@coffeebeans.com");
    system.displaySuppliers();
    
    system.updateSupplier(1, "Coffee Suppliers Ltd.", "info@coffeesuppliers.com");
    system.displaySuppliers();
    
    Supplier* s = system.searchSupplier(1);
    if (s != nullptr) {
        std::cout << "Found Supplier: " << s->name << std::endl;
    }
    
    system.deleteSupplier(1);
    system.displaySuppliers();
    
    return 0;
}