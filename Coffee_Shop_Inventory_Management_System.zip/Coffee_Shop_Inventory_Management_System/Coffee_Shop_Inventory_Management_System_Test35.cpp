#include <iostream>
#include <string>
#include <vector>

class Drink {
public:
    std::string name;
    double price;
    unsigned int quantity;

    Drink(const std::string& name, double price, unsigned int qty)
        : name(name), price(price), quantity(qty) {}
};

class Supplier {
public:
    std::string name;
    std::string contact;

    Supplier(const std::string& name, const std::string& contact)
        : name(name), contact(contact) {}
};

class InventorySystem {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(const std::string& name, double price, unsigned int qty) {
        drinks.emplace_back(name, price, qty);
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.emplace_back(name, contact);
    }

    void deleteDrink(const std::string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                return;
            }
        }
    }

    void deleteSupplier(const std::string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                return;
            }
        }
    }

    void updateDrink(const std::string& name, double price, unsigned int qty) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = qty;
                return;
            }
        }
    }

    void updateSupplier(const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contact = contact;
                return;
            }
        }
    }

    void searchDrink(const std::string& name) {
        for (const auto& drink : drinks) {
            if (drink.name == name) {
                std::cout << "Drink found: " << drink.name << ", Price: " << drink.price 
                          << ", Quantity: " << drink.quantity << std::endl;
                return;
            }
        }
        std::cout << "Drink not found.\n";
    }

    void searchSupplier(const std::string& name) {
        for (const auto& supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Supplier found: " << supplier.name 
                          << ", Contact: " << supplier.contact << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found.\n";
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            std::cout << "Drink: " << drink.name << ", Price: " << drink.price 
                      << ", Quantity: " << drink.quantity << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier: " << supplier.name << ", Contact: " << supplier.contact 
                      << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addDrink("Espresso", 3.5, 10);
    system.addDrink("Latte", 4.5, 20);
    system.addSupplier("ABC Coffee Co.", "123-456-7890");
    system.addSupplier("XYZ Beans", "987-654-3210");

    system.displayDrinks();
    system.displaySuppliers();

    system.searchDrink("Latte");
    system.searchSupplier("XYZ Beans");

    system.updateDrink("Espresso", 3.75, 15);
    system.updateSupplier("ABC Coffee Co.", "111-222-3333");

    system.displayDrinks();
    system.displaySuppliers();

    system.deleteDrink("Latte");
    system.deleteSupplier("XYZ Beans");

    system.displayDrinks();
    system.displaySuppliers();

    return 0;
}