#include <iostream>
#include <string>
#include <vector>

class Drink {
public:
    std::string name;
    double price;
    int quantity;

    Drink(std::string n, double p, int q) : name(n), price(p), quantity(q) {}
};

class Supplier {
public:
    std::string name;
    std::string contactInfo;

    Supplier(std::string n, std::string c) : name(n), contactInfo(c) {}
};

class CoffeeShop {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(const std::string& name, double price, int quantity) {
        drinks.push_back(Drink(name, price, quantity));
    }

    void deleteDrink(const std::string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(const std::string& name, double price, int quantity) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = quantity;
                break;
            }
        }
    }

    void searchDrink(const std::string& name) const {
        for (const auto& drink : drinks) {
            if (drink.name == name) {
                std::cout << "Drink found: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << std::endl;
                return;
            }
        }
        std::cout << "Drink not found." << std::endl;
    }

    void displayDrinks() const {
        if (drinks.empty()) {
            std::cout << "No drinks available." << std::endl;
            return;
        }
        for (const auto& drink : drinks) {
            std::cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << std::endl;
        }
    }

    void addSupplier(const std::string& name, const std::string& contactInfo) {
        suppliers.push_back(Supplier(name, contactInfo));
    }

    void deleteSupplier(const std::string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(const std::string& name, const std::string& contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    void searchSupplier(const std::string& name) const {
        for (const auto& supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Supplier found: " << supplier.name << ", Contact Info: " << supplier.contactInfo << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found." << std::endl;
    }

    void displaySuppliers() const {
        if (suppliers.empty()) {
            std::cout << "No suppliers available." << std::endl;
            return;
        }
        for (const auto& supplier : suppliers) {
            std::cout << "Name: " << supplier.name << ", Contact Info: " << supplier.contactInfo << std::endl;
        }
    }
};

int main() {
    CoffeeShop shop;

    shop.addDrink("Espresso", 2.5, 30);
    shop.addDrink("Latte", 3.5, 20);
    shop.displayDrinks();

    shop.addSupplier("Coffee Beans Co.", "contact@coffee.com");
    shop.displaySuppliers();

    shop.searchDrink("Latte");
    shop.deleteDrink("Latte");
    shop.displayDrinks();

    return 0;
}