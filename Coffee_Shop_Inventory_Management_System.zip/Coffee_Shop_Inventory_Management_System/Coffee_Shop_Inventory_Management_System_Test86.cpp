#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    int id;
    string name;
    double price;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

vector<Drink> drinks;
vector<Supplier> suppliers;

void addDrink() {
    Drink d;
    cout << "Enter Drink ID: ";
    cin >> d.id;
    cout << "Enter Drink Name: ";
    cin.ignore();
    getline(cin, d.name);
    cout << "Enter Drink Price: ";
    cin >> d.price;
    drinks.push_back(d);
}

void deleteDrink() {
    int id;
    cout << "Enter Drink ID to Delete: ";
    cin >> id;
    for (auto it = drinks.begin(); it != drinks.end(); ++it) {
        if (it->id == id) {
            drinks.erase(it);
            cout << "Drink Deleted.\n";
            return;
        }
    }
    cout << "Drink Not Found.\n";
}

void updateDrink() {
    int id;
    cout << "Enter Drink ID to Update: ";
    cin >> id;
    for (auto& d : drinks) {
        if (d.id == id) {
            cout << "Enter New Drink Name: ";
            cin.ignore();
            getline(cin, d.name);
            cout << "Enter New Drink Price: ";
            cin >> d.price;
            cout << "Drink Updated.\n";
            return;
        }
    }
    cout << "Drink Not Found.\n";
}

void searchDrink() {
    int id;
    cout << "Enter Drink ID to Search: ";
    cin >> id;
    for (const auto& d : drinks) {
        if (d.id == id) {
            cout << "ID: " << d.id << ", Name: " << d.name << ", Price: " << d.price << endl;
            return;
        }
    }
    cout << "Drink Not Found.\n";
}

void displayDrinks() {
    cout << "Drinks Inventory:\n";
    for (const auto& d : drinks) {
        cout << "ID: " << d.id << ", Name: " << d.name << ", Price: " << d.price << endl;
    }
}

void addSupplier() {
    Supplier s;
    cout << "Enter Supplier ID: ";
    cin >> s.id;
    cout << "Enter Supplier Name: ";
    cin.ignore();
    getline(cin, s.name);
    cout << "Enter Supplier Contact: ";
    getline(cin, s.contact);
    suppliers.push_back(s);
}

void deleteSupplier() {
    int id;
    cout << "Enter Supplier ID to Delete: ";
    cin >> id;
    for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
        if (it->id == id) {
            suppliers.erase(it);
            cout << "Supplier Deleted.\n";
            return;
        }
    }
    cout << "Supplier Not Found.\n";
}

void updateSupplier() {
    int id;
    cout << "Enter Supplier ID to Update: ";
    cin >> id;
    for (auto& s : suppliers) {
        if (s.id == id) {
            cout << "Enter New Supplier Name: ";
            cin.ignore();
            getline(cin, s.name);
            cout << "Enter New Supplier Contact: ";
            getline(cin, s.contact);
            cout << "Supplier Updated.\n";
            return;
        }
    }
    cout << "Supplier Not Found.\n";
}

void searchSupplier() {
    int id;
    cout << "Enter Supplier ID to Search: ";
    cin >> id;
    for (const auto& s : suppliers) {
        if (s.id == id) {
            cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << endl;
            return;
        }
    }
    cout << "Supplier Not Found.\n";
}

void displaySuppliers() {
    cout << "Suppliers List:\n";
    for (const auto& s : suppliers) {
        cout << "ID: " << s.id << ", Name: " << s.name << ", Contact: " << s.contact << endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Drink\n2. Delete Drink\n3. Update Drink\n4. Search Drink\n5. Display Drinks\n"
             << "6. Add Supplier\n7. Delete Supplier\n8. Update Supplier\n9. Search Supplier\n10. Display Suppliers\n11. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addDrink(); break;
            case 2: deleteDrink(); break;
            case 3: updateDrink(); break;
            case 4: searchDrink(); break;
            case 5: displayDrinks(); break;
            case 6: addSupplier(); break;
            case 7: deleteSupplier(); break;
            case 8: updateSupplier(); break;
            case 9: searchSupplier(); break;
            case 10: displaySuppliers(); break;
            case 11: return 0;
            default: cout << "Invalid choice. Try again.\n";
        }
    }
}