#include <iostream>
#include <string>
using namespace std;

struct Drink {
    string name;
    double price;
    int quantity;
};

struct Supplier {
    string name;
    string contact;
};

class Inventory {
    Drink drinks[100];
    Supplier suppliers[100];
    int drinkCount;
    int supplierCount;
public:
    Inventory() : drinkCount(0), supplierCount(0) {}

    void addDrink(string name, double price, int quantity) {
        drinks[drinkCount++] = {name, price, quantity};
    }
    
    void addSupplier(string name, string contact) {
        suppliers[supplierCount++] = {name, contact};
    }

    void deleteDrink(string name) {
        for (int i = 0; i < drinkCount; ++i) {
            if (drinks[i].name == name) {
                drinks[i] = drinks[--drinkCount];
                break;
            }
        }
    }

    void deleteSupplier(string name) {
        for (int i = 0; i < supplierCount; ++i) {
            if (suppliers[i].name == name) {
                suppliers[i] = suppliers[--supplierCount];
                break;
            }
        }
    }

    void updateDrink(string name, double price, int quantity) {
        for (int i = 0; i < drinkCount; ++i) {
            if (drinks[i].name == name) {
                drinks[i].price = price;
                drinks[i].quantity = quantity;
                break;
            }
        }
    }

    void updateSupplier(string name, string contact) {
        for (int i = 0; i < supplierCount; ++i) {
            if (suppliers[i].name == name) {
                suppliers[i].contact = contact;
                break;
            }
        }
    }

    Drink* searchDrink(string name) {
        for (int i = 0; i < drinkCount; ++i) {
            if (drinks[i].name == name) {
                return &drinks[i];
            }
        }
        return nullptr;
    }

    Supplier* searchSupplier(string name) {
        for (int i = 0; i < supplierCount; ++i) {
            if (suppliers[i].name == name) {
                return &suppliers[i];
            }
        }
        return nullptr;
    }

    void displayDrinks() {
        for (int i = 0; i < drinkCount; ++i) {
            cout << "Drink Name: " << drinks[i].name
                 << ", Price: " << drinks[i].price
                 << ", Quantity: " << drinks[i].quantity << endl;
        }
    }

    void displaySuppliers() {
        for (int i = 0; i < supplierCount; ++i) {
            cout << "Supplier Name: " << suppliers[i].name
                 << ", Contact: " << suppliers[i].contact << endl;
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addDrink("Espresso", 2.50, 100);
    inventory.addSupplier("CoffeeBeans Co", "123-456-7890");
    inventory.displayDrinks();
    inventory.displaySuppliers();
    inventory.updateDrink("Espresso", 3.00, 120);
    inventory.displayDrinks();
    inventory.deleteDrink("Espresso");
    inventory.displayDrinks();
    return 0;
}