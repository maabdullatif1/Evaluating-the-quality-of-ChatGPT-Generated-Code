#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    int id;
    string name;
    double price;
    int quantity;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

vector<Drink> drinks;
vector<Supplier> suppliers;

int nextDrinkId = 1;
int nextSupplierId = 1;

void addDrink() {
    Drink newDrink;
    newDrink.id = nextDrinkId++;
    cout << "Enter drink name: ";
    cin >> newDrink.name;
    cout << "Enter drink price: ";
    cin >> newDrink.price;
    cout << "Enter drink quantity: ";
    cin >> newDrink.quantity;
    drinks.push_back(newDrink);
}

void deleteDrink() {
    int id;
    cout << "Enter drink ID to delete: ";
    cin >> id;
    for (auto it = drinks.begin(); it != drinks.end(); ++it) {
        if (it->id == id) {
            drinks.erase(it);
            return;
        }
    }
    cout << "Drink not found." << endl;
}

void updateDrink() {
    int id;
    cout << "Enter drink ID to update: ";
    cin >> id;
    for (auto &drink : drinks) {
        if (drink.id == id) {
            cout << "Enter new drink name: ";
            cin >> drink.name;
            cout << "Enter new drink price: ";
            cin >> drink.price;
            cout << "Enter new drink quantity: ";
            cin >> drink.quantity;
            return;
        }
    }
    cout << "Drink not found." << endl;
}

void searchDrink() {
    int id;
    cout << "Enter drink ID to search: ";
    cin >> id;
    for (const auto &drink : drinks) {
        if (drink.id == id) {
            cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
            return;
        }
    }
    cout << "Drink not found." << endl;
}

void displayDrinks() {
    for (const auto &drink : drinks) {
        cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
    }
}

void addSupplier() {
    Supplier newSupplier;
    newSupplier.id = nextSupplierId++;
    cout << "Enter supplier name: ";
    cin >> newSupplier.name;
    cout << "Enter supplier contact: ";
    cin >> newSupplier.contact;
    suppliers.push_back(newSupplier);
}

void deleteSupplier() {
    int id;
    cout << "Enter supplier ID to delete: ";
    cin >> id;
    for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
        if (it->id == id) {
            suppliers.erase(it);
            return;
        }
    }
    cout << "Supplier not found." << endl;
}

void updateSupplier() {
    int id;
    cout << "Enter supplier ID to update: ";
    cin >> id;
    for (auto &supplier : suppliers) {
        if (supplier.id == id) {
            cout << "Enter new supplier name: ";
            cin >> supplier.name;
            cout << "Enter new supplier contact: ";
            cin >> supplier.contact;
            return;
        }
    }
    cout << "Supplier not found." << endl;
}

void searchSupplier() {
    int id;
    cout << "Enter supplier ID to search: ";
    cin >> id;
    for (const auto &supplier : suppliers) {
        if (supplier.id == id) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
            return;
        }
    }
    cout << "Supplier not found." << endl;
}

void displaySuppliers() {
    for (const auto &supplier : suppliers) {
        cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Drink\n2. Delete Drink\n3. Update Drink\n4. Search Drink\n5. Display Drinks\n6. Add Supplier\n7. Delete Supplier\n8. Update Supplier\n9. Search Supplier\n10. Display Suppliers\n11. Exit\nChoose an option: ";
        cin >> choice;
        switch (choice) {
            case 1: addDrink(); break;
            case 2: deleteDrink(); break;
            case 3: updateDrink(); break;
            case 4: searchDrink(); break;
            case 5: displayDrinks(); break;
            case 6: addSupplier(); break;
            case 7: deleteSupplier(); break;
            case 8: updateSupplier(); break;
            case 9: searchSupplier(); break;
            case 10: displaySuppliers(); break;
            case 11: break;
            default: cout << "Invalid choice." << endl; break;
        }
    } while (choice != 11);
    return 0;
}