#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Drink {
public:
    string name;
    double price;
    int quantity;

    Drink(string name, double price, int quantity) : name(name), price(price), quantity(quantity) {}
};

class Supplier {
public:
    string name;
    string contactInfo;

    Supplier(string name, string contactInfo) : name(name), contactInfo(contactInfo) {}
};

class CoffeeShopInventory {
private:
    vector<Drink> drinks;
    vector<Supplier> suppliers;

public:
    void addDrink(string name, double price, int quantity) {
        drinks.push_back(Drink(name, price, quantity));
    }

    void deleteDrink(string name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                return;
            }
        }
    }

    void updateDrink(string name, double price, int quantity) {
        for (auto &drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = quantity;
                return;
            }
        }
    }

    void searchDrink(string name) {
        for (const auto &drink : drinks) {
            if (drink.name == name) {
                cout << "Drink found: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
                return;
            }
        }
        cout << "Drink not found." << endl;
    }

    void displayDrinks() {
        for (const auto &drink : drinks) {
            cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
        }
    }

    void addSupplier(string name, string contactInfo) {
        suppliers.push_back(Supplier(name, contactInfo));
    }

    void deleteSupplier(string name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                return;
            }
        }
    }

    void updateSupplier(string name, string contactInfo) {
        for (auto &supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contactInfo = contactInfo;
                return;
            }
        }
    }

    void searchSupplier(string name) {
        for (const auto &supplier : suppliers) {
            if (supplier.name == name) {
                cout << "Supplier found: " << supplier.name << ", Contact Info: " << supplier.contactInfo << endl;
                return;
            }
        }
        cout << "Supplier not found." << endl;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            cout << "Name: " << supplier.name << ", Contact Info: " << supplier.contactInfo << endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;

    inventory.addDrink("Espresso", 2.5, 100);
    inventory.addDrink("Latte", 3.0, 80);

    inventory.addSupplier("Coffee Beans Inc.", "contact@coffeeinc.com");
    inventory.addSupplier("Milk Suppliers Co.", "info@milkco.com");

    cout << "Drinks Available:" << endl;
    inventory.displayDrinks();

    cout << "Suppliers:" << endl;
    inventory.displaySuppliers();

    inventory.searchDrink("Espresso");
    inventory.searchSupplier("Coffee Beans Inc.");

    inventory.updateDrink("Latte", 3.5, 75);
    inventory.updateSupplier("Milk Suppliers Co.", "support@milkco.com");

    cout << "Updated Drinks:" << endl;
    inventory.displayDrinks();

    cout << "Updated Suppliers:" << endl;
    inventory.displaySuppliers();

    inventory.deleteDrink("Espresso");
    inventory.deleteSupplier("Coffee Beans Inc.");

    cout << "Final Drinks:" << endl;
    inventory.displayDrinks();

    cout << "Final Suppliers:" << endl;
    inventory.displaySuppliers();

    return 0;
}