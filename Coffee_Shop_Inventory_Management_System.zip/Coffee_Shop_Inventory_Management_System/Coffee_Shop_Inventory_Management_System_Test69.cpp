#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    int id;
    string name;
    double price;
    int quantity;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

class CoffeeShopInventory {
    vector<Drink> drinks;
    vector<Supplier> suppliers;

    int findDrinkIndex(int id) {
        for (int i = 0; i < drinks.size(); ++i) {
            if (drinks[i].id == id) return i;
        }
        return -1;
    }

    int findSupplierIndex(int id) {
        for (int i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].id == id) return i;
        }
        return -1;
    }

public:
    void addDrink(int id, string name, double price, int quantity) {
        if (findDrinkIndex(id) == -1)
            drinks.push_back({id, name, price, quantity});
    }

    void deleteDrink(int id) {
        int index = findDrinkIndex(id);
        if (index != -1)
            drinks.erase(drinks.begin() + index);
    }

    void updateDrink(int id, string name, double price, int quantity) {
        int index = findDrinkIndex(id);
        if (index != -1)
            drinks[index] = {id, name, price, quantity};
    }

    Drink* searchDrink(int id) {
        int index = findDrinkIndex(id);
        if (index != -1)
            return &drinks[index];
        return nullptr;
    }

    void displayDrinks() {
        for (const auto &drink : drinks) {
            cout << "ID: " << drink.id << ", Name: " << drink.name 
                 << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
        }
    }

    void addSupplier(int id, string name, string contact) {
        if (findSupplierIndex(id) == -1)
            suppliers.push_back({id, name, contact});
    }

    void deleteSupplier(int id) {
        int index = findSupplierIndex(id);
        if (index != -1)
            suppliers.erase(suppliers.begin() + index);
    }

    void updateSupplier(int id, string name, string contact) {
        int index = findSupplierIndex(id);
        if (index != -1)
            suppliers[index] = {id, name, contact};
    }

    Supplier* searchSupplier(int id) {
        int index = findSupplierIndex(id);
        if (index != -1)
            return &suppliers[index];
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name 
                 << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;

    inventory.addDrink(1, "Espresso", 2.5, 100);
    inventory.addDrink(2, "Latte", 3.0, 150);
    inventory.addSupplier(1, "Supplier A", "123-456-7890");
    inventory.addSupplier(2, "Supplier B", "098-765-4321");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    return 0;
}