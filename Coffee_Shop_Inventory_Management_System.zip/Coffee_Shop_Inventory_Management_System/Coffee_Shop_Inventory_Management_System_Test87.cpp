#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    string name;
    double price;
    int quantity;
};

struct Supplier {
    string name;
    string contactInfo;
};

class CoffeeShopInventory {
private:
    vector<Drink> drinks;
    vector<Supplier> suppliers;

public:
    void addDrink(const string& name, double price, int quantity) {
        drinks.push_back({name, price, quantity});
    }

    void deleteDrink(const string& name) {
        auto it = remove_if(drinks.begin(), drinks.end(),
            [&name](const Drink& d) { return d.name == name; });
        drinks.erase(it, drinks.end());
    }

    void updateDrink(const string& name, double price, int quantity) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = quantity;
                return;
            }
        }
    }

    Drink* searchDrink(const string& name) {
        for (auto& drink : drinks) {
            if (drink.name == name)
                return &drink;
        }
        return nullptr;
    }

    void displayDrinks() const {
        for (const auto& drink : drinks) {
            cout << "Name: " << drink.name << ", Price: $" << drink.price 
                 << ", Quantity: " << drink.quantity << "\n";
        }
    }

    void addSupplier(const string& name, const string& contactInfo) {
        suppliers.push_back({name, contactInfo});
    }

    void deleteSupplier(const string& name) {
        auto it = remove_if(suppliers.begin(), suppliers.end(),
            [&name](const Supplier& s) { return s.name == name; });
        suppliers.erase(it, suppliers.end());
    }

    Supplier* searchSupplier(const string& name) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name)
                return &supplier;
        }
        return nullptr;
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            cout << "Name: " << supplier.name << ", Contact Info: " 
                 << supplier.contactInfo << "\n";
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink("Espresso", 2.5, 100);
    inventory.addDrink("Latte", 3.0, 50);
    inventory.addSupplier("Coffee Beans Co.", "beans@supplier.com");
    inventory.displayDrinks();
    inventory.displaySuppliers();

    Drink* searchedDrink = inventory.searchDrink("Latte");
    if (searchedDrink) {
        cout << "Found: " << searchedDrink->name << ", Price: $" 
             << searchedDrink->price << ", Quantity: " 
             << searchedDrink->quantity << "\n";
    }

    inventory.updateDrink("Espresso", 2.8, 120);
    inventory.deleteDrink("Latte");
    inventory.displayDrinks();

    Supplier* searchedSupplier = inventory.searchSupplier("Coffee Beans Co.");
    if (searchedSupplier) {
        cout << "Found Supplier: " << searchedSupplier->name 
             << ", Contact Info: " << searchedSupplier->contactInfo << "\n";
    }

    return 0;
}