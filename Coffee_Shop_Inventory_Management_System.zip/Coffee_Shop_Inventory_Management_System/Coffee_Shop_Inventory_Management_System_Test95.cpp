#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    int id;
    std::string name;
    double price;

    Drink(int i, const std::string& n, double p) : id(i), name(n), price(p) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int i, const std::string& n, const std::string& c) : id(i), name(n), contact(c) {}
};

class InventoryManagementSystem {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    int nextDrinkId;
    int nextSupplierId;

public:
    InventoryManagementSystem() : nextDrinkId(1), nextSupplierId(1) {}

    void addDrink(const std::string& name, double price) {
        drinks.push_back(Drink(nextDrinkId++, name, price));
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(int id, const std::string& name, double price) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                break;
            }
        }
    }

    Drink* searchDrink(int id) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                return &drink;
            }
        }
        return nullptr;
    }

    void displayDrinks() const {
        for (const auto& drink : drinks) {
            std::cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: $" << drink.price << std::endl;
        }
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back(Supplier(nextSupplierId++, name, contact));
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addDrink("Espresso", 2.50);
    ims.addDrink("Latte", 3.25);
    ims.displayDrinks();
    ims.updateDrink(2, "Large Latte", 3.75);
    ims.displayDrinks();
    ims.deleteDrink(1);
    ims.displayDrinks();
    ims.addSupplier("Coffee Supplier Inc.", "123-456-7890");
    ims.displaySuppliers();
    ims.updateSupplier(1, "Premium Coffee Supply", "987-654-3210");
    ims.displaySuppliers();
    ims.deleteSupplier(1);
    ims.displaySuppliers();
    return 0;
}