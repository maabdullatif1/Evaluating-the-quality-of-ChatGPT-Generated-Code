#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    int id;
    string name;
    double price;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

vector<Drink> drinks;
vector<Supplier> suppliers;

void addDrink() {
    int id;
    string name;
    double price;
    cout << "Enter Drink ID: ";
    cin >> id;
    cout << "Enter Drink Name: ";
    cin.ignore();
    getline(cin, name);
    cout << "Enter Drink Price: ";
    cin >> price;
    drinks.push_back({id, name, price});
}

void deleteDrink() {
    int id;
    cout << "Enter Drink ID to delete: ";
    cin >> id;
    for (auto it = drinks.begin(); it != drinks.end(); ++it) {
        if (it->id == id) {
            drinks.erase(it);
            cout << "Drink deleted.\n";
            return;
        }
    }
    cout << "Drink not found.\n";
}

void updateDrink() {
    int id;
    cout << "Enter Drink ID to update: ";
    cin >> id;
    for (auto &drink : drinks) {
        if (drink.id == id) {
            cout << "Enter new Drink Name: ";
            cin.ignore();
            getline(cin, drink.name);
            cout << "Enter new Drink Price: ";
            cin >> drink.price;
            cout << "Drink updated.\n";
            return;
        }
    }
    cout << "Drink not found.\n";
}

void searchDrink() {
    int id;
    cout << "Enter Drink ID to search: ";
    cin >> id;
    for (const auto &drink : drinks) {
        if (drink.id == id) {
            cout << "Found Drink: " << drink.name << ", Price: " << drink.price << endl;
            return;
        }
    }
    cout << "Drink not found.\n";
}

void displayDrinks() {
    cout << "Drinks List:\n";
    for (const auto &drink : drinks) {
        cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: " << drink.price << endl;
    }
}

void addSupplier() {
    int id;
    string name, contact;
    cout << "Enter Supplier ID: ";
    cin >> id;
    cout << "Enter Supplier Name: ";
    cin.ignore();
    getline(cin, name);
    cout << "Enter Supplier Contact: ";
    getline(cin, contact);
    suppliers.push_back({id, name, contact});
}

void deleteSupplier() {
    int id;
    cout << "Enter Supplier ID to delete: ";
    cin >> id;
    for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
        if (it->id == id) {
            suppliers.erase(it);
            cout << "Supplier deleted.\n";
            return;
        }
    }
    cout << "Supplier not found.\n";
}

void updateSupplier() {
    int id;
    cout << "Enter Supplier ID to update: ";
    cin >> id;
    for (auto &supplier : suppliers) {
        if (supplier.id == id) {
            cout << "Enter new Supplier Name: ";
            cin.ignore();
            getline(cin, supplier.name);
            cout << "Enter new Supplier Contact: ";
            getline(cin, supplier.contact);
            cout << "Supplier updated.\n";
            return;
        }
    }
    cout << "Supplier not found.\n";
}

void searchSupplier() {
    int id;
    cout << "Enter Supplier ID to search: ";
    cin >> id;
    for (const auto &supplier : suppliers) {
        if (supplier.id == id) {
            cout << "Found Supplier: " << supplier.name << ", Contact: " << supplier.contact << endl;
            return;
        }
    }
    cout << "Supplier not found.\n";
}

void displaySuppliers() {
    cout << "Suppliers List:\n";
    for (const auto &supplier : suppliers) {
        cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "\nCoffee Shop Inventory Management System\n";
        cout << "1. Add Drink\n2. Delete Drink\n3. Update Drink\n4. Search Drink\n5. Display Drinks\n";
        cout << "6. Add Supplier\n7. Delete Supplier\n8. Update Supplier\n9. Search Supplier\n10. Display Suppliers\n11. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addDrink(); break;
            case 2: deleteDrink(); break;
            case 3: updateDrink(); break;
            case 4: searchDrink(); break;
            case 5: displayDrinks(); break;
            case 6: addSupplier(); break;
            case 7: deleteSupplier(); break;
            case 8: updateSupplier(); break;
            case 9: searchSupplier(); break;
            case 10: displaySuppliers(); break;
            case 11: return 0;
            default: cout << "Invalid choice.\n";
        }
    }
}