#include <iostream>
#include <vector>
#include <string>

struct Drink {
    int id;
    std::string name;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class CoffeeShopInventory {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    int nextDrinkId;
    int nextSupplierId;

    int findDrinkIndexById(int id) {
        for (size_t i = 0; i < drinks.size(); ++i) {
            if (drinks[i].id == id)
                return i;
        }
        return -1;
    }

    int findSupplierIndexById(int id) {
        for (size_t i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].id == id)
                return i;
        }
        return -1;
    }

public:
    CoffeeShopInventory() : nextDrinkId(1), nextSupplierId(1) {}

    void addDrink(const std::string& name, double price) {
        drinks.push_back({nextDrinkId++, name, price});
    }

    void deleteDrink(int id) {
        int index = findDrinkIndexById(id);
        if (index != -1) {
            drinks.erase(drinks.begin() + index);
        }
    }

    void updateDrink(int id, const std::string& name, double price) {
        int index = findDrinkIndexById(id);
        if (index != -1) {
            drinks[index].name = name;
            drinks[index].price = price;
        }
    }

    Drink* searchDrink(int id) {
        int index = findDrinkIndexById(id);
        return index != -1 ? &drinks[index] : nullptr;
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            std::cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: " << drink.price << "\n";
        }
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back({nextSupplierId++, name, contact});
    }

    void deleteSupplier(int id) {
        int index = findSupplierIndexById(id);
        if (index != -1) {
            suppliers.erase(suppliers.begin() + index);
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        int index = findSupplierIndexById(id);
        if (index != -1) {
            suppliers[index].name = name;
            suppliers[index].contact = contact;
        }
    }

    Supplier* searchSupplier(int id) {
        int index = findSupplierIndexById(id);
        return index != -1 ? &suppliers[index] : nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink("Espresso", 2.5);
    inventory.addDrink("Latte", 3.0);
    inventory.displayDrinks();

    inventory.addSupplier("Coffee Beans Inc.", "contact@coffeebeans.com");
    inventory.addSupplier("Milk Supplier Ltd.", "milk@suppliers.com");
    inventory.displaySuppliers();

    return 0;
}