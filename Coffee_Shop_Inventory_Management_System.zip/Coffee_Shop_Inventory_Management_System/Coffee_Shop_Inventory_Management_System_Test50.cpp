#include <iostream>
#include <vector>
#include <string>

struct Drink {
    int id;
    std::string name;
    double price;
    int quantity;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class CoffeeShopInventory {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    int drinkIdCounter;
    int supplierIdCounter;

public:
    CoffeeShopInventory() : drinkIdCounter(1), supplierIdCounter(1) {}

    void addDrink(std::string name, double price, int quantity) {
        drinks.push_back({drinkIdCounter++, name, price, quantity});
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(int id, std::string name, double price, int quantity) {
        for (auto &drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                drink.quantity = quantity;
            }
        }
    }

    void searchDrink(std::string name) {
        for (const auto &drink : drinks) {
            if (drink.name == name) {
                std::cout << "ID: " << drink.id << ", Name: " << drink.name
                          << ", Price: $" << drink.price
                          << ", Quantity: " << drink.quantity << "\n";
            }
        }
    }

    void displayDrinks() {
        for (const auto &drink : drinks) {
            std::cout << "ID: " << drink.id << ", Name: " << drink.name
                      << ", Price: $" << drink.price
                      << ", Quantity: " << drink.quantity << "\n";
        }
    }

    void addSupplier(std::string name, std::string contact) {
        suppliers.push_back({supplierIdCounter++, name, contact});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
            }
        }
    }

    void searchSupplier(std::string name) {
        for (const auto &supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                          << ", Contact: " << supplier.contact << "\n";
            }
        }
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink("Espresso", 2.50, 30);
    inventory.addDrink("Cappuccino", 3.00, 20);
    inventory.displayDrinks();
    inventory.addSupplier("Beans Supplier Co.", "123-456-7890");
    inventory.displaySuppliers();

    return 0;
}