#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Drink {
    int id;
    string name;
    double price;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

class InventorySystem {
public:
    void addDrink(const Drink& drink) {
        drinks.push_back(drink);
    }

    void deleteDrink(int id) {
        for (size_t i = 0; i < drinks.size(); ++i) {
            if (drinks[i].id == id) {
                drinks.erase(drinks.begin() + i);
                return;
            }
        }
    }

    void updateDrink(int id, const Drink& newDrink) {
        for (size_t i = 0; i < drinks.size(); ++i) {
            if (drinks[i].id == id) {
                drinks[i] = newDrink;
                return;
            }
        }
    }

    Drink* searchDrink(int id) {
        for (size_t i = 0; i < drinks.size(); ++i) {
            if (drinks[i].id == id) {
                return &drinks[i];
            }
        }
        return nullptr;
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            cout << "Drink ID: " << drink.id << ", Name: " << drink.name << ", Price: $" << drink.price << endl;
        }
    }

    void addSupplier(const Supplier& supplier) {
        suppliers.push_back(supplier);
    }

    void deleteSupplier(int id) {
        for (size_t i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].id == id) {
                suppliers.erase(suppliers.begin() + i);
                return;
            }
        }
    }

    void updateSupplier(int id, const Supplier& newSupplier) {
        for (size_t i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].id == id) {
                suppliers[i] = newSupplier;
                return;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (size_t i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].id == id) {
                return &suppliers[i];
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }

private:
    vector<Drink> drinks;
    vector<Supplier> suppliers;
};

int main() {
    InventorySystem inventory;

    inventory.addDrink({1, "Espresso", 2.5});
    inventory.addDrink({2, "Latte", 3.5});

    inventory.addSupplier({1, "Coffee Bean Co.", "123-456-7890"});
    inventory.addSupplier({2, "Milk Suppliers", "987-654-3210"});

    cout << "Drinks:" << endl;
    inventory.displayDrinks();
    
    cout << "\nSuppliers:" << endl;
    inventory.displaySuppliers();

    return 0;
}