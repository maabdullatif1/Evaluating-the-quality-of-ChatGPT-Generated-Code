#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Drink {
public:
    string name;
    double price;
    int quantity;
    
    Drink(string n, double p, int q) : name(n), price(p), quantity(q) {}
};

class Supplier {
public:
    string name;
    string contactInfo;

    Supplier(string n, string c) : name(n), contactInfo(c) {}
};

class CoffeeShopInventory {
private:
    vector<Drink> drinks;
    vector<Supplier> suppliers;

public:
    void addDrink(string name, double price, int quantity) {
        drinks.push_back(Drink(name, price, quantity));
    }

    void deleteDrink(string name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(string name, double price, int quantity) {
        for (auto &drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = quantity;
                break;
            }
        }
    }

    void searchDrink(string name) {
        for (const auto &drink : drinks) {
            if (drink.name == name) {
                cout << "Drink found: " << drink.name << ", Price: $" << drink.price << ", Quantity: " << drink.quantity << endl;
                return;
            }
        }
        cout << "Drink not found" << endl;
    }

    void displayDrinks() {
        for (const auto &drink : drinks) {
            cout << "Name: " << drink.name << ", Price: $" << drink.price << ", Quantity: " << drink.quantity << endl;
        }
    }

    void addSupplier(string name, string contactInfo) {
        suppliers.push_back(Supplier(name, contactInfo));
    }

    void deleteSupplier(string name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(string name, string contactInfo) {
        for (auto &supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    void searchSupplier(string name) {
        for (const auto &supplier : suppliers) {
            if (supplier.name == name) {
                cout << "Supplier found: " << supplier.name << ", Contact Info: " << supplier.contactInfo << endl;
                return;
            }
        }
        cout << "Supplier not found" << endl;
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            cout << "Name: " << supplier.name << ", Contact Info: " << supplier.contactInfo << endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink("Espresso", 2.50, 100);
    inventory.addDrink("Latte", 3.50, 80);
    inventory.displayDrinks();
    inventory.searchDrink("Latte");
    inventory.updateDrink("Latte", 3.75, 90);
    inventory.deleteDrink("Espresso");
    inventory.displayDrinks();

    inventory.addSupplier("Supplier A", "123-456-7890");
    inventory.addSupplier("Supplier B", "098-765-4321");
    inventory.displaySuppliers();
    inventory.searchSupplier("Supplier A");
    inventory.updateSupplier("Supplier B", "111-222-3333");
    inventory.deleteSupplier("Supplier A");
    inventory.displaySuppliers();

    return 0;
}