#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    int id;
    std::string name;
    double price;
    Drink(int drinkId, std::string drinkName, double drinkPrice) 
        : id(drinkId), name(drinkName), price(drinkPrice) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    Supplier(int supplierId, std::string supplierName, std::string supplierContact) 
        : id(supplierId), name(supplierName), contact(supplierContact) {}
};

class CoffeeShopInventory {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    
public:
    void addDrink(int id, std::string name, double price) {
        drinks.push_back(Drink(id, name, price));
    }
    
    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }
    
    void updateDrink(int id, std::string name, double price) {
        for (auto &drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                break;
            }
        }
    }
    
    Drink* searchDrink(int id) {
        for (auto &drink : drinks) {
            if (drink.id == id) {
                return &drink;
            }
        }
        return nullptr;
    }
    
    void displayDrinks() {
        for (auto &drink : drinks) {
            std::cout << "ID: " << drink.id << ", Name: " << drink.name 
                      << ", Price: " << drink.price << std::endl;
        }
    }
    
    void addSupplier(int id, std::string name, std::string contact) {
        suppliers.push_back(Supplier(id, name, contact));
    }
    
    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }
    
    void updateSupplier(int id, std::string name, std::string contact) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }
    
    Supplier* searchSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }
    
    void displaySuppliers() {
        for (auto &supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name 
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    
    inventory.addDrink(1, "Espresso", 2.50);
    inventory.addDrink(2, "Cappuccino", 3.00);
    inventory.addSupplier(1, "Supplier A", "123-456-7890");
    inventory.addSupplier(2, "Supplier B", "098-765-4321");
    
    std::cout << "Drinks in Inventory:" << std::endl;
    inventory.displayDrinks();
    
    std::cout << "Suppliers in Inventory:" << std::endl;
    inventory.displaySuppliers();
    
    return 0;
}