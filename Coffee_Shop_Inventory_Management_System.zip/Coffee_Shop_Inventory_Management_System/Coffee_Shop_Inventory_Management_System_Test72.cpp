#include <iostream>
#include <vector>
#include <string>

struct Drink {
    int id;
    std::string name;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contactInfo;
};

class InventoryManagement {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    int nextDrinkId;
    int nextSupplierId;

public:
    InventoryManagement() : nextDrinkId(1), nextSupplierId(1) {}

    void addDrink(const std::string& name, double price) {
        drinks.push_back({nextDrinkId++, name, price});
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(int id, const std::string& name, double price) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                break;
            }
        }
    }

    void searchDrink(const std::string& name) {
        for (const auto& drink : drinks) {
            if (drink.name == name) {
                std::cout << "Found Drink ID: " << drink.id << ", Name: " << drink.name << ", Price: " << drink.price << '\n';
            }
        }
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            std::cout << "Drink ID: " << drink.id << ", Name: " << drink.name << ", Price: " << drink.price << '\n';
        }
    }

    void addSupplier(const std::string& name, const std::string& contactInfo) {
        suppliers.push_back({nextSupplierId++, name, contactInfo});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    void searchSupplier(const std::string& name) {
        for (const auto& supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Found Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contactInfo << '\n';
            }
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact Info: " << supplier.contactInfo << '\n';
        }
    }
};

int main() {
    InventoryManagement inventory;

    inventory.addDrink("Espresso", 2.5);
    inventory.addDrink("Latte", 3.7);
    inventory.displayDrinks();

    inventory.updateDrink(1, "Double Espresso", 3.0);
    inventory.searchDrink("Double Espresso");

    inventory.deleteDrink(2);
    inventory.displayDrinks();

    inventory.addSupplier("Coffee Supplier Co", "123-456-789");
    inventory.addSupplier("Beans Ltd", "987-654-321");
    inventory.displaySuppliers();

    inventory.updateSupplier(1, "The Coffee Supplier Co", "123-456-000");
    inventory.searchSupplier("The Coffee Supplier Co");

    inventory.deleteSupplier(2);
    inventory.displaySuppliers();

    return 0;
}