#include <iostream>
#include <string>
#include <vector>

class Drink {
public:
    std::string name;
    double price;
    int quantity;

    Drink(std::string n, double p, int q) : name(n), price(p), quantity(q) {}
};

class Supplier {
public:
    std::string name;
    std::string contact;

    Supplier(std::string n, std::string c) : name(n), contact(c) {}
};

class Inventory {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink() {
        std::string name;
        double price;
        int quantity;
        std::cout << "Enter drink name: ";
        std::cin >> name;
        std::cout << "Enter drink price: ";
        std::cin >> price;
        std::cout << "Enter drink quantity: ";
        std::cin >> quantity;
        drinks.push_back(Drink(name, price, quantity));
    }

    void deleteDrink() {
        std::string name;
        std::cout << "Enter drink name to delete: ";
        std::cin >> name;
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                return;
            }
        }
    }

    void updateDrink() {
        std::string name;
        std::cout << "Enter drink name to update: ";
        std::cin >> name;
        for (auto &drink : drinks) {
            if (drink.name == name) {
                std::cout << "Enter new drink price: ";
                std::cin >> drink.price;
                std::cout << "Enter new drink quantity: ";
                std::cin >> drink.quantity;
                return;
            }
        }
    }

    void searchDrink() {
        std::string name;
        std::cout << "Enter drink name to search: ";
        std::cin >> name;
        for (const auto &drink : drinks) {
            if (drink.name == name) {
                std::cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << '\n';
                return;
            }
        }
    }

    void displayDrinks() {
        for (const auto &drink : drinks) {
            std::cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << '\n';
        }
    }

    void addSupplier() {
        std::string name, contact;
        std::cout << "Enter supplier name: ";
        std::cin >> name;
        std::cout << "Enter supplier contact: ";
        std::cin >> contact;
        suppliers.push_back(Supplier(name, contact));
    }

    void deleteSupplier() {
        std::string name;
        std::cout << "Enter supplier name to delete: ";
        std::cin >> name;
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                return;
            }
        }
    }

    void updateSupplier() {
        std::string name;
        std::cout << "Enter supplier name to update: ";
        std::cin >> name;
        for (auto &supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Enter new supplier contact: ";
                std::cin >> supplier.contact;
                return;
            }
        }
    }

    void searchSupplier() {
        std::string name;
        std::cout << "Enter supplier name to search: ";
        std::cin >> name;
        for (const auto &supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Name: " << supplier.name << ", Contact: " << supplier.contact << '\n';
                return;
            }
        }
    }

    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "Name: " << supplier.name << ", Contact: " << supplier.contact << '\n';
        }
    }
};

int main() {
    Inventory inventory;
    int choice;
    do {
        std::cout << "1. Add Drink\n2. Delete Drink\n3. Update Drink\n4. Search Drink\n5. Display Drinks\n";
        std::cout << "6. Add Supplier\n7. Delete Supplier\n8. Update Supplier\n9. Search Supplier\n10. Display Suppliers\n0. Exit\n";
        std::cin >> choice;
        switch (choice) {
            case 1: inventory.addDrink(); break;
            case 2: inventory.deleteDrink(); break;
            case 3: inventory.updateDrink(); break;
            case 4: inventory.searchDrink(); break;
            case 5: inventory.displayDrinks(); break;
            case 6: inventory.addSupplier(); break;
            case 7: inventory.deleteSupplier(); break;
            case 8: inventory.updateSupplier(); break;
            case 9: inventory.searchSupplier(); break;
            case 10: inventory.displaySuppliers(); break;
        }
    } while (choice != 0);
    return 0;
}