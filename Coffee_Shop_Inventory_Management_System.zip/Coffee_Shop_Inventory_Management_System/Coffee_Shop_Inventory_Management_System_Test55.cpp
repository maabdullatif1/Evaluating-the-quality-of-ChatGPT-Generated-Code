#include <iostream>
#include <vector>
#include <string>

struct Drink {
    std::string name;
    double price;
    int quantity;
};

struct Supplier {
    std::string name;
    std::string contactInfo;
};

struct Inventory {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

    void addDrink(const std::string& name, double price, int quantity) {
        drinks.push_back({name, price, quantity});
    }

    void deleteDrink(const std::string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                return;
            }
        }
    }

    void updateDrink(const std::string& name, double newPrice, int newQuantity) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = newPrice;
                drink.quantity = newQuantity;
                return;
            }
        }
    }

    void searchDrink(const std::string& name) const {
        for (const auto& drink : drinks) {
            if (drink.name == name) {
                std::cout << "Drink found: " << drink.name << " Price: " << drink.price << " Quantity: " << drink.quantity << '\n';
                return;
            }
        }
        std::cout << "Drink not found\n";
    }

    void displayDrinks() const {
        for (const auto& drink : drinks) {
            std::cout << "Name: " << drink.name << " Price: " << drink.price << " Quantity: " << drink.quantity << '\n';
        }
    }

    void addSupplier(const std::string& name, const std::string& contactInfo) {
        suppliers.push_back({name, contactInfo});
    }

    void deleteSupplier(const std::string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                return;
            }
        }
    }

    void updateSupplier(const std::string& name, const std::string& newContactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contactInfo = newContactInfo;
                return;
            }
        }
    }

    void searchSupplier(const std::string& name) const {
        for (const auto& supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Supplier found: " << supplier.name << " Contact: " << supplier.contactInfo << '\n';
                return;
            }
        }
        std::cout << "Supplier not found\n";
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            std::cout << "Name: " << supplier.name << " Contact: " << supplier.contactInfo << '\n';
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addDrink("Espresso", 2.5, 30);
    inventory.addDrink("Latte", 3.0, 25);
    inventory.displayDrinks();
    inventory.searchDrink("Latte");
    inventory.updateDrink("Latte", 3.5, 20);
    inventory.displayDrinks();
    inventory.deleteDrink("Espresso");
    inventory.displayDrinks();
    
    inventory.addSupplier("Coffee Beans Inc", "contact@coffeebeans.com");
    inventory.addSupplier("Milk Suppliers Ltd", "contact@milksuppliers.com");
    inventory.displaySuppliers();
    inventory.searchSupplier("Coffee Beans Inc");
    inventory.updateSupplier("Coffee Beans Inc", "newcontact@coffeebeans.com");
    inventory.displaySuppliers();
    inventory.deleteSupplier("Milk Suppliers Ltd");
    inventory.displaySuppliers();

    return 0;
}