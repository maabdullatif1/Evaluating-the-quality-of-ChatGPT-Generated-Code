#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    std::string name;
    float price;
    int quantity;

    Drink(std::string name, float price, int quantity)
        : name(name), price(price), quantity(quantity) {}
};

class Supplier {
public:
    std::string name;
    std::string contact;

    Supplier(std::string name, std::string contact)
        : name(name), contact(contact) {}
};

class InventorySystem {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(std::string name, float price, int quantity) {
        drinks.push_back(Drink(name, price, quantity));
    }

    void deleteDrink(std::string name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(std::string name, float price, int quantity) {
        for (auto &drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = quantity;
                break;
            }
        }
    }

    void searchDrink(std::string name) {
        for (auto &drink : drinks) {
            if (drink.name == name) {
                std::cout << "Name: " << drink.name
                          << ", Price: " << drink.price
                          << ", Quantity: " << drink.quantity << std::endl;
                return;
            }
        }
        std::cout << "Drink not found" << std::endl;
    }

    void displayDrinks() {
        for (auto &drink : drinks) {
            std::cout << "Name: " << drink.name
                      << ", Price: " << drink.price
                      << ", Quantity: " << drink.quantity << std::endl;
        }
    }

    void addSupplier(std::string name, std::string contact) {
        suppliers.push_back(Supplier(name, contact));
    }

    void deleteSupplier(std::string name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(std::string name, std::string contact) {
        for (auto &supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(std::string name) {
        for (auto &supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Name: " << supplier.name
                          << ", Contact: " << supplier.contact << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found" << std::endl;
    }

    void displaySuppliers() {
        for (auto &supplier : suppliers) {
            std::cout << "Name: " << supplier.name
                      << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addDrink("Espresso", 2.5, 100);
    system.addDrink("Latte", 3.0, 150);

    system.addSupplier("Coffee Beans Inc.", "+123456789");
    system.addSupplier("Milk Suppliers Co.", "+987654321");

    system.displayDrinks();
    system.displaySuppliers();

    system.searchDrink("Espresso");
    system.searchSupplier("Milk Suppliers Co.");

    system.updateDrink("Espresso", 2.7, 120);
    system.updateSupplier("Coffee Beans Inc.", "+1122334455");

    system.deleteDrink("Latte");
    system.deleteSupplier("Milk Suppliers Co.");

    system.displayDrinks();
    system.displaySuppliers();

    return 0;
}