#include <iostream>
#include <vector>
#include <string>

struct Drink {
    std::string name;
    double price;
    int quantity;
};

struct Supplier {
    std::string name;
    std::string contact;
};

class InventoryManagementSystem {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(const std::string& name, double price, int quantity) {
        drinks.push_back({name, price, quantity});
    }

    void deleteDrink(const std::string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(const std::string& name, double price, int quantity) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = quantity;
                break;
            }
        }
    }

    void searchDrink(const std::string& name) {
        for (const auto& drink : drinks) {
            if (drink.name == name) {
                std::cout << "Drink Found: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << std::endl;
                return;
            }
        }
        std::cout << "Drink not found." << std::endl;
    }

    void displayDrinks() {
        std::cout << "Drinks Inventory:" << std::endl;
        for (const auto& drink : drinks) {
            std::cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << std::endl;
        }
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back({name, contact});
    }

    void deleteSupplier(const std::string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(const std::string& name) {
        for (const auto& supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Supplier Found: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found." << std::endl;
    }

    void displaySuppliers() {
        std::cout << "Suppliers List:" << std::endl;
        for (const auto& supplier : suppliers) {
            std::cout << "Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addDrink("Espresso", 2.5, 50);
    ims.addDrink("Latte", 3.5, 30);
    ims.displayDrinks();

    ims.updateDrink("Latte", 3.75, 25);
    ims.searchDrink("Latte");
    ims.deleteDrink("Espresso");
    ims.displayDrinks();

    ims.addSupplier("CoffeeBean Co.", "123-456-7890");
    ims.addSupplier("Milk Supplier Inc.", "098-765-4321");
    ims.displaySuppliers();

    ims.updateSupplier("Milk Supplier Inc.", "098-111-2233");
    ims.searchSupplier("Milk Supplier Inc.");
    ims.deleteSupplier("CoffeeBean Co.");
    ims.displaySuppliers();

    return 0;
}