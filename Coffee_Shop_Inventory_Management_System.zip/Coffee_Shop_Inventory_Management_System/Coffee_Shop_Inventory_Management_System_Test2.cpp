#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    std::string name;
    double price;
    int quantity;

    Drink(std::string name, double price, int quantity)
        : name(name), price(price), quantity(quantity) {}
};

class Supplier {
public:
    std::string name;
    std::string contactInfo;

    Supplier(std::string name, std::string contactInfo)
        : name(name), contactInfo(contactInfo) {}
};

class InventorySystem {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(const std::string& name, double price, int quantity) {
        drinks.push_back(Drink(name, price, quantity));
    }

    void deleteDrink(const std::string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(const std::string& name, double price, int quantity) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = quantity;
                break;
            }
        }
    }

    void searchDrink(const std::string& name) {
        for (const auto& drink : drinks) {
            if (drink.name == name) {
                std::cout << "Drink: " << drink.name 
                          << ", Price: " << drink.price 
                          << ", Quantity: " << drink.quantity << std::endl;
                return;
            }
        }
        std::cout << "Drink not found" << std::endl;
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            std::cout << "Drink: " << drink.name 
                      << ", Price: " << drink.price 
                      << ", Quantity: " << drink.quantity << std::endl;
        }
    }

    void addSupplier(const std::string& name, const std::string& contactInfo) {
        suppliers.push_back(Supplier(name, contactInfo));
    }

    void deleteSupplier(const std::string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(const std::string& name, const std::string& contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    void searchSupplier(const std::string& name) {
        for (const auto& supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Supplier: " << supplier.name 
                          << ", Contact Info: " << supplier.contactInfo << std::endl;
                return;
            }
        }
        std::cout << "Supplier not found" << std::endl;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier: " << supplier.name 
                      << ", Contact Info: " << supplier.contactInfo << std::endl;
        }
    }
};

int main() {
    InventorySystem system;
    system.addDrink("Espresso", 2.5, 100);
    system.addDrink("Latte", 3.5, 80);
    system.addSupplier("John Doe", "123-456-7890");

    system.displayDrinks();
    system.searchDrink("Latte");
    system.updateDrink("Latte", 3.75, 75);
    system.searchDrink("Latte");
    system.displaySuppliers();
    system.deleteDrink("Espresso");
    system.displayDrinks();

    return 0;
}