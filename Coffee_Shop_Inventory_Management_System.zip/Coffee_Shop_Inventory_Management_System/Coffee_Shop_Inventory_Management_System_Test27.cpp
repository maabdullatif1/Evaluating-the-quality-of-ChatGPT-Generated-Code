#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Drink {
    int id;
    string name;
    float price;
    int quantity;
};

struct Supplier {
    int id;
    string name;
    string contactInfo;
};

class CoffeeShopInventory {
private:
    vector<Drink> drinks;
    vector<Supplier> suppliers;
    int drinkIDCounter;
    int supplierIDCounter;

    int findDrinkIndexById(int id) {
        for (int i = 0; i < drinks.size(); ++i) {
            if (drinks[i].id == id) return i;
        }
        return -1;
    }

    int findSupplierIndexById(int id) {
        for (int i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].id == id) return i;
        }
        return -1;
    }

public:
    CoffeeShopInventory() : drinkIDCounter(1), supplierIDCounter(1) {}

    void addDrink(const string& name, float price, int quantity) {
        drinks.push_back({drinkIDCounter++, name, price, quantity});
    }

    void deleteDrink(int id) {
        int index = findDrinkIndexById(id);
        if (index != -1) drinks.erase(drinks.begin() + index);
    }

    void updateDrink(int id, const string& name, float price, int quantity) {
        int index = findDrinkIndexById(id);
        if (index != -1) {
            drinks[index].name = name;
            drinks[index].price = price;
            drinks[index].quantity = quantity;
        }
    }

    Drink* searchDrink(int id) {
        int index = findDrinkIndexById(id);
        return index != -1 ? &drinks[index] : nullptr;
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            cout << "ID: " << drink.id << " Name: " << drink.name 
                 << " Price: " << drink.price << " Quantity: " << drink.quantity << endl;
        }
    }

    void addSupplier(const string& name, const string& contactInfo) {
        suppliers.push_back({supplierIDCounter++, name, contactInfo});
    }

    void deleteSupplier(int id) {
        int index = findSupplierIndexById(id);
        if (index != -1) suppliers.erase(suppliers.begin() + index);
    }

    void updateSupplier(int id, const string& name, const string& contactInfo) {
        int index = findSupplierIndexById(id);
        if (index != -1) {
            suppliers[index].name = name;
            suppliers[index].contactInfo = contactInfo;
        }
    }

    Supplier* searchSupplier(int id) {
        int index = findSupplierIndexById(id);
        return index != -1 ? &suppliers[index] : nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "ID: " << supplier.id << " Name: " << supplier.name 
                 << " Contact: " << supplier.contactInfo << endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink("Espresso", 2.50, 100);
    inventory.addDrink("Latte", 3.50, 50);
    inventory.addSupplier("Coffee Co", "123-456-7890");
    inventory.displayDrinks();
    inventory.displaySuppliers();
    return 0;
}