#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    std::string name;
    double price;
    
    Drink(std::string n, double p) : name(n), price(p) {}
};

class Supplier {
public:
    std::string name;
    std::string contact;
    
    Supplier(std::string n, std::string c) : name(n), contact(c) {}
};

class CoffeeShop {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    
public:
    void addDrink(const std::string &name, double price) {
        drinks.push_back(Drink(name, price));
    }
    
    void deleteDrink(const std::string &name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }
    
    void updateDrink(const std::string &name, double newPrice) {
        for (auto &drink : drinks) {
            if (drink.name == name) {
                drink.price = newPrice;
                break;
            }
        }
    }
    
    void searchDrink(const std::string &name) {
        for (const auto &drink : drinks) {
            if (drink.name == name) {
                std::cout << "Drink found: " << drink.name << " - $" << drink.price << "\n";
                return;
            }
        }
        std::cout << "Drink not found.\n";
    }
    
    void displayDrinks() {
        std::cout << "Drinks:\n";
        for (const auto &drink : drinks) {
            std::cout << drink.name << " - $" << drink.price << "\n";
        }
    }

    void addSupplier(const std::string &name, const std::string &contact) {
        suppliers.push_back(Supplier(name, contact));
    }
    
    void deleteSupplier(const std::string &name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }
    
    void updateSupplier(const std::string &name, const std::string &newContact) {
        for (auto &supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contact = newContact;
                break;
            }
        }
    }
    
    void searchSupplier(const std::string &name) {
        for (const auto &supplier : suppliers) {
            if (supplier.name == name) {
                std::cout << "Supplier found: " << supplier.name << ", Contact: " << supplier.contact << "\n";
                return;
            }
        }
        std::cout << "Supplier not found.\n";
    }

    void displaySuppliers() {
        std::cout << "Suppliers:\n";
        for (const auto &supplier : suppliers) {
            std::cout << supplier.name << ", Contact: " << supplier.contact << "\n";
        }
    }
};

int main() {
    CoffeeShop shop;
    shop.addDrink("Espresso", 2.50);
    shop.addDrink("Latte", 3.50);
    shop.displayDrinks();
    shop.searchDrink("Latte");
    shop.updateDrink("Latte", 4.00);
    shop.displayDrinks();
    shop.deleteDrink("Espresso");
    shop.displayDrinks();

    shop.addSupplier("ABC Coffee Supplies", "123-456-7890");
    shop.addSupplier("Best Beans Co", "098-765-4321");
    shop.displaySuppliers();
    shop.searchSupplier("ABC Coffee Supplies");
    shop.updateSupplier("ABC Coffee Supplies", "111-222-3333");
    shop.displaySuppliers();
    shop.deleteSupplier("Best Beans Co");
    shop.displaySuppliers();

    return 0;
}