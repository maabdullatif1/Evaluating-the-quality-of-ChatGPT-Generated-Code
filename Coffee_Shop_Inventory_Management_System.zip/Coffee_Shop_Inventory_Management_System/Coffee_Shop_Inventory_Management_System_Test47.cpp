#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    int id;
    std::string name;
    double price;
    Drink(int i, const std::string& n, double p) : id(i), name(n), price(p) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInfo;
    Supplier(int i, const std::string& n, const std::string& c) : id(i), name(n), contactInfo(c) {}
};

class Inventory {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    
    Drink* findDrinkById(int id) {
        for (auto& drink : drinks) {
            if (drink.id == id)
                return &drink;
        }
        return nullptr;
    }

    Supplier* findSupplierById(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id)
                return &supplier;
        }
        return nullptr;
    }

public:
    void addDrink(int id, const std::string& name, double price) {
        if (findDrinkById(id) == nullptr) {
            drinks.push_back(Drink(id, name, price));
        }
    }

    void deleteDrink(int id) {
        auto it = std::remove_if(drinks.begin(), drinks.end(), [id](Drink& drink) { return drink.id == id; });
        if (it != drinks.end()) {
            drinks.erase(it, drinks.end());
        }
    }

    void updateDrink(int id, const std::string& name, double price) {
        Drink* drink = findDrinkById(id);
        if (drink != nullptr) {
            drink->name = name;
            drink->price = price;
        }
    }

    void searchAndDisplayDrink(int id) {
        Drink* drink = findDrinkById(id);
        if (drink != nullptr) {
            std::cout << "Drink ID: " << drink->id << ", Name: " << drink->name << ", Price: " << drink->price << std::endl;
        }
    }

    void displayAllDrinks() {
        for (auto& drink : drinks) {
            std::cout << "Drink ID: " << drink.id << ", Name: " << drink.name << ", Price: " << drink.price << std::endl;
        }
    }

    void addSupplier(int id, const std::string& name, const std::string& contactInfo) {
        if (findSupplierById(id) == nullptr) {
            suppliers.push_back(Supplier(id, name, contactInfo));
        }
    }

    void deleteSupplier(int id) {
        auto it = std::remove_if(suppliers.begin(), suppliers.end(), [id](Supplier& supplier) { return supplier.id == id; });
        if (it != suppliers.end()) {
            suppliers.erase(it, suppliers.end());
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contactInfo) {
        Supplier* supplier = findSupplierById(id);
        if (supplier != nullptr) {
            supplier->name = name;
            supplier->contactInfo = contactInfo;
        }
    }

    void searchAndDisplaySupplier(int id) {
        Supplier* supplier = findSupplierById(id);
        if (supplier != nullptr) {
            std::cout << "Supplier ID: " << supplier->id << ", Name: " << supplier->name << ", Contact: " << supplier->contactInfo << std::endl;
        }
    }

    void displayAllSuppliers() {
        for (auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contactInfo << std::endl;
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addDrink(1, "Espresso", 2.50);
    inventory.addDrink(2, "Latte", 3.00);
    inventory.addSupplier(1, "Coffee Supplier", "contact@coffee.com");
    inventory.displayAllDrinks();
    inventory.displayAllSuppliers();
    inventory.updateDrink(1, "Double Espresso", 3.00);
    inventory.searchAndDisplayDrink(1);
    inventory.deleteDrink(2);
    inventory.displayAllDrinks();
    inventory.updateSupplier(1, "Premium Coffee Supplier", "premium@coffee.com");
    inventory.searchAndDisplaySupplier(1);
    inventory.deleteSupplier(1);
    inventory.displayAllSuppliers();
    return 0;
}