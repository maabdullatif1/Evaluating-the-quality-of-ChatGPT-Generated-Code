#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Drink {
    string name;
    double price;
    int stock;
};

struct Supplier {
    string name;
    string contact;
};

vector<Drink> drinks;
vector<Supplier> suppliers;

void addDrink() {
    Drink d;
    cout << "Enter drink name: ";
    cin >> d.name;
    cout << "Enter drink price: ";
    cin >> d.price;
    cout << "Enter drink stock: ";
    cin >> d.stock;
    drinks.push_back(d);
}

void deleteDrink() {
    string name;
    cout << "Enter name of drink to delete: ";
    cin >> name;
    for (auto it = drinks.begin(); it != drinks.end(); ++it) {
        if (it->name == name) {
            drinks.erase(it);
            cout << "Drink deleted" << endl;
            return;
        }
    }
    cout << "Drink not found" << endl;
}

void updateDrink() {
    string name;
    cout << "Enter name of drink to update: ";
    cin >> name;
    for (auto &d : drinks) {
        if (d.name == name) {
            cout << "Enter new price: ";
            cin >> d.price;
            cout << "Enter new stock: ";
            cin >> d.stock;
            cout << "Drink updated" << endl;
            return;
        }
    }
    cout << "Drink not found" << endl;
}

void searchDrink() {
    string name;
    cout << "Enter name of drink to search: ";
    cin >> name;
    for (const auto &d : drinks) {
        if (d.name == name) {
            cout << "Drink found: " << d.name << ", Price: " << d.price << ", Stock: " << d.stock << endl;
            return;
        }
    }
    cout << "Drink not found" << endl;
}

void displayDrinks() {
    cout << "Drinks List:" << endl;
    for (const auto &d : drinks) {
        cout << "Name: " << d.name << ", Price: " << d.price << ", Stock: " << d.stock << endl;
    }
}

void addSupplier() {
    Supplier s;
    cout << "Enter supplier name: ";
    cin >> s.name;
    cout << "Enter supplier contact: ";
    cin >> s.contact;
    suppliers.push_back(s);
}

void deleteSupplier() {
    string name;
    cout << "Enter name of supplier to delete: ";
    cin >> name;
    for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
        if (it->name == name) {
            suppliers.erase(it);
            cout << "Supplier deleted" << endl;
            return;
        }
    }
    cout << "Supplier not found" << endl;
}

void updateSupplier() {
    string name;
    cout << "Enter name of supplier to update: ";
    cin >> name;
    for (auto &s : suppliers) {
        if (s.name == name) {
            cout << "Enter new contact: ";
            cin >> s.contact;
            cout << "Supplier updated" << endl;
            return;
        }
    }
    cout << "Supplier not found" << endl;
}

void searchSupplier() {
    string name;
    cout << "Enter name of supplier to search: ";
    cin >> name;
    for (const auto &s : suppliers) {
        if (s.name == name) {
            cout << "Supplier found: " << s.name << ", Contact: " << s.contact << endl;
            return;
        }
    }
    cout << "Supplier not found" << endl;
}

void displaySuppliers() {
    cout << "Suppliers List:" << endl;
    for (const auto &s : suppliers) {
        cout << "Name: " << s.name << ", Contact: " << s.contact << endl;
    }
}

void menu() {
    cout << "1. Add Drink" << endl;
    cout << "2. Delete Drink" << endl;
    cout << "3. Update Drink" << endl;
    cout << "4. Search Drink" << endl;
    cout << "5. Display Drinks" << endl;
    cout << "6. Add Supplier" << endl;
    cout << "7. Delete Supplier" << endl;
    cout << "8. Update Supplier" << endl;
    cout << "9. Search Supplier" << endl;
    cout << "10. Display Suppliers" << endl;
    cout << "11. Exit" << endl;
}

int main() {
    int choice;
    while (true) {
        menu();
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addDrink(); break;
            case 2: deleteDrink(); break;
            case 3: updateDrink(); break;
            case 4: searchDrink(); break;
            case 5: displayDrinks(); break;
            case 6: addSupplier(); break;
            case 7: deleteSupplier(); break;
            case 8: updateSupplier(); break;
            case 9: searchSupplier(); break;
            case 10: displaySuppliers(); break;
            case 11: return 0;
            default: cout << "Invalid choice" << endl;
        }
    }
}