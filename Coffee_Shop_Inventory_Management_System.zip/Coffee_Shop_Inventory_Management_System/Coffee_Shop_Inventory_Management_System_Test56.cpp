#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    string name;
    double price;
    int quantity;
};

struct Supplier {
    string name;
    string contact_info;
};

vector<Drink> drinks;
vector<Supplier> suppliers;

void addDrink() {
    Drink drink;
    cout << "Enter drink name: ";
    cin >> drink.name;
    cout << "Enter drink price: ";
    cin >> drink.price;
    cout << "Enter drink quantity: ";
    cin >> drink.quantity;
    drinks.push_back(drink);
}

void deleteDrink() {
    string name;
    cout << "Enter drink name to delete: ";
    cin >> name;
    for (auto it = drinks.begin(); it != drinks.end(); ++it) {
        if (it->name == name) {
            drinks.erase(it);
            return;
        }
    }
    cout << "Drink not found.\n";
}

void updateDrink() {
    string name;
    cout << "Enter drink name to update: ";
    cin >> name;
    for (auto &drink : drinks) {
        if (drink.name == name) {
            cout << "Enter new price: ";
            cin >> drink.price;
            cout << "Enter new quantity: ";
            cin >> drink.quantity;
            return;
        }
    }
    cout << "Drink not found.\n";
}

void searchDrink() {
    string name;
    cout << "Enter drink name to search: ";
    cin >> name;
    for (const auto &drink : drinks) {
        if (drink.name == name) {
            cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << '\n';
            return;
        }
    }
    cout << "Drink not found.\n";
}

void displayDrinks() {
    cout << "Drinks List:\n";
    for (const auto &drink : drinks) {
        cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << '\n';
    }
}

void addSupplier() {
    Supplier supplier;
    cout << "Enter supplier name: ";
    cin >> supplier.name;
    cout << "Enter supplier contact info: ";
    cin >> supplier.contact_info;
    suppliers.push_back(supplier);
}

void deleteSupplier() {
    string name;
    cout << "Enter supplier name to delete: ";
    cin >> name;
    for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
        if (it->name == name) {
            suppliers.erase(it);
            return;
        }
    }
    cout << "Supplier not found.\n";
}

void updateSupplier() {
    string name;
    cout << "Enter supplier name to update: ";
    cin >> name;
    for (auto &supplier : suppliers) {
        if (supplier.name == name) {
            cout << "Enter new contact info: ";
            cin >> supplier.contact_info;
            return;
        }
    }
    cout << "Supplier not found.\n";
}

void searchSupplier() {
    string name;
    cout << "Enter supplier name to search: ";
    cin >> name;
    for (const auto &supplier : suppliers) {
        if (supplier.name == name) {
            cout << "Name: " << supplier.name << ", Contact Info: " << supplier.contact_info << '\n';
            return;
        }
    }
    cout << "Supplier not found.\n";
}

void displaySuppliers() {
    cout << "Suppliers List:\n";
    for (const auto &supplier : suppliers) {
        cout << "Name: " << supplier.name << ", Contact Info: " << supplier.contact_info << '\n';
    }
}

int main() {
    int choice;
    do {
        cout << "Coffee Shop Inventory Management\n";
        cout << "1. Add Drink\n2. Delete Drink\n3. Update Drink\n4. Search Drink\n5. Display Drinks\n";
        cout << "6. Add Supplier\n7. Delete Supplier\n8. Update Supplier\n9. Search Supplier\n10. Display Suppliers\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addDrink(); break;
            case 2: deleteDrink(); break;
            case 3: updateDrink(); break;
            case 4: searchDrink(); break;
            case 5: displayDrinks(); break;
            case 6: addSupplier(); break;
            case 7: deleteSupplier(); break;
            case 8: updateSupplier(); break;
            case 9: searchSupplier(); break;
            case 10: displaySuppliers(); break;
            case 0: break;
            default: cout << "Invalid choice.\n"; break;
        }
    } while (choice != 0);

    return 0;
}