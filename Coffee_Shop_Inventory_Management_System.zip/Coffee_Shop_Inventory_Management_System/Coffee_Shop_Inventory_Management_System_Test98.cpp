#include <iostream>
#include <string>
#include <vector>

class Drink {
public:
    int id;
    std::string name;
    double price;
    int quantity;
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contactInfo;
};

class CoffeeShopInventory {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    int drinkIDCounter = 0;
    int supplierIDCounter = 0;

public:
    void addDrink(const std::string &name, double price, int quantity) {
        drinks.push_back({++drinkIDCounter, name, price, quantity});
    }
    
    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(int id, const std::string &name, double price, int quantity) {
        for (auto &drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                drink.quantity = quantity;
                break;
            }
        }
    }

    Drink* searchDrink(int id) {
        for (auto &drink : drinks) {
            if (drink.id == id) {
                return &drink;
            }
        }
        return nullptr;
    }

    void displayDrinks() const {
        for (const auto &drink : drinks) {
            std::cout << "ID: " << drink.id << ", Name: " << drink.name
                      << ", Price: " << drink.price << ", Quantity: " << drink.quantity << "\n";
        }
    }

    void addSupplier(const std::string &name, const std::string &contactInfo) {
        suppliers.push_back({++supplierIDCounter, name, contactInfo});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string &name, const std::string &contactInfo) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto &supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() const {
        for (const auto &supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name
                      << ", Contact Info: " << supplier.contactInfo << "\n";
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink("Espresso", 2.50, 100);
    inventory.addDrink("Latte", 3.50, 50);
    inventory.addSupplier("Coffee Beans Co.", "123-456-7890");
    inventory.addSupplier("Dairy Supplies Inc.", "987-654-3210");
    
    inventory.displayDrinks();
    inventory.displaySuppliers();
    
    Drink* drink = inventory.searchDrink(1);
    if(drink) std::cout << "Found Drink: " << drink->name << "\n";

    Supplier* supplier = inventory.searchSupplier(1);
    if(supplier) std::cout << "Found Supplier: " << supplier->name << "\n";
    
    inventory.updateDrink(1, "Espresso", 2.75, 120);
    inventory.deleteSupplier(2);

    inventory.displayDrinks();
    inventory.displaySuppliers();

    return 0;
}