#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Drink {
public:
    int id;
    string name;
    int quantity;
    double price;

    Drink(int id, string name, int quantity, double price)
        : id(id), name(name), quantity(quantity), price(price) {}
};

class Supplier {
public:
    int id;
    string name;
    string contactInfo;

    Supplier(int id, string name, string contactInfo)
        : id(id), name(name), contactInfo(contactInfo) {}
};

class InventoryManagement {
    vector<Drink> drinks;
    vector<Supplier> suppliers;

public:
    void addDrink(int id, string name, int quantity, double price) {
        drinks.emplace_back(id, name, quantity, price);
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(int id, string name, int quantity, double price) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.quantity = quantity;
                drink.price = price;
                break;
            }
        }
    }

    void searchDrink(int id) {
        for (const auto& drink : drinks) {
            if (drink.id == id) {
                cout << "Drink ID: " << drink.id << ", Name: " << drink.name
                     << ", Quantity: " << drink.quantity << ", Price: " << drink.price << endl;
                return;
            }
        }
        cout << "Drink not found." << endl;
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            cout << "Drink ID: " << drink.id << ", Name: " << drink.name
                 << ", Quantity: " << drink.quantity << ", Price: " << drink.price << endl;
        }
    }

    void addSupplier(int id, string name, string contactInfo) {
        suppliers.emplace_back(id, name, contactInfo);
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, string name, string contactInfo) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name
                     << ", Contact Info: " << supplier.contactInfo << endl;
                return;
            }
        }
        cout << "Supplier not found." << endl;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name
                 << ", Contact Info: " << supplier.contactInfo << endl;
        }
    }
};

int main() {
    InventoryManagement inventory;

    inventory.addDrink(1, "Espresso", 50, 2.5);
    inventory.addDrink(2, "Latte", 30, 3.0);

    inventory.addSupplier(1, "Coffee Suppliers Ltd.", "contact@coffee.com");
    inventory.addSupplier(2, "Global Beans", "info@globalbeans.com");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    inventory.updateDrink(1, "Espresso", 40, 2.6);
    inventory.updateSupplier(1, "Coffee Suppliers Ltd.", "newcontact@coffee.com");

    inventory.searchDrink(1);
    inventory.searchSupplier(1);

    inventory.deleteDrink(2);
    inventory.deleteSupplier(2);

    inventory.displayDrinks();
    inventory.displaySuppliers();

    return 0;
}