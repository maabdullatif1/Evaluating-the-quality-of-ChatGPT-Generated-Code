#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    int id;
    std::string name;
    double price;

    Drink(int d_id, const std::string& d_name, double d_price) 
        : id(d_id), name(d_name), price(d_price) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int s_id, const std::string& s_name, const std::string& s_contact) 
        : id(s_id), name(s_name), contact(s_contact) {}
};

class CoffeeShop {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(int id, const std::string& name, double price) {
        drinks.emplace_back(id, name, price);
    }

    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.emplace_back(id, name, contact);
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateDrink(int id, const std::string& name, double price) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Drink* searchDrink(int id) {
        for (auto& drink : drinks) {
            if (drink.id == id) return &drink;
        }
        return nullptr;
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) return &supplier;
        }
        return nullptr;
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            std::cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: $" << drink.price << std::endl;
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    CoffeeShop shop;
    
    shop.addDrink(1, "Espresso", 2.5);
    shop.addDrink(2, "Latte", 3.5);
    shop.addSupplier(1, "Coffee Beans Co.", "123-456-7890");
    shop.addSupplier(2, "Sugar Supplies Ltd.", "098-765-4321");

    std::cout << "Drinks:" << std::endl;
    shop.displayDrinks();
    std::cout << "Suppliers:" << std::endl;
    shop.displaySuppliers();
    
    shop.updateDrink(1, "Espresso", 2.75);
    shop.deleteSupplier(2);

    std::cout << "\nUpdated Drinks:" << std::endl;
    shop.displayDrinks();
    std::cout << "Updated Suppliers:" << std::endl;
    shop.displaySuppliers();

    return 0;
}