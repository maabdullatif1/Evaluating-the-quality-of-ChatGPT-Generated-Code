#include <iostream>
#include <vector>
#include <string>

struct Drink {
    std::string name;
    double price;
    int quantity;
};

struct Supplier {
    std::string name;
    std::string contact;
};

class CoffeeShopInventory {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
public:
    void addDrink(const Drink& drink) {
        drinks.push_back(drink);
    }

    void deleteDrink(const std::string& drinkName) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == drinkName) {
                drinks.erase(it);
                return;
            }
        }
    }

    void updateDrink(const std::string& drinkName, const Drink& newDrink) {
        for (auto& drink : drinks) {
            if (drink.name == drinkName) {
                drink = newDrink;
                return;
            }
        }
    }

    Drink* searchDrink(const std::string& drinkName) {
        for (auto& drink : drinks) {
            if (drink.name == drinkName) {
                return &drink;
            }
        }
        return nullptr;
    }

    void displayDrinks() const {
        for (const auto& drink : drinks) {
            std::cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << std::endl;
        }
    }

    void addSupplier(const Supplier& supplier) {
        suppliers.push_back(supplier);
    }

    void deleteSupplier(const std::string& supplierName) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == supplierName) {
                suppliers.erase(it);
                return;
            }
        }
    }

    void updateSupplier(const std::string& supplierName, const Supplier& newSupplier) {
        for (auto& supplier : suppliers) {
            if (supplier.name == supplierName) {
                supplier = newSupplier;
                return;
            }
        }
    }

    Supplier* searchSupplier(const std::string& supplierName) {
        for (auto& supplier : suppliers) {
            if (supplier.name == supplierName) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            std::cout << "Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink({"Espresso", 2.5, 100});
    inventory.addDrink({"Latte", 3.0, 50});
    inventory.addSupplier({"Coffee Corp", "123-456-7890"});
    
    inventory.displayDrinks();
    inventory.displaySuppliers();
    
    Drink* searchResult = inventory.searchDrink("Latte");
    if (searchResult) {
        std::cout << "Found drink: " << searchResult->name << std::endl;
    }

    Supplier* supplierResult = inventory.searchSupplier("Coffee Corp");
    if (supplierResult) {
        std::cout << "Found supplier: " << supplierResult->name << std::endl;
    }

    inventory.updateDrink("Espresso", {"Espresso", 2.75, 110});
    inventory.displayDrinks();

    inventory.deleteDrink("Latte");
    inventory.displayDrinks();

    inventory.updateSupplier("Coffee Corp", {"Coffee Co.", "987-654-3210"});
    inventory.displaySuppliers();

    inventory.deleteSupplier("Coffee Co.");
    inventory.displaySuppliers();

    return 0;
}