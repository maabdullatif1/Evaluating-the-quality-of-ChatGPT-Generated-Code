#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    int id;
    string name;
    double price;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

class Inventory {
private:
    vector<Drink> drinks;
    vector<Supplier> suppliers;
    int drinkID = 0;
    int supplierID = 0;

    Drink* findDrink(int id) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                return &drink;
            }
        }
        return nullptr;
    }

    Supplier* findSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                return &supplier;
            }
        }
        return nullptr;
    }

public:
    void addDrink(string name, double price) {
        drinks.push_back({drinkID++, name, price});
    }

    void updateDrink(int id, string name, double price) {
        Drink* drink = findDrink(id);
        if (drink) {
            drink->name = name;
            drink->price = price;
        }
    }

    void deleteDrink(int id) {
        drinks.erase(
            remove_if(drinks.begin(), drinks.end(),
                      [id](Drink& drink) { return drink.id == id; }),
            drinks.end());
    }

    Drink* searchDrink(int id) {
        return findDrink(id);
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            cout << "ID: " << drink.id << ", Name: " << drink.name
                 << ", Price: $" << drink.price << endl;
        }
    }

    void addSupplier(string name, string contact) {
        suppliers.push_back({supplierID++, name, contact});
    }

    void updateSupplier(int id, string name, string contact) {
        Supplier* supplier = findSupplier(id);
        if (supplier) {
            supplier->name = name;
            supplier->contact = contact;
        }
    }

    void deleteSupplier(int id) {
        suppliers.erase(
            remove_if(suppliers.begin(), suppliers.end(),
                      [id](Supplier& supplier) { return supplier.id == id; }),
            suppliers.end());
    }

    Supplier* searchSupplier(int id) {
        return findSupplier(id);
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "ID: " << supplier.id << ", Name: " << supplier.name
                 << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addDrink("Latte", 4.5);
    inventory.addDrink("Espresso", 3.0);
    inventory.addSupplier("Coffee Beans Co", "123-456-7890");
    inventory.addSupplier("Dairy Supply Inc.", "098-765-4321");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    Drink* foundDrink = inventory.searchDrink(0);
    if (foundDrink) {
        cout << "Found Drink: " << foundDrink->name << ", Price: $" << foundDrink->price << endl;
    }

    Supplier* foundSupplier = inventory.searchSupplier(0);
    if (foundSupplier) {
        cout << "Found Supplier: " << foundSupplier->name << ", Contact: " << foundSupplier->contact << endl;
    }

    inventory.updateDrink(1, "Double Espresso", 3.5);
    inventory.updateSupplier(1, "Dairy Supply Inc.", "111-222-3333");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    inventory.deleteDrink(0);
    inventory.deleteSupplier(1);

    inventory.displayDrinks();
    inventory.displaySuppliers();

    return 0;
}