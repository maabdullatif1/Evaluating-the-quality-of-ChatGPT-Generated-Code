#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    string name;
    double price;
    int quantity;
};

struct Supplier {
    string name;
    string contact;
};

class CoffeeShopInventory {
    vector<Drink> drinks;
    vector<Supplier> suppliers;

public:
    void addDrink(const string& name, double price, int quantity) {
        drinks.push_back({name, price, quantity});
    }

    void deleteDrink(const string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                return;
            }
        }
    }

    void updateDrink(const string& name, double price, int quantity) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = quantity;
                return;
            }
        }
    }

    Drink* searchDrink(const string& name) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                return &drink;
            }
        }
        return nullptr;
    }

    void displayDrinks() const {
        for (const auto& drink : drinks) {
            cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << endl;
        }
    }

    void addSupplier(const string& name, const string& contact) {
        suppliers.push_back({name, contact});
    }

    void deleteSupplier(const string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                return;
            }
        }
    }

    Supplier* searchSupplier(const string& name) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            cout << "Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;

    inventory.addDrink("Latte", 3.5, 10);
    inventory.addDrink("Espresso", 2.5, 20);
    
    inventory.addSupplier("ACME", "123-456-789");
    inventory.addSupplier("CoffeeCo", "987-654-321");

    cout << "Drinks:" << endl;
    inventory.displayDrinks();

    cout << endl << "Suppliers:" << endl;
    inventory.displaySuppliers();

    return 0;
}