#include <iostream>
#include <vector>
#include <string>

struct Drink {
    int id;
    std::string name;
    double price;
};

struct Supplier {
    int id;
    std::string name;
    std::string contact;
};

class InventoryManagementSystem {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
    int drinkIdCounter;
    int supplierIdCounter;

public:
    InventoryManagementSystem() : drinkIdCounter(0), supplierIdCounter(0) {}

    void addDrink(const std::string& name, double price) {
        Drink drink = {++drinkIdCounter, name, price};
        drinks.push_back(drink);
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(int id, const std::string& name, double price) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                break;
            }
        }
    }

    Drink* searchDrink(int id) {
        for (auto& drink : drinks) {
            if (drink.id == id) return &drink;
        }
        return nullptr;
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        Supplier supplier = {++supplierIdCounter, name, contact};
        suppliers.push_back(supplier);
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                break;
            }
        }
    }

    Supplier* searchSupplier(int id) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) return &supplier;
        }
        return nullptr;
    }

    void displayDrinks() const {
        for (const auto& drink : drinks) {
            std::cout << "Drink ID: " << drink.id << ", Name: " << drink.name << ", Price: " << drink.price << std::endl;
        }
    }

    void displaySuppliers() const {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;

    ims.addDrink("Espresso", 2.5);
    ims.addDrink("Latte", 3.0);
    ims.addSupplier("Coffee Beans Ltd", "123-456-789");
    ims.addSupplier("Milk Suppliers Inc", "987-654-321");

    ims.displayDrinks();
    ims.displaySuppliers();

    Drink* drink = ims.searchDrink(1);
    if (drink) {
        ims.updateDrink(1, "Double Espresso", 2.8);
    }

    Supplier* supplier = ims.searchSupplier(2);
    if (supplier) {
        ims.updateSupplier(2, "Best Milk Suppliers", "555-555-555");
    }

    ims.displayDrinks();
    ims.displaySuppliers();

    ims.deleteDrink(1);
    ims.deleteSupplier(1);

    ims.displayDrinks();
    ims.displaySuppliers();

    return 0;
}