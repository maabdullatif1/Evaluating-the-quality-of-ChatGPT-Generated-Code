#include <iostream>
#include <vector>
#include <string>

struct Drink {
    std::string name;
    double price;
    int quantity;
};

struct Supplier {
    std::string name;
    std::string contact;
};

class CoffeeShopInventory {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

    int findDrinkIndex(const std::string& name) {
        for (size_t i = 0; i < drinks.size(); ++i) {
            if (drinks[i].name == name) {
                return i;
            }
        }
        return -1;
    }

    int findSupplierIndex(const std::string& name) {
        for (size_t i = 0; i < suppliers.size(); ++i) {
            if (suppliers[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addDrink(const std::string& name, double price, int quantity) {
        drinks.push_back({name, price, quantity});
    }

    void updateDrink(const std::string& name, double price, int quantity) {
        int index = findDrinkIndex(name);
        if (index != -1) {
            drinks[index].price = price;
            drinks[index].quantity = quantity;
        }
    }

    void deleteDrink(const std::string& name) {
        int index = findDrinkIndex(name);
        if (index != -1) {
            drinks.erase(drinks.begin() + index);
        }
    }

    Drink* searchDrink(const std::string& name) {
        int index = findDrinkIndex(name);
        return index != -1 ? &drinks[index] : nullptr;
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            std::cout << "Name: " << drink.name << ", Price: $" << drink.price << ", Quantity: " << drink.quantity << std::endl;
        }
    }

    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back({name, contact});
    }

    void updateSupplier(const std::string& name, const std::string& contact) {
        int index = findSupplierIndex(name);
        if (index != -1) {
            suppliers[index].contact = contact;
        }
    }

    void deleteSupplier(const std::string& name) {
        int index = findSupplierIndex(name);
        if (index != -1) {
            suppliers.erase(suppliers.begin() + index);
        }
    }

    Supplier* searchSupplier(const std::string& name) {
        int index = findSupplierIndex(name);
        return index != -1 ? &suppliers[index] : nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;

    inventory.addDrink("Espresso", 2.5, 100);
    inventory.addDrink("Latte", 3.0, 50);

    inventory.addSupplier("Coffee Beans Co", "123-456-7890");
    inventory.addSupplier("Milk Supplies Inc", "098-765-4321");

    std::cout << "Drinks:\n";
    inventory.displayDrinks();

    std::cout << "\nSuppliers:\n";
    inventory.displaySuppliers();

    return 0;
}