#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    int id;
    std::string name;
    double price;
    int quantity;

    Drink(int i, const std::string& n, double p, int q)
        : id(i), name(n), price(p), quantity(q) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int i, const std::string& n, const std::string& c)
        : id(i), name(n), contact(c) {}
};

class Inventory {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

    template<typename T>
    void display(const std::vector<T>& items) {
        for (const auto& item : items) {
            std::cout << "ID: " << item.id << "\n";
            if constexpr (std::is_same<T, Drink>::value) {
                std::cout << "Name: " << item.name << "\nPrice: " << item.price 
                          << "\nQuantity: " << item.quantity << "\n";
            } else {
                std::cout << "Name: " << item.name << "\nContact: " << item.contact << "\n";
            }
            std::cout << "----------------------\n";
        }
    }

public:
    void addDrink(int id, const std::string& name, double price, int quantity) {
        drinks.emplace_back(id, name, price, quantity);
    }

    void addSupplier(int id, const std::string& name, const std::string& contact) {
        suppliers.emplace_back(id, name, contact);
    }

    void deleteDrink(int id) {
        drinks.erase(
            std::remove_if(drinks.begin(), drinks.end(), [id](const Drink& d) { return d.id == id; }),
            drinks.end()
        );
    }

    void deleteSupplier(int id) {
        suppliers.erase(
            std::remove_if(suppliers.begin(), suppliers.end(), [id](const Supplier& s) { return s.id == id; }),
            suppliers.end()
        );
    }

    void updateDrink(int id, const std::string& name, double price, int quantity) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                drink.quantity = quantity;
                return;
            }
        }
    }

    void updateSupplier(int id, const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                return;
            }
        }
    }

    void searchDrink(int id) {
        for (const auto& drink : drinks) {
            if (drink.id == id) {
                std::cout << "Drink Found:\nID: " << drink.id << "\nName: " << drink.name 
                          << "\nPrice: " << drink.price << "\nQuantity: " << drink.quantity << "\n";
                return;
            }
        }
        std::cout << "Drink not found.\n";
    }

    void searchSupplier(int id) {
        for (const auto& supplier : suppliers) {
            if (supplier.id == id) {
                std::cout << "Supplier Found:\nID: " << supplier.id << "\nName: " << supplier.name 
                          << "\nContact: " << supplier.contact << "\n";
                return;
            }
        }
        std::cout << "Supplier not found.\n";
    }

    void displayDrinks() {
        std::cout << "Drinks Inventory:\n";
        display(drinks);
    }

    void displaySuppliers() {
        std::cout << "Suppliers List:\n";
        display(suppliers);
    }
};

int main() {
    Inventory inventory;
    inventory.addDrink(1, "Espresso", 3.5, 50);
    inventory.addDrink(2, "Latte", 4.0, 30);
    inventory.addSupplier(1, "Coffee Beans Inc.", "123-456-7890");
    inventory.displayDrinks();
    inventory.displaySuppliers();
    inventory.updateDrink(1, "Espresso", 3.75, 45);
    inventory.searchDrink(1);
    inventory.deleteDrink(2);
    inventory.displayDrinks();
    return 0;
}