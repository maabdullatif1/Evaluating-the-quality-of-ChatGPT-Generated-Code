#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    int id;
    std::string name;
    double price;
    Drink(int i, const std::string &n, double p) : id(i), name(n), price(p) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;
    Supplier(int i, const std::string &n, const std::string &c) : id(i), name(n), contact(c) {}
};

class CoffeeShopInventory {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

    template <typename T>
    int findById(const std::vector<T> &list, int id) {
        for (int i = 0; i < list.size(); i++)
            if (list[i].id == id) return i;
        return -1;
    }

public:
    void addDrink(int id, const std::string &name, double price) {
        if (findById(drinks, id) == -1) {
            drinks.push_back(Drink(id, name, price));
        }
    }

    void deleteDrink(int id) {
        int idx = findById(drinks, id);
        if (idx != -1) {
            drinks.erase(drinks.begin() + idx);
        }
    }

    void updateDrink(int id, const std::string &name, double price) {
        int idx = findById(drinks, id);
        if (idx != -1) {
            drinks[idx].name = name;
            drinks[idx].price = price;
        }
    }

    void searchDrink(int id) {
        int idx = findById(drinks, id);
        if (idx != -1) {
            std::cout << "Drink ID: " << drinks[idx].id << ", Name: " << drinks[idx].name << ", Price: $" << drinks[idx].price << std::endl;
        } else {
            std::cout << "Drink not found." << std::endl;
        }
    }

    void displayDrinks() {
        for (const auto &drink : drinks) {
            std::cout << "Drink ID: " << drink.id << ", Name: " << drink.name << ", Price: $" << drink.price << std::endl;
        }
    }

    void addSupplier(int id, const std::string &name, const std::string &contact) {
        if (findById(suppliers, id) == -1) {
            suppliers.push_back(Supplier(id, name, contact));
        }
    }

    void deleteSupplier(int id) {
        int idx = findById(suppliers, id);
        if (idx != -1) {
            suppliers.erase(suppliers.begin() + idx);
        }
    }

    void updateSupplier(int id, const std::string &name, const std::string &contact) {
        int idx = findById(suppliers, id);
        if (idx != -1) {
            suppliers[idx].name = name;
            suppliers[idx].contact = contact;
        }
    }

    void searchSupplier(int id) {
        int idx = findById(suppliers, id);
        if (idx != -1) {
            std::cout << "Supplier ID: " << suppliers[idx].id << ", Name: " << suppliers[idx].name << ", Contact: " << suppliers[idx].contact << std::endl;
        } else {
            std::cout << "Supplier not found." << std::endl;
        }
    }
    
    void displaySuppliers() {
        for (const auto &supplier : suppliers) {
            std::cout << "Supplier ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;

    inventory.addDrink(1, "Espresso", 2.50);
    inventory.addDrink(2, "Cappuccino", 3.00);
    inventory.displayDrinks();
    
    inventory.updateDrink(1, "Espresso", 2.75);
    inventory.searchDrink(1);
    
    inventory.deleteDrink(2);
    inventory.displayDrinks();
    
    inventory.addSupplier(1, "Best Beans", "contact@bestbeans.com");
    inventory.addSupplier(2, "Coffee Co.", "info@coffeeco.com");
    inventory.displaySuppliers();
    
    inventory.updateSupplier(2, "Coffee Co. Ltd.", "support@coffeeco.com");
    inventory.searchSupplier(2);
    
    inventory.deleteSupplier(1);
    inventory.displaySuppliers();

    return 0;
}