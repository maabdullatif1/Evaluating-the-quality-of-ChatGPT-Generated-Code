#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    int id;
    std::string name;
    double price;

    Drink(int i, std::string n, double p) : id(i), name(n), price(p) {}
};

class Supplier {
public:
    int id;
    std::string name;
    std::string contact;

    Supplier(int i, std::string n, std::string c) : id(i), name(n), contact(c) {}
};

std::vector<Drink> drinks;
std::vector<Supplier> suppliers;

void addDrink(int id, std::string name, double price) {
    drinks.push_back(Drink(id, name, price));
}

void deleteDrink(int id) {
    for (auto it = drinks.begin(); it != drinks.end(); ++it) {
        if (it->id == id) {
            drinks.erase(it);
            break;
        }
    }
}

void updateDrink(int id, std::string name, double price) {
    for (auto &drink : drinks) {
        if (drink.id == id) {
            drink.name = name;
            drink.price = price;
            break;
        }
    }
}

Drink* searchDrink(int id) {
    for (auto &drink : drinks) {
        if (drink.id == id) {
            return &drink;
        }
    }
    return nullptr;
}

void displayDrinks() {
    for (const auto &drink : drinks) {
        std::cout << "ID: " << drink.id << ", Name: " << drink.name << ", Price: " << drink.price << std::endl;
    }
}

void addSupplier(int id, std::string name, std::string contact) {
    suppliers.push_back(Supplier(id, name, contact));
}

void deleteSupplier(int id) {
    for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
        if (it->id == id) {
            suppliers.erase(it);
            break;
        }
    }
}

void updateSupplier(int id, std::string name, std::string contact) {
    for (auto &supplier : suppliers) {
        if (supplier.id == id) {
            supplier.name = name;
            supplier.contact = contact;
            break;
        }
    }
}

Supplier* searchSupplier(int id) {
    for (auto &supplier : suppliers) {
        if (supplier.id == id) {
            return &supplier;
        }
    }
    return nullptr;
}

void displaySuppliers() {
    for (const auto &supplier : suppliers) {
        std::cout << "ID: " << supplier.id << ", Name: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
    }
}

int main() {
    addDrink(1, "Espresso", 2.50);
    addDrink(2, "Latte", 3.50);
    updateDrink(1, "Double Espresso", 3.00);
    displayDrinks();
    deleteDrink(2);
    displayDrinks();
    
    addSupplier(1, "ABC Supplies", "123-456-7890");
    addSupplier(2, "XYZ Inc.", "987-654-3210");
    updateSupplier(1, "ABC Supplies and Co.", "123-456-7000");
    displaySuppliers();
    deleteSupplier(2);
    displaySuppliers();

    return 0;
}