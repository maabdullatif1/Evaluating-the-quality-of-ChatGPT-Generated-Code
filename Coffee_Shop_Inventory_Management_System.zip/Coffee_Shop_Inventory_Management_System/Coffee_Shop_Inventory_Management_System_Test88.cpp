#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    string name;
    double price;
    int quantity;
};

struct Supplier {
    string name;
    string contactInfo;
};

class CoffeeShopInventory {
private:
    vector<Drink> drinks;
    vector<Supplier> suppliers;

public:
    void addDrink(const string& name, double price, int quantity) {
        drinks.push_back({name, price, quantity});
    }

    void deleteDrink(const string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(const string& name, double price, int quantity) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.quantity = quantity;
                break;
            }
        }
    }

    Drink* searchDrink(const string& name) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                return &drink;
            }
        }
        return nullptr;
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            cout << "Drink: " << drink.name << ", Price: $" << drink.price << ", Quantity: " << drink.quantity << endl;
        }
    }

    void addSupplier(const string& name, const string& contactInfo) {
        suppliers.push_back({name, contactInfo});
    }

    void deleteSupplier(const string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    Supplier* searchSupplier(const string& name) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "Supplier: " << supplier.name << ", Contact: " << supplier.contactInfo << endl;
        }
    }
};

int main() {
    CoffeeShopInventory inventory;
    inventory.addDrink("Espresso", 2.50, 100);
    inventory.addDrink("Latte", 3.75, 50);
    inventory.addSupplier("Coffee Beans Co.", "123-456-7890");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    auto* drink = inventory.searchDrink("Espresso");
    if (drink) {
        cout << "Found Drink - Name: " << drink->name << ", Price: $" << drink->price << ", Quantity: " << drink->quantity << endl;
    }

    auto* supplier = inventory.searchSupplier("Coffee Beans Co.");
    if (supplier) {
        cout << "Found Supplier - Name: " << supplier->name << ", Contact: " << supplier->contactInfo << endl;
    }

    inventory.updateDrink("Espresso", 2.75, 90);
    inventory.deleteSupplier("Coffee Beans Co.");

    inventory.displayDrinks();
    inventory.displaySuppliers();

    return 0;
}