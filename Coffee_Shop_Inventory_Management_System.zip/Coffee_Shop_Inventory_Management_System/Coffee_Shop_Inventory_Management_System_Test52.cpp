#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    string name;
    double price;
};

struct Supplier {
    string name;
    string contact;
};

class InventoryManagementSystem {
    vector<Drink> drinks;
    vector<Supplier> suppliers;
public:
    void addDrink(const string& name, double price) {
        drinks.push_back({name, price});
    }

    void deleteDrink(const string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(const string& name, double price) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                break;
            }
        }
    }

    void searchDrink(const string& name) {
        for (const auto& drink : drinks) {
            if (drink.name == name) {
                cout << "Drink found: " << drink.name << ", Price: " << drink.price << endl;
                return;
            }
        }
        cout << "Drink not found." << endl;
    }

    void displayDrinks() {
        cout << "Drinks List:" << endl;
        for (const auto& drink : drinks) {
            cout << "Name: " << drink.name << ", Price: " << drink.price << endl;
        }
    }

    void addSupplier(const string& name, const string& contact) {
        suppliers.push_back({name, contact});
    }

    void deleteSupplier(const string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(const string& name, const string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contact = contact;
                break;
            }
        }
    }

    void searchSupplier(const string& name) {
        for (const auto& supplier : suppliers) {
            if (supplier.name == name) {
                cout << "Supplier found: " << supplier.name << ", Contact: " << supplier.contact << endl;
                return;
            }
        }
        cout << "Supplier not found." << endl;
    }

    void displaySuppliers() {
        cout << "Suppliers List:" << endl;
        for (const auto& supplier : suppliers) {
            cout << "Name: " << supplier.name << ", Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    InventoryManagementSystem ims;
    ims.addDrink("Espresso", 2.5);
    ims.addDrink("Latte", 3.0);
    ims.displayDrinks();
    ims.searchDrink("Latte");
    ims.updateDrink("Latte", 3.5);
    ims.displayDrinks();
    ims.deleteDrink("Espresso");
    ims.displayDrinks();

    ims.addSupplier("CoffeeSupplier", "123-456-7890");
    ims.displaySuppliers();
    ims.searchSupplier("CoffeeSupplier");
    ims.updateSupplier("CoffeeSupplier", "098-765-4321");
    ims.displaySuppliers();
    ims.deleteSupplier("CoffeeSupplier");
    ims.displaySuppliers();

    return 0;
}