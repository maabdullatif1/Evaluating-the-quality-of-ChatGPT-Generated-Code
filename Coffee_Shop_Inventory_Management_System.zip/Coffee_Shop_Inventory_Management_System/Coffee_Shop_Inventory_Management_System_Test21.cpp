#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    std::string name;
    double price;
    int stock;

    Drink(std::string name, double price, int stock)
        : name(name), price(price), stock(stock) {}
};

class Supplier {
public:
    std::string name;
    std::string contactInfo;

    Supplier(std::string name, std::string contactInfo)
        : name(name), contactInfo(contactInfo) {}
};

class InventoryManagementSystem {
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;

public:
    void addDrink(const std::string& name, double price, int stock) {
        drinks.emplace_back(name, price, stock);
    }

    void deleteDrink(const std::string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }

    void updateDrink(const std::string& name, double price, int stock) {
        for (auto &drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                drink.stock = stock;
                break;
            }
        }
    }

    Drink* searchDrink(const std::string& name) {
        for (auto &drink : drinks) {
            if (drink.name == name) {
                return &drink;
            }
        }
        return nullptr;
    }

    void displayDrinks() const {
        for (const auto &drink : drinks) {
            std::cout << "Name: " << drink.name
                      << ", Price: " << drink.price
                      << ", Stock: " << drink.stock << std::endl;
        }
    }

    void addSupplier(const std::string& name, const std::string& contactInfo) {
        suppliers.emplace_back(name, contactInfo);
    }

    void deleteSupplier(const std::string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }

    void updateSupplier(const std::string& name, const std::string& contactInfo) {
        for (auto &supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contactInfo = contactInfo;
                break;
            }
        }
    }

    Supplier* searchSupplier(const std::string& name) {
        for (auto &supplier : suppliers) {
            if (supplier.name == name) {
                return &supplier;
            }
        }
        return nullptr;
    }

    void displaySuppliers() const {
        for (const auto &supplier : suppliers) {
            std::cout << "Name: " << supplier.name
                      << ", Contact: " << supplier.contactInfo << std::endl;
        }
    }
};

int main() {
    InventoryManagementSystem system;
    system.addDrink("Espresso", 2.5, 100);
    system.addDrink("Latte", 3.0, 50);
    system.addSupplier("Coffee Co", "contact@coffeeco.com");
    system.addSupplier("Beans Supplier", "beans@coffee.com");

    system.displayDrinks();
    system.displaySuppliers();

    Drink* drink = system.searchDrink("Latte");
    if (drink) {
        std::cout << "Found drink: " << drink->name << std::endl;
    }

    Supplier* supplier = system.searchSupplier("Beans Supplier");
    if (supplier) {
        std::cout << "Found supplier: " << supplier->name << std::endl;
    }
    
    system.updateDrink("Espresso", 2.7, 90);
    system.updateSupplier("Coffee Co", "newcontact@coffeeco.com");

    system.displayDrinks();
    system.displaySuppliers();

    system.deleteDrink("Latte");
    system.deleteSupplier("Beans Supplier");

    system.displayDrinks();
    system.displaySuppliers();

    return 0;
}