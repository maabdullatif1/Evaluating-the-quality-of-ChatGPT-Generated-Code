#include <iostream>
#include <vector>
#include <string>

class Drink {
public:
    std::string name;
    double price;
    Drink(const std::string& n, double p) : name(n), price(p) {}
};

class Supplier {
public:
    std::string name;
    std::string contact;
    Supplier(const std::string& n, const std::string& c) : name(n), contact(c) {}
};

class Inventory {
private:
    std::vector<Drink> drinks;
    std::vector<Supplier> suppliers;
public:
    void addDrink(const std::string& name, double price) {
        drinks.push_back(Drink(name, price));
    }
    
    void deleteDrink(const std::string& name) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->name == name) {
                drinks.erase(it);
                break;
            }
        }
    }
    
    void updateDrink(const std::string& name, double price) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                drink.price = price;
                break;
            }
        }
    }
    
    Drink* searchDrink(const std::string& name) {
        for (auto& drink : drinks) {
            if (drink.name == name) {
                return &drink;
            }
        }
        return nullptr;
    }
    
    void displayDrinks() {
        for (const auto& drink : drinks) {
            std::cout << "Drink: " << drink.name << ", Price: $" << drink.price << std::endl;
        }
    }
    
    void addSupplier(const std::string& name, const std::string& contact) {
        suppliers.push_back(Supplier(name, contact));
    }
    
    void deleteSupplier(const std::string& name) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->name == name) {
                suppliers.erase(it);
                break;
            }
        }
    }
    
    void updateSupplier(const std::string& name, const std::string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                supplier.contact = contact;
                break;
            }
        }
    }
    
    Supplier* searchSupplier(const std::string& name) {
        for (auto& supplier : suppliers) {
            if (supplier.name == name) {
                return &supplier;
            }
        }
        return nullptr;
    }
    
    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            std::cout << "Supplier: " << supplier.name << ", Contact: " << supplier.contact << std::endl;
        }
    }
};

int main() {
    Inventory inventory;
    inventory.addDrink("Espresso", 2.50);
    inventory.addDrink("Latte", 3.50);
    inventory.displayDrinks();
    inventory.addSupplier("Coffee Beans Inc.", "123-456-7890");
    inventory.displaySuppliers();
    return 0;
}