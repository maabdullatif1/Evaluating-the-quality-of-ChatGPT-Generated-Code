#include <iostream>
#include <vector>
#include <string>

struct Drink {
    std::string name;
    double price;
    int quantity;
};

struct Supplier {
    std::string name;
    std::string contactInfo;
};

std::vector<Drink> drinksInventory;
std::vector<Supplier> suppliersList;

void addDrink() {
    Drink drink;
    std::cout << "Enter drink name: ";
    std::cin >> drink.name;
    std::cout << "Enter drink price: ";
    std::cin >> drink.price;
    std::cout << "Enter drink quantity: ";
    std::cin >> drink.quantity;
    drinksInventory.push_back(drink);
}

void deleteDrink() {
    std::string name;
    std::cout << "Enter drink name to delete: ";
    std::cin >> name;
    for (auto it = drinksInventory.begin(); it != drinksInventory.end(); ++it) {
        if (it->name == name) {
            drinksInventory.erase(it);
            std::cout << "Drink deleted.\n";
            return;
        }
    }
    std::cout << "Drink not found.\n";
}

void updateDrink() {
    std::string name;
    std::cout << "Enter drink name to update: ";
    std::cin >> name;
    for (auto& drink : drinksInventory) {
        if (drink.name == name) {
            std::cout << "Enter new price: ";
            std::cin >> drink.price;
            std::cout << "Enter new quantity: ";
            std::cin >> drink.quantity;
            std::cout << "Drink updated.\n";
            return;
        }
    }
    std::cout << "Drink not found.\n";
}

void displayDrinks() {
    for (const auto& drink : drinksInventory) {
        std::cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << "\n";
    }
}

void searchDrink() {
    std::string name;
    std::cout << "Enter drink name to search: ";
    std::cin >> name;
    for (const auto& drink : drinksInventory) {
        if (drink.name == name) {
            std::cout << "Name: " << drink.name << ", Price: " << drink.price << ", Quantity: " << drink.quantity << "\n";
            return;
        }
    }
    std::cout << "Drink not found.\n";
}

void addSupplier() {
    Supplier supplier;
    std::cout << "Enter supplier name: ";
    std::cin >> supplier.name;
    std::cout << "Enter supplier contact info: ";
    std::cin.ignore();
    std::getline(std::cin, supplier.contactInfo);
    suppliersList.push_back(supplier);
}

void deleteSupplier() {
    std::string name;
    std::cout << "Enter supplier name to delete: ";
    std::cin >> name;
    for (auto it = suppliersList.begin(); it != suppliersList.end(); ++it) {
        if (it->name == name) {
            suppliersList.erase(it);
            std::cout << "Supplier deleted.\n";
            return;
        }
    }
    std::cout << "Supplier not found.\n";
}

void updateSupplier() {
    std::string name;
    std::cout << "Enter supplier name to update: ";
    std::cin >> name;
    for (auto& supplier : suppliersList) {
        if (supplier.name == name) {
            std::cout << "Enter new contact info: ";
            std::cin.ignore();
            std::getline(std::cin, supplier.contactInfo);
            std::cout << "Supplier updated.\n";
            return;
        }
    }
    std::cout << "Supplier not found.\n";
}

void displaySuppliers() {
    for (const auto& supplier : suppliersList) {
        std::cout << "Name: " << supplier.name << ", Contact Info: " << supplier.contactInfo << "\n";
    }
}

void searchSupplier() {
    std::string name;
    std::cout << "Enter supplier name to search: ";
    std::cin >> name;
    for (const auto& supplier : suppliersList) {
        if (supplier.name == name) {
            std::cout << "Name: " << supplier.name << ", Contact Info: " << supplier.contactInfo << "\n";
            return;
        }
    }
    std::cout << "Supplier not found.\n";
}

int main() {
    int choice;
    do {
        std::cout << "1. Add Drink\n2. Delete Drink\n3. Update Drink\n4. Display Drinks\n5. Search Drink\n";
        std::cout << "6. Add Supplier\n7. Delete Supplier\n8. Update Supplier\n9. Display Suppliers\n10. Search Supplier\n0. Exit\n";
        std::cout << "Enter choice: ";
        std::cin >> choice;
        switch (choice) {
            case 1: addDrink(); break;
            case 2: deleteDrink(); break;
            case 3: updateDrink(); break;
            case 4: displayDrinks(); break;
            case 5: searchDrink(); break;
            case 6: addSupplier(); break;
            case 7: deleteSupplier(); break;
            case 8: updateSupplier(); break;
            case 9: displaySuppliers(); break;
            case 10: searchSupplier(); break;
            case 0: break;
            default: std::cout << "Invalid choice.\n";
        }
    } while (choice != 0);

    return 0;
}