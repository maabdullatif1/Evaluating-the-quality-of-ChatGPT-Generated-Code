#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Drink {
    int id;
    string name;
    double price;
    int quantity;
};

struct Supplier {
    int id;
    string name;
    string contact;
};

class InventorySystem {
private:
    vector<Drink> drinks;
    vector<Supplier> suppliers;
    int drinkIDCounter;
    int supplierIDCounter;

public:
    InventorySystem() : drinkIDCounter(1), supplierIDCounter(1) {}

    void addDrink(const string& name, double price, int quantity) {
        drinks.push_back({drinkIDCounter++, name, price, quantity});
    }

    void deleteDrink(int id) {
        for (auto it = drinks.begin(); it != drinks.end(); ++it) {
            if (it->id == id) {
                drinks.erase(it);
                return;
            }
        }
    }

    void updateDrink(int id, const string& name, double price, int quantity) {
        for (auto& drink : drinks) {
            if (drink.id == id) {
                drink.name = name;
                drink.price = price;
                drink.quantity = quantity;
                return;
            }
        }
    }

    void searchDrink(const string& name) {
        for (const auto& drink : drinks) {
            if (drink.name == name) {
                cout << "Drink ID: " << drink.id << " Name: " << drink.name 
                     << " Price: " << drink.price << " Quantity: " << drink.quantity << endl;
                return;
            }
        }
    }

    void displayDrinks() {
        for (const auto& drink : drinks) {
            cout << "Drink ID: " << drink.id << " Name: " << drink.name 
                 << " Price: " << drink.price << " Quantity: " << drink.quantity << endl;
        }
    }

    void addSupplier(const string& name, const string& contact) {
        suppliers.push_back({supplierIDCounter++, name, contact});
    }

    void deleteSupplier(int id) {
        for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
            if (it->id == id) {
                suppliers.erase(it);
                return;
            }
        }
    }

    void updateSupplier(int id, const string& name, const string& contact) {
        for (auto& supplier : suppliers) {
            if (supplier.id == id) {
                supplier.name = name;
                supplier.contact = contact;
                return;
            }
        }
    }

    void searchSupplier(const string& name) {
        for (const auto& supplier : suppliers) {
            if (supplier.name == name) {
                cout << "Supplier ID: " << supplier.id << " Name: " << supplier.name 
                     << " Contact: " << supplier.contact << endl;
                return;
            }
        }
    }

    void displaySuppliers() {
        for (const auto& supplier : suppliers) {
            cout << "Supplier ID: " << supplier.id << " Name: " << supplier.name 
                 << " Contact: " << supplier.contact << endl;
        }
    }
};

int main() {
    InventorySystem system;

    system.addDrink("Espresso", 2.5, 100);
    system.addDrink("Latte", 3.0, 80);
    system.updateDrink(1, "Espresso", 2.75, 90);
    system.displayDrinks();

    system.addSupplier("CoffeeCo", "123-456-7890");
    system.addSupplier("BeanSuppliers", "098-765-4321");
    system.updateSupplier(1, "CoffeeCo", "321-654-0987");
    system.displaySuppliers();

    return 0;
}