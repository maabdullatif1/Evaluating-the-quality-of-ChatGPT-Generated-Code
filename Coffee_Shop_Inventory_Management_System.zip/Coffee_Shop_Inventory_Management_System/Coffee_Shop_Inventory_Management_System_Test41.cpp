#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Drink {
public:
    string name;
    double price;
    int stock;

    Drink(string n, double p, int s) : name(n), price(p), stock(s) {}
};

class Supplier {
public:
    string name;
    string contactInfo;

    Supplier(string n, string c) : name(n), contactInfo(c) {}
};

vector<Drink> drinks;
vector<Supplier> suppliers;

void addDrink() {
    string name;
    double price;
    int stock;
    cout << "Enter drink name: ";
    cin.ignore();
    getline(cin, name);
    cout << "Enter drink price: ";
    cin >> price;
    cout << "Enter stock amount: ";
    cin >> stock;
    drinks.push_back(Drink(name, price, stock));
}

void deleteDrink() {
    string name;
    cout << "Enter drink name to delete: ";
    cin.ignore();
    getline(cin, name);
    for (auto it = drinks.begin(); it != drinks.end(); ++it) {
        if (it->name == name) {
            drinks.erase(it);
            cout << "Drink deleted.\n";
            return;
        }
    }
    cout << "Drink not found.\n";
}

void updateDrink() {
    string name;
    cout << "Enter drink name to update: ";
    cin.ignore();
    getline(cin, name);
    for (auto& d : drinks) {
        if (d.name == name) {
            cout << "Enter new price: ";
            cin >> d.price;
            cout << "Enter new stock amount: ";
            cin >> d.stock;
            cout << "Drink updated.\n";
            return;
        }
    }
    cout << "Drink not found.\n";
}

void searchDrink() {
    string name;
    cout << "Enter drink name to search: ";
    cin.ignore();
    getline(cin, name);
    for (const auto& d : drinks) {
        if (d.name == name) {
            cout << "Name: " << d.name << ", Price: " << d.price << ", Stock: " << d.stock << endl;
            return;
        }
    }
    cout << "Drink not found.\n";
}

void displayDrinks() {
    for (const auto& d : drinks) {
        cout << "Name: " << d.name << ", Price: " << d.price << ", Stock: " << d.stock << endl;
    }
}

void addSupplier() {
    string name;
    string contactInfo;
    cout << "Enter supplier name: ";
    cin.ignore();
    getline(cin, name);
    cout << "Enter supplier contact information: ";
    getline(cin, contactInfo);
    suppliers.push_back(Supplier(name, contactInfo));
}

void deleteSupplier() {
    string name;
    cout << "Enter supplier name to delete: ";
    cin.ignore();
    getline(cin, name);
    for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
        if (it->name == name) {
            suppliers.erase(it);
            cout << "Supplier deleted.\n";
            return;
        }
    }
    cout << "Supplier not found.\n";
}

void updateSupplier() {
    string name;
    cout << "Enter supplier name to update: ";
    cin.ignore();
    getline(cin, name);
    for (auto& s : suppliers) {
        if (s.name == name) {
            cout << "Enter new contact information: ";
            getline(cin, s.contactInfo);
            cout << "Supplier updated.\n";
            return;
        }
    }
    cout << "Supplier not found.\n";
}

void searchSupplier() {
    string name;
    cout << "Enter supplier name to search: ";
    cin.ignore();
    getline(cin, name);
    for (const auto& s : suppliers) {
        if (s.name == name) {
            cout << "Name: " << s.name << ", Contact Info: " << s.contactInfo << endl;
            return;
        }
    }
    cout << "Supplier not found.\n";
}

void displaySuppliers() {
    for (const auto& s : suppliers) {
        cout << "Name: " << s.name << ", Contact Info: " << s.contactInfo << endl;
    }
}

int main() {
    int choice;
    while (true) {
        cout << "1. Add Drink\n2. Delete Drink\n3. Update Drink\n4. Search Drink\n5. Display Drinks\n";
        cout << "6. Add Supplier\n7. Delete Supplier\n8. Update Supplier\n9. Search Supplier\n10. Display Suppliers\n11. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addDrink(); break;
            case 2: deleteDrink(); break;
            case 3: updateDrink(); break;
            case 4: searchDrink(); break;
            case 5: displayDrinks(); break;
            case 6: addSupplier(); break;
            case 7: deleteSupplier(); break;
            case 8: updateSupplier(); break;
            case 9: searchSupplier(); break;
            case 10: displaySuppliers(); break;
            case 11: return 0;
            default: cout << "Invalid choice.\n";
        }
    }
}