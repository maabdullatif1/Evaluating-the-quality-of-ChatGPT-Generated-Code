#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Passenger {
public:
    int id;
    string name;
    string contact;

    Passenger(int id, string name, string contact) : id(id), name(name), contact(contact) {}
};

class Flight {
public:
    int flightNumber;
    string destination;
    string departureTime;

    Flight(int flightNumber, string destination, string departureTime)
        : flightNumber(flightNumber), destination(destination), departureTime(departureTime) {}
};

class AirlineBookingSystem {
    vector<Passenger> passengers;
    vector<Flight> flights;

public:
    void addPassenger(int id, const string& name, const string& contact) {
        passengers.push_back(Passenger(id, name, contact));
    }

    void addFlight(int flightNumber, const string& destination, const string& departureTime) {
        flights.push_back(Flight(flightNumber, destination, departureTime));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, const string& name, const string& contact) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.contact = contact;
                break;
            }
        }
    }

    void updateFlight(int flightNumber, const string& destination, const string& departureTime) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = destination;
                flight.departureTime = departureTime;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }

    Flight* searchFlight(int flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            cout << "Passenger ID: " << passenger.id 
                 << ", Name: " << passenger.name 
                 << ", Contact: " << passenger.contact << endl;
        }
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            cout << "Flight Number: " << flight.flightNumber 
                 << ", Destination: " << flight.destination 
                 << ", Departure Time: " << flight.departureTime << endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "John Doe", "123456789");
    system.addPassenger(2, "Jane Smith", "987654321");
    system.displayPassengers();
    system.updatePassenger(1, "John Doe", "111222333");
    system.deletePassenger(2);
    Passenger* p = system.searchPassenger(1);
    if (p) cout << "Found Passenger: " << p->name << endl;
    system.addFlight(101, "New York", "10:00 AM");
    system.addFlight(102, "Los Angeles", "2:00 PM");
    system.displayFlights();
    system.updateFlight(101, "New York", "11:00 AM");
    system.deleteFlight(102);
    Flight* f = system.searchFlight(101);
    if (f) cout << "Found Flight: " << f->destination << endl;
    return 0;
}