#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Passenger {
public:
    int id;
    string name;
    string passportNumber;

    Passenger(int id, string name, string passportNumber)
        : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int flightNumber;
    string destination;
    vector<Passenger> passengers;

    Flight(int flightNumber, string destination)
        : flightNumber(flightNumber), destination(destination) {}

    void addPassenger(Passenger passenger) {
        passengers.push_back(passenger);
    }

    void removePassenger(int passengerId) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == passengerId) {
                passengers.erase(it);
                return;
            }
        }
    }

    Passenger* searchPassenger(int passengerId) {
        for (auto& passenger : passengers) {
            if (passenger.id == passengerId) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            cout << "ID: " << passenger.id << ", Name: " << passenger.name 
                 << ", Passport: " << passenger.passportNumber << endl;
        }
    }
};

class AirlineSystem {
    vector<Flight> flights;
public:
    void addFlight(int flightNumber, string destination) {
        flights.emplace_back(flightNumber, destination);
    }

    void removeFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                return;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void updateFlight(int flightNumber, string newDestination) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            flight->destination = newDestination;
        }
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            cout << "Flight Number: " << flight.flightNumber 
                 << ", Destination: " << flight.destination << endl;
            flight.displayPassengers();
        }
    }
};

int main() {
    AirlineSystem airline;
    airline.addFlight(101, "New York");
    airline.addFlight(102, "Paris");
    
    Flight* flight = airline.searchFlight(101);
    if (flight) {
        flight->addPassenger(Passenger(1, "John Doe", "A123456"));
        flight->addPassenger(Passenger(2, "Jane Smith", "B654321"));
    }

    flight = airline.searchFlight(102);
    if (flight) {
        flight->addPassenger(Passenger(3, "Mike Brown", "C987654"));
    }

    airline.displayFlights();

    return 0;
}