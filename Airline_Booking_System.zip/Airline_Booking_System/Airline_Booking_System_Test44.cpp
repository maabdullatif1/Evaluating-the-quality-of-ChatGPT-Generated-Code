#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Passenger {
public:
    string name;
    int id;
};

class Flight {
public:
    string destination;
    int flightNumber;
    vector<Passenger> passengers;
};

class AirlineSystem {
private:
    vector<Flight> flights;

public:
    void addFlight(string destination, int flightNumber) {
        Flight flight;
        flight.destination = destination;
        flight.flightNumber = flightNumber;
        flights.push_back(flight);
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int flightNumber, string newDestination) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = newDestination;
                break;
            }
        }
    }

    void displayFlights() {
        for (const auto &flight : flights) {
            cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << endl;
        }
    }

    void addPassenger(int flightNumber, string name, int id) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                Passenger passenger;
                passenger.name = name;
                passenger.id = id;
                flight.passengers.push_back(passenger);
                break;
            }
        }
    }

    void deletePassenger(int flightNumber, int id) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                for (auto it = flight.passengers.begin(); it != flight.passengers.end(); ++it) {
                    if (it->id == id) {
                        flight.passengers.erase(it);
                        break;
                    }
                }
                break;
            }
        }
    }

    void updatePassenger(int flightNumber, int id, string newName) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                for (auto &passenger : flight.passengers) {
                    if (passenger.id == id) {
                        passenger.name = newName;
                        break;
                    }
                }
                break;
            }
        }
    }

    void displayPassengers(int flightNumber) {
        for (const auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                for (const auto &passenger : flight.passengers) {
                    cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << endl;
                }
                break;
            }
        }
    }

    void searchFlight(int flightNumber) {
        for (const auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << endl;
                return;
            }
        }
        cout << "Flight not found" << endl;
    }

    void searchPassenger(int flightNumber, int id) {
        for (const auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                for (const auto &passenger : flight.passengers) {
                    if (passenger.id == id) {
                        cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << endl;
                        return;
                    }
                }
            }
        }
        cout << "Passenger not found" << endl;
    }
};

int main() {
    AirlineSystem system;
    system.addFlight("New York", 101);
    system.addFlight("Los Angeles", 102);

    system.addPassenger(101, "Alice", 1);
    system.addPassenger(101, "Bob", 2);

    system.displayFlights();
    system.displayPassengers(101);
    system.searchFlight(101);
    system.searchPassenger(101, 1);

    system.updateFlight(102, "San Francisco");
    system.updatePassenger(101, 1, "Alicia");

    system.displayFlights();
    system.displayPassengers(101);

    system.deletePassenger(101, 1);
    system.deleteFlight(102);

    system.displayFlights();
    system.displayPassengers(101);

    return 0;
}