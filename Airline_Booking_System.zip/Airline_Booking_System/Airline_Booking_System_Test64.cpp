#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Passenger {
public:
    string name;
    int age;
    string passportNumber;
    
    Passenger(string name, int age, string passportNumber) 
    : name(name), age(age), passportNumber(passportNumber) {}
};

class Flight {
public:
    string flightNumber;
    string origin;
    string destination;
    vector<Passenger> passengers;

    Flight(string flightNumber, string origin, string destination) 
    : flightNumber(flightNumber), origin(origin), destination(destination) {}
};

class AirlineBookingSystem {
private:
    vector<Flight> flights;

public:
    void addFlight(string flightNumber, string origin, string destination) {
        flights.push_back(Flight(flightNumber, origin, destination));
    }

    void deleteFlight(string flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(string flightNumber, string newOrigin, string newDestination) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.origin = newOrigin;
                flight.destination = newDestination;
                break;
            }
        }
    }

    Flight* searchFlight(string flightNumber) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr; 
    }

    void displayFlights() {
        for (const auto &flight : flights) {
            cout << "Flight No: " << flight.flightNumber << ", Origin: " << flight.origin 
                 << ", Destination: " << flight.destination << endl;
        }
    }

    void addPassenger(string flightNumber, string name, int age, string passportNumber) {
        Flight* flight = searchFlight(flightNumber);
        if (flight != nullptr) {
            flight->passengers.push_back(Passenger(name, age, passportNumber));
        }
    }

    void deletePassenger(string flightNumber, string passportNumber) {
        Flight* flight = searchFlight(flightNumber);
        if (flight != nullptr) {
            auto &passengers = flight->passengers;
            for (auto it = passengers.begin(); it != passengers.end(); ++it) {
                if (it->passportNumber == passportNumber) {
                    passengers.erase(it);
                    break;
                }
            }
        }
    }

    void updatePassenger(string flightNumber, string passportNumber, string newName, int newAge) {
        Flight* flight = searchFlight(flightNumber);
        if (flight != nullptr) {
            for (auto &passenger : flight->passengers) {
                if (passenger.passportNumber == passportNumber) {
                    passenger.name = newName;
                    passenger.age = newAge;
                    break;
                }
            }
        }
    }

    Passenger* searchPassenger(string flightNumber, string passportNumber) {
        Flight* flight = searchFlight(flightNumber);
        if (flight != nullptr) {
            for (auto &passenger : flight->passengers) {
                if (passenger.passportNumber == passportNumber) {
                    return &passenger;
                }
            }
        }
        return nullptr;
    }

    void displayPassengers(string flightNumber) {
        Flight* flight = searchFlight(flightNumber);
        if (flight != nullptr) {
            for (const auto &passenger : flight->passengers) {
                cout << "Passenger Name: " << passenger.name << ", Age: " << passenger.age
                     << ", Passport: " << passenger.passportNumber << endl;
            }
        }
    }
};

int main() {
    AirlineBookingSystem system;
    
    system.addFlight("AB123", "New York", "Los Angeles");
    system.addPassenger("AB123", "Alice", 30, "P123456");
    system.displayFlights();
    system.displayPassengers("AB123");

    return 0;
}