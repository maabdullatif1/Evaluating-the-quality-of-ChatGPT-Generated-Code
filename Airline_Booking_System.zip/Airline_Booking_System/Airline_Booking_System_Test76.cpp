#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Passenger {
    int id;
    string name;
    string passportNumber;
};

struct Flight {
    int id;
    string destination;
    string date;
};

class AirlineBookingSystem {
    vector<Passenger> passengers;
    vector<Flight> flights;
    int passengerIdCounter = 0;
    int flightIdCounter = 0;

public:
    void addPassenger(const string& name, const string& passport) {
        passengers.push_back({++passengerIdCounter, name, passport});
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, const string& name, const string& passport) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.passportNumber = passport;
                break;
            }
        }
    }

    void searchPassenger(int id) {
        for (const auto& passenger : passengers) {
            if (passenger.id == id) {
                cout << "Passenger ID: " << passenger.id 
                     << ", Name: " << passenger.name 
                     << ", Passport: " << passenger.passportNumber << "\n";
                return;
            }
        }
        cout << "Passenger not found\n";
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            cout << "Passenger ID: " << passenger.id 
                 << ", Name: " << passenger.name 
                 << ", Passport: " << passenger.passportNumber << "\n";
        }
    }

    void addFlight(const string& destination, const string& date) {
        flights.push_back({++flightIdCounter, destination, date});
    }

    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int id, const string& destination, const string& date) {
        for (auto& flight : flights) {
            if (flight.id == id) {
                flight.destination = destination;
                flight.date = date;
                break;
            }
        }
    }

    void searchFlight(int id) {
        for (const auto& flight : flights) {
            if (flight.id == id) {
                cout << "Flight ID: " << flight.id 
                     << ", Destination: " << flight.destination 
                     << ", Date: " << flight.date << "\n";
                return;
            }
        }
        cout << "Flight not found\n";
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            cout << "Flight ID: " << flight.id 
                 << ", Destination: " << flight.destination 
                 << ", Date: " << flight.date << "\n";
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger("Alice", "P123456");
    system.displayPassengers();
    system.addFlight("New York", "2023-12-25");
    system.displayFlights();
    return 0;
}