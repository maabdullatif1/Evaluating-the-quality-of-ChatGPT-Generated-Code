#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Passenger {
public:
    int id;
    string name;
    string email;

    Passenger(int id, string name, string email) 
        : id(id), name(name), email(email) {}
};

class Flight {
public:
    int number;
    string origin;
    string destination;

    Flight(int number, string origin, string destination) 
        : number(number), origin(origin), destination(destination) {}
};

class BookingSystem {
private:
    vector<Passenger> passengers;
    vector<Flight> flights;

public:
    void addPassenger(int id, string name, string email) {
        passengers.emplace_back(id, name, email);
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, string name, string email) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.email = email;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) return &passenger;
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            cout << "ID: " << passenger.id << " Name: " << passenger.name << " Email: " << passenger.email << endl;
        }
    }

    void addFlight(int number, string origin, string destination) {
        flights.emplace_back(number, origin, destination);
    }

    void deleteFlight(int number) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->number == number) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int number, string origin, string destination) {
        for (auto& flight : flights) {
            if (flight.number == number) {
                flight.origin = origin;
                flight.destination = destination;
                break;
            }
        }
    }

    Flight* searchFlight(int number) {
        for (auto& flight : flights) {
            if (flight.number == number) return &flight;
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            cout << "Number: " << flight.number << " Origin: " << flight.origin << " Destination: " << flight.destination << endl;
        }
    }
};

int main() {
    BookingSystem system;
    
    system.addPassenger(1, "John Doe", "john@example.com");
    system.addPassenger(2, "Jane Smith", "jane@example.com");
    system.displayPassengers();
    
    system.addFlight(101, "New York", "London");
    system.addFlight(202, "Los Angeles", "Tokyo");
    system.displayFlights();
    
    Passenger* passenger = system.searchPassenger(1);
    if (passenger) {
        cout << "Found Passenger: ID: " << passenger->id << " Name: " << passenger->name << endl;
    }

    Flight* flight = system.searchFlight(101);
    if (flight) {
        cout << "Found Flight: Number: " << flight->number << " Origin: " << flight->origin << endl;
    }

    system.updatePassenger(2, "Jane Doe", "jane.doe@example.com");
    system.updateFlight(202, "Los Angeles", "Seoul");
    
    system.displayPassengers();
    system.displayFlights();

    system.deletePassenger(1);
    system.deleteFlight(101);
    
    system.displayPassengers();
    system.displayFlights();

    return 0;
}