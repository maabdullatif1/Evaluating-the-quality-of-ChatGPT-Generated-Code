#include <iostream>
#include <string>
#include <vector>

class Passenger {
public:
    int id;
    std::string name;
    std::string contactInfo;

    Passenger(int id, std::string name, std::string contactInfo) : id(id), name(name), contactInfo(contactInfo) {}
};

class Flight {
public:
    int flightNumber;
    std::string destination;
    std::string departureTime;

    Flight(int flightNumber, std::string destination, std::string departureTime) : flightNumber(flightNumber), destination(destination), departureTime(departureTime) {}
};

class AirlineBookingSystem {
private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(int id, std::string name, std::string contactInfo) {
        passengers.push_back(Passenger(id, name, contactInfo));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                return;
            }
        }
    }

    void updatePassenger(int id, std::string name, std::string contactInfo) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.contactInfo = contactInfo;
                return;
            }
        }
    }

    void searchPassenger(int id) {
        for (const auto &passenger : passengers) {
            if (passenger.id == id) {
                std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << ", Contact: " << passenger.contactInfo << std::endl;
                return;
            }
        }
    }

    void displayPassengers() {
        for (const auto &passenger : passengers) {
            std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << ", Contact: " << passenger.contactInfo << std::endl;
        }
    }

    void addFlight(int flightNumber, std::string destination, std::string departureTime) {
        flights.push_back(Flight(flightNumber, destination, departureTime));
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                return;
            }
        }
    }

    void updateFlight(int flightNumber, std::string destination, std::string departureTime) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = destination;
                flight.departureTime = departureTime;
                return;
            }
        }
    }

    void searchFlight(int flightNumber) {
        for (const auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << ", Departure Time: " << flight.departureTime << std::endl;
                return;
            }
        }
    }

    void displayFlights() {
        for (const auto &flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << ", Departure Time: " << flight.departureTime << std::endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;

    system.addPassenger(1, "John Doe", "555-1234");
    system.addPassenger(2, "Jane Smith", "555-5678");

    system.addFlight(101, "New York", "10:00 AM");
    system.addFlight(102, "Los Angeles", "02:00 PM");

    system.displayPassengers();
    system.displayFlights();

    system.searchPassenger(1);
    system.searchFlight(102);

    system.updatePassenger(2, "Jane Doe", "555-8765");
    system.updateFlight(101, "Boston", "09:00 AM");

    system.displayPassengers();
    system.displayFlights();

    system.deletePassenger(1);
    system.deleteFlight(102);

    system.displayPassengers();
    system.displayFlights();

    return 0;
}