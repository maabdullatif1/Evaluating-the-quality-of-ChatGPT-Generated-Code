#include <iostream>
#include <string>

using namespace std;

const int MAX_PASSENGERS = 100;
const int MAX_FLIGHTS = 50;

struct Passenger {
    int id;
    string name;
    int flightID;
};

struct Flight {
    int id;
    string destination;
    int seats;
};

Passenger passengers[MAX_PASSENGERS];
Flight flights[MAX_FLIGHTS];

int passengerCount = 0;
int flightCount = 0;

void addPassenger() {
    if (passengerCount < MAX_PASSENGERS) {
        int id, flightID;
        string name;
        cout << "Enter Passenger ID: ";
        cin >> id;
        cout << "Enter Passenger Name: ";
        cin.ignore();
        getline(cin, name);
        cout << "Enter Flight ID: ";
        cin >> flightID;
        passengers[passengerCount++] = { id, name, flightID };
    } else {
        cout << "Maximum passengers reached." << endl;
    }
}

void deletePassenger() {
    if (passengerCount > 0) {
        int id;
        cout << "Enter Passenger ID to delete: ";
        cin >> id;
        for (int i = 0; i < passengerCount; ++i) {
            if (passengers[i].id == id) {
                for (int j = i; j < passengerCount - 1; ++j) {
                    passengers[j] = passengers[j + 1];
                }
                --passengerCount;
                cout << "Passenger deleted." << endl;
                return;
            }
        }
        cout << "Passenger not found." << endl;
    } else {
        cout << "No passengers to delete." << endl;
    }
}

void updatePassenger() {
    int id, flightID;
    string name;
    cout << "Enter Passenger ID to update: ";
    cin >> id;
    for (int i = 0; i < passengerCount; ++i) {
        if (passengers[i].id == id) {
            cout << "Enter new Passenger Name: ";
            cin.ignore();
            getline(cin, name);
            cout << "Enter new Flight ID: ";
            cin >> flightID;
            passengers[i] = { id, name, flightID };
            cout << "Passenger updated." << endl;
            return;
        }
    }
    cout << "Passenger not found." << endl;
}

void searchPassenger() {
    int id;
    cout << "Enter Passenger ID to search: ";
    cin >> id;
    for (int i = 0; i < passengerCount; ++i) {
        if (passengers[i].id == id) {
            cout << "Passenger ID: " << passengers[i].id << ", Name: " << passengers[i].name << ", Flight ID: " << passengers[i].flightID << endl;
            return;
        }
    }
    cout << "Passenger not found." << endl;
}

void displayPassengers() {
    for (int i = 0; i < passengerCount; ++i) {
        cout << "Passenger ID: " << passengers[i].id << ", Name: " << passengers[i].name << ", Flight ID: " << passengers[i].flightID << endl;
    }
}

void addFlight() {
    if (flightCount < MAX_FLIGHTS) {
        int id, seats;
        string destination;
        cout << "Enter Flight ID: ";
        cin >> id;
        cout << "Enter Destination: ";
        cin.ignore();
        getline(cin, destination);
        cout << "Enter Number of Seats: ";
        cin >> seats;
        flights[flightCount++] = { id, destination, seats };
    } else {
        cout << "Maximum flights reached." << endl;
    }
}

void deleteFlight() {
    if (flightCount > 0) {
        int id;
        cout << "Enter Flight ID to delete: ";
        cin >> id;
        for (int i = 0; i < flightCount; ++i) {
            if (flights[i].id == id) {
                for (int j = i; j < flightCount - 1; ++j) {
                    flights[j] = flights[j + 1];
                }
                --flightCount;
                cout << "Flight deleted." << endl;
                return;
            }
        }
        cout << "Flight not found." << endl;
    } else {
        cout << "No flights to delete." << endl;
    }
}

void updateFlight() {
    int id, seats;
    string destination;
    cout << "Enter Flight ID to update: ";
    cin >> id;
    for (int i = 0; i < flightCount; ++i) {
        if (flights[i].id == id) {
            cout << "Enter new Destination: ";
            cin.ignore();
            getline(cin, destination);
            cout << "Enter new Number of Seats: ";
            cin >> seats;
            flights[i] = { id, destination, seats };
            cout << "Flight updated." << endl;
            return;
        }
    }
    cout << "Flight not found." << endl;
}

void searchFlight() {
    int id;
    cout << "Enter Flight ID to search: ";
    cin >> id;
    for (int i = 0; i < flightCount; ++i) {
        if (flights[i].id == id) {
            cout << "Flight ID: " << flights[i].id << ", Destination: " << flights[i].destination << ", Seats: " << flights[i].seats << endl;
            return;
        }
    }
    cout << "Flight not found." << endl;
}

void displayFlights() {
    for (int i = 0; i < flightCount; ++i) {
        cout << "Flight ID: " << flights[i].id << ", Destination: " << flights[i].destination << ", Seats: " << flights[i].seats << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "\n1. Add Passenger\n2. Delete Passenger\n3. Update Passenger\n4. Search Passenger\n5. Display Passengers\n";
        cout << "6. Add Flight\n7. Delete Flight\n8. Update Flight\n9. Search Flight\n10. Display Flights\n0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        switch (choice) {
            case 1: addPassenger(); break;
            case 2: deletePassenger(); break;
            case 3: updatePassenger(); break;
            case 4: searchPassenger(); break;
            case 5: displayPassengers(); break;
            case 6: addFlight(); break;
            case 7: deleteFlight(); break;
            case 8: updateFlight(); break;
            case 9: searchFlight(); break;
            case 10: displayFlights(); break;
            case 0: break;
            default: cout << "Invalid choice." << endl; break;
        }
    } while (choice != 0);
    
    return 0;
}