#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Passenger {
public:
    int id;
    string name;
    Passenger(int id, string name) : id(id), name(name) {}
};

class Flight {
public:
    int flightNumber;
    string destination;
    vector<Passenger> passengers;
    Flight(int flightNumber, string destination) : flightNumber(flightNumber), destination(destination) {}
    void addPassenger(Passenger p) { passengers.push_back(p); }
    void removePassenger(int passengerId) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == passengerId) {
                passengers.erase(it);
                return;
            }
        }
    }
    void displayPassengers() {
        for (const auto& p : passengers) {
            cout << "Passenger ID: " << p.id << ", Name: " << p.name << endl;
        }
    }
};

class BookingSystem {
private:
    vector<Flight> flights;
public:
    void addFlight(int flightNumber, string destination) {
        flights.emplace_back(flightNumber, destination);
    }
    void removeFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                return;
            }
        }
    }
    void updateFlight(int flightNumber, string newDestination) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = newDestination;
                return;
            }
        }
    }
    void addPassenger(int flightNumber, Passenger p) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.addPassenger(p);
                return;
            }
        }
    }
    void removePassenger(int flightNumber, int passengerId) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.removePassenger(passengerId);
                return;
            }
        }
    }
    void displayFlights() {
        for (const auto& flight : flights) {
            cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << endl;
            flight.displayPassengers();
        }
    }
    Flight* searchFlight(int flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }
    Passenger* searchPassenger(int flightNumber, int passengerId) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            for (auto& p : flight->passengers) {
                if (p.id == passengerId) {
                    return &p;
                }
            }
        }
        return nullptr;
    }
};

int main() {
    BookingSystem system;
    system.addFlight(101, "New York");
    system.addFlight(102, "Los Angeles");

    system.addPassenger(101, Passenger(1, "John Doe"));
    system.addPassenger(101, Passenger(2, "Jane Smith"));
    system.addPassenger(102, Passenger(3, "Alice Johnson"));

    system.displayFlights();

    system.removePassenger(101, 1);
    system.updateFlight(102, "San Francisco");

    system.displayFlights();

    return 0;
}