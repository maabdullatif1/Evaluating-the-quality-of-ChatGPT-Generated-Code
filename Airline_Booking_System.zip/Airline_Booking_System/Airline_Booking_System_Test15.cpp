#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;

    Passenger(int id, const std::string& name, const std::string& passportNumber)
        : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int flightNumber;
    std::string departure;
    std::string destination;

    Flight(int flightNumber, const std::string& departure, const std::string& destination)
        : flightNumber(flightNumber), departure(departure), destination(destination) {}
};

class BookingSystem {
private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

    int findPassengerIndex(int id) {
        for (int i = 0; i < passengers.size(); i++)
            if (passengers[i].id == id) return i;
        return -1;
    }

    int findFlightIndex(int flightNumber) {
        for (int i = 0; i < flights.size(); i++)
            if (flights[i].flightNumber == flightNumber) return i;
        return -1;
    }

public:
    void addPassenger(int id, const std::string& name, const std::string& passportNumber) {
        if (findPassengerIndex(id) == -1)
            passengers.emplace_back(id, name, passportNumber);
    }

    void deletePassenger(int id) {
        int index = findPassengerIndex(id);
        if (index != -1)
            passengers.erase(passengers.begin() + index);
    }

    void updatePassenger(int id, const std::string& name, const std::string& passportNumber) {
        int index = findPassengerIndex(id);
        if (index != -1) {
            passengers[index].name = name;
            passengers[index].passportNumber = passportNumber;
        }
    }

    Passenger* searchPassenger(int id) {
        int index = findPassengerIndex(id);
        return index != -1 ? &passengers[index] : nullptr;
    }

    void displayPassengers() {
        for (const auto& passenger : passengers)
            std::cout << "ID: " << passenger.id << ", Name: " << passenger.name 
                      << ", Passport Number: " << passenger.passportNumber << std::endl;
    }

    void addFlight(int flightNumber, const std::string& departure, const std::string& destination) {
        if (findFlightIndex(flightNumber) == -1)
            flights.emplace_back(flightNumber, departure, destination);
    }

    void deleteFlight(int flightNumber) {
        int index = findFlightIndex(flightNumber);
        if (index != -1)
            flights.erase(flights.begin() + index);
    }

    void updateFlight(int flightNumber, const std::string& departure, const std::string& destination) {
        int index = findFlightIndex(flightNumber);
        if (index != -1) {
            flights[index].departure = departure;
            flights[index].destination = destination;
        }
    }

    Flight* searchFlight(int flightNumber) {
        int index = findFlightIndex(flightNumber);
        return index != -1 ? &flights[index] : nullptr;
    }

    void displayFlights() {
        for (const auto& flight : flights)
            std::cout << "Flight Number: " << flight.flightNumber << ", Departure: " << flight.departure 
                      << ", Destination: " << flight.destination << std::endl;
    }
};

int main() {
    BookingSystem system;
    
    system.addPassenger(1, "John Doe", "AB12345");
    system.addPassenger(2, "Jane Smith", "BC23456");
    system.displayPassengers();

    system.addFlight(101, "New York", "London");
    system.addFlight(102, "Paris", "Tokyo");
    system.displayFlights();

    return 0;
}