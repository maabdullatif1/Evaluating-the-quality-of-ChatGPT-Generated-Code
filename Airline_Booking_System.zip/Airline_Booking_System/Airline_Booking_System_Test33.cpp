#include <iostream>
#include <string>
#include <vector>

class Passenger {
public:
    int id;
    std::string name;
    std::string passport;

    Passenger(int id, std::string name, std::string passport)
        : id(id), name(name), passport(passport) {}
};

class Flight {
public:
    int id;
    std::string destination;
    std::vector<Passenger> passengers;

    Flight(int id, std::string destination) : id(id), destination(destination) {}

    void addPassenger(const Passenger &passenger) {
        passengers.push_back(passenger);
    }

    void removePassenger(int passengerId) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == passengerId) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int passengerId, const std::string &newName, const std::string &newPassport) {
        for (auto &p : passengers) {
            if (p.id == passengerId) {
                p.name = newName;
                p.passport = newPassport;
                return;
            }
        }
    }

    void displayPassengers() {
        for (const auto &p : passengers) {
            std::cout << "ID: " << p.id << ", Name: " << p.name << ", Passport: " << p.passport << std::endl;
        }
    }
};

class BookingSystem {
public:
    std::vector<Flight> flights;

    void addFlight(int id, const std::string &destination) {
        flights.push_back(Flight(id, destination));
    }

    void removeFlight(int flightId) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == flightId) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int flightId, const std::string &newDestination) {
        for (auto &f : flights) {
            if (f.id == flightId) {
                f.destination = newDestination;
                return;
            }
        }
    }

    Flight* searchFlight(int flightId) {
        for (auto &f : flights) {
            if (f.id == flightId) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayFlightInfo() {
        for (const auto &f : flights) {
            std::cout << "Flight ID: " << f.id << ", Destination: " << f.destination << std::endl;
        }
    }
};

int main() {
    BookingSystem system;
    system.addFlight(101, "New York");
    system.addFlight(102, "London");

    Flight* flight = system.searchFlight(101);
    if (flight) {
        flight->addPassenger(Passenger(1, "Alice", "P1234"));
        flight->addPassenger(Passenger(2, "Bob", "P5678"));
    }

    system.displayFlightInfo();

    if (flight) {
        std::cout << "Passengers for flight 101:" << std::endl;
        flight->displayPassengers();
    }

    if (flight) {
        flight->updatePassenger(1, "Alice Smith", "P91011");
    }

    if (flight) {
        std::cout << "Updated Passengers for flight 101:" << std::endl;
        flight->displayPassengers();
    }

    return 0;
}