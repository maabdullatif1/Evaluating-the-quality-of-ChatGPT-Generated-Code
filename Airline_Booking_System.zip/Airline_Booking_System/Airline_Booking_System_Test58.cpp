#include <iostream>
#include <string>

using namespace std;

const int MAX_PASSENGERS = 100;
const int MAX_FLIGHTS = 50;

struct Passenger {
    int id;
    string name;
    string passportNumber;
};

struct Flight {
    string flightNumber;
    string destination;
    int totalSeats;
    int bookedSeats;
};

Passenger passengers[MAX_PASSENGERS];
Flight flights[MAX_FLIGHTS];

int passengerCount = 0;
int flightCount = 0;

void addPassenger() {
    if (passengerCount >= MAX_PASSENGERS) return;
    cout << "Enter passenger id: ";
    cin >> passengers[passengerCount].id;
    cout << "Enter passenger name: ";
    cin.ignore();
    getline(cin, passengers[passengerCount].name);
    cout << "Enter passport number: ";
    getline(cin, passengers[passengerCount].passportNumber);
    passengerCount++;
}

void deletePassenger(int id) {
    for (int i = 0; i < passengerCount; ++i) {
        if (passengers[i].id == id) {
            passengers[i] = passengers[--passengerCount];
            return;
        }
    }
}

void updatePassenger(int id) {
    for (int i = 0; i < passengerCount; ++i) {
        if (passengers[i].id == id) {
            cout << "Enter new name: ";
            cin.ignore();
            getline(cin, passengers[i].name);
            cout << "Enter new passport number: ";
            getline(cin, passengers[i].passportNumber);
            return;
        }
    }
}

void searchPassenger(int id) {
    for (int i = 0; i < passengerCount; ++i) {
        if (passengers[i].id == id) {
            cout << "ID: " << passengers[i].id << ", Name: " << passengers[i].name << ", Passport: " << passengers[i].passportNumber << endl;
            return;
        }
    }
    cout << "Passenger not found." << endl;
}

void displayPassengers() {
    for (int i = 0; i < passengerCount; ++i) {
        cout << "ID: " << passengers[i].id << ", Name: " << passengers[i].name << ", Passport: " << passengers[i].passportNumber << endl;
    }
}

void addFlight() {
    if (flightCount >= MAX_FLIGHTS) return;
    cout << "Enter flight number: ";
    cin >> flights[flightCount].flightNumber;
    cout << "Enter destination: ";
    cin.ignore();
    getline(cin, flights[flightCount].destination);
    cout << "Enter total seats: ";
    cin >> flights[flightCount].totalSeats;
    flights[flightCount].bookedSeats = 0;
    flightCount++;
}

void deleteFlight(string flightNumber) {
    for (int i = 0; i < flightCount; ++i) {
        if (flights[i].flightNumber == flightNumber) {
            flights[i] = flights[--flightCount];
            return;
        }
    }
}

void updateFlight(string flightNumber) {
    for (int i = 0; i < flightCount; ++i) {
        if (flights[i].flightNumber == flightNumber) {
            cout << "Enter new destination: ";
            cin.ignore();
            getline(cin, flights[i].destination);
            cout << "Enter new total seats: ";
            cin >> flights[i].totalSeats;
            return;
        }
    }
}

void searchFlight(string flightNumber) {
    for (int i = 0; i < flightCount; ++i) {
        if (flights[i].flightNumber == flightNumber) {
            cout << "Flight Number: " << flights[i].flightNumber << ", Destination: " << flights[i].destination << ", Total Seats: " << flights[i].totalSeats << ", Booked Seats: " << flights[i].bookedSeats << endl;
            return;
        }
    }
    cout << "Flight not found." << endl;
}

void displayFlights() {
    for (int i = 0; i < flightCount; ++i) {
        cout << "Flight Number: " << flights[i].flightNumber << ", Destination: " << flights[i].destination << ", Total Seats: " << flights[i].totalSeats << ", Booked Seats: " << flights[i].bookedSeats << endl;
    }
}

int main() {
    int option;
    do {
        cout << "1. Add Passenger\n2. Delete Passenger\n3. Update Passenger\n4. Search Passenger\n5. Display Passengers\n6. Add Flight\n7. Delete Flight\n8. Update Flight\n9. Search Flight\n10. Display Flights\n0. Exit\n";
        cout << "Enter an option: ";
        cin >> option;
        switch (option) {
            case 1: addPassenger(); break;
            case 2: {
                int id;
                cout << "Enter passenger id to delete: ";
                cin >> id;
                deletePassenger(id);
                break;
            }
            case 3: {
                int id;
                cout << "Enter passenger id to update: ";
                cin >> id;
                updatePassenger(id);
                break;
            }
            case 4: {
                int id;
                cout << "Enter passenger id to search: ";
                cin >> id;
                searchPassenger(id);
                break;
            }
            case 5: displayPassengers(); break;
            case 6: addFlight(); break;
            case 7: {
                string flightNumber;
                cout << "Enter flight number to delete: ";
                cin >> flightNumber;
                deleteFlight(flightNumber);
                break;
            }
            case 8: {
                string flightNumber;
                cout << "Enter flight number to update: ";
                cin >> flightNumber;
                updateFlight(flightNumber);
                break;
            }
            case 9: {
                string flightNumber;
                cout << "Enter flight number to search: ";
                cin >> flightNumber;
                searchFlight(flightNumber);
                break;
            }
            case 10: displayFlights(); break;
        }
    } while (option != 0);

    return 0;
}