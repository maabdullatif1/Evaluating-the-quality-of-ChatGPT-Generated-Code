#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    std::string name;
    int passengerID;
    Passenger(std::string n, int id) : name(n), passengerID(id) {}
};

class Flight {
public:
    std::string flightNumber;
    std::string destination;
    std::vector<Passenger> passengers;
    Flight(std::string fn, std::string dest) : flightNumber(fn), destination(dest) {}
};

class AirlineSystem {
private:
    std::vector<Flight> flights;
public:
    void addFlight(const std::string& flightNumber, const std::string& destination) {
        flights.push_back(Flight(flightNumber, destination));
    }
    
    void deleteFlight(const std::string& flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(const std::string& flightNumber, const std::string& newDestination) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = newDestination;
                break;
            }
        }
    }
    
    Flight* searchFlight(const std::string& flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }
    
    void displayFlights() {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber 
                      << ", Destination: " << flight.destination << std::endl;
        }
    }
    
    void addPassenger(const std::string& flightNumber, const std::string& passengerName, int passengerID) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.passengers.push_back(Passenger(passengerName, passengerID));
                break;
            }
        }
    }
    
    void deletePassenger(const std::string& flightNumber, int passengerID) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                for (auto it = flight.passengers.begin(); it != flight.passengers.end(); ++it) {
                    if (it->passengerID == passengerID) {
                        flight.passengers.erase(it);
                        break;
                    }
                }
            }
        }
    }
    
    void updatePassenger(const std::string& flightNumber, int passengerID, const std::string& newName) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                for (auto& passenger : flight.passengers) {
                    if (passenger.passengerID == passengerID) {
                        passenger.name = newName;
                        break;
                    }
                }
            }
        }
    }
    
    Passenger* searchPassenger(const std::string& flightNumber, int passengerID) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                for (auto& passenger : flight.passengers) {
                    if (passenger.passengerID == passengerID) {
                        return &passenger;
                    }
                }
            }
        }
        return nullptr;
    }
    
    void displayPassengers(const std::string& flightNumber) {
        for (const auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                for (const auto& passenger : flight.passengers) {
                    std::cout << "Passenger ID: " << passenger.passengerID 
                              << ", Name: " << passenger.name << std::endl;
                }
            }
        }
    }
};

int main() {
    AirlineSystem system;
    system.addFlight("AA101", "New York");
    system.addFlight("BA202", "London");
    system.addPassenger("AA101", "John Doe", 1);
    system.addPassenger("AA101", "Jane Smith", 2);
    system.displayFlights();
    system.displayPassengers("AA101");
    system.updatePassenger("AA101", 1, "Johnathon Doe");
    system.displayPassengers("AA101");
    system.deletePassenger("AA101", 1);
    system.displayPassengers("AA101");
    system.deleteFlight("BA202");
    system.displayFlights();
    return 0;
}