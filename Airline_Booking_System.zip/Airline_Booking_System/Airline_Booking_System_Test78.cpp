#include <iostream>
#include <string>
#include <vector>

class Passenger {
public:
    int id;
    std::string name;

    Passenger(int id, const std::string &name) : id(id), name(name) {}
};

class Flight {
public:
    int flightNumber;
    std::string destination;

    Flight(int flightNumber, const std::string &destination)
        : flightNumber(flightNumber), destination(destination) {}
};

class AirlineBookingSystem {
private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

    int findPassengerIndex(int id) {
        for (size_t i = 0; i < passengers.size(); ++i) {
            if (passengers[i].id == id) return i;
        }
        return -1;
    }

    int findFlightIndex(int flightNumber) {
        for (size_t i = 0; i < flights.size(); ++i) {
            if (flights[i].flightNumber == flightNumber) return i;
        }
        return -1;
    }

public:
    void addPassenger(int id, const std::string &name) {
        if (findPassengerIndex(id) == -1) {
            passengers.push_back(Passenger(id, name));
        }
    }

    void deletePassenger(int id) {
        int index = findPassengerIndex(id);
        if (index != -1) {
            passengers.erase(passengers.begin() + index);
        }
    }

    void updatePassenger(int id, const std::string &newName) {
        int index = findPassengerIndex(id);
        if (index != -1) {
            passengers[index].name = newName;
        }
    }

    void searchPassenger(int id) {
        int index = findPassengerIndex(id);
        if (index != -1) {
            std::cout << "Passenger ID: " << passengers[index].id
                      << ", Name: " << passengers[index].name << std::endl;
        } else {
            std::cout << "Passenger not found!" << std::endl;
        }
    }

    void displayAllPassengers() {
        for (const auto &p : passengers) {
            std::cout << "Passenger ID: " << p.id << ", Name: " << p.name << std::endl;
        }
    }

    void addFlight(int flightNumber, const std::string &destination) {
        if (findFlightIndex(flightNumber) == -1) {
            flights.push_back(Flight(flightNumber, destination));
        }
    }

    void deleteFlight(int flightNumber) {
        int index = findFlightIndex(flightNumber);
        if (index != -1) {
            flights.erase(flights.begin() + index);
        }
    }

    void updateFlight(int flightNumber, const std::string &newDestination) {
        int index = findFlightIndex(flightNumber);
        if (index != -1) {
            flights[index].destination = newDestination;
        }
    }

    void searchFlight(int flightNumber) {
        int index = findFlightIndex(flightNumber);
        if (index != -1) {
            std::cout << "Flight Number: " << flights[index].flightNumber
                      << ", Destination: " << flights[index].destination << std::endl;
        } else {
            std::cout << "Flight not found!" << std::endl;
        }
    }

    void displayAllFlights() {
        for (const auto &f : flights) {
            std::cout << "Flight Number: " << f.flightNumber
                      << ", Destination: " << f.destination << std::endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;

    system.addPassenger(1, "John Doe");
    system.addPassenger(2, "Jane Smith");

    system.addFlight(1001, "New York");
    system.addFlight(1002, "Los Angeles");

    system.displayAllPassengers();
    system.displayAllFlights();

    system.updatePassenger(1, "John A. Doe");
    system.searchPassenger(1);

    system.updateFlight(1001, "San Francisco");
    system.searchFlight(1001);

    system.deletePassenger(2);
    system.deleteFlight(1002);

    system.displayAllPassengers();
    system.displayAllFlights();

    return 0;
}