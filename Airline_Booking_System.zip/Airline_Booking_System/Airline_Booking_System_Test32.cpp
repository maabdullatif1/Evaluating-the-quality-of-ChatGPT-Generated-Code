#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    Passenger(int id, std::string name) : id(id), name(name) {}
};

class Flight {
public:
    int id;
    std::string destination;
    std::vector<Passenger> passengers;
    Flight(int id, std::string destination) : id(id), destination(destination) {}
};

class AirlineBookingSystem {
    std::vector<Flight> flights;

public:
    void addFlight(int id, const std::string& destination) {
        flights.emplace_back(id, destination);
    }

    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int id, const std::string& newDestination) {
        for (auto& flight : flights) {
            if (flight.id == id) {
                flight.destination = newDestination;
                break;
            }
        }
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            std::cout << "Flight ID: " << flight.id << ", Destination: " << flight.destination << "\n";
        }
    }

    void addPassengerToFlight(int flightId, int passengerId, const std::string& name) {
        for (auto& flight : flights) {
            if (flight.id == flightId) {
                flight.passengers.emplace_back(passengerId, name);
                break;
            }
        }
    }

    void deletePassengerFromFlight(int flightId, int passengerId) {
        for (auto& flight : flights) {
            if (flight.id == flightId) {
                auto& passengers = flight.passengers;
                for (auto it = passengers.begin(); it != passengers.end(); ++it) {
                    if (it->id == passengerId) {
                        passengers.erase(it);
                        break;
                    }
                }
                break;
            }
        }
    }

    void updatePassengerInFlight(int flightId, int passengerId, const std::string& newName) {
        for (auto& flight : flights) {
            if (flight.id == flightId) {
                for (auto& passenger : flight.passengers) {
                    if (passenger.id == passengerId) {
                        passenger.name = newName;
                        break;
                    }
                }
                break;
            }
        }
    }
    
    void displayPassengersInFlight(int flightId) {
        for (const auto& flight : flights) {
            if (flight.id == flightId) {
                std::cout << "Passengers for Flight ID " << flight.id << ":\n";
                for (const auto& passenger : flight.passengers) {
                    std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << "\n";
                }
                break;
            }
        }
    }

    void searchFlights(const std::string& destination) {
        for (const auto& flight : flights) {
            if (flight.destination == destination) {
                std::cout << "Flight ID: " << flight.id << " has destination " << destination << "\n";
            }
        }
    }

    void searchPassenger(int passengerId, int flightId) {
        for (const auto& flight : flights) {
            if (flight.id == flightId) {
                for (const auto& passenger : flight.passengers) {
                    if (passenger.id == passengerId) {
                        std::cout << "Passenger ID: " << passenger.id << " found in Flight ID: " << flight.id << "\n";
                        return;
                    }
                }
            }
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addFlight(1, "Paris");
    system.addFlight(2, "New York");
    system.addPassengerToFlight(1, 101, "Alice");
    system.addPassengerToFlight(1, 102, "Bob");
    system.displayFlights();
    system.displayPassengersInFlight(1);
    system.updatePassengerInFlight(1, 101, "Alicia");
    system.displayPassengersInFlight(1);
    system.searchFlights("New York");
    system.searchPassenger(102, 1);
    system.deletePassengerFromFlight(1, 102);
    system.displayPassengersInFlight(1);
    return 0;
}