#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;

    Passenger(int id, std::string name, std::string passportNumber)
        : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int flightNumber;
    std::string origin;
    std::string destination;
    std::vector<Passenger> passengers;

    Flight(int flightNumber, std::string origin, std::string destination)
        : flightNumber(flightNumber), origin(origin), destination(destination) {}
};

class AirlineBookingSystem {
private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(int id, std::string name, std::string passportNumber) {
        passengers.push_back(Passenger(id, name, passportNumber));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, std::string name, std::string passportNumber) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.passportNumber = passportNumber;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto &passenger : passengers) {
            std::cout << "ID: " << passenger.id << ", Name: " << passenger.name
                      << ", Passport: " << passenger.passportNumber << "\n";
        }
    }

    void addFlight(int flightNumber, std::string origin, std::string destination) {
        flights.push_back(Flight(flightNumber, origin, destination));
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int flightNumber, std::string origin, std::string destination) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.origin = origin;
                flight.destination = destination;
                break;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto &flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber
                      << ", Origin: " << flight.origin
                      << ", Destination: " << flight.destination << "\n";
            std::cout << "Passengers:\n";
            for (const auto &passenger : flight.passengers) {
                std::cout << "  ID: " << passenger.id << ", Name: " << passenger.name
                          << ", Passport: " << passenger.passportNumber << "\n";
            }
        }
    }

    void addPassengerToFlight(int flightNumber, int passengerId) {
        Flight *flight = searchFlight(flightNumber);
        if (flight) {
            Passenger *passenger = searchPassenger(passengerId);
            if (passenger) {
                flight->passengers.push_back(*passenger);
            }
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "John Doe", "A123456");
    system.addPassenger(2, "Jane Smith", "B987654");
    system.addFlight(101, "New York", "Los Angeles");
    system.addPassengerToFlight(101, 1);
    system.addPassengerToFlight(101, 2);
    system.displayPassengers();
    system.displayFlights();
    return 0;
}