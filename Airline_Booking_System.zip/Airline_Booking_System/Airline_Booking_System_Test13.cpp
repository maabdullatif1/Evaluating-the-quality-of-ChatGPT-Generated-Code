#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;

    Passenger(int i, std::string n) : id(i), name(n) {}
};

class Flight {
public:
    int flightNumber;
    std::string origin;
    std::string destination;
    
    Flight(int fn, std::string o, std::string d) : flightNumber(fn), origin(o), destination(d) {}
};

class AirlineBookingSystem {
private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

    template<typename T>
    int findIndex(const std::vector<T>& vec, int id) {
        for (size_t i = 0; i < vec.size(); ++i) {
            if (vec[i].id == id || vec[i].flightNumber == id) return i;
        }
        return -1;
    }

public:
    void addPassenger(int id, std::string name) {
        if (findIndex(passengers, id) == -1) {
            passengers.push_back(Passenger(id, name));
        }
    }

    void deletePassenger(int id) {
        int index = findIndex(passengers, id);
        if (index != -1) {
            passengers.erase(passengers.begin() + index);
        }
    }

    void updatePassenger(int id, std::string name) {
        int index = findIndex(passengers, id);
        if (index != -1) {
            passengers[index].name = name;
        }
    }

    void searchPassenger(int id) {
        int index = findIndex(passengers, id);
        if (index != -1) {
            std::cout << "Passenger found: " << passengers[index].name << std::endl;
        } else {
            std::cout << "Passenger not found" << std::endl;
        }
    }

    void displayPassengers() {
        for (const auto& p : passengers) {
            std::cout << "Passenger ID: " << p.id << ", Name: " << p.name << std::endl;
        }
    }

    void addFlight(int flightNumber, std::string origin, std::string destination) {
        if (findIndex(flights, flightNumber) == -1) {
            flights.push_back(Flight(flightNumber, origin, destination));
        }
    }

    void deleteFlight(int flightNumber) {
        int index = findIndex(flights, flightNumber);
        if (index != -1) {
            flights.erase(flights.begin() + index);
        }
    }

    void updateFlight(int flightNumber, std::string origin, std::string destination) {
        int index = findIndex(flights, flightNumber);
        if (index != -1) {
            flights[index].origin = origin;
            flights[index].destination = destination;
        }
    }

    void searchFlight(int flightNumber) {
        int index = findIndex(flights, flightNumber);
        if (index != -1) {
            std::cout << "Flight found: " << flights[index].origin << " to " << flights[index].destination << std::endl;
        } else {
            std::cout << "Flight not found" << std::endl;
        }
    }

    void displayFlights() {
        for (const auto& f : flights) {
            std::cout << "Flight Number: " << f.flightNumber << ", Origin: " << f.origin << ", Destination: " << f.destination << std::endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "John Doe");
    system.addPassenger(2, "Jane Smith");
    system.addFlight(101, "New York", "Los Angeles");
    system.addFlight(102, "San Francisco", "Chicago");
    system.displayPassengers();
    system.displayFlights();
    system.searchPassenger(1);
    system.searchFlight(101);
    system.updatePassenger(1, "Johnathan Doe");
    system.updateFlight(101, "Boston", "Miami");
    system.displayPassengers();
    system.displayFlights();
    system.deletePassenger(2);
    system.deleteFlight(102);
    system.displayPassengers();
    system.displayFlights();
    return 0;
}