#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passport;

    Passenger(int pid, std::string pname, std::string ppassport)
        : id(pid), name(pname), passport(ppassport) {}
};

class Flight {
public:
    int id;
    std::string source;
    std::string destination;
    std::vector<Passenger> passengers;

    Flight(int fid, std::string fsource, std::string fdestination)
        : id(fid), source(fsource), destination(fdestination) {}
};

class AirlineBookingSystem {
    std::vector<Flight> flights;

public:
    void addFlight(int id, std::string source, std::string destination) {
        flights.push_back(Flight(id, source, destination));
    }

    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int id, std::string source, std::string destination) {
        for (auto &flight : flights) {
            if (flight.id == id) {
                flight.source = source;
                flight.destination = destination;
                break;
            }
        }
    }

    Flight* searchFlight(int id) {
        for (auto &flight : flights) {
            if (flight.id == id) return &flight;
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto &flight : flights) {
            std::cout << "Flight ID: " << flight.id 
                      << ", Source: " << flight.source 
                      << ", Destination: " << flight.destination << "\n";
        }
    }

    void addPassengerToFlight(int flightId, int passengerId, std::string name, std::string passport) {
        Flight* flight = searchFlight(flightId);
        if (flight) {
            flight->passengers.push_back(Passenger(passengerId, name, passport));
        }
    }

    void displayPassengersOnFlight(int flightId) {
        Flight* flight = searchFlight(flightId);
        if (flight) {
            for (const auto &passenger : flight->passengers) {
                std::cout << "Passenger ID: " << passenger.id
                          << ", Name: " << passenger.name 
                          << ", Passport: " << passenger.passport << "\n";
            }
        }
    }

    void deletePassengerFromFlight(int flightId, int passengerId) {
        Flight* flight = searchFlight(flightId);
        if (flight) {
            for (auto it = flight->passengers.begin(); it != flight->passengers.end(); ++it) {
                if (it->id == passengerId) {
                    flight->passengers.erase(it);
                    break;
                }
            }
        }
    }

    void updatePassengerOnFlight(int flightId, int passengerId, std::string name, std::string passport) {
        Flight* flight = searchFlight(flightId);
        if (flight) {
            for (auto &passenger : flight->passengers) {
                if (passenger.id == passengerId) {
                    passenger.name = name;
                    passenger.passport = passport;
                    break;
                }
            }
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addFlight(1, "New York", "London");
    system.addFlight(2, "Paris", "Tokyo");

    system.addPassengerToFlight(1, 101, "Alice Smith", "P123456");
    system.addPassengerToFlight(1, 102, "Bob Johnson", "P654321");

    system.displayFlights();
    std::cout << "Passengers on Flight 1:\n";
    system.displayPassengersOnFlight(1);

    system.updatePassengerOnFlight(1, 101, "Alice Jones", "P123456XYZ");

    std::cout << "Updated Passengers on Flight 1:\n";
    system.displayPassengersOnFlight(1);

    system.deletePassengerFromFlight(1, 102);

    std::cout << "Passengers on Flight 1 after deletion:\n";
    system.displayPassengersOnFlight(1);

    return 0;
}