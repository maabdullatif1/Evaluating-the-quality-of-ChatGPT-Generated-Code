#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Passenger {
public:
    int id;
    string name;
    string passportNumber;

    Passenger(int id, string name, string passportNumber)
        : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int id;
    string destination;
    string departureTime;

    Flight(int id, string destination, string departureTime)
        : id(id), destination(destination), departureTime(departureTime) {}
};

class AirlineSystem {
    vector<Passenger> passengers;
    vector<Flight> flights;

public:
    void addPassenger(int id, string name, string passportNumber) {
        passengers.push_back(Passenger(id, name, passportNumber));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, string name, string passportNumber) {
        for (auto &p : passengers) {
            if (p.id == id) {
                p.name = name;
                p.passportNumber = passportNumber;
                return;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto &p : passengers) {
            if (p.id == id) {
                return &p;
            }
        }
        return nullptr;
    }

    void displayAllPassengers() {
        for (const auto &p : passengers) {
            cout << "ID: " << p.id << ", Name: " << p.name << ", Passport Number: " << p.passportNumber << endl;
        }
    }

    void addFlight(int id, string destination, string departureTime) {
        flights.push_back(Flight(id, destination, departureTime));
    }

    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int id, string destination, string departureTime) {
        for (auto &f : flights) {
            if (f.id == id) {
                f.destination = destination;
                f.departureTime = departureTime;
                return;
            }
        }
    }

    Flight* searchFlight(int id) {
        for (auto &f : flights) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayAllFlights() {
        for (const auto &f : flights) {
            cout << "ID: " << f.id << ", Destination: " << f.destination << ", Departure Time: " << f.departureTime << endl;
        }
    }
};

int main() {
    AirlineSystem system;

    system.addPassenger(1, "John Doe", "P123456");
    system.addPassenger(2, "Jane Smith", "P654321");

    system.addFlight(101, "New York", "10:00 AM");
    system.addFlight(102, "Los Angeles", "4:00 PM");

    system.displayAllPassengers();
    cout << endl;
    system.displayAllFlights();

    return 0;
}