#include <iostream>
#include <string>
#include <vector>

class Passenger {
public:
    int id;
    std::string name;

    Passenger(int id, const std::string &name) : id(id), name(name) {}
};

class Flight {
public:
    int flightNumber;
    std::string destination;

    Flight(int flightNumber, const std::string &destination) : flightNumber(flightNumber), destination(destination) {}
}

class AirlineBookingSystem {
public:
    void addPassenger(int id, const std::string &name) {
        passengers.push_back(Passenger(id, name));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, const std::string &name) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                break;
            }
        }
    }

    void searchPassenger(int id) {
        for (const auto &passenger : passengers) {
            if (passenger.id == id) {
                std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << std::endl;
                return;
            }
        }
        std::cout << "Passenger not found." << std::endl;
    }

    void displayPassengers() {
        for (const auto &passenger : passengers) {
            std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << std::endl;
        }
    }

    void addFlight(int flightNumber, const std::string &destination) {
        flights.push_back(Flight(flightNumber, destination));
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int flightNumber, const std::string &destination) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = destination;
                break;
            }
        }
    }

    void searchFlight(int flightNumber) {
        for (const auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << std::endl;
                return;
            }
        }
        std::cout << "Flight not found." << std::endl;
    }

    void displayFlights() {
        for (const auto &flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << std::endl;
        }
    }

private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "John Doe");
    system.addPassenger(2, "Jane Smith");

    system.addFlight(101, "New York");
    system.addFlight(102, "Los Angeles");

    std::cout << "Initial State:\n";
    system.displayPassengers();
    system.displayFlights();

    system.updatePassenger(1, "John Doe Jr.");
    system.updateFlight(102, "San Francisco");

    std::cout << "\nAfter Updates:\n";
    system.displayPassengers();
    system.displayFlights();

    system.searchPassenger(1);
    system.searchFlight(101);

    system.deletePassenger(2);
    system.deleteFlight(101);

    std::cout << "\nAfter Deletions:\n";
    system.displayPassengers();
    system.displayFlights();

    return 0;
}