#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Passenger {
public:
    string name;
    int age;
    string passportNumber;
    
    Passenger(string n, int a, string p) : name(n), age(a), passportNumber(p) {}
};

class Flight {
public:
    string flightNumber;
    string destination;
    vector<Passenger> passengers;

    Flight(string fn, string dest) : flightNumber(fn), destination(dest) {}

    void addPassenger(Passenger p) {
        passengers.push_back(p);
    }

    void deletePassenger(string passportNumber) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->passportNumber == passportNumber) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(string passportNumber, string newName, int newAge) {
        for (auto& p : passengers) {
            if (p.passportNumber == passportNumber) {
                p.name = newName;
                p.age = newAge;
                break;
            }
        }
    }
};

class AirlineSystem {
    vector<Flight> flights;

public:
    void addFlight(string flightNumber, string destination) {
        flights.push_back(Flight(flightNumber, destination));
    }

    void deleteFlight(string flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void addPassengerToFlight(string flightNumber, Passenger p) {
        for (auto& f : flights) {
            if (f.flightNumber == flightNumber) {
                f.addPassenger(p);
                break;
            }
        }
    }

    void deletePassengerFromFlight(string flightNumber, string passportNumber) {
        for (auto& f : flights) {
            if (f.flightNumber == flightNumber) {
                f.deletePassenger(passportNumber);
                break;
            }
        }
    }

    void updatePassengerInFlight(string flightNumber, string passportNumber, string newName, int newAge) {
        for (auto& f : flights) {
            if (f.flightNumber == flightNumber) {
                f.updatePassenger(passportNumber, newName, newAge);
                break;
            }
        }
    }

    void searchPassenger(string passportNumber) {
        for (const auto& f : flights) {
            for (const auto& p : f.passengers) {
                if (p.passportNumber == passportNumber) {
                    cout << "Passenger found: " << p.name << ", Age: " << p.age << ", Flight: " << f.flightNumber << endl;
                    return;
                }
            }
        }
        cout << "Passenger not found." << endl;
    }

    void displayFlights() {
        for (const auto& f : flights) {
            cout << "Flight Number: " << f.flightNumber << ", Destination: " << f.destination << ", Passengers: ";
            for (const auto& p : f.passengers) {
                cout << p.name << " ";
            }
            cout << endl;
        }
    }
};

int main() {
    AirlineSystem system;
    
    system.addFlight("AB123", "New York");
    system.addFlight("CD456", "Los Angeles");
    
    system.addPassengerToFlight("AB123", Passenger("John Doe", 30, "P12345"));
    system.addPassengerToFlight("CD456", Passenger("Jane Doe", 28, "P67890"));

    system.displayFlights();
    
    system.searchPassenger("P12345");

    system.updatePassengerInFlight("AB123", "P12345", "John Smith", 31);

    system.displayFlights();
    
    system.deletePassengerFromFlight("AB123", "P12345");

    system.displayFlights();
    
    return 0;
}