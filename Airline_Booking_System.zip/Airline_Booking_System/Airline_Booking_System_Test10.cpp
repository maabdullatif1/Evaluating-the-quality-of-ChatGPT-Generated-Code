#include <iostream>
#include <string>
#include <vector>

struct Passenger {
    int id;
    std::string name;
    std::string passportNumber;
};

struct Flight {
    int id;
    std::string destination;
    std::string departureTime;
};

class AirlineBookingSystem {
private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(int id, const std::string& name, const std::string& passportNumber) {
        passengers.push_back({id, name, passportNumber});
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, const std::string& name, const std::string& passportNumber) {
        for (auto& p : passengers) {
            if (p.id == id) {
                p.name = name;
                p.passportNumber = passportNumber;
                break;
            }
        }
    }

    void searchPassenger(int id) {
        for (const auto& p : passengers) {
            if (p.id == id) {
                std::cout << "Passenger ID: " << p.id << " Name: " << p.name << " Passport Number: " << p.passportNumber << std::endl;
                return;
            }
        }
        std::cout << "Passenger not found" << std::endl;
    }

    void displayPassengers() {
        for (const auto& p : passengers) {
            std::cout << "Passenger ID: " << p.id << " Name: " << p.name << " Passport Number: " << p.passportNumber << std::endl;
        }
    }

    void addFlight(int id, const std::string& destination, const std::string& departureTime) {
        flights.push_back({id, destination, departureTime});
    }

    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int id, const std::string& destination, const std::string& departureTime) {
        for (auto& f : flights) {
            if (f.id == id) {
                f.destination = destination;
                f.departureTime = departureTime;
                break;
            }
        }
    }

    void searchFlight(int id) {
        for (const auto& f : flights) {
            if (f.id == id) {
                std::cout << "Flight ID: " << f.id << " Destination: " << f.destination << " Departure Time: " << f.departureTime << std::endl;
                return;
            }
        }
        std::cout << "Flight not found" << std::endl;
    }

    void displayFlights() {
        for (const auto& f : flights) {
            std::cout << "Flight ID: " << f.id << " Destination: " << f.destination << " Departure Time: " << f.departureTime << std::endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "John Doe", "AB123456");
    system.addPassenger(2, "Jane Smith", "XY789012");
    system.displayPassengers();
    system.addFlight(101, "New York", "10:30 AM");
    system.addFlight(102, "London", "3:45 PM");
    system.displayFlights();
    system.searchPassenger(1);
    system.searchFlight(101);
    system.updatePassenger(1, "John Doe", "CD987654");
    system.updateFlight(101, "New York", "11:00 AM");
    system.displayPassengers();
    system.displayFlights();
    system.deletePassenger(2);
    system.deleteFlight(102);
    system.displayPassengers();
    system.displayFlights();

    return 0;
}