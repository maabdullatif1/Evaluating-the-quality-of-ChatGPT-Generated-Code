#include <iostream>
#include <vector>
#include <string>

class Flight {
public:
    int flightNumber;
    std::string origin;
    std::string destination;

    Flight(int fNum, std::string orig, std::string dest) :
        flightNumber(fNum), origin(orig), destination(dest) {}
};

class Passenger {
public:
    int passengerID;
    std::string name;
    int flightNumber;

    Passenger(int pID, std::string n, int fNum) :
        passengerID(pID), name(n), flightNumber(fNum) {}
};

class AirlineSystem {
private:
    std::vector<Flight> flights;
    std::vector<Passenger> passengers;

public:
    void addFlight(int fNum, std::string orig, std::string dest) {
        flights.push_back(Flight(fNum, orig, dest));
    }

    void deleteFlight(int fNum) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == fNum) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int fNum, std::string orig, std::string dest) {
        for (auto &flight : flights) {
            if (flight.flightNumber == fNum) {
                flight.origin = orig;
                flight.destination = dest;
            }
        }
    }

    void displayFlights() {
        for (const auto &flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Origin: " 
                      << flight.origin << ", Destination: " << flight.destination << std::endl;
        }
    }

    void addPassenger(int pID, std::string name, int fNum) {
        passengers.push_back(Passenger(pID, name, fNum));
    }

    void deletePassenger(int pID) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->passengerID == pID) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int pID, std::string name, int fNum) {
        for (auto &passenger : passengers) {
            if (passenger.passengerID == pID) {
                passenger.name = name;
                passenger.flightNumber = fNum;
            }
        }
    }

    void displayPassengers() {
        for (const auto &passenger : passengers) {
            std::cout << "Passenger ID: " << passenger.passengerID << ", Name: " 
                      << passenger.name << ", Flight Number: " << passenger.flightNumber << std::endl;
        }
    }

    void searchFlight(int fNum) {
        for (const auto &flight : flights) {
            if (flight.flightNumber == fNum) {
                std::cout << "Flight Found: Flight Number: " << flight.flightNumber << ", Origin: " 
                          << flight.origin << ", Destination: " << flight.destination << std::endl;
                return;
            }
        }
        std::cout << "Flight not found." << std::endl;
    }

    void searchPassenger(int pID) {
        for (const auto &passenger : passengers) {
            if (passenger.passengerID == pID) {
                std::cout << "Passenger Found: Passenger ID: " << passenger.passengerID << ", Name: " 
                          << passenger.name << ", Flight Number: " << passenger.flightNumber << std::endl;
                return;
            }
        }
        std::cout << "Passenger not found." << std::endl;
    }
};

int main() {
    AirlineSystem system;
    system.addFlight(101, "New York", "Los Angeles");
    system.addFlight(102, "Chicago", "Miami");
    system.addPassenger(1, "John Doe", 101);
    system.addPassenger(2, "Jane Smith", 102);

    system.displayFlights();
    system.displayPassengers();

    system.searchFlight(101);
    system.searchPassenger(1);

    system.updateFlight(101, "New York", "San Francisco");
    system.updatePassenger(1, "John Doe", 102);

    system.displayFlights();
    system.displayPassengers();

    system.deleteFlight(102);
    system.deletePassenger(2);

    system.displayFlights();
    system.displayPassengers();

    return 0;
}