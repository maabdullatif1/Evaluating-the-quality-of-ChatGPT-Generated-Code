#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Passenger {
public:
    string name;
    string passportNumber;

    Passenger(string n, string p) : name(n), passportNumber(p) {}
};

class Flight {
public:
    string flightNumber;
    string origin;
    string destination;
    vector<Passenger> passengers;

    Flight(string fn, string o, string d) : flightNumber(fn), origin(o), destination(d) {}

    void addPassenger(const Passenger& p) {
        passengers.push_back(p);
    }

    void removePassenger(const string& passportNumber) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->passportNumber == passportNumber) {
                passengers.erase(it);
                break;
            }
        }
    }
};

class AirlineBookingSystem {
private:
    vector<Flight> flights;

    Flight* findFlight(const string& flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

public:
    void addFlight(const Flight& flight) {
        flights.push_back(flight);
    }

    void removeFlight(const string& flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(const string& flightNumber, const string& newOrigin, const string& newDestination) {
        Flight* flight = findFlight(flightNumber);
        if (flight) {
            flight->origin = newOrigin;
            flight->destination = newDestination;
        }
    }

    void addPassengerToFlight(const string& flightNumber, const Passenger& passenger) {
        Flight* flight = findFlight(flightNumber);
        if (flight) {
            flight->addPassenger(passenger);
        }
    }

    void removePassengerFromFlight(const string& flightNumber, const string& passportNumber) {
        Flight* flight = findFlight(flightNumber);
        if (flight) {
            flight->removePassenger(passportNumber);
        }
    }

    Flight* searchFlight(const string& flightNumber) {
        return findFlight(flightNumber);
    }

    void displayFlights() const {
        for (const auto& flight : flights) {
            cout << "Flight Number: " << flight.flightNumber
                 << ", Origin: " << flight.origin
                 << ", Destination: " << flight.destination << endl;
        }
    }

    void displayPassengers(const string& flightNumber) const {
        const Flight* flight = nullptr;
        for (const auto& f : flights) {
            if (f.flightNumber == flightNumber) {
                flight = &f;
                break;
            }
        }
        if (flight) {
            for (const auto& passenger : flight->passengers) {
                cout << "Passenger Name: " << passenger.name
                     << ", Passport Number: " << passenger.passportNumber << endl;
            }
        }
    }
};

int main() {
    AirlineBookingSystem system;

    system.addFlight(Flight("FL123", "New York", "Los Angeles"));
    system.addFlight(Flight("FL456", "San Francisco", "Tokyo"));

    system.addPassengerToFlight("FL123", Passenger("John Doe", "P123456"));
    system.addPassengerToFlight("FL123", Passenger("Jane Smith", "P654321"));

    system.displayFlights();
    system.displayPassengers("FL123");

    system.removePassengerFromFlight("FL123", "P123456");
    system.displayPassengers("FL123");

    system.updateFlight("FL456", "San Francisco", "Osaka");
    system.displayFlights();

    return 0;
}