#include<iostream>
#include<string>
#include<vector>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;
    Passenger(int id, std::string name, std::string passportNumber)
    : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int flightNumber;
    std::string destination;
    std::string departureTime;
    std::vector<Passenger> passengers;
    Flight(int flightNumber, std::string destination, std::string departureTime)
    : flightNumber(flightNumber), destination(destination), departureTime(departureTime) {}
    
    void addPassenger(Passenger p) {
        passengers.push_back(p);
    }
    
    void deletePassenger(int passengerId) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == passengerId) {
                passengers.erase(it);
                break;
            }
        }
    }
    
    void updatePassenger(int passengerId, std::string name, std::string passportNumber) {
        for (auto &p : passengers) {
            if (p.id == passengerId) {
                p.name = name;
                p.passportNumber = passportNumber;
                break;
            }
        }
    }
    
    Passenger* searchPassenger(int passengerId) {
        for (auto &p : passengers) {
            if (p.id == passengerId) {
                return &p;
            }
        }
        return nullptr;
    }
    
    void displayPassengers() {
        for (auto &p : passengers) {
            std::cout << "ID: " << p.id << ", Name: " << p.name << ", Passport: " << p.passportNumber << std::endl;
        }
    }
};

class BookingSystem {
public:
    std::vector<Flight> flights;

    void addFlight(Flight flight) {
        flights.push_back(flight);
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int flightNumber, std::string destination, std::string departureTime) {
        for (auto &f : flights) {
            if (f.flightNumber == flightNumber) {
                f.destination = destination;
                f.departureTime = departureTime;
                break;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto &f : flights) {
            if (f.flightNumber == flightNumber) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (auto &f : flights) {
            std::cout << "Flight: " << f.flightNumber << ", Destination: " << f.destination << ", Departure: " << f.departureTime << std::endl;
            f.displayPassengers();
        }
    }
};

int main() {
    BookingSystem system;
    Flight f1(101, "New York", "10:00 AM");
    f1.addPassenger(Passenger(1, "John Doe", "AB1234"));
    f1.addPassenger(Passenger(2, "Jane Smith", "CD5678"));
    system.addFlight(f1);
    system.displayFlights();

    Flight *searchResult = system.searchFlight(101);
    if (searchResult) {
        Passenger *p = searchResult->searchPassenger(1);
        if (p) std::cout << "Found passenger: " << p->name << std::endl;
    }

    system.updateFlight(101, "Los Angeles", "11:00 AM");
    system.displayFlights();
    system.deleteFlight(101);
    system.displayFlights();
    
    return 0;
}