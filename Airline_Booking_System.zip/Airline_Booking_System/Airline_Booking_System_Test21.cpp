#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;

    Passenger(int id, const std::string &name, const std::string &passportNumber)
        : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int flightNumber;
    std::string origin;
    std::string destination;
    std::vector<Passenger> passengers;

    Flight(int flightNumber, const std::string &origin, const std::string &destination)
        : flightNumber(flightNumber), origin(origin), destination(destination) {}

    void addPassenger(const Passenger &passenger) {
        passengers.push_back(passenger);
    }

    void removePassenger(int passengerId) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == passengerId) {
                passengers.erase(it);
                return;
            }
        }
    }
};

class AirlineSystem {
public:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

    void addPassenger(int id, const std::string &name, const std::string &passportNumber) {
        passengers.emplace_back(id, name, passportNumber);
    }

    void removePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                return;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto &p : passengers) {
            if (p.id == id) return &p;
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto &p : passengers) {
            std::cout << "ID: " << p.id << ", Name: " << p.name << ", Passport: " << p.passportNumber << std::endl;
        }
    }

    void addFlight(int flightNumber, const std::string &origin, const std::string &destination) {
        flights.emplace_back(flightNumber, origin, destination);
    }

    void removeFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                return;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto &f : flights) {
            if (f.flightNumber == flightNumber) return &f;
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto &f : flights) {
            std::cout << "Flight Number: " << f.flightNumber << ", Origin: " << f.origin << ", Destination: " << f.destination << std::endl;
            for (const auto &p : f.passengers) {
                std::cout << "  Passenger ID: " << p.id << ", Name: " << p.name << ", Passport: " << p.passportNumber << std::endl;
            }
        }
    }

    void updatePassenger(int id, const std::string &newName, const std::string &newPassport) {
        Passenger* passenger = searchPassenger(id);
        if (passenger) {
            passenger->name = newName;
            passenger->passportNumber = newPassport;
        }
    }

    void updateFlight(int flightNumber, const std::string &newOrigin, const std::string &newDestination) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            flight->origin = newOrigin;
            flight->destination = newDestination;
        }
    }
};

int main() {
    AirlineSystem system;
    system.addPassenger(1, "John Doe", "P1234567");
    system.addPassenger(2, "Jane Smith", "P7654321");

    system.addFlight(101, "New York", "Los Angeles");
    system.addFlight(102, "Boston", "Miami");

    system.displayPassengers();
    system.displayFlights();

    return 0;
}