#include <iostream>
#include <vector>
#include <string>

struct Passenger {
    int id;
    std::string name;
    std::string passportNumber;
};

struct Flight {
    int id;
    std::string destination;
    std::string departureTime;
};

class AirlineBookingSystem {
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;
    
public:
    void addPassenger(int id, const std::string& name, const std::string& passportNumber) {
        passengers.push_back({id, name, passportNumber});
    }
    
    void addFlight(int id, const std::string& destination, const std::string& departureTime) {
        flights.push_back({id, destination, departureTime});
    }
    
    void deletePassenger(int id) {
        passengers.erase(std::remove_if(passengers.begin(), passengers.end(), [&](Passenger& p) { return p.id == id; }), passengers.end());
    }
    
    void deleteFlight(int id) {
        flights.erase(std::remove_if(flights.begin(), flights.end(), [&](Flight& f) { return f.id == id; }), flights.end());
    }
    
    void updatePassenger(int id, const std::string& name, const std::string& passportNumber) {
        for (auto& p : passengers) {
            if (p.id == id) {
                p.name = name;
                p.passportNumber = passportNumber;
                break;
            }
        }
    }
    
    void updateFlight(int id, const std::string& destination, const std::string& departureTime) {
        for (auto& f : flights) {
            if (f.id == id) {
                f.destination = destination;
                f.departureTime = departureTime;
                break;
            }
        }
    }
    
    Passenger* searchPassenger(int id) {
        for (auto& p : passengers) {
            if (p.id == id) {
                return &p;
            }
        }
        return nullptr;
    }
    
    Flight* searchFlight(int id) {
        for (auto& f : flights) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }
    
    void displayPassengers() {
        for (const auto& p : passengers) {
            std::cout << "ID: " << p.id << ", Name: " << p.name << ", Passport: " << p.passportNumber << "\n";
        }
    }
    
    void displayFlights() {
        for (const auto& f : flights) {
            std::cout << "ID: " << f.id << ", Destination: " << f.destination << ", Departure: " << f.departureTime << "\n";
        }
    }
};

int main() {
    AirlineBookingSystem system;

    system.addPassenger(1, "Alice", "P12345");
    system.addPassenger(2, "Bob", "P67890");
    system.displayPassengers();

    system.addFlight(101, "New York", "10:00 AM");
    system.addFlight(102, "Los Angeles", "2:00 PM");
    system.displayFlights();

    Passenger* p = system.searchPassenger(1);
    if (p) {
        std::cout << "Found Passenger: " << p->name << "\n";
    }

    system.updatePassenger(1, "Alice Smith", "P54321");
    system.displayPassengers();

    system.deletePassenger(2);
    system.displayPassengers();

    system.deleteFlight(101);
    system.displayFlights();

    return 0;
}