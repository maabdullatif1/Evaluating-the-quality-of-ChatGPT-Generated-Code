#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Passenger {
    int id;
    string name;
    int age;
};

struct Flight {
    int id;
    string origin;
    string destination;
    vector<Passenger> passengers;
};

class AirlineBookingSystem {
private:
    vector<Passenger> passengers;
    vector<Flight> flights;

public:
    void addPassenger(int id, string name, int age) {
        passengers.push_back({id, name, age});
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, string name, int age) {
        for (auto &p : passengers) {
            if (p.id == id) {
                p.name = name;
                p.age = age;
                break;
            }
        }
    }

    void addFlight(int id, string origin, string destination) {
        flights.push_back({id, origin, destination});
    }

    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int id, string origin, string destination) {
        for (auto &f : flights) {
            if (f.id == id) {
                f.origin = origin;
                f.destination = destination;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto &p : passengers) {
            if (p.id == id) {
                return &p;
            }
        }
        return nullptr;
    }

    Flight* searchFlight(int id) {
        for (auto &f : flights) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto &p : passengers) {
            cout << "Passenger ID: " << p.id << ", Name: " << p.name << ", Age: " << p.age << endl;
        }
    }

    void displayFlights() {
        for (const auto &f : flights) {
            cout << "Flight ID: " << f.id << ", Origin: " << f.origin << ", Destination: " << f.destination << endl;
            cout << "Passengers on this flight:" << endl;
            for (const auto &p : f.passengers) {
                cout << "  Passenger ID: " << p.id << ", Name: " << p.name << ", Age: " << p.age << endl;
            }
        }
    }

    void addPassengerToFlight(int passengerId, int flightId) {
        Passenger* p = searchPassenger(passengerId);
        if (!p) return;
        Flight* f = searchFlight(flightId);
        if (!f) return;
        f->passengers.push_back(*p);
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "John Doe", 30);
    system.addPassenger(2, "Jane Smith", 28);
    system.addFlight(101, "New York", "Los Angeles");
    system.addPassengerToFlight(1, 101);
    system.displayPassengers();
    system.displayFlights();
    return 0;
}