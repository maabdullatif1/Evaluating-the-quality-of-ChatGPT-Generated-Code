#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;

    Passenger(int id, std::string name, std::string passportNumber)
        : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int flightNumber;
    std::string destination;
    std::vector<Passenger> passengers;

    Flight(int flightNumber, std::string destination)
        : flightNumber(flightNumber), destination(destination) {}

    void addPassenger(const Passenger& passenger) {
        passengers.push_back(passenger);
    }

    void removePassenger(int passengerId) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == passengerId) {
                passengers.erase(it);
                break;
            }
        }
    }

    Passenger* searchPassenger(int passengerId) {
        for (auto& passenger : passengers) {
            if (passenger.id == passengerId)
                return &passenger;
        }
        return nullptr;
    }
};

class AirlineBookingSystem {
private:
    std::vector<Flight> flights;
    int lastPassengerId = 0;
    
    Flight* findFlight(int flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber)
                return &flight;
        }
        return nullptr;
    }

public:
    void addFlight(int flightNumber, std::string destination) {
        flights.emplace_back(flightNumber, destination);
    }

    void removeFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void addPassenger(int flightNumber, std::string name, std::string passportNumber) {
        Passenger passenger(++lastPassengerId, name, passportNumber);
        Flight* flight = findFlight(flightNumber);
        if (flight) {
            flight->addPassenger(passenger);
        }
    }

    void removePassenger(int flightNumber, int passengerId) {
        Flight* flight = findFlight(flightNumber);
        if (flight) {
            flight->removePassenger(passengerId);
        }
    }

    Passenger* searchPassenger(int flightNumber, int passengerId) {
        Flight* flight = findFlight(flightNumber);
        if (flight) {
            return flight->searchPassenger(passengerId);
        }
        return nullptr;
    }

    void updatePassenger(int flightNumber, int passengerId, std::string name, std::string passportNumber) {
        Passenger* passenger = searchPassenger(flightNumber, passengerId);
        if (passenger) {
            passenger->name = name;
            passenger->passportNumber = passportNumber;
        }
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << std::endl;
            displayPassengers(flight.flightNumber);
        }
    }

    void displayPassengers(int flightNumber) {
        Flight* flight = findFlight(flightNumber);
        if (flight) {
            std::cout << "Passengers for Flight " << flightNumber << ":" << std::endl;
            for (const auto& passenger : flight->passengers) {
                std::cout << "\tID: " << passenger.id << ", Name: " << passenger.name
                          << ", Passport Number: " << passenger.passportNumber << std::endl;
            }
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addFlight(101, "New York");
    system.addFlight(102, "Los Angeles");
    system.addPassenger(101, "John Doe", "P123456");
    system.addPassenger(101, "Jane Smith", "P654321");
    system.displayFlights();
    system.updatePassenger(101, 1, "John Doe II", "P654987");
    system.removePassenger(101, 2);
    system.displayFlights();
    return 0;
}