#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Passenger {
    int id;
    string name;
};

struct Flight {
    string flightNumber;
    string origin;
    string destination;
};

vector<Passenger> passengers;
vector<Flight> flights;

void addPassenger(int id, string name) {
    passengers.push_back({id, name});
}

void deletePassenger(int id) {
    for (auto it = passengers.begin(); it != passengers.end(); ++it) {
        if (it->id == id) {
            passengers.erase(it);
            break;
        }
    }
}

void updatePassenger(int id, string newName) {
    for (auto& passenger : passengers) {
        if (passenger.id == id) {
            passenger.name = newName;
            break;
        }
    }
}

Passenger* searchPassenger(int id) {
    for (auto& passenger : passengers) {
        if (passenger.id == id) {
            return &passenger;
        }
    }
    return nullptr;
}

void displayPassengers() {
    for (auto& passenger : passengers) {
        cout << "ID: " << passenger.id << ", Name: " << passenger.name << endl;
    }
}

void addFlight(string flightNumber, string origin, string destination) {
    flights.push_back({flightNumber, origin, destination});
}

void deleteFlight(string flightNumber) {
    for (auto it = flights.begin(); it != flights.end(); ++it) {
        if (it->flightNumber == flightNumber) {
            flights.erase(it);
            break;
        }
    }
}

void updateFlight(string flightNumber, string newOrigin, string newDestination) {
    for (auto& flight : flights) {
        if (flight.flightNumber == flightNumber) {
            flight.origin = newOrigin;
            flight.destination = newDestination;
            break;
        }
    }
}

Flight* searchFlight(string flightNumber) {
    for (auto& flight : flights) {
        if (flight.flightNumber == flightNumber) {
            return &flight;
        }
    }
    return nullptr;
}

void displayFlights() {
    for (auto& flight : flights) {
        cout << "Flight Number: " << flight.flightNumber
             << ", Origin: " << flight.origin
             << ", Destination: " << flight.destination << endl;
    }
}

int main() {
    addPassenger(1, "John Doe");
    addPassenger(2, "Jane Smith");
    addFlight("AA123", "New York", "Los Angeles");
    addFlight("BA456", "London", "Paris");

    cout << "Passengers initially:" << endl;
    displayPassengers();

    cout << "Flights initially:" << endl;
    displayFlights();

    updatePassenger(1, "John Alexander");
    updateFlight("BA456", "London", "Berlin");

    cout << "Passengers after update:" << endl;
    displayPassengers();

    cout << "Flights after update:" << endl;
    displayFlights();

    deletePassenger(2);
    deleteFlight("AA123");

    cout << "Passengers after deletion:" << endl;
    displayPassengers();

    cout << "Flights after deletion:" << endl;
    displayFlights();

    Passenger* foundPassenger = searchPassenger(1);
    if (foundPassenger) {
        cout << "Found passenger: ID = " << foundPassenger->id
             << ", Name = " << foundPassenger->name << endl;
    }

    Flight* foundFlight = searchFlight("BA456");
    if (foundFlight) {
        cout << "Found flight: Flight Number = " << foundFlight->flightNumber
             << ", Origin = " << foundFlight->origin
             << ", Destination = " << foundFlight->destination << endl;
    }

    return 0;
}