#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;

    Passenger(int i, std::string n, std::string p) : id(i), name(n), passportNumber(p) {}
};

class Flight {
public:
    int flightNumber;
    std::string origin;
    std::string destination;

    Flight(int fn, std::string o, std::string d) : flightNumber(fn), origin(o), destination(d) {}
};

class AirlineBookingSystem {
private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(int id, std::string name, std::string passportNumber) {
        passengers.push_back(Passenger(id, name, passportNumber));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, std::string name, std::string passportNumber) {
        for (auto& p : passengers) {
            if (p.id == id) {
                p.name = name;
                p.passportNumber = passportNumber;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto& p : passengers) {
            if (p.id == id) {
                return &p;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto& p : passengers) {
            std::cout << "ID: " << p.id << ", Name: " << p.name << ", Passport: " << p.passportNumber << std::endl;
        }
    }

    void addFlight(int flightNumber, std::string origin, std::string destination) {
        flights.push_back(Flight(flightNumber, origin, destination));
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int flightNumber, std::string origin, std::string destination) {
        for (auto& f : flights) {
            if (f.flightNumber == flightNumber) {
                f.origin = origin;
                f.destination = destination;
                break;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto& f : flights) {
            if (f.flightNumber == flightNumber) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto& f : flights) {
            std::cout << "Flight Number: " << f.flightNumber << ", Origin: " << f.origin << ", Destination: " << f.destination << std::endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;

    system.addPassenger(1, "John Doe", "A1234567");
    system.addPassenger(2, "Jane Smith", "B7654321");

    system.displayPassengers();

    system.addFlight(1001, "New York", "London");
    system.addFlight(1002, "Paris", "Tokyo");

    system.displayFlights();

    system.updatePassenger(1, "John Doe", "C9876543");
    system.updateFlight(1002, "Paris", "Sydney");

    system.displayPassengers();
    system.displayFlights();

    Passenger* p = system.searchPassenger(2);
    if (p) std::cout << "Found passenger: " << p->name << std::endl;

    Flight* f = system.searchFlight(1001);
    if (f) std::cout << "Found flight to: " << f->destination << std::endl;

    system.deletePassenger(2);
    system.deleteFlight(1001);

    system.displayPassengers();
    system.displayFlights();

    return 0;
}