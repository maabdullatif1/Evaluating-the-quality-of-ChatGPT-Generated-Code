#include <iostream>
#include <string>
#include <vector>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;

    Passenger(int i, const std::string &n, const std::string &p)
        : id(i), name(n), passportNumber(p) {}
};

class Flight {
public:
    int id;
    std::string origin;
    std::string destination;
    std::vector<Passenger> passengers;

    Flight(int i, const std::string &o, const std::string &d)
        : id(i), origin(o), destination(d) {}
};

class AirlineSystem {
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(int id, const std::string &name, const std::string &passportNumber) {
        passengers.push_back(Passenger(id, name, passportNumber));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, const std::string &name, const std::string &passportNumber) {
        for (auto &p : passengers) {
            if (p.id == id) {
                p.name = name;
                p.passportNumber = passportNumber;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto &p : passengers) {
            if (p.id == id) {
                return &p;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto &p : passengers) {
            std::cout << "Passenger ID: " << p.id << ", Name: " << p.name << ", Passport: " << p.passportNumber << std::endl;
        }
    }

    void addFlight(int id, const std::string &origin, const std::string &destination) {
        flights.push_back(Flight(id, origin, destination));
    }

    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int id, const std::string &origin, const std::string &destination) {
        for (auto &f : flights) {
            if (f.id == id) {
                f.origin = origin;
                f.destination = destination;
                break;
            }
        }
    }

    Flight* searchFlight(int id) {
        for (auto &f : flights) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto &f : flights) {
            std::cout << "Flight ID: " << f.id << ", Origin: " << f.origin << ", Destination: " << f.destination << std::endl;
        }
    }
};

int main() {
    AirlineSystem system;

    system.addPassenger(1, "John Doe", "A12345678");
    system.addPassenger(2, "Jane Smith", "B87654321");
   
    system.addFlight(101, "New York", "London");
    system.addFlight(102, "San Francisco", "Tokyo");

    system.displayPassengers();
    system.displayFlights();

    system.updatePassenger(1, "John Doe", "A87654321");
    system.updateFlight(101, "New York", "Paris");

    system.displayPassengers();
    system.displayFlights();

    Passenger* p = system.searchPassenger(2);
    if (p != nullptr) {
        std::cout << "Found passenger: " << p->name << std::endl;
    }

    Flight* f = system.searchFlight(102);
    if (f != nullptr) {
        std::cout << "Found flight from " << f->origin << " to " << f->destination << std::endl;
    }

    system.deletePassenger(1);
    system.deleteFlight(101);

    system.displayPassengers();
    system.displayFlights();

    return 0;
}