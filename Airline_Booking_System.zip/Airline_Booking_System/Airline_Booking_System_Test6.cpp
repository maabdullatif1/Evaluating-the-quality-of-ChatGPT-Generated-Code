#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    std::string name;
    int id;
    Passenger(const std::string& n, int i) : name(n), id(i) {}
};

class Flight {
public:
    std::string destination;
    int flightNumber;
    std::vector<Passenger> passengers;
    Flight(const std::string& d, int fn) : destination(d), flightNumber(fn) {}
};

class AirlineSystem {
    std::vector<Flight> flights;

public:
    void addFlight(const std::string& destination, int flightNumber) {
        flights.emplace_back(destination, flightNumber);
    }

    void deleteFlight(int flightNumber) {
        flights.erase(std::remove_if(flights.begin(), flights.end(), 
                                    [flightNumber](Flight& f) { return f.flightNumber == flightNumber; }), flights.end());
    }

    void updateFlight(int flightNumber, const std::string& newDestination) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = newDestination;
                break;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << "\n";
        }
    }

    void addPassenger(int flightNumber, const std::string& name, int id) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            flight->passengers.emplace_back(name, id);
        }
    }

    void deletePassenger(int flightNumber, int passengerId) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            auto& passengers = flight->passengers;
            passengers.erase(std::remove_if(passengers.begin(), passengers.end(), 
                                           [passengerId](Passenger& p) { return p.id == passengerId; }), passengers.end());
        }
    }

    void updatePassenger(int flightNumber, int passengerId, const std::string& newName) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            for (auto& passenger : flight->passengers) {
                if (passenger.id == passengerId) {
                    passenger.name = newName;
                    break;
                }
            }
        }
    }

    Passenger* searchPassenger(int flightNumber, int passengerId) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            for (auto& passenger : flight->passengers) {
                if (passenger.id == passengerId) {
                    return &passenger;
                }
            }
        }
        return nullptr;
    }

    void displayPassengers(int flightNumber) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            for (const auto& passenger : flight->passengers) {
                std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << "\n";
            }
        }
    }
};

int main() {
    AirlineSystem system;

    system.addFlight("New York", 101);
    system.addFlight("London", 102);

    system.addPassenger(101, "John Doe", 1);
    system.addPassenger(101, "Mary Smith", 2);

    system.displayFlights();
    system.displayPassengers(101);

    system.updatePassenger(101, 1, "John Smith");
    system.displayPassengers(101);

    system.deletePassenger(101, 2);
    system.displayPassengers(101);

    system.updateFlight(102, "Paris");
    system.displayFlights();

    system.deleteFlight(101);
    system.displayFlights();

    return 0;
}