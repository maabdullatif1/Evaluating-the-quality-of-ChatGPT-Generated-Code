#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Passenger {
    string name;
    string passportNumber;
};

struct Flight {
    string flightNumber;
    string destination;
    vector<Passenger> passengers;
};

class AirlineBookingSystem {
private:
    vector<Flight> flights;

public:
    void addFlight(const string& flightNumber, const string& destination) {
        flights.push_back({flightNumber, destination});
    }

    void deleteFlight(const string& flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(const string& flightNumber, const string& newDestination) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = newDestination;
                break;
            }
        }
    }

    void addPassenger(const string& flightNumber, const string& name, const string& passportNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.passengers.push_back({name, passportNumber});
                break;
            }
        }
    }

    void deletePassenger(const string& flightNumber, const string& passportNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                for (auto it = flight.passengers.begin(); it != flight.passengers.end(); ++it) {
                    if (it->passportNumber == passportNumber) {
                        flight.passengers.erase(it);
                        break;
                    }
                }
                break;
            }
        }
    }

    void updatePassenger(const string& flightNumber, const string& passportNumber, const string& newName) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                for (auto& passenger : flight.passengers) {
                    if (passenger.passportNumber == passportNumber) {
                        passenger.name = newName;
                        break;
                    }
                }
                break;
            }
        }
    }

    void searchPassenger(const string& passportNumber) {
        for (const auto& flight : flights) {
            for (const auto& passenger : flight.passengers) {
                if (passenger.passportNumber == passportNumber) {
                    cout << "Passenger found: " << passenger.name << ", Flight: " << flight.flightNumber << endl;
                    return;
                }
            }
        }
        cout << "Passenger not found" << endl;
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            cout << "Flight: " << flight.flightNumber << ", Destination: " << flight.destination << endl;
            for (const auto& passenger : flight.passengers) {
                cout << "  Passenger: " << passenger.name << ", Passport: " << passenger.passportNumber << endl;
            }
        }
    }
};

int main() {
    AirlineBookingSystem system;

    system.addFlight("AA101", "New York");
    system.addPassenger("AA101", "John Doe", "P123456");
    system.addPassenger("AA101", "Jane Smith", "P654321");
    
    system.addFlight("BA202", "London");
    system.addPassenger("BA202", "Alice Brown", "P112233");
    
    system.displayFlights();
    
    system.searchPassenger("P123456");
    
    system.updatePassenger("AA101", "P123456", "Johnathan Doe");
    system.displayFlights();
    
    system.deletePassenger("AA101", "P123456");
    system.displayFlights();
    
    system.deleteFlight("BA202");
    system.displayFlights();
    
    return 0;
}