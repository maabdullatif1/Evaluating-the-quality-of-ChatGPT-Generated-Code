#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Passenger {
public:
    int id;
    string name;
    string passportNumber;
    
    Passenger(int id, string name, string passportNumber) 
        : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int flightNumber;
    string destination;
    vector<Passenger> passengers;
    
    Flight(int flightNumber, string destination) 
        : flightNumber(flightNumber), destination(destination) {}
};

class AirlineSystem {
public:
    vector<Passenger> passengerList;
    vector<Flight> flightList;
    
    void addPassenger(int id, string name, string passportNumber) {
        Passenger p(id, name, passportNumber);
        passengerList.push_back(p);
    }
    
    void deletePassenger(int id) {
        for (size_t i = 0; i < passengerList.size(); ++i) {
            if (passengerList[i].id == id) {
                passengerList.erase(passengerList.begin() + i);
                break;
            }
        }
    }
    
    void updatePassenger(int id, string name, string passportNumber) {
        for (auto &p : passengerList) {
            if (p.id == id) {
                p.name = name;
                p.passportNumber = passportNumber;
                break;
            }
        }
    }
    
    void searchPassenger(int id) {
        for (const auto &p : passengerList) {
            if (p.id == id) {
                cout << "Passenger ID: " << p.id << ", Name: " << p.name 
                     << ", Passport Number: " << p.passportNumber << endl;
                return;
            }
        }
        cout << "Passenger not found." << endl;
    }
    
    void displayPassengers() {
        for (const auto &p : passengerList) {
            cout << "Passenger ID: " << p.id << ", Name: " << p.name 
                 << ", Passport Number: " << p.passportNumber << endl;
        }
    }
    
    void addFlight(int flightNumber, string destination) {
        Flight f(flightNumber, destination);
        flightList.push_back(f);
    }
    
    void deleteFlight(int flightNumber) {
        for (size_t i = 0; i < flightList.size(); ++i) {
            if (flightList[i].flightNumber == flightNumber) {
                flightList.erase(flightList.begin() + i);
                break;
            }
        }
    }
    
    void updateFlight(int flightNumber, string destination) {
        for (auto &f : flightList) {
            if (f.flightNumber == flightNumber) {
                f.destination = destination;
                break;
            }
        }
    }
    
    void searchFlight(int flightNumber) {
        for (const auto &f : flightList) {
            if (f.flightNumber == flightNumber) {
                cout << "Flight Number: " << f.flightNumber << ", Destination: "
                     << f.destination << endl;
                return;
            }
        }
        cout << "Flight not found." << endl;
    }
    
    void displayFlights() {
        for (const auto &f : flightList) {
            cout << "Flight Number: " << f.flightNumber << ", Destination: "
                 << f.destination << ", Passengers: [";
            for (const auto &p : f.passengers) {
                cout << p.name << " ";
            }
            cout << "]" << endl;
        }
    }
};

int main() {
    AirlineSystem system;
    system.addPassenger(1, "John Doe", "AB1234");
    system.addPassenger(2, "Jane Doe", "CD5678");
    system.addFlight(101, "New York");
    system.searchPassenger(1);
    system.displayPassengers();
    system.searchFlight(101);
    system.displayFlights();
    
    return 0;
}