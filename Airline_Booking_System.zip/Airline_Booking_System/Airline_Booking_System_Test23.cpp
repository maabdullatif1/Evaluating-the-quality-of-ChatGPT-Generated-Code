#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Passenger {
public:
    int id;
    string name;
    string passportNumber;

    Passenger(int id, const string &name, const string &passportNumber) : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int flightNumber;
    string origin;
    string destination;

    Flight(int flightNumber, const string &origin, const string &destination) : flightNumber(flightNumber), origin(origin), destination(destination) {}
};

class AirlineBookingSystem {
private:
    vector<Passenger> passengers;
    vector<Flight> flights;

public:
    void addPassenger(int id, const string &name, const string &passportNumber) {
        passengers.emplace_back(id, name, passportNumber);
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                return;
            }
        }
    }

    void updatePassenger(int id, const string &name, const string &passportNumber) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.passportNumber = passportNumber;
                return;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto &passenger : passengers) {
            cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << ", Passport Number: " << passenger.passportNumber << endl;
        }
    }

    void addFlight(int flightNumber, const string &origin, const string &destination) {
        flights.emplace_back(flightNumber, origin, destination);
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                return;
            }
        }
    }

    void updateFlight(int flightNumber, const string &origin, const string &destination) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.origin = origin;
                flight.destination = destination;
                return;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto &flight : flights) {
            cout << "Flight Number: " << flight.flightNumber << ", Origin: " << flight.origin << ", Destination: " << flight.destination << endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;

    system.addPassenger(1, "Alice", "P1234");
    system.addPassenger(2, "Bob", "P5678");

    system.displayPassengers();

    system.addFlight(101, "New York", "London");
    system.addFlight(102, "San Francisco", "Paris");

    system.displayFlights();

    Passenger* passenger = system.searchPassenger(1);
    if (passenger) {
        cout << "Found Passenger: " << passenger->name << endl;
    }

    Flight* flight = system.searchFlight(101);
    if (flight) {
        cout << "Found Flight: " << flight->origin << " to " << flight->destination << endl;
    }

    system.updatePassenger(1, "Alice Johnson", "P4321");
    system.updateFlight(102, "San Francisco", "Berlin");

    system.displayPassengers();
    system.displayFlights();

    system.deletePassenger(2);
    system.deleteFlight(101);

    system.displayPassengers();
    system.displayFlights();

    return 0;
}