#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    std::string name;
    int age;
    std::string passportNumber;

    Passenger(std::string n, int a, std::string p) : name(n), age(a), passportNumber(p) {}
};

class Flight {
public:
    std::string flightNumber;
    std::string destination;
    std::vector<Passenger> passengers;

    Flight(std::string f, std::string d) : flightNumber(f), destination(d) {}
    
    void addPassenger(Passenger p) {
        passengers.push_back(p);
    }
    
    void deletePassenger(std::string passportNumber) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->passportNumber == passportNumber) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(std::string passportNumber, std::string newName, int newAge) {
        for (auto &p : passengers) {
            if (p.passportNumber == passportNumber) {
                p.name = newName;
                p.age = newAge;
                break;
            }
        }
    }

    void displayPassengers() {
        for (const auto &p : passengers) {
            std::cout << "Name: " << p.name << ", Age: " << p.age << ", Passport: " << p.passportNumber << std::endl;
        }
    }
};

class AirlineSystem {
public:
    std::vector<Flight> flights;

    void addFlight(Flight f) {
        flights.push_back(f);
    }

    void deleteFlight(std::string flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    Flight* searchFlight(std::string flightNumber) {
        for (auto &f : flights) {
            if (f.flightNumber == flightNumber) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto &f : flights) {
            std::cout << "Flight: " << f.flightNumber << ", Destination: " << f.destination << std::endl;
            f.displayPassengers();
        }
    }
};

int main() {
    AirlineSystem system;
    system.addFlight(Flight("AB123", "New York"));
    system.addFlight(Flight("CD456", "London"));

    Flight* flight = system.searchFlight("AB123");
    if (flight != nullptr) {
        flight->addPassenger(Passenger("Alice", 30, "P001"));
        flight->addPassenger(Passenger("Bob", 25, "P002"));
    }

    flight = system.searchFlight("CD456");
    if (flight != nullptr) {
        flight->addPassenger(Passenger("Charlie", 40, "P003"));
    }

    system.displayFlights();
    
    return 0;
}