#include <iostream>
#include <string>
using namespace std;

const int MAX_ENTRIES = 100;

struct Passenger {
    int id;
    string name;
};

struct Flight {
    int flightNumber;
    string destination;
    Passenger passengers[MAX_ENTRIES];
    int passengerCount;
};

struct BookingSystem {
    Flight flights[MAX_ENTRIES];
    int flightCount;

    BookingSystem() : flightCount(0) {}

    void addFlight(int flightNumber, const string& destination) {
        if (flightCount < MAX_ENTRIES) {
            flights[flightCount].flightNumber = flightNumber;
            flights[flightCount].destination = destination;
            flights[flightCount].passengerCount = 0;
            flightCount++;
        }
    }

    void deleteFlight(int flightNumber) {
        for (int i = 0; i < flightCount; i++) {
            if (flights[i].flightNumber == flightNumber) {
                for (int j = i; j < flightCount - 1; j++) {
                    flights[j] = flights[j + 1];
                }
                flightCount--;
                break;
            }
        }
    }

    void updateFlight(int flightNumber, const string& newDestination) {
        for (int i = 0; i < flightCount; i++) {
            if (flights[i].flightNumber == flightNumber) {
                flights[i].destination = newDestination;
                break;
            }
        }
    }

    void searchFlight(int flightNumber) const {
        for (int i = 0; i < flightCount; i++) {
            if (flights[i].flightNumber == flightNumber) {
                cout << "Flight Number: " << flights[i].flightNumber
                     << ", Destination: " << flights[i].destination << endl;
                break;
            }
        }
    }

    void displayFlights() const {
        for (int i = 0; i < flightCount; i++) {
            cout << "Flight Number: " << flights[i].flightNumber
                 << ", Destination: " << flights[i].destination << endl;
        }
    }

    void addPassenger(int flightNumber, int passengerId, const string& name) {
        for (int i = 0; i < flightCount; i++) {
            if (flights[i].flightNumber == flightNumber) {
                if (flights[i].passengerCount < MAX_ENTRIES) {
                    flights[i].passengers[flights[i].passengerCount].id = passengerId;
                    flights[i].passengers[flights[i].passengerCount].name = name;
                    flights[i].passengerCount++;
                }
                break;
            }
        }
    }

    void deletePassenger(int flightNumber, int passengerId) {
        for (int i = 0; i < flightCount; i++) {
            if (flights[i].flightNumber == flightNumber) {
                for (int j = 0; j < flights[i].passengerCount; j++) {
                    if (flights[i].passengers[j].id == passengerId) {
                        for (int k = j; k < flights[i].passengerCount - 1; k++) {
                            flights[i].passengers[k] = flights[i].passengers[k + 1];
                        }
                        flights[i].passengerCount--;
                        break;
                    }
                }
                break;
            }
        }
    }

    void updatePassenger(int flightNumber, int passengerId, const string& newName) {
        for (int i = 0; i < flightCount; i++) {
            if (flights[i].flightNumber == flightNumber) {
                for (int j = 0; j < flights[i].passengerCount; j++) {
                    if (flights[i].passengers[j].id == passengerId) {
                        flights[i].passengers[j].name = newName;
                        break;
                    }
                }
                break;
            }
        }
    }

    void searchPassenger(int flightNumber, int passengerId) const {
        for (int i = 0; i < flightCount; i++) {
            if (flights[i].flightNumber == flightNumber) {
                for (int j = 0; j < flights[i].passengerCount; j++) {
                    if (flights[i].passengers[j].id == passengerId) {
                        cout << "Passenger ID: " << flights[i].passengers[j].id
                             << ", Name: " << flights[i].passengers[j].name << endl;
                        break;
                    }
                }
                break;
            }
        }
    }

    void displayPassengers(int flightNumber) const {
        for (int i = 0; i < flightCount; i++) {
            if (flights[i].flightNumber == flightNumber) {
                for (int j = 0; j < flights[i].passengerCount; j++) {
                    cout << "Passenger ID: " << flights[i].passengers[j].id
                         << ", Name: " << flights[i].passengers[j].name << endl;
                }
                break;
            }
        }
    }
};

int main() {
    BookingSystem system;
    system.addFlight(101, "New York");
    system.addPassenger(101, 1, "Alice");
    system.addPassenger(101, 2, "Bob");
    system.displayFlights();
    system.displayPassengers(101);
    system.updatePassenger(101, 1, "Alicia");
    system.searchPassenger(101, 1);
    system.deletePassenger(101, 2);
    system.displayPassengers(101);
    system.updateFlight(101, "Los Angeles");
    system.searchFlight(101);
    system.deleteFlight(101);
    system.displayFlights();
    return 0;
}