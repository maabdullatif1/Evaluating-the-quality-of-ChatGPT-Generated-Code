#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;

    Passenger(int pid, std::string pname, std::string ppassNum) 
        : id(pid), name(pname), passportNumber(ppassNum) {}
};

class Flight {
public:
    int id;
    std::string destination;
    std::string departureTime;

    Flight(int fid, std::string fdestination, std::string fdepartureTime) 
        : id(fid), destination(fdestination), departureTime(fdepartureTime) {}
};

class BookingSystem {
private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(int id, std::string name, std::string passport) {
        passengers.emplace_back(id, name, passport);
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, std::string name, std::string passport) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.passportNumber = passport;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto &passenger : passengers) {
            std::cout << "ID: " << passenger.id << ", Name: " << passenger.name 
                      << ", Passport Number: " << passenger.passportNumber << "\n";
        }
    }

    void addFlight(int id, std::string destination, std::string departureTime) {
        flights.emplace_back(id, destination, departureTime);
    }

    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int id, std::string destination, std::string departureTime) {
        for (auto &flight : flights) {
            if (flight.id == id) {
                flight.destination = destination;
                flight.departureTime = departureTime;
                break;
            }
        }
    }

    Flight* searchFlight(int id) {
        for (auto &flight : flights) {
            if (flight.id == id) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto &flight : flights) {
            std::cout << "ID: " << flight.id << ", Destination: " << flight.destination 
                      << ", Departure Time: " << flight.departureTime << "\n";
        }
    }
};

int main() {
    BookingSystem system;
    
    system.addPassenger(1, "Alice", "P12345");
    system.addPassenger(2, "Bob", "P67890");

    system.addFlight(1, "New York", "10:00 AM");
    system.addFlight(2, "Los Angeles", "02:00 PM");

    std::cout << "Passengers:\n";
    system.displayPassengers();

    std::cout << "\nFlights:\n";
    system.displayFlights();

    return 0;
}