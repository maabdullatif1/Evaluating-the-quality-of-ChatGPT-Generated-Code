#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Passenger {
public:
    int id;
    string name;
    string passport;
    
    Passenger(int id, const string &name, const string &passport)
        : id(id), name(name), passport(passport) {}
};

class Flight {
public:
    int flightNumber;
    string origin;
    string destination;
    
    Flight(int flightNumber, const string &origin, const string &destination)
        : flightNumber(flightNumber), origin(origin), destination(destination) {}
};

class AirlineBookingSystem {
    vector<Passenger> passengers;
    vector<Flight> flights;
    
public:
    void addPassenger(int id, const string &name, const string &passport) {
        passengers.emplace_back(id, name, passport);
    }
    
    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }
    
    void updatePassenger(int id, const string &name, const string &passport) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.passport = passport;
                break;
            }
        }
    }
    
    void searchPassenger(int id) {
        for (const auto &passenger : passengers) {
            if (passenger.id == id) {
                cout << "Passenger ID: " << passenger.id 
                     << " Name: " << passenger.name 
                     << " Passport: " << passenger.passport << endl;
                return;
            }
        }
        cout << "Passenger not found." << endl;
    }

    void displayPassengers() {
        if (passengers.empty()) {
            cout << "No passengers available." << endl;
            return;
        }
        for (const auto &passenger : passengers) {
            cout << "ID: " << passenger.id 
                 << " Name: " << passenger.name 
                 << " Passport: " << passenger.passport << endl;
        }
    }

    void addFlight(int flightNumber, const string &origin, const string &destination) {
        flights.emplace_back(flightNumber, origin, destination);
    }
    
    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }
    
    void updateFlight(int flightNumber, const string &origin, const string &destination) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.origin = origin;
                flight.destination = destination;
                break;
            }
        }
    }
    
    void searchFlight(int flightNumber) {
        for (const auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                cout << "Flight Number: " << flight.flightNumber 
                     << " Origin: " << flight.origin 
                     << " Destination: " << flight.destination << endl;
                return;
            }
        }
        cout << "Flight not found." << endl;
    }

    void displayFlights() {
        if (flights.empty()) {
            cout << "No flights available." << endl;
            return;
        }
        for (const auto &flight : flights) {
            cout << "Flight Number: " << flight.flightNumber 
                 << " Origin: " << flight.origin 
                 << " Destination: " << flight.destination << endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "John Doe", "A123456");
    system.addPassenger(2, "Jane Smith", "B789012");
    system.addFlight(101, "New York", "Los Angeles");
    system.addFlight(202, "Chicago", "Miami");

    cout << "Displaying Passengers:" << endl;
    system.displayPassengers();
    
    cout << "Displaying Flights:" << endl;
    system.displayFlights();
    
    system.searchPassenger(1);
    system.searchFlight(101);

    system.updatePassenger(1, "Johnathan Doe", "A123456");
    system.updateFlight(101, "New York", "San Francisco");

    system.displayPassengers();
    system.displayFlights();

    system.deletePassenger(2);
    system.deleteFlight(202);

    system.displayPassengers();
    system.displayFlights();

    return 0;
}