#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;

    Passenger(int id, const std::string& name, const std::string& passportNumber)
        : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int flightNumber;
    std::string destination;
    std::string time;

    Flight(int flightNumber, const std::string& destination, const std::string& time)
        : flightNumber(flightNumber), destination(destination), time(time) {}
};

class AirlineBookingSystem {
private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(int id, const std::string& name, const std::string& passportNumber) {
        passengers.push_back(Passenger(id, name, passportNumber));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ) {
            if (it->id == id) it = passengers.erase(it);
            else ++it;
        }
    }

    void updatePassenger(int id, const std::string& name, const std::string& passportNumber) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.passportNumber = passportNumber;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto& passenger : passengers)
            if (passenger.id == id)
                return &passenger;
        return nullptr;
    }

    void displayPassengers() {
        for (const auto& passenger : passengers)
            std::cout << "ID: " << passenger.id << ", Name: " << passenger.name 
                      << ", Passport: " << passenger.passportNumber << std::endl;
    }

    void addFlight(int flightNumber, const std::string& destination, const std::string& time) {
        flights.push_back(Flight(flightNumber, destination, time));
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ) {
            if (it->flightNumber == flightNumber) it = flights.erase(it);
            else ++it;
        }
    }

    void updateFlight(int flightNumber, const std::string& destination, const std::string& time) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = destination;
                flight.time = time;
                break;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto& flight : flights)
            if (flight.flightNumber == flightNumber)
                return &flight;
        return nullptr;
    }

    void displayFlights() {
        for (const auto& flight : flights)
            std::cout << "Flight Number: " << flight.flightNumber << ", Destination: "
                      << flight.destination << ", Time: " << flight.time << std::endl;
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "John Doe", "AB123456");
    system.addPassenger(2, "Jane Doe", "CD789012");
    system.displayPassengers();
    std::cout << "----" << std::endl;
    system.addFlight(101, "New York", "10:00");
    system.addFlight(202, "Los Angeles", "15:00");
    system.displayFlights();
    return 0;
}