#include <iostream>
#include <vector>
#include <string>

struct Passenger {
    int id;
    std::string name;
    std::string passportNumber;
};

struct Flight {
    int flightNumber;
    std::string destination;
    std::string departureTime;
};

class AirlineBookingSystem {
public:
    void addPassenger(int id, const std::string& name, const std::string& passportNumber) {
        passengers.push_back({id, name, passportNumber});
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, const std::string& name, const std::string& passportNumber) {
        for (auto& p : passengers) {
            if (p.id == id) {
                p.name = name;
                p.passportNumber = passportNumber;
                break;
            }
        }
    }

    Passenger searchPassenger(int id) {
        for (const auto& p : passengers) {
            if (p.id == id) {
                return p;
            }
        }
        return {-1, "Not Found", "Not Found"};
    }

    void addFlight(int flightNumber, const std::string& destination, const std::string& departureTime) {
        flights.push_back({flightNumber, destination, departureTime});
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int flightNumber, const std::string& destination, const std::string& departureTime) {
        for (auto& f : flights) {
            if (f.flightNumber == flightNumber) {
                f.destination = destination;
                f.departureTime = departureTime;
                break;
            }
        }
    }

    Flight searchFlight(int flightNumber) {
        for (const auto& f : flights) {
            if (f.flightNumber == flightNumber) {
                return f;
            }
        }
        return {-1, "Not Found", "Not Found"};
    }

    void displayPassengers() {
        for (const auto& p : passengers) {
            std::cout << "ID: " << p.id << ", Name: " << p.name
                      << ", Passport Number: " << p.passportNumber << std::endl;
        }
    }

    void displayFlights() {
        for (const auto& f : flights) {
            std::cout << "Flight Number: " << f.flightNumber << ", Destination: "
                      << f.destination << ", Departure Time: " << f.departureTime << std::endl;
        }
    }

private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "John Doe", "P123456");
    system.addPassenger(2, "Jane Smith", "P654321");
    system.addFlight(1001, "New York", "10:00 AM");
    system.addFlight(1002, "Los Angeles", "12:00 PM");

    system.displayPassengers();
    system.displayFlights();

    return 0;
}