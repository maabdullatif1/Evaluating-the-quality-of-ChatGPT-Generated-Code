#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;

    Passenger(int id, std::string name, std::string passportNumber)
        : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int flightNumber;
    std::string origin;
    std::string destination;

    Flight(int flightNumber, std::string origin, std::string destination)
        : flightNumber(flightNumber), origin(origin), destination(destination) {}
};

class AirlineBookingSystem {
private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

    Passenger* findPassenger(int id) {
        for (auto& passenger : passengers)
            if (passenger.id == id)
                return &passenger;
        return nullptr;
    }

    Flight* findFlight(int flightNumber) {
        for (auto& flight : flights)
            if (flight.flightNumber == flightNumber)
                return &flight;
        return nullptr;
    }

public:
    void addPassenger(int id, std::string name, std::string passportNumber) {
        passengers.push_back(Passenger(id, name, passportNumber));
    }

    void deletePassenger(int id) {
        passengers.erase(remove_if(passengers.begin(), passengers.end(), [id](Passenger& p) { return p.id == id; }), passengers.end());
    }

    void updatePassenger(int id, std::string name, std::string passportNumber) {
        Passenger* passenger = findPassenger(id);
        if (passenger) {
            passenger->name = name;
            passenger->passportNumber = passportNumber;
        }
    }

    void searchPassenger(int id) {
        Passenger* passenger = findPassenger(id);
        if (passenger)
            std::cout << "Passenger ID: " << passenger->id << ", Name: " << passenger->name << ", Passport Number: " << passenger->passportNumber << "\n";
        else
            std::cout << "Passenger not found\n";
    }

    void displayPassengers() {
        for (const auto& passenger : passengers)
            std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << ", Passport Number: " << passenger.passportNumber << "\n";
    }

    void addFlight(int flightNumber, std::string origin, std::string destination) {
        flights.push_back(Flight(flightNumber, origin, destination));
    }

    void deleteFlight(int flightNumber) {
        flights.erase(remove_if(flights.begin(), flights.end(), [flightNumber](Flight& f) { return f.flightNumber == flightNumber; }), flights.end());
    }

    void updateFlight(int flightNumber, std::string origin, std::string destination) {
        Flight* flight = findFlight(flightNumber);
        if (flight) {
            flight->origin = origin;
            flight->destination = destination;
        }
    }

    void searchFlight(int flightNumber) {
        Flight* flight = findFlight(flightNumber);
        if (flight)
            std::cout << "Flight Number: " << flight->flightNumber << ", Origin: " << flight->origin << ", Destination: " << flight->destination << "\n";
        else
            std::cout << "Flight not found\n";
    }

    void displayFlights() {
        for (const auto& flight : flights)
            std::cout << "Flight Number: " << flight.flightNumber << ", Origin: " << flight.origin << ", Destination: " << flight.destination << "\n";
    }
};

int main() {
    AirlineBookingSystem abs;
    abs.addPassenger(1, "John Doe", "P123456");
    abs.addPassenger(2, "Jane Smith", "P654321");
    abs.addFlight(101, "NYC", "LAX");
    abs.addFlight(102, "SFO", "MIA");
    std::cout << "Passengers:\n";
    abs.displayPassengers();
    std::cout << "\nFlights:\n";
    abs.displayFlights();
    std::cout << "\nSearch Passenger ID 1:\n";
    abs.searchPassenger(1);
    std::cout << "\nUpdate Passenger ID 1:\n";
    abs.updatePassenger(1, "John Doe Jr.", "P123456A");
    abs.displayPassengers();
    return 0;
}