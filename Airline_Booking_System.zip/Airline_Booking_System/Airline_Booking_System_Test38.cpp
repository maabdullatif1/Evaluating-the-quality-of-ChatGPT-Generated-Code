#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passport;

    Passenger(int id, std::string name, std::string passport)
        : id(id), name(name), passport(passport) {}
};

class Flight {
public:
    int flightNumber;
    std::string origin;
    std::string destination;

    Flight(int flightNumber, std::string origin, std::string destination)
        : flightNumber(flightNumber), origin(origin), destination(destination) {}
};

class BookingSystem {
private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(int id, std::string name, std::string passport) {
        passengers.push_back(Passenger(id, name, passport));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, std::string name, std::string passport) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.passport = passport;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) return &passenger;
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            std::cout << "ID: " << passenger.id << ", Name: " << passenger.name
                      << ", Passport: " << passenger.passport << std::endl;
        }
    }

    void addFlight(int flightNumber, std::string origin, std::string destination) {
        flights.push_back(Flight(flightNumber, origin, destination));
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int flightNumber, std::string origin, std::string destination) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.origin = origin;
                flight.destination = destination;
                break;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) return &flight;
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Origin: " << flight.origin
                      << ", Destination: " << flight.destination << std::endl;
        }
    }
};

int main() {
    BookingSystem system;
    system.addPassenger(1, "John Doe", "AB123456");
    system.addPassenger(2, "Jane Smith", "CD987654");
    system.addFlight(1001, "New York", "London");
    system.addFlight(2002, "Paris", "Tokyo");

    system.displayPassengers();
    system.displayFlights();

    Passenger* p = system.searchPassenger(1);
    if (p) std::cout << "Found Passenger: " << p->name << std::endl;

    Flight* f = system.searchFlight(1001);
    if (f) std::cout << "Found Flight: " << f->origin << " to " << f->destination << std::endl;

    system.updatePassenger(1, "Johnathan Doe", "XY123456");
    system.updateFlight(1001, "New York", "Paris");

    system.displayPassengers();
    system.displayFlights();

    system.deletePassenger(2);
    system.deleteFlight(2002);

    system.displayPassengers();
    system.displayFlights();

    return 0;
}