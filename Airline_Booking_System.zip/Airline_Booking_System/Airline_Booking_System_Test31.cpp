#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;

    Passenger(int id, const std::string &name, const std::string &passportNumber)
        : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int flightNumber;
    std::string destination;
    std::string departureTime;

    Flight(int flightNumber, const std::string &destination, const std::string &departureTime)
        : flightNumber(flightNumber), destination(destination), departureTime(departureTime) {}
};

class AirlineBookingSystem {
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(const Passenger &p) {
        passengers.push_back(p);
    }

    void deletePassenger(int passengerId) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == passengerId) {
                passengers.erase(it);
                return;
            }
        }
    }

    void updatePassenger(int passengerId, const std::string &name, const std::string &passportNumber) {
        for (auto &p : passengers) {
            if (p.id == passengerId) {
                p.name = name;
                p.passportNumber = passportNumber;
                return;
            }
        }
    }

    Passenger* searchPassenger(int passengerId) {
        for (auto &p : passengers) {
            if (p.id == passengerId) {
                return &p;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto &p : passengers) {
            std::cout << "ID: " << p.id << ", Name: " << p.name << ", Passport Number: " << p.passportNumber << "\n";
        }
    }

    void addFlight(const Flight &f) {
        flights.push_back(f);
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                return;
            }
        }
    }

    void updateFlight(int flightNumber, const std::string& destination, const std::string& departureTime) {
        for (auto &f : flights) {
            if (f.flightNumber == flightNumber) {
                f.destination = destination;
                f.departureTime = departureTime;
                return;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto &f : flights) {
            if (f.flightNumber == flightNumber) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto &f : flights) {
            std::cout << "Flight Number: " << f.flightNumber << ", Destination: " << f.destination << ", Departure Time: " << f.departureTime << "\n";
        }
    }
};

int main() {
    AirlineBookingSystem system;

    system.addPassenger(Passenger(1, "John Doe", "ABC123"));
    system.addPassenger(Passenger(2, "Jane Smith", "XYZ789"));
    system.displayPassengers();

    system.addFlight(Flight(101, "New York", "10:00"));
    system.addFlight(Flight(102, "Los Angeles", "15:00"));
    system.displayFlights();
    
    return 0;
}