#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    std::string name;
    int id;
    Passenger(std::string name, int id): name(name), id(id) {}
};

class Flight {
public:
    std::string flightNumber;
    std::string origin;
    std::string destination;
    std::vector<Passenger> passengers;

    Flight(std::string flightNumber, std::string origin, std::string destination)
    : flightNumber(flightNumber), origin(origin), destination(destination) {}

    void addPassenger(const Passenger& passenger) {
        passengers.push_back(passenger);
    }

    void removePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                return;
            }
        }
    }

    void updatePassenger(int id, const std::string& newName) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = newName;
                return;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << "\n";
        }
    }
};

class BookingSystem {
public:
    std::vector<Flight> flights;

    void addFlight(const Flight& flight) {
        flights.push_back(flight);
    }

    void removeFlight(const std::string& flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                return;
            }
        }
    }

    void updateFlight(const std::string& flightNumber, const std::string& newOrigin, const std::string& newDestination) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.origin = newOrigin;
                flight.destination = newDestination;
                return;
            }
        }
    }

    Flight* searchFlight(const std::string& flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber 
                      << ", Origin: " << flight.origin 
                      << ", Destination: " << flight.destination << std::endl;
            flight.displayPassengers();
        }
    }
};

int main() {
    BookingSystem system;
    Flight flight1("AB123", "New York", "Los Angeles");
    flight1.addPassenger(Passenger("John Doe", 1));
    flight1.addPassenger(Passenger("Alice Smith", 2));

    system.addFlight(flight1);
    system.displayFlights();

    Flight* f = system.searchFlight("AB123");
    if (f) {
        f->removePassenger(1);
        f->updatePassenger(2, "Alice Johnson");
    }

    system.displayFlights();

    return 0;
}