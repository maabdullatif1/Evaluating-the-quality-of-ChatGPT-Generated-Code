#include <iostream>
#include <vector>
#include <string>

struct Passenger {
    int id;
    std::string name;
    std::string passportNumber;
};

struct Flight {
    int flightNumber;
    std::string destination;
    std::string departureTime;
    std::vector<Passenger> passengers;
};

class AirlineSystem {
    std::vector<Flight> flights;
    int passengerCount = 0;

public:
    void addPassenger(int flightNumber, const std::string& name, const std::string& passportNumber);
    void deletePassenger(int flightNumber, int passengerId);
    void updatePassenger(int flightNumber, int passengerId, const std::string& name, const std::string& passportNumber);
    void searchPassenger(int flightNumber, int passengerId);
    void displayPassengers(int flightNumber);
    void addFlight(int flightNumber, const std::string& destination, const std::string& departureTime);
    void deleteFlight(int flightNumber);
    void updateFlight(int flightNumber, const std::string& destination, const std::string& departureTime);
    void searchFlight(int flightNumber);
    void displayFlights();
};

void AirlineSystem::addPassenger(int flightNumber, const std::string& name, const std::string& passportNumber) {
    for (auto& flight : flights) {
        if (flight.flightNumber == flightNumber) {
            Passenger passenger = { ++passengerCount, name, passportNumber };
            flight.passengers.push_back(passenger);
            return;
        }
    }
}

void AirlineSystem::deletePassenger(int flightNumber, int passengerId) {
    for (auto& flight : flights) {
        if (flight.flightNumber == flightNumber) {
            for (auto it = flight.passengers.begin(); it != flight.passengers.end(); ++it) {
                if (it->id == passengerId) {
                    flight.passengers.erase(it);
                    return;
                }
            }
        }
    }
}

void AirlineSystem::updatePassenger(int flightNumber, int passengerId, const std::string& name, const std::string& passportNumber) {
    for (auto& flight : flights) {
        if (flight.flightNumber == flightNumber) {
            for (auto& passenger : flight.passengers) {
                if (passenger.id == passengerId) {
                    passenger.name = name;
                    passenger.passportNumber = passportNumber;
                    return;
                }
            }
        }
    }
}

void AirlineSystem::searchPassenger(int flightNumber, int passengerId) {
    for (const auto& flight : flights) {
        if (flight.flightNumber == flightNumber) {
            for (const auto& passenger : flight.passengers) {
                if (passenger.id == passengerId) {
                    std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << ", Passport No: " << passenger.passportNumber << std::endl;
                    return;
                }
            }
        }
    }
}

void AirlineSystem::displayPassengers(int flightNumber) {
    for (const auto& flight : flights) {
        if (flight.flightNumber == flightNumber) {
            for (const auto& passenger : flight.passengers) {
                std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << ", Passport No: " << passenger.passportNumber << std::endl;
            }
            return;
        }
    }
}

void AirlineSystem::addFlight(int flightNumber, const std::string& destination, const std::string& departureTime) {
    Flight flight = { flightNumber, destination, departureTime, {} };
    flights.push_back(flight);
}

void AirlineSystem::deleteFlight(int flightNumber) {
    for (auto it = flights.begin(); it != flights.end(); ++it) {
        if (it->flightNumber == flightNumber) {
            flights.erase(it);
            return;
        }
    }
}

void AirlineSystem::updateFlight(int flightNumber, const std::string& destination, const std::string& departureTime) {
    for (auto& flight : flights) {
        if (flight.flightNumber == flightNumber) {
            flight.destination = destination;
            flight.departureTime = departureTime;
            return;
        }
    }
}

void AirlineSystem::searchFlight(int flightNumber) {
    for (const auto& flight : flights) {
        if (flight.flightNumber == flightNumber) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << ", Departure Time: " << flight.departureTime << std::endl;
            return;
        }
    }
}

void AirlineSystem::displayFlights() {
    for (const auto& flight : flights) {
        std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << ", Departure Time: " << flight.departureTime << std::endl;
    }
}

int main() {
    AirlineSystem system;
    system.addFlight(123, "New York", "10:00 AM");
    system.addPassenger(123, "John Doe", "AB1234567");
    system.displayFlights();
    system.displayPassengers(123);
    return 0;
}