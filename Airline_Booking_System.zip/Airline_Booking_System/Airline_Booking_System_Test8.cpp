#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    std::string name;
    int age;
    std::string passportNumber;

    Passenger(std::string n, int a, std::string p) : name(n), age(a), passportNumber(p) {}
};

class Flight {
public:
    std::string flightNumber;
    std::string destination;
    std::string departureTime;

    Flight(std::string fn, std::string dest, std::string dt) : flightNumber(fn), destination(dest), departureTime(dt) {}
};

class AirlineBookingSystem {
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(const std::string& name, int age, const std::string& passportNumber) {
        passengers.push_back(Passenger(name, age, passportNumber));
    }

    void deletePassenger(const std::string& passportNumber) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->passportNumber == passportNumber) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(const std::string& passportNumber, const std::string& newName, int newAge) {
        for (auto& passenger : passengers) {
            if (passenger.passportNumber == passportNumber) {
                passenger.name = newName;
                passenger.age = newAge;
                break;
            }
        }
    }

    void searchPassenger(const std::string& passportNumber) {
        for (const auto& passenger : passengers) {
            if (passenger.passportNumber == passportNumber) {
                std::cout << "Name: " << passenger.name << ", Age: " << passenger.age << ", Passport Number: " << passenger.passportNumber << std::endl;
                return;
            }
        }
        std::cout << "Passenger not found.\n";
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            std::cout << "Name: " << passenger.name << ", Age: " << passenger.age << ", Passport Number: " << passenger.passportNumber << std::endl;
        }
    }

    void addFlight(const std::string& flightNumber, const std::string& destination, const std::string& departureTime) {
        flights.push_back(Flight(flightNumber, destination, departureTime));
    }

    void deleteFlight(const std::string& flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(const std::string& flightNumber, const std::string& newDestination, const std::string& newDepartureTime) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = newDestination;
                flight.departureTime = newDepartureTime;
                break;
            }
        }
    }

    void searchFlight(const std::string& flightNumber) {
        for (const auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << ", Departure Time: " << flight.departureTime << std::endl;
                return;
            }
        }
        std::cout << "Flight not found.\n";
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << ", Departure Time: " << flight.departureTime << std::endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger("John Doe", 30, "XYZ123");
    system.addPassenger("Jane Smith", 25, "ABC456");
    system.displayPassengers();
    system.updatePassenger("XYZ123", "Johnathan Doe", 31);
    system.displayPassengers();
    system.deletePassenger("ABC456");
    system.displayPassengers();

    system.addFlight("FL123", "New York", "10:00 AM");
    system.addFlight("FL456", "London", "02:00 PM");
    system.displayFlights();
    system.updateFlight("FL123", "Los Angeles", "11:00 AM");
    system.displayFlights();
    system.deleteFlight("FL456");
    system.displayFlights();

    return 0;
}