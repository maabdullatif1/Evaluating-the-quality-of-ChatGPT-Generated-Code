#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    Passenger(int i, std::string n) : id(i), name(n) {}
};

class Flight {
public:
    int id;
    std::string destination;
    std::vector<Passenger> passengers;
    Flight(int i, std::string d) : id(i), destination(d) {}
    
    void addPassenger(const Passenger& p) {
        passengers.push_back(p);
    }

    void deletePassenger(int passengerId) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == passengerId) {
                passengers.erase(it);
                break;
            }
        }
    }
    
    void updatePassenger(int passengerId, const std::string& newName) {
        for (auto& p : passengers) {
            if (p.id == passengerId) {
                p.name = newName;
                break;
            }
        }
    }
    
    Passenger* searchPassenger(int passengerId) {
        for (auto& p : passengers) {
            if (p.id == passengerId) {
                return &p;
            }
        }
        return nullptr;
    }
};

class AirlineBookingSystem {
private:
    std::vector<Flight> flights;
    
public:
    void addFlight(int flightId, const std::string& destination) {
        flights.emplace_back(flightId, destination);
    }
    
    void deleteFlight(int flightId) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == flightId) {
                flights.erase(it);
                break;
            }
        }
    }
    
    void updateFlightDestination(int flightId, const std::string& newDestination) {
        for (auto& flight : flights) {
            if (flight.id == flightId) {
                flight.destination = newDestination;
                break;
            }
        }
    }
    
    Flight* searchFlight(int flightId) {
        for (auto& flight : flights) {
            if (flight.id == flightId) {
                return &flight;
            }
        }
        return nullptr;
    }
    
    void displayFlights() {
        for (const auto& flight : flights) {
            std::cout << "Flight ID: " << flight.id << ", Destination: " << flight.destination << "\nPassengers:\n";
            for (const auto& p : flight.passengers) {
                std::cout << "\tID: " << p.id << ", Name: " << p.name << "\n";
            }
        }
    }
    
    void addPassengerToFlight(int flightId, const Passenger& p) {
        Flight* flight = searchFlight(flightId);
        if (flight) {
            flight->addPassenger(p);
        }
    }

    void deletePassengerFromFlight(int flightId, int passengerId) {
        Flight* flight = searchFlight(flightId);
        if (flight) {
            flight->deletePassenger(passengerId);
        }
    }
    
    void updatePassengerInFlight(int flightId, int passengerId, const std::string& newName) {
        Flight* flight = searchFlight(flightId);
        if (flight) {
            flight->updatePassenger(passengerId, newName);
        }
    }
    
    Passenger* searchPassengerInFlight(int flightId, int passengerId) {
        Flight* flight = searchFlight(flightId);
        if (flight) {
            return flight->searchPassenger(passengerId);
        }
        return nullptr;
    }
};

int main() {
    AirlineBookingSystem system;
    system.addFlight(101, "New York");
    system.addPassengerToFlight(101, Passenger(1, "John Doe"));
    system.addPassengerToFlight(101, Passenger(2, "Jane Smith"));
    system.displayFlights();
    return 0;
}