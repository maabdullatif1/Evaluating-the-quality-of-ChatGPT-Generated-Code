#include <iostream>
#include <string>
#include <vector>

class Passenger {
public:
    std::string name;
    std::string passportNumber;

    Passenger(std::string n, std::string pn) : name(n), passportNumber(pn) {}
};

class Flight {
public:
    std::string flightNumber;
    std::string destination;
    std::vector<Passenger> passengers;

    Flight(std::string fn, std::string dest) : flightNumber(fn), destination(dest) {}

    void addPassenger(const Passenger& p) {
        passengers.push_back(p);
    }

    void removePassenger(const std::string& passportNumber) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->passportNumber == passportNumber) {
                passengers.erase(it);
                return;
            }
        }
    }

    void updatePassenger(const std::string& passportNumber, const std::string& newName) {
        for (auto& p : passengers) {
            if (p.passportNumber == passportNumber) {
                p.name = newName;
                return;
            }
        }
    }

    Passenger* searchPassenger(const std::string& passportNumber) {
        for (auto& p : passengers) {
            if (p.passportNumber == passportNumber) {
                return &p;
            }
        }
        return nullptr;
    }

    void displayPassengers() const {
        for (const auto& p : passengers) {
            std::cout << "Name: " << p.name << ", Passport Number: " << p.passportNumber << std::endl;
        }
    }
};

class BookingSystem {
private:
    std::vector<Flight> flights;

public:
    void addFlight(const std::string& flightNumber, const std::string& destination) {
        flights.emplace_back(flightNumber, destination);
    }

    void removeFlight(const std::string& flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                return;
            }
        }
    }

    Flight* searchFlight(const std::string& flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() const {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << std::endl;
        }
    }
};

int main() {
    BookingSystem system;
    system.addFlight("AA101", "New York");
    system.addFlight("BA202", "London");

    Flight* flight = system.searchFlight("AA101");
    if (flight) {
        flight->addPassenger(Passenger("John Doe", "1234"));
        flight->addPassenger(Passenger("Jane Smith", "5678"));
    }

    system.displayFlights();
    if (flight) {
        flight->displayPassengers();
    }

    return 0;
}