#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string email;

    Passenger(int id, std::string name, std::string email) : id(id), name(name), email(email) {}
};

class Flight {
public:
    int flightNumber;
    std::string destination;
    std::string date;

    Flight(int flightNumber, std::string destination, std::string date) : flightNumber(flightNumber), destination(destination), date(date) {}
};

class AirlineBookingSystem {
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(int id, std::string name, std::string email) {
        passengers.push_back(Passenger(id, name, email));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, std::string name, std::string email) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.email = email;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }
    
    void displayPassengers() {
        for (const auto &passenger : passengers) {
            std::cout << "ID: " << passenger.id << ", Name: " << passenger.name << ", Email: " << passenger.email << std::endl;
        }
    }

    void addFlight(int flightNumber, std::string destination, std::string date) {
        flights.push_back(Flight(flightNumber, destination, date));
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int flightNumber, std::string destination, std::string date) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = destination;
                flight.date = date;
                break;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto &flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << ", Date: " << flight.date << std::endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;

    system.addPassenger(1, "John Doe", "john@example.com");
    system.addPassenger(2, "Jane Smith", "jane@example.com");

    system.addFlight(101, "New York", "2023-10-01");
    system.addFlight(102, "London", "2023-11-15");

    system.displayPassengers();
    system.displayFlights();

    Passenger* passenger = system.searchPassenger(1);
    if (passenger) {
        std::cout << "Found Passenger: " << passenger->name << std::endl;
    }

    Flight* flight = system.searchFlight(101);
    if (flight) {
        std::cout << "Found Flight: " << flight->destination << std::endl;
    }

    system.updatePassenger(1, "Johnathan Doe", "johnathan@example.com");
    system.updateFlight(101, "Los Angeles", "2023-10-02");

    system.deletePassenger(2);
    system.deleteFlight(102);

    system.displayPassengers();
    system.displayFlights();

    return 0;
}