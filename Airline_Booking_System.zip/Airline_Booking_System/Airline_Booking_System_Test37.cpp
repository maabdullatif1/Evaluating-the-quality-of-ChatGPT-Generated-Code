#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Flight {
    string flightNumber;
    string destination;
    string departure;
};

struct Passenger {
    string name;
    string passportNumber;
    string flightNumber;
};

class AirlineSystem {
private:
    vector<Flight> flights;
    vector<Passenger> passengers;

    int findFlightIndex(const string& flightNumber) {
        for (int i = 0; i < flights.size(); ++i) {
            if (flights[i].flightNumber == flightNumber) {
                return i;
            }
        }
        return -1;
    }

    int findPassengerIndex(const string& passportNumber) {
        for (int i = 0; i < passengers.size(); ++i) {
            if (passengers[i].passportNumber == passportNumber) {
                return i;
            }
        }
        return -1;
    }

public:
    void addFlight(const string& flightNumber, const string& destination, const string& departure) {
        if (findFlightIndex(flightNumber) == -1) {
            flights.push_back({flightNumber, destination, departure});
        }
    }

    void deleteFlight(const string& flightNumber) {
        int index = findFlightIndex(flightNumber);
        if (index != -1) {
            flights.erase(flights.begin() + index);
        }
    }

    void updateFlight(const string& flightNumber, const string& newDestination, const string& newDeparture) {
        int index = findFlightIndex(flightNumber);
        if (index != -1) {
            flights[index] = {flightNumber, newDestination, newDeparture};
        }
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            cout << "Flight Number: " << flight.flightNumber
                 << ", Destination: " << flight.destination
                 << ", Departure: " << flight.departure << endl;
        }
    }

    void addPassenger(const string& name, const string& passportNumber, const string& flightNumber) {
        if (findPassengerIndex(passportNumber) == -1 && findFlightIndex(flightNumber) != -1) {
            passengers.push_back({name, passportNumber, flightNumber});
        }
    }

    void deletePassenger(const string& passportNumber) {
        int index = findPassengerIndex(passportNumber);
        if (index != -1) {
            passengers.erase(passengers.begin() + index);
        }
    }

    void updatePassenger(const string& passportNumber, const string& newName, const string& newFlightNumber) {
        int index = findPassengerIndex(passportNumber);
        if (index != -1 && findFlightIndex(newFlightNumber) != -1) {
            passengers[index] = {newName, passportNumber, newFlightNumber};
        }
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            cout << "Name: " << passenger.name
                 << ", Passport Number: " << passenger.passportNumber
                 << ", Flight Number: " << passenger.flightNumber << endl;
        }
    }
};

int main() {
    AirlineSystem system;
    system.addFlight("FL123", "New York", "10:00");
    system.addPassenger("John Doe", "P123456", "FL123");
    system.displayFlights();
    system.displayPassengers();
    system.updateFlight("FL123", "Los Angeles", "11:00");
    system.updatePassenger("P123456", "John Smith", "FL123");
    system.displayFlights();
    system.displayPassengers();
    system.deletePassenger("P123456");
    system.deleteFlight("FL123");
    system.displayFlights();
    system.displayPassengers();
    return 0;
}