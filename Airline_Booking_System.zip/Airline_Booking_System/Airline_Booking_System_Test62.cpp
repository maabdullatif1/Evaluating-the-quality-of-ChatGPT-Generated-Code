#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;

    Passenger(int id, std::string name, std::string passportNumber) 
        : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int flightNumber;
    std::string destination;
    std::string departureTime;

    Flight(int flightNumber, std::string destination, std::string departureTime) 
        : flightNumber(flightNumber), destination(destination), departureTime(departureTime) {}
};

class AirlineBookingSystem {
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(int id, std::string name, std::string passportNumber) {
        passengers.push_back(Passenger(id, name, passportNumber));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, std::string name, std::string passportNumber) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.passportNumber = passportNumber;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            std::cout << "ID: " << passenger.id << ", Name: " << passenger.name << ", Passport: " << passenger.passportNumber << "\n";
        }
    }

    void addFlight(int flightNumber, std::string destination, std::string departureTime) {
        flights.push_back(Flight(flightNumber, destination, departureTime));
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int flightNumber, std::string destination, std::string departureTime) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = destination;
                flight.departureTime = departureTime;
                break;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << ", Departure Time: " << flight.departureTime << "\n";
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "John Doe", "A123456");
    system.addPassenger(2, "Jane Doe", "B654321");
    
    system.addFlight(101, "New York", "10:00 AM");
    system.addFlight(102, "London", "02:00 PM");
    
    system.displayPassengers();
    system.displayFlights();
    
    Passenger* foundPassenger = system.searchPassenger(1);
    if (foundPassenger) {
        std::cout << "Found Passenger: " << foundPassenger->name << "\n";
    }
    
    system.updatePassenger(2, "Jane Smith", "B654321");
    system.deletePassenger(1);
    system.displayPassengers();
    
    Flight* foundFlight = system.searchFlight(101);
    if (foundFlight) {
        std::cout << "Found Flight to: " << foundFlight->destination << "\n";
    }
    
    system.updateFlight(102, "Paris", "03:00 PM");
    system.deleteFlight(101);
    system.displayFlights();
    
    return 0;
}