#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Passenger {
public:
    string name;
    int id;
    Passenger(int i, string n) : id(i), name(n) {}
};

class Flight {
public:
    string destination;
    int flightNumber;
    Flight(int fn, string d) : flightNumber(fn), destination(d) {}
};

class BookingSystem {
private:
    vector<Passenger> passengers;
    vector<Flight> flights;

public:
    void addPassenger(int id, const string& name) {
        passengers.push_back(Passenger(id, name));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, const string& name) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << endl;
        }
    }

    void addFlight(int flightNumber, const string& destination) {
        flights.push_back(Flight(flightNumber, destination));
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int flightNumber, const string& destination) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = destination;
                break;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << endl;
        }
    }
};

int main() {
    BookingSystem system;
    system.addPassenger(1, "John Doe");
    system.addPassenger(2, "Jane Smith");
    system.addFlight(101, "New York");
    system.addFlight(102, "London");

    system.displayPassengers();
    system.displayFlights();

    system.updatePassenger(1, "John A. Doe");
    system.updateFlight(101, "San Francisco");

    system.displayPassengers();
    system.displayFlights();

    Passenger* p = system.searchPassenger(1);
    if (p) {
        cout << "Found Passenger: " << p->name << endl;
    }

    Flight* f = system.searchFlight(102);
    if (f) {
        cout << "Found Flight to: " << f->destination << endl;
    }

    system.deletePassenger(1);
    system.deleteFlight(101);

    system.displayPassengers();
    system.displayFlights();

    return 0;
}