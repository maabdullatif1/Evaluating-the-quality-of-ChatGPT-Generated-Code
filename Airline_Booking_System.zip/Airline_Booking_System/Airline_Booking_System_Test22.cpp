#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Passenger {
public:
    string name;
    int age;
    string passportNumber;

    Passenger(string name, int age, string passportNumber)
        : name(name), age(age), passportNumber(passportNumber) {}
};

class Flight {
public:
    string flightNumber;
    string origin;
    string destination;
    vector<Passenger> passengers;

    Flight(string flightNumber, string origin, string destination)
        : flightNumber(flightNumber), origin(origin), destination(destination) {}

    void addPassenger(Passenger passenger) {
        passengers.push_back(passenger);
    }

    void deletePassenger(string passportNumber) {
        for (size_t i = 0; i < passengers.size(); ++i) {
            if (passengers[i].passportNumber == passportNumber) {
                passengers.erase(passengers.begin() + i);
                return;
            }
        }
    }

    void updatePassenger(string passportNumber, string name, int age) {
        for (auto &passenger : passengers) {
            if (passenger.passportNumber == passportNumber) {
                passenger.name = name;
                passenger.age = age;
                return;
            }
        }
    }

    void displayPassengers() {
        for (const auto &passenger : passengers) {
            cout << "Name: " << passenger.name << ", Age: " << passenger.age
                 << ", Passport Number: " << passenger.passportNumber << endl;
        }
    }
};

class AirlineBookingSystem {
public:
    vector<Flight> flights;

    void addFlight(Flight flight) {
        flights.push_back(flight);
    }

    void deleteFlight(string flightNumber) {
        for (size_t i = 0; i < flights.size(); ++i) {
            if (flights[i].flightNumber == flightNumber) {
                flights.erase(flights.begin() + i);
                return;
            }
        }
    }

    void updateFlight(string flightNumber, string origin, string destination) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.origin = origin;
                flight.destination = destination;
                return;
            }
        }
    }

    void searchFlight(string flightNumber) {
        for (const auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                cout << "Flight Number: " << flight.flightNumber
                     << ", Origin: " << flight.origin
                     << ", Destination: " << flight.destination << endl;
                flight.displayPassengers();
                return;
            }
        }
        cout << "Flight not found." << endl;
    }

    void displayFlights() {
        for (const auto &flight : flights) {
            cout << "Flight Number: " << flight.flightNumber
                 << ", Origin: " << flight.origin
                 << ", Destination: " << flight.destination << endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;
    Flight flight1("A123", "New York", "Los Angeles");
    system.addFlight(flight1);

    Passenger passenger1("John Doe", 30, "AB123456");
    flight1.addPassenger(passenger1);

    system.searchFlight("A123");
    system.displayFlights();

    system.updateFlight("A123", "New York", "San Francisco");
    system.searchFlight("A123");

    return 0;
}