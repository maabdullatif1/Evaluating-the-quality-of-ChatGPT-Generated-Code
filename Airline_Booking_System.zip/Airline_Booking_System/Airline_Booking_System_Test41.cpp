#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Passenger {
public:
    string name;
    int id;
    Passenger(string n, int i) : name(n), id(i) {}
};

class Flight {
public:
    int flightNumber;
    string destination;
    vector<Passenger> passengers;
    Flight(int fn, string dest) : flightNumber(fn), destination(dest) {}
};

class AirlineBookingSystem {
    vector<Flight> flights;
public:
    void addFlight(int flightNumber, string destination) {
        flights.push_back(Flight(flightNumber, destination));
    }
    
    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }
    
    void updateFlight(int flightNumber, string newDestination) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = newDestination;
                break;
            }
        }
    }
    
    void addPassenger(int flightNumber, string name, int id) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.passengers.push_back(Passenger(name, id));
                break;
            }
        }
    }
    
    void deletePassenger(int flightNumber, int passengerId) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                for (auto it = flight.passengers.begin(); it != flight.passengers.end(); ++it) {
                    if (it->id == passengerId) {
                        flight.passengers.erase(it);
                        break;
                    }
                }
            }
        }
    }
    
    void updatePassenger(int flightNumber, int passengerId, string newName) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                for (auto &passenger : flight.passengers) {
                    if (passenger.id == passengerId) {
                        passenger.name = newName;
                        break;
                    }
                }
            }
        }
    }

    void searchPassenger(int passengerId) {
        for (auto &flight : flights) {
            for (auto &passenger : flight.passengers) {
                if (passenger.id == passengerId) {
                    cout << "Passenger Found: " << passenger.name << ", Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << endl;
                    return;
                }
            }
        }
        cout << "Passenger not found." << endl;
    }

    void displayAllFlights() {
        for (auto &flight : flights) {
            cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << endl;
            for (auto &passenger : flight.passengers) {
                cout << "    Passenger ID: " << passenger.id << ", Name: " << passenger.name << endl;
            }
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addFlight(101, "New York");
    system.addPassenger(101, "John Doe", 1);
    system.addPassenger(101, "Jane Doe", 2);
    
    system.addFlight(202, "Los Angeles");
    system.addPassenger(202, "Alice Smith", 3);
    
    system.displayAllFlights();
    
    system.updatePassenger(101, 1, "John Smith");
    system.deletePassenger(101, 2);
    system.displayAllFlights();
    
    system.searchPassenger(3);
    
    system.updateFlight(202, "San Francisco");
    system.deleteFlight(101);
    system.displayAllFlights();
    
    return 0;
}