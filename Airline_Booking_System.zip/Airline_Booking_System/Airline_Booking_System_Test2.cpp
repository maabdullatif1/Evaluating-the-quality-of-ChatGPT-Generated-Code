#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Passenger {
    int id;
    string name;
};

struct Flight {
    int id;
    string destination;
    vector<Passenger> passengers;
};

class AirlineSystem {
    vector<Flight> flights;

public:
    void addFlight(int id, const string& destination) {
        flights.push_back({ id, destination });
    }
    
    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int id, const string& newDestination) {
        for (auto& flight : flights) {
            if (flight.id == id) {
                flight.destination = newDestination;
                break;
            }
        }
    }

    void searchFlight(int id) const {
        for (const auto& flight : flights) {
            if (flight.id == id) {
                cout << "Flight ID: " << flight.id << ", Destination: " << flight.destination << endl;
                cout << "Passengers:" << endl;
                for (const auto& passenger : flight.passengers) {
                    cout << "ID: " << passenger.id << ", Name: " << passenger.name << endl;
                }
                return;
            }
        }
        cout << "Flight not found" << endl;
    }

    void displayFlights() const {
        for (const auto& flight : flights) {
            cout << "Flight ID: " << flight.id << ", Destination: " << flight.destination << endl;
        }
    }

    void addPassenger(int flightId, int passengerId, const string& passengerName) {
        for (auto& flight : flights) {
            if (flight.id == flightId) {
                flight.passengers.push_back({ passengerId, passengerName });
                break;
            }
        }
    }

    void deletePassenger(int flightId, int passengerId) {
        for (auto& flight : flights) {
            if (flight.id == flightId) {
                for (auto it = flight.passengers.begin(); it != flight.passengers.end(); ++it) {
                    if (it->id == passengerId) {
                        flight.passengers.erase(it);
                        return;
                    }
                }
            }
        }
    }

    void updatePassenger(int flightId, int passengerId, const string& newName) {
        for (auto& flight : flights) {
            if (flight.id == flightId) {
                for (auto& passenger : flight.passengers) {
                    if (passenger.id == passengerId) {
                        passenger.name = newName;
                        return;
                    }
                }
            }
        }
    }

    void searchPassenger(int flightId, int passengerId) const {
        for (const auto& flight : flights) {
            if (flight.id == flightId) {
                for (const auto& passenger : flight.passengers) {
                    if (passenger.id == passengerId) {
                        cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << endl;
                        return;
                    }
                }
            }
        }
        cout << "Passenger not found" << endl;
    }

    void displayPassengers(int flightId) const {
        for (const auto& flight : flights) {
            if (flight.id == flightId) {
                cout << "Passengers in Flight ID: " << flight.id << endl;
                for (const auto& passenger : flight.passengers) {
                    cout << "ID: " << passenger.id << ", Name: " << passenger.name << endl;
                }
                return;
            }
        }
        cout << "Flight not found" << endl;
    }
};

int main() {
    AirlineSystem system;

    system.addFlight(101, "New York");
    system.addFlight(102, "Los Angeles");

    system.addPassenger(101, 1, "John Doe");
    system.addPassenger(101, 2, "Jane Smith");

    system.displayFlights();
    system.searchFlight(101);

    system.updatePassenger(101, 1, "Johnny Doe");
    system.searchPassenger(101, 1);

    system.deletePassenger(101, 2);
    system.displayPassengers(101);

    system.deleteFlight(102);
    system.displayFlights();

    return 0;
}