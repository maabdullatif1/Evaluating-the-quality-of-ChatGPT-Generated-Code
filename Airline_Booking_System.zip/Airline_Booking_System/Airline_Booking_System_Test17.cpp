#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Passenger {
public:
    int id;
    string name;

    Passenger(int pid, string pname) : id(pid), name(pname) {}
};

class Flight {
public:
    int id;
    string destination;

    Flight(int fid, string fdestination) : id(fid), destination(fdestination) {}
};

class AirlineBookingSystem {
private:
    vector<Passenger> passengers;
    vector<Flight> flights;

public:
    void addPassenger(int id, string name) {
        passengers.push_back(Passenger(id, name));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, string newName) {
        for (auto &p : passengers) {
            if (p.id == id) {
                p.name = newName;
                break;
            }
        }
    }

    void searchPassenger(int id) {
        for (auto &p : passengers) {
            if (p.id == id) {
                cout << "Passenger ID: " << p.id << ", Name: " << p.name << endl;
                return;
            }
        }
        cout << "Passenger not found." << endl;
    }

    void displayPassengers() {
        for (auto &p : passengers) {
            cout << "Passenger ID: " << p.id << ", Name: " << p.name << endl;
        }
    }

    void addFlight(int id, string destination) {
        flights.push_back(Flight(id, destination));
    }

    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int id, string newDestination) {
        for (auto &f : flights) {
            if (f.id == id) {
                f.destination = newDestination;
                break;
            }
        }
    }

    void searchFlight(int id) {
        for (auto &f : flights) {
            if (f.id == id) {
                cout << "Flight ID: " << f.id << ", Destination: " << f.destination << endl;
                return;
            }
        }
        cout << "Flight not found." << endl;
    }

    void displayFlights() {
        for (auto &f : flights) {
            cout << "Flight ID: " << f.id << ", Destination: " << f.destination << endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;

    system.addPassenger(1, "John Doe");
    system.addPassenger(2, "Jane Doe");
    system.addFlight(101, "New York");
    system.addFlight(102, "Los Angeles");

    system.displayPassengers();
    system.displayFlights();

    system.searchPassenger(1);
    system.searchFlight(102);

    system.updatePassenger(2, "Jane Smith");
    system.updateFlight(101, "Chicago");

    system.displayPassengers();
    system.displayFlights();

    system.deletePassenger(1);
    system.deleteFlight(102);

    system.displayPassengers();
    system.displayFlights();

    return 0;
}