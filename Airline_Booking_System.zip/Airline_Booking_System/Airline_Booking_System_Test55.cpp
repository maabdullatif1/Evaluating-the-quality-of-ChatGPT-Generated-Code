#include <iostream>
#include <vector>
#include <string>

struct Passenger {
    int id;
    std::string name;
};

struct Flight {
    int flightNumber;
    std::string destination;
};

class AirlineSystem {
private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(int id, std::string name) {
        passengers.push_back({id, name});
    }
    
    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }
    
    void updatePassenger(int id, std::string newName) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = newName;
                break;
            }
        }
    }
    
    void searchPassenger(int id) {
        for (const auto &passenger : passengers) {
            if (passenger.id == id) {
                std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << '\n';
                return;
            }
        }
        std::cout << "Passenger not found\n";
    }
    
    void displayPassengers() {
        for (const auto &passenger : passengers) {
            std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << '\n';
        }
    }
    
    void addFlight(int flightNumber, std::string destination) {
        flights.push_back({flightNumber, destination});
    }
    
    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }
    
    void updateFlight(int flightNumber, std::string newDestination) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = newDestination;
                break;
            }
        }
    }
    
    void searchFlight(int flightNumber) {
        for (const auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << '\n';
                return;
            }
        }
        std::cout << "Flight not found\n";
    }
    
    void displayFlights() {
        for (const auto &flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << '\n';
        }
    }
};

int main() {
    AirlineSystem system;
    system.addPassenger(1, "John Doe");
    system.addPassenger(2, "Jane Smith");
    
    system.addFlight(101, "New York");
    system.addFlight(202, "Los Angeles");
    
    system.displayPassengers();
    system.displayFlights();
    
    system.searchPassenger(1);
    system.searchFlight(101);
    
    system.updatePassenger(1, "Johnny Doe");
    system.updateFlight(101, "San Francisco");
    
    system.displayPassengers();
    system.displayFlights();
    
    system.deletePassenger(1);
    system.deleteFlight(202);
    
    system.displayPassengers();
    system.displayFlights();

    return 0;
}