#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    std::string name;
    int id;

    Passenger(std::string n, int i) : name(n), id(i) {}
};

class Flight {
public:
    std::string flightNumber;
    std::string destination;
    std::vector<Passenger> passengers;

    Flight(std::string fn, std::string dest) 
        : flightNumber(fn), destination(dest) {}

    void addPassenger(const Passenger& p) {
        passengers.push_back(p);
    }
    
    void removePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                return;
            }
        }
    }
    
    void updatePassenger(int id, const std::string& newName) {
        for (auto& p : passengers) {
            if (p.id == id) {
                p.name = newName;
                return;
            }
        }
    }
    
    Passenger* searchPassenger(int id) {
        for (auto& p : passengers) {
            if (p.id == id) {
                return &p;
            }
        }
        return nullptr;
    }

    void display() {
        std::cout << "Flight: " << flightNumber << " to " << destination << "\n";
        for (const auto& p : passengers) {
            std::cout << "Passenger ID: " << p.id << " Name: " << p.name << "\n";
        }
    }
};

class AirlineSystem {
public:
    std::vector<Flight> flights;

    void addFlight(const Flight& f) {
        flights.push_back(f);
    }

    void removeFlight(const std::string& flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                return;
            }
        }
    }

    Flight* searchFlight(const std::string& flightNumber) {
        for (auto& f : flights) {
            if (f.flightNumber == flightNumber) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto& f : flights) {
            f.display();
        }
    }
};

int main() {
    AirlineSystem system;

    Flight flight1("AA123", "New York");
    flight1.addPassenger(Passenger("John Doe", 1));
    flight1.addPassenger(Passenger("Jane Smith", 2));

    system.addFlight(flight1);

    system.displayFlights();
    
    Flight* flight = system.searchFlight("AA123");
    if (flight) {
        flight->addPassenger(Passenger("Alice Brown", 3));
    }
    
    system.displayFlights();
    
    if (flight) {
        flight->updatePassenger(2, "Jane Doe");
        flight->removePassenger(1);
    }
    
    system.displayFlights();

    return 0;
}