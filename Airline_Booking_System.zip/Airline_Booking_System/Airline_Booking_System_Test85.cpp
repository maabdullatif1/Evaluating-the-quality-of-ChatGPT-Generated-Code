#include <iostream>
#include <vector>
#include <string>

struct Passenger {
    int id;
    std::string name;
    std::string passport_number;
    std::string flight_number;
};

struct Flight {
    std::string flight_number;
    std::string origin;
    std::string destination;
    std::string departure_time;
    std::string arrival_time;
};

class AirlineBookingSystem {
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(int id, const std::string& name, const std::string& passport_number, const std::string& flight_number) {
        passengers.push_back({id, name, passport_number, flight_number});
    }

    void addFlight(const std::string& flight_number, const std::string& origin, const std::string& destination,
                   const std::string& departure_time, const std::string& arrival_time) {
        flights.push_back({flight_number, origin, destination, departure_time, arrival_time});
    }

    bool deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                return true;
            }
        }
        return false;
    }

    bool deleteFlight(const std::string& flight_number) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flight_number == flight_number) {
                flights.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updatePassenger(int id, const std::string& name, const std::string& passport_number, const std::string& flight_number) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.passport_number = passport_number;
                passenger.flight_number = flight_number;
                return true;
            }
        }
        return false;
    }

    bool updateFlight(const std::string& flight_number, const std::string& origin, const std::string& destination,
                      const std::string& departure_time, const std::string& arrival_time) {
        for (auto& flight : flights) {
            if (flight.flight_number == flight_number) {
                flight.origin = origin;
                flight.destination = destination;
                flight.departure_time = departure_time;
                flight.arrival_time = arrival_time;
                return true;
            }
        }
        return false;
    }

    void searchPassenger(int id) const {
        for (const auto& passenger : passengers) {
            if (passenger.id == id) {
                std::cout << "Passenger ID: " << passenger.id << "\nName: " << passenger.name 
                          << "\nPassport Number: " << passenger.passport_number 
                          << "\nFlight Number: " << passenger.flight_number << "\n";
                return;
            }
        }
        std::cout << "Passenger not found.\n";
    }

    void searchFlight(const std::string& flight_number) const {
        for (const auto& flight : flights) {
            if (flight.flight_number == flight_number) {
                std::cout << "Flight Number: " << flight.flight_number 
                          << "\nOrigin: " << flight.origin 
                          << "\nDestination: " << flight.destination 
                          << "\nDeparture Time: " << flight.departure_time 
                          << "\nArrival Time: " << flight.arrival_time << "\n";
                return;
            }
        }
        std::cout << "Flight not found.\n";
    }

    void displayPassengers() const {
        for (const auto& passenger : passengers) {
            std::cout << "ID: " << passenger.id << ", Name: " << passenger.name 
                      << ", Passport No: " << passenger.passport_number 
                      << ", Flight No: " << passenger.flight_number << "\n";
        }
    }

    void displayFlights() const {
        for (const auto& flight : flights) {
            std::cout << "Flight No: " << flight.flight_number << ", Origin: " << flight.origin 
                      << ", Destination: " << flight.destination 
                      << ", Departure: " << flight.departure_time 
                      << ", Arrival: " << flight.arrival_time << "\n";
        }
    }
};

int main() {
    AirlineBookingSystem system;

    system.addPassenger(1, "John Doe", "AB123456", "FL123");
    system.addPassenger(2, "Jane Smith", "CD789012", "FL124");
    system.addFlight("FL123", "New York", "London", "10:00", "22:00");
    system.addFlight("FL124", "Los Angeles", "Tokyo", "12:00", "16:00");

    system.displayPassengers();
    system.displayFlights();

    system.searchPassenger(1);
    system.searchFlight("FL123");

    system.updatePassenger(1, "John Doe Updated", "AB123456", "FL123");
    system.updateFlight("FL123", "New York", "London", "11:00", "23:00");

    system.displayPassengers();
    system.displayFlights();

    system.deletePassenger(2);
    system.deleteFlight("FL124");

    system.displayPassengers();
    system.displayFlights();

    return 0;
}