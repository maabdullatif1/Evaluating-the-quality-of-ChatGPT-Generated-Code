#include <iostream>
#include <vector>
#include <string>

struct Passenger {
    int id;
    std::string name;
};

struct Flight {
    int flightNumber;
    std::string destination;
    std::vector<Passenger> passengers;
};

class AirlineBookingSystem {
private:
    std::vector<Flight> flights;
    int passengerCounter = 0;

    Flight* findFlight(int flightNumber) {
        for(auto& flight : flights)
            if(flight.flightNumber == flightNumber) return &flight;
        return nullptr;
    }

public:
    void addFlight(int flightNumber, const std::string& destination) {
        flights.push_back({flightNumber, destination, {}});
    }

    void deleteFlight(int flightNumber) {
        flights.erase(std::remove_if(flights.begin(), flights.end(), [flightNumber](const Flight& f) {
            return f.flightNumber == flightNumber;
        }), flights.end());
    }

    void updateFlight(int flightNumber, const std::string& newDestination) {
        Flight* flight = findFlight(flightNumber);
        if(flight) flight->destination = newDestination;
    }

    void addPassenger(int flightNumber, const std::string& name) {
        Flight* flight = findFlight(flightNumber);
        if(flight)
            flight->passengers.push_back({++passengerCounter, name});
    }

    void deletePassenger(int flightNumber, int passengerId) {
        Flight* flight = findFlight(flightNumber);
        if(flight)
            flight->passengers.erase(std::remove_if(flight->passengers.begin(), flight->passengers.end(), [passengerId](const Passenger& p) {
                return p.id == passengerId;
            }), flight->passengers.end());
    }

    Passenger* searchPassenger(int flightNumber, int passengerId) {
        Flight* flight = findFlight(flightNumber);
        if(flight) {
            for(auto& passenger : flight->passengers)
                if(passenger.id == passengerId) return &passenger;
        }
        return nullptr;
    }

    void displayFlights() {
        for(const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << "\n";
            for(const auto& passenger : flight.passengers) {
                std::cout << "  Passenger ID: " << passenger.id << ", Name: " << passenger.name << "\n";
            }
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addFlight(101, "New York");
    system.addPassenger(101, "John Doe");
    system.addPassenger(101, "Jane Smith");
    system.displayFlights();
    system.updateFlight(101, "Los Angeles");
    Passenger* p = system.searchPassenger(101, 1);
    if(p) std::cout << "Found Passenger: " << p->name << "\n";
    system.deletePassenger(101, 1);
    system.displayFlights();
    system.deleteFlight(101);
    system.displayFlights();
    return 0;
}