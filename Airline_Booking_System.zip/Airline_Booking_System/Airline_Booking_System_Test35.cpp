#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Passenger {
    int id;
    string name;
    string passport;
};

struct Flight {
    int id;
    string destination;
    int capacity;
};

class AirlineBookingSystem {
private:
    vector<Passenger> passengers;
    vector<Flight> flights;

    int findPassengerIndex(int id) {
        for (size_t i = 0; i < passengers.size(); i++) {
            if (passengers[i].id == id) return i;
        }
        return -1;
    }

    int findFlightIndex(int id) {
        for (size_t i = 0; i < flights.size(); i++) {
            if (flights[i].id == id) return i;
        }
        return -1;
    }

public:
    void addPassenger(int id, string name, string passport) {
        Passenger p = {id, name, passport};
        passengers.push_back(p);
    }

    void deletePassenger(int id) {
        int index = findPassengerIndex(id);
        if (index != -1) passengers.erase(passengers.begin() + index);
    }

    void updatePassenger(int id, string name, string passport) {
        int index = findPassengerIndex(id);
        if (index != -1) {
            passengers[index].name = name;
            passengers[index].passport = passport;
        }
    }

    void searchPassenger(int id) {
        int index = findPassengerIndex(id);
        if (index != -1) {
            cout << "Passenger found: " << passengers[index].name << ", " << passengers[index].passport << endl;
        } else {
            cout << "Passenger not found" << endl;
        }
    }

    void displayPassengers() {
        for (const auto& p : passengers) {
            cout << p.id << ": " << p.name << ", " << p.passport << endl;
        }
    }

    void addFlight(int id, string destination, int capacity) {
        Flight f = {id, destination, capacity};
        flights.push_back(f);
    }

    void deleteFlight(int id) {
        int index = findFlightIndex(id);
        if (index != -1) flights.erase(flights.begin() + index);
    }

    void updateFlight(int id, string destination, int capacity) {
        int index = findFlightIndex(id);
        if (index != -1) {
            flights[index].destination = destination;
            flights[index].capacity = capacity;
        }
    }

    void searchFlight(int id) {
        int index = findFlightIndex(id);
        if (index != -1) {
            cout << "Flight found: " << flights[index].destination << ", " << flights[index].capacity << endl;
        } else {
            cout << "Flight not found" << endl;
        }
    }

    void displayFlights() {
        for (const auto& f : flights) {
            cout << f.id << ": " << f.destination << ", " << f.capacity << endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;

    system.addPassenger(1, "John Doe", "A123456");
    system.addPassenger(2, "Jane Smith", "B654321");
    system.displayPassengers();
    
    system.addFlight(101, "New York", 180);
    system.addFlight(102, "London", 220);
    system.displayFlights();
    
    system.searchPassenger(1);
    system.updatePassenger(1, "John D", "A123456X");
    system.searchPassenger(1);
    
    system.searchFlight(101);
    system.updateFlight(101, "New York JFK", 185);
    system.searchFlight(101);
    
    system.deletePassenger(2);
    system.displayPassengers();
    
    system.deleteFlight(102);
    system.displayFlights();

    return 0;
}