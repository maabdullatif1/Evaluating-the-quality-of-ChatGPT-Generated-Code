#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    std::string name;
    int id;
    Passenger(std::string nm, int i) : name(nm), id(i) {}
};

class Flight {
public:
    std::string destination;
    int flightNumber;
    std::vector<Passenger> passengers;
    Flight(std::string dest, int fn) : destination(dest), flightNumber(fn) {}

    void addPassenger(const Passenger& p) {
        passengers.push_back(p);
    }

    void deletePassenger(int passengerId) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == passengerId) {
                passengers.erase(it);
                break;
            }
        }
    }

    Passenger* searchPassenger(int passengerId) {
        for (auto& passenger : passengers) {
            if (passenger.id == passengerId) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << std::endl;
        }
    }
};

class AirlineBookingSystem {
public:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

    void addPassenger(const std::string& name, int id) {
        passengers.emplace_back(name, id);
    }

    void deletePassenger(int passengerId) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == passengerId) {
                passengers.erase(it);
                break;
            }
        }
    }

    Passenger* searchPassenger(int passengerId) {
        for (auto& passenger : passengers) {
            if (passenger.id == passengerId) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << std::endl;
        }
    }

    void addFlight(const std::string& destination, int flightNumber) {
        flights.emplace_back(destination, flightNumber);
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << std::endl;
            flight.displayPassengers();
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger("John Doe", 1);
    system.addPassenger("Jane Smith", 2);
    system.addFlight("New York", 101);
    system.addFlight("Los Angeles", 102);

    system.flights[0].addPassenger(system.passengers[0]);
    system.flights[1].addPassenger(system.passengers[1]);
    
    system.displayFlights();
    
    system.flights[0].deletePassenger(1);
    system.deletePassenger(2);
    system.displayFlights();

    return 0;
}