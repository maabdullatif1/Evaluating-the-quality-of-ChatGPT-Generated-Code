#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Passenger {
    int passengerID;
    string name;
    string email;
};

struct Flight {
    int flightID;
    string origin;
    string destination;
    vector<Passenger> passengers;
};

class AirlineBookingSystem {
    vector<Flight> flights;
    int passengerCounter, flightCounter;

public:
    AirlineBookingSystem() : passengerCounter(0), flightCounter(0) {}

    int addPassenger(const string& name, const string& email) {
        Passenger newPassenger = { ++passengerCounter, name, email };
        return newPassenger.passengerID;
    }

    int addFlight(const string& origin, const string& destination) {
        Flight newFlight = { ++flightCounter, origin, destination };
        flights.push_back(newFlight);
        return newFlight.flightID;
    }

    bool deleteFlight(int flightID) {
        for (size_t i = 0; i < flights.size(); ++i) {
            if (flights[i].flightID == flightID) {
                flights.erase(flights.begin() + i);
                return true;
            }
        }
        return false;
    }

    bool updateFlight(int flightID, const string& newOrigin, const string& newDestination) {
        for (auto& flight : flights) {
            if (flight.flightID == flightID) {
                flight.origin = newOrigin;
                flight.destination = newDestination;
                return true;
            }
        }
        return false;
    }

    bool searchFlight(int flightID, Flight& result) {
        for (const auto& flight : flights) {
            if (flight.flightID == flightID) {
                result = flight;
                return true;
            }
        }
        return false;
    }

    bool addPassengerToFlight(int flightID, const Passenger& passenger) {
        for (auto& flight : flights) {
            if (flight.flightID == flightID) {
                flight.passengers.push_back(passenger);
                return true;
            }
        }
        return false;
    }

    bool deletePassengerFromFlight(int flightID, int passengerID) {
        for (auto& flight : flights) {
            if (flight.flightID == flightID) {
                for (size_t i = 0; i < flight.passengers.size(); ++i) {
                    if (flight.passengers[i].passengerID == passengerID) {
                        flight.passengers.erase(flight.passengers.begin() + i);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    void displayFlightInfo(int flightID) {
        Flight flight;
        if (searchFlight(flightID, flight)) {
            cout << "Flight ID: " << flight.flightID << ", Origin: " << flight.origin 
                 << ", Destination: " << flight.destination << "\nPassengers:\n";
            for (const auto& passenger : flight.passengers) {
                cout << "Passenger ID: " << passenger.passengerID 
                     << ", Name: " << passenger.name 
                     << ", Email: " << passenger.email << '\n';
            }
        } else {
            cout << "Flight not found.\n";
        }
    }

    void displayAllFlights() {
        for (const auto& flight : flights) {
            displayFlightInfo(flight.flightID);
        }
    }
};

int main() {
    AirlineBookingSystem system;
    int flightID = system.addFlight("New York", "Los Angeles");
    int passengerID = system.addPassenger("John Doe", "john@example.com");
    system.addPassengerToFlight(flightID, {passengerID, "John Doe", "john@example.com"});
    system.displayAllFlights();
    return 0;
}