#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;

    Passenger(int i, std::string n, std::string p) : id(i), name(n), passportNumber(p) {}
};

class Flight {
public:
    int id;
    std::string origin;
    std::string destination;
    int seats;

    Flight(int i, std::string o, std::string d, int s) : id(i), origin(o), destination(d), seats(s) {}
};

class AirlineBookingSystem {
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(int id, std::string name, std::string passportNumber) {
        passengers.emplace_back(id, name, passportNumber);
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, std::string name, std::string passportNumber) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.passportNumber = passportNumber;
                break;
            }
        }
    }

    void searchPassenger(int id) {
        for (const auto& passenger : passengers) {
            if (passenger.id == id) {
                std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name 
                          << ", Passport Number: " << passenger.passportNumber << std::endl;
                return;
            }
        }
        std::cout << "Passenger not found." << std::endl;
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name 
                      << ", Passport Number: " << passenger.passportNumber << std::endl;
        }
    }

    void addFlight(int id, std::string origin, std::string destination, int seats) {
        flights.emplace_back(id, origin, destination, seats);
    }

    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int id, std::string origin, std::string destination, int seats) {
        for (auto& flight : flights) {
            if (flight.id == id) {
                flight.origin = origin;
                flight.destination = destination;
                flight.seats = seats;
                break;
            }
        }
    }

    void searchFlight(int id) {
        for (const auto& flight : flights) {
            if (flight.id == id) {
                std::cout << "Flight ID: " << flight.id << ", Origin: " << flight.origin 
                          << ", Destination: " << flight.destination << ", Seats: " << flight.seats << std::endl;
                return;
            }
        }
        std::cout << "Flight not found." << std::endl;
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            std::cout << "Flight ID: " << flight.id << ", Origin: " << flight.origin 
                      << ", Destination: " << flight.destination << ", Seats: " << flight.seats << std:: endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "John Doe", "AB123456");
    system.addPassenger(2, "Jane Smith", "CD789012");
    system.addFlight(1, "New York", "Los Angeles", 150);
    system.displayPassengers();
    system.displayFlights();
    system.searchPassenger(1);
    system.searchFlight(1);
    system.updatePassenger(1, "John Doe", "XY987654");
    system.updateFlight(1, "New York", "San Francisco", 130);
    system.displayPassengers();
    system.displayFlights();
    system.deletePassenger(2);
    system.deleteFlight(1);
    system.displayPassengers();
    system.displayFlights();
    return 0;
}