```cpp
#include <iostream>
#include <vector>
#include <string>

struct Passenger {
    int id;
    std::string name;
};

struct Flight {
    int number;
    std::string destination;
};

class AirlineBookingSystem {
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(int id, const std::string& name) {
        passengers.push_back({id, name});
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, const std::string& newName) {
        for (auto& passenger : passengers) {