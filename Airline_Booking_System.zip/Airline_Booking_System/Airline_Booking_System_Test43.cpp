#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Passenger {
public:
    int id;
    string name;
    string passport;

    Passenger(int id, string name, string passport)
        : id(id), name(name), passport(passport) {}
};

class Flight {
public:
    int id;
    string destination;
    string date;

    Flight(int id, string destination, string date)
        : id(id), destination(destination), date(date) {}
};

class AirlineBookingSystem {
    vector<Passenger> passengers;
    vector<Flight> flights;

public:
    void addPassenger(int id, string name, string passport) {
        passengers.push_back(Passenger(id, name, passport));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, string name, string passport) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.passport = passport;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto &passenger : passengers) {
            cout << "ID: " << passenger.id << ", Name: " << passenger.name
                 << ", Passport: " << passenger.passport << endl;
        }
    }

    void addFlight(int id, string destination, string date) {
        flights.push_back(Flight(id, destination, date));
    }

    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int id, string destination, string date) {
        for (auto &flight : flights) {
            if (flight.id == id) {
                flight.destination = destination;
                flight.date = date;
                break;
            }
        }
    }

    Flight* searchFlight(int id) {
        for (auto &flight : flights) {
            if (flight.id == id) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto &flight : flights) {
            cout << "ID: " << flight.id << ", Destination: " << flight.destination
                 << ", Date: " << flight.date << endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "John Doe", "P123456");
    system.addPassenger(2, "Jane Smith", "P654321");
    system.displayPassengers();

    system.addFlight(101, "New York", "2023-10-15");
    system.addFlight(102, "Los Angeles", "2023-11-25");
    system.displayFlights();

    system.updatePassenger(2, "Jane Doe", "P111111");
    system.displayPassengers();

    system.deleteFlight(101);
    system.displayFlights();

    Passenger* passenger = system.searchPassenger(1);
    if (passenger) {
        cout << "Found: " << passenger->name << endl;
    }

    Flight* flight = system.searchFlight(102);
    if (flight) {
        cout << "Found: " << flight->destination << endl;
    }

    return 0;
}