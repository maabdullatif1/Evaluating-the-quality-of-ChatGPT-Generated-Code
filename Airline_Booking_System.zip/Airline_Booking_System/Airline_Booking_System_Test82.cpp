#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Passenger {
    int id;
    string name;
    string passportNumber;
};

struct Flight {
    int flightNumber;
    string origin;
    string destination;
};

vector<Passenger> passengers;
vector<Flight> flights;

void addPassenger(int id, const string& name, const string& passportNumber) {
    passengers.push_back({id, name, passportNumber});
}

void deletePassenger(int id) {
    for (auto it = passengers.begin(); it != passengers.end(); ++it) {
        if (it->id == id) {
            passengers.erase(it);
            break;
        }
    }
}

void updatePassenger(int id, const string& name, const string& passportNumber) {
    for (auto& passenger : passengers) {
        if (passenger.id == id) {
            passenger.name = name;
            passenger.passportNumber = passportNumber;
            break;
        }
    }
}

Passenger* searchPassenger(int id) {
    for (auto& passenger : passengers) {
        if (passenger.id == id) {
            return &passenger;
        }
    }
    return nullptr;
}

void displayPassengers() {
    for (const auto& passenger : passengers) {
        cout << "ID: " << passenger.id << ", Name: " << passenger.name 
             << ", Passport Number: " << passenger.passportNumber << endl;
    }
}

void addFlight(int flightNumber, const string& origin, const string& destination) {
    flights.push_back({flightNumber, origin, destination});
}

void deleteFlight(int flightNumber) {
    for (auto it = flights.begin(); it != flights.end(); ++it) {
        if (it->flightNumber == flightNumber) {
            flights.erase(it);
            break;
        }
    }
}

void updateFlight(int flightNumber, const string& origin, const string& destination) {
    for (auto& flight : flights) {
        if (flight.flightNumber == flightNumber) {
            flight.origin = origin;
            flight.destination = destination;
            break;
        }
    }
}

Flight* searchFlight(int flightNumber) {
    for (auto& flight : flights) {
        if (flight.flightNumber == flightNumber) {
            return &flight;
        }
    }
    return nullptr;
}

void displayFlights() {
    for (const auto& flight : flights) {
        cout << "Flight Number: " << flight.flightNumber << ", Origin: " << flight.origin 
             << ", Destination: " << flight.destination << endl;
    }
}

int main() {
    addPassenger(1, "John Doe", "AB12345");
    addPassenger(2, "Jane Smith", "XY67890");
    addFlight(101, "New York", "Los Angeles");
    addFlight(202, "Chicago", "Miami");
    
    displayPassengers();
    displayFlights();
    
    Passenger* passenger = searchPassenger(1);
    if (passenger) {
        cout << "Found Passenger: " << passenger->name << endl;
    }
    
    Flight* flight = searchFlight(101);
    if (flight) {
        cout << "Found Flight: " << flight->flightNumber << endl;
    }
    
    updatePassenger(1, "Johnathan Doe", "AB12345");
    updateFlight(101, "New York", "San Francisco");
    
    displayPassengers();
    displayFlights();
    
    deletePassenger(2);
    deleteFlight(202);
    
    displayPassengers();
    displayFlights();
    
    return 0;
}