#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Passenger {
public:
    int id;
    string name;
    string flightID;
    
    Passenger(int id, string name, string flightID) : id(id), name(name), flightID(flightID) {}
};

class Flight {
public:
    string id;
    string destination;
    
    Flight(string id, string destination) : id(id), destination(destination) {}
};

class AirlineBookingSystem {
    vector<Passenger> passengers;
    vector<Flight> flights;

public:
    void addPassenger(int id, string name, string flightID) {
        passengers.push_back(Passenger(id, name, flightID));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                return;
            }
        }
    }

    void updatePassenger(int id, string newName, string newFlightID) {
        for (auto& p : passengers) {
            if (p.id == id) {
                p.name = newName;
                p.flightID = newFlightID;
                return;
            }
        }
    }

    void searchPassenger(int id) {
        for (const auto& p : passengers) {
            if (p.id == id) {
                cout << "Passenger ID: " << p.id << ", Name: " << p.name << ", Flight ID: " << p.flightID << endl;
                return;
            }
        }
        cout << "Passenger not found" << endl;
    }

    void displayPassengers() {
        for (const auto& p : passengers) {
            cout << "Passenger ID: " << p.id << ", Name: " << p.name << ", Flight ID: " << p.flightID << endl;
        }
    }

    void addFlight(string id, string destination) {
        flights.push_back(Flight(id, destination));
    }

    void deleteFlight(string id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                return;
            }
        }
    }

    void updateFlight(string id, string newDestination) {
        for (auto& f : flights) {
            if (f.id == id) {
                f.destination = newDestination;
                return;
            }
        }
    }

    void searchFlight(string id) {
        for (const auto& f : flights) {
            if (f.id == id) {
                cout << "Flight ID: " << f.id << ", Destination: " << f.destination << endl;
                return;
            }
        }
        cout << "Flight not found" << endl;
    }

    void displayFlights() {
        for (const auto& f : flights) {
            cout << "Flight ID: " << f.id << ", Destination: " << f.destination << endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;
    
    system.addFlight("F001", "New York");
    system.addFlight("F002", "Los Angeles");
    system.displayFlights();
    
    system.addPassenger(1, "Alice", "F001");
    system.addPassenger(2, "Bob", "F002");
    system.displayPassengers();
    
    system.updatePassenger(1, "Alice Johnson", "F002");
    system.displayPassengers();
    
    system.searchPassenger(1);
    
    system.deletePassenger(1);
    system.displayPassengers();
    
    return 0;
}