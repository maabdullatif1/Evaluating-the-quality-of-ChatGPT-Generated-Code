#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Passenger {
    int id;
    string name;
};

struct Flight {
    int id;
    string origin;
    string destination;
};

vector<Passenger> passengers;
vector<Flight> flights;

void addPassenger(int id, string name) {
    passengers.push_back({id, name});
}

void deletePassenger(int id) {
    for (auto it = passengers.begin(); it != passengers.end(); ++it) {
        if (it->id == id) {
            passengers.erase(it);
            break;
        }
    }
}

void updatePassenger(int id, string name) {
    for (auto &passenger : passengers) {
        if (passenger.id == id) {
            passenger.name = name;
            break;
        }
    }
}

void searchPassenger(int id) {
    for (const auto &passenger : passengers) {
        if (passenger.id == id) {
            cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << endl;
            return;
        }
    }
    cout << "Passenger not found" << endl;
}

void displayPassengers() {
    for (const auto &passenger : passengers) {
        cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << endl;
    }
}

void addFlight(int id, string origin, string destination) {
    flights.push_back({id, origin, destination});
}

void deleteFlight(int id) {
    for (auto it = flights.begin(); it != flights.end(); ++it) {
        if (it->id == id) {
            flights.erase(it);
            break;
        }
    }
}

void updateFlight(int id, string origin, string destination) {
    for (auto &flight : flights) {
        if (flight.id == id) {
            flight.origin = origin;
            flight.destination = destination;
            break;
        }
    }
}

void searchFlight(int id) {
    for (const auto &flight : flights) {
        if (flight.id == id) {
            cout << "Flight ID: " << flight.id << ", Origin: " << flight.origin << ", Destination: " << flight.destination << endl;
            return;
        }
    }
    cout << "Flight not found" << endl;
}

void displayFlights() {
    for (const auto &flight : flights) {
        cout << "Flight ID: " << flight.id << ", Origin: " << flight.origin << ", Destination: " << flight.destination << endl;
    }
}

int main() {
    addPassenger(1, "John Doe");
    addPassenger(2, "Jane Smith");
    addFlight(101, "New York", "Los Angeles");
    addFlight(102, "Chicago", "Miami");

    displayPassengers();
    displayFlights();

    searchPassenger(1);
    searchFlight(101);

    updatePassenger(1, "John A. Doe");
    updateFlight(102, "Houston", "Dallas");

    displayPassengers();
    displayFlights();

    deletePassenger(2);
    deleteFlight(101);

    displayPassengers();
    displayFlights();

    return 0;
}