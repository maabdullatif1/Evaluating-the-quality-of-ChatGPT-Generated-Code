#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Passenger {
    int id;
    string name;
};

struct Flight {
    int flightNumber;
    string destination;
    string departureTime;
};

vector<Passenger> passengers;
vector<Flight> flights;

void addPassenger(int id, string name) {
    passengers.push_back({id, name});
}

void deletePassenger(int id) {
    for (auto it = passengers.begin(); it != passengers.end(); ++it) {
        if (it->id == id) {
            passengers.erase(it);
            break;
        }
    }
}

void updatePassenger(int id, string newName) {
    for (auto &passenger : passengers) {
        if (passenger.id == id) {
            passenger.name = newName;
            break;
        }
    }
}

void searchPassenger(int id) {
    for (const auto &passenger : passengers) {
        if (passenger.id == id) {
            cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << endl;
            return;
        }
    }
    cout << "Passenger not found." << endl;
}

void displayPassengers() {
    for (const auto &passenger : passengers) {
        cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << endl;
    }
}

void addFlight(int flightNumber, string destination, string departureTime) {
    flights.push_back({flightNumber, destination, departureTime});
}

void deleteFlight(int flightNumber) {
    for (auto it = flights.begin(); it != flights.end(); ++it) {
        if (it->flightNumber == flightNumber) {
            flights.erase(it);
            break;
        }
    }
}

void updateFlight(int flightNumber, string newDestination, string newDepartureTime) {
    for (auto &flight : flights) {
        if (flight.flightNumber == flightNumber) {
            flight.destination = newDestination;
            flight.departureTime = newDepartureTime;
            break;
        }
    }
}

void searchFlight(int flightNumber) {
    for (const auto &flight : flights) {
        if (flight.flightNumber == flightNumber) {
            cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << ", Departure Time: " << flight.departureTime << endl;
            return;
        }
    }
    cout << "Flight not found." << endl;
}

void displayFlights() {
    for (const auto &flight : flights) {
        cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << ", Departure Time: " << flight.departureTime << endl;
    }
}

int main() {
    addPassenger(1, "John Doe");
    addPassenger(2, "Jane Doe");
    displayPassengers();

    addFlight(101, "New York", "10:00 AM");
    addFlight(102, "Los Angeles", "2:00 PM");
    displayFlights();

    updatePassenger(1, "John Smith");
    searchPassenger(1);

    updateFlight(101, "Chicago", "11:00 AM");
    searchFlight(101);

    deletePassenger(2);
    displayPassengers();

    deleteFlight(102);
    displayFlights();

    return 0;
}