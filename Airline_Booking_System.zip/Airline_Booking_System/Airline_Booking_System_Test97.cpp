#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;
    
    Passenger(int i, const std::string& n, const std::string& p)
        : id(i), name(n), passportNumber(p) {}
};

class Flight {
public:
    int flightNumber;
    std::string origin;
    std::string destination;
    
    Flight(int fn, const std::string& o, const std::string& d)
        : flightNumber(fn), origin(o), destination(d) {}
};

class AirlineSystem {
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;
    
public:
    void addPassenger(const Passenger& p) {
        passengers.push_back(p);
    }
    
    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }
    
    void updatePassenger(int id, const std::string& name, const std::string& passport) {
        for (auto& p : passengers) {
            if (p.id == id) {
                p.name = name;
                p.passportNumber = passport;
                break;
            }
        }
    }
    
    Passenger* searchPassenger(int id) {
        for (auto& p : passengers) {
            if (p.id == id) {
                return &p;
            }
        }
        return nullptr;
    }
    
    void displayPassengers() const {
        for (const auto& p : passengers) {
            std::cout << "ID: " << p.id << ", Name: " << p.name << ", Passport: " << p.passportNumber << "\n";
        }
    }
    
    void addFlight(const Flight& f) {
        flights.push_back(f);
    }
    
    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }
    
    void updateFlight(int flightNumber, const std::string& origin, const std::string& destination) {
        for (auto& f : flights) {
            if (f.flightNumber == flightNumber) {
                f.origin = origin;
                f.destination = destination;
                break;
            }
        }
    }
    
    Flight* searchFlight(int flightNumber) {
        for (auto& f : flights) {
            if (f.flightNumber == flightNumber) {
                return &f;
            }
        }
        return nullptr;
    }
    
    void displayFlights() const {
        for (const auto& f : flights) {
            std::cout << "Flight Number: " << f.flightNumber << ", From: " << f.origin << ", To: " << f.destination << "\n";
        }
    }
};

int main() {
    AirlineSystem system;
    
    system.addPassenger(Passenger(1, "John Doe", "A12345678"));
    system.addPassenger(Passenger(2, "Jane Smith", "B87654321"));
    
    system.addFlight(Flight(101, "New York", "London"));
    system.addFlight(Flight(102, "London", "Tokyo"));
    
    system.displayPassengers();
    system.displayFlights();
    
    Passenger* p = system.searchPassenger(1);
    if (p) {
        std::cout << "Found Passenger: " << p->name << "\n";
    }
    
    Flight* f = system.searchFlight(101);
    if (f) {
        std::cout << "Found Flight: " << f->origin << " to " << f->destination << "\n";
    }
    
    system.updatePassenger(1, "Johnathan Doe", "C11223344");
    system.updateFlight(101, "Boston", "Paris");
    
    system.displayPassengers();
    system.displayFlights();
    
    system.deletePassenger(2);
    system.deleteFlight(102);
    
    system.displayPassengers();
    system.displayFlights();
    
    return 0;
}