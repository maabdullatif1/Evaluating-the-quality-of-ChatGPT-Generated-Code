#include <iostream>
#include <string>

using namespace std;

const int MAX_PASSENGERS = 100;
const int MAX_FLIGHTS = 50;

struct Passenger {
    string name;
    int age;
    string passportNumber;
};

struct Flight {
    string flightNumber;
    string destination;
    string departureTime;
};

Passenger passengers[MAX_PASSENGERS];
Flight flights[MAX_FLIGHTS];
int passengerCount = 0;
int flightCount = 0;

void addPassenger() {
    if (passengerCount >= MAX_PASSENGERS) {
        cout << "Cannot add more passengers, limit reached." << endl;
        return;
    }
    cout << "Enter passenger name: ";
    cin >> passengers[passengerCount].name;
    cout << "Enter passenger age: ";
    cin >> passengers[passengerCount].age;
    cout << "Enter passport number: ";
    cin >> passengers[passengerCount].passportNumber;
    passengerCount++;
}

void deletePassenger() {
    string passport;
    cout << "Enter passport number of passenger to delete: ";
    cin >> passport;
    bool found = false;
    for (int i = 0; i < passengerCount; i++) {
        if (passengers[i].passportNumber == passport) {
            for (int j = i; j < passengerCount - 1; j++) {
                passengers[j] = passengers[j + 1];
            }
            passengerCount--;
            found = true;
            cout << "Passenger deleted." << endl;
            break;
        }
    }
    if (!found) {
        cout << "Passenger not found." << endl;
    }
}

void updatePassenger() {
    string passport;
    cout << "Enter passport number of passenger to update: ";
    cin >> passport;
    bool found = false;
    for (int i = 0; i < passengerCount; i++) {
        if (passengers[i].passportNumber == passport) {
            cout << "Enter new name: ";
            cin >> passengers[i].name;
            cout << "Enter new age: ";
            cin >> passengers[i].age;
            found = true;
            cout << "Passenger updated." << endl;
            break;
        }
    }
    if (!found) {
        cout << "Passenger not found." << endl;
    }
}

void searchPassenger() {
    string passport;
    cout << "Enter passport number to search: ";
    cin >> passport;
    bool found = false;
    for (int i = 0; i < passengerCount; i++) {
        if (passengers[i].passportNumber == passport) {
            cout << "Name: " << passengers[i].name << ", Age: " << passengers[i].age << endl;
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "Passenger not found." << endl;
    }
}

void displayPassengers() {
    for (int i = 0; i < passengerCount; i++) {
        cout << "Name: " << passengers[i].name << ", Age: " << passengers[i].age << ", Passport: " << passengers[i].passportNumber << endl;
    }
}

void addFlight() {
    if (flightCount >= MAX_FLIGHTS) {
        cout << "Cannot add more flights, limit reached." << endl;
        return;
    }
    cout << "Enter flight number: ";
    cin >> flights[flightCount].flightNumber;
    cout << "Enter destination: ";
    cin >> flights[flightCount].destination;
    cout << "Enter departure time: ";
    cin >> flights[flightCount].departureTime;
    flightCount++;
}

void deleteFlight() {
    string flightNumber;
    cout << "Enter flight number to delete: ";
    cin >> flightNumber;
    bool found = false;
    for (int i = 0; i < flightCount; i++) {
        if (flights[i].flightNumber == flightNumber) {
            for (int j = i; j < flightCount - 1; j++) {
                flights[j] = flights[j + 1];
            }
            flightCount--;
            found = true;
            cout << "Flight deleted." << endl;
            break;
        }
    }
    if (!found) {
        cout << "Flight not found." << endl;
    }
}

void updateFlight() {
    string flightNumber;
    cout << "Enter flight number to update: ";
    cin >> flightNumber;
    bool found = false;
    for (int i = 0; i < flightCount; i++) {
        if (flights[i].flightNumber == flightNumber) {
            cout << "Enter new destination: ";
            cin >> flights[i].destination;
            cout << "Enter new departure time: ";
            cin >> flights[i].departureTime;
            found = true;
            cout << "Flight updated." << endl;
            break;
        }
    }
    if (!found) {
        cout << "Flight not found." << endl;
    }
}

void searchFlight() {
    string flightNumber;
    cout << "Enter flight number to search: ";
    cin >> flightNumber;
    bool found = false;
    for (int i = 0; i < flightCount; i++) {
        if (flights[i].flightNumber == flightNumber) {
            cout << "Flight Number: " << flights[i].flightNumber << ", Destination: " << flights[i].destination << ", Departure Time: " << flights[i].departureTime << endl;
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "Flight not found." << endl;
    }
}

void displayFlights() {
    for (int i = 0; i < flightCount; i++) {
        cout << "Flight Number: " << flights[i].flightNumber << ", Destination: " << flights[i].destination << ", Departure Time: " << flights[i].departureTime << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Passenger\n2. Delete Passenger\n3. Update Passenger\n4. Search Passenger\n5. Display Passengers\n";
        cout << "6. Add Flight\n7. Delete Flight\n8. Update Flight\n9. Search Flight\n10. Display Flights\n0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
        case 1:
            addPassenger();
            break;
        case 2:
            deletePassenger();
            break;
        case 3:
            updatePassenger();
            break;
        case 4:
            searchPassenger();
            break;
        case 5:
            displayPassengers();
            break;
        case 6:
            addFlight();
            break;
        case 7:
            deleteFlight();
            break;
        case 8:
            updateFlight();
            break;
        case 9:
            searchFlight();
            break;
        case 10:
            displayFlights();
            break;
        case 0:
            cout << "Exiting..." << endl;
            break;
        default:
            cout << "Invalid choice." << endl;
        }
    } while (choice != 0);

    return 0;
}