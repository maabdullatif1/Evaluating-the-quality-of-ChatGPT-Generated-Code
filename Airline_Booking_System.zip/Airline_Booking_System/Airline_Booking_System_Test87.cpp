#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Passenger {
public:
    string name;
    int id;
    string gender;
    int age;

    Passenger(string n, int i, string g, int a) : name(n), id(i), gender(g), age(a) {}
};

class Flight {
public:
    string flightNumber;
    string destination;
    string departure;
    vector<Passenger> passengers;

    Flight(string fn, string d, string dep) : flightNumber(fn), destination(d), departure(dep) {}

    void addPassenger(Passenger p) {
        passengers.push_back(p);
    }

    void removePassenger(int passengerId) {
        for (size_t i = 0; i < passengers.size(); ++i) {
            if (passengers[i].id == passengerId) {
                passengers.erase(passengers.begin() + i);
                break;
            }
        }
    }

    Passenger* searchPassenger(int passengerId) {
        for (auto &passenger : passengers) {
            if (passenger.id == passengerId) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto &passenger : passengers) {
            cout << "Name: " << passenger.name << ", ID: " << passenger.id
                 << ", Gender: " << passenger.gender << ", Age: " << passenger.age << endl;
        }
    }
};

class AirlineBookingSystem {
    vector<Flight> flights;

public:
    void addFlight(string flightNumber, string destination, string departure) {
        flights.emplace_back(flightNumber, destination, departure);
    }

    void removeFlight(const string &flightNumber) {
        for (size_t i = 0; i < flights.size(); ++i) {
            if (flights[i].flightNumber == flightNumber) {
                flights.erase(flights.begin() + i);
                break;
            }
        }
    }

    Flight* searchFlight(const string &flightNumber) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto &flight : flights) {
            cout << "Flight Number: " << flight.flightNumber
                 << ", Destination: " << flight.destination
                 << ", Departure: " << flight.departure << endl;
            flight.displayPassengers();
        }
    }

    void updatePassengerDetails(const string &flightNumber, int passengerId, const string &newName, int newAge, const string &newGender) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            Passenger* passenger = flight->searchPassenger(passengerId);
            if (passenger) {
                passenger->name = newName;
                passenger->age = newAge;
                passenger->gender = newGender;
            }
        }
    }
};

int main() {
    AirlineBookingSystem system;

    system.addFlight("FN123", "New York", "London");
    system.addFlight("FN456", "Paris", "Tokyo");

    Passenger p1("Alice Smith", 1, "Female", 30);
    Passenger p2("Bob Brown", 2, "Male", 45);

    Flight* flight1 = system.searchFlight("FN123");
    if (flight1) {
        flight1->addPassenger(p1);
        flight1->addPassenger(p2);
    }

    system.displayFlights();

    system.updatePassengerDetails("FN123", 1, "Alice Johnson", 31, "Female");

    system.displayFlights();

    return 0;
}