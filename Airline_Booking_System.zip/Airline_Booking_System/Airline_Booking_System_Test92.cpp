#include <iostream>
#include <string>

struct Passenger {
    int id;
    std::string name;
    std::string passportNumber;
};

struct Flight {
    int flightNumber;
    std::string destination;
    int capacity;
    int bookedSeats;
};

Passenger passengers[100];
Flight flights[100];
int passengerCount = 0;
int flightCount = 0;

void addPassenger(int id, std::string name, std::string passportNumber) {
    passengers[passengerCount++] = {id, name, passportNumber};
}

void deletePassenger(int id) {
    for (int i = 0; i < passengerCount; ++i) {
        if (passengers[i].id == id) {
            passengers[i] = passengers[--passengerCount];
            break;
        }
    }
}

void updatePassenger(int id, std::string newName, std::string newPassportNumber) {
    for (int i = 0; i < passengerCount; ++i) {
        if (passengers[i].id == id) {
            passengers[i].name = newName;
            passengers[i].passportNumber = newPassportNumber;
            break;
        }
    }
}

void displayPassengers() {
    for (int i = 0; i < passengerCount; ++i) {
        std::cout << "ID: " << passengers[i].id << ", Name: " << passengers[i].name 
                  << ", Passport Number: " << passengers[i].passportNumber << '\n';
    }
}

void addFlight(int flightNumber, std::string destination, int capacity) {
    flights[flightCount++] = {flightNumber, destination, capacity, 0};
}

void deleteFlight(int flightNumber) {
    for (int i = 0; i < flightCount; ++i) {
        if (flights[i].flightNumber == flightNumber) {
            flights[i] = flights[--flightCount];
            break;
        }
    }
}

void updateFlight(int flightNumber, std::string newDestination, int newCapacity) {
    for (int i = 0; i < flightCount; ++i) {
        if (flights[i].flightNumber == flightNumber) {
            flights[i].destination = newDestination;
            flights[i].capacity = newCapacity;
            break;
        }
    }
}

void displayFlights() {
    for (int i = 0; i < flightCount; ++i) {
        std::cout << "Flight Number: " << flights[i].flightNumber << ", Destination: " 
                  << flights[i].destination << ", Capacity: " << flights[i].capacity
                  << ", Booked Seats: " << flights[i].bookedSeats << '\n';
    }
}

void bookFlight(int passengerId, int flightNumber) {
    for (int i = 0; i < flightCount; ++i) {
        if (flights[i].flightNumber == flightNumber) {
            if (flights[i].bookedSeats < flights[i].capacity) {
                flights[i].bookedSeats += 1;
            }
            break;
        }
    }
}

void searchPassenger(int id) {
    for (int i = 0; i < passengerCount; ++i) {
        if (passengers[i].id == id) {
            std::cout << "Found Passenger - ID: " << passengers[i].id << ", Name: " 
                      << passengers[i].name << ", Passport Number: " 
                      << passengers[i].passportNumber << '\n';
            return;
        }
    }
    std::cout << "Passenger Not Found.\n";
}

void searchFlight(int flightNumber) {
    for (int i = 0; i < flightCount; ++i) {
        if (flights[i].flightNumber == flightNumber) {
            std::cout << "Found Flight - Flight Number: " << flights[i].flightNumber 
                      << ", Destination: " << flights[i].destination 
                      << ", Capacity: " << flights[i].capacity 
                      << ", Booked Seats: " << flights[i].bookedSeats << '\n';
            return;
        }
    }
    std::cout << "Flight Not Found.\n";
}

int main() {
    addPassenger(1, "John Doe", "A123456");
    addPassenger(2, "Jane Smith", "B654321");
    displayPassengers();
    
    addFlight(101, "New York", 200);
    addFlight(102, "Los Angeles", 150);
    displayFlights();
    
    bookFlight(1, 101);
    bookFlight(2, 101);
    displayFlights();
    
    searchPassenger(1);
    searchFlight(101);
    
    deletePassenger(2);
    deleteFlight(102);
    
    displayPassengers();
    displayFlights();
    
    return 0;
}