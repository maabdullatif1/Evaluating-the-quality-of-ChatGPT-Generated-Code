#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Passenger {
    int id;
    string name;
    string passportNumber;
};

struct Flight {
    int flightNumber;
    string origin;
    string destination;
};

class AirlineBookingSystem {
    vector<Passenger> passengers;
    vector<Flight> flights;

public:
    void addPassenger(int id, string name, string passportNumber) {
        passengers.push_back({id, name, passportNumber});
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, string name, string passportNumber) {
        for (auto &p : passengers) {
            if (p.id == id) {
                p.name = name;
                p.passportNumber = passportNumber;
                break;
            }
        }
    }

    void displayPassengers() {
        for (const auto &p : passengers) {
            cout << "ID: " << p.id << ", Name: " << p.name << ", Passport Number: " << p.passportNumber << endl;
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto &p : passengers) {
            if (p.id == id) {
                return &p;
            }
        }
        return nullptr;
    }

    void addFlight(int flightNumber, string origin, string destination) {
        flights.push_back({flightNumber, origin, destination});
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int flightNumber, string origin, string destination) {
        for (auto &f : flights) {
            if (f.flightNumber == flightNumber) {
                f.origin = origin;
                f.destination = destination;
                break;
            }
        }
    }

    void displayFlights() {
        for (const auto &f : flights) {
            cout << "Flight Number: " << f.flightNumber << ", Origin: " << f.origin << ", Destination: " << f.destination << endl;
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto &f : flights) {
            if (f.flightNumber == flightNumber) {
                return &f;
            }
        }
        return nullptr;
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "John Doe", "A123456");
    system.addFlight(101, "New York", "London");
    system.displayPassengers();
    system.displayFlights();
    system.updatePassenger(1, "John Doe", "B654321");
    system.updateFlight(101, "New York", "Paris");
    system.displayPassengers();
    system.displayFlights();

    return 0;
}