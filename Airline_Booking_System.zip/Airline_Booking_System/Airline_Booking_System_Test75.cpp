#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;

    Passenger(int i, std::string n, std::string p)
        : id(i), name(n), passportNumber(p) {}
};

class Flight {
public:
    int flightNumber;
    std::string origin;
    std::string destination;

    Flight(int f, std::string o, std::string d)
        : flightNumber(f), origin(o), destination(d) {}
};

class BookingSystem {
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

    Passenger* findPassengerById(int id) {
        for (auto& p : passengers)
            if (p.id == id)
                return &p;
        return nullptr;
    }

    Flight* findFlightByNumber(int flightNumber) {
        for (auto& f : flights)
            if (f.flightNumber == flightNumber)
                return &f;
        return nullptr;
    }

public:
    void addPassenger(int id, const std::string& name, const std::string& passportNumber) {
        passengers.emplace_back(id, name, passportNumber);
    }

    void deletePassenger(int id) {
        passengers.erase(std::remove_if(passengers.begin(), passengers.end(),
            [id](Passenger& p) { return p.id == id; }), passengers.end());
    }

    void updatePassenger(int id, const std::string& name, const std::string& passportNumber) {
        Passenger* p = findPassengerById(id);
        if (p) {
            p->name = name;
            p->passportNumber = passportNumber;
        }
    }

    void addFlight(int flightNumber, const std::string& origin, const std::string& destination) {
        flights.emplace_back(flightNumber, origin, destination);
    }

    void deleteFlight(int flightNumber) {
        flights.erase(std::remove_if(flights.begin(), flights.end(),
            [flightNumber](Flight& f) { return f.flightNumber == flightNumber; }), flights.end());
    }

    void updateFlight(int flightNumber, const std::string& origin, const std::string& destination) {
        Flight* f = findFlightByNumber(flightNumber);
        if (f) {
            f->origin = origin;
            f->destination = destination;
        }
    }

    void displayPassengers() const {
        for (const auto& p : passengers) {
            std::cout << "ID: " << p.id << ", Name: " << p.name << ", Passport: " << p.passportNumber << "\n";
        }
    }

    void displayFlights() const {
        for (const auto& f : flights) {
            std::cout << "Flight Number: " << f.flightNumber << ", Origin: " << f.origin << ", Destination: " << f.destination << "\n";
        }
    }

    void searchPassenger(int id) const {
        for (const auto& p : passengers) {
            if (p.id == id) {
                std::cout << "ID: " << p.id << ", Name: " << p.name << ", Passport: " << p.passportNumber << "\n";
                return;
            }
        }
        std::cout << "Passenger not found.\n";
    }

    void searchFlight(int flightNumber) const {
        for (const auto& f : flights) {
            if (f.flightNumber == flightNumber) {
                std::cout << "Flight Number: " << f.flightNumber << ", Origin: " << f.origin << ", Destination: " << f.destination << "\n";
                return;
            }
        }
        std::cout << "Flight not found.\n";
    }
};

int main() {
    BookingSystem system;
    
    system.addPassenger(1, "John Doe", "A123456");
    system.addPassenger(2, "Jane Smith", "B234567");
    system.addFlight(100, "New York", "London");
    system.addFlight(200, "San Francisco", "Tokyo");

    system.displayPassengers();
    system.displayFlights();

    system.searchPassenger(1);
    system.searchFlight(100);

    system.updatePassenger(1, "John Doe Updated", "A123456U");
    system.updateFlight(100, "New York", "Paris");

    system.displayPassengers();
    system.displayFlights();

    system.deletePassenger(2);
    system.deleteFlight(200);

    system.displayPassengers();
    system.displayFlights();

    return 0;
}