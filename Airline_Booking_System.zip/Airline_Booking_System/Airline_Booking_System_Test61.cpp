#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Passenger {
public:
    int id;
    string name;
    string passportNumber;

    Passenger(int id, string name, string passportNumber) 
        : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int flightNumber;
    string destination;
    string departureTime;

    Flight(int flightNumber, string destination, string departureTime) 
        : flightNumber(flightNumber), destination(destination), departureTime(departureTime) {}
};

class AirlineBookingSystem {
private:
    vector<Passenger> passengers;
    vector<Flight> flights;

public:
    void addPassenger(int id, string name, string passportNumber) {
        passengers.push_back(Passenger(id, name, passportNumber));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, string name, string passportNumber) {
        for (auto& p : passengers) {
            if (p.id == id) {
                p.name = name;
                p.passportNumber = passportNumber;
                break;
            }
        }
    }

    void searchPassenger(int id) {
        for (const auto& p : passengers) {
            if (p.id == id) {
                cout << "Passenger ID: " << p.id << ", Name: " << p.name 
                     << ", Passport Number: " << p.passportNumber << endl;
                return;
            }
        }
        cout << "Passenger not found." << endl;
    }

    void displayPassengers() {
        for (const auto& p : passengers) {
            cout << "Passenger ID: " << p.id << ", Name: " << p.name 
                 << ", Passport Number: " << p.passportNumber << endl;
        }
    }

    void addFlight(int flightNumber, string destination, string departureTime) {
        flights.push_back(Flight(flightNumber, destination, departureTime));
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int flightNumber, string destination, string departureTime) {
        for (auto& f : flights) {
            if (f.flightNumber == flightNumber) {
                f.destination = destination;
                f.departureTime = departureTime;
                break;
            }
        }
    }

    void searchFlight(int flightNumber) {
        for (const auto& f : flights) {
            if (f.flightNumber == flightNumber) {
                cout << "Flight Number: " << f.flightNumber << ", Destination: " 
                     << f.destination << ", Departure Time: " << f.departureTime << endl;
                return;
            }
        }
        cout << "Flight not found." << endl;
    }

    void displayFlights() {
        for (const auto& f : flights) {
            cout << "Flight Number: " << f.flightNumber << ", Destination: " 
                 << f.destination << ", Departure Time: " << f.departureTime << endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "Alice", "P12345");
    system.addPassenger(2, "Bob", "P67890");
    system.addFlight(101, "New York", "10:00 AM");
    system.addFlight(102, "London", "8:00 PM");
    system.displayPassengers();
    system.displayFlights();
    system.searchPassenger(1);
    system.searchFlight(101);
    system.updatePassenger(2, "Bob Smith", "P67890");
    system.updateFlight(102, "London", "9:00 PM");
    system.deletePassenger(1);
    system.deleteFlight(101);
    system.displayPassengers();
    system.displayFlights();
    return 0;
}