#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;
    
    Passenger(int id, std::string name, std::string passportNumber)
        : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int flightNumber;
    std::string destination;
    std::vector<Passenger> passengers;

    Flight(int flightNumber, std::string destination)
        : flightNumber(flightNumber), destination(destination) {}

    void addPassenger(const Passenger& passenger) {
        passengers.push_back(passenger);
    }

    void removePassenger(int passengerId) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == passengerId) {
                passengers.erase(it);
                return;
            }
        }
    }

    void updatePassenger(int passengerId, std::string newName, std::string newPassport) {
        for (auto& passenger : passengers) {
            if (passenger.id == passengerId) {
                passenger.name = newName;
                passenger.passportNumber = newPassport;
                return;
            }
        }
    }

    void displayPassengers() const {
        for (const auto& passenger : passengers) {
            std::cout << "ID: " << passenger.id << ", Name: " << passenger.name
                      << ", Passport: " << passenger.passportNumber << std::endl;
        }
    }
};

class AirlineSystem {
public:
    std::vector<Flight> flights;

    void addFlight(int flightNumber, std::string destination) {
        flights.emplace_back(flightNumber, destination);
    }

    void removeFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                return;
            }
        }
    }

    void updateFlight(int flightNumber, std::string newDestination) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = newDestination;
                return;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() const {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << std::endl;
            flight.displayPassengers();
        }
    }
};

int main() {
    AirlineSystem system;

    system.addFlight(101, "New York");
    system.addFlight(102, "London");

    Flight* flight = system.searchFlight(101);
    if (flight) {
        flight->addPassenger(Passenger(1, "John Doe", "AB12345"));
        flight->addPassenger(Passenger(2, "Jane Smith", "CD54321"));
    }

    system.updateFlight(101, "Chicago");

    if (flight) {
        flight->updatePassenger(1, "Johnathan Doe", "AB123456");
        flight->removePassenger(2);
    }

    system.displayFlights();

    return 0;
}