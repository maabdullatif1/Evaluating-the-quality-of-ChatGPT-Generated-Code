#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Passenger {
public:
    int id;
    string name;
    string passportNumber;

    Passenger(int id, const string& name, const string& passportNumber)
        : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int id;
    string flightNumber;
    string origin;
    string destination;

    Flight(int id, const string& flightNumber, const string& origin, const string& destination)
        : id(id), flightNumber(flightNumber), origin(origin), destination(destination) {}
};

class AirlineBookingSystem {
    vector<Passenger> passengers;
    vector<Flight> flights;

public:
    void addPassenger(int id, const string& name, const string& passportNumber) {
        passengers.push_back(Passenger(id, name, passportNumber));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                return;
            }
        }
    }

    void updatePassenger(int id, const string& name, const string& passportNumber) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.passportNumber = passportNumber;
                return;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            cout << "ID: " << passenger.id << ", Name: " << passenger.name
                 << ", Passport Number: " << passenger.passportNumber << endl;
        }
    }

    void addFlight(int id, const string& flightNumber, const string& origin, const string& destination) {
        flights.push_back(Flight(id, flightNumber, origin, destination));
    }

    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                return;
            }
        }
    }

    void updateFlight(int id, const string& flightNumber, const string& origin, const string& destination) {
        for (auto& flight : flights) {
            if (flight.id == id) {
                flight.flightNumber = flightNumber;
                flight.origin = origin;
                flight.destination = destination;
                return;
            }
        }
    }

    Flight* searchFlight(int id) {
        for (auto& flight : flights) {
            if (flight.id == id) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            cout << "ID: " << flight.id << ", Flight Number: " << flight.flightNumber
                 << ", Origin: " << flight.origin << ", Destination: " << flight.destination << endl;
        }
    }
};

int main() {
    AirlineBookingSystem abs;
    abs.addPassenger(1, "John Doe", "A1234567");
    abs.addFlight(101, "AB123", "New York", "London");
    abs.displayPassengers();
    abs.displayFlights();
    return 0;
}