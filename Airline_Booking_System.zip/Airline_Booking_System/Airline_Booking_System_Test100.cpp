#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    Passenger(int id, const std::string& name) : id(id), name(name) {}
};

class Flight {
public:
    int flightNumber;
    std::string origin;
    std::string destination;
    Flight(int flightNum, const std::string& origin, const std::string& destination)
        : flightNumber(flightNum), origin(origin), destination(destination) {}
};

class BookingSystem {
private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;
public:
    void addPassenger(int id, const std::string& name) {
        passengers.push_back(Passenger(id, name));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, const std::string& newName) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = newName;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void addFlight(int flightNumber, const std::string& origin, const std::string& destination) {
        flights.push_back(Flight(flightNumber, origin, destination));
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int flightNumber, const std::string& newOrigin, const std::string& newDestination) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.origin = newOrigin;
                flight.destination = newDestination;
                break;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << std::endl;
        }
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Origin: " 
                      << flight.origin << ", Destination: " << flight.destination << std::endl;
        }
    }
};

int main() {
    BookingSystem system;
    system.addPassenger(1, "Alice");
    system.addPassenger(2, "Bob");
    system.addFlight(101, "New York", "Los Angeles");
    system.addFlight(102, "Chicago", "Miami");

    system.displayPassengers();
    system.displayFlights();

    Passenger* passenger = system.searchPassenger(1);
    if (passenger) {
        std::cout << "Found Passenger: ID: " << passenger->id << ", Name: " << passenger->name << std::endl;
    }

    Flight* flight = system.searchFlight(101);
    if (flight) {
        std::cout << "Found Flight: Number: " << flight->flightNumber 
                  << ", Origin: " << flight->origin 
                  << ", Destination: " << flight->destination << std::endl;
    }

    system.updatePassenger(1, "Alice Johnson");
    system.updateFlight(101, "New York", "San Francisco");

    system.displayPassengers();
    system.displayFlights();

    system.deletePassenger(2);
    system.deleteFlight(102);

    system.displayPassengers();
    system.displayFlights();

    return 0;
}