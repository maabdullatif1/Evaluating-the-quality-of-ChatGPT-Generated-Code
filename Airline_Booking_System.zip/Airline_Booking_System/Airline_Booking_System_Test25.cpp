#include <iostream>
#include <string>
#include <vector>

class Passenger {
public:
    std::string id;
    std::string name;
    
    Passenger(const std::string& p_id, const std::string& p_name)
        : id(p_id), name(p_name) {}
};

class Flight {
public:
    std::string flight_number;
    std::string origin;
    std::string destination;
    
    Flight(const std::string& f_number, const std::string& f_origin, const std::string& f_destination)
        : flight_number(f_number), origin(f_origin), destination(f_destination) {}
};

class AirlineBookingSystem {
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;
    
public:
    void addPassenger(const std::string& id, const std::string& name) {
        passengers.emplace_back(id, name);
    }
    
    void deletePassenger(const std::string& id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }
    
    void updatePassenger(const std::string& id, const std::string& new_name) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = new_name;
                break;
            }
        }
    }
    
    Passenger* searchPassenger(const std::string& id) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }
    
    void displayPassengers() const {
        for (const auto& passenger : passengers) {
            std::cout << "ID: " << passenger.id << ", Name: " << passenger.name << std::endl;
        }
    }
    
    void addFlight(const std::string& flight_number, const std::string& origin, const std::string& destination) {
        flights.emplace_back(flight_number, origin, destination);
    }
    
    void deleteFlight(const std::string& flight_number) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flight_number == flight_number) {
                flights.erase(it);
                break;
            }
        }
    }
    
    void updateFlight(const std::string& flight_number, const std::string& new_origin, const std::string& new_destination) {
        for (auto& flight : flights) {
            if (flight.flight_number == flight_number) {
                flight.origin = new_origin;
                flight.destination = new_destination;
                break;
            }
        }
    }
    
    Flight* searchFlight(const std::string& flight_number) {
        for (auto& flight : flights) {
            if (flight.flight_number == flight_number) {
                return &flight;
            }
        }
        return nullptr;
    }
    
    void displayFlights() const {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flight_number 
                      << ", Origin: " << flight.origin 
                      << ", Destination: " << flight.destination << std::endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger("1", "John Doe");
    system.addPassenger("2", "Jane Smith");
    system.displayPassengers();
    
    system.addFlight("AA101", "New York", "Los Angeles");
    system.addFlight("BB202", "San Francisco", "Chicago");
    system.displayFlights();
    
    system.updatePassenger("1", "John A. Doe");
    system.displayPassengers();
    
    system.updateFlight("AA101", "Washington", "Miami");
    system.displayFlights();
    
    system.deletePassenger("2");
    system.displayPassengers();
    
    system.deleteFlight("BB202");
    system.displayFlights();

    Passenger* p = system.searchPassenger("1");
    if(p) std::cout << "Found passenger: " << p->name << std::endl;
    
    Flight* f = system.searchFlight("AA101");
    if(f) std::cout << "Found flight: " << f->flight_number << std::endl;

    return 0;
}