#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    std::string name;
    int age;
    std::string passportNumber;
    Passenger(std::string n, int a, std::string p) : name(n), age(a), passportNumber(p) {}
};

class Flight {
public:
    std::string flightNumber;
    std::string source;
    std::string destination;
    std::vector<Passenger> passengers;
    Flight(std::string fn, std::string s, std::string d) : flightNumber(fn), source(s), destination(d) {}
};

class AirlineBookingSystem {
    std::vector<Flight> flights;
public:
    void addFlight(std::string fn, std::string s, std::string d) {
        flights.push_back(Flight(fn, s, d));
    }

    void deleteFlight(std::string fn) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == fn) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(std::string fn, std::string newSource, std::string newDestination) {
        for (auto& flight : flights) {
            if (flight.flightNumber == fn) {
                flight.source = newSource;
                flight.destination = newDestination;
                break;
            }
        }
    }

    Flight* searchFlight(std::string fn) {
        for (auto& flight : flights) {
            if (flight.flightNumber == fn) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber
                      << ", Source: " << flight.source
                      << ", Destination: " << flight.destination << "\n";
        }
    }

    void addPassenger(std::string flightNumber, std::string name, int age, std::string passportNumber) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            flight->passengers.push_back(Passenger(name, age, passportNumber));
        }
    }

    void deletePassenger(std::string flightNumber, std::string passportNumber) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            for (auto it = flight->passengers.begin(); it != flight->passengers.end(); ++it) {
                if (it->passportNumber == passportNumber) {
                    flight->passengers.erase(it);
                    break;
                }
            }
        }
    }

    void updatePassenger(std::string flightNumber, std::string passportNumber, std::string newName, int newAge) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            for (auto& passenger : flight->passengers) {
                if (passenger.passportNumber == passportNumber) {
                    passenger.name = newName;
                    passenger.age = newAge;
                    break;
                }
            }
        }
    }

    Passenger* searchPassenger(std::string flightNumber, std::string passportNumber) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            for (auto& passenger : flight->passengers) {
                if (passenger.passportNumber == passportNumber) {
                    return &passenger;
                }
            }
        }
        return nullptr;
    }

    void displayPassengers(std::string flightNumber) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            for (const auto& passenger : flight->passengers) {
                std::cout << "Name: " << passenger.name
                          << ", Age: " << passenger.age
                          << ", Passport Number: " << passenger.passportNumber << "\n";
            }
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addFlight("AB123", "New York", "London");
    system.addPassenger("AB123", "John Doe", 30, "P123456");
    system.displayFlights();
    system.displayPassengers("AB123");
    return 0;
}