#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;

    Passenger(int pid, const std::string& pname) : id(pid), name(pname) {}
};

class Flight {
public:
    int flightNumber;
    std::string destination;
    std::vector<Passenger> passengers;

    Flight(int fnumber, const std::string& dest) : flightNumber(fnumber), destination(dest) {}

    void addPassenger(const Passenger& passenger) {
        passengers.push_back(passenger);
    }

    void removePassenger(int passengerId) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == passengerId) {
                passengers.erase(it);
                return;
            }
        }
    }

    void displayPassengers() const {
        for (const auto& passenger : passengers) {
            std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << std::endl;
        }
    }
};

class BookingSystem {
private:
    std::vector<Flight> flights;
    std::vector<Passenger> passengers;

public:
    void addPassenger(int id, const std::string& name) {
        passengers.emplace_back(id, name);
    }

    void removePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                return;
            }
        }
    }

    void addFlight(int flightNumber, const std::string& destination) {
        flights.emplace_back(flightNumber, destination);
    }

    void removeFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                return;
            }
        }
    }

    void updatePassenger(int id, const std::string& newName) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = newName;
                return;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }

    Flight* searchFlight(int flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() const {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << std::endl;
        }
    }

    void displayPassengers() const {
        for (const auto& passenger : passengers) {
            std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << std::endl;
        }
    }
};

int main() {
    BookingSystem system;

    system.addPassenger(1, "John Doe");
    system.addPassenger(2, "Jane Smith");
    system.addFlight(101, "New York");
    system.addFlight(102, "Los Angeles");

    system.displayPassengers();
    system.displayFlights();

    Flight* flight = system.searchFlight(101);
    if (flight) {
        Passenger* passenger = system.searchPassenger(1);
        if (passenger) {
            flight->addPassenger(*passenger);
        }
    }

    if (flight) {
        std::cout << "Passengers for Flight 101:" << std::endl;
        flight->displayPassengers();
    }

    return 0;
}