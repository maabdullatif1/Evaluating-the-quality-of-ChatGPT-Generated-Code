#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Passenger {
    int id;
    string name;
    string passportNumber;
};

struct Flight {
    int flightNumber;
    string origin;
    string destination;
    vector<int> passengerIds;
};

class AirlineBookingSystem {
    vector<Passenger> passengers;
    vector<Flight> flights;
    int passengerIdCounter = 1;
    int flightNumberCounter = 1000;

public:
    void addPassenger(string name, string passportNumber) {
        Passenger passenger = {passengerIdCounter++, name, passportNumber};
        passengers.push_back(passenger);
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, string name, string passportNumber) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.passportNumber = passportNumber;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto& passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            cout << "ID: " << passenger.id << ", Name: " << passenger.name
                 << ", Passport: " << passenger.passportNumber << endl;
        }
    }

    void addFlight(string origin, string destination) {
        Flight flight = {flightNumberCounter++, origin, destination};
        flights.push_back(flight);
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int flightNumber, string origin, string destination) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.origin = origin;
                flight.destination = destination;
                break;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            cout << "Flight Number: " << flight.flightNumber << ", Origin: "
                 << flight.origin << ", Destination: " << flight.destination << endl;
            cout << "Passengers: ";
            for (const auto& passengerId : flight.passengerIds) {
                cout << passengerId << " ";
            }
            cout << endl;
        }
    }

    void addPassengerToFlight(int flightNumber, int passengerId) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            flight->passengerIds.push_back(passengerId);
        }
    }

    void removePassengerFromFlight(int flightNumber, int passengerId) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            auto& passengers = flight->passengerIds;
            passengers.erase(remove(passengers.begin(), passengers.end(), passengerId), passengers.end());
        }
    }
};

int main() {
    AirlineBookingSystem abs;
    abs.addPassenger("John Doe", "AB123456");
    abs.addPassenger("Jane Smith", "CD789012");
    abs.addFlight("New York", "London");
    abs.displayPassengers();
    abs.displayFlights();
    abs.addPassengerToFlight(1000, 1);
    abs.displayFlights();
    return 0;
}