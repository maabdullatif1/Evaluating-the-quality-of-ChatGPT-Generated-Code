#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Passenger {
    int id;
    string name;
    int flightId;
};

struct Flight {
    int id;
    string destination;
    int capacity;
};

class AirlineBookingSystem {
public:
    void addPassenger(int id, string name, int flightId) {
        passengers.push_back({id, name, flightId});
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, string name, int flightId) {
        for (auto &p : passengers) {
            if (p.id == id) {
                p.name = name;
                p.flightId = flightId;
                break;
            }
        }
    }

    void addFlight(int id, string destination, int capacity) {
        flights.push_back({id, destination, capacity});
    }

    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int id, string destination, int capacity) {
        for (auto &f : flights) {
            if (f.id == id) {
                f.destination = destination;
                f.capacity = capacity;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto &p : passengers) {
            if (p.id == id) {
                return &p;
            }
        }
        return nullptr;
    }

    Flight* searchFlight(int id) {
        for (auto &f : flights) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto &p : passengers) {
            cout << "Passenger ID: " << p.id << ", Name: " << p.name << ", Flight ID: " << p.flightId << endl;
        }
    }

    void displayFlights() {
        for (const auto &f : flights) {
            cout << "Flight ID: " << f.id << ", Destination: " << f.destination << ", Capacity: " << f.capacity << endl;
        }
    }

private:
    vector<Passenger> passengers;
    vector<Flight> flights;
};

int main() {
    AirlineBookingSystem system;
    
    system.addFlight(1, "New York", 180);
    system.addFlight(2, "London", 150);
    
    system.addPassenger(1, "John Doe", 1);
    system.addPassenger(2, "Jane Smith", 2);
    
    cout << "Current Flights:" << endl;
    system.displayFlights();
    
    cout << "\nCurrent Passengers:" << endl;
    system.displayPassengers();
    
    system.updatePassenger(1, "Johnathon Doe", 2);
    system.updateFlight(1, "Los Angeles", 200);
    
    cout << "\nUpdated Flights:" << endl;
    system.displayFlights();
    
    cout << "\nUpdated Passengers:" << endl;
    system.displayPassengers();
    
    return 0;
}