#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    std::string name;
    int id;
    
    Passenger(int id, std::string name) : id(id), name(name) {}
};

class Flight {
public:
    std::string flightNumber;
    std::vector<Passenger> passengers;
    
    Flight(std::string fn) : flightNumber(fn) {}

    void addPassenger(int id, std::string name) {
        passengers.emplace_back(id, name);
    }

    void deletePassenger(int id) {
        passengers.erase(std::remove_if(passengers.begin(), passengers.end(), 
                                         [id](Passenger& p){ return p.id == id; }), passengers.end());
    }

    void updatePassenger(int id, std::string newName) {
        for (auto& p : passengers) {
            if (p.id == id) {
                p.name = newName;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto& p : passengers) {
            if (p.id == id) return &p;
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto& p : passengers) {
            std::cout << "Passenger ID: " << p.id << ", Name: " << p.name << std::endl;
        }
    }
};

class AirlineSystem {
public:
    std::vector<Flight> flights;

    void addFlight(std::string flightNumber) {
        flights.emplace_back(flightNumber);
    }

    void deleteFlight(std::string flightNumber) {
        flights.erase(std::remove_if(flights.begin(), flights.end(), 
                                      [flightNumber](Flight& f){ return f.flightNumber == flightNumber; }), flights.end());
    }

    void updateFlight(std::string oldNumber, std::string newNumber) {
        for (auto& f : flights) {
            if (f.flightNumber == oldNumber) {
                f.flightNumber = newNumber;
                break;
            }
        }
    }

    Flight* searchFlight(std::string flightNumber) {
        for (auto& f : flights) {
            if (f.flightNumber == flightNumber) return &f;
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto& f : flights) {
            std::cout << "Flight Number: " << f.flightNumber << std::endl;
            f.displayPassengers();
        }
    }
};

int main() {
    AirlineSystem system;
    system.addFlight("AA123");
    system.addFlight("BB456");

    Flight* flight = system.searchFlight("AA123");
    if (flight) {
        flight->addPassenger(1, "John Doe");
        flight->addPassenger(2, "Jane Smith");
    }

    system.displayFlights();
    return 0;
}