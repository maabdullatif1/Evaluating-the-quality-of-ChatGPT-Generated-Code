#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Passenger {
public:
    int id;
    string name;

    Passenger(int pid, string pname) : id(pid), name(pname) {}
};

class Flight {
public:
    int id;
    string origin;
    string destination;
    vector<Passenger> passengers;

    Flight(int fid, string forigin, string fdestination)
        : id(fid), origin(forigin), destination(fdestination) {}
    
    void addPassenger(Passenger p) {
        passengers.push_back(p);
    }

    void deletePassenger(int pid) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == pid) {
                passengers.erase(it);
                break;
            }
        }
    }
};

class AirlineBookingSystem {
public:
    vector<Passenger> passengers;
    vector<Flight> flights;

    void addPassenger(int id, string name) {
        passengers.push_back(Passenger(id, name));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, string new_name) {
        for (auto &p : passengers) {
            if (p.id == id) {
                p.name = new_name;
                break;
            }
        }
    }

    void addFlight(int id, string origin, string destination) {
        flights.push_back(Flight(id, origin, destination));
    }

    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int id, string new_origin, string new_destination) {
        for (auto &f : flights) {
            if (f.id == id) {
                f.origin = new_origin;
                f.destination = new_destination;
                break;
            }
        }
    }

    void searchPassenger(int id) {
        for (const auto &p : passengers) {
            if (p.id == id) {
                cout << "Passenger ID: " << p.id << ", Name: " << p.name << endl;
                return;
            }
        }
        cout << "Passenger not found." << endl;
    }

    void searchFlight(int id) {
        for (const auto &f : flights) {
            if (f.id == id) {
                cout << "Flight ID: " << f.id << ", Origin: " << f.origin 
                     << ", Destination: " << f.destination << endl;
                return;
            }
        }
        cout << "Flight not found." << endl;
    }

    void displayPassengers() {
        for (const auto &p : passengers) {
            cout << "Passenger ID: " << p.id << ", Name: " << p.name << endl;
        }
    }

    void displayFlights() {
        for (const auto &f : flights) {
            cout << "Flight ID: " << f.id << ", Origin: " << f.origin 
                 << ", Destination: " << f.destination << endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "John Doe");
    system.addPassenger(2, "Jane Smith");
    system.addFlight(101, "New York", "Los Angeles");
    system.addFlight(102, "Chicago", "Miami");

    system.displayPassengers();
    system.displayFlights();

    system.searchPassenger(1);
    system.searchFlight(101);

    system.updatePassenger(1, "Johnathan Doe");
    system.updateFlight(101, "New York", "San Francisco");

    system.displayPassengers();
    system.displayFlights();

    system.deletePassenger(2);
    system.deleteFlight(102);

    system.displayPassengers();
    system.displayFlights();

    return 0;
}