#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Passenger {
public:
    string name;
    int age;
    string passportNumber;

    Passenger(string name, int age, string passportNumber)
        : name(name), age(age), passportNumber(passportNumber) {}
};

class Flight {
public:
    string flightNumber;
    string destination;
    vector<Passenger> passengers;

    Flight(string flightNumber, string destination)
        : flightNumber(flightNumber), destination(destination) {}

    void addPassenger(const Passenger& passenger) {
        passengers.push_back(passenger);
    }

    bool removePassenger(const string& passportNumber) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->passportNumber == passportNumber) {
                passengers.erase(it);
                return true;
            }
        }
        return false;
    }

    Passenger* findPassenger(const string& passportNumber) {
        for (auto& passenger : passengers) {
            if (passenger.passportNumber == passportNumber) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto& passenger : passengers) {
            cout << "Name: " << passenger.name << ", Age: " << passenger.age 
                 << ", Passport: " << passenger.passportNumber << endl;
        }
    }

    void updatePassenger(const string& passportNumber, const string& newName, int newAge) {
        Passenger* passenger = findPassenger(passportNumber);
        if (passenger != nullptr) {
            passenger->name = newName;
            passenger->age = newAge;
        }
    }
};

class AirlineSystem {
    vector<Flight> flights;

public:

    void addFlight(const Flight& flight) {
        flights.push_back(flight);
    }

    void addPassengerToFlight(const string& flightNumber, const Passenger& passenger) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.addPassenger(passenger);
                return;
            }
        }
    }

    void removePassengerFromFlight(const string& flightNumber, const string& passportNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.removePassenger(passportNumber);
                return;
            }
        }
    }

    void updatePassengerInFlight(const string& flightNumber, const string& passportNumber, 
                                 const string& newName, int newAge) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.updatePassenger(passportNumber, newName, newAge);
                return;
            }
        }
    }

    Flight* findFlight(const string& flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            cout << "Flight Number: " << flight.flightNumber 
                 << ", Destination: " << flight.destination << endl;
            flight.displayPassengers();
        }
    }
};

int main() {
    AirlineSystem system;

    Flight flight1("AA123", "New York");
    Flight flight2("BA456", "London");

    system.addFlight(flight1);
    system.addFlight(flight2);

    system.addPassengerToFlight("AA123", Passenger("John Doe", 30, "P123456"));
    system.addPassengerToFlight("AA123", Passenger("Alice Smith", 25, "P654321"));
    system.addPassengerToFlight("BA456", Passenger("Bob Brown", 40, "P112233"));

    system.displayFlights();

    system.updatePassengerInFlight("AA123", "P654321", "Alice Johnson", 26);
    system.removePassengerFromFlight("BA456", "P112233");

    system.displayFlights();

    return 0;
}