#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;

    Passenger(int pid, const std::string &pname) : id(pid), name(pname) {}

    void display() {
        std::cout << "Passenger ID: " << id << ", Name: " << name << std::endl;
    }
};

class Flight {
public:
    int id;
    std::string destination;

    Flight(int fid, const std::string &fdestination) : id(fid), destination(fdestination) {}

    void display() {
        std::cout << "Flight ID: " << id << ", Destination: " << destination << std::endl;
    }
};

class AirlineSystem {
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

    Passenger* findPassenger(int id) {
        for (auto &p : passengers) {
            if (p.id == id) return &p;
        }
        return nullptr;
    }

    Flight* findFlight(int id) {
        for (auto &f : flights) {
            if (f.id == id) return &f;
        }
        return nullptr;
    }

public:
    void addPassenger(int id, const std::string &name) {
        if (!findPassenger(id)) {
            passengers.emplace_back(id, name);
        }
    }

    void updatePassenger(int id, const std::string &name) {
        Passenger* passenger = findPassenger(id);
        if (passenger) {
            passenger->name = name;
        }
    }

    void deletePassenger(int id) {
        passengers.erase(remove_if(passengers.begin(), passengers.end(), [=](Passenger &p) {
            return p.id == id; 
        }), passengers.end());
    }

    void searchPassenger(int id) {
        Passenger* passenger = findPassenger(id);
        if (passenger) {
            passenger->display();
        }
    }

    void displayPassengers() {
        for (auto &p : passengers) {
            p.display();
        }
    }

    void addFlight(int id, const std::string &destination) {
        if (!findFlight(id)) {
            flights.emplace_back(id, destination);
        }
    }

    void updateFlight(int id, const std::string &destination) {
        Flight* flight = findFlight(id);
        if (flight) {
            flight->destination = destination;
        }
    }

    void deleteFlight(int id) {
        flights.erase(remove_if(flights.begin(), flights.end(), [=](Flight &f) {
            return f.id == id; 
        }), flights.end());
    }

    void searchFlight(int id) {
        Flight* flight = findFlight(id);
        if (flight) {
            flight->display();
        }
    }

    void displayFlights() {
        for (auto &f : flights) {
            f.display();
        }
    }
};

int main() {
    AirlineSystem system;
    system.addPassenger(1, "John Doe");
    system.addPassenger(2, "Jane Smith");
    system.displayPassengers();

    system.addFlight(101, "New York");
    system.addFlight(102, "Los Angeles");
    system.displayFlights();

    system.updatePassenger(1, "John A. Doe");
    system.searchPassenger(1);

    system.updateFlight(101, "Chicago");
    system.searchFlight(101);

    system.deletePassenger(2);
    system.displayPassengers();

    system.deleteFlight(102);
    system.displayFlights();

    return 0;
}