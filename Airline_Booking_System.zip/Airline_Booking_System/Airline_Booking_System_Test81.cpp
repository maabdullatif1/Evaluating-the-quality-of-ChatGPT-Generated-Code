#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;
    std::string passportNumber;

    Passenger(int id, std::string name, std::string passportNumber)
        : id(id), name(name), passportNumber(passportNumber) {}
};

class Flight {
public:
    int flightNumber;
    std::string destination;
    std::string departureTime;

    Flight(int flightNumber, std::string destination, std::string departureTime)
        : flightNumber(flightNumber), destination(destination), departureTime(departureTime) {}
};

class AirlineBookingSystem {
private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(int id, std::string name, std::string passportNumber) {
        passengers.push_back(Passenger(id, name, passportNumber));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, std::string name, std::string passportNumber) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = name;
                passenger.passportNumber = passportNumber;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto &passenger : passengers) {
            std::cout << "ID: " << passenger.id << ", Name: " << passenger.name 
                      << ", Passport: " << passenger.passportNumber << std::endl;
        }
    }

    void addFlight(int flightNumber, std::string destination, std::string departureTime) {
        flights.push_back(Flight(flightNumber, destination, departureTime));
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    void updateFlight(int flightNumber, std::string destination, std::string departureTime) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = destination;
                flight.departureTime = departureTime;
                break;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto &flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber
                      << ", Destination: " << flight.destination 
                      << ", Departure: " << flight.departureTime << std::endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "John Doe", "A123456");
    system.addPassenger(2, "Jane Smith", "B654321");
    system.addFlight(100, "New York", "10:00 AM");
    system.addFlight(200, "Los Angeles", "12:00 PM");

    std::cout << "Passengers:" << std::endl;
    system.displayPassengers();

    std::cout << "Flights:" << std::endl;
    system.displayFlights();

    return 0;
}