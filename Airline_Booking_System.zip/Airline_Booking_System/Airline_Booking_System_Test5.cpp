#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Passenger {
public:
    int id;
    string name;
    string passportNumber;
};

class Flight {
public:
    int id;
    string destination;
    string departureTime;
};

class AirlineBookingSystem {
private:
    vector<Passenger> passengers;
    vector<Flight> flights;

public:
    void addPassenger(int id, string name, string passportNumber) {
        Passenger p;
        p.id = id;
        p.name = name;
        p.passportNumber = passportNumber;
        passengers.push_back(p);
    }

    void addFlight(int id, string destination, string departureTime) {
        Flight f;
        f.id = id;
        f.destination = destination;
        f.departureTime = departureTime;
        flights.push_back(f);
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, string name, string passportNumber) {
        for (auto &p : passengers) {
            if (p.id == id) {
                p.name = name;
                p.passportNumber = passportNumber;
                break;
            }
        }
    }

    void updateFlight(int id, string destination, string departureTime) {
        for (auto &f : flights) {
            if (f.id == id) {
                f.destination = destination;
                f.departureTime = departureTime;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto &p : passengers) {
            if (p.id == id) {
                return &p;
            }
        }
        return nullptr;
    }

    Flight* searchFlight(int id) {
        for (auto &f : flights) {
            if (f.id == id) {
                return &f;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (const auto &p : passengers) {
            cout << "Passenger ID: " << p.id << ", Name: " << p.name 
                 << ", Passport No: " << p.passportNumber << endl;
        }
    }

    void displayFlights() {
        for (const auto &f : flights) {
            cout << "Flight ID: " << f.id << ", Destination: " << f.destination 
                 << ", Departure Time: " << f.departureTime << endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;

    system.addPassenger(1, "Alice", "A123456");
    system.addPassenger(2, "Bob", "B234567");

    system.addFlight(101, "New York", "10:00 AM");
    system.addFlight(102, "Los Angeles", "2:00 PM");

    system.displayPassengers();
    system.displayFlights();

    system.updatePassenger(1, "Alice Smith", "A123456");
    system.updateFlight(101, "New York", "11:00 AM");

    Passenger* p = system.searchPassenger(1);
    if (p) {
        cout << "Found Passenger - ID: " << p->id << " Name: " << p->name << endl;
    }

    Flight* f = system.searchFlight(102);
    if (f) {
        cout << "Found Flight - ID: " << f->id << " Destination: " << f->destination << endl;
    }

    system.deletePassenger(2);
    system.deleteFlight(102);

    system.displayPassengers();
    system.displayFlights();

    return 0;
}