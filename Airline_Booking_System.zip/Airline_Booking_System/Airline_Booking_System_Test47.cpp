#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    std::string name;
    std::string passportNumber;

    Passenger(std::string n, std::string p) : name(n), passportNumber(p) {}
};

class Flight {
public:
    std::string flightNumber;
    std::string destination;
    std::vector<Passenger> passengers;

    Flight(std::string f, std::string d) : flightNumber(f), destination(d) {}
};

class BookingSystem {
public:
    std::vector<Flight> flights;

    void addFlight(std::string flightNumber, std::string destination) {
        flights.emplace_back(flightNumber, destination);
    }

    void deleteFlight(std::string flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                return;
            }
        }
    }

    void updateFlight(std::string flightNumber, std::string newDestination) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = newDestination;
                return;
            }
        }
    }

    Flight* searchFlight(std::string flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber
                      << ", Destination: " << flight.destination << std::endl;
        }
    }

    void addPassenger(std::string flightNumber, std::string name, std::string passportNumber) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            flight->passengers.emplace_back(name, passportNumber);
        }
    }

    void deletePassenger(std::string flightNumber, std::string passportNumber) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            for (auto it = flight->passengers.begin(); it != flight->passengers.end(); ++it) {
                if (it->passportNumber == passportNumber) {
                    flight->passengers.erase(it);
                    return;
                }
            }
        }
    }

    void updatePassenger(std::string flightNumber, std::string passportNumber, std::string newName) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            for (auto& passenger : flight->passengers) {
                if (passenger.passportNumber == passportNumber) {
                    passenger.name = newName;
                    return;
                }
            }
        }
    }

    void displayPassengers(std::string flightNumber) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            for (const auto& passenger : flight->passengers) {
                std::cout << "Name: " << passenger.name
                          << ", Passport Number: " << passenger.passportNumber << std::endl;
            }
        }
    }
};

int main() {
    BookingSystem system;
    system.addFlight("FL123", "New York");
    system.addPassenger("FL123", "John Doe", "P12345");
    system.displayFlights();
    system.displayPassengers("FL123");
    return 0;
}