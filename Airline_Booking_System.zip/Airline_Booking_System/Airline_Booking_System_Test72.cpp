#include <iostream>
#include <vector>
#include <string>

struct Passenger {
    int id;
    std::string name;
    std::string passport;
};

struct Flight {
    int flightNumber;
    std::string destination;
    std::vector<Passenger> passengers;
};

class AirlineBookingSystem {
    std::vector<Flight> flights;
    int passengerIdCounter = 1;

public:
    void addFlight(int flightNumber, const std::string& destination) {
        Flight flight = {flightNumber, destination, {}};
        flights.push_back(flight);
    }

    void addPassenger(int flightNumber, const std::string& name, const std::string& passport) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.passengers.push_back({passengerIdCounter++, name, passport});
                return;
            }
        }
    }

    void deletePassenger(int flightNumber, int passengerId) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                for (auto it = flight.passengers.begin(); it != flight.passengers.end(); ++it) {
                    if (it->id == passengerId) {
                        flight.passengers.erase(it);
                        return;
                    }
                }
            }
        }
    }

    void updatePassenger(int flightNumber, int passengerId, const std::string& name, const std::string& passport) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                for (auto& passenger : flight.passengers) {
                    if (passenger.id == passengerId) {
                        passenger.name = name;
                        passenger.passport = passport;
                        return;
                    }
                }
            }
        }
    }

    void searchPassenger(int flightNumber, int passengerId) {
        for (const auto& flight : flights) {
            if (flight.flightNumber == flightNumber) {
                for (const auto& passenger : flight.passengers) {
                    if (passenger.id == passengerId) {
                        std::cout << "Passenger ID: " << passenger.id << " Name: " << passenger.name << " Passport: " << passenger.passport << std::endl;
                        return;
                    }
                }
            }
        }
        std::cout << "Passenger not found" << std::endl;
    }

    void displayFlights() {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << " Destination: " << flight.destination << std::endl;
            for (const auto& passenger : flight.passengers) {
                std::cout << "  Passenger ID: " << passenger.id << " Name: " << passenger.name << " Passport: " << passenger.passport << std::endl;
            }
        }
    }
};

int main() {
    AirlineBookingSystem system;
    
    system.addFlight(100, "New York");
    system.addFlight(200, "Los Angeles");

    system.addPassenger(100, "John Doe", "A123456");
    system.addPassenger(100, "Jane Doe", "A654321");
    system.addPassenger(200, "Alice Smith", "B987654");

    system.displayFlights();

    system.updatePassenger(100, 1, "Johnathan Doe", "A123456");

    system.searchPassenger(100, 1);
    
    system.deletePassenger(100, 2);

    system.displayFlights();

    return 0;
}