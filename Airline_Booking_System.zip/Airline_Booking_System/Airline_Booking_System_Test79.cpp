#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Passenger {
public:
    string name;
    int id;

    Passenger(int id, string name) : id(id), name(name) {}
};

class Flight {
public:
    int flightNumber;
    string destination;

    Flight(int flightNumber, string destination) : flightNumber(flightNumber), destination(destination) {}
};

class AirlineSystem {
private:
    vector<Passenger> passengers;
    vector<Flight> flights;

public:
    void addPassenger(int id, string name) {
        passengers.push_back(Passenger(id, name));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                return;
            }
        }
    }

    void updatePassenger(int id, string newName) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = newName;
                return;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (auto &passenger : passengers) {
            cout << "ID: " << passenger.id << ", Name: " << passenger.name << endl;
        }
    }

    void addFlight(int flightNumber, string destination) {
        flights.push_back(Flight(flightNumber, destination));
    }

    void deleteFlight(int flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                return;
            }
        }
    }

    void updateFlight(int flightNumber, string newDestination) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                flight.destination = newDestination;
                return;
            }
        }
    }

    Flight* searchFlight(int flightNumber) {
        for (auto &flight : flights) {
            if (flight.flightNumber == flightNumber) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayFlights() {
        for (auto &flight : flights) {
            cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << endl;
        }
    }
};

int main() {
    AirlineSystem airlineSystem;

    airlineSystem.addPassenger(1, "John Doe");
    airlineSystem.addPassenger(2, "Jane Smith");
    airlineSystem.addFlight(101, "New York");
    airlineSystem.addFlight(102, "Los Angeles");

    cout << "Passengers List:" << endl;
    airlineSystem.displayPassengers();

    cout << "Flights List:" << endl;
    airlineSystem.displayFlights();

    airlineSystem.updatePassenger(1, "Johnny Doe");
    airlineSystem.updateFlight(101, "Boston");

    cout << "Updated Passengers List:" << endl;
    airlineSystem.displayPassengers();

    cout << "Updated Flights List:" << endl;
    airlineSystem.displayFlights();

    return 0;
}