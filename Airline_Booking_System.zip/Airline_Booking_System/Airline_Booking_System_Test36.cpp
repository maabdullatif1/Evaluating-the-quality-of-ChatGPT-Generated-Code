#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;

    Passenger(int id, const std::string& name) : id(id), name(name) {}
};

class Flight {
public:
    int id;
    std::string destination;

    Flight(int id, const std::string& destination) : id(id), destination(destination) {}
};

class AirlineBookingSystem {
private:
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;

public:
    void addPassenger(int id, const std::string& name) {
        passengers.push_back(Passenger(id, name));
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                return;
            }
        }
    }

    void updatePassenger(int id, const std::string& newName) {
        for (auto& p : passengers) {
            if (p.id == id) {
                p.name = newName;
                return;
            }
        }
    }

    void searchPassenger(int id) {
        for (const auto& p : passengers) {
            if (p.id == id) {
                std::cout << "Passenger Found: ID = " << p.id << ", Name = " << p.name << std::endl;
                return;
            }
        }
        std::cout << "Passenger not found." << std::endl;
    }

    void addFlight(int id, const std::string& destination) {
        flights.push_back(Flight(id, destination));
    }

    void deleteFlight(int id) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->id == id) {
                flights.erase(it);
                return;
            }
        }
    }

    void updateFlight(int id, const std::string& newDestination) {
        for (auto& f : flights) {
            if (f.id == id) {
                f.destination = newDestination;
                return;
            }
        }
    }

    void searchFlight(int id) {
        for (const auto& f : flights) {
            if (f.id == id) {
                std::cout << "Flight Found: ID = " << f.id << ", Destination = " << f.destination << std::endl;
                return;
            }
        }
        std::cout << "Flight not found." << std::endl;
    }

    void displayPassengers() {
        for (const auto& p : passengers) {
            std::cout << "Passenger ID: " << p.id << ", Name: " << p.name << std::endl;
        }
    }

    void displayFlights() {
        for (const auto& f : flights) {
            std::cout << "Flight ID: " << f.id << ", Destination: " << f.destination << std::endl;
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addPassenger(1, "John Doe");
    system.addPassenger(2, "Jane Smith");
    system.displayPassengers();
    system.searchPassenger(1);

    system.addFlight(101, "New York");
    system.addFlight(102, "Los Angeles");
    system.displayFlights();
    system.searchFlight(101);

    system.updatePassenger(1, "Johnathon Doe");
    system.updateFlight(102, "San Francisco");
    system.displayPassengers();
    system.displayFlights();

    system.deletePassenger(2);
    system.deleteFlight(101);
    system.displayPassengers();
    system.displayFlights();

    return 0;
}