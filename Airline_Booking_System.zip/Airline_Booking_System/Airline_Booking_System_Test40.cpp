#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    std::string name;
    int id;

    Passenger(int id, const std::string& name) : id(id), name(name) {}
};

class Flight {
public:
    std::string flightNumber;
    std::string destination;
    std::vector<Passenger> passengers;

    Flight(const std::string& flightNumber, const std::string& destination)
        : flightNumber(flightNumber), destination(destination) {}

    void addPassenger(const Passenger& passenger) {
        passengers.push_back(passenger);
    }

    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }
};

class AirlineBookingSystem {
    std::vector<Flight> flights;

public:
    void addFlight(const std::string& flightNumber, const std::string& destination) {
        flights.emplace_back(flightNumber, destination);
    }

    void deleteFlight(const std::string& flightNumber) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == flightNumber) {
                flights.erase(it);
                break;
            }
        }
    }

    Flight* searchFlight(const std::string& flightNumber) {
        for (auto& flight : flights) {
            if (flight.flightNumber == flightNumber)
                return &flight;
        }
        return nullptr;
    }

    void updateFlight(const std::string& flightNumber, const std::string& newDestination) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            flight->destination = newDestination;
        }
    }

    void displayFlights() const {
        for (const auto& flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber
                      << ", Destination: " << flight.destination << "\nPassengers:\n";
            for (const auto& passenger : flight.passengers) {
                std::cout << "  - ID: " << passenger.id << ", Name: " << passenger.name << "\n";
            }
            std::cout << std::endl;
        }
    }

    void addPassengerToFlight(const std::string& flightNumber, int id, const std::string& name) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            flight->addPassenger(Passenger(id, name));
        }
    }

    void deletePassengerFromFlight(const std::string& flightNumber, int id) {
        Flight* flight = searchFlight(flightNumber);
        if (flight) {
            flight->deletePassenger(id);
        }
    }
};

int main() {
    AirlineBookingSystem system;
    system.addFlight("AA101", "New York");
    system.addFlight("BA202", "London");

    system.addPassengerToFlight("AA101", 1, "John Smith");
    system.addPassengerToFlight("AA101", 2, "Jane Doe");

    system.addPassengerToFlight("BA202", 3, "Alice Brown");
    
    system.displayFlights();
    
    system.updateFlight("AA101", "Boston");
    
    system.deletePassengerFromFlight("AA101", 1);
    
    system.displayFlights();
    
    system.deleteFlight("BA202");
    
    system.displayFlights();
    
    return 0;
}