#include <iostream>
#include <vector>
#include <string>

class Passenger {
public:
    int id;
    std::string name;

    Passenger(int i, std::string n) : id(i), name(n) {}
};

class Flight {
public:
    int flightNumber;
    std::string destination;

    Flight(int num, std::string dest) : flightNumber(num), destination(dest) {}
};

class AirlineBookingSystem {
    std::vector<Passenger> passengers;
    std::vector<Flight> flights;
    
public:
    void addPassenger(int id, std::string name) {
        passengers.push_back(Passenger(id, name));
    }
    
    void deletePassenger(int id) {
        for (auto it = passengers.begin(); it != passengers.end(); ++it) {
            if (it->id == id) {
                passengers.erase(it);
                break;
            }
        }
    }

    void updatePassenger(int id, std::string newName) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                passenger.name = newName;
                break;
            }
        }
    }

    Passenger* searchPassenger(int id) {
        for (auto &passenger : passengers) {
            if (passenger.id == id) {
                return &passenger;
            }
        }
        return nullptr;
    }

    void addFlight(int number, std::string destination) {
        flights.push_back(Flight(number, destination));
    }
    
    void deleteFlight(int number) {
        for (auto it = flights.begin(); it != flights.end(); ++it) {
            if (it->flightNumber == number) {
                flights.erase(it);
                break;
            }
        }
    }
    
    void updateFlight(int number, std::string newDestination) {
        for (auto &flight : flights) {
            if (flight.flightNumber == number) {
                flight.destination = newDestination;
                break;
            }
        }
    }

    Flight* searchFlight(int number) {
        for (auto &flight : flights) {
            if (flight.flightNumber == number) {
                return &flight;
            }
        }
        return nullptr;
    }

    void displayPassengers() {
        for (auto &passenger : passengers) {
            std::cout << "Passenger ID: " << passenger.id << ", Name: " << passenger.name << "\n";
        }
    }

    void displayFlights() {
        for (auto &flight : flights) {
            std::cout << "Flight Number: " << flight.flightNumber << ", Destination: " << flight.destination << "\n";
        }
    }
};

int main() {
    AirlineBookingSystem system;
    
    system.addPassenger(1, "Alice");
    system.addPassenger(2, "Bob");

    system.addFlight(101, "New York");
    system.addFlight(102, "Los Angeles");

    system.displayPassengers();
    system.displayFlights();

    system.updatePassenger(1, "Alice Smith");
    system.updateFlight(101, "Chicago");

    Passenger* p = system.searchPassenger(1);
    if (p) {
        std::cout << "Found Passenger: " << p->id << ", " << p->name << "\n";
    }

    Flight* f = system.searchFlight(101);
    if (f) {
        std::cout << "Found Flight: " << f->flightNumber << ", " << f->destination << "\n";
    }

    system.deletePassenger(2);
    system.deleteFlight(102);

    system.displayPassengers();
    system.displayFlights();
    
    return 0;
}