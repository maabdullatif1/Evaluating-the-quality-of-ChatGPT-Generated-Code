#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Attraction {
public:
    string name;
    string location;
    string description;

    Attraction(string n, string l, string d) : name(n), location(l), description(d) {}
};

class Tourist {
public:
    string name;
    int age;
    string nationality;

    Tourist(string n, int a, string nat) : name(n), age(a), nationality(nat) {}
};

class TourismGuide {
private:
    vector<Tourist> tourists;
    vector<Attraction> attractions;

public:
    void addTourist(string name, int age, string nationality) {
        tourists.push_back(Tourist(name, age, nationality));
    }

    void removeTourist(string name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(string oldName, string newName, int age, string nationality) {
        for (auto &tourist : tourists) {
            if (tourist.name == oldName) {
                tourist.name = newName;
                tourist.age = age;
                tourist.nationality = nationality;
                break;
            }
        }
    }

    void searchTourist(string name) {
        for (const auto &tourist : tourists) {
            if (tourist.name == name) {
                cout << "Found Tourist: " << tourist.name << ", Age: " << tourist.age
                     << ", Nationality: " << tourist.nationality << endl;
                return;
            }
        }
        cout << "Tourist not found" << endl;
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            cout << "Tourist: " << tourist.name << ", Age: " << tourist.age
                 << ", Nationality: " << tourist.nationality << endl;
        }
    }

    void addAttraction(string name, string location, string description) {
        attractions.push_back(Attraction(name, location, description));
    }

    void removeAttraction(string name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(string oldName, string newName, string location, string description) {
        for (auto &attraction : attractions) {
            if (attraction.name == oldName) {
                attraction.name = newName;
                attraction.location = location;
                attraction.description = description;
                break;
            }
        }
    }

    void searchAttraction(string name) {
        for (const auto &attraction : attractions) {
            if (attraction.name == name) {
                cout << "Found Attraction: " << attraction.name << ", Location: " << attraction.location
                     << ", Description: " << attraction.description << endl;
                return;
            }
        }
        cout << "Attraction not found" << endl;
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            cout << "Attraction: " << attraction.name << ", Location: " << attraction.location
                 << ", Description: " << attraction.description << endl;
        }
    }
};

int main() {
    TourismGuide guide;

    guide.addTourist("Alice Johnson", 30, "American");
    guide.addTourist("Bob Smith", 40, "British");
    guide.displayTourists();

    guide.addAttraction("Eiffel Tower", "Paris", "Iconic symbol of France");
    guide.addAttraction("Great Wall of China", "China", "Ancient world wonder");
    guide.displayAttractions();

    guide.searchTourist("Alice Johnson");
    guide.searchAttraction("Eiffel Tower");

    guide.updateTourist("Alice Johnson", "Alice Cooper", 31, "Canadian");
    guide.updateAttraction("Eiffel Tower", "The Eiffel Tower", "Paris", "Famous landmark in Paris");
    guide.displayTourists();
    guide.displayAttractions();

    guide.removeTourist("Bob Smith");
    guide.removeAttraction("Great Wall of China");
    guide.displayTourists();
    guide.displayAttractions();

    return 0;
}