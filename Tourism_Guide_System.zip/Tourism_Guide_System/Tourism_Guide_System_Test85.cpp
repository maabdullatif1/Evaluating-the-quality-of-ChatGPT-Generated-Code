#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;

    Attraction(std::string n, std::string l, std::string d) : name(n), location(l), description(d) {}
};

class Tourist {
public:
    std::string name;
    std::string country;

    Tourist(std::string n, std::string c) : name(n), country(c) {}
};

class TourismGuideSystem {
private:
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;

public:
    void addAttraction(std::string name, std::string location, std::string description) {
        attractions.push_back(Attraction(name, location, description));
    }

    void addTourist(std::string name, std::string country) {
        tourists.push_back(Tourist(name, country));
    }

    void deleteAttraction(std::string name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void deleteTourist(std::string name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateAttraction(std::string name, std::string newLocation, std::string newDescription) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                attraction.location = newLocation;
                attraction.description = newDescription;
                break;
            }
        }
    }

    void updateTourist(std::string name, std::string newCountry) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                tourist.country = newCountry;
                break;
            }
        }
    }

    void searchAttraction(std::string name) {
        for (const auto& attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Attraction Found: " << name << ", Location: " << attraction.location
                          << ", Description: " << attraction.description << "\n";
                return;
            }
        }
        std::cout << "Attraction not found.\n";
    }

    void searchTourist(std::string name) {
        for (const auto& tourist : tourists) {
            if (tourist.name == name) {
                std::cout << "Tourist Found: " << name << ", Country: " << tourist.country << "\n";
                return;
            }
        }
        std::cout << "Tourist not found.\n";
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "Attraction: " << attraction.name << ", Location: " << attraction.location
                      << ", Description: " << attraction.description << "\n";
        }
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Tourist: " << tourist.name << ", Country: " << tourist.country << "\n";
        }
    }
};

int main() {
    TourismGuideSystem system;
    system.addAttraction("Eiffel Tower", "Paris", "Iconic symbol of France");
    system.addTourist("John Doe", "USA");
    
    system.displayAttractions();
    system.displayTourists();
    
    system.searchAttraction("Eiffel Tower");
    system.searchTourist("John Doe");
    
    system.updateAttraction("Eiffel Tower", "Paris, France", "Iconic iron lattice tower");
    system.updateTourist("John Doe", "United States");
    
    system.deleteAttraction("Eiffel Tower");
    system.deleteTourist("John Doe");
    
    system.displayAttractions();
    system.displayTourists();
    
    return 0;
}