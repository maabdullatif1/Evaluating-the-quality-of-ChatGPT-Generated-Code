#include <iostream>
#include <vector>
#include <string>

struct Tourist {
    std::string name;
    std::string country;
    int age;
};

struct Attraction {
    std::string name;
    std::string location;
    std::string description;
};

std::vector<Tourist> tourists;
std::vector<Attraction> attractions;

void addTourist() {
    Tourist t;
    std::cout << "Enter tourist name: ";
    std::cin >> t.name;
    std::cout << "Enter country of origin: ";
    std::cin >> t.country;
    std::cout << "Enter age: ";
    std::cin >> t.age;
    tourists.push_back(t);
}

void addAttraction() {
    Attraction a;
    std::cout << "Enter attraction name: ";
    std::cin >> a.name;
    std::cout << "Enter location: ";
    std::cin >> a.location;
    std::cout << "Enter description: ";
    std::cin.ignore();
    std::getline(std::cin, a.description);
    attractions.push_back(a);
}

void deleteTourist() {
    std::string name;
    std::cout << "Enter the name of the tourist to delete: ";
    std::cin >> name;
    for (auto it = tourists.begin(); it != tourists.end(); ++it) {
        if (it->name == name) {
            tourists.erase(it);
            std::cout << "Tourist deleted.\n";
            return;
        }
    }
    std::cout << "Tourist not found.\n";
}

void deleteAttraction() {
    std::string name;
    std::cout << "Enter the name of the attraction to delete: ";
    std::cin >> name;
    for (auto it = attractions.begin(); it != attractions.end(); ++it) {
        if (it->name == name) {
            attractions.erase(it);
            std::cout << "Attraction deleted.\n";
            return;
        }
    }
    std::cout << "Attraction not found.\n";
}

void updateTourist() {
    std::string name;
    std::cout << "Enter the name of the tourist to update: ";
    std::cin >> name;
    for (auto &t : tourists) {
        if (t.name == name) {
            std::cout << "Enter new country of origin: ";
            std::cin >> t.country;
            std::cout << "Enter new age: ";
            std::cin >> t.age;
            std::cout << "Tourist updated.\n";
            return;
        }
    }
    std::cout << "Tourist not found.\n";
}

void updateAttraction() {
    std::string name;
    std::cout << "Enter the name of the attraction to update: ";
    std::cin >> name;
    for (auto &a : attractions) {
        if (a.name == name) {
            std::cout << "Enter new location: ";
            std::cin >> a.location;
            std::cout << "Enter new description: ";
            std::cin.ignore();
            std::getline(std::cin, a.description);
            std::cout << "Attraction updated.\n";
            return;
        }
    }
    std::cout << "Attraction not found.\n";
}

void searchTourist() {
    std::string name;
    std::cout << "Enter the name of the tourist to search: ";
    std::cin >> name;
    for (const auto &t : tourists) {
        if (t.name == name) {
            std::cout << "Tourist found: " << t.name << ", " << t.country << ", " << t.age << "\n";
            return;
        }
    }
    std::cout << "Tourist not found.\n";
}

void searchAttraction() {
    std::string name;
    std::cout << "Enter the name of the attraction to search: ";
    std::cin >> name;
    for (const auto &a : attractions) {
        if (a.name == name) {
            std::cout << "Attraction found: " << a.name << ", " << a.location << ", " << a.description << "\n";
            return;
        }
    }
    std::cout << "Attraction not found.\n";
}

void displayTourists() {
    std::cout << "Tourists:\n";
    for (const auto &t : tourists) {
        std::cout << t.name << ", " << t.country << ", " << t.age << "\n";
    }
}

void displayAttractions() {
    std::cout << "Attractions:\n";
    for (const auto &a : attractions) {
        std::cout << a.name << ", " << a.location << ", " << a.description << "\n";
    }
}

int main() {
    int choice;
    do {
        std::cout << "Tourism Guide System\n";
        std::cout << "1. Add Tourist\n2. Add Attraction\n3. Delete Tourist\n4. Delete Attraction\n";
        std::cout << "5. Update Tourist\n6. Update Attraction\n7. Search Tourist\n8. Search Attraction\n";
        std::cout << "9. Display Tourists\n10. Display Attractions\n0. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;
        switch (choice) {
            case 1: addTourist(); break;
            case 2: addAttraction(); break;
            case 3: deleteTourist(); break;
            case 4: deleteAttraction(); break;
            case 5: updateTourist(); break;
            case 6: updateAttraction(); break;
            case 7: searchTourist(); break;
            case 8: searchAttraction(); break;
            case 9: displayTourists(); break;
            case 10: displayAttractions(); break;
            case 0: break;
            default: std::cout << "Invalid choice.\n";
        }
    } while (choice != 0);
    return 0;
}