#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Attraction {
public:
    string name;
    string location;
    string description;
    Attraction(string name, string location, string description)
        : name(name), location(location), description(description) {}
};

class Tourist {
public:
    string name;
    int age;
    string nationality;
    Tourist(string name, int age, string nationality)
        : name(name), age(age), nationality(nationality) {}
};

class TourismGuide {
    vector<Tourist> tourists;
    vector<Attraction> attractions;

public:
    void addTourist() {
        string name, nationality;
        int age;
        cout << "Enter Tourist Name: ";
        cin.ignore();
        getline(cin, name);
        cout << "Enter Tourist Age: ";
        cin >> age;
        cout << "Enter Tourist Nationality: ";
        cin.ignore();
        getline(cin, nationality);
        tourists.push_back(Tourist(name, age, nationality));
    }

    void deleteTourist() {
        string name;
        cout << "Enter Tourist Name to Delete: ";
        cin.ignore();
        getline(cin, name);
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                cout << "Tourist Deleted.\n";
                return;
            }
        }
        cout << "Tourist Not Found.\n";
    }

    void updateTourist() {
        string name;
        cout << "Enter Tourist Name to Update: ";
        cin.ignore();
        getline(cin, name);
        for (auto &t : tourists) {
            if (t.name == name) {
                cout << "Enter New Age: ";
                cin >> t.age;
                cout << "Enter New Nationality: ";
                cin.ignore();
                getline(cin, t.nationality);
                cout << "Tourist Updated.\n";
                return;
            }
        }
        cout << "Tourist Not Found.\n";
    }

    void searchTourist() {
        string name;
        cout << "Enter Tourist Name to Search: ";
        cin.ignore();
        getline(cin, name);
        for (const auto &t : tourists) {
            if (t.name == name) {
                cout << "Name: " << t.name << ", Age: " << t.age
                     << ", Nationality: " << t.nationality << endl;
                return;
            }
        }
        cout << "Tourist Not Found.\n";
    }

    void displayTourists() {
        if (tourists.empty()) {
            cout << "No Tourists Available.\n";
            return;
        }
        for (const auto &t : tourists) {
            cout << "Name: " << t.name << ", Age: " << t.age
                 << ", Nationality: " << t.nationality << endl;
        }
    }

    void addAttraction() {
        string name, location, description;
        cout << "Enter Attraction Name: ";
        cin.ignore();
        getline(cin, name);
        cout << "Enter Attraction Location: ";
        getline(cin, location);
        cout << "Enter Attraction Description: ";
        getline(cin, description);
        attractions.push_back(Attraction(name, location, description));
    }

    void deleteAttraction() {
        string name;
        cout << "Enter Attraction Name to Delete: ";
        cin.ignore();
        getline(cin, name);
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                cout << "Attraction Deleted.\n";
                return;
            }
        }
        cout << "Attraction Not Found.\n";
    }

    void updateAttraction() {
        string name;
        cout << "Enter Attraction Name to Update: ";
        cin.ignore();
        getline(cin, name);
        for (auto &a : attractions) {
            if (a.name == name) {
                cout << "Enter New Location: ";
                getline(cin, a.location);
                cout << "Enter New Description: ";
                getline(cin, a.description);
                cout << "Attraction Updated.\n";
                return;
            }
        }
        cout << "Attraction Not Found.\n";
    }

    void searchAttraction() {
        string name;
        cout << "Enter Attraction Name to Search: ";
        cin.ignore();
        getline(cin, name);
        for (const auto &a : attractions) {
            if (a.name == name) {
                cout << "Name: " << a.name << ", Location: " << a.location
                     << ", Description: " << a.description << endl;
                return;
            }
        }
        cout << "Attraction Not Found.\n";
    }

    void displayAttractions() {
        if (attractions.empty()) {
            cout << "No Attractions Available.\n";
            return;
        }
        for (const auto &a : attractions) {
            cout << "Name: " << a.name << ", Location: " << a.location
                 << ", Description: " << a.description << endl;
        }
    }
};

int main() {
    TourismGuide guide;
    int choice;
    while (true) {
        cout << "1. Add Tourist\n2. Delete Tourist\n3. Update Tourist\n4. Search Tourist\n";
        cout << "5. Display Tourists\n6. Add Attraction\n7. Delete Attraction\n";
        cout << "8. Update Attraction\n9. Search Attraction\n10. Display Attractions\n11. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1: guide.addTourist(); break;
        case 2: guide.deleteTourist(); break;
        case 3: guide.updateTourist(); break;
        case 4: guide.searchTourist(); break;
        case 5: guide.displayTourists(); break;
        case 6: guide.addAttraction(); break;
        case 7: guide.deleteAttraction(); break;
        case 8: guide.updateAttraction(); break;
        case 9: guide.searchAttraction(); break;
        case 10: guide.displayAttractions(); break;
        case 11: return 0;
        default: cout << "Invalid Choice. Try Again.\n";
        }
    }
    return 0;
}