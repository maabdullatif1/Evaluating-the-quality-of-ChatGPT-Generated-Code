#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    int id;
    std::string name;
    std::string description;

    Attraction(int id, std::string name, std::string description)
        : id(id), name(name), description(description) {}
};

class Tourist {
public:
    int id;
    std::string name;
    std::string contactInfo;

    Tourist(int id, std::string name, std::string contactInfo)
        : id(id), name(name), contactInfo(contactInfo) {}
};

class TourismGuideSystem {
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;

public:
    void addAttraction(int id, std::string name, std::string description) {
        attractions.push_back(Attraction(id, name, description));
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(int id, std::string name, std::string description) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.description = description;
                break;
            }
        }
    }

    Attraction* searchAttraction(int id) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            std::cout << "ID: " << attraction.id << ", Name: " << attraction.name
                      << ", Description: " << attraction.description << std::endl;
        }
    }

    void addTourist(int id, std::string name, std::string contactInfo) {
        tourists.push_back(Tourist(id, name, contactInfo));
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(int id, std::string name, std::string contactInfo) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.contactInfo = contactInfo;
                break;
            }
        }
    }

    Tourist* searchTourist(int id) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            std::cout << "ID: " << tourist.id << ", Name: " << tourist.name
                      << ", Contact Info: " << tourist.contactInfo << std::endl;
        }
    }
};

int main() {
    TourismGuideSystem system;
    
    system.addAttraction(1, "Eiffel Tower", "Famous landmark in Paris");
    system.addTourist(1, "John Doe", "john@example.com");
    
    system.displayAttractions();
    system.displayTourists();
 
    system.updateAttraction(1, "Eiffel Tower", "Iconic Parisian landmark");
    system.updateTourist(1, "John Doe", "john.doe@example.com");
    
    system.displayAttractions();
    system.displayTourists();
    
    Attraction* attraction = system.searchAttraction(1);
    if (attraction) {
        std::cout << "Found attraction: " << attraction->name << std::endl;
    }

    Tourist* tourist = system.searchTourist(1);
    if (tourist) {
        std::cout << "Found tourist: " << tourist->name << std::endl;
    }

    system.deleteAttraction(1);
    system.deleteTourist(1);
    
    system.displayAttractions();
    system.displayTourists();
    
    return 0;
}