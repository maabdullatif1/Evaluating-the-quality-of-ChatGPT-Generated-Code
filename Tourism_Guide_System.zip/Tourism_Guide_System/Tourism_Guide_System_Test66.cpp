#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;

    Attraction(const std::string& name, const std::string& location, const std::string& description)
        : name(name), location(location), description(description) {}
};

class Tourist {
public:
    std::string name;
    std::string email;
    int age;

    Tourist(const std::string& name, const std::string& email, int age)
        : name(name), email(email), age(age) {}
};

class TourismGuide {
private:
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;

public:
    void addAttraction(const Attraction& attraction) {
        attractions.push_back(attraction);
    }

    void deleteAttraction(const std::string& name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(const std::string& name, const std::string& newLocation, const std::string& newDescription) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                attraction.location = newLocation;
                attraction.description = newDescription;
                break;
            }
        }
    }

    Attraction* searchAttraction(const std::string& name) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayAttractions() const {
        for (const auto& attraction : attractions) {
            std::cout << "Name: " << attraction.name 
                      << ", Location: " << attraction.location 
                      << ", Description: " << attraction.description << "\n";
        }
    }

    void addTourist(const Tourist& tourist) {
        tourists.push_back(tourist);
    }

    void deleteTourist(const std::string& name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(const std::string& name, const std::string& newEmail, int newAge) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                tourist.email = newEmail;
                tourist.age = newAge;
                break;
            }
        }
    }

    Tourist* searchTourist(const std::string& name) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void displayTourists() const {
        for (const auto& tourist : tourists) {
            std::cout << "Name: " << tourist.name 
                      << ", Email: " << tourist.email 
                      << ", Age: " << tourist.age << "\n";
        }
    }
};

int main() {
    TourismGuide guide;

    guide.addAttraction(Attraction("Eiffel Tower", "Paris", "Iconic landmark of Paris"));
    guide.addAttraction(Attraction("Statue of Liberty", "New York", "Symbol of freedom in the USA"));
    guide.displayAttractions();

    guide.addTourist(Tourist("John Doe", "john@example.com", 30));
    guide.addTourist(Tourist("Jane Smith", "jane@example.com", 25));
    guide.displayTourists();

    return 0;
}