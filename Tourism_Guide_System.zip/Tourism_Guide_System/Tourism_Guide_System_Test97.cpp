#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    std::string name;
    std::string nationality;
    int age;

    Tourist(std::string n, std::string nat, int a) : name(n), nationality(nat), age(a) {}
};

class Attraction {
public:
    std::string name;
    std::string location;
    double rating;

    Attraction(std::string n, std::string loc, double r) : name(n), location(loc), rating(r) {}
};

class TourismGuide {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(std::string name, std::string nationality, int age) {
        tourists.push_back(Tourist(name, nationality, age));
    }

    void deleteTourist(std::string name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(std::string oldName, std::string newName, std::string nationality, int age) {
        for (auto& tourist : tourists) {
            if (tourist.name == oldName) {
                tourist.name = newName;
                tourist.nationality = nationality;
                tourist.age = age;
                break;
            }
        }
    }

    void searchTourist(std::string name) {
        for (const auto& tourist : tourists) {
            if (tourist.name == name) {
                std::cout << "Tourist found: " << tourist.name << ", " << tourist.nationality << ", " << tourist.age << "\n";
                return;
            }
        }
        std::cout << "Tourist not found.\n";
    }

    void addAttraction(std::string name, std::string location, double rating) {
        attractions.push_back(Attraction(name, location, rating));
    }

    void deleteAttraction(std::string name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(std::string oldName, std::string newName, std::string location, double rating) {
        for (auto& attraction : attractions) {
            if (attraction.name == oldName) {
                attraction.name = newName;
                attraction.location = location;
                attraction.rating = rating;
                break;
            }
        }
    }

    void searchAttraction(std::string name) {
        for (const auto& attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Attraction found: " << attraction.name << ", " << attraction.location << ", " << attraction.rating << "\n";
                return;
            }
        }
        std::cout << "Attraction not found.\n";
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Tourist: " << tourist.name << ", " << tourist.nationality << ", " << tourist.age << "\n";
        }
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "Attraction: " << attraction.name << ", " << attraction.location << ", " << attraction.rating << "\n";
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist("John Doe", "American", 30);
    guide.addTourist("Jane Smith", "British", 25);

    guide.addAttraction("Eiffel Tower", "Paris", 4.5);
    guide.addAttraction("Statue of Liberty", "New York", 4.7);

    guide.searchTourist("John Doe");
    guide.searchAttraction("Statue of Liberty");

    guide.displayTourists();
    guide.displayAttractions();

    guide.updateTourist("John Doe", "John M. Doe", "American", 31);
    guide.updateAttraction("Eiffel Tower", "Eiffel Tower Landmark", "Paris", 4.6);

    guide.displayTourists();
    guide.displayAttractions();

    guide.deleteTourist("Jane Smith");
    guide.deleteAttraction("Statue of Liberty");

    guide.displayTourists();
    guide.displayAttractions();

    return 0;
}