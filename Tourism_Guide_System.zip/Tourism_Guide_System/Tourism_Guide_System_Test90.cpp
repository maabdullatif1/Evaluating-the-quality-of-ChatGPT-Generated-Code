#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    int id;
    std::string name;
    std::string nationality;

    Tourist(int id, std::string name, std::string nationality)
        : id(id), name(name), nationality(nationality) {}
};

class Attraction {
public:
    int id;
    std::string name;
    std::string location;

    Attraction(int id, std::string name, std::string location)
        : id(id), name(name), location(location) {}
};

class TourismGuideSystem {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;
    int tourist_id_counter;
    int attraction_id_counter;

public:
    TourismGuideSystem() : tourist_id_counter(0), attraction_id_counter(0) {}

    void addTourist(const std::string& name, const std::string& nationality) {
        tourists.push_back(Tourist(++tourist_id_counter, name, nationality));
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(int id, const std::string& name, const std::string& nationality) {
        for (auto& tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.nationality = nationality;
                break;
            }
        }
    }

    Tourist* searchTourist(int id) {
        for (auto& tourist : tourists) {
            if (tourist.id == id) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "ID: " << tourist.id << ", Name: " << tourist.name << ", Nationality: " << tourist.nationality << std::endl;
        }
    }

    void addAttraction(const std::string& name, const std::string& location) {
        attractions.push_back(Attraction(++attraction_id_counter, name, location));
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(int id, const std::string& name, const std::string& location) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.location = location;
                break;
            }
        }
    }

    Attraction* searchAttraction(int id) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "ID: " << attraction.id << ", Name: " << attraction.name << ", Location: " << attraction.location << std::endl;
        }
    }
};

int main() {
    TourismGuideSystem system;

    system.addTourist("John Doe", "American");
    system.addTourist("Jane Smith", "British");

    system.displayTourists();

    system.addAttraction("Eiffel Tower", "Paris");
    system.addAttraction("Statue of Liberty", "New York");

    system.displayAttractions();

    Tourist* tourist = system.searchTourist(1);
    if (tourist != nullptr) {
        std::cout << "Found Tourist - ID: " << tourist->id << ", Name: " << tourist->name << std::endl;
    }

    Attraction* attraction = system.searchAttraction(1);
    if (attraction != nullptr) {
        std::cout << "Found Attraction - ID: " << attraction->id << ", Name: " << attraction->name << std::endl;
    }

    system.updateTourist(1, "Johnathan Doe", "American");
    system.updateAttraction(1, "Eiffel Tower", "Paris, France");

    system.displayTourists();
    system.displayAttractions();

    system.deleteTourist(2);
    system.deleteAttraction(2);

    system.displayTourists();
    system.displayAttractions();

    return 0;
}