#include <iostream>
#include <vector>
#include <string>

class Tourist {
private:
    std::string name;
    std::string nationality;

public:
    Tourist(std::string name, std::string nationality) : name(name), nationality(nationality) {}

    std::string getName() const { return name; }
    std::string getNationality() const { return nationality; }
    void setName(const std::string& newName) { name = newName; }
    void setNationality(const std::string& newNationality) { nationality = newNationality; }
};

class Attraction {
private:
    std::string name;
    std::string location;

public:
    Attraction(std::string name, std::string location) : name(name), location(location) {}

    std::string getName() const { return name; }
    std::string getLocation() const { return location; }
    void setName(const std::string& newName) { name = newName; }
    void setLocation(const std::string& newLocation) { location = newLocation; }
};

class TourismGuide {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(const Tourist& tourist) { tourists.push_back(tourist); }
    void addAttraction(const Attraction& attraction) { attractions.push_back(attraction); }

    void deleteTourist(const std::string& name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->getName() == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void deleteAttraction(const std::string& name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->getName() == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateTourist(const std::string& name, const Tourist& newTourist) {
        for (auto& tourist : tourists) {
            if (tourist.getName() == name) {
                tourist.setName(newTourist.getName());
                tourist.setNationality(newTourist.getNationality());
                break;
            }
        }
    }

    void updateAttraction(const std::string& name, const Attraction& newAttraction) {
        for (auto& attraction : attractions) {
            if (attraction.getName() == name) {
                attraction.setName(newAttraction.getName());
                attraction.setLocation(newAttraction.getLocation());
                break;
            }
        }
    }

    Tourist* searchTourist(const std::string& name) {
        for (auto& tourist : tourists) {
            if (tourist.getName() == name) {
                return &tourist;
            }
        }
        return nullptr;
    }

    Attraction* searchAttraction(const std::string& name) {
        for (auto& attraction : attractions) {
            if (attraction.getName() == name) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayTourists() const {
        for (const auto& tourist : tourists) {
            std::cout << "Name: " << tourist.getName() << ", Nationality: " << tourist.getNationality() << std::endl;
        }
    }

    void displayAttractions() const {
        for (const auto& attraction : attractions) {
            std::cout << "Name: " << attraction.getName() << ", Location: " << attraction.getLocation() << std::endl;
        }
    }
};

int main() {
    TourismGuide guide;
    
    Tourist tourist1("John Doe", "American");
    Tourist tourist2("Jane Smith", "British");
    
    guide.addTourist(tourist1);
    guide.addTourist(tourist2);
    
    Attraction attraction1("Eiffel Tower", "Paris");
    Attraction attraction2("Statue of Liberty", "New York");
    
    guide.addAttraction(attraction1);
    guide.addAttraction(attraction2);
    
    guide.displayTourists();
    guide.displayAttractions();
    
    guide.updateTourist("John Doe", {"John Doe", "Canadian"});
    guide.updateAttraction("Eiffel Tower", {"Eiffel Tower", "France"});
    
    guide.displayTourists();
    guide.displayAttractions();
    
    guide.deleteTourist("Jane Smith");
    guide.deleteAttraction("Statue of Liberty");
    
    guide.displayTourists();
    guide.displayAttractions();
    
    return 0;
}