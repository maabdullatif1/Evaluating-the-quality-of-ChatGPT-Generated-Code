#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Attraction {
public:
    int id;
    string name;
    string description;
    
    Attraction(int id, string name, string description)
        : id(id), name(name), description(description) {}
};

class Tourist {
public:
    int id;
    string name;
    int age;
    string country;
    
    Tourist(int id, string name, int age, string country)
        : id(id), name(name), age(age), country(country) {}
};

class TourismGuide {
    vector<Attraction> attractions;
    vector<Tourist> tourists;
    int nextAttractionId;
    int nextTouristId;
    
public:
    TourismGuide() : nextAttractionId(1), nextTouristId(1) {}

    void addAttraction(string name, string description) {
        attractions.push_back(Attraction(nextAttractionId++, name, description));
    }
    
    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                return;
            }
        }
    }

    void updateAttraction(int id, string name, string description) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.description = description;
                return;
            }
        }
    }
    
    void searchAttraction(string name) {
        for (const auto &attraction : attractions) {
            if (attraction.name == name) {
                cout << "Attraction Found: Id: " << attraction.id << ", Name: " << attraction.name << ", Description: " << attraction.description << endl;
                return;
            }
        }
        cout << "Attraction not found" << endl;
    }
    
    void displayAttractions() {
        for (const auto &attraction : attractions) {
            cout << "Id: " << attraction.id << ", Name: " << attraction.name << ", Description: " << attraction.description << endl;
        }
    }
    
    void addTourist(string name, int age, string country) {
        tourists.push_back(Tourist(nextTouristId++, name, age, country));
    }
    
    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                return;
            }
        }
    }

    void updateTourist(int id, string name, int age, string country) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.age = age;
                tourist.country = country;
                return;
            }
        }
    }
    
    void searchTourist(string name) {
        for (const auto &tourist : tourists) {
            if (tourist.name == name) {
                cout << "Tourist Found: Id: " << tourist.id << ", Name: " << tourist.name << ", Age: " << tourist.age << ", Country: " << tourist.country << endl;
                return;
            }
        }
        cout << "Tourist not found" << endl;
    }
    
    void displayTourists() {
        for (const auto &tourist : tourists) {
            cout << "Id: " << tourist.id << ", Name: " << tourist.name << ", Age: " << tourist.age << ", Country: " << tourist.country << endl;
        }
    }
};

int main() {
    TourismGuide guide;

    guide.addAttraction("Eiffel Tower", "An iconic tower in Paris.");
    guide.addAttraction("Statue of Liberty", "A historic monument in New York City.");

    guide.displayAttractions();

    guide.addTourist("Alice", 30, "USA");
    guide.addTourist("Bob", 24, "UK");

    guide.displayTourists();

    guide.searchAttraction("Eiffel Tower");
    guide.searchTourist("Alice");

    guide.updateAttraction(1, "Eiffel Tower", "The most iconic tower in Paris.");
    guide.updateTourist(1, "Alice", 31, "USA");

    guide.displayAttractions();
    guide.displayTourists();

    guide.deleteAttraction(2);
    guide.deleteTourist(2);

    guide.displayAttractions();
    guide.displayTourists();

    return 0;
}