#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Attraction {
public:
    string name;
    string description;
    string location;

    Attraction(string name, string description, string location) {
        this->name = name;
        this->description = description;
        this->location = location;
    }
};

class Tourist {
public:
    string name;
    string email;
    string phone;

    Tourist(string name, string email, string phone) {
        this->name = name;
        this->email = email;
        this->phone = phone;
    }
};

class TourismGuideSystem {
    vector<Attraction> attractions;
    vector<Tourist> tourists;

    int findAttractionIndex(string name) {
        for (int i = 0; i < attractions.size(); i++) {
            if (attractions[i].name == name) {
                return i;
            }
        }
        return -1;
    }

    int findTouristIndex(string name) {
        for (int i = 0; i < tourists.size(); i++) {
            if (tourists[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addAttraction(string name, string description, string location) {
        attractions.push_back(Attraction(name, description, location));
    }

    void deleteAttraction(string name) {
        int index = findAttractionIndex(name);
        if (index != -1) {
            attractions.erase(attractions.begin() + index);
        } else {
            cout << "Attraction not found." << endl;
        }
    }

    void updateAttraction(string name, string newDescription, string newLocation) {
        int index = findAttractionIndex(name);
        if (index != -1) {
            attractions[index].description = newDescription;
            attractions[index].location = newLocation;
        } else {
            cout << "Attraction not found." << endl;
        }
    }

    void searchAttraction(string name) {
        int index = findAttractionIndex(name);
        if (index != -1) {
            cout << "Attraction: " << attractions[index].name << endl
                 << "Description: " << attractions[index].description << endl
                 << "Location: " << attractions[index].location << endl;
        } else {
            cout << "Attraction not found." << endl;
        }
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            cout << "Attraction: " << attraction.name << endl
                 << "Description: " << attraction.description << endl
                 << "Location: " << attraction.location << endl
                 << "------------------------------" << endl;
        }
    }

    void addTourist(string name, string email, string phone) {
        tourists.push_back(Tourist(name, email, phone));
    }

    void deleteTourist(string name) {
        int index = findTouristIndex(name);
        if (index != -1) {
            tourists.erase(tourists.begin() + index);
        } else {
            cout << "Tourist not found." << endl;
        }
    }

    void updateTourist(string name, string newEmail, string newPhone) {
        int index = findTouristIndex(name);
        if (index != -1) {
            tourists[index].email = newEmail;
            tourists[index].phone = newPhone;
        } else {
            cout << "Tourist not found." << endl;
        }
    }

    void searchTourist(string name) {
        int index = findTouristIndex(name);
        if (index != -1) {
            cout << "Tourist: " << tourists[index].name << endl
                 << "Email: " << tourists[index].email << endl
                 << "Phone: " << tourists[index].phone << endl;
        } else {
            cout << "Tourist not found." << endl;
        }
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            cout << "Tourist: " << tourist.name << endl
                 << "Email: " << tourist.email << endl
                 << "Phone: " << tourist.phone << endl
                 << "------------------------------" << endl;
        }
    }
};

int main() {
    TourismGuideSystem system;

    system.addAttraction("Eiffel Tower", "Iconic French landmark in Paris.", "Paris, France");
    system.addTourist("John Doe", "john@example.com", "123456789");

    system.displayAttractions();
    system.displayTourists();

    return 0;
}