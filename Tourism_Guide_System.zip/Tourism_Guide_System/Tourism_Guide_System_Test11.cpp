#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    std::string name;
    int id;

    Tourist(int id, std::string name) : id(id), name(name) {}
};

class Attraction {
public:
    std::string name;
    std::string location;
    int id;

    Attraction(int id, std::string name, std::string location) 
        : id(id), name(name), location(location) {}
};

class TourismGuideSystem {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

    Tourist* findTouristById(int id) {
        for (auto& tourist : tourists) {
            if (tourist.id == id) {
                return &tourist;
            }
        }
        return nullptr;
    }

    Attraction* findAttractionById(int id) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) {
                return &attraction;
            }
        }
        return nullptr;
    }

public:
    void addTourist(int id, std::string name) {
        tourists.emplace_back(id, name);
    }

    void addAttraction(int id, std::string name, std::string location) {
        attractions.emplace_back(id, name, location);
    }

    bool deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                return true;
            }
        }
        return false;
    }

    bool deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                return true;
            }
        }
        return false;
    }

    bool updateTourist(int id, std::string newName) {
        Tourist* tourist = findTouristById(id);
        if (tourist) {
            tourist->name = newName;
            return true;
        }
        return false;
    }

    bool updateAttraction(int id, std::string newName, std::string newLocation) {
        Attraction* attraction = findAttractionById(id);
        if (attraction) {
            attraction->name = newName;
            attraction->location = newLocation;
            return true;
        }
        return false;
    }

    Tourist* searchTourist(int id) {
        return findTouristById(id);
    }

    Attraction* searchAttraction(int id) {
        return findAttractionById(id);
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "ID: " << tourist.id << ", Name: " << tourist.name << std::endl;
        }
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "ID: " << attraction.id << ", Name: " << attraction.name 
                      << ", Location: " << attraction.location << std::endl;
        }
    }
};

int main() {
    TourismGuideSystem tgs;
    tgs.addTourist(1, "John Doe");
    tgs.addAttraction(1, "Eiffel Tower", "Paris");

    tgs.displayTourists();
    tgs.displayAttractions();

    tgs.updateTourist(1, "Jane Doe");
    tgs.updateAttraction(1, "Eiffel Tower", "Paris, France");

    tgs.displayTourists();
    tgs.displayAttractions();

    tgs.deleteTourist(1);
    tgs.deleteAttraction(1);

    tgs.displayTourists();
    tgs.displayAttractions();

    return 0;
}