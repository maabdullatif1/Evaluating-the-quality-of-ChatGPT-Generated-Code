#include <iostream>
#include <vector>
#include <string>

struct Tourist {
    std::string name;
    int age;
    std::string nationality;
};

struct Attraction {
    std::string name;
    std::string location;
    std::string description;
};

std::vector<Tourist> tourists;
std::vector<Attraction> attractions;

void addTourist(const std::string& name, int age, const std::string& nationality) {
    tourists.push_back({name, age, nationality});
}

void addAttraction(const std::string& name, const std::string& location, const std::string& description) {
    attractions.push_back({name, location, description});
}

void deleteTourist(const std::string& name) {
    for (auto it = tourists.begin(); it != tourists.end(); ++it) {
        if (it->name == name) {
            tourists.erase(it);
            return;
        }
    }
}

void deleteAttraction(const std::string& name) {
    for (auto it = attractions.begin(); it != attractions.end(); ++it) {
        if (it->name == name) {
            attractions.erase(it);
            return;
        }
    }
}

void updateTourist(const std::string& name, int age, const std::string& nationality) {
    for (auto& t : tourists) {
        if (t.name == name) {
            t.age = age;
            t.nationality = nationality;
            return;
        }
    }
}

void updateAttraction(const std::string& name, const std::string& location, const std::string& description) {
    for (auto& a : attractions) {
        if (a.name == name) {
            a.location = location;
            a.description = description;
            return;
        }
    }
}

Tourist* searchTourist(const std::string& name) {
    for (auto& t : tourists) {
        if (t.name == name) {
            return &t;
        }
    }
    return nullptr;
}

Attraction* searchAttraction(const std::string& name) {
    for (auto& a : attractions) {
        if (a.name == name) {
            return &a;
        }
    }
    return nullptr;
}

void displayTourists() {
    for (const auto& t : tourists) {
        std::cout << "Name: " << t.name << ", Age: " << t.age << ", Nationality: " << t.nationality << "\n";
    }
}

void displayAttractions() {
    for (const auto& a : attractions) {
        std::cout << "Name: " << a.name << ", Location: " << a.location << ", Description: " << a.description << "\n";
    }
}

int main() {
    addTourist("John Doe", 30, "American");
    addAttraction("Eiffel Tower", "Paris", "Iconic French landmark");

    displayTourists();
    displayAttractions();

    updateTourist("John Doe", 31, "Canadian");
    updateAttraction("Eiffel Tower", "Paris", "Famous tower in Paris");

    if (Tourist* t = searchTourist("John Doe")) {
        std::cout << "Found tourist: " << t->name << "\n";
    }

    if (Attraction* a = searchAttraction("Eiffel Tower")) {
        std::cout << "Found attraction: " << a->name << "\n";
    }

    deleteTourist("John Doe");
    deleteAttraction("Eiffel Tower");

    displayTourists();
    displayAttractions();

    return 0;
}