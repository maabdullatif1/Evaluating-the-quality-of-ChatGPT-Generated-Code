#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;
    Attraction(std::string n, std::string l, std::string d) 
        : name(n), location(l), description(d) {}
};

class Tourist {
public:
    std::string name;
    int age;
    std::string nationality;
    Tourist(std::string n, int a, std::string nat) 
        : name(n), age(a), nationality(nat) {}
};

class TourismGuide {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;
public:
    void addTourist(std::string name, int age, std::string nationality) {
        tourists.push_back(Tourist(name, age, nationality));
    }

    void deleteTourist(std::string name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                return;
            }
        }
    }

    void updateTourist(std::string name, int age, std::string nationality) {
        for (auto& t : tourists) {
            if (t.name == name) {
                t.age = age;
                t.nationality = nationality;
                return;
            }
        }
    }

    void searchTourist(std::string name) {
        for (auto& t : tourists) {
            if (t.name == name) {
                std::cout << "Tourist: " << t.name << ", Age: " << t.age 
                          << ", Nationality: " << t.nationality << "\n";
                return;
            }
        }
        std::cout << "Tourist not found\n";
    }

    void displayTourists() {
        for (auto& t : tourists) {
            std::cout << "Tourist: " << t.name << ", Age: " << t.age 
                      << ", Nationality: " << t.nationality << "\n";
        }
    }

    void addAttraction(std::string name, std::string location, std::string description) {
        attractions.push_back(Attraction(name, location, description));
    }

    void deleteAttraction(std::string name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                return;
            }
        }
    }

    void updateAttraction(std::string name, std::string location, std::string description) {
        for (auto& a : attractions) {
            if (a.name == name) {
                a.location = location;
                a.description = description;
                return;
            }
        }
    }

    void searchAttraction(std::string name) {
        for (auto& a : attractions) {
            if (a.name == name) {
                std::cout << "Attraction: " << a.name << ", Location: " << a.location 
                          << ", Description: " << a.description << "\n";
                return;
            }
        }
        std::cout << "Attraction not found\n";
    }

    void displayAttractions() {
        for (auto& a : attractions) {
            std::cout << "Attraction: " << a.name << ", Location: " << a.location 
                      << ", Description: " << a.description << "\n";
        }
    }
};

int main() {
    TourismGuide guide;
    
    guide.addTourist("Alice", 30, "American");
    guide.addTourist("Bob", 25, "British");
    guide.displayTourists();
    
    guide.addAttraction("Eiffel Tower", "Paris", "Historic tower");
    guide.addAttraction("Great Wall", "China", "Ancient wall");
    guide.displayAttractions();
    
    guide.updateTourist("Alice", 31, "Canadian");
    guide.searchTourist("Alice");
    
    guide.updateAttraction("Great Wall", "Beijing", "World heritage site");
    guide.searchAttraction("Great Wall");
    
    guide.deleteTourist("Bob");
    guide.displayTourists();
    
    guide.deleteAttraction("Eiffel Tower");
    guide.displayAttractions();
    
    return 0;
}