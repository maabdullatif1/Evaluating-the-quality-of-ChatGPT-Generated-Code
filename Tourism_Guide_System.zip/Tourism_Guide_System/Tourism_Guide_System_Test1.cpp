#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    int id;
    std::string name;
    std::string email;

    Tourist(int tid, std::string tname, std::string temail) : id(tid), name(tname), email(temail) {}
};

class Attraction {
public:
    int id;
    std::string name;
    std::string location;

    Attraction(int aid, std::string aname, std::string alocation) : id(aid), name(aname), location(alocation) {}
};

class TourismGuideSystem {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(int id, std::string name, std::string email) {
        tourists.push_back(Tourist(id, name, email));
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                return;
            }
        }
    }

    void updateTourist(int id, std::string name, std::string email) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.email = email;
                return;
            }
        }
    }

    Tourist* searchTourist(int id) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            std::cout << "ID: " << tourist.id << ", Name: " << tourist.name << ", Email: " << tourist.email << std::endl;
        }
    }

    void addAttraction(int id, std::string name, std::string location) {
        attractions.push_back(Attraction(id, name, location));
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                return;
            }
        }
    }

    void updateAttraction(int id, std::string name, std::string location) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.location = location;
                return;
            }
        }
    }

    Attraction* searchAttraction(int id) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            std::cout << "ID: " << attraction.id << ", Name: " << attraction.name << ", Location: " << attraction.location << std::endl;
        }
    }
};

int main() {
    TourismGuideSystem system;

    system.addTourist(1, "John Doe", "john@example.com");
    system.addTourist(2, "Jane Smith", "jane@example.com");

    system.addAttraction(1, "Eiffel Tower", "Paris");
    system.addAttraction(2, "Statue of Liberty", "New York");

    system.displayTourists();
    system.displayAttractions();

    Tourist* tourist = system.searchTourist(1);
    if (tourist != nullptr) {
        std::cout << "Found tourist: " << tourist->name << std::endl;
    }

    system.updateAttraction(2, "Statue of Liberty", "USA");
    system.displayAttractions();

    system.deleteTourist(2);
    system.displayTourists();

    return 0;
}