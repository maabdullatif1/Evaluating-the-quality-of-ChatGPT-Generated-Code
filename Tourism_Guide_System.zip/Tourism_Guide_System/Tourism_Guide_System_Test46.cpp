#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Tourist {
public:
    int id;
    string name;
    string nationality;

    Tourist(int id, const string& name, const string& nationality)
        : id(id), name(name), nationality(nationality) {}
};

class Attraction {
public:
    int id;
    string name;
    string location;

    Attraction(int id, const string& name, const string& location)
        : id(id), name(name), location(location) {}
};

class TourismGuideSystem {
private:
    vector<Tourist> tourists;
    vector<Attraction> attractions;

public:
    void addTourist(int id, const string& name, const string& nationality) {
        tourists.emplace_back(id, name, nationality);
    }

    void deleteTourist(int id) {
        tourists.erase(remove_if(tourists.begin(), tourists.end(),
                     [id](Tourist& t) { return t.id == id; }), tourists.end());
    }

    void updateTourist(int id, const string& name, const string& nationality) {
        for (auto& tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.nationality = nationality;
                break;
            }
        }
    }

    void searchTourist(int id) {
        for (const auto& tourist : tourists) {
            if (tourist.id == id) {
                cout << "Tourist ID: " << tourist.id << ", Name: " << tourist.name
                     << ", Nationality: " << tourist.nationality << endl;
                return;
            }
        }
        cout << "Tourist not found" << endl;
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            cout << "ID: " << tourist.id << ", Name: " << tourist.name
                 << ", Nationality: " << tourist.nationality << endl;
        }
    }

    void addAttraction(int id, const string& name, const string& location) {
        attractions.emplace_back(id, name, location);
    }

    void deleteAttraction(int id) {
        attractions.erase(remove_if(attractions.begin(), attractions.end(),
                      [id](Attraction& a) { return a.id == id; }), attractions.end());
    }

    void updateAttraction(int id, const string& name, const string& location) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.location = location;
                break;
            }
        }
    }

    void searchAttraction(int id) {
        for (const auto& attraction : attractions) {
            if (attraction.id == id) {
                cout << "Attraction ID: " << attraction.id << ", Name: " << attraction.name
                     << ", Location: " << attraction.location << endl;
                return;
            }
        }
        cout << "Attraction not found" << endl;
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            cout << "ID: " << attraction.id << ", Name: " << attraction.name
                 << ", Location: " << attraction.location << endl;
        }
    }
};

int main() {
    TourismGuideSystem system;
    system.addTourist(1, "John Doe", "American");
    system.addTourist(2, "Jane Smith", "British");
    system.displayTourists();

    system.addAttraction(1, "Eiffel Tower", "Paris");
    system.addAttraction(2, "Great Wall", "China");
    system.displayAttractions();

    system.searchTourist(1);
    system.updateTourist(1, "Johnny Doe", "Canadian");
    system.searchTourist(1);

    system.searchAttraction(2);
    system.updateAttraction(2, "Great Wall of China", "Beijing");
    system.searchAttraction(2);

    system.deleteTourist(2);
    system.displayTourists();

    system.deleteAttraction(1);
    system.displayAttractions();

    return 0;
}