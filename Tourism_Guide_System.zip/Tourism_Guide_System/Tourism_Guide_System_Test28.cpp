#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Tourist {
public:
    string name;
    int age;
    string nationality;

    Tourist(string name, int age, string nationality) : name(name), age(age), nationality(nationality) {}
};

class Attraction {
public:
    string name;
    string location;
    double entranceFee;

    Attraction(string name, string location, double entranceFee) : name(name), location(location), entranceFee(entranceFee) {}
};

class TourismGuide {
private:
    vector<Tourist> tourists;
    vector<Attraction> attractions;

public:
    void addTourist(string name, int age, string nationality) {
        tourists.push_back(Tourist(name, age, nationality));
    }

    void deleteTourist(string name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(string name, int age, string nationality) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                tourist.age = age;
                tourist.nationality = nationality;
                break;
            }
        }
    }

    Tourist* searchTourist(string name) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            cout << "Name: " << tourist.name << ", Age: " << tourist.age << ", Nationality: " << tourist.nationality << endl;
        }
    }

    void addAttraction(string name, string location, double entranceFee) {
        attractions.push_back(Attraction(name, location, entranceFee));
    }

    void deleteAttraction(string name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(string name, string location, double entranceFee) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                attraction.location = location;
                attraction.entranceFee = entranceFee;
                break;
            }
        }
    }

    Attraction* searchAttraction(string name) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            cout << "Name: " << attraction.name << ", Location: " << attraction.location << ", Entrance Fee: " << attraction.entranceFee << endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist("Jane Doe", 30, "American");
    guide.addTourist("John Smith", 25, "British");
    guide.addAttraction("Eiffel Tower", "Paris", 25.0);
    guide.addAttraction("Statue of Liberty", "New York", 30.0);

    cout << "Tourists:" << endl;
    guide.displayTourists();
    
    cout << "\nAttractions:" << endl;
    guide.displayAttractions();

    return 0;
}