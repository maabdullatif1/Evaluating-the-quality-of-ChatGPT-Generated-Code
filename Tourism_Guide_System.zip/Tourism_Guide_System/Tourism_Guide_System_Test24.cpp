#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Tourist {
    int id;
    string name;
    string nationality;
};

struct Attraction {
    int id;
    string name;
    string location;
};

vector<Tourist> tourists;
vector<Attraction> attractions;

int touristID = 1;
int attractionID = 1;

void addTourist(string name, string nationality) {
    tourists.push_back({touristID++, name, nationality});
}

void addAttraction(string name, string location) {
    attractions.push_back({attractionID++, name, location});
}

void deleteTourist(int id) {
    for (auto it = tourists.begin(); it != tourists.end(); ++it) {
        if (it->id == id) {
            tourists.erase(it);
            break;
        }
    }
}

void deleteAttraction(int id) {
    for (auto it = attractions.begin(); it != attractions.end(); ++it) {
        if (it->id == id) {
            attractions.erase(it);
            break;
        }
    }
}

void updateTourist(int id, string name, string nationality) {
    for (auto& tourist : tourists) {
        if (tourist.id == id) {
            tourist.name = name;
            tourist.nationality = nationality;
            break;
        }
    }
}

void updateAttraction(int id, string name, string location) {
    for (auto& attraction : attractions) {
        if (attraction.id == id) {
            attraction.name = name;
            attraction.location = location;
            break;
        }
    }
}

Tourist* searchTourist(int id) {
    for (auto& tourist : tourists) {
        if (tourist.id == id) {
            return &tourist;
        }
    }
    return nullptr;
}

Attraction* searchAttraction(int id) {
    for (auto& attraction : attractions) {
        if (attraction.id == id) {
            return &attraction;
        }
    }
    return nullptr;
}

void displayTourists() {
    for (const auto& tourist : tourists) {
        cout << "Tourist ID: " << tourist.id << ", Name: " << tourist.name << ", Nationality: " << tourist.nationality << endl;
    }
}

void displayAttractions() {
    for (const auto& attraction : attractions) {
        cout << "Attraction ID: " << attraction.id << ", Name: " << attraction.name << ", Location: " << attraction.location << endl;
    }
}

int main() {
    addTourist("John Doe", "American");
    addTourist("Jane Smith", "British");
    addAttraction("Statue of Liberty", "New York");
    addAttraction("Eiffel Tower", "Paris");
    
    cout << "Tourists List:" << endl;
    displayTourists();
    
    cout << "\nAttractions List:" << endl;
    displayAttractions();
    
    updateTourist(1, "John Doe", "Canadian");
    updateAttraction(2, "Eiffel Tower", "France");

    cout << "\nUpdated Tourists List:" << endl;
    displayTourists();
    
    cout << "\nUpdated Attractions List:" << endl;
    displayAttractions();
    
    deleteTourist(2);
    deleteAttraction(1);
    
    cout << "\nAfter Deletion Tourists List:" << endl;
    displayTourists();
    
    cout << "\nAfter Deletion Attractions List:" << endl;
    displayAttractions();
    
    Tourist* t = searchTourist(1);
    Attraction* a = searchAttraction(2);
    
    if(t) {
        cout << "\nFound Tourist ID 1: " << t->name << endl;
    } else {
        cout << "\nTourist ID 1 not found." << endl;
    }

    if(a) {
        cout << "Found Attraction ID 2: " << a->name << endl;
    } else {
        cout << "Attraction ID 2 not found." << endl;
    }
    
    return 0;
}