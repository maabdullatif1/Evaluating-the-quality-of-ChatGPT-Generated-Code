#include <iostream>
#include <vector>
#include <string>

struct Tourist {
    int id;
    std::string name;
    int age;
};

struct Attraction {
    int id;
    std::string name;
    std::string location;
};

std::vector<Tourist> tourists;
std::vector<Attraction> attractions;

int main() {
    int choice;
    
    do {
        std::cout << "1. Add Tourist\n2. Delete Tourist\n3. Update Tourist\n4. Search Tourist\n";
        std::cout << "5. Display Tourists\n6. Add Attraction\n7. Delete Attraction\n8. Update Attraction\n";
        std::cout << "9. Search Attraction\n10. Display Attractions\n0. Exit\nEnter choice: ";
        std::cin >> choice;

        if (choice == 1) {
            Tourist t;
            std::cout << "Enter ID: "; std::cin >> t.id;
            std::cout << "Enter Name: "; std::cin >> t.name;
            std::cout << "Enter Age: "; std::cin >> t.age;
            tourists.push_back(t);
        } else if (choice == 2) {
            int id;
            std::cout << "Enter Tourist ID to delete: "; std::cin >> id;
            tourists.erase(std::remove_if(tourists.begin(), tourists.end(), [&](Tourist& t) { return t.id == id; }), tourists.end());
        } else if (choice == 3) {
            int id;
            std::cout << "Enter Tourist ID to update: "; std::cin >> id;
            for (auto& t : tourists) {
                if (t.id == id) {
                    std::cout << "Enter new Name: "; std::cin >> t.name;
                    std::cout << "Enter new Age: "; std::cin >> t.age;
                    break;
                }
            }
        } else if (choice == 4) {
            int id;
            std::cout << "Enter Tourist ID to search: "; std::cin >> id;
            for (const auto& t : tourists) {
                if (t.id == id) {
                    std::cout << "ID: " << t.id << ", Name: " << t.name << ", Age: " << t.age << "\n";
                    break;
                }
            }
        } else if (choice == 5) {
            for (const auto& t : tourists) {
                std::cout << "ID: " << t.id << ", Name: " << t.name << ", Age: " << t.age << "\n";
            }
        } else if (choice == 6) {
            Attraction a;
            std::cout << "Enter ID: "; std::cin >> a.id;
            std::cout << "Enter Name: "; std::cin >> a.name;
            std::cout << "Enter Location: "; std::cin >> a.location;
            attractions.push_back(a);
        } else if (choice == 7) {
            int id;
            std::cout << "Enter Attraction ID to delete: "; std::cin >> id;
            attractions.erase(std::remove_if(attractions.begin(), attractions.end(), [&](Attraction& a) { return a.id == id; }), attractions.end());
        } else if (choice == 8) {
            int id;
            std::cout << "Enter Attraction ID to update: "; std::cin >> id;
            for (auto& a : attractions) {
                if (a.id == id) {
                    std::cout << "Enter new Name: "; std::cin >> a.name;
                    std::cout << "Enter new Location: "; std::cin >> a.location;
                    break;
                }
            }
        } else if (choice == 9) {
            int id;
            std::cout << "Enter Attraction ID to search: "; std::cin >> id;
            for (const auto& a : attractions) {
                if (a.id == id) {
                    std::cout << "ID: " << a.id << ", Name: " << a.name << ", Location: " << a.location << "\n";
                    break;
                }
            }
        } else if (choice == 10) {
            for (const auto& a : attractions) {
                std::cout << "ID: " << a.id << ", Name: " << a.name << ", Location: " << a.location << "\n";
            }
        }
    } while (choice != 0);

    return 0;
}