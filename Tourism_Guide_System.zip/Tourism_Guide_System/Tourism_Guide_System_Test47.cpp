#include <iostream>
#include <string>
#include <vector>

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;

    Attraction(std::string n, std::string l, std::string d) : name(n), location(l), description(d) {}
};

class Tourist {
public:
    std::string name;
    std::string nationality;

    Tourist(std::string n, std::string nation) : name(n), nationality(nation) {}
};

class TourismGuide {
private:
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;

public:
    void addAttraction(std::string name, std::string location, std::string description) {
        attractions.push_back(Attraction(name, location, description));
    }

    void addTourist(std::string name, std::string nationality) {
        tourists.push_back(Tourist(name, nationality));
    }

    void deleteAttraction(const std::string& name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                return;
            }
        }
    }

    void deleteTourist(const std::string& name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                return;
            }
        }
    }

    void updateAttraction(const std::string& name, const std::string& newLocation, const std::string& newDescription) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                attraction.location = newLocation;
                attraction.description = newDescription;
                return;
            }
        }
    }

    void updateTourist(const std::string& name, const std::string& newNationality) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                tourist.nationality = newNationality;
                return;
            }
        }
    }

    void searchAttraction(const std::string& name) const {
        for (const auto& attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Attraction: " << attraction.name << "\nLocation: " << attraction.location 
                          << "\nDescription: " << attraction.description << "\n";
                return;
            }
        }
        std::cout << "No attraction found with name: " << name << "\n";
    }

    void searchTourist(const std::string& name) const {
        for (const auto& tourist : tourists) {
            if (tourist.name == name) {
                std::cout << "Tourist: " << tourist.name << "\nNationality: " << tourist.nationality << "\n";
                return;
            }
        }
        std::cout << "No tourist found with name: " << name << "\n";
    }

    void displayAttractions() const {
        for (const auto& attraction : attractions) {
            std::cout << "Attraction: " << attraction.name << "\nLocation: " << attraction.location 
                      << "\nDescription: " << attraction.description << "\n\n";
        }
    }

    void displayTourists() const {
        for (const auto& tourist : tourists) {
            std::cout << "Tourist: " << tourist.name << "\nNationality: " << tourist.nationality << "\n\n";
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addAttraction("Eiffel Tower", "Paris", "Iconic landmark of France");
    guide.addTourist("John Doe", "American");

    guide.displayAttractions();
    guide.displayTourists();

    guide.searchAttraction("Eiffel Tower");
    guide.searchTourist("John Doe");

    guide.updateAttraction("Eiffel Tower", "Paris, France", "Famous tower in France");
    guide.updateTourist("John Doe", "Canadian");

    guide.displayAttractions();
    guide.displayTourists();

    guide.deleteAttraction("Eiffel Tower");
    guide.deleteTourist("John Doe");

    guide.displayAttractions();
    guide.displayTourists();

    return 0;
}