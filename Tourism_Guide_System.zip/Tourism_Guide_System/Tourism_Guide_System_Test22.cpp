#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Tourist {
    string name;
    int age;
    string nationality;
};

struct Attraction {
    string name;
    string location;
    string description;
};

class TourismGuide {
private:
    vector<Tourist> tourists;
    vector<Attraction> attractions;

public:
    void addTourist(const string& name, int age, const string& nationality) {
        tourists.push_back({name, age, nationality});
    }

    void deleteTourist(const string& name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                return;
            }
        }
    }

    void updateTourist(const string& name, int age, const string& nationality) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                tourist.age = age;
                tourist.nationality = nationality;
                return;
            }
        }
    }

    void searchTourist(const string& name) {
        for (const auto& tourist : tourists) {
            if (tourist.name == name) {
                cout << "Tourist Found: " << tourist.name << ", " << tourist.age << ", " << tourist.nationality << "\n";
                return;
            }
        }
        cout << "Tourist not found\n";
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            cout << "Name: " << tourist.name << ", Age: " << tourist.age << ", Nationality: " << tourist.nationality << "\n";
        }
    }

    void addAttraction(const string& name, const string& location, const string& description) {
        attractions.push_back({name, location, description});
    }

    void deleteAttraction(const string& name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                return;
            }
        }
    }

    void updateAttraction(const string& name, const string& location, const string& description) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                attraction.location = location;
                attraction.description = description;
                return;
            }
        }
    }

    void searchAttraction(const string& name) {
        for (const auto& attraction : attractions) {
            if (attraction.name == name) {
                cout << "Attraction Found: " << attraction.name << ", " << attraction.location << ", " << attraction.description << "\n";
                return;
            }
        }
        cout << "Attraction not found\n";
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            cout << "Name: " << attraction.name << ", Location: " << attraction.location << ", Description: " << attraction.description << "\n";
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist("John Doe", 30, "USA");
    guide.addTourist("Jane Smith", 25, "UK");

    guide.addAttraction("Eiffel Tower", "Paris", "A wrought-iron lattice tower on the Champ de Mars.");
    guide.addAttraction("Colosseum", "Rome", "An ancient amphitheater in the center of the city.");

    guide.searchTourist("Jane Smith");
    guide.displayTourists();

    guide.searchAttraction("Eiffel Tower");
    guide.displayAttractions();

    guide.updateTourist("Jane Smith", 26, "Canada");
    guide.updateAttraction("Eiffel Tower", "Paris, France", "A famous landmark in Paris.");

    guide.displayTourists();
    guide.displayAttractions();

    guide.deleteTourist("John Doe");
    guide.deleteAttraction("Colosseum");

    guide.displayTourists();
    guide.displayAttractions();

    return 0;
}