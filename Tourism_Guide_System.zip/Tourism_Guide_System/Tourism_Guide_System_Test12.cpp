#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Tourist {
public:
    string name;
    int age;
    string nationality;

    Tourist(string n, int a, string nat): name(n), age(a), nationality(nat) {}
};

class Attraction {
public:
    string name;
    string location;
    string description;

    Attraction(string n, string loc, string desc): name(n), location(loc), description(desc) {}
};

class TourismGuideSystem {
private:
    vector<Tourist> tourists;
    vector<Attraction> attractions;

public:
    void addTourist(string name, int age, string nationality) {
        tourists.push_back(Tourist(name, age, nationality));
    }

    void addAttraction(string name, string location, string description) {
        attractions.push_back(Attraction(name, location, description));
    }

    void deleteTourist(string name) {
        for(auto it = tourists.begin(); it != tourists.end(); ++it) {
            if(it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void deleteAttraction(string name) {
        for(auto it = attractions.begin(); it != attractions.end(); ++it) {
            if(it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateTourist(string name, int age, string nationality) {
        for(auto &tourist: tourists) {
            if(tourist.name == name) {
                tourist.age = age;
                tourist.nationality = nationality;
                break;
            }
        }
    }

    void updateAttraction(string name, string location, string description) {
        for(auto &attraction: attractions) {
            if(attraction.name == name) {
                attraction.location = location;
                attraction.description = description;
                break;
            }
        }
    }

    void searchTourist(string name) {
        for(const auto &tourist: tourists) {
            if(tourist.name == name) {
                cout << "Tourist Found: " << tourist.name << ", Age: " << tourist.age << ", Nationality: " << tourist.nationality << endl;
                return;
            }
        }
        cout << "Tourist not found" << endl;
    }

    void searchAttraction(string name) {
        for(const auto &attraction: attractions) {
            if(attraction.name == name) {
                cout << "Attraction Found: " << attraction.name << ", Location: " << attraction.location << ", Description: " << attraction.description << endl;
                return;
            }
        }
        cout << "Attraction not found" << endl;
    }

    void displayTourists() {
        for(const auto &tourist: tourists) {
            cout << "Tourist: " << tourist.name << ", Age: " << tourist.age << ", Nationality: " << tourist.nationality << endl;
        }
    }

    void displayAttractions() {
        for(const auto &attraction: attractions) {
            cout << "Attraction: " << attraction.name << ", Location: " << attraction.location << ", Description: " << attraction.description << endl;
        }
    }
};

int main() {
    TourismGuideSystem guide;
    guide.addTourist("John Doe", 30, "American");
    guide.addAttraction("Eiffel Tower", "Paris", "Iconic symbol of France");
    guide.displayTourists();
    guide.displayAttractions();
    guide.searchTourist("John Doe");
    guide.searchAttraction("Eiffel Tower");
    guide.updateTourist("John Doe", 31, "American");
    guide.updateAttraction("Eiffel Tower", "Paris, France", "Famous tower in Paris");
    guide.displayTourists();
    guide.displayAttractions();
    guide.deleteTourist("John Doe");
    guide.deleteAttraction("Eiffel Tower");
    guide.displayTourists();
    guide.displayAttractions();
    return 0;
}