#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    std::string name;
    std::string location;
    
    Attraction(std::string n, std::string loc) : name(n), location(loc) {}
};

class Tourist {
public:
    std::string name;
    std::string nationality;
    
    Tourist(std::string n, std::string nat) : name(n), nationality(nat) {}
};

class TourismGuide {
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;
    
public:
    void addTourist(std::string name, std::string nationality) {
        tourists.push_back(Tourist(name, nationality));
    }
    
    void addAttraction(std::string name, std::string location) {
        attractions.push_back(Attraction(name, location));
    }
    
    void deleteTourist(std::string name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                return;
            }
        }
    }
    
    void deleteAttraction(std::string name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                return;
            }
        }
    }
    
    void updateTourist(std::string oldName, std::string newName, std::string newNationality) {
        for (auto& tourist : tourists) {
            if (tourist.name == oldName) {
                tourist.name = newName;
                tourist.nationality = newNationality;
                return;
            }
        }
    }
    
    void updateAttraction(std::string oldName, std::string newName, std::string newLocation) {
        for (auto& attraction : attractions) {
            if (attraction.name == oldName) {
                attraction.name = newName;
                attraction.location = newLocation;
                return;
            }
        }
    }
    
    void searchTourist(std::string name) {
        for (const auto& tourist : tourists) {
            if (tourist.name == name) {
                std::cout << "Tourist Found: " << tourist.name << ", " << tourist.nationality << std::endl;
                return;
            }
        }
        std::cout << "Tourist Not Found" << std::endl;
    }
    
    void searchAttraction(std::string name) {
        for (const auto& attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Attraction Found: " << attraction.name << ", " << attraction.location << std::endl;
                return;
            }
        }
        std::cout << "Attraction Not Found" << std::endl;
    }
    
    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Tourist: " << tourist.name << ", " << tourist.nationality << std::endl;
        }
    }
    
    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "Attraction: " << attraction.name << ", " << attraction.location << std::endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist("John Doe", "USA");
    guide.addTourist("Anna Smith", "UK");
    guide.addAttraction("Eiffel Tower", "Paris");
    guide.addAttraction("Colosseum", "Rome");
    
    guide.displayTourists();
    guide.displayAttractions();
    
    guide.searchTourist("John Doe");
    guide.searchAttraction("Eiffel Tower");
    
    guide.updateTourist("John Doe", "Johnny Doe", "Canada");
    guide.updateAttraction("Eiffel Tower", "The Eiffel Tower", "Paris, France");
    
    guide.displayTourists();
    guide.displayAttractions();
    
    guide.deleteTourist("Anna Smith");
    guide.deleteAttraction("Colosseum");
    
    guide.displayTourists();
    guide.displayAttractions();
    
    return 0;
}