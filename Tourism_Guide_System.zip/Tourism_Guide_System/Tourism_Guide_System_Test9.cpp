#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    Tourist(std::string name, std::string country) : name(name), country(country) {}
    std::string name;
    std::string country;
};

class Attraction {
public:
    Attraction(std::string name, std::string location) : name(name), location(location) {}
    std::string name;
    std::string location;
};

class TourismGuide {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;
    
public:
    void addTourist(std::string name, std::string country) {
        tourists.push_back(Tourist(name, country));
    }
    
    void deleteTourist(std::string name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(std::string name, std::string newName, std::string newCountry) {
        for (auto &tourist : tourists) {
            if (tourist.name == name) {
                tourist.name = newName;
                tourist.country = newCountry;
                break;
            }
        }
    }
    
    void addAttraction(std::string name, std::string location) {
        attractions.push_back(Attraction(name, location));
    }
    
    void deleteAttraction(std::string name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }
    
    void updateAttraction(std::string name, std::string newName, std::string newLocation) {
        for (auto &attraction : attractions) {
            if (attraction.name == name) {
                attraction.name = newName;
                attraction.location = newLocation;
                break;
            }
        }
    }
    
    void searchTourist(std::string name) const {
        for (const auto &tourist : tourists) {
            if (tourist.name == name) {
                std::cout << "Tourist Found: " << tourist.name << " from " << tourist.country << std::endl;
                return;
            }
        }
        std::cout << "Tourist not found" << std::endl;
    }
    
    void searchAttraction(std::string name) const {
        for (const auto &attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Attraction Found: " << attraction.name << " located at " << attraction.location << std::endl;
                return;
            }
        }
        std::cout << "Attraction not found" << std::endl;
    }
    
    void displayTourists() const {
        if (tourists.empty()) {
            std::cout << "No tourists available." << std::endl;
            return;
        }
        std::cout << "Tourists List:" << std::endl;
        for (const auto &tourist : tourists) {
            std::cout << "Name: " << tourist.name << ", Country: " << tourist.country << std::endl;
        }
    }

    void displayAttractions() const {
        if (attractions.empty()) {
            std::cout << "No attractions available." << std::endl;
            return;
        }
        std::cout << "Attractions List:" << std::endl;
        for (const auto &attraction : attractions) {
            std::cout << "Name: " << attraction.name << ", Location: " << attraction.location << std::endl;
        }
    }
};

int main() {
    TourismGuide guide;
    
    guide.addTourist("Alice", "USA");
    guide.addTourist("Bob", "UK");
    guide.addAttraction("Eiffel Tower", "Paris");
    guide.addAttraction("Colosseum", "Rome");
    
    guide.displayTourists();
    guide.displayAttractions();
    
    guide.searchTourist("Alice");
    guide.searchAttraction("Colosseum");
    
    guide.updateTourist("Alice", "Alicia", "Canada");
    guide.updateAttraction("Eiffel Tower", "Eiffel Tower", "France");
    
    guide.displayTourists();
    guide.displayAttractions();
    
    guide.deleteTourist("Bob");
    guide.deleteAttraction("Colosseum");
    
    guide.displayTourists();
    guide.displayAttractions();
    
    return 0;
}