#include <iostream>
#include <vector>
#include <string>

struct Attraction {
    std::string name;
    std::string location;
    std::string description;
};

class TourismGuide {
private:
    std::vector<Attraction> attractions;

public:
    void addAttraction(const std::string& name, const std::string& location, const std::string& description) {
        Attraction attraction = {name, location, description};
        attractions.push_back(attraction);
    }

    void deleteAttraction(const std::string& name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                return;
            }
        }
    }

    void updateAttraction(const std::string& name, const std::string& newLocation, const std::string& newDescription) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                attraction.location = newLocation;
                attraction.description = newDescription;
                return;
            }
        }
    }

    void searchAttraction(const std::string& name) {
        for (const auto& attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Name: " << attraction.name << "\n"
                          << "Location: " << attraction.location << "\n"
                          << "Description: " << attraction.description << "\n";
                return;
            }
        }
        std::cout << "Attraction not found.\n";
    }

    void displayAllAttractions() {
        if (attractions.empty()) {
            std::cout << "No attractions available.\n";
            return;
        }
        for (const auto& attraction : attractions) {
            std::cout << "Name: " << attraction.name << "\n"
                      << "Location: " << attraction.location << "\n"
                      << "Description: " << attraction.description << "\n\n";
        }
    }
};

int main() {
    TourismGuide guide;
    int choice;
    std::string name, location, description;

    while (true) {
        std::cout << "1. Add Attraction\n"
                  << "2. Delete Attraction\n"
                  << "3. Update Attraction\n"
                  << "4. Search Attraction\n"
                  << "5. Display All Attractions\n"
                  << "6. Exit\n"
                  << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter name: ";
                std::cin.ignore();
                std::getline(std::cin, name);
                std::cout << "Enter location: ";
                std::getline(std::cin, location);
                std::cout << "Enter description: ";
                std::getline(std::cin, description);
                guide.addAttraction(name, location, description);
                break;
            case 2:
                std::cout << "Enter name of attraction to delete: ";
                std::cin.ignore();
                std::getline(std::cin, name);
                guide.deleteAttraction(name);
                break;
            case 3:
                std::cout << "Enter name of attraction to update: ";
                std::cin.ignore();
                std::getline(std::cin, name);
                std::cout << "Enter new location: ";
                std::getline(std::cin, location);
                std::cout << "Enter new description: ";
                std::getline(std::cin, description);
                guide.updateAttraction(name, location, description);
                break;
            case 4:
                std::cout << "Enter name of attraction to search: ";
                std::cin.ignore();
                std::getline(std::cin, name);
                guide.searchAttraction(name);
                break;
            case 5:
                guide.displayAllAttractions();
                break;
            case 6:
                return 0;
            default:
                std::cout << "Invalid choice. Please try again.\n";
        }
    }
}