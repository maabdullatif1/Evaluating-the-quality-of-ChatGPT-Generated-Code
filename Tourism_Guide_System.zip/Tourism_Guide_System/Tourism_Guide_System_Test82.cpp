#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    std::string name;
    std::string description;
    std::string location;

    Attraction() {}

    Attraction(std::string name, std::string description, std::string location)
        : name(name), description(description), location(location) {}
};

class Tourist {
public:
    std::string name;
    int age;
    std::string nationality;

    Tourist() {}

    Tourist(std::string name, int age, std::string nationality)
        : name(name), age(age), nationality(nationality) {}
};

class TourismGuideSystem {
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(std::string name, int age, std::string nationality) {
        tourists.push_back(Tourist(name, age, nationality));
    }

    void deleteTourist(std::string name) {
        for (auto it = tourists.begin(); it != tourists.end(); it++) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(std::string name, int age, std::string nationality) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                tourist.age = age;
                tourist.nationality = nationality;
                break;
            }
        }
    }

    void displayTourists() const {
        for (const auto& tourist : tourists) {
            std::cout << "Name: " << tourist.name 
                      << ", Age: " << tourist.age 
                      << ", Nationality: " << tourist.nationality << std::endl;
        }
    }

    void addAttraction(std::string name, std::string description, std::string location) {
        attractions.push_back(Attraction(name, description, location));
    }

    void deleteAttraction(std::string name) {
        for (auto it = attractions.begin(); it != attractions.end(); it++) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(std::string name, std::string description, std::string location) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                attraction.description = description;
                attraction.location = location;
                break;
            }
        }
    }

    void displayAttractions() const {
        for (const auto& attraction : attractions) {
            std::cout << "Name: " << attraction.name 
                      << ", Description: " << attraction.description 
                      << ", Location: " << attraction.location << std::endl;
        }
    }

    void searchTourist(std::string name) const {
        for (const auto& tourist : tourists) {
            if (tourist.name == name) {
                std::cout << "Found Tourist: " << tourist.name 
                          << ", Age: " << tourist.age 
                          << ", Nationality: " << tourist.nationality << std::endl;
                return;
            }
        }
        std::cout << "Tourist not found." << std::endl;
    }

    void searchAttraction(std::string name) const {
        for (const auto& attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Found Attraction: " << attraction.name 
                          << ", Description: " << attraction.description 
                          << ", Location: " << attraction.location << std::endl;
                return;
            }
        }
        std::cout << "Attraction not found." << std::endl;
    }
};

int main() {
    TourismGuideSystem system;

    system.addTourist("John Doe", 30, "American");
    system.addTourist("Jane Smith", 25, "British");

    system.addAttraction("Eiffel Tower", "An iconic symbol of France.", "Paris");
    system.addAttraction("Colosseum", "An ancient amphitheater in Rome.", "Rome");

    system.displayTourists();
    system.displayAttractions();

    system.searchTourist("Jane Smith");
    system.searchAttraction("Eiffel Tower");

    system.updateTourist("John Doe", 31, "Canadian");
    system.updateAttraction("Eiffel Tower", "The historic landmark in Paris.", "Paris, France");

    system.deleteTourist("Jane Smith");
    system.deleteAttraction("Colosseum");

    system.displayTourists();
    system.displayAttractions();

    return 0;
}