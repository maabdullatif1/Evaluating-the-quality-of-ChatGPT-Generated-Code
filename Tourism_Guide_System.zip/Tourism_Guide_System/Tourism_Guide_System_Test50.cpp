#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Tourist {
public:
    string name;
    string nationality;
    Tourist(string n, string nat) : name(n), nationality(nat) {}
};

class Attraction {
public:
    string name;
    string location;
    Attraction(string n, string loc) : name(n), location(loc) {}
};

class TourismGuide {
private:
    vector<Tourist> tourists;
    vector<Attraction> attractions;

    int findTouristIndex(string name) {
        for (size_t i = 0; i < tourists.size(); ++i) {
            if (tourists[i].name == name) {
                return i;
            }
        }
        return -1;
    }

    int findAttractionIndex(string name) {
        for (size_t i = 0; i < attractions.size(); ++i) {
            if (attractions[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addTourist(string name, string nationality) {
        tourists.push_back(Tourist(name, nationality));
    }

    void deleteTourist(string name) {
        int index = findTouristIndex(name);
        if (index != -1) {
            tourists.erase(tourists.begin() + index);
        }
    }

    void updateTourist(string oldName, string newName, string nationality) {
        int index = findTouristIndex(oldName);
        if (index != -1) {
            tourists[index].name = newName;
            tourists[index].nationality = nationality;
        }
    }

    void addAttraction(string name, string location) {
        attractions.push_back(Attraction(name, location));
    }

    void deleteAttraction(string name) {
        int index = findAttractionIndex(name);
        if (index != -1) {
            attractions.erase(attractions.begin() + index);
        }
    }

    void updateAttraction(string oldName, string newName, string location) {
        int index = findAttractionIndex(oldName);
        if (index != -1) {
            attractions[index].name = newName;
            attractions[index].location = location;
        }
    }

    void searchTourist(string name) {
        int index = findTouristIndex(name);
        if (index != -1) {
            cout << "Tourist Found: " << tourists[index].name << ", " << tourists[index].nationality << endl;
        } else {
            cout << "Tourist not found." << endl;
        }
    }

    void searchAttraction(string name) {
        int index = findAttractionIndex(name);
        if (index != -1) {
            cout << "Attraction Found: " << attractions[index].name << ", " << attractions[index].location << endl;
        } else {
            cout << "Attraction not found." << endl;
        }
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            cout << tourist.name << ", " << tourist.nationality << endl;
        }
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            cout << attraction.name << ", " << attraction.location << endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist("John Doe", "American");
    guide.addTourist("Jane Smith", "British");
    guide.addAttraction("Eiffel Tower", "Paris");
    guide.addAttraction("Statue of Liberty", "New York");

    cout << "Tourists:" << endl;
    guide.displayTourists();
    cout << "\nAttractions:" << endl;
    guide.displayAttractions();

    guide.searchTourist("John Doe");
    guide.searchAttraction("Eiffel Tower");

    guide.updateTourist("John Doe", "John A. Doe", "Canadian");
    guide.updateAttraction("Eiffel Tower", "Eiffel Tower", "France");

    cout << "\nAfter Updates:" << endl;
    cout << "Tourists:" << endl;
    guide.displayTourists();
    cout << "\nAttractions:" << endl;
    guide.displayAttractions();

    guide.deleteTourist("Jane Smith");
    guide.deleteAttraction("Statue of Liberty");

    cout << "\nAfter Deletion:" << endl;
    cout << "Tourists:" << endl;
    guide.displayTourists();
    cout << "\nAttractions:" << endl;
    guide.displayAttractions();

    return 0;
}