#include <iostream>
#include <string>
#include <vector>

class Tourist {
public:
    int id;
    std::string name;
    std::string country;
    
    Tourist(int id, const std::string& name, const std::string& country)
        : id(id), name(name), country(country) {}
};

class Attraction {
public:
    int id;
    std::string name;
    std::string location;
    
    Attraction(int id, const std::string& name, const std::string& location)
        : id(id), name(name), location(location) {}
};

class TourismGuideSystem {
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;
    
public:
    void addTourist(Tourist t) {
        tourists.push_back(t);
    }
    
    void addAttraction(Attraction a) {
        attractions.push_back(a);
    }
    
    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                return;
            }
        }
    }
    
    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                return;
            }
        }
    }
    
    void updateTourist(int id, const std::string& name, const std::string& country) {
        for (auto& t : tourists) {
            if (t.id == id) {
                t.name = name;
                t.country = country;
                return;
            }
        }
    }
    
    void updateAttraction(int id, const std::string& name, const std::string& location) {
        for (auto& a : attractions) {
            if (a.id == id) {
                a.name = name;
                a.location = location;
                return;
            }
        }
    }
    
    Tourist* searchTourist(int id) {
        for (auto& t : tourists) {
            if (t.id == id) {
                return &t;
            }
        }
        return nullptr;
    }
    
    Attraction* searchAttraction(int id) {
        for (auto& a : attractions) {
            if (a.id == id) {
                return &a;
            }
        }
        return nullptr;
    }
    
    void displayTourists() {
        for (const auto& t : tourists) {
            std::cout << "ID: " << t.id << " Name: " << t.name << " Country: " << t.country << std::endl;
        }
    }
    
    void displayAttractions() {
        for (const auto& a : attractions) {
            std::cout << "ID: " << a.id << " Name: " << a.name << " Location: " << a.location << std::endl;
        }
    }
};

int main() {
    TourismGuideSystem system;
    system.addTourist(Tourist(1, "Alice", "USA"));
    system.addTourist(Tourist(2, "Bob", "UK"));
    
    system.addAttraction(Attraction(1, "Eiffel Tower", "Paris"));
    system.addAttraction(Attraction(2, "Statue of Liberty", "New York"));
    
    system.updateTourist(1, "Alice Johnson", "USA");
    system.updateAttraction(2, "Statue of Liberty National Monument", "New York");
    
    system.displayTourists();
    system.displayAttractions();
    
    system.deleteTourist(2);
    system.deleteAttraction(1);
    
    system.displayTourists();
    system.displayAttractions();
    
    Tourist* t = system.searchTourist(1);
    if (t) {
        std::cout << "Found Tourist: ID: " << t->id << " Name: " << t->name << " Country: " << t->country << std::endl;
    }
    
    Attraction* a = system.searchAttraction(2);
    if (a) {
        std::cout << "Found Attraction: ID: " << a->id << " Name: " << a->name << " Location: " << a->location << std::endl;
    }
    
    return 0;
}