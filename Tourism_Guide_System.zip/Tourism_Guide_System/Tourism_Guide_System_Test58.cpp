#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Tourist {
public:
    int id;
    string name;
    int age;

    Tourist(int i, string n, int a) : id(i), name(n), age(a) {}
};

class Attraction {
public:
    int id;
    string name;
    string location;

    Attraction(int i, string n, string l) : id(i), name(n), location(l) {}
};

class TourismGuideSystem {
private:
    vector<Tourist> tourists;
    vector<Attraction> attractions;

    Tourist* findTouristById(int id) {
        for (auto& tourist : tourists) {
            if (tourist.id == id) return &tourist;
        }
        return nullptr;
    }

    Attraction* findAttractionById(int id) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) return &attraction;
        }
        return nullptr;
    }

public:
    void addTourist(int id, string name, int age) {
        tourists.push_back(Tourist(id, name, age));
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(int id, string name, int age) {
        Tourist* tourist = findTouristById(id);
        if (tourist) {
            tourist->name = name;
            tourist->age = age;
        }
    }

    void searchTourist(int id) {
        Tourist* tourist = findTouristById(id);
        if (tourist) {
            cout << "Tourist ID: " << tourist->id << ", Name: " << tourist->name << ", Age: " << tourist->age << endl;
        } else {
            cout << "Tourist not found." << endl;
        }
    }

    void displayTourists() {
        for (auto& tourist : tourists) {
            cout << "ID: " << tourist.id << ", Name: " << tourist.name << ", Age: " << tourist.age << endl;
        }
    }

    void addAttraction(int id, string name, string location) {
        attractions.push_back(Attraction(id, name, location));
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(int id, string name, string location) {
        Attraction* attraction = findAttractionById(id);
        if (attraction) {
            attraction->name = name;
            attraction->location = location;
        }
    }

    void searchAttraction(int id) {
        Attraction* attraction = findAttractionById(id);
        if (attraction) {
            cout << "Attraction ID: " << attraction->id << ", Name: " << attraction->name << ", Location: " << attraction->location << endl;
        } else {
            cout << "Attraction not found." << endl;
        }
    }

    void displayAttractions() {
        for (auto& attraction : attractions) {
            cout << "ID: " << attraction.id << ", Name: " << attraction.name << ", Location: " << attraction.location << endl;
        }
    }
};

int main() {
    TourismGuideSystem system;
    system.addTourist(1, "John Doe", 30);
    system.addTourist(2, "Jane Smith", 25);
    system.addAttraction(1, "Eiffel Tower", "Paris");
    system.addAttraction(2, "Statue of Liberty", "New York");

    cout << "Tourists:" << endl;
    system.displayTourists();

    cout << "Attractions:" << endl;
    system.displayAttractions();

    return 0;
}