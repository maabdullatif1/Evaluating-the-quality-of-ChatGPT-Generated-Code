#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    int id;
    std::string name;

    Tourist(int id, std::string name) : id(id), name(name) {}
};

class Attraction {
public:
    int id;
    std::string name;

    Attraction(int id, std::string name) : id(id), name(name) {}
};

class TourismGuideSystem {
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(int id, std::string name) {
        tourists.push_back(Tourist(id, name));
    }

    void addAttraction(int id, std::string name) {
        attractions.push_back(Attraction(id, name));
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateTourist(int id, std::string newName) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = newName;
                break;
            }
        }
    }

    void updateAttraction(int id, std::string newName) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = newName;
                break;
            }
        }
    }

    void displayTourists() const {
        for (const auto &tourist : tourists) {
            std::cout << "Tourist ID: " << tourist.id << ", Name: " << tourist.name << std::endl;
        }
    }

    void displayAttractions() const {
        for (const auto &attraction : attractions) {
            std::cout << "Attraction ID: " << attraction.id << ", Name: " << attraction.name << std::endl;
        }
    }

    Tourist* searchTourist(int id) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                return &tourist;
            }
        }
        return nullptr;
    }

    Attraction* searchAttraction(int id) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                return &attraction;
            }
        }
        return nullptr;
    }
};

int main() {
    TourismGuideSystem system;
    
    system.addTourist(1, "John Doe");
    system.addTourist(2, "Jane Smith");
    system.addAttraction(1, "Eiffel Tower");
    system.addAttraction(2, "Statue of Liberty");
    
    system.displayTourists();
    system.displayAttractions();

    system.updateTourist(1, "John A. Doe");
    system.updateAttraction(1, "The Eiffel Tower");

    system.displayTourists();
    system.displayAttractions();

    system.deleteTourist(2);
    system.deleteAttraction(2);

    system.displayTourists();
    system.displayAttractions();

    Tourist* searchedTourist = system.searchTourist(1);
    if (searchedTourist) {
        std::cout << "Found Tourist - ID: " << searchedTourist->id << ", Name: " << searchedTourist->name << std::endl;
    }

    Attraction* searchedAttraction = system.searchAttraction(1);
    if (searchedAttraction) {
        std::cout << "Found Attraction - ID: " << searchedAttraction->id << ", Name: " << searchedAttraction->name << std::endl;
    }

    return 0;
}