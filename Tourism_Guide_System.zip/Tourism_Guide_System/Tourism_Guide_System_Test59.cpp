#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Tourist {
    int id;
    string name;
    string country;
};

struct Attraction {
    int id;
    string name;
    string location;
};

class TourismGuide {
private:
    vector<Tourist> tourists;
    vector<Attraction> attractions;

    template<typename T>
    typename vector<T>::iterator findByID(vector<T>& items, int id) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->id == id) {
                return it;
            }
        }
        return items.end();
    }

    template<typename T>
    void displayList(const vector<T>& items) {
        for (const auto& item : items) {
            cout << "ID: " << item.id << ", Name: " << item.name;
            if (is_same<T, Tourist>::value) {
                cout << ", Country: " << item.country << endl;
            } else {
                cout << ", Location: " << item.location << endl;
            }
        }
    }

public:
    void addTourist(int id, const string& name, const string& country) {
        tourists.push_back({id, name, country});
    }

    void deleteTourist(int id) {
        auto it = findByID(tourists, id);
        if (it != tourists.end()) {
            tourists.erase(it);
        }
    }

    void updateTourist(int id, const string& name, const string& country) {
        auto it = findByID(tourists, id);
        if (it != tourists.end()) {
            it->name = name;
            it->country = country;
        }
    }

    void searchTourist(int id) {
        auto it = findByID(tourists, id);
        if (it != tourists.end()) {
            cout << "ID: " << it->id << ", Name: " << it->name 
                 << ", Country: " << it->country << endl;
        }
    }

    void displayTourists() {
        displayList(tourists);
    }

    void addAttraction(int id, const string& name, const string& location) {
        attractions.push_back({id, name, location});
    }

    void deleteAttraction(int id) {
        auto it = findByID(attractions, id);
        if (it != attractions.end()) {
            attractions.erase(it);
        }
    }

    void updateAttraction(int id, const string& name, const string& location) {
        auto it = findByID(attractions, id);
        if (it != attractions.end()) {
            it->name = name;
            it->location = location;
        }
    }

    void searchAttraction(int id) {
        auto it = findByID(attractions, id);
        if (it != attractions.end()) {
            cout << "ID: " << it->id << ", Name: " << it->name 
                 << ", Location: " << it->location << endl;
        }
    }

    void displayAttractions() {
        displayList(attractions);
    }
};

int main() {
    TourismGuide guide;

    guide.addTourist(1, "Alice", "USA");
    guide.addTourist(2, "Bob", "UK");
    guide.addAttraction(1, "Eiffel Tower", "Paris");
    guide.addAttraction(2, "Statue of Liberty", "New York");
    
    guide.displayTourists();
    guide.displayAttractions();

    guide.updateTourist(1, "Alice Smith", "Canada");
    guide.updateAttraction(2, "Liberty Statue", "New York City");

    guide.displayTourists();
    guide.displayAttractions();

    guide.searchTourist(1);
    guide.searchAttraction(2);

    guide.deleteTourist(2);
    guide.deleteAttraction(1);

    guide.displayTourists();
    guide.displayAttractions();

    return 0;
}