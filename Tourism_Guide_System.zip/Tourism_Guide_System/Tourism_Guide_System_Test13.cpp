#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    std::string name;
    std::string nationality;
    int age;

    Tourist(std::string n, std::string nat, int a) : name(n), nationality(nat), age(a) {}
};

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;

    Attraction(std::string n, std::string loc, std::string desc) : name(n), location(loc), description(desc) {}
};

class TourismGuide {
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(const std::string& name, const std::string& nationality, int age) {
        tourists.push_back(Tourist(name, nationality, age));
    }

    void deleteTourist(const std::string& name) {
        tourists.erase(
            std::remove_if(tourists.begin(), tourists.end(),
                           [&](Tourist& t) { return t.name == name; }),
            tourists.end());
    }

    void updateTourist(const std::string& name, const std::string& newNationality, int newAge) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                tourist.nationality = newNationality;
                tourist.age = newAge;
                break;
            }
        }
    }

    Tourist* searchTourist(const std::string& name) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void addAttraction(const std::string& name, const std::string& location, const std::string& description) {
        attractions.push_back(Attraction(name, location, description));
    }

    void deleteAttraction(const std::string& name) {
        attractions.erase(
            std::remove_if(attractions.begin(), attractions.end(),
                           [&](Attraction& a) { return a.name == name; }),
            attractions.end());
    }

    void updateAttraction(const std::string& name, const std::string& newLocation, const std::string& newDescription) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                attraction.location = newLocation;
                attraction.description = newDescription;
                break;
            }
        }
    }

    Attraction* searchAttraction(const std::string& name) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Name: " << tourist.name
                      << ", Nationality: " << tourist.nationality
                      << ", Age: " << tourist.age << std::endl;
        }
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "Name: " << attraction.name
                      << ", Location: " << attraction.location
                      << ", Description: " << attraction.description << std::endl;
        }
    }
};

int main() {
    TourismGuide guide;

    guide.addTourist("John Doe", "USA", 30);
    guide.addTourist("Jane Smith", "UK", 25);

    guide.addAttraction("Eiffel Tower", "Paris", "Iconic French landmark.");

    guide.displayTourists();
    guide.displayAttractions();

    guide.updateTourist("John Doe", "Canada", 31);
    guide.updateAttraction("Eiffel Tower", "Paris, France", "World-famous landmark.");

    guide.displayTourists();
    guide.displayAttractions();

    Tourist* tourist = guide.searchTourist("Jane Smith");
    if (tourist) {
        std::cout << "Found tourist: " << tourist->name << std::endl;
    }

    Attraction* attraction = guide.searchAttraction("Eiffel Tower");
    if (attraction) {
        std::cout << "Found attraction: " << attraction->name << std::endl;
    }

    guide.deleteTourist("Jane Smith");
    guide.deleteAttraction("Eiffel Tower");

    guide.displayTourists();
    guide.displayAttractions();

    return 0;
}