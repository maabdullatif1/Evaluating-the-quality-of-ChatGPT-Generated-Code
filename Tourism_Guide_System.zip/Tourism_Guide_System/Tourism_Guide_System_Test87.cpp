#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Tourist {
public:
    string name;
    string country;

    Tourist(string n, string c) : name(n), country(c) {}
};

class Attraction {
public:
    string name;
    string location;
    string description;

    Attraction(string n, string loc, string desc) : name(n), location(loc), description(desc) {}
};

class TourismGuideSystem {
private:
    vector<Tourist> tourists;
    vector<Attraction> attractions;

    int findTouristIndex(string name) {
        for (size_t i = 0; i < tourists.size(); ++i) {
            if (tourists[i].name == name) return i;
        }
        return -1;
    }

    int findAttractionIndex(string name) {
        for (size_t i = 0; i < attractions.size(); ++i) {
            if (attractions[i].name == name) return i;
        }
        return -1;
    }

public:
    void addTourist(string name, string country) {
        tourists.push_back(Tourist(name, country));
    }

    void deleteTourist(string name) {
        int index = findTouristIndex(name);
        if (index != -1) {
            tourists.erase(tourists.begin() + index);
        }
    }

    void updateTourist(string oldName, string newName, string newCountry) {
        int index = findTouristIndex(oldName);
        if (index != -1) {
            tourists[index].name = newName;
            tourists[index].country = newCountry;
        }
    }

    void addAttraction(string name, string location, string description) {
        attractions.push_back(Attraction(name, location, description));
    }

    void deleteAttraction(string name) {
        int index = findAttractionIndex(name);
        if (index != -1) {
            attractions.erase(attractions.begin() + index);
        }
    }

    void updateAttraction(string oldName, string newName, string newLocation, string newDescription) {
        int index = findAttractionIndex(oldName);
        if (index != -1) {
            attractions[index].name = newName;
            attractions[index].location = newLocation;
            attractions[index].description = newDescription;
        }
    }

    Tourist* searchTourist(string name) {
        int index = findTouristIndex(name);
        if (index != -1) {
            return &tourists[index];
        }
        return nullptr;
    }

    Attraction* searchAttraction(string name) {
        int index = findAttractionIndex(name);
        if (index != -1) {
            return &attractions[index];
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            cout << "Name: " << tourist.name << ", Country: " << tourist.country << endl;
        }
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            cout << "Name: " << attraction.name << ", Location: " << attraction.location
                 << ", Description: " << attraction.description << endl;
        }
    }
};

int main() {
    TourismGuideSystem system;

    system.addTourist("Alice", "USA");
    system.addTourist("Bob", "Canada");

    system.addAttraction("Eiffel Tower", "Paris", "Famous landmark in France");
    system.addAttraction("Statue of Liberty", "New York", "Iconic statue in the USA");

    system.displayTourists();
    system.displayAttractions();

    system.updateTourist("Alice", "Alice Smith", "United States");
    system.updateAttraction("Eiffel Tower", "Eiffel Tower", "Paris, France", "Iconic symbol of France");

    system.displayTourists();
    system.displayAttractions();

    system.deleteTourist("Bob");
    system.deleteAttraction("Statue of Liberty");

    system.displayTourists();
    system.displayAttractions();

    return 0;
}