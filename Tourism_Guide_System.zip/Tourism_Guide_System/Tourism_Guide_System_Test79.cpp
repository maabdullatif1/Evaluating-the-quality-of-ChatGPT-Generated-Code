#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Attraction {
    int id;
    string name;
    string description;
    string location;
};

struct Tourist {
    int id;
    string name;
    string nationality;
    vector<int> attractionsVisited;
};

class TourismGuideSystem {
    vector<Attraction> attractions;
    vector<Tourist> tourists;
    int nextAttractionId = 1;
    int nextTouristId = 1;

    Attraction* findAttractionById(int id) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                return &attraction;
            }
        }
        return nullptr;
    }

    Tourist* findTouristById(int id) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                return &tourist;
            }
        }
        return nullptr;
    }

public:
    void addAttraction(string name, string description, string location) {
        attractions.push_back({nextAttractionId++, name, description, location});
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(int id, string name, string description, string location) {
        Attraction* attraction = findAttractionById(id);
        if (attraction != nullptr) {
            attraction->name = name;
            attraction->description = description;
            attraction->location = location;
        }
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            cout << "ID: " << attraction.id << ", Name: " << attraction.name
                 << ", Description: " << attraction.description
                 << ", Location: " << attraction.location << endl;
        }
    }

    void searchAttraction(string name) {
        for (const auto &attraction : attractions) {
            if (attraction.name == name) {
                cout << "ID: " << attraction.id << ", Name: " << attraction.name
                     << ", Description: " << attraction.description
                     << ", Location: " << attraction.location << endl;
            }
        }
    }

    void addTourist(string name, string nationality) {
        tourists.push_back({nextTouristId++, name, nationality, {}});
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(int id, string name, string nationality) {
        Tourist* tourist = findTouristById(id);
        if (tourist != nullptr) {
            tourist->name = name;
            tourist->nationality = nationality;
        }
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            cout << "ID: " << tourist.id << ", Name: " << tourist.name
                 << ", Nationality: " << tourist.nationality << ", Attractions Visited: ";
            for (int attractionId : tourist.attractionsVisited) {
                cout << attractionId << " ";
            }
            cout << endl;
        }
    }

    void searchTourist(string name) {
        for (const auto &tourist : tourists) {
            if (tourist.name == name) {
                cout << "ID: " << tourist.id << ", Name: " << tourist.name
                     << ", Nationality: " << tourist.nationality << ", Attractions Visited: ";
                for (int attractionId : tourist.attractionsVisited) {
                    cout << attractionId << " ";
                }
                cout << endl;
            }
        }
    }

    void addVisitedAttraction(int touristId, int attractionId) {
        Tourist* tourist = findTouristById(touristId);
        if (tourist != nullptr && findAttractionById(attractionId) != nullptr) {
            tourist->attractionsVisited.push_back(attractionId);
        }
    }
};

int main() {
    TourismGuideSystem system;
    system.addAttraction("Statue of Liberty", "Iconic National Monument", "New York City");
    system.addTourist("John Doe", "American");
    system.addVisitedAttraction(1, 1);
    system.displayAttractions();
    system.displayTourists();
    system.searchAttraction("Statue of Liberty");
    system.searchTourist("John Doe");
    return 0;
}