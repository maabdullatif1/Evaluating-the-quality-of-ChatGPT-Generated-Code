#include <iostream>
#include <vector>
#include <string>

class Tourist {
    std::string name;
    std::string contact;

public:
    Tourist(const std::string& n, const std::string& c) : name(n), contact(c) {}
    
    std::string getName() const { return name; }
    std::string getContact() const { return contact; }

    void setName(const std::string& n) { name = n; }
    void setContact(const std::string& c) { contact = c; }
};

class Attraction {
    std::string name;
    std::string location;

public:
    Attraction(const std::string& n, const std::string& l) : name(n), location(l) {}

    std::string getName() const { return name; }
    std::string getLocation() const { return location; }

    void setName(const std::string& n) { name = n; }
    void setLocation(const std::string& l) { location = l; }
};

class TourismGuide {
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(const std::string& name, const std::string& contact) {
        tourists.push_back(Tourist(name, contact));
    }

    void deleteTourist(const std::string& name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->getName() == name) {
                tourists.erase(it);
                return;
            }
        }
    }

    void updateTourist(const std::string& name, const std::string& new_contact) {
        for (auto& tourist : tourists) {
            if (tourist.getName() == name) {
                tourist.setContact(new_contact);
                return;
            }
        }
    }

    void searchTourist(const std::string& name) const {
        for (const auto& tourist : tourists) {
            if (tourist.getName() == name) {
                std::cout << "Found Tourist: " << tourist.getName() << ", Contact: " << tourist.getContact() << std::endl;
                return;
            }
        }
        std::cout << "Tourist not found." << std::endl;
    }

    void displayTourists() const {
        for (const auto& tourist : tourists) {
            std::cout << "Name: " << tourist.getName() << ", Contact: " << tourist.getContact() << std::endl;
        }
    }

    void addAttraction(const std::string& name, const std::string& location) {
        attractions.push_back(Attraction(name, location));
    }

    void deleteAttraction(const std::string& name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->getName() == name) {
                attractions.erase(it);
                return;
            }
        }
    }

    void updateAttraction(const std::string& name, const std::string& new_location) {
        for (auto& attraction : attractions) {
            if (attraction.getName() == name) {
                attraction.setLocation(new_location);
                return;
            }
        }
    }

    void searchAttraction(const std::string& name) const {
        for (const auto& attraction : attractions) {
            if (attraction.getName() == name) {
                std::cout << "Found Attraction: " << attraction.getName() << ", Location: " << attraction.getLocation() << std::endl;
                return;
            }
        }
        std::cout << "Attraction not found." << std::endl;
    }

    void displayAttractions() const {
        for (const auto& attraction : attractions) {
            std::cout << "Name: " << attraction.getName() << ", Location: " << attraction.getLocation() << std::endl;
        }
    }
};

int main() {
    TourismGuide guide;
    
    guide.addTourist("Alice", "alice@example.com");
    guide.addTourist("Bob", "bob@example.com");
    guide.addAttraction("Eiffel Tower", "Paris");
    guide.addAttraction("Statue of Liberty", "New York");

    std::cout << "All Tourists:" << std::endl;
    guide.displayTourists();

    std::cout << "All Attractions:" << std::endl;
    guide.displayAttractions();

    guide.searchTourist("Alice");
    guide.searchAttraction("Eiffel Tower");

    guide.updateTourist("Alice", "alice_updated@example.com");
    guide.updateAttraction("Eiffel Tower", "Paris, France");

    std::cout << "After Updates:" << std::endl;
    guide.displayTourists();
    guide.displayAttractions();

    guide.deleteTourist("Bob");
    guide.deleteAttraction("Statue of Liberty");

    std::cout << "After Deletions:" << std::endl;
    guide.displayTourists();
    guide.displayAttractions();

    return 0;
}