#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Attraction {
    string name;
    string location;
    string description;
};

class Tourist {
public:
    string name;
    int age;
    vector<Attraction> attractions;

    Tourist(string n, int a) : name(n), age(a) {}
};

class TourismGuide {
private:
    vector<Tourist> tourists;

public:
    void addTourist(string name, int age) {
        tourists.push_back(Tourist(name, age));
    }

    void deleteTourist(string name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(string oldName, string newName, int newAge) {
        for (auto& tourist : tourists) {
            if (tourist.name == oldName) {
                tourist.name = newName;
                tourist.age = newAge;
                break;
            }
        }
    }

    Tourist* searchTourist(string name) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void addAttraction(string touristName, string attractionName, string location, string description) {
        Tourist* tourist = searchTourist(touristName);
        if (tourist) {
            tourist->attractions.push_back(Attraction{attractionName, location, description});
        }
    }

    void deleteAttraction(string touristName, string attractionName) {
        Tourist* tourist = searchTourist(touristName);
        if (tourist) {
            for (auto it = tourist->attractions.begin(); it != tourist->attractions.end(); ++it) {
                if (it->name == attractionName) {
                    tourist->attractions.erase(it);
                    break;
                }
            }
        }
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            cout << "Name: " << tourist.name << ", Age: " << tourist.age << endl;
            for (const auto& attraction : tourist.attractions) {
                cout << "  Attraction: " << attraction.name
                     << ", Location: " << attraction.location
                     << ", Description: " << attraction.description << endl;
            }
        }
    }
};

int main() {
    TourismGuide guide;
    
    guide.addTourist("Alice", 30);
    guide.addAttraction("Alice", "Eiffel Tower", "Paris", "Iconic tower in Paris");

    guide.addTourist("Bob", 25);
    guide.addAttraction("Bob", "Colosseum", "Rome", "Ancient amphitheater in Rome");

    guide.displayTourists();

    guide.updateTourist("Alice", "Alicia", 31);
    guide.deleteAttraction("Bob", "Colosseum");

    guide.deleteTourist("Bob");

    guide.displayTourists();

    return 0;
}