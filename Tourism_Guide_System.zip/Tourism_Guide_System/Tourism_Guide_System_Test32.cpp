#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Attraction {
    int id;
    string name;
    string location;
};

struct Tourist {
    int id;
    string name;
    vector<int> attractionsVisited;
};

class TourismGuideSystem {
private:
    vector<Attraction> attractions;
    vector<Tourist> tourists;
    int nextAttractionId = 1;
    int nextTouristId = 1;

    Attraction* findAttractionById(int id) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) {
                return &attraction;
            }
        }
        return nullptr;
    }

    Tourist* findTouristById(int id) {
        for (auto& tourist : tourists) {
            if (tourist.id == id) {
                return &tourist;
            }
        }
        return nullptr;
    }

public:
    void addAttraction(const string& name, const string& location) {
        attractions.push_back({ nextAttractionId++, name, location });
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(int id, const string& name, const string& location) {
        Attraction* attraction = findAttractionById(id);
        if (attraction) {
            attraction->name = name;
            attraction->location = location;
        }
    }

    void addTourist(const string& name) {
        tourists.push_back({ nextTouristId++, name });
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(int id, const string& name) {
        Tourist* tourist = findTouristById(id);
        if (tourist) {
            tourist->name = name;
        }
    }

    void addVisit(int touristId, int attractionId) {
        Tourist* tourist = findTouristById(touristId);
        Attraction* attraction = findAttractionById(attractionId);
        if (tourist && attraction) {
            tourist->attractionsVisited.push_back(attractionId);
        }
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            cout << "ID: " << attraction.id << ", Name: " << attraction.name << ", Location: " << attraction.location << endl;
        }
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            cout << "ID: " << tourist.id << ", Name: " << tourist.name << ", Attractions Visited: ";
            for (const auto& attractionId : tourist.attractionsVisited) {
                cout << attractionId << " ";
            }
            cout << endl;
        }
    }

    void searchAttraction(const string& keyword) {
        for (const auto& attraction : attractions) {
            if (attraction.name.find(keyword) != string::npos || attraction.location.find(keyword) != string::npos) {
                cout << "ID: " << attraction.id << ", Name: " << attraction.name << ", Location: " << attraction.location << endl;
            }
        }
    }

    void searchTourist(const string& keyword) {
        for (const auto& tourist : tourists) {
            if (tourist.name.find(keyword) != string::npos) {
                cout << "ID: " << tourist.id << ", Name: " << tourist.name << endl;
            }
        }
    }
};

int main() {
    TourismGuideSystem system;
    system.addAttraction("Eiffel Tower", "Paris");
    system.addAttraction("Great Wall", "China");
    system.addTourist("Alice");
    system.addTourist("Bob");
    system.addVisit(1, 1);
    system.addVisit(1, 2);
    system.displayAttractions();
    system.displayTourists();
    system.searchAttraction("Great");
    system.searchTourist("Alice");
    system.updateAttraction(1, "Eiffel Tower Updated", "Paris, France");
    system.updateTourist(1, "Alice Smith");
    system.displayAttractions();
    system.displayTourists();
    system.deleteAttraction(2);
    system.deleteTourist(2);
    system.displayAttractions();
    system.displayTourists();
    return 0;
}