#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Tourist {
public:
    Tourist(string n, int a, string c) : name(n), age(a), country(c) {}

    string getName() { return name; }
    int getAge() { return age; }
    string getCountry() { return country; }
    void setName(string n) { name = n; }
    void setAge(int a) { age = a; }
    void setCountry(string c) { country = c; }

private:
    string name;
    int age;
    string country;
};

class Attraction {
public:
    Attraction(string n, string l, double p) : name(n), location(l), price(p) {}

    string getName() { return name; }
    string getLocation() { return location; }
    double getPrice() { return price; }
    void setName(string n) { name = n; }
    void setLocation(string l) { location = l; }
    void setPrice(double p) { price = p; }

private:
    string name;
    string location;
    double price;
};

class TourismGuide {
public:
    void addTourist(string name, int age, string country) {
        tourists.push_back(Tourist(name, age, country));
    }

    void deleteTourist(string name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->getName() == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(string name, string newName, int newAge, string newCountry) {
        for (auto &tourist : tourists) {
            if (tourist.getName() == name) {
                tourist.setName(newName);
                tourist.setAge(newAge);
                tourist.setCountry(newCountry);
                break;
            }
        }
    }

    Tourist* searchTourist(string name) {
        for (auto &tourist : tourists) {
            if (tourist.getName() == name) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (auto &tourist : tourists) {
            cout << "Name: " << tourist.getName() 
                 << ", Age: " << tourist.getAge() 
                 << ", Country: " << tourist.getCountry() << endl;
        }
    }

    void addAttraction(string name, string location, double price) {
        attractions.push_back(Attraction(name, location, price));
    }

    void deleteAttraction(string name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->getName() == name) {
                attractions.erase(it);
                break;
            }
        }
    }
    
    void updateAttraction(string name, string newName, string newLocation, double newPrice) {
        for (auto &attraction : attractions) {
            if (attraction.getName() == name) {
                attraction.setName(newName);
                attraction.setLocation(newLocation);
                attraction.setPrice(newPrice);
                break;
            }
        }
    }

    Attraction* searchAttraction(string name) {
        for (auto &attraction : attractions) {
            if (attraction.getName() == name) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayAttractions() {
        for (auto &attraction : attractions) {
            cout << "Name: " << attraction.getName() 
                 << ", Location: " << attraction.getLocation() 
                 << ", Price: " << attraction.getPrice() << endl;
        }
    }

private:
    vector<Tourist> tourists;
    vector<Attraction> attractions;
};

int main() {
    TourismGuide guide;
    
    guide.addTourist("Alice", 30, "Canada");
    guide.addTourist("Bob", 25, "USA");
    
    guide.addAttraction("Eiffel Tower", "Paris", 15.0);
    guide.addAttraction("Statue of Liberty", "New York", 20.0);
    
    guide.displayTourists();
    guide.displayAttractions();
    
    guide.updateTourist("Alice", "Alice Smith", 31, "Canada");
    guide.updateAttraction("Eiffel Tower", "Eiffel Tower", "Paris, France", 16.0);
    
    guide.displayTourists();
    guide.displayAttractions();
    
    return 0;
}