#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Attraction {
    string name;
    string location;
    string description;
};

struct Tourist {
    string name;
    int age;
    string nationality;
};

class TourismGuide {
private:
    vector<Attraction> attractions;
    vector<Tourist> tourists;

    int findAttraction(const string& name) {
        for (int i = 0; i < attractions.size(); i++) {
            if (attractions[i].name == name)
                return i;
        }
        return -1;
    }

    int findTourist(const string& name) {
        for (int i = 0; i < tourists.size(); i++) {
            if (tourists[i].name == name)
                return i;
        }
        return -1;
    }

public:
    void addAttraction(const string& name, const string& location, const string& description) {
        attractions.push_back({name, location, description});
    }

    void deleteAttraction(const string& name) {
        int index = findAttraction(name);
        if (index != -1) {
            attractions.erase(attractions.begin() + index);
        }
    }

    void updateAttraction(const string& name, const string& location, const string& description) {
        int index = findAttraction(name);
        if (index != -1) {
            attractions[index] = {name, location, description};
        }
    }

    void searchAttraction(const string& name) {
        int index = findAttraction(name);
        if (index != -1) {
            cout << "Attraction Found: " << attractions[index].name << ", " << attractions[index].location << ", " << attractions[index].description << endl;
        } else {
            cout << "Attraction not found" << endl;
        }
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            cout << "Attraction: " << attraction.name << ", Location: " << attraction.location << ", Description: " << attraction.description << endl;
        }
    }

    void addTourist(const string& name, int age, const string& nationality) {
        tourists.push_back({name, age, nationality});
    }

    void deleteTourist(const string& name) {
        int index = findTourist(name);
        if (index != -1) {
            tourists.erase(tourists.begin() + index);
        }
    }

    void updateTourist(const string& name, int age, const string& nationality) {
        int index = findTourist(name);
        if (index != -1) {
            tourists[index] = {name, age, nationality};
        }
    }

    void searchTourist(const string& name) {
        int index = findTourist(name);
        if (index != -1) {
            cout << "Tourist Found: " << tourists[index].name << ", Age: " << tourists[index].age << ", Nationality: " << tourists[index].nationality << endl;
        } else {
            cout << "Tourist not found" << endl;
        }
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            cout << "Tourist: " << tourist.name << ", Age: " << tourist.age << ", Nationality: " << tourist.nationality << endl;
        }
    }
};

int main() {
    TourismGuide guide;

    guide.addAttraction("Eiffel Tower", "Paris", "Iconic landmark of France");
    guide.addTourist("John Doe", 30, "American");

    guide.displayAttractions();
    guide.displayTourists();

    guide.searchAttraction("Eiffel Tower");
    guide.searchTourist("John Doe");

    guide.updateAttraction("Eiffel Tower", "Paris", "Famous landmark of France");
    guide.updateTourist("John Doe", 31, "Canadian");

    guide.displayAttractions();
    guide.displayTourists();

    guide.deleteAttraction("Eiffel Tower");
    guide.deleteTourist("John Doe");

    guide.displayAttractions();
    guide.displayTourists();

    return 0;
}