#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    int id;
    std::string name;
    std::string nationality;

    Tourist(int id, const std::string& name, const std::string& nationality)
        : id(id), name(name), nationality(nationality) {}
};

class Attraction {
public:
    int id;
    std::string name;
    std::string location;

    Attraction(int id, const std::string& name, const std::string& location)
        : id(id), name(name), location(location) {}
};

class TourismGuideSystem {
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(int id, const std::string& name, const std::string& nationality) {
        tourists.emplace_back(id, name, nationality);
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(int id, const std::string& name, const std::string& nationality) {
        for (auto& tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.nationality = nationality;
                break;
            }
        }
    }

    void searchTourist(int id) {
        for (const auto& tourist : tourists) {
            if (tourist.id == id) {
                std::cout << "Tourist ID: " << tourist.id << ", Name: " << tourist.name
                          << ", Nationality: " << tourist.nationality << std::endl;
                return;
            }
        }
        std::cout << "Tourist not found." << std::endl;
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Tourist ID: " << tourist.id << ", Name: " << tourist.name
                      << ", Nationality: " << tourist.nationality << std::endl;
        }
    }

    void addAttraction(int id, const std::string& name, const std::string& location) {
        attractions.emplace_back(id, name, location);
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(int id, const std::string& name, const std::string& location) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.location = location;
                break;
            }
        }
    }

    void searchAttraction(int id) {
        for (const auto& attraction : attractions) {
            if (attraction.id == id) {
                std::cout << "Attraction ID: " << attraction.id << ", Name: " << attraction.name
                          << ", Location: " << attraction.location << std::endl;
                return;
            }
        }
        std::cout << "Attraction not found." << std::endl;
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "Attraction ID: " << attraction.id << ", Name: " << attraction.name
                      << ", Location: " << attraction.location << std::endl;
        }
    }
};

int main() {
    TourismGuideSystem tgs;
    tgs.addTourist(1, "John Doe", "USA");
    tgs.addTourist(2, "Maria Garcia", "Spain");
    tgs.displayTourists();
    
    tgs.addAttraction(1, "Eiffel Tower", "Paris");
    tgs.addAttraction(2, "Great Wall", "China");
    tgs.displayAttractions();
    
    tgs.updateTourist(1, "Jonathan Doe", "USA");
    tgs.searchTourist(1);
    
    tgs.updateAttraction(1, "Eiffel Tower", "France");
    tgs.searchAttraction(1);
    
    tgs.deleteTourist(2);
    tgs.displayTourists();
    
    tgs.deleteAttraction(2);
    tgs.displayAttractions();

    return 0;
}