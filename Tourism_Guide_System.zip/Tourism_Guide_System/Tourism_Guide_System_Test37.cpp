#include <iostream>
#include <vector>
#include <string>

struct Attraction {
    std::string name;
    std::string location;
    std::string description;
};

class TourismGuideSystem {
private:
    std::vector<Attraction> attractions;

public:
    void addAttraction(const std::string& name, const std::string& location, const std::string& description) {
        attractions.push_back({name, location, description});
    }

    void deleteAttraction(const std::string& name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(const std::string& name, const std::string& newLocation, const std::string& newDescription) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                attraction.location = newLocation;
                attraction.description = newDescription;
                break;
            }
        }
    }

    void displayAttractions() const {
        for (const auto& attraction : attractions) {
            std::cout << "Name: " << attraction.name << std::endl;
            std::cout << "Location: " << attraction.location << std::endl;
            std::cout << "Description: " << attraction.description << std::endl;
            std::cout << "-------------------------" << std::endl;
        }
    }

    void searchAttraction(const std::string& name) const {
        for (const auto& attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Name: " << attraction.name << std::endl;
                std::cout << "Location: " << attraction.location << std::endl;
                std::cout << "Description: " << attraction.description << std::endl;
                return;
            }
        }
        std::cout << "Attraction not found" << std::endl;
    }
};

int main() {
    TourismGuideSystem system;

    system.addAttraction("Eiffel Tower", "Paris", "An iconic symbol of France.");
    system.addAttraction("Great Wall", "China", "Historical fortification and a tourist attraction.");
    system.displayAttractions();
    system.searchAttraction("Eiffel Tower");
    system.updateAttraction("Eiffel Tower", "Paris, France", "An iconic symbol of France; magnificent view.");
    system.displayAttractions();
    system.deleteAttraction("Great Wall");
    system.displayAttractions();

    return 0;
}