#include <iostream>
#include <vector>
#include <string>

class Attraction {
    std::string name;
    std::string location;
    std::string description;
public:
    Attraction(std::string n, std::string loc, std::string desc) 
        : name(n), location(loc), description(desc) {}

    std::string getName() const {
        return name;
    }

    std::string getDescription() const {
        return description;
    }

    std::string getLocation() const {
        return location;
    }

    void updateDetails(std::string n, std::string loc, std::string desc) {
        name = n;
        location = loc;
        description = desc;
    }
};

class Tourist {
    std::string name;
    std::string contact;
public:
    Tourist(std::string n, std::string c) : name(n), contact(c) {}

    std::string getName() const {
        return name;
    }

    std::string getContact() const {
        return contact;
    }

    void updateDetails(std::string n, std::string c) {
        name = n;
        contact = c;
    }
};

class TourismGuideSystem {
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

    template<typename T>
    int findIndexByName(const std::vector<T>& list, const std::string& name) {
        for (size_t i = 0; i < list.size(); ++i) {
            if (list[i].getName() == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addTourist(std::string name, std::string contact) {
        tourists.emplace_back(name, contact);
    }

    void deleteTourist(std::string name) {
        int index = findIndexByName(tourists, name);
        if (index != -1) {
            tourists.erase(tourists.begin() + index);
        }
    }

    void updateTourist(std::string oldName, std::string newName, std::string newContact) {
        int index = findIndexByName(tourists, oldName);
        if (index != -1) {
            tourists[index].updateDetails(newName, newContact);
        }
    }

    void searchTourist(std::string name) {
        int index = findIndexByName(tourists, name);
        if (index != -1) {
            std::cout << "Tourist: " << tourists[index].getName() 
                      << ", Contact: " << tourists[index].getContact() << '\n';
        } else {
            std::cout << "Tourist not found.\n";
        }
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Tourist: " << tourist.getName() 
                      << ", Contact: " << tourist.getContact() << '\n';
        }
    }

    void addAttraction(std::string name, std::string location, std::string description) {
        attractions.emplace_back(name, location, description);
    }

    void deleteAttraction(std::string name) {
        int index = findIndexByName(attractions, name);
        if (index != -1) {
            attractions.erase(attractions.begin() + index);
        }
    }

    void updateAttraction(std::string oldName, std::string newName, std::string newLocation, std::string newDescription) {
        int index = findIndexByName(attractions, oldName);
        if (index != -1) {
            attractions[index].updateDetails(newName, newLocation, newDescription);
        }
    }

    void searchAttraction(std::string name) {
        int index = findIndexByName(attractions, name);
        if (index != -1) {
            std::cout << "Attraction: " << attractions[index].getName() 
                      << ", Location: " << attractions[index].getLocation()
                      << ", Description: " << attractions[index].getDescription() << '\n';
        } else {
            std::cout << "Attraction not found.\n";
        }
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "Attraction: " << attraction.getName() 
                      << ", Location: " << attraction.getLocation() 
                      << ", Description: " << attraction.getDescription() << '\n';
        }
    }
};

int main() {
    TourismGuideSystem system;
    system.addTourist("Alice", "123456789");
    system.addAttraction("Eiffel Tower", "Paris", "Iconic tower");

    system.displayTourists();
    system.displayAttractions();

    system.updateTourist("Alice", "Alice Smith", "987654321");
    system.updateAttraction("Eiffel Tower", "Eiffel Tower", "Paris, France", "Iconic Parisian landmark");

    system.searchTourist("Alice Smith");
    system.searchAttraction("Eiffel Tower");

    return 0;
}