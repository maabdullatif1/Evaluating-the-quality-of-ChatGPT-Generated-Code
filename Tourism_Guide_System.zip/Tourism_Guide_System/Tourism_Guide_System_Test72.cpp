#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;

    Attraction(const std::string& name, const std::string& location, const std::string& description)
        : name(name), location(location), description(description) {}
};

class Tourist {
public:
    std::string name;
    int age;
    std::vector<std::string> visitedAttractions;

    Tourist(const std::string& name, int age) : name(name), age(age) {}
};

class TourismGuide {
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

    int findTourist(const std::string& name) {
        for (size_t i = 0; i < tourists.size(); ++i) {
            if (tourists[i].name == name) return i;
        }
        return -1;
    }

    int findAttraction(const std::string& name) {
        for (size_t i = 0; i < attractions.size(); ++i) {
            if (attractions[i].name == name) return i;
        }
        return -1;
    }

public:
    void addTourist(const std::string& name, int age) {
        if (findTourist(name) == -1) {
            tourists.emplace_back(name, age);
        } else {
            std::cout << "Tourist already exists.\n";
        }
    }

    void deleteTourist(const std::string& name) {
        int index = findTourist(name);
        if (index != -1) {
            tourists.erase(tourists.begin() + index);
        } else {
            std::cout << "Tourist not found.\n";
        }
    }

    void updateTourist(const std::string& name, int age) {
        int index = findTourist(name);
        if (index != -1) {
            tourists[index].age = age;
        } else {
            std::cout << "Tourist not found.\n";
        }
    }

    void searchTourist(const std::string& name) {
        int index = findTourist(name);
        if (index != -1) {
            std::cout << "Tourist: " << tourists[index].name << ", Age: " << tourists[index].age << "\n";
        } else {
            std::cout << "Tourist not found.\n";
        }
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Tourist: " << tourist.name << ", Age: " << tourist.age << "\n";
        }
    }

    void addAttraction(const std::string& name, const std::string& location, const std::string& description) {
        if (findAttraction(name) == -1) {
            attractions.emplace_back(name, location, description);
        } else {
            std::cout << "Attraction already exists.\n";
        }
    }

    void deleteAttraction(const std::string& name) {
        int index = findAttraction(name);
        if (index != -1) {
            attractions.erase(attractions.begin() + index);
        } else {
            std::cout << "Attraction not found.\n";
        }
    }

    void updateAttraction(const std::string& name, const std::string& location, const std::string& description) {
        int index = findAttraction(name);
        if (index != -1) {
            attractions[index].location = location;
            attractions[index].description = description;
        } else {
            std::cout << "Attraction not found.\n";
        }
    }

    void searchAttraction(const std::string& name) {
        int index = findAttraction(name);
        if (index != -1) {
            std::cout << "Attraction: " << attractions[index].name << ", Location: " << attractions[index].location 
                      << ", Description: " << attractions[index].description << "\n";
        } else {
            std::cout << "Attraction not found.\n";
        }
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "Attraction: " << attraction.name << ", Location: " << attraction.location 
                      << ", Description: " << attraction.description << "\n";
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist("John Doe", 30);
    guide.addAttraction("Eiffel Tower", "Paris", "Iconic French landmark.");

    guide.displayTourists();
    guide.displayAttractions();

    guide.searchTourist("John Doe");
    guide.searchAttraction("Eiffel Tower");

    guide.updateTourist("John Doe", 31);
    guide.updateAttraction("Eiffel Tower", "Paris, France", "Famous landmark of Paris.");

    guide.displayTourists();
    guide.displayAttractions();

    guide.deleteTourist("John Doe");
    guide.deleteAttraction("Eiffel Tower");

    guide.displayTourists();
    guide.displayAttractions();

    return 0;
}