#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Attraction {
    int id;
    string name;
    string location;
    string description;
};

struct Tourist {
    int id;
    string name;
    int age;
};

vector<Attraction> attractions;
vector<Tourist> tourists;

void addAttraction() {
    Attraction attraction;
    cout << "Enter attraction ID: ";
    cin >> attraction.id;
    cin.ignore();
    cout << "Enter attraction name: ";
    getline(cin, attraction.name);
    cout << "Enter location: ";
    getline(cin, attraction.location);
    cout << "Enter description: ";
    getline(cin, attraction.description);
    attractions.push_back(attraction);
}

void deleteAttraction() {
    int id;
    cout << "Enter attraction ID to delete: ";
    cin >> id;
    for(auto it = attractions.begin(); it != attractions.end(); ++it) {
        if(it->id == id) {
            attractions.erase(it);
            break;
        }
    }
}

void updateAttraction() {
    int id;
    cout << "Enter attraction ID to update: ";
    cin >> id;
    for(auto &attraction : attractions) {
        if(attraction.id == id) {
            cin.ignore();
            cout << "Enter new name: ";
            getline(cin, attraction.name);
            cout << "Enter new location: ";
            getline(cin, attraction.location);
            cout << "Enter new description: ";
            getline(cin, attraction.description);
            break;
        }
    }
}

void searchAttraction() {
    int id;
    cout << "Enter attraction ID to search: ";
    cin >> id;
    for(const auto &attraction : attractions) {
        if(attraction.id == id) {
            cout << "ID: " << attraction.id << ", Name: " << attraction.name 
                 << ", Location: " << attraction.location 
                 << ", Description: " << attraction.description << endl;
            return;
        }
    }
    cout << "Attraction not found" << endl;
}

void displayAttractions() {
    for(const auto &attraction : attractions) {
        cout << "ID: " << attraction.id << ", Name: " << attraction.name 
             << ", Location: " << attraction.location 
             << ", Description: " << attraction.description << endl;
    }
}

void addTourist() {
    Tourist tourist;
    cout << "Enter tourist ID: ";
    cin >> tourist.id;
    cin.ignore();
    cout << "Enter name: ";
    getline(cin, tourist.name);
    cout << "Enter age: ";
    cin >> tourist.age;
    tourists.push_back(tourist);
}

void deleteTourist() {
    int id;
    cout << "Enter tourist ID to delete: ";
    cin >> id;
    for(auto it = tourists.begin(); it != tourists.end(); ++it) {
        if(it->id == id) {
            tourists.erase(it);
            break;
        }
    }
}

void updateTourist() {
    int id;
    cout << "Enter tourist ID to update: ";
    cin >> id;
    for(auto &tourist : tourists) {
        if(tourist.id == id) {
            cin.ignore();
            cout << "Enter new name: ";
            getline(cin, tourist.name);
            cout << "Enter new age: ";
            cin >> tourist.age;
            break;
        }
    }
}

void searchTourist() {
    int id;
    cout << "Enter tourist ID to search: ";
    cin >> id;
    for(const auto &tourist : tourists) {
        if(tourist.id == id) {
            cout << "ID: " << tourist.id << ", Name: " << tourist.name 
                 << ", Age: " << tourist.age << endl;
            return;
        }
    }
    cout << "Tourist not found" << endl;
}

void displayTourists() {
    for(const auto &tourist : tourists) {
        cout << "ID: " << tourist.id << ", Name: " << tourist.name 
             << ", Age: " << tourist.age << endl;
    }
}

int main() {
    int choice;
    do {
        cout << "1. Add Attraction\n2. Delete Attraction\n3. Update Attraction\n4. Search Attraction\n5. Display Attractions\n";
        cout << "6. Add Tourist\n7. Delete Tourist\n8. Update Tourist\n9. Search Tourist\n10. Display Tourists\n0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        switch(choice) {
            case 1: addAttraction(); break;
            case 2: deleteAttraction(); break;
            case 3: updateAttraction(); break;
            case 4: searchAttraction(); break;
            case 5: displayAttractions(); break;
            case 6: addTourist(); break;
            case 7: deleteTourist(); break;
            case 8: updateTourist(); break;
            case 9: searchTourist(); break;
            case 10: displayTourists(); break;
            case 0: break;
            default: cout << "Invalid choice" << endl; break;
        }
    } while(choice != 0);
    return 0;
}