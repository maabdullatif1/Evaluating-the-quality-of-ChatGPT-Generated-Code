#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    int id;
    std::string name;
    std::string nationality;

    Tourist(int i, std::string n, std::string nat) : id(i), name(n), nationality(nat) {}
};

class Attraction {
public:
    int id;
    std::string name;
    std::string location;

    Attraction(int i, std::string n, std::string loc) : id(i), name(n), location(loc) {}
};

class TourismGuide {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

    Tourist* findTouristById(int id) {
        for (auto& tourist : tourists) {
            if (tourist.id == id) return &tourist;
        }
        return nullptr;
    }

    Attraction* findAttractionById(int id) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) return &attraction;
        }
        return nullptr;
    }

public:
    void addTourist(int id, const std::string& name, const std::string& nationality) {
        tourists.emplace_back(id, name, nationality);
    }

    void deleteTourist(int id) {
        tourists.erase(std::remove_if(tourists.begin(), tourists.end(),
            [id](Tourist& t) { return t.id == id; }), tourists.end());
    }

    void updateTourist(int id, const std::string& name, const std::string& nationality) {
        Tourist* tourist = findTouristById(id);
        if (tourist) {
            tourist->name = name;
            tourist->nationality = nationality;
        }
    }

    void addAttraction(int id, const std::string& name, const std::string& location) {
        attractions.emplace_back(id, name, location);
    }

    void deleteAttraction(int id) {
        attractions.erase(std::remove_if(attractions.begin(), attractions.end(),
            [id](Attraction& a) { return a.id == id; }), attractions.end());
    }

    void updateAttraction(int id, const std::string& name, const std::string& location) {
        Attraction* attraction = findAttractionById(id);
        if (attraction) {
            attraction->name = name;
            attraction->location = location;
        }
    }

    Tourist* searchTourist(int id) {
        return findTouristById(id);
    }

    Attraction* searchAttraction(int id) {
        return findAttractionById(id);
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Tourist ID: " << tourist.id << ", Name: " << tourist.name 
                      << ", Nationality: " << tourist.nationality << std::endl;
        }
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "Attraction ID: " << attraction.id << ", Name: " << attraction.name 
                      << ", Location: " << attraction.location << std::endl;
        }
    }
};

int main() {
    TourismGuide guide;

    guide.addTourist(1, "John Doe", "American");
    guide.addTourist(2, "Alice Smith", "British");

    guide.addAttraction(1, "Eiffel Tower", "Paris");
    guide.addAttraction(2, "Colosseum", "Rome");

    std::cout << "Tourists:" << std::endl;
    guide.displayTourists();

    std::cout << "Attractions:" << std::endl;
    guide.displayAttractions();

    guide.updateTourist(1, "John Smith", "Canadian");
    guide.updateAttraction(1, "Louvre Museum", "Paris");

    Tourist* tourist = guide.searchTourist(1);
    if (tourist) {
        std::cout << "Found Tourist - ID: " << tourist->id << ", Name: " << tourist->name 
                  << ", Nationality: " << tourist->nationality << std::endl;
    }

    guide.deleteTourist(2);
    guide.deleteAttraction(2);

    std::cout << "After Deletion - Tourists:" << std::endl;
    guide.displayTourists();

    std::cout << "After Deletion - Attractions:" << std::endl;
    guide.displayAttractions();

    return 0;
}