#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Tourist {
    int id;
    string name;
    string contact;
};

struct Attraction {
    int id;
    string name;
    string location;
};

class TourismGuide {
    vector<Tourist> tourists;
    vector<Attraction> attractions;
    int touristID;
    int attractionID;

public:
    TourismGuide() : touristID(1), attractionID(1) {}

    void addTourist(string name, string contact) {
        tourists.push_back({touristID++, name, contact});
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                return;
            }
        }
    }

    void updateTourist(int id, string name, string contact) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.contact = contact;
                return;
            }
        }
    }

    void searchTourist(int id) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                cout << "Tourist ID: " << tourist.id << ", Name: " << tourist.name << ", Contact: " << tourist.contact << endl;
                return;
            }
        }
        cout << "Tourist not found" << endl;
    }

    void displayTourists() {
        for (auto &tourist : tourists) {
            cout << "Tourist ID: " << tourist.id << ", Name: " << tourist.name << ", Contact: " << tourist.contact << endl;
        }
    }

    void addAttraction(string name, string location) {
        attractions.push_back({attractionID++, name, location});
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                return;
            }
        }
    }

    void updateAttraction(int id, string name, string location) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.location = location;
                return;
            }
        }
    }

    void searchAttraction(int id) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                cout << "Attraction ID: " << attraction.id << ", Name: " << attraction.name << ", Location: " << attraction.location << endl;
                return;
            }
        }
        cout << "Attraction not found" << endl;
    }

    void displayAttractions() {
        for (auto &attraction : attractions) {
            cout << "Attraction ID: " << attraction.id << ", Name: " << attraction.name << ", Location: " << attraction.location << endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist("Alice", "123-456-7890");
    guide.addTourist("Bob", "098-765-4321");
    guide.displayTourists();
    guide.updateTourist(1, "Alice Smith", "111-222-3333");
    guide.searchTourist(1);
    guide.deleteTourist(2);

    guide.addAttraction("Eiffel Tower", "Paris");
    guide.addAttraction("Statue of Liberty", "New York");
    guide.displayAttractions();
    guide.updateAttraction(1, "Eiffel Tower", "Paris, France");
    guide.searchAttraction(1);
    guide.deleteAttraction(2);

    return 0;
}