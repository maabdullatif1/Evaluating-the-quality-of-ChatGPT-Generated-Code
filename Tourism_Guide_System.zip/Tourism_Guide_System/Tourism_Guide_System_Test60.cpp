#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    int id;
    std::string name;
    std::string location;
    std::string description;

    Attraction(int id, std::string name, std::string location, std::string description)
        : id(id), name(name), location(location), description(description) {}
};

class TourismGuideSystem {
private:
    std::vector<Attraction> attractions;

public:
    void addAttraction(int id, const std::string& name, const std::string& location, const std::string& description) {
        attractions.emplace_back(id, name, location, description);
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(int id, const std::string& name, const std::string& location, const std::string& description) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.location = location;
                attraction.description = description;
                break;
            }
        }
    }

    const Attraction* searchAttraction(int id) const {
        for (const auto& attraction : attractions) {
            if (attraction.id == id) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayAttractions() const {
        for (const auto& attraction : attractions) {
            std::cout << "ID: " << attraction.id << "\n"
                      << "Name: " << attraction.name << "\n"
                      << "Location: " << attraction.location << "\n"
                      << "Description: " << attraction.description << "\n"
                      << "-------------------------\n";
        }
    }
};

int main() {
    TourismGuideSystem system;
    system.addAttraction(1, "Eiffel Tower", "Paris, France", "Iconic 19th-century tower.");
    system.addAttraction(2, "Statue of Liberty", "New York, USA", "Gift from France, 1886.");
    system.addAttraction(3, "Great Wall of China", "China", "Historical fortification.");

    system.displayAttractions();

    system.updateAttraction(1, "Eiffel Tower", "Paris, France", "Iconic landmark of Paris.");

    const Attraction* attraction = system.searchAttraction(2);
    if (attraction) {
        std::cout << "\nFound Attraction:\n"
                  << "ID: " << attraction->id << "\n"
                  << "Name: " << attraction->name << "\n"
                  << "Location: " << attraction->location << "\n"
                  << "Description: " << attraction->description << "\n";
    }

    system.deleteAttraction(3);
    
    std::cout << "\nAfter Deletion:\n";
    system.displayAttractions();

    return 0;
}