#include <iostream>
#include <string>
#include <vector>

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;

    Attraction(std::string n, std::string l, std::string d) : name(n), location(l), description(d) {}
};

class Tourist {
public:
    std::string name;
    int age;
    std::string nationality;

    Tourist(std::string n, int a, std::string nat) : name(n), age(a), nationality(nat) {}
};

class TourismGuide {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(const std::string &name, int age, const std::string &nationality) {
        tourists.emplace_back(name, age, nationality);
    }
    
    void deleteTourist(const std::string &name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(const std::string &name, int newAge, const std::string &newNationality) {
        for (auto &tourist : tourists) {
            if (tourist.name == name) {
                tourist.age = newAge;
                tourist.nationality = newNationality;
                break;
            }
        }
    }

    Tourist* searchTourist(const std::string &name) {
        for (auto &tourist : tourists) {
            if (tourist.name == name) return &tourist;
        }
        return nullptr;
    }

    void displayTourists() {
        for (auto &tourist : tourists) {
            std::cout << "Name: " << tourist.name << ", Age: " << tourist.age << ", Nationality: " << tourist.nationality << std::endl;
        }
    }

    void addAttraction(const std::string &name, const std::string &location, const std::string &description) {
        attractions.emplace_back(name, location, description);
    }

    void deleteAttraction(const std::string &name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(const std::string &name, const std::string &newLocation, const std::string &newDescription) {
        for (auto &attraction : attractions) {
            if (attraction.name == name) {
                attraction.location = newLocation;
                attraction.description = newDescription;
                break;
            }
        }
    }

    Attraction* searchAttraction(const std::string &name) {
        for (auto &attraction : attractions) {
            if (attraction.name == name) return &attraction;
        }
        return nullptr;
    }

    void displayAttractions() {
        for (auto &attraction : attractions) {
            std::cout << "Name: " << attraction.name << ", Location: " << attraction.location << ", Description: " << attraction.description << std::endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist("John Doe", 30, "USA");
    guide.addAttraction("Eiffel Tower", "Paris", "Iconic tower");

    guide.displayTourists();
    guide.displayAttractions();

    Tourist* t = guide.searchTourist("John Doe");
    if (t) std::cout << "Found tourist: " << t->name << std::endl;

    Attraction* a = guide.searchAttraction("Eiffel Tower");
    if (a) std::cout << "Found attraction: " << a->name << std::endl;

    guide.updateTourist("John Doe", 31, "Canada");
    guide.updateAttraction("Eiffel Tower", "France", "World-famous tower");

    guide.displayTourists();
    guide.displayAttractions();

    guide.deleteTourist("John Doe");
    guide.deleteAttraction("Eiffel Tower");

    guide.displayTourists();
    guide.displayAttractions();

    return 0;
}