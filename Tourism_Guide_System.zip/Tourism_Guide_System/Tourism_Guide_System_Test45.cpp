#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Attraction {
public:
    int id;
    string name;
    string description;

    Attraction(int i, string n, string d) : id(i), name(n), description(d) {}
};

class Tourist {
public:
    int id;
    string name;
    int age;

    Tourist(int i, string n, int a) : id(i), name(n), age(a) {}
};

class TourismGuide {
private:
    vector<Attraction> attractions;
    vector<Tourist> tourists;
    int nextAttractionId = 1;
    int nextTouristId = 1;

public:
    void addAttraction(string name, string description) {
        attractions.push_back(Attraction(nextAttractionId++, name, description));
    }

    void addTourist(string name, int age) {
        tourists.push_back(Tourist(nextTouristId++, name, age));
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateAttraction(int id, string name, string description) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.description = description;
                break;
            }
        }
    }

    void updateTourist(int id, string name, int age) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.age = age;
                break;
            }
        }
    }

    Attraction* searchAttraction(int id) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                return &attraction;
            }
        }
        return nullptr;
    }

    Tourist* searchTourist(int id) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            cout << "ID: " << attraction.id << ", Name: " << attraction.name << ", Description: " << attraction.description << endl;
        }
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            cout << "ID: " << tourist.id << ", Name: " << tourist.name << ", Age: " << tourist.age << endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addAttraction("Eiffel Tower", "A famous landmark in Paris.");
    guide.addTourist("John Doe", 30);
    guide.displayAttractions();
    guide.displayTourists();
    guide.updateAttraction(1, "Louvre Museum", "World's largest art museum.");
    guide.updateTourist(1, "Jane Doe", 25);
    guide.displayAttractions();
    guide.displayTourists();
    guide.deleteAttraction(1);
    guide.deleteTourist(1);
    guide.displayAttractions();
    guide.displayTourists();
    return 0;
}