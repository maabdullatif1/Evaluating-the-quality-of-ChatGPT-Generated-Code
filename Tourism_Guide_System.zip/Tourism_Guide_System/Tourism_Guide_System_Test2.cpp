#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Tourist {
public:
    int id;
    string name;
    string country;
    
    Tourist(int id, string name, string country) : id(id), name(name), country(country) {}
};

class Attraction {
public:
    int id;
    string name;
    string location;
    
    Attraction(int id, string name, string location) : id(id), name(name), location(location) {}
};

class TourismGuide {
    vector<Tourist> tourists;
    vector<Attraction> attractions;
    
public:
    void addTourist(int id, string name, string country) {
        tourists.push_back(Tourist(id, name, country));
    }
    
    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }
    
    void updateTourist(int id, string name, string country) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.country = country;
                break;
            }
        }
    }
    
    void searchTourist(int id) {
        for (const auto &tourist : tourists) {
            if (tourist.id == id) {
                cout << "Tourist found: " << tourist.name << ", " << tourist.country << endl;
                return;
            }
        }
        cout << "Tourist not found." << endl;
    }
    
    void displayTourists() {
        for (const auto &tourist : tourists) {
            cout << "ID: " << tourist.id << ", Name: " << tourist.name << ", Country: " << tourist.country << endl;
        }
    }
    
    void addAttraction(int id, string name, string location) {
        attractions.push_back(Attraction(id, name, location));
    }
    
    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }
    
    void updateAttraction(int id, string name, string location) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.location = location;
                break;
            }
        }
    }
    
    void searchAttraction(int id) {
        for (const auto &attraction : attractions) {
            if (attraction.id == id) {
                cout << "Attraction found: " << attraction.name << ", " << attraction.location << endl;
                return;
            }
        }
        cout << "Attraction not found." << endl;
    }
    
    void displayAttractions() {
        for (const auto &attraction : attractions) {
            cout << "ID: " << attraction.id << ", Name: " << attraction.name << ", Location: " << attraction.location << endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist(1, "John Doe", "USA");
    guide.addTourist(2, "Jane Doe", "Canada");
    guide.displayTourists();
    guide.updateTourist(1, "John Smith", "USA");
    guide.searchTourist(1);
    guide.deleteTourist(2);
    guide.displayTourists();
    guide.addAttraction(1, "Eiffel Tower", "Paris");
    guide.addAttraction(2, "Statue of Liberty", "New York");
    guide.displayAttractions();
    guide.updateAttraction(1, "Louvre Museum", "Paris");
    guide.searchAttraction(1);
    guide.deleteAttraction(2);
    guide.displayAttractions();
    return 0;
}