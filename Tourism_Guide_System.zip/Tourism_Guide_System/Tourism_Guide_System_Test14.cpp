#include <iostream>
#include <string>

using namespace std;

struct Attraction {
    string name;
    string location;
    string description;
};

struct Tourist {
    string name;
    string nationality;
    string email;
};

struct Node {
    Attraction attraction;
    Tourist tourist;
    Node* next;
};

class TourismGuide {
private:
    Node* head;

    Node* findTourist(string name) {
        Node* current = head;
        while (current != nullptr) {
            if (current->tourist.name == name) {
                return current;
            }
            current = current->next;
        }
        return nullptr;
    }

    Node* findAttraction(string name) {
        Node* current = head;
        while (current != nullptr) {
            if (current->attraction.name == name) {
                return current;
            }
            current = current->next;
        }
        return nullptr;
    }

public:
    TourismGuide() : head(nullptr) {}

    void addTourist(string name, string nationality, string email) {
        if (findTourist(name) != nullptr) {
            cout << "Tourist already exists.\n";
            return;
        }
        Node* newNode = new Node();
        newNode->tourist = {name, nationality, email};
        newNode->next = head;
        head = newNode;
    }

    void deleteTourist(string name) {
        Node *current = head, *prev = nullptr;
        while (current != nullptr && current->tourist.name != name) {
            prev = current;
            current = current->next;
        }
        if (current == nullptr) {
            cout << "Tourist not found.\n";
            return;
        }
        if (prev == nullptr) {
            head = current->next;
        } else {
            prev->next = current->next;
        }
        delete current;
    }

    void updateTourist(string name, string nationality, string email) {
        Node* tourist = findTourist(name);
        if (tourist != nullptr) {
            tourist->tourist.nationality = nationality;
            tourist->tourist.email = email;
        } else {
            cout << "Tourist not found.\n";
        }
    }

    void searchTourist(string name) {
        Node* tourist = findTourist(name);
        if (tourist != nullptr) {
            cout << "Tourist Found: " << tourist->tourist.name << ", " << tourist->tourist.nationality << ", " << tourist->tourist.email << "\n";
        } else {
            cout << "Tourist not found.\n";
        }
    }

    void displayTourists() {
        Node* current = head;
        while (current != nullptr) {
            cout << "Tourist: " << current->tourist.name << ", " << current->tourist.nationality << ", " << current->tourist.email << "\n";
            current = current->next;
        }
    }

    void addAttraction(string name, string location, string description) {
        if (findAttraction(name) != nullptr) {
            cout << "Attraction already exists.\n";
            return;
        }
        Node* newNode = new Node();
        newNode->attraction = {name, location, description};
        newNode->next = head;
        head = newNode;
    }

    void deleteAttraction(string name) {
        Node *current = head, *prev = nullptr;
        while (current != nullptr && current->attraction.name != name) {
            prev = current;
            current = current->next;
        }
        if (current == nullptr) {
            cout << "Attraction not found.\n";
            return;
        }
        if (prev == nullptr) {
            head = current->next;
        } else {
            prev->next = current->next;
        }
        delete current;
    }

    void updateAttraction(string name, string location, string description) {
        Node* attraction = findAttraction(name);
        if (attraction != nullptr) {
            attraction->attraction.location = location;
            attraction->attraction.description = description;
        } else {
            cout << "Attraction not found.\n";
        }
    }

    void searchAttraction(string name) {
        Node* attraction = findAttraction(name);
        if (attraction != nullptr) {
            cout << "Attraction Found: " << attraction->attraction.name << ", " << attraction->attraction.location << ", " << attraction->attraction.description << "\n";
        } else {
            cout << "Attraction not found.\n";
        }
    }

    void displayAttractions() {
        Node* current = head;
        while (current != nullptr) {
            cout << "Attraction: " << current->attraction.name << ", " << current->attraction.location << ", " << current->attraction.description << "\n";
            current = current->next;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist("John Doe", "American", "john@example.com");
    guide.updateTourist("John Doe", "Canadian", "johnny@example.com");
    guide.searchTourist("John Doe");
    guide.displayTourists();

    guide.addAttraction("Eiffel Tower", "Paris", "Iconic tower in Paris");
    guide.updateAttraction("Eiffel Tower", "Paris", "Landmark of Paris");
    guide.searchAttraction("Eiffel Tower");
    guide.displayAttractions();

    return 0;
}