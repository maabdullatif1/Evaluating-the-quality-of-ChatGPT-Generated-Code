#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;

    Attraction(std::string n, std::string loc, std::string desc) 
        : name(n), location(loc), description(desc) {}
};

class Tourist {
public:
    std::string name;
    int age;
    std::string country;

    Tourist(std::string n, int a, std::string c) 
        : name(n), age(a), country(c) {}
};

class TourismGuide {
private:
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;

public:
    void addAttraction(std::string name, std::string location, std::string description) {
        attractions.push_back(Attraction(name, location, description));
    }

    void deleteAttraction(std::string name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(std::string oldName, std::string newName, std::string newLocation, std::string newDescription) {
        for (auto &attraction : attractions) {
            if (attraction.name == oldName) {
                attraction.name = newName;
                attraction.location = newLocation;
                attraction.description = newDescription;
                break;
            }
        }
    }

    void searchAttraction(std::string name) {
        for (const auto &attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Attraction Found: " << attraction.name << ", " << attraction.location 
                          << ", " << attraction.description << std::endl;
                return;
            }
        }
        std::cout << "Attraction not found." << std::endl;
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            std::cout << "Attraction: " << attraction.name << ", Location: " << attraction.location 
                      << ", Description: " << attraction.description << std::endl;
        }
    }

    void addTourist(std::string name, int age, std::string country) {
        tourists.push_back(Tourist(name, age, country));
    }

    void deleteTourist(std::string name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(std::string oldName, std::string newName, int newAge, std::string newCountry) {
        for (auto &tourist : tourists) {
            if (tourist.name == oldName) {
                tourist.name = newName;
                tourist.age = newAge;
                tourist.country = newCountry;
                break;
            }
        }
    }

    void searchTourist(std::string name) {
        for (const auto &tourist : tourists) {
            if (tourist.name == name) {
                std::cout << "Tourist Found: " << tourist.name << ", Age: " << tourist.age 
                          << ", Country: " << tourist.country << std::endl;
                return;
            }
        }
        std::cout << "Tourist not found." << std::endl;
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            std::cout << "Tourist: " << tourist.name << ", Age: " << tourist.age 
                      << ", Country: " << tourist.country << std::endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addAttraction("Eiffel Tower", "Paris", "Iconic French landmark");
    guide.addTourist("John Doe", 30, "USA");
    guide.displayAttractions();
    guide.displayTourists();
    guide.searchAttraction("Eiffel Tower");
    guide.searchTourist("John Doe");
    guide.updateAttraction("Eiffel Tower", "Eiffel Tower", "Paris, France", "Famous tower in Paris");
    guide.updateTourist("John Doe", "John Doe", 31, "UK");
    guide.displayAttractions();
    guide.displayTourists();
    guide.deleteAttraction("Eiffel Tower");
    guide.deleteTourist("John Doe");
    guide.displayAttractions();
    guide.displayTourists();
    return 0;
}