#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Attraction {
public:
    string name;
    string location;
    string description;

    Attraction(string n, string l, string d) : name(n), location(l), description(d) {}
};

class Tourist {
public:
    string name;
    int age;
    string nationality;

    Tourist(string n, int a, string nat) : name(n), age(a), nationality(nat) {}
};

class TourismGuideSystem {
private:
    vector<Attraction> attractions;
    vector<Tourist> tourists;

public:
    void addAttraction() {
        string name, location, description;
        cout << "Enter attraction name: ";
        cin.ignore();
        getline(cin, name);
        cout << "Enter location: ";
        getline(cin, location);
        cout << "Enter description: ";
        getline(cin, description);
        attractions.push_back(Attraction(name, location, description));
    }

    void deleteAttraction() {
        string name;
        cout << "Enter attraction name to delete: ";
        cin.ignore();
        getline(cin, name);
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                cout << "Attraction deleted.\n";
                return;
            }
        }
        cout << "Attraction not found.\n";
    }

    void updateAttraction() {
        string name;
        cout << "Enter attraction name to update: ";
        cin.ignore();
        getline(cin, name);
        for (auto &attraction : attractions) {
            if (attraction.name == name) {
                cout << "Enter new location: ";
                getline(cin, attraction.location);
                cout << "Enter new description: ";
                getline(cin, attraction.description);
                cout << "Attraction updated.\n";
                return;
            }
        }
        cout << "Attraction not found.\n";
    }

    void searchAttraction() {
        string name;
        cout << "Enter attraction name to search: ";
        cin.ignore();
        getline(cin, name);
        for (auto &attraction : attractions) {
            if (attraction.name == name) {
                cout << "Name: " << attraction.name << "\nLocation: " << attraction.location << "\nDescription: " << attraction.description << "\n";
                return;
            }
        }
        cout << "Attraction not found.\n";
    }

    void displayAttractions() {
        for (auto &attraction : attractions) {
            cout << "Name: " << attraction.name << "\nLocation: " << attraction.location << "\nDescription: " << attraction.description << "\n";
        }
    }

    void addTourist() {
        string name, nationality;
        int age;
        cout << "Enter tourist name: ";
        cin.ignore();
        getline(cin, name);
        cout << "Enter age: ";
        cin >> age;
        cout << "Enter nationality: ";
        cin.ignore();
        getline(cin, nationality);
        tourists.push_back(Tourist(name, age, nationality));
    }

    void deleteTourist() {
        string name;
        cout << "Enter tourist name to delete: ";
        cin.ignore();
        getline(cin, name);
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                cout << "Tourist deleted.\n";
                return;
            }
        }
        cout << "Tourist not found.\n";
    }

    void updateTourist() {
        string name;
        cout << "Enter tourist name to update: ";
        cin.ignore();
        getline(cin, name);
        for (auto &tourist : tourists) {
            if (tourist.name == name) {
                cout << "Enter new age: ";
                cin >> tourist.age;
                cout << "Enter new nationality: ";
                cin.ignore();
                getline(cin, tourist.nationality);
                cout << "Tourist updated.\n";
                return;
            }
        }
        cout << "Tourist not found.\n";
    }

    void searchTourist() {
        string name;
        cout << "Enter tourist name to search: ";
        cin.ignore();
        getline(cin, name);
        for (auto &tourist : tourists) {
            if (tourist.name == name) {
                cout << "Name: " << tourist.name << "\nAge: " << tourist.age << "\nNationality: " << tourist.nationality << "\n";
                return;
            }
        }
        cout << "Tourist not found.\n";
    }

    void displayTourists() {
        for (auto &tourist : tourists) {
            cout << "Name: " << tourist.name << "\nAge: " << tourist.age << "\nNationality: " << tourist.nationality << "\n";
        }
    }
};

int main() {
    TourismGuideSystem system;
    int choice;
    do {
        cout << "\n1. Add Attraction\n2. Delete Attraction\n3. Update Attraction\n4. Search Attraction\n5. Display Attractions\n";
        cout << "6. Add Tourist\n7. Delete Tourist\n8. Update Tourist\n9. Search Tourist\n10. Display Tourists\n0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: system.addAttraction(); break;
            case 2: system.deleteAttraction(); break;
            case 3: system.updateAttraction(); break;
            case 4: system.searchAttraction(); break;
            case 5: system.displayAttractions(); break;
            case 6: system.addTourist(); break;
            case 7: system.deleteTourist(); break;
            case 8: system.updateTourist(); break;
            case 9: system.searchTourist(); break;
            case 10: system.displayTourists(); break;
            case 0: break;
            default: cout << "Invalid choice.\n"; break;
        }
    } while (choice != 0);

    return 0;
}