#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Attraction {
public:
    string name;
    string location;
    string description;

    Attraction(string n, string l, string d) : name(n), location(l), description(d) {}
};

class Tourist {
public:
    string name;
    int age;
    string nationality;

    Tourist(string n, int a, string nat) : name(n), age(a), nationality(nat) {}
};

class TourismGuideSystem {
private:
    vector<Attraction> attractions;
    vector<Tourist> tourists;

public:
    void addAttraction(string name, string location, string description) {
        attractions.emplace_back(name, location, description);
    }

    void deleteAttraction(string name) {
        attractions.erase(remove_if(attractions.begin(), attractions.end(), [&](Attraction& a) { return a.name == name; }), attractions.end());
    }

    void updateAttraction(string oldName, string newName, string newLocation, string newDescription) {
        for (auto& attraction : attractions) {
            if (attraction.name == oldName) {
                attraction.name = newName;
                attraction.location = newLocation;
                attraction.description = newDescription;
                break;
            }
        }
    }

    void searchAttraction(string name) {
        for (const auto& attraction : attractions) {
            if (attraction.name == name) {
                cout << "Found Attraction: " << attraction.name << ", Location: " << attraction.location << ", Description: " << attraction.description << endl;
                return;
            }
        }
        cout << "Attraction not found.\n";
    }

    void displayAttractions() {
        if (attractions.empty()) {
            cout << "No attractions available.\n";
            return;
        }
        for (const auto& attraction : attractions) {
            cout << "Attraction: " << attraction.name << ", Location: " << attraction.location << ", Description: " << attraction.description << endl;
        }
    }

    void addTourist(string name, int age, string nationality) {
        tourists.emplace_back(name, age, nationality);
    }

    void deleteTourist(string name) {
        tourists.erase(remove_if(tourists.begin(), tourists.end(), [&](Tourist& t) { return t.name == name; }), tourists.end());
    }

    void updateTourist(string oldName, string newName, int newAge, string newNationality) {
        for (auto& tourist : tourists) {
            if (tourist.name == oldName) {
                tourist.name = newName;
                tourist.age = newAge;
                tourist.nationality = newNationality;
                break;
            }
        }
    }

    void searchTourist(string name) {
        for (const auto& tourist : tourists) {
            if (tourist.name == name) {
                cout << "Found Tourist: " << tourist.name << ", Age: " << tourist.age << ", Nationality: " << tourist.nationality << endl;
                return;
            }
        }
        cout << "Tourist not found.\n";
    }

    void displayTourists() {
        if (tourists.empty()) {
            cout << "No tourists available.\n";
            return;
        }
        for (const auto& tourist : tourists) {
            cout << "Tourist: " << tourist.name << ", Age: " << tourist.age << ", Nationality: " << tourist.nationality << endl;
        }
    }
};

int main() {
    TourismGuideSystem system;
    system.addAttraction("Eiffel Tower", "Paris", "An iconic landmark of France.");
    system.displayAttractions();

    system.addTourist("John Doe", 30, "American");
    system.displayTourists();

    system.searchAttraction("Eiffel Tower");
    system.searchTourist("John Doe");

    system.updateAttraction("Eiffel Tower", "Louvre Museum", "Paris", "Famous art museum.");
    system.searchAttraction("Louvre Museum");

    system.deleteAttraction("Louvre Museum");
    system.displayAttractions();

    system.updateTourist("John Doe", "Jane Doe", 28, "Canadian");
    system.searchTourist("Jane Doe");

    system.deleteTourist("Jane Doe");
    system.displayTourists();

    return 0;
}