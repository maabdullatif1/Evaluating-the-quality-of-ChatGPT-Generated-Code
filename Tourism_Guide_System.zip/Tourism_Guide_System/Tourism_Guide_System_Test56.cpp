#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    int id;
    std::string name;
    std::string nationality;

    Tourist(int id, const std::string& name, const std::string& nationality)
        : id(id), name(name), nationality(nationality) {}
};

class Attraction {
public:
    int id;
    std::string name;
    std::string location;

    Attraction(int id, const std::string& name, const std::string& location)
        : id(id), name(name), location(location) {}
};

class TourismGuideSystem {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

    template<typename T>
    T* findById(std::vector<T>& list, int id) {
        for (auto& item : list) {
            if (item.id == id) {
                return &item;
            }
        }
        return nullptr;
    }

    template<typename T>
    void displayList(const std::vector<T>& list) {
        for (const auto& item : list) {
            std::cout << "ID: " << item.id << ", Name: " << item.name << "\n";
        }
    }

public:
    void addTourist(int id, const std::string& name, const std::string& nationality) {
        tourists.emplace_back(id, name, nationality);
    }

    void addAttraction(int id, const std::string& name, const std::string& location) {
        attractions.emplace_back(id, name, location);
    }

    void deleteTourist(int id) {
        tourists.erase(std::remove_if(tourists.begin(), tourists.end(),
            [id](const Tourist& t) { return t.id == id; }), tourists.end());
    }

    void deleteAttraction(int id) {
        attractions.erase(std::remove_if(attractions.begin(), attractions.end(),
            [id](const Attraction& a) { return a.id == id; }), attractions.end());
    }

    void updateTourist(int id, const std::string& newName, const std::string& newNationality) {
        auto* tourist = findById(tourists, id);
        if (tourist) {
            tourist->name = newName;
            tourist->nationality = newNationality;
        }
    }

    void updateAttraction(int id, const std::string& newName, const std::string& newLocation) {
        auto* attraction = findById(attractions, id);
        if (attraction) {
            attraction->name = newName;
            attraction->location = newLocation;
        }
    }

    void searchTourist(int id) {
        auto* tourist = findById(tourists, id);
        if (tourist) {
            std::cout << "ID: " << tourist->id << ", Name: " << tourist->name
                      << ", Nationality: " << tourist->nationality << "\n";
        }
    }

    void searchAttraction(int id) {
        auto* attraction = findById(attractions, id);
        if (attraction) {
            std::cout << "ID: " << attraction->id << ", Name: " << attraction->name
                      << ", Location: " << attraction->location << "\n";
        }
    }

    void displayTourists() {
        displayList(tourists);
    }

    void displayAttractions() {
        displayList(attractions);
    }
};

int main() {
    TourismGuideSystem system;
    system.addTourist(1, "Alice", "American");
    system.addTourist(2, "Bob", "British");
    system.addAttraction(1, "Eiffel Tower", "Paris");
    system.addAttraction(2, "Colosseum", "Rome");
    
    system.updateTourist(1, "Alice Smith", "American");
    system.updateAttraction(1, "Eiffel Tower", "Paris, France");
    
    system.searchTourist(1);
    system.searchAttraction(1);
    
    system.displayTourists();
    system.displayAttractions();

    system.deleteTourist(2);
    system.deleteAttraction(2);

    system.displayTourists();
    system.displayAttractions();

    return 0;
}