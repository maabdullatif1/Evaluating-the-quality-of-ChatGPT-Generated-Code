#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    int id;
    std::string name;
    std::string nationality;

    Tourist(int id, const std::string &name, const std::string &nationality)
        : id(id), name(name), nationality(nationality) {}
};

class Attraction {
public:
    int id;
    std::string name;
    std::string location;
    std::string description;

    Attraction(int id, const std::string &name, const std::string &location, const std::string &description)
        : id(id), name(name), location(location), description(description) {}
};

class TourismGuide {
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(int id, const std::string &name, const std::string &nationality) {
        tourists.emplace_back(id, name, nationality);
    }

    void deleteTourist(int id) {
        tourists.erase(std::remove_if(tourists.begin(), tourists.end(), 
                       [id](Tourist &t) { return t.id == id; }), tourists.end());
    }

    void updateTourist(int id, const std::string &name, const std::string &nationality) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.nationality = nationality;
                break;
            }
        }
    }

    Tourist* searchTourist(int id) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            std::cout << "ID: " << tourist.id << ", Name: " << tourist.name 
                      << ", Nationality: " << tourist.nationality << std::endl;
        }
    }

    void addAttraction(int id, const std::string &name, const std::string &location, const std::string &description) {
        attractions.emplace_back(id, name, location, description);
    }

    void deleteAttraction(int id) {
        attractions.erase(std::remove_if(attractions.begin(), attractions.end(), 
                          [id](Attraction &a) { return a.id == id; }), attractions.end());
    }

    void updateAttraction(int id, const std::string &name, const std::string &location, const std::string &description) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.location = location;
                attraction.description = description;
                break;
            }
        }
    }

    Attraction* searchAttraction(int id) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            std::cout << "ID: " << attraction.id << ", Name: " << attraction.name 
                      << ", Location: " << attraction.location 
                      << ", Description: " << attraction.description << std::endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist(1, "John Doe", "USA");
    guide.addTourist(2, "Jane Smith", "UK");
    guide.displayTourists();

    guide.addAttraction(1, "Eiffel Tower", "Paris", "Iconic landmark of France");
    guide.addAttraction(2, "Great Wall", "China", "Ancient World Wonder");
    guide.displayAttractions();

    guide.updateTourist(1, "John Doe Updated", "Canada");
    guide.displayTourists();

    guide.updateAttraction(1, "Eiffel Tower Updated", "Paris", "The famous landmark");
    guide.displayAttractions();

    return 0;
}