#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    int id;
    std::string name;
    std::string location;
    std::string description;

    Attraction(int id, std::string name, std::string location, std::string description)
        : id(id), name(name), location(location), description(description) {}
};

class Tourist {
public:
    int id;
    std::string name;
    int age;
    std::string nationality;

    Tourist(int id, std::string name, int age, std::string nationality)
        : id(id), name(name), age(age), nationality(nationality) {}
};

class TourismSystem {
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;
    int attractionIdCounter = 1;
    int touristIdCounter = 1;

public:
    void addAttraction(std::string name, std::string location, std::string description) {
        attractions.emplace_back(attractionIdCounter++, name, location, description);
    }

    void addTourist(std::string name, int age, std::string nationality) {
        tourists.emplace_back(touristIdCounter++, name, age, nationality);
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateAttraction(int id, std::string name, std::string location, std::string description) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.location = location;
                attraction.description = description;
                break;
            }
        }
    }

    void updateTourist(int id, std::string name, int age, std::string nationality) {
        for (auto& tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.age = age;
                tourist.nationality = nationality;
                break;
            }
        }
    }

    void searchAttraction(std::string name) {
        for (const auto& attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Attraction found: ID=" << attraction.id << ", Name=" << attraction.name 
                          << ", Location=" << attraction.location << ", Description=" << attraction.description 
                          << std::endl;
            }
        }
    }

    void searchTourist(std::string name) {
        for (const auto& tourist : tourists) {
            if (tourist.name == name) {
                std::cout << "Tourist found: ID=" << tourist.id << ", Name=" << tourist.name << ", Age=" 
                          << tourist.age << ", Nationality=" << tourist.nationality << std::endl;
            }
        }
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "Attraction: ID=" << attraction.id << ", Name=" << attraction.name 
                      << ", Location=" << attraction.location << ", Description=" << attraction.description 
                      << std::endl;
        }
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Tourist: ID=" << tourist.id << ", Name=" << tourist.name << ", Age=" 
                      << tourist.age << ", Nationality=" << tourist.nationality << std::endl;
        }
    }
};

int main() {
    TourismSystem system;
    system.addAttraction("Eiffel Tower", "Paris", "An iconic symbol of France.");
    system.addTourist("John Doe", 30, "USA");
    system.displayAttractions();
    system.displayTourists();
    system.searchAttraction("Eiffel Tower");
    system.updateTourist(1, "John Smith", 31, "Canada");
    system.displayTourists();
    system.deleteAttraction(1);
    system.displayAttractions();
    return 0;
}