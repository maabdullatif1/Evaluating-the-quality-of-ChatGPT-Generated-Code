#include <iostream>
#include <vector>
#include <string>

struct Tourist {
    int id;
    std::string name;
    std::string nationality;
};

struct Attraction {
    int id;
    std::string name;
    std::string location;
};

std::vector<Tourist> tourists;
std::vector<Attraction> attractions;

int GenerateId() {
    static int id = 0;
    return ++id;
}

void AddTourist() {
    Tourist t;
    t.id = GenerateId();
    std::cout << "Enter name: ";
    std::cin >> t.name;
    std::cout << "Enter nationality: ";
    std::cin >> t.nationality;
    tourists.push_back(t);
}

void AddAttraction() {
    Attraction a;
    a.id = GenerateId();
    std::cout << "Enter name: ";
    std::cin >> a.name;
    std::cout << "Enter location: ";
    std::cin >> a.location;
    attractions.push_back(a);
}

void DeleteTourist() {
    int id;
    std::cout << "Enter tourist ID to delete: ";
    std::cin >> id;
    for (auto it = tourists.begin(); it != tourists.end(); ++it) {
        if (it->id == id) {
            tourists.erase(it);
            break;
        }
    }
}

void DeleteAttraction() {
    int id;
    std::cout << "Enter attraction ID to delete: ";
    std::cin >> id;
    for (auto it = attractions.begin(); it != attractions.end(); ++it) {
        if (it->id == id) {
            attractions.erase(it);
            break;
        }
    }
}

void UpdateTourist() {
    int id;
    std::cout << "Enter tourist ID to update: ";
    std::cin >> id;
    for (auto &t : tourists) {
        if (t.id == id) {
            std::cout << "Enter new name: ";
            std::cin >> t.name;
            std::cout << "Enter new nationality: ";
            std::cin >> t.nationality;
            break;
        }
    }
}

void UpdateAttraction() {
    int id;
    std::cout << "Enter attraction ID to update: ";
    std::cin >> id;
    for (auto &a : attractions) {
        if (a.id == id) {
            std::cout << "Enter new name: ";
            std::cin >> a.name;
            std::cout << "Enter new location: ";
            std::cin >> a.location;
            break;
        }
    }
}

void SearchTourist() {
    std::string name;
    std::cout << "Enter tourist name to search: ";
    std::cin >> name;
    for (const auto &t : tourists) {
        if (t.name == name) {
            std::cout << "Tourist ID: " << t.id << ", Name: " << t.name << ", Nationality: " << t.nationality << '\n';
        }
    }
}

void SearchAttraction() {
    std::string name;
    std::cout << "Enter attraction name to search: ";
    std::cin >> name;
    for (const auto &a : attractions) {
        if (a.name == name) {
            std::cout << "Attraction ID: " << a.id << ", Name: " << a.name << ", Location: " << a.location << '\n';
        }
    }
}

void DisplayTourists() {
    for (const auto &t : tourists) {
        std::cout << "Tourist ID: " << t.id << ", Name: " << t.name << ", Nationality: " << t.nationality << '\n';
    }
}

void DisplayAttractions() {
    for (const auto &a : attractions) {
        std::cout << "Attraction ID: " << a.id << ", Name: " << a.name << ", Location: " << a.location << '\n';
    }
}

int main() {
    int choice;
    while (true) {
        std::cout << "1. Add Tourist\n2. Delete Tourist\n3. Update Tourist\n4. Search Tourist\n5. Display Tourists\n";
        std::cout << "6. Add Attraction\n7. Delete Attraction\n8. Update Attraction\n9. Search Attraction\n10. Display Attractions\n11. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1: AddTourist(); break;
            case 2: DeleteTourist(); break;
            case 3: UpdateTourist(); break;
            case 4: SearchTourist(); break;
            case 5: DisplayTourists(); break;
            case 6: AddAttraction(); break;
            case 7: DeleteAttraction(); break;
            case 8: UpdateAttraction(); break;
            case 9: SearchAttraction(); break;
            case 10: DisplayAttractions(); break;
            case 11: return 0;
            default: std::cout << "Invalid choice\n";
        }
    }
    return 0;
}