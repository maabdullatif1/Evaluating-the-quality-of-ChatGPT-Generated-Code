#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Tourist {
    int id;
    string name;
    string nationality;
};

struct Attraction {
    int id;
    string name;
    string description;
};

class TourismGuideSystem {
public:
    void addTourist(int id, const string &name, const string &nationality) {
        tourists.push_back({id, name, nationality});
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(int id, const string &name, const string &nationality) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.nationality = nationality;
                break;
            }
        }
    }

    void searchTourist(int id) const {
        for (const auto &tourist : tourists) {
            if (tourist.id == id) {
                cout << "Tourist ID: " << tourist.id << ", Name: " << tourist.name
                     << ", Nationality: " << tourist.nationality << endl;
                return;
            }
        }
        cout << "Tourist not found!" << endl;
    }

    void displayTourists() const {
        for (const auto &tourist : tourists) {
            cout << "ID: " << tourist.id << ", Name: " << tourist.name
                 << ", Nationality: " << tourist.nationality << endl;
        }
    }

    void addAttraction(int id, const string &name, const string &description) {
        attractions.push_back({id, name, description});
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(int id, const string &name, const string &description) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.description = description;
                break;
            }
        }
    }

    void searchAttraction(int id) const {
        for (const auto &attraction : attractions) {
            if (attraction.id == id) {
                cout << "Attraction ID: " << attraction.id << ", Name: " << attraction.name
                     << ", Description: " << attraction.description << endl;
                return;
            }
        }
        cout << "Attraction not found!" << endl;
    }

    void displayAttractions() const {
        for (const auto &attraction : attractions) {
            cout << "ID: " << attraction.id << ", Name: " << attraction.name
                 << ", Description: " << attraction.description << endl;
        }
    }

private:
    vector<Tourist> tourists;
    vector<Attraction> attractions;
};

int main() {
    TourismGuideSystem system;
    system.addTourist(1, "Alice", "USA");
    system.addTourist(2, "Bob", "UK");

    system.addAttraction(1, "Grand Canyon", "A steep-sided canyon carved by the Colorado River.");
    system.addAttraction(2, "Statue of Liberty", "A colossal neoclassical sculpture on Liberty Island.");

    system.displayTourists();
    system.displayAttractions();

    system.updateTourist(1, "Alice Smith", "USA");
    system.updateAttraction(1, "Grand Canyon National Park", "A United States National Park.");

    system.searchTourist(1);
    system.searchAttraction(1);

    system.deleteTourist(2);
    system.deleteAttraction(2);

    system.displayTourists();
    system.displayAttractions();

    return 0;
}