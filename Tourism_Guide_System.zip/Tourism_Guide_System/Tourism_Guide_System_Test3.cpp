#include <iostream>
#include <string>
#include <vector>

class Tourist {
public:
    std::string name;
    std::string nationality;
    Tourist(std::string name, std::string nationality) : name(name), nationality(nationality) {}
};

class Attraction {
public:
    std::string name;
    std::string location;
    Attraction(std::string name, std::string location) : name(name), location(location) {}
};

class TourismGuideSystem {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(std::string name, std::string nationality) {
        tourists.push_back(Tourist(name, nationality));
    }

    void deleteTourist(std::string name) {
        for (size_t i = 0; i < tourists.size(); ++i) {
            if (tourists[i].name == name) {
                tourists.erase(tourists.begin() + i);
                break;
            }
        }
    }

    void updateTourist(std::string oldName, std::string newName, std::string newNationality) {
        for (auto& tourist : tourists) {
            if (tourist.name == oldName) {
                tourist.name = newName;
                tourist.nationality = newNationality;
                break;
            }
        }
    }

    Tourist* searchTourist(std::string name) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Name: " << tourist.name << ", Nationality: " << tourist.nationality << std::endl;
        }
    }

    void addAttraction(std::string name, std::string location) {
        attractions.push_back(Attraction(name, location));
    }

    void deleteAttraction(std::string name) {
        for (size_t i = 0; i < attractions.size(); ++i) {
            if (attractions[i].name == name) {
                attractions.erase(attractions.begin() + i);
                break;
            }
        }
    }

    void updateAttraction(std::string oldName, std::string newName, std::string newLocation) {
        for (auto& attraction : attractions) {
            if (attraction.name == oldName) {
                attraction.name = newName;
                attraction.location = newLocation;
                break;
            }
        }
    }

    Attraction* searchAttraction(std::string name) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "Name: " << attraction.name << ", Location: " << attraction.location << std::endl;
        }
    }
};

int main() {
    TourismGuideSystem system;
    system.addTourist("John Doe", "American");
    system.addTourist("Jane Smith", "British");
    system.addAttraction("Eiffel Tower", "Paris");
    system.addAttraction("Colosseum", "Rome");
    system.displayTourists();
    system.displayAttractions();
    system.updateTourist("John Doe", "Johnny Doe", "Canadian");
    system.updateAttraction("Eiffel Tower", "Eiffel Tower", "France");
    system.displayTourists();
    system.displayAttractions();
    system.deleteTourist("Jane Smith");
    system.deleteAttraction("Colosseum");
    system.displayTourists();
    system.displayAttractions();
    return 0;
}