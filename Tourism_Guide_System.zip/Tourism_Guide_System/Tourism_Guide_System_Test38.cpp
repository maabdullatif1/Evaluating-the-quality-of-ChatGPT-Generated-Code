#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    int id;
    std::string name;
    std::string location;
    std::string description;
    Attraction(int i, std::string n, std::string l, std::string d)
        : id(i), name(n), location(l), description(d) {}
};

class Tourist {
public:
    int id;
    std::string name;
    std::string nationality;
    int age;
    Tourist(int i, std::string n, std::string na, int a)
        : id(i), name(n), nationality(na), age(a) {}
};

class TourismGuideSystem {
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;
    
public:
    void addAttraction(int id, std::string name, std::string location, std::string description) {
        attractions.push_back(Attraction(id, name, location, description));
    }
    
    void deleteAttraction(int id) {
        for(auto it = attractions.begin(); it != attractions.end(); ++it) {
            if(it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }
    
    void updateAttraction(int id, std::string name, std::string location, std::string description) {
        for(auto& attraction : attractions) {
            if(attraction.id == id) {
                attraction.name = name;
                attraction.location = location;
                attraction.description = description;
                break;
            }
        }
    }
    
    Attraction* searchAttraction(int id) {
        for(auto& attraction : attractions) {
            if(attraction.id == id) {
                return &attraction;
            }
        }
        return nullptr;
    }
    
    void displayAttractions() {
        for(const auto& attraction : attractions) {
            std::cout << "ID: " << attraction.id << ", Name: " << attraction.name 
                      << ", Location: " << attraction.location << ", Description: " 
                      << attraction.description << std::endl;
        }
    }
    
    void addTourist(int id, std::string name, std::string nationality, int age) {
        tourists.push_back(Tourist(id, name, nationality, age));
    }
    
    void deleteTourist(int id) {
        for(auto it = tourists.begin(); it != tourists.end(); ++it) {
            if(it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }
    
    void updateTourist(int id, std::string name, std::string nationality, int age) {
        for(auto& tourist : tourists) {
            if(tourist.id == id) {
                tourist.name = name;
                tourist.nationality = nationality;
                tourist.age = age;
                break;
            }
        }
    }
    
    Tourist* searchTourist(int id) {
        for(auto& tourist : tourists) {
            if(tourist.id == id) {
                return &tourist;
            }
        }
        return nullptr;
    }
    
    void displayTourists() {
        for(const auto& tourist : tourists) {
            std::cout << "ID: " << tourist.id << ", Name: " << tourist.name 
                      << ", Nationality: " << tourist.nationality << ", Age: " 
                      << tourist.age << std::endl;
        }
    }
};

int main() {
    TourismGuideSystem system;
    system.addAttraction(1, "Eiffel Tower", "Paris", "Iconic tourist attraction in Paris.");
    system.addTourist(101, "John Doe", "USA", 30);
    
    system.displayAttractions();
    system.displayTourists();
    
    system.updateAttraction(1, "Eiffel Tower", "Paris", "Symbol of love and romance.");
    Attraction* attraction = system.searchAttraction(1);
    if (attraction) {
        std::cout << "Found Attraction: " << attraction->name << std::endl;
    }
    
    system.updateTourist(101, "John Smith", "USA", 31);
    Tourist* tourist = system.searchTourist(101);
    if (tourist) {
        std::cout << "Found Tourist: " << tourist->name << std::endl;
    }
    
    system.deleteAttraction(1);
    system.deleteTourist(101);

    system.displayAttractions();
    system.displayTourists();
    
    return 0;
}