#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    std::string name;
    std::string passportNumber;

    Tourist(std::string n, std::string p) : name(n), passportNumber(p) {}
};

class Attraction {
public:
    std::string name;
    std::string location;

    Attraction(std::string n, std::string l) : name(n), location(l) {}
};

class TourismGuide {
public:
    void addTourist(const std::string &name, const std::string &passportNumber) {
        tourists.push_back(Tourist(name, passportNumber));
    }

    void deleteTourist(const std::string &passportNumber) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->passportNumber == passportNumber) {
                tourists.erase(it);
                break;
            }
        }
    }
    
    void updateTourist(const std::string &passportNumber, const std::string &newName) {
        for (auto &tourist : tourists) {
            if (tourist.passportNumber == passportNumber) {
                tourist.name = newName;
                break;
            }
        }
    }
    
    bool searchTourist(const std::string &passportNumber) {
        for (const auto &tourist : tourists) {
            if (tourist.passportNumber == passportNumber) {
                std::cout << "Found Tourist: " << tourist.name << std::endl;
                return true;
            }
        }
        return false;
    }
    
    void displayTourists() {
        for (const auto &tourist : tourists) {
            std::cout << "Tourist Name: " << tourist.name << ", Passport Number: " << tourist.passportNumber << std::endl;
        }
    }
    
    void addAttraction(const std::string &name, const std::string &location) {
        attractions.push_back(Attraction(name, location));
    }

    void deleteAttraction(const std::string &name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }
    
    void updateAttraction(const std::string &name, const std::string &newLocation) {
        for (auto &attraction : attractions) {
            if (attraction.name == name) {
                attraction.location = newLocation;
                break;
            }
        }
    }

    bool searchAttraction(const std::string &name) {
        for (const auto &attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Found Attraction: " << attraction.name << " at " << attraction.location << std::endl;
                return true;
            }
        }
        return false;
    }
    
    void displayAttractions() {
        for (const auto &attraction : attractions) {
            std::cout << "Attraction Name: " << attraction.name << ", Location: " << attraction.location << std::endl;
        }
    }
    
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;
};

int main() {
    TourismGuide guide;
    guide.addTourist("Alice", "P12345");
    guide.addTourist("Bob", "P23456");
    guide.displayTourists();

    guide.addAttraction("Eiffel Tower", "Paris");
    guide.addAttraction("Statue of Liberty", "New York");
    guide.displayAttractions();

    guide.updateTourist("P12345", "Alice Johnson");
    guide.displayTourists();

    guide.searchTourist("P12345");
    guide.searchAttraction("Eiffel Tower");

    guide.deleteTourist("P23456");
    guide.deleteAttraction("Statue of Liberty");
    guide.displayTourists();
    guide.displayAttractions();

    return 0;
}