#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;

    Attraction(std::string n, std::string l, std::string d) : name(n), location(l), description(d) {}
};

class Tourist {
public:
    std::string name;
    int age;
    std::vector<Attraction> visitedAttractions;

    Tourist(std::string n, int a) : name(n), age(a) {}
    
    void addAttraction(Attraction attraction) {
        visitedAttractions.push_back(attraction);
    }
};

class TourismGuide {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(std::string name, int age) {
        tourists.push_back(Tourist(name, age));
    }
    
    void deleteTourist(std::string name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }
    
    void updateTourist(std::string name, int newAge) {
        for (auto &tourist : tourists) {
            if (tourist.name == name) {
                tourist.age = newAge;
                break;
            }
        }
    }
    
    Tourist* searchTourist(std::string name) {
        for (auto &tourist : tourists) {
            if (tourist.name == name) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            std::cout << "Tourist Name: " << tourist.name << ", Age: " << tourist.age << std::endl;
            std::cout << "Visited Attractions: " << std::endl;
            for (const auto &attraction : tourist.visitedAttractions) {
                std::cout << "- " << attraction.name << " in " << attraction.location << std::endl;
            }
        }
    }

    void addAttraction(std::string name, std::string location, std::string description) {
        attractions.push_back(Attraction(name, location, description));
    }
    
    void deleteAttraction(std::string name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }
    
    void updateAttraction(std::string name, std::string newLocation, std::string newDescription) {
        for (auto &attraction : attractions) {
            if (attraction.name == name) {
                attraction.location = newLocation;
                attraction.description = newDescription;
                break;
            }
        }
    }
    
    Attraction* searchAttraction(std::string name) {
        for (auto &attraction : attractions) {
            if (attraction.name == name) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            std::cout << "Attraction Name: " << attraction.name << ", Location: " << attraction.location
                      << ", Description: " << attraction.description << std::endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist("Alice", 30);
    guide.addTourist("Bob", 25);
    guide.addAttraction("Eiffel Tower", "Paris", "Iconic wrought-iron lattice tower on the Champ de Mars.");
    guide.displayTourists();
    guide.displayAttractions();
    return 0;
}