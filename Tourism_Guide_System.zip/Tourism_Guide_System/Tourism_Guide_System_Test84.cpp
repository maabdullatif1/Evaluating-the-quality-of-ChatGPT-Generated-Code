#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    std::string name;
    std::string nationality;
    int age;
    
    Tourist(const std::string& n, const std::string& nat, int a) : name(n), nationality(nat), age(a) {}
};

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;
    
    Attraction(const std::string& n, const std::string& loc, const std::string& desc) : name(n), location(loc), description(desc) {}
};

class TourismGuide {
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;
    
public:
    void addTourist(const std::string& name, const std::string& nationality, int age) {
        tourists.push_back(Tourist(name, nationality, age));
    }
    
    void deleteTourist(const std::string& name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }
    
    void updateTourist(const std::string& name, const std::string& nationality, int age) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                tourist.nationality = nationality;
                tourist.age = age;
                break;
            }
        }
    }
    
    void searchTourist(const std::string& name) {
        for (const auto& tourist : tourists) {
            if (tourist.name == name) {
                std::cout << "Name: " << tourist.name << ", Nationality: " << tourist.nationality << ", Age: " << tourist.age << std::endl;
                return;
            }
        }
        std::cout << "Tourist not found." << std::endl;
    }
    
    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Name: " << tourist.name << ", Nationality: " << tourist.nationality << ", Age: " << tourist.age << std::endl;
        }
    }
    
    void addAttraction(const std::string& name, const std::string& location, const std::string& description) {
        attractions.push_back(Attraction(name, location, description));
    }
    
    void deleteAttraction(const std::string& name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }
    
    void updateAttraction(const std::string& name, const std::string& location, const std::string& description) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                attraction.location = location;
                attraction.description = description;
                break;
            }
        }
    }
    
    void searchAttraction(const std::string& name) {
        for (const auto& attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Name: " << attraction.name << ", Location: " << attraction.location << ", Description: " << attraction.description << std::endl;
                return;
            }
        }
        std::cout << "Attraction not found." << std::endl;
    }
    
    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "Name: " << attraction.name << ", Location: " << attraction.location << ", Description: " << attraction.description << std::endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist("John Doe", "American", 30);
    guide.addTourist("Jane Smith", "British", 25);
    guide.displayTourists();
    guide.searchTourist("John Doe");
    guide.updateTourist("Jane Smith", "British", 26);
    guide.displayTourists();
    
    guide.addAttraction("Eiffel Tower", "Paris", "Iconic landmark of France");
    guide.addAttraction("Great Wall", "China", "Historical fortification in China");
    guide.displayAttractions();
    guide.searchAttraction("Great Wall");
    guide.updateAttraction("Eiffel Tower", "Paris", "Famous tower in Paris");
    guide.displayAttractions();
    
    return 0;
}