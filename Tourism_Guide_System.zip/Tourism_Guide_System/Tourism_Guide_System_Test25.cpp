#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Tourist {
    int id;
    string name;
    string country;
};

struct Attraction {
    int id;
    string name;
    string location;
};

class TourismGuide {
private:
    vector<Tourist> tourists;
    vector<Attraction> attractions;
    int touristIdCounter = 1;
    int attractionIdCounter = 1;

public:
    void addTourist(string name, string country) {
        tourists.push_back({touristIdCounter++, name, country});
    }

    void addAttraction(string name, string location) {
        attractions.push_back({attractionIdCounter++, name, location});
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateTourist(int id, string name, string country) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.country = country;
                break;
            }
        }
    }

    void updateAttraction(int id, string name, string location) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.location = location;
                break;
            }
        }
    }

    Tourist* searchTourist(int id) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                return &tourist;
            }
        }
        return nullptr;
    }

    Attraction* searchAttraction(int id) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            cout << "ID: " << tourist.id << ", Name: " << tourist.name << ", Country: " << tourist.country << endl;
        }
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            cout << "ID: " << attraction.id << ", Name: " << attraction.name << ", Location: " << attraction.location << endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist("Alice", "USA");
    guide.addTourist("Bob", "UK");
    guide.addAttraction("Eiffel Tower", "Paris");
    guide.addAttraction("Colosseum", "Rome");

    guide.displayTourists();
    guide.displayAttractions();

    guide.updateTourist(1, "Alice Smith", "USA");
    guide.updateAttraction(1, "Eiffel Tower", "France");

    guide.displayTourists();
    guide.displayAttractions();

    guide.deleteTourist(2);
    guide.deleteAttraction(2);

    guide.displayTourists();
    guide.displayAttractions();

    return 0;
}