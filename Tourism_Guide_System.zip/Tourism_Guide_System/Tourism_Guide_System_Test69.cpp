#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Tourist {
public:
    int id;
    string name;
    string country;

    Tourist(int id, string name, string country) : id(id), name(name), country(country) {}
};

class Attraction {
public:
    int id;
    string name;
    string location;
    double entryFee;

    Attraction(int id, string name, string location, double entryFee) : id(id), name(name), location(location), entryFee(entryFee) {}
};

class TourismGuideSystem {
    vector<Tourist> tourists;
    vector<Attraction> attractions;

public:
    void addTourist(int id, string name, string country) {
        tourists.push_back(Tourist(id, name, country));
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                return;
            }
        }
    }

    void updateTourist(int id, string name, string country) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.country = country;
                return;
            }
        }
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            cout << "ID: " << tourist.id << ", Name: " << tourist.name << ", Country: " << tourist.country << endl;
        }
    }

    void addAttraction(int id, string name, string location, double entryFee) {
        attractions.push_back(Attraction(id, name, location, entryFee));
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                return;
            }
        }
    }

    void updateAttraction(int id, string name, string location, double entryFee) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.location = location;
                attraction.entryFee = entryFee;
                return;
            }
        }
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            cout << "ID: " << attraction.id << ", Name: " << attraction.name << ", Location: " << attraction.location << ", Entry Fee: $" << attraction.entryFee << endl;
        }
    }

    void searchTourist(int id) {
        for (const auto &tourist : tourists) {
            if (tourist.id == id) {
                cout << "ID: " << tourist.id << ", Name: " << tourist.name << ", Country: " << tourist.country << endl;
                return;
            }
        }
        cout << "Tourist not found." << endl;
    }

    void searchAttraction(int id) {
        for (const auto &attraction : attractions) {
            if (attraction.id == id) {
                cout << "ID: " << attraction.id << ", Name: " << attraction.name << ", Location: " << attraction.location << ", Entry Fee: $" << attraction.entryFee << endl;
                return;
            }
        }
        cout << "Attraction not found." << endl;
    }
};

int main() {
    TourismGuideSystem tgs;

    tgs.addTourist(1, "John Doe", "USA");
    tgs.addTourist(2, "Jane Smith", "UK");

    tgs.addAttraction(1, "Eiffel Tower", "Paris", 25.50);
    tgs.addAttraction(2, "Colosseum", "Rome", 18.00);

    tgs.updateTourist(1, "Johnathan Doe", "USA");
    tgs.updateAttraction(1, "Eiffel Tower", "Paris, France", 27.00);

    cout << "Tourists:" << endl;
    tgs.displayTourists();
    
    cout << "\nAttractions:" << endl;
    tgs.displayAttractions();

    cout << "\nSearch for Tourist ID 2:" << endl;
    tgs.searchTourist(2);

    cout << "\nSearch for Attraction ID 1:" << endl;
    tgs.searchAttraction(1);

    tgs.deleteTourist(2);
    tgs.deleteAttraction(2);

    cout << "\nAfter deletion:" << endl;
    tgs.displayTourists();
    tgs.displayAttractions();

    return 0;
}