#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    int id;
    std::string name;

    Tourist(int id, const std::string& name) : id(id), name(name) {}
};

class Attraction {
public:
    int id;
    std::string name;

    Attraction(int id, const std::string& name) : id(id), name(name) {}
};

class TourismGuideSystem {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(int id, const std::string& name) {
        tourists.emplace_back(id, name);
    }

    void deleteTourist(int id) {
        tourists.erase(
            std::remove_if(tourists.begin(), tourists.end(),
                           [id](const Tourist& t) { return t.id == id; }),
            tourists.end());
    }

    void updateTourist(int id, const std::string& newName) {
        for (auto& tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = newName;
                break;
            }
        }
    }

    void searchTourist(int id) {
        for (const auto& tourist : tourists) {
            if (tourist.id == id) {
                std::cout << "Tourist ID: " << tourist.id << ", Name: " << tourist.name << std::endl;
                return;
            }
        }
        std::cout << "Tourist not found." << std::endl;
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Tourist ID: " << tourist.id << ", Name: " << tourist.name << std::endl;
        }
    }

    void addAttraction(int id, const std::string& name) {
        attractions.emplace_back(id, name);
    }

    void deleteAttraction(int id) {
        attractions.erase(
            std::remove_if(attractions.begin(), attractions.end(),
                           [id](const Attraction& a) { return a.id == id; }),
            attractions.end());
    }

    void updateAttraction(int id, const std::string& newName) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = newName;
                break;
            }
        }
    }

    void searchAttraction(int id) {
        for (const auto& attraction : attractions) {
            if (attraction.id == id) {
                std::cout << "Attraction ID: " << attraction.id << ", Name: " << attraction.name << std::endl;
                return;
            }
        }
        std::cout << "Attraction not found." << std::endl;
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "Attraction ID: " << attraction.id << ", Name: " << attraction.name << std::endl;
        }
    }
};

int main() {
    TourismGuideSystem system;
    
    system.addTourist(1, "Alice");
    system.addTourist(2, "Bob");
    system.displayTourists();
    
    system.addAttraction(1, "Eiffel Tower");
    system.addAttraction(2, "The Louvre");
    system.displayAttractions();
    
    system.updateTourist(1, "Alicia");
    system.updateAttraction(1, "Eiffel");
    
    system.searchTourist(1);
    system.searchAttraction(1);
    
    system.deleteTourist(2);
    system.deleteAttraction(2);
    
    system.displayTourists();
    system.displayAttractions();
    
    return 0;
}