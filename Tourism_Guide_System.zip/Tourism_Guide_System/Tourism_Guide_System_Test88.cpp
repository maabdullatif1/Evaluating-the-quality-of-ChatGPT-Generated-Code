#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Attraction {
public:
    int id;
    string name;
    string description;

    Attraction(int id, string name, string description) {
        this->id = id;
        this->name = name;
        this->description = description;
    }
};

class Tourist {
public:
    int id;
    string name;
    string nationality;
    
    Tourist(int id, string name, string nationality) {
        this->id = id;
        this->name = name;
        this->nationality = nationality;
    }
};

class TourismGuide {
    vector<Tourist> tourists;
    vector<Attraction> attractions;
    int touristCounter;
    int attractionCounter;

public:
    TourismGuide() : touristCounter(0), attractionCounter(0) {}

    void addTourist(string name, string nationality) {
        tourists.push_back(Tourist(++touristCounter, name, nationality));
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(int id, string name, string nationality) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.nationality = nationality;
                break;
            }
        }
    }

    Tourist* searchTourist(int id) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void addAttraction(string name, string description) {
        attractions.push_back(Attraction(++attractionCounter, name, description));
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(int id, string name, string description) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.description = description;
                break;
            }
        }
    }

    Attraction* searchAttraction(int id) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            cout << "ID: " << tourist.id << ", Name: " << tourist.name << ", Nationality: " << tourist.nationality << endl;
        }
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            cout << "ID: " << attraction.id << ", Name: " << attraction.name << ", Description: " << attraction.description << endl;
        }
    }
};

int main() {
    TourismGuide guide;
    
    guide.addTourist("Alice", "American");
    guide.addTourist("Bob", "British");
    guide.displayTourists();
    
    guide.addAttraction("Eiffel Tower", "Iconic symbol of Paris");
    guide.addAttraction("Colosseum", "Ancient Roman gladiatorial arena");
    guide.displayAttractions();

    guide.updateTourist(1, "Alice A.", "Canadian");
    guide.updateAttraction(1, "Eiffel Tower", "Famous landmark in Paris, France");
    
    Tourist* tourist = guide.searchTourist(1);
    if (tourist) {
        cout << "Found Tourist - ID: " << tourist->id << ", Name: " << tourist->name << ", Nationality: " << tourist->nationality << endl;
    }

    Attraction* attraction = guide.searchAttraction(2);
    if (attraction) {
        cout << "Found Attraction - ID: " << attraction->id << ", Name: " << attraction->name << ", Description: " << attraction->description << endl;
    }
    
    guide.displayTourists();
    guide.displayAttractions();

    guide.deleteTourist(1);
    guide.deleteAttraction(2);
    guide.displayTourists();
    guide.displayAttractions();
    
    return 0;
}