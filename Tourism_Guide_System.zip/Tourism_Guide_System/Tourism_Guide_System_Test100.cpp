#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    std::string name;
    int age;
    std::string nationality;

    Tourist(std::string n, int a, std::string nat) : name(n), age(a), nationality(nat) {}
};

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;

    Attraction(std::string n, std::string loc, std::string desc) : name(n), location(loc), description(desc) {}
};

class TourismGuideSystem {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist() {
        std::string name, nationality;
        int age;
        std::cout << "Enter Name: ";
        std::cin >> name;
        std::cout << "Enter Age: ";
        std::cin >> age;
        std::cout << "Enter Nationality: ";
        std::cin >> nationality;
        tourists.push_back(Tourist(name, age, nationality));
    }

    void deleteTourist() {
        std::string name;
        std::cout << "Enter Name of Tourist to Delete: ";
        std::cin >> name;
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                std::cout << "Tourist Deleted\n";
                return;
            }
        }
        std::cout << "Tourist Not Found\n";
    }

    void updateTourist() {
        std::string name;
        std::cout << "Enter Name of Tourist to Update: ";
        std::cin >> name;
        for (auto &tourist : tourists) {
            if (tourist.name == name) {
                std::cout << "Enter New Age: ";
                std::cin >> tourist.age;
                std::cout << "Enter New Nationality: ";
                std::cin >> tourist.nationality;
                std::cout << "Tourist Updated\n";
                return;
            }
        }
        std::cout << "Tourist Not Found\n";
    }

    void searchTourist() {
        std::string name;
        std::cout << "Enter Name of Tourist to Search: ";
        std::cin >> name;
        for (const auto &tourist : tourists) {
            if (tourist.name == name) {
                std::cout << "Name: " << tourist.name << ", Age: " << tourist.age << ", Nationality: " << tourist.nationality << "\n";
                return;
            }
        }
        std::cout << "Tourist Not Found\n";
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            std::cout << "Name: " << tourist.name << ", Age: " << tourist.age << ", Nationality: " << tourist.nationality << "\n";
        }
    }

    void addAttraction() {
        std::string name, location, description;
        std::cout << "Enter Name: ";
        std::cin >> name;
        std::cout << "Enter Location: ";
        std::cin >> location;
        std::cout << "Enter Description: ";
        std::cin.ignore();
        std::getline(std::cin, description);
        attractions.push_back(Attraction(name, location, description));
    }

    void deleteAttraction() {
        std::string name;
        std::cout << "Enter Name of Attraction to Delete: ";
        std::cin >> name;
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                std::cout << "Attraction Deleted\n";
                return;
            }
        }
        std::cout << "Attraction Not Found\n";
    }

    void updateAttraction() {
        std::string name;
        std::cout << "Enter Name of Attraction to Update: ";
        std::cin >> name;
        for (auto &attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Enter New Location: ";
                std::cin >> attraction.location;
                std::cout << "Enter New Description: ";
                std::cin.ignore();
                std::getline(std::cin, attraction.description);
                std::cout << "Attraction Updated\n";
                return;
            }
        }
        std::cout << "Attraction Not Found\n";
    }

    void searchAttraction() {
        std::string name;
        std::cout << "Enter Name of Attraction to Search: ";
        std::cin >> name;
        for (const auto &attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Name: " << attraction.name << ", Location: " << attraction.location << ", Description: " << attraction.description << "\n";
                return;
            }
        }
        std::cout << "Attraction Not Found\n";
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            std::cout << "Name: " << attraction.name << ", Location: " << attraction.location << ", Description: " << attraction.description << "\n";
        }
    }
};

int main() {
    TourismGuideSystem system;
    int choice;
    while (true) {
        std::cout << "1. Add Tourist\n2. Delete Tourist\n3. Update Tourist\n4. Search Tourist\n5. Display Tourists\n";
        std::cout << "6. Add Attraction\n7. Delete Attraction\n8. Update Attraction\n9. Search Attraction\n10. Display Attractions\n11. Exit\n";
        std::cin >> choice;
        switch (choice) {
            case 1: system.addTourist(); break;
            case 2: system.deleteTourist(); break;
            case 3: system.updateTourist(); break;
            case 4: system.searchTourist(); break;
            case 5: system.displayTourists(); break;
            case 6: system.addAttraction(); break;
            case 7: system.deleteAttraction(); break;
            case 8: system.updateAttraction(); break;
            case 9: system.searchAttraction(); break;
            case 10: system.displayAttractions(); break;
            case 11: return 0;
            default: std::cout << "Invalid Option\n"; break;
        }
    }
    return 0;
}