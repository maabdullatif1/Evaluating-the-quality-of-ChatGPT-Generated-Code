#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Tourist {
public:
    int id;
    string name;
    string nationality;

    Tourist(int i, string n, string nat) : id(i), name(n), nationality(nat) {}
};

class Attraction {
public:
    int id;
    string name;
    string location;

    Attraction(int i, string n, string loc) : id(i), name(n), location(loc) {}
};

class TourismGuideSystem {
private:
    vector<Tourist> tourists;
    vector<Attraction> attractions;
    int touristCounter = 0;
    int attractionCounter = 0;

public:
    void addTourist(string name, string nationality) {
        tourists.push_back(Tourist(++touristCounter, name, nationality));
    }

    void deleteTourist(int id) {
        tourists.erase(remove_if(tourists.begin(), tourists.end(), [id](Tourist& t) { return t.id == id; }), tourists.end());
    }

    void updateTourist(int id, string name, string nationality) {
        for (auto& t : tourists) {
            if (t.id == id) {
                t.name = name;
                t.nationality = nationality;
                break;
            }
        }
    }

    void searchTourist(string name) {
        for (const auto& t : tourists) {
            if (t.name.find(name) != string::npos) {
                cout << "Tourist ID: " << t.id << ", Name: " << t.name << ", Nationality: " << t.nationality << endl;
            }
        }
    }

    void displayTourists() {
        for (const auto& t : tourists) {
            cout << "Tourist ID: " << t.id << ", Name: " << t.name << ", Nationality: " << t.nationality << endl;
        }
    }

    void addAttraction(string name, string location) {
        attractions.push_back(Attraction(++attractionCounter, name, location));
    }

    void deleteAttraction(int id) {
        attractions.erase(remove_if(attractions.begin(), attractions.end(), [id](Attraction& a) { return a.id == id; }), attractions.end());
    }

    void updateAttraction(int id, string name, string location) {
        for (auto& a : attractions) {
            if (a.id == id) {
                a.name = name;
                a.location = location;
                break;
            }
        }
    }

    void searchAttraction(string name) {
        for (const auto& a : attractions) {
            if (a.name.find(name) != string::npos) {
                cout << "Attraction ID: " << a.id << ", Name: " << a.name << ", Location: " << a.location << endl;
            }
        }
    }

    void displayAttractions() {
        for (const auto& a : attractions) {
            cout << "Attraction ID: " << a.id << ", Name: " << a.name << ", Location: " << a.location << endl;
        }
    }
};

int main() {
    TourismGuideSystem system;
    system.addTourist("John Doe", "USA");
    system.addTourist("Jane Smith", "UK");
    system.displayTourists();

    system.addAttraction("Eiffel Tower", "Paris");
    system.addAttraction("Statue of Liberty", "New York");
    system.displayAttractions();

    system.searchTourist("Jane");
    system.searchAttraction("Eiffel");

    system.updateTourist(1, "John Adams", "USA");
    system.updateAttraction(1, "Eiffel Tower", "France");

    system.displayTourists();
    system.displayAttractions();

    system.deleteTourist(2);
    system.deleteAttraction(2);

    system.displayTourists();
    system.displayAttractions();

    return 0;
}