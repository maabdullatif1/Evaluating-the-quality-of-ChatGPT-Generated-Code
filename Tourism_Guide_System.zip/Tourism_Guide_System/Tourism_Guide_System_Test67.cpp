#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;
    Attraction(std::string n, std::string loc, std::string desc) : name(n), location(loc), description(desc) {}
};

class Tourist {
public:
    std::string name;
    int age;
    std::string interest;
    Tourist(std::string n, int a, std::string i) : name(n), age(a), interest(i) {}
};

class TourismGuide {
private:
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;
public:
    void addAttraction(std::string name, std::string location, std::string description) {
        attractions.push_back(Attraction(name, location, description));
    }
    
    void deleteAttraction(std::string name) {
        for (size_t i = 0; i < attractions.size(); ++i) {
            if (attractions[i].name == name) {
                attractions.erase(attractions.begin() + i);
                break;
            }
        }
    }

    void updateAttraction(std::string name, std::string newLocation, std::string newDescription) {
        for (size_t i = 0; i < attractions.size(); ++i) {
            if (attractions[i].name == name) {
                attractions[i].location = newLocation;
                attractions[i].description = newDescription;
                break;
            }
        }
    }
    
    void searchAttraction(std::string name) {
        for (size_t i = 0; i < attractions.size(); ++i) {
            if (attractions[i].name == name) {
                std::cout << "Name: " << attractions[i].name << ", Location: " << attractions[i].location << ", Description: " << attractions[i].description << std::endl;
                return;
            }
        }
        std::cout << "Attraction not found." << std::endl;
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "Name: " << attraction.name << ", Location: " << attraction.location << ", Description: " << attraction.description << std::endl;
        }
    }

    void addTourist(std::string name, int age, std::string interest) {
        tourists.push_back(Tourist(name, age, interest));
    }

    void deleteTourist(std::string name) {
        for (size_t i = 0; i < tourists.size(); ++i) {
            if (tourists[i].name == name) {
                tourists.erase(tourists.begin() + i);
                break;
            }
        }
    }

    void updateTourist(std::string name, int newAge, std::string newInterest) {
        for (size_t i = 0; i < tourists.size(); ++i) {
            if (tourists[i].name == name) {
                tourists[i].age = newAge;
                tourists[i].interest = newInterest;
                break;
            }
        }
    }

    void searchTourist(std::string name) {
        for (size_t i = 0; i < tourists.size(); ++i) {
            if (tourists[i].name == name) {
                std::cout << "Name: " << tourists[i].name << ", Age: " << tourists[i].age << ", Interest: " << tourists[i].interest << std::endl;
                return;
            }
        }
        std::cout << "Tourist not found." << std::endl;
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Name: " << tourist.name << ", Age: " << tourist.age << ", Interest: " << tourist.interest << std::endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addAttraction("Eiffel Tower", "Paris", "Iconic landmark of Paris.");
    guide.addTourist("John Doe", 30, "Historical Sites");
    guide.displayAttractions();
    guide.displayTourists();
    guide.searchAttraction("Eiffel Tower");
    guide.searchTourist("John Doe");
    guide.updateAttraction("Eiffel Tower", "Paris, France", "World-famous landmark.");
    guide.updateTourist("John Doe", 31, "Cultural Tours");
    guide.displayAttractions();
    guide.displayTourists();
    guide.deleteAttraction("Eiffel Tower");
    guide.deleteTourist("John Doe");
    guide.displayAttractions();
    guide.displayTourists();
    return 0;
}