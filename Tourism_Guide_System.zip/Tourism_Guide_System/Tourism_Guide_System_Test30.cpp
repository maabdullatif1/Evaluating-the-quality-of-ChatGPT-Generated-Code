#include <iostream>
#include <vector>
#include <string>

struct Attraction {
    int id;
    std::string name;
    std::string location;
    std::string description;
};

class TourismGuide {
    std::vector<Attraction> attractions;
    int nextId = 1;

public:
    void addAttraction(const std::string& name, const std::string& location, const std::string& description) {
        attractions.push_back({nextId++, name, location, description});
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(int id, const std::string& name, const std::string& location, const std::string& description) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.location = location;
                attraction.description = description;
                break;
            }
        }
    }

    void searchAttraction(const std::string& name) const {
        for (const auto& attraction : attractions) {
            if (attraction.name.find(name) != std::string::npos) {
                displayAttraction(attraction);
            }
        }
    }

    void displayAll() const {
        for (const auto& attraction : attractions) {
            displayAttraction(attraction);
        }
    }

private:
    void displayAttraction(const Attraction& attraction) const {
        std::cout << "ID: " << attraction.id << "\n";
        std::cout << "Name: " << attraction.name << "\n";
        std::cout << "Location: " << attraction.location << "\n";
        std::cout << "Description: " << attraction.description << "\n";
        std::cout << "---------------------\n";
    }
};

int main() {
    TourismGuide tg;
    tg.addAttraction("Eiffel Tower", "Paris", "An iconic symbol of France.");
    tg.addAttraction("Great Wall", "China", "A historic structure built centuries ago.");
    
    std::cout << "Search Results:\n";
    tg.searchAttraction("Eiffel");

    std::cout << "All Attractions:\n";
    tg.displayAll();

    tg.updateAttraction(1, "Eiffel Tower", "Paris", "The magnificent Eiffel Tower in France.");
    std::cout << "Updated Attraction:\n";
    tg.displayAll();

    tg.deleteAttraction(2);
    std::cout << "After Deletion:\n";
    tg.displayAll();

    return 0;
}