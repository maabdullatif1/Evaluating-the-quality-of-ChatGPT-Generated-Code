#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    std::string name;
    int age;
    std::string nationality;

    Tourist(std::string n, int a, std::string nat) : name(n), age(a), nationality(nat) {}
};

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;

    Attraction(std::string n, std::string loc, std::string desc) : name(n), location(loc), description(desc) {}
};

class TourismGuide {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(const std::string &name, int age, const std::string &nationality) {
        tourists.push_back(Tourist(name, age, nationality));
    }

    void deleteTourist(const std::string &name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(const std::string &name, int age, const std::string &nationality) {
        for (auto &tourist : tourists) {
            if (tourist.name == name) {
                tourist.age = age;
                tourist.nationality = nationality;
                break;
            }
        }
    }

    void searchTourist(const std::string &name) {
        for (const auto &tourist : tourists) {
            if (tourist.name == name) {
                std::cout << "Name: " << tourist.name << ", Age: " << tourist.age
                          << ", Nationality: " << tourist.nationality << "\n";
                return;
            }
        }
        std::cout << "Tourist not found\n";
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            std::cout << "Name: " << tourist.name << ", Age: " << tourist.age
                      << ", Nationality: " << tourist.nationality << "\n";
        }
    }

    void addAttraction(const std::string &name, const std::string &location, const std::string &description) {
        attractions.push_back(Attraction(name, location, description));
    }

    void deleteAttraction(const std::string &name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(const std::string &name, const std::string &location, const std::string &description) {
        for (auto &attraction : attractions) {
            if (attraction.name == name) {
                attraction.location = location;
                attraction.description = description;
                break;
            }
        }
    }

    void searchAttraction(const std::string &name) {
        for (const auto &attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Name: " << attraction.name << ", Location: " << attraction.location
                          << ", Description: " << attraction.description << "\n";
                return;
            }
        }
        std::cout << "Attraction not found\n";
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            std::cout << "Name: " << attraction.name << ", Location: " << attraction.location
                      << ", Description: " << attraction.description << "\n";
        }
    }
};

int main() {
    TourismGuide guide;

    guide.addTourist("Alice", 30, "American");
    guide.addTourist("Bob", 25, "British");
    guide.displayTourists();

    guide.addAttraction("Eiffel Tower", "Paris", "Iconic French landmark");
    guide.addAttraction("Colosseum", "Rome", "Ancient arena");
    guide.displayAttractions();

    guide.updateTourist("Alice", 31, "American");
    guide.searchTourist("Alice");

    guide.updateAttraction("Eiffel Tower", "Paris", "Famous tower in France");
    guide.searchAttraction("Eiffel Tower");

    guide.deleteTourist("Bob");
    guide.displayTourists();

    guide.deleteAttraction("Colosseum");
    guide.displayAttractions();

    return 0;
}