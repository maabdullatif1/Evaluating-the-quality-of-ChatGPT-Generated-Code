#include <iostream>
#include <string>
#include <vector>

class Attraction {
public:
    int id;
    std::string name;
    std::string location;

    Attraction(int aId, std::string aName, std::string aLocation)
        : id(aId), name(aName), location(aLocation) {}
};

class Tourist {
public:
    int id;
    std::string name;
    std::string country;

    Tourist(int tId, std::string tName, std::string tCountry)
        : id(tId), name(tName), country(tCountry) {}
};

class TourismGuide {
private:
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;

public:
    void addAttraction(int id, std::string name, std::string location) {
        attractions.push_back(Attraction(id, name, location));
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(int id, std::string name, std::string location) {
        for (auto &attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.location = location;
                break;
            }
        }
    }

    void searchAttraction(int id) {
        for (const auto &attraction : attractions) {
            if (attraction.id == id) {
                std::cout << "Attraction ID: " << attraction.id
                          << ", Name: " << attraction.name
                          << ", Location: " << attraction.location << std::endl;
                return;
            }
        }
        std::cout << "Attraction not found." << std::endl;
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            std::cout << "Attraction ID: " << attraction.id
                      << ", Name: " << attraction.name
                      << ", Location: " << attraction.location << std::endl;
        }
    }

    void addTourist(int id, std::string name, std::string country) {
        tourists.push_back(Tourist(id, name, country));
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(int id, std::string name, std::string country) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.country = country;
                break;
            }
        }
    }

    void searchTourist(int id) {
        for (const auto &tourist : tourists) {
            if (tourist.id == id) {
                std::cout << "Tourist ID: " << tourist.id
                          << ", Name: " << tourist.name
                          << ", Country: " << tourist.country << std::endl;
                return;
            }
        }
        std::cout << "Tourist not found." << std::endl;
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            std::cout << "Tourist ID: " << tourist.id
                      << ", Name: " << tourist.name
                      << ", Country: " << tourist.country << std::endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addAttraction(1, "Eiffel Tower", "Paris");
    guide.addTourist(1, "John Doe", "USA");

    guide.displayAttractions();
    guide.displayTourists();

    guide.updateAttraction(1, "Eiffel Tower", "Paris, France");
    guide.updateTourist(1, "John Smith", "United States");

    guide.searchAttraction(1);
    guide.searchTourist(1);

    guide.deleteAttraction(1);
    guide.deleteTourist(1);

    guide.displayAttractions();
    guide.displayTourists();

    return 0;
}