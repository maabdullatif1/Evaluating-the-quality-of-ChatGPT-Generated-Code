#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;

    Attraction(std::string n, std::string loc, std::string desc)
        : name(n), location(loc), description(desc) {}
};

class Tourist {
public:
    std::string name;
    std::string nationality;
    std::vector<Attraction> visitedAttractions;

    Tourist(std::string n, std::string nat)
        : name(n), nationality(nat) {}
    
    void addAttraction(Attraction a) {
        visitedAttractions.push_back(a);
    }
};

class TourismSystem {
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(std::string name, std::string nationality) {
        tourists.push_back(Tourist(name, nationality));
    }

    void deleteTourist(std::string name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                return;
            }
        }
    }

    void updateTourist(std::string oldName, std::string newName, std::string newNationality) {
        for (auto& tourist : tourists) {
            if (tourist.name == oldName) {
                tourist.name = newName;
                tourist.nationality = newNationality;
                return;
            }
        }
    }

    Tourist* searchTourist(std::string name) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Name: " << tourist.name 
                      << ", Nationality: " << tourist.nationality << "\n";
            for (const auto& attr : tourist.visitedAttractions) {
                std::cout << "    Attraction: " << attr.name 
                          << ", Location: " << attr.location 
                          << ", Description: " << attr.description << "\n";
            }
        }
    }

    void addAttraction(std::string name, std::string location, std::string description) {
        attractions.push_back(Attraction(name, location, description));
    }

    void deleteAttraction(std::string name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                return;
            }
        }
    }

    void updateAttraction(std::string oldName, std::string newName, std::string newLocation, std::string newDescription) {
        for (auto& attraction : attractions) {
            if (attraction.name == oldName) {
                attraction.name = newName;
                attraction.location = newLocation;
                attraction.description = newDescription;
                return;
            }
        }
    }

    Attraction* searchAttraction(std::string name) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "Name: " << attraction.name 
                      << ", Location: " << attraction.location 
                      << ", Description: " << attraction.description << "\n";
        }
    }
};

int main() {
    TourismSystem system;
    system.addTourist("Alice", "American");
    system.addAttraction("Eiffel Tower", "Paris", "Famous landmark");
    
    Tourist* tourist = system.searchTourist("Alice");
    if (tourist) {
        Attraction* attraction = system.searchAttraction("Eiffel Tower");
        if (attraction) {
            tourist->addAttraction(*attraction);
        }
    }

    system.displayTourists();
    system.displayAttractions();

    return 0;
}