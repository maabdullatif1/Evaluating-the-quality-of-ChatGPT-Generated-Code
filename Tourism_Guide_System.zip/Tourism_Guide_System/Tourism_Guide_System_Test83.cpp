#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    int id;
    std::string name;
    std::string location;
    
    Attraction(int aId, std::string aName, std::string aLocation)
        : id(aId), name(aName), location(aLocation) {}
};

class Tourist {
public:
    int id;
    std::string name;
    
    Tourist(int tId, std::string tName)
        : id(tId), name(tName) {}
};

class TourismGuide {
private:
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;

    int getAttractionIndexById(int id) {
        for (int i = 0; i < attractions.size(); i++) {
            if (attractions[i].id == id) return i;
        }
        return -1;
    }

    int getTouristIndexById(int id) {
        for (int i = 0; i < tourists.size(); i++) {
            if (tourists[i].id == id) return i;
        }
        return -1;
    }

public:
    void addAttraction(int id, std::string name, std::string location) {
        attractions.push_back(Attraction(id, name, location));
    }

    void addTourist(int id, std::string name) {
        tourists.push_back(Tourist(id, name));
    }

    void deleteAttraction(int id) {
        int index = getAttractionIndexById(id);
        if (index != -1) attractions.erase(attractions.begin() + index);
    }

    void deleteTourist(int id) {
        int index = getTouristIndexById(id);
        if (index != -1) tourists.erase(tourists.begin() + index);
    }

    void updateAttraction(int id, std::string name, std::string location) {
        int index = getAttractionIndexById(id);
        if (index != -1) {
            attractions[index].name = name;
            attractions[index].location = location;
        }
    }

    void updateTourist(int id, std::string name) {
        int index = getTouristIndexById(id);
        if (index != -1) {
            tourists[index].name = name;
        }
    }

    Attraction* searchAttraction(int id) {
        int index = getAttractionIndexById(id);
        if (index != -1) return &attractions[index];
        return nullptr;
    }

    Tourist* searchTourist(int id) {
        int index = getTouristIndexById(id);
        if (index != -1) return &tourists[index];
        return nullptr;
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "Attraction ID: " << attraction.id
                      << ", Name: " << attraction.name
                      << ", Location: " << attraction.location << std::endl;
        }
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Tourist ID: " << tourist.id
                      << ", Name: " << tourist.name << std::endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addAttraction(1, "Eiffel Tower", "Paris");
    guide.addAttraction(2, "Great Wall", "China");
    guide.addTourist(1, "John Doe");
    guide.addTourist(2, "Jane Smith");
    
    guide.displayAttractions();
    guide.displayTourists();
    
    guide.updateAttraction(1, "Eiffel Tower", "France");
    guide.updateTourist(1, "Johnny Doe");

    guide.displayAttractions();
    guide.displayTourists();

    guide.deleteAttraction(2);
    guide.deleteTourist(2);

    guide.displayAttractions();
    guide.displayTourists();

    return 0;
}