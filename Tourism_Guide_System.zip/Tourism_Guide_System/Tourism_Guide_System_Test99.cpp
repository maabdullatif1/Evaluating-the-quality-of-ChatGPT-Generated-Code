#include <iostream>
#include <vector>
#include <string>

struct Attraction {
    int id;
    std::string name;
    std::string description;
};

struct Tourist {
    int id;
    std::string name;
    std::string country;
};

std::vector<Attraction> attractions;
std::vector<Tourist> tourists;

void addAttraction() {
    int id;
    std::string name, description;
    std::cout << "Enter Attraction ID: ";
    std::cin >> id;
    std::cout << "Enter Attraction Name: ";
    std::cin.ignore();
    std::getline(std::cin, name);
    std::cout << "Enter Description: ";
    std::getline(std::cin, description);
    attractions.push_back({id, name, description});
}

void deleteAttraction() {
    int id;
    std::cout << "Enter Attraction ID to delete: ";
    std::cin >> id;
    for (auto it = attractions.begin(); it != attractions.end(); ++it) {
        if (it->id == id) {
            attractions.erase(it);
            break;
        }
    }
}

void updateAttraction() {
    int id;
    std::cout << "Enter Attraction ID to update: ";
    std::cin >> id;
    for (auto& attraction : attractions) {
        if (attraction.id == id) {
            std::cout << "Enter new name: ";
            std::cin.ignore();
            std::getline(std::cin, attraction.name);
            std::cout << "Enter new description: ";
            std::getline(std::cin, attraction.description);
            break;
        }
    }
}

void searchAttraction() {
    int id;
    std::cout << "Enter Attraction ID to search: ";
    std::cin >> id;
    for (const auto& attraction : attractions) {
        if (attraction.id == id) {
            std::cout << "ID: " << attraction.id << ", Name: " << attraction.name << ", Description: " << attraction.description << std::endl;
            return;
        }
    }
    std::cout << "Attraction not found." << std::endl;
}

void displayAttractions() {
    for (const auto& attraction : attractions) {
        std::cout << "ID: " << attraction.id << ", Name: " << attraction.name << ", Description: " << attraction.description << std::endl;
    }
}

void addTourist() {
    int id;
    std::string name, country;
    std::cout << "Enter Tourist ID: ";
    std::cin >> id;
    std::cout << "Enter Tourist Name: ";
    std::cin.ignore();
    std::getline(std::cin, name);
    std::cout << "Enter Country: ";
    std::getline(std::cin, country);
    tourists.push_back({id, name, country});
}

void deleteTourist() {
    int id;
    std::cout << "Enter Tourist ID to delete: ";
    std::cin >> id;
    for (auto it = tourists.begin(); it != tourists.end(); ++it) {
        if (it->id == id) {
            tourists.erase(it);
            break;
        }
    }
}

void updateTourist() {
    int id;
    std::cout << "Enter Tourist ID to update: ";
    std::cin >> id;
    for (auto& tourist : tourists) {
        if (tourist.id == id) {
            std::cout << "Enter new name: ";
            std::cin.ignore();
            std::getline(std::cin, tourist.name);
            std::cout << "Enter new country: ";
            std::getline(std::cin, tourist.country);
            break;
        }
    }
}

void searchTourist() {
    int id;
    std::cout << "Enter Tourist ID to search: ";
    std::cin >> id;
    for (const auto& tourist : tourists) {
        if (tourist.id == id) {
            std::cout << "ID: " << tourist.id << ", Name: " << tourist.name << ", Country: " << tourist.country << std::endl;
            return;
        }
    }
    std::cout << "Tourist not found." << std::endl;
}

void displayTourists() {
    for (const auto& tourist : tourists) {
        std::cout << "ID: " << tourist.id << ", Name: " << tourist.name << ", Country: " << tourist.country << std::endl;
    }
}

int main() {
    int choice;
    while (true) {
        std::cout << "\nTourism Guide System:\n1. Add Attraction\n2. Delete Attraction\n3. Update Attraction\n4. Search Attraction\n5. Display Attractions\n6. Add Tourist\n7. Delete Tourist\n8. Update Tourist\n9. Search Tourist\n10. Display Tourists\n11. Exit\nEnter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1: addAttraction(); break;
            case 2: deleteAttraction(); break;
            case 3: updateAttraction(); break;
            case 4: searchAttraction(); break;
            case 5: displayAttractions(); break;
            case 6: addTourist(); break;
            case 7: deleteTourist(); break;
            case 8: updateTourist(); break;
            case 9: searchTourist(); break;
            case 10: displayTourists(); break;
            case 11: return 0;
            default: std::cout << "Invalid choice. Please try again."; break;
        }
    }
}