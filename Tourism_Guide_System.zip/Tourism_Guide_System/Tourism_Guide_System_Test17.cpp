#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Tourist {
public:
    string name;
    int age;
    string country;
    
    Tourist(string name, int age, string country) : name(name), age(age), country(country) {}
};

class Attraction {
public:
    string name;
    string location;
    string description;
    
    Attraction(string name, string location, string description) 
        : name(name), location(location), description(description) {}
};

class TourismGuide {
private:
    vector<Tourist> tourists;
    vector<Attraction> attractions;

public:
    void addTourist(const string &name, int age, const string &country) {
        tourists.push_back(Tourist(name, age, country));
    }

    void deleteTourist(const string &name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(const string &name, int age, const string &country) {
        for (auto &tourist : tourists) {
            if (tourist.name == name) {
                tourist.age = age;
                tourist.country = country;
                break;
            }
        }
    }

    void searchTourist(const string &name) {
        for (const auto &tourist : tourists) {
            if (tourist.name == name) {
                cout << "Tourist: " << tourist.name << ", Age: " 
                     << tourist.age << ", Country: " << tourist.country << endl;
                return;
            }
        }
        cout << "Tourist not found." << endl;
    }

    void addAttraction(const string &name, const string &location, const string &description) {
        attractions.push_back(Attraction(name, location, description));
    }

    void deleteAttraction(const string &name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(const string &name, const string &location, const string &description) {
        for (auto &attraction : attractions) {
            if (attraction.name == name) {
                attraction.location = location;
                attraction.description = description;
                break;
            }
        }
    }

    void searchAttraction(const string &name) {
        for (const auto &attraction : attractions) {
            if (attraction.name == name) {
                cout << "Attraction: " << attraction.name << ", Location: " 
                     << attraction.location << ", Description: " << attraction.description << endl;
                return;
            }
        }
        cout << "Attraction not found." << endl;
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            cout << "Name: " << tourist.name << ", Age: " << tourist.age 
                 << ", Country: " << tourist.country << endl;
        }
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            cout << "Name: " << attraction.name << ", Location: " 
                 << attraction.location << ", Description: " << attraction.description << endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist("Alice", 30, "USA");
    guide.addTourist("Bob", 25, "UK");
    guide.searchTourist("Alice");
    guide.displayTourists();
    guide.addAttraction("Eiffel Tower", "Paris", "Iconic symbol of France");
    guide.searchAttraction("Eiffel Tower");
    guide.displayAttractions();
    return 0;
}