#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Attraction {
public:
    string name;
    string description;
    void display() const {
        cout << "Attraction: " << name << ", Description: " << description << endl;
    }
};

class Tourist {
public:
    string name;
    vector<Attraction> wishList;
    void display() const {
        cout << "Tourist: " << name << endl;
        cout << "Wishlist Attractions: " << endl;
        for (const auto& attraction : wishList) {
            cout << " - " << attraction.name << endl;
        }
    }
};

class TourismGuide {
public:
    vector<Attraction> attractions;
    vector<Tourist> tourists;

    void addAttraction(string name, string description) {
        attractions.push_back({name, description});
    }

    void deleteAttraction(string name) {
        attractions.erase(remove_if(attractions.begin(), attractions.end(),
            [&name](const Attraction& a) { return a.name == name; }), attractions.end());
    }

    void updateAttraction(string oldName, string newName, string newDescription) {
        for (auto& attraction : attractions) {
            if (attraction.name == oldName) {
                attraction.name = newName;
                attraction.description = newDescription;
                break;
            }
        }
    }

    void searchAttraction(string name) const {
        for (const auto& attraction : attractions) {
            if (attraction.name == name) {
                attraction.display();
                return;
            }
        }
        cout << "Attraction " << name << " not found." << endl;
    }

    void displayAttractions() const {
        cout << "All Attractions:" << endl;
        for (const auto& attraction : attractions) {
            attraction.display();
        }
    }

    void addTourist(string name) {
        tourists.push_back({name});
    }

    void deleteTourist(string name) {
        tourists.erase(remove_if(tourists.begin(), tourists.end(),
            [&name](const Tourist& t) { return t.name == name; }), tourists.end());
    }

    void updateTourist(string oldName, string newName) {
        for (auto& tourist : tourists) {
            if (tourist.name == oldName) {
                tourist.name = newName;
                break;
            }
        }
    }

    void searchTourist(string name) const {
        for (const auto& tourist : tourists) {
            if (tourist.name == name) {
                tourist.display();
                return;
            }
        }
        cout << "Tourist " << name << " not found." << endl;
    }

    void displayTourists() const {
        cout << "All Tourists:" << endl;
        for (const auto& tourist : tourists) {
            tourist.display();
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addAttraction("Eiffel Tower", "Famous landmark in Paris");
    guide.addAttraction("Colosseum", "Iconic ancient Roman gladiatorial arena");
    guide.addTourist("Alice");
    guide.addTourist("Bob");
    guide.displayAttractions();
    guide.displayTourists();
    guide.searchAttraction("Eiffel Tower");
    guide.searchTourist("Alice");
    guide.updateAttraction("Eiffel Tower", "Eiffel Tower Updated", "Famous landmark in Paris, updated description");
    guide.updateTourist("Alice", "Alice Smith");
    guide.deleteAttraction("Colosseum");
    guide.deleteTourist("Bob");
    guide.displayAttractions();
    guide.displayTourists();
    return 0;
}