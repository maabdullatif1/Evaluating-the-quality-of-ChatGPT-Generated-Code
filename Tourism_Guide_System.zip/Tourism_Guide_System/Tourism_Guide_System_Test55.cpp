#include <iostream>
#include <string>
#include <vector>

class Tourist {
public:
    std::string name;
    std::string id;
    
    Tourist(std::string n, std::string i) : name(n), id(i) {}
};

class Attraction {
public:
    std::string name;
    std::string location;
    
    Attraction(std::string n, std::string loc) : name(n), location(loc) {}
};

class TourismGuide {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(std::string name, std::string id) {
        tourists.push_back(Tourist(name, id));
    }
    
    void addAttraction(std::string name, std::string location) {
        attractions.push_back(Attraction(name, location));
    }

    void deleteTourist(std::string id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }

    void deleteAttraction(std::string name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateTourist(std::string id, std::string newName) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = newName;
                break;
            }
        }
    }

    void updateAttraction(std::string name, std::string newLocation) {
        for (auto &attraction : attractions) {
            if (attraction.name == name) {
                attraction.location = newLocation;
                break;
            }
        }
    }

    Tourist* searchTourist(std::string id) {
        for (auto &tourist : tourists) {
            if (tourist.id == id) {
                return &tourist;
            }
        }
        return nullptr;
    }

    Attraction* searchAttraction(std::string name) {
        for (auto &attraction : attractions) {
            if (attraction.name == name) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto &tourist : tourists) {
            std::cout << "Name: " << tourist.name << ", ID: " << tourist.id << std::endl;
        }
    }

    void displayAttractions() {
        for (const auto &attraction : attractions) {
            std::cout << "Name: " << attraction.name << ", Location: " << attraction.location << std::endl;
        }
    }
};

int main() {
    TourismGuide guide;

    guide.addTourist("Alice", "T001");
    guide.addTourist("Bob", "T002");

    guide.addAttraction("Eiffel Tower", "Paris");
    guide.addAttraction("Statue of Liberty", "New York");

    std::cout << "Tourists:\n";
    guide.displayTourists();

    std::cout << "\nAttractions:\n";
    guide.displayAttractions();

    return 0;
}