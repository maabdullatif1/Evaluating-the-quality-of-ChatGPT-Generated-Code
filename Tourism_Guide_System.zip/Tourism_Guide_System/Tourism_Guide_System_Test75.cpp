#include <iostream>
#include <vector>
#include <string>

struct Attraction {
    std::string name;
    std::string location;
    std::string description;
};

class TourismGuide {
private:
    std::vector<Attraction> attractions;

    int findAttraction(const std::string& name) {
        for (size_t i = 0; i < attractions.size(); ++i) {
            if (attractions[i].name == name) {
                return i;
            }
        }
        return -1;
    }

public:
    void addAttraction(const std::string& name, const std::string& location, const std::string& description) {
        Attraction newAttraction = {name, location, description};
        attractions.push_back(newAttraction);
    }

    void deleteAttraction(const std::string& name) {
        int index = findAttraction(name);
        if (index != -1) {
            attractions.erase(attractions.begin() + index);
        } else {
            std::cout << "Attraction not found.\n";
        }
    }

    void updateAttraction(const std::string& name, const std::string& location, const std::string& description) {
        int index = findAttraction(name);
        if (index != -1) {
            attractions[index].location = location;
            attractions[index].description = description;
        } else {
            std::cout << "Attraction not found.\n";
        }
    }

    void searchAttraction(const std::string& name) {
        int index = findAttraction(name);
        if (index != -1) {
            std::cout << "Name: " << attractions[index].name << "\n";
            std::cout << "Location: " << attractions[index].location << "\n";
            std::cout << "Description: " << attractions[index].description << "\n";
        } else {
            std::cout << "Attraction not found.\n";
        }
    }

    void displayAttractions() {
        if (attractions.empty()) {
            std::cout << "No attractions available.\n";
            return;
        }
        for (const auto& a : attractions) {
            std::cout << "Name: " << a.name << "\n";
            std::cout << "Location: " << a.location << "\n";
            std::cout << "Description: " << a.description << "\n";
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addAttraction("Eiffel Tower", "Paris", "Iconic tower in Paris");
    guide.addAttraction("Statue of Liberty", "New York", "Famous statue representing freedom");

    std::cout << "All attractions:\n";
    guide.displayAttractions();

    std::cout << "\nSearching for 'Eiffel Tower':\n";
    guide.searchAttraction("Eiffel Tower");

    std::cout << "\nUpdating 'Eiffel Tower':\n";
    guide.updateAttraction("Eiffel Tower", "Paris, France", "987 ft tall wrought iron tower");

    std::cout << "\nSearching for 'Eiffel Tower' after update:\n";
    guide.searchAttraction("Eiffel Tower");

    std::cout << "\nDeleting 'Statue of Liberty':\n";
    guide.deleteAttraction("Statue of Liberty");

    std::cout << "\nAll attractions after deletion:\n";
    guide.displayAttractions();

    return 0;
}