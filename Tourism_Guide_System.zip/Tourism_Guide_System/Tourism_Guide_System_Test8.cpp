#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    std::string name;
    std::string nationality;
    int age;

    Tourist(std::string n, std::string nat, int a) : name(n), nationality(nat), age(a) {}
};

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;

    Attraction(std::string n, std::string loc, std::string desc) : name(n), location(loc), description(desc) {}
};

class TourismGuideSystem {
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;
    
public:
    void addTourist(std::string name, std::string nationality, int age) {
        tourists.push_back(Tourist(name, nationality, age));
    }

    void deleteTourist(std::string name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                return;
            }
        }
    }

    void updateTourist(std::string oldName, std::string newName, std::string newNationality, int newAge) {
        for (auto& tourist : tourists) {
            if (tourist.name == oldName) {
                tourist.name = newName;
                tourist.nationality = newNationality;
                tourist.age = newAge;
                return;
            }
        }
    }

    void searchTourist(std::string name) {
        for (const auto& tourist : tourists) {
            if (tourist.name == name) {
                std::cout << "Tourist Found: " << tourist.name << ", " << tourist.nationality << ", " << tourist.age << "\n";
                return;
            }
        }
        std::cout << "Tourist Not Found\n";
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << tourist.name << ", " << tourist.nationality << ", " << tourist.age << "\n";
        }
    }

    void addAttraction(std::string name, std::string location, std::string description) {
        attractions.push_back(Attraction(name, location, description));
    }

    void deleteAttraction(std::string name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                return;
            }
        }
    }

    void updateAttraction(std::string oldName, std::string newName, std::string newLocation, std::string newDescription) {
        for (auto& attraction : attractions) {
            if (attraction.name == oldName) {
                attraction.name = newName;
                attraction.location = newLocation;
                attraction.description = newDescription;
                return;
            }
        }
    }

    void searchAttraction(std::string name) {
        for (const auto& attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Attraction Found: " << attraction.name << ", " << attraction.location << ", " << attraction.description << "\n";
                return;
            }
        }
        std::cout << "Attraction Not Found\n";
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << attraction.name << ", " << attraction.location << ", " << attraction.description << "\n";
        }
    }
};

int main() {
    TourismGuideSystem system;

    system.addTourist("John Doe", "American", 28);
    system.addTourist("Jane Smith", "British", 34);
    
    system.addAttraction("Eiffel Tower", "Paris", "Iconic landmark of France");
    system.addAttraction("Statue of Liberty", "New York", "Famous symbol of freedom");

    system.displayTourists();
    system.displayAttractions();

    system.searchTourist("Jane Smith");
    system.searchAttraction("Eiffel Tower");

    system.updateTourist("John Doe", "Johnny Doe", "Canadian", 29);
    system.updateAttraction("Statue of Liberty", "Liberty Statue", "Liberty Island", "Renowned American landmark");

    system.displayTourists();
    system.displayAttractions();

    system.deleteTourist("Jane Smith");
    system.deleteAttraction("Eiffel Tower");

    system.displayTourists();
    system.displayAttractions();

    return 0;
}