#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    std::string name;
    int age;
    
    Tourist(const std::string& name, int age) : name(name), age(age) {}
};

class Attraction {
public:
    std::string attractionName;
    std::string location;
    
    Attraction(const std::string& attractionName, const std::string& location) 
        : attractionName(attractionName), location(location) {}
};

class TourismGuide {
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;
    
public:
    void addTourist(const std::string& name, int age) {
        tourists.emplace_back(name, age);
    }
    
    void deleteTourist(const std::string& name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }
    
    void updateTourist(const std::string& name, const std::string& newName, int newAge) {
        for (auto& t : tourists) {
            if (t.name == name) {
                t.name = newName;
                t.age = newAge;
                break;
            }
        }
    }

    void searchTourist(const std::string& name) {
        for (const auto& t : tourists) {
            if (t.name == name) {
                std::cout << "Tourist Name: " << t.name << ", Age: " << t.age << '\n';
                return;
            }
        }
        std::cout << "Tourist not found\n";
    }
    
    void displayTourists() {
        for (const auto& t : tourists) {
            std::cout << "Tourist Name: " << t.name << ", Age: " << t.age << '\n';
        }
    }

    void addAttraction(const std::string& name, const std::string& location) {
        attractions.emplace_back(name, location);
    }
    
    void deleteAttraction(const std::string& name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->attractionName == name) {
                attractions.erase(it);
                break;
            }
        }
    }
    
    void updateAttraction(const std::string& name, const std::string& newName, const std::string& newLocation) {
        for (auto& a : attractions) {
            if (a.attractionName == name) {
                a.attractionName = newName;
                a.location = newLocation;
                break;
            }
        }
    }

    void searchAttraction(const std::string& name) {
        for (const auto& a : attractions) {
            if (a.attractionName == name) {
                std::cout << "Attraction Name: " << a.attractionName << ", Location: " << a.location << '\n';
                return;
            }
        }
        std::cout << "Attraction not found\n";
    }
    
    void displayAttractions() {
        for (const auto& a : attractions) {
            std::cout << "Attraction Name: " << a.attractionName << ", Location: " << a.location << '\n';
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist("John Doe", 35);
    guide.addTourist("Jane Smith", 28);
    guide.addAttraction("Eiffel Tower", "Paris");
    guide.addAttraction("Statue of Liberty", "New York");

    std::cout << "Displaying all tourists:\n";
    guide.displayTourists();
    
    std::cout << "\nDisplaying all attractions:\n";
    guide.displayAttractions();
    
    std::cout << "\nSearching for Tourist 'John Doe':\n";
    guide.searchTourist("John Doe");
    
    std::cout << "\nUpdating Tourist 'John Doe' to 'Jonathan Doe', Age 36:\n";
    guide.updateTourist("John Doe", "Jonathan Doe", 36);
    guide.displayTourists();
    
    std::cout << "\nDeleting Tourist 'Jane Smith':\n";
    guide.deleteTourist("Jane Smith");
    guide.displayTourists();
    
    std::cout << "\nSearching for Attraction 'Eiffel Tower':\n";
    guide.searchAttraction("Eiffel Tower");
    
    std::cout << "\nUpdating Attraction 'Eiffel Tower' to 'Louvre', Location 'Paris':\n";
    guide.updateAttraction("Eiffel Tower", "Louvre", "Paris");
    guide.displayAttractions();
    
    std::cout << "\nDeleting Attraction 'Statue of Liberty':\n";
    guide.deleteAttraction("Statue of Liberty");
    guide.displayAttractions();
    
    return 0;
}