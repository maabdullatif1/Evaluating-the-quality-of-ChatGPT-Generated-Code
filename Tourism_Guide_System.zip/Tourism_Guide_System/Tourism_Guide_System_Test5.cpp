#include <iostream>
#include <vector>
#include <string>

struct Attraction {
    std::string name;
    std::string location;
    std::string description;
};

struct Tourist {
    std::string name;
    int age;
    std::string nationality;
};

class TourismGuide {
private:
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;

public:
    void addAttraction(const std::string& name, const std::string& location, const std::string& description) {
        attractions.push_back({name, location, description});
    }

    void deleteAttraction(const std::string& name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(const std::string& name, const std::string& location, const std::string& description) {
        for (auto& attr : attractions) {
            if (attr.name == name) {
                attr.location = location;
                attr.description = description;
                break;
            }
        }
    }

    void searchAttraction(const std::string& name) {
        for (const auto& attr : attractions) {
            if (attr.name == name) {
                std::cout << "Attraction: " << attr.name << ", Location: " << attr.location 
                          << ", Description: " << attr.description << std::endl;
                return;
            }
        }
        std::cout << "Attraction not found" << std::endl;
    }

    void displayAttractions() {
        for (const auto& attr : attractions) {
            std::cout << "Attraction: " << attr.name << ", Location: " << attr.location 
                      << ", Description: " << attr.description << std::endl;
        }
    }

    void addTourist(const std::string& name, int age, const std::string& nationality) {
        tourists.push_back({name, age, nationality});
    }

    void deleteTourist(const std::string& name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(const std::string& name, int age, const std::string& nationality) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                tourist.age = age;
                tourist.nationality = nationality;
                break;
            }
        }
    }

    void searchTourist(const std::string& name) {
        for (const auto& tourist : tourists) {
            if (tourist.name == name) {
                std::cout << "Tourist: " << tourist.name << ", Age: " << tourist.age 
                          << ", Nationality: " << tourist.nationality << std::endl;
                return;
            }
        }
        std::cout << "Tourist not found" << std::endl;
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Tourist: " << tourist.name << ", Age: " << tourist.age 
                      << ", Nationality: " << tourist.nationality << std::endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addAttraction("Eiffel Tower", "Paris", "Famous landmark of Paris");
    guide.addTourist("Alice", 30, "American");
    guide.displayAttractions();
    guide.displayTourists();
    guide.searchAttraction("Eiffel Tower");
    guide.searchTourist("Alice");
    guide.updateAttraction("Eiffel Tower", "Paris", "Iconic symbol of France");
    guide.updateTourist("Alice", 31, "Canadian");
    guide.displayAttractions();
    guide.displayTourists();
    guide.deleteAttraction("Eiffel Tower");
    guide.deleteTourist("Alice");
    guide.displayAttractions();
    guide.displayTourists();
    return 0;
}