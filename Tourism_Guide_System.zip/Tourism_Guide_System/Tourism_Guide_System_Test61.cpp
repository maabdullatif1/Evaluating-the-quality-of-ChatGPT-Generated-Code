#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    int id;
    std::string name;
    std::string location;
    Attraction(int id, std::string name, std::string location)
        : id(id), name(name), location(location) {}
};

class Tourist {
public:
    int id;
    std::string name;
    std::string nationality;
    Tourist(int id, std::string name, std::string nationality)
        : id(id), name(name), nationality(nationality) {}
};

class TourismSystem {
private:
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;
    int nextTouristId;
    int nextAttractionId;

    int findTouristIndexById(int id) {
        for (int i = 0; i < tourists.size(); ++i) {
            if (tourists[i].id == id)
                return i;
        }
        return -1;
    }

    int findAttractionIndexById(int id) {
        for (int i = 0; i < attractions.size(); ++i) {
            if (attractions[i].id == id)
                return i;
        }
        return -1;
    }

public:
    TourismSystem() : nextTouristId(1), nextAttractionId(1) {}

    void addTourist(std::string name, std::string nationality) {
        tourists.push_back(Tourist(nextTouristId++, name, nationality));
    }

    void addAttraction(std::string name, std::string location) {
        attractions.push_back(Attraction(nextAttractionId++, name, location));
    }

    void deleteTourist(int id) {
        int index = findTouristIndexById(id);
        if (index != -1) {
            tourists.erase(tourists.begin() + index);
        }
    }

    void deleteAttraction(int id) {
        int index = findAttractionIndexById(id);
        if (index != -1) {
            attractions.erase(attractions.begin() + index);
        }
    }
    
    void updateTourist(int id, std::string name, std::string nationality) {
        int index = findTouristIndexById(id);
        if (index != -1) {
            tourists[index].name = name;
            tourists[index].nationality = nationality;
        }
    }

    void updateAttraction(int id, std::string name, std::string location) {
        int index = findAttractionIndexById(id);
        if (index != -1) {
            attractions[index].name = name;
            attractions[index].location = location;
        }
    }

    Tourist* searchTourist(int id) {
        int index = findTouristIndexById(id);
        return index != -1 ? &tourists[index] : nullptr;
    }

    Attraction* searchAttraction(int id) {
        int index = findAttractionIndexById(id);
        return index != -1 ? &attractions[index] : nullptr;
    }

    void displayTourists() {
        for (const Tourist& t : tourists) {
            std::cout << "ID: " << t.id << ", Name: " << t.name << ", Nationality: " << t.nationality << std::endl;
        }
    }

    void displayAttractions() {
        for (const Attraction& a : attractions) {
            std::cout << "ID: " << a.id << ", Name: " << a.name << ", Location: " << a.location << std::endl;
        }
    }
};

int main() {
    TourismSystem system;
    system.addTourist("Alice", "American");
    system.addTourist("Bob", "British");
    system.addAttraction("Eiffel Tower", "Paris");
    system.addAttraction("Statue of Liberty", "New York");
    
    system.displayTourists();
    system.displayAttractions();
    
    system.updateTourist(1, "Alice Smith", "Canadian");
    system.updateAttraction(2, "Statue of Liberty", "Liberty Island, New York");

    Tourist* tourist = system.searchTourist(1);
    if (tourist) {
        std::cout << "Found Tourist: " << tourist->name << ", " << tourist->nationality << std::endl;
    }

    Attraction* attraction = system.searchAttraction(1);
    if (attraction) {
        std::cout << "Found Attraction: " << attraction->name << ", " << attraction->location << std::endl;
    }

    system.deleteTourist(2);
    system.deleteAttraction(2);

    system.displayTourists();
    system.displayAttractions();

    return 0;
}