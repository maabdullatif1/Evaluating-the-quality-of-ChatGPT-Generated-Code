#include <iostream>
#include <vector>
#include <string>

struct Attraction {
    std::string name;
    std::string location;
    std::string description;
};

struct Tourist {
    std::string name;
    std::string nationality;
    std::vector<Attraction> attractionsVisited;
};

class TourismGuideSystem {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(const std::string& name, const std::string& nationality) {
        Tourist t;
        t.name = name;
        t.nationality = nationality;
        tourists.push_back(t);
    }

    void deleteTourist(const std::string& name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(const std::string& name, const std::string& newName, const std::string& nationality) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                tourist.name = newName;
                tourist.nationality = nationality;
                break;
            }
        }
    }

    Tourist* searchTourist(const std::string& name) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "Name: " << tourist.name << ", Nationality: " << tourist.nationality << "\n";
        }
    }

    void addAttraction(const std::string& name, const std::string& location, const std::string& description) {
        Attraction a;
        a.name = name;
        a.location = location;
        a.description = description;
        attractions.push_back(a);
    }

    void deleteAttraction(const std::string& name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(const std::string& name, const std::string& newName, const std::string& location, const std::string& description) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                attraction.name = newName;
                attraction.location = location;
                attraction.description = description;
                break;
            }
        }
    }

    Attraction* searchAttraction(const std::string& name) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "Name: " << attraction.name << ", Location: " << attraction.location << ", Description: " << attraction.description << "\n";
        }
    }

    void recordVisit(const std::string& touristName, const std::string& attractionName) {
        Tourist* tourist = searchTourist(touristName);
        Attraction* attraction = searchAttraction(attractionName);
        if (tourist && attraction) {
            tourist->attractionsVisited.push_back(*attraction);
        }
    }

    void displayVisits(const std::string& touristName) {
        Tourist* tourist = searchTourist(touristName);
        if (tourist) {
            std::cout << "Attractions visited by " << tourist->name << ":\n";
            for (const auto& attraction : tourist->attractionsVisited) {
                std::cout << "- " << attraction.name << "\n";
            }
        }
    }
};

int main() {
    TourismGuideSystem system;
    system.addTourist("Alice Smith", "USA");
    system.addTourist("Bob Brown", "UK");
    system.displayTourists();

    system.addAttraction("Eiffel Tower", "Paris", "Iconic landmark of France");
    system.addAttraction("Colosseum", "Rome", "Ancient Roman gladiatorial arena");
    system.displayAttractions();

    system.recordVisit("Alice Smith", "Eiffel Tower");
    system.displayVisits("Alice Smith");

    return 0;
}