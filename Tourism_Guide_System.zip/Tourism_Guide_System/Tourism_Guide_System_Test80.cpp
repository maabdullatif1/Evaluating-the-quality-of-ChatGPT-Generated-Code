#include <iostream>
#include <string>
#include <vector>

class Tourist {
public:
    int id;
    std::string name;
    std::string nationality;

    Tourist(int id, const std::string& name, const std::string& nationality)
        : id(id), name(name), nationality(nationality) {}
};

class Attraction {
public:
    int id;
    std::string name;
    std::string location;

    Attraction(int id, const std::string& name, const std::string& location)
        : id(id), name(name), location(location) {}
};

class TourismGuide {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(int id, const std::string& name, const std::string& nationality) {
        tourists.push_back(Tourist(id, name, nationality));
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                return;
            }
        }
    }

    void updateTourist(int id, const std::string& name, const std::string& nationality) {
        for (auto& tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.nationality = nationality;
                return;
            }
        }
    }

    void searchTourist(int id) const {
        for (const auto& tourist : tourists) {
            if (tourist.id == id) {
                std::cout << "Tourist found: " << tourist.name << ", " << tourist.nationality << "\n";
                return;
            }
        }
        std::cout << "Tourist not found.\n";
    }

    void displayTourists() const {
        for (const auto& tourist : tourists) {
            std::cout << "ID: " << tourist.id << ", Name: " << tourist.name
                      << ", Nationality: " << tourist.nationality << "\n";
        }
    }

    void addAttraction(int id, const std::string& name, const std::string& location) {
        attractions.push_back(Attraction(id, name, location));
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                return;
            }
        }
    }

    void updateAttraction(int id, const std::string& name, const std::string& location) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.location = location;
                return;
            }
        }
    }

    void searchAttraction(int id) const {
        for (const auto& attraction : attractions) {
            if (attraction.id == id) {
                std::cout << "Attraction found: " << attraction.name << ", " << attraction.location << "\n";
                return;
            }
        }
        std::cout << "Attraction not found.\n";
    }

    void displayAttractions() const {
        for (const auto& attraction : attractions) {
            std::cout << "ID: " << attraction.id << ", Name: " << attraction.name
                      << ", Location: " << attraction.location << "\n";
        }
    }
};

int main() {
    TourismGuide guide;

    guide.addTourist(1, "Alice", "USA");
    guide.addTourist(2, "Bob", "UK");
    guide.addAttraction(1, "Eiffel Tower", "Paris");
    guide.addAttraction(2, "Statue of Liberty", "New York");

    guide.displayTourists();
    guide.displayAttractions();

    guide.updateTourist(1, "Alice Smith", "USA");
    guide.updateAttraction(2, "Statue of Liberty National Monument", "New York");

    guide.searchTourist(1);
    guide.searchAttraction(2);

    guide.deleteTourist(2);
    guide.deleteAttraction(1);

    guide.displayTourists();
    guide.displayAttractions();

    return 0;
}