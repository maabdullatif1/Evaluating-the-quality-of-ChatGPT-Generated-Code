#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Tourist {
public:
    int id;
    string name;
    string contact;

    Tourist(int id, const string& name, const string& contact) : id(id), name(name), contact(contact) {}
};

class Attraction {
public:
    int id;
    string name;
    string location;

    Attraction(int id, const string& name, const string& location) : id(id), name(name), location(location) {}
};

class TourismGuide {
    vector<Tourist> tourists;
    vector<Attraction> attractions;

public:
    void addTourist(int id, const string& name, const string& contact) {
        tourists.push_back(Tourist(id, name, contact));
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(int id, const string& name, const string& contact) {
        for (auto& tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.contact = contact;
                break;
            }
        }
    }

    Tourist* searchTourist(int id) {
        for (auto& tourist : tourists) {
            if (tourist.id == id) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            cout << "ID: " << tourist.id << ", Name: " << tourist.name << ", Contact: " << tourist.contact << endl;
        }
    }

    void addAttraction(int id, const string& name, const string& location) {
        attractions.push_back(Attraction(id, name, location));
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(int id, const string& name, const string& location) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) {
                attraction.name = name;
                attraction.location = location;
                break;
            }
        }
    }

    Attraction* searchAttraction(int id) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            cout << "ID: " << attraction.id << ", Name: " << attraction.name << ", Location: " << attraction.location << endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist(1, "John Doe", "123456789");
    guide.addTourist(2, "Jane Smith", "987654321");
    guide.displayTourists();

    guide.addAttraction(1, "Eiffel Tower", "Paris");
    guide.addAttraction(2, "Statue of Liberty", "New York");
    guide.displayAttractions();

    guide.updateTourist(1, "John Doe Updated", "111222333");
    guide.displayTourists();

    Tourist* t = guide.searchTourist(2);
    if (t) {
        cout << "Found Tourist: " << t->name << endl;
    }

    guide.deleteTourist(1);
    guide.displayTourists();

    guide.updateAttraction(2, "Statue of Liberty Updated", "NYC");
    guide.displayAttractions();

    Attraction* a = guide.searchAttraction(1);
    if (a) {
        cout << "Found Attraction: " << a->name << endl;
    }

    guide.deleteAttraction(1);
    guide.displayAttractions();

    return 0;
}