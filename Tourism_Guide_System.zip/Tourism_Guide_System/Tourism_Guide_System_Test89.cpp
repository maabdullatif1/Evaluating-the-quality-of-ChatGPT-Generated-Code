#include <iostream>
#include <string>
#include <vector>

class Attraction {
public:
    Attraction(const std::string& name, const std::string& location) : name(name), location(location) {}
    std::string getName() const { return name; }
    void setName(const std::string& newName) { name = newName; }
    std::string getLocation() const { return location; }
    void setLocation(const std::string& newLocation) { location = newLocation; }

private:
    std::string name;
    std::string location;
};

class Tourist {
public:
    Tourist(const std::string& name, const std::string& nationality) : name(name), nationality(nationality) {}
    std::string getName() const { return name; }
    void setName(const std::string& newName) { name = newName; }
    std::string getNationality() const { return nationality; }
    void setNationality(const std::string& newNationality) { nationality = newNationality; }

private:
    std::string name;
    std::string nationality;
};

class TourismGuide {
public:
    void addAttraction(const std::string& name, const std::string& location) {
        attractions.emplace_back(name, location);
    }

    void addTourist(const std::string& name, const std::string& nationality) {
        tourists.emplace_back(name, nationality);
    }

    void deleteAttraction(const std::string& name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->getName() == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void deleteTourist(const std::string& name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->getName() == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateAttraction(const std::string& name, const std::string& newName, const std::string& newLocation) {
        for (auto& attraction : attractions) {
            if (attraction.getName() == name) {
                attraction.setName(newName);
                attraction.setLocation(newLocation);
                break;
            }
        }
    }

    void updateTourist(const std::string& name, const std::string& newName, const std::string& newNationality) {
        for (auto& tourist : tourists) {
            if (tourist.getName() == name) {
                tourist.setName(newName);
                tourist.setNationality(newNationality);
                break;
            }
        }
    }

    void searchAttraction(const std::string& name) const {
        for (const auto& attraction : attractions) {
            if (attraction.getName() == name) {
                std::cout << "Attraction Found: " << attraction.getName() << ", Location: " << attraction.getLocation() << std::endl;
                return;
            }
        }
        std::cout << "Attraction not found." << std::endl;
    }

    void searchTourist(const std::string& name) const {
        for (const auto& tourist : tourists) {
            if (tourist.getName() == name) {
                std::cout << "Tourist Found: " << tourist.getName() << ", Nationality: " << tourist.getNationality() << std::endl;
                return;
            }
        }
        std::cout << "Tourist not found." << std::endl;
    }

    void displayAttractions() const {
        std::cout << "Attractions List:" << std::endl;
        for (const auto& attraction : attractions) {
            std::cout << "Name: " << attraction.getName() << ", Location: " << attraction.getLocation() << std::endl;
        }
    }

    void displayTourists() const {
        std::cout << "Tourists List:" << std::endl;
        for (const auto& tourist : tourists) {
            std::cout << "Name: " << tourist.getName() << ", Nationality: " << tourist.getNationality() << std::endl;
        }
    }

private:
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;
};

int main() {
    TourismGuide guide;
    guide.addAttraction("Eiffel Tower", "Paris");
    guide.addTourist("John Doe", "American");

    guide.displayAttractions();
    guide.displayTourists();

    guide.searchAttraction("Eiffel Tower");
    guide.searchTourist("John Doe");

    guide.updateAttraction("Eiffel Tower", "The Louvre", "Paris");
    guide.updateTourist("John Doe", "Jane Smith", "British");

    guide.displayAttractions();
    guide.displayTourists();

    guide.deleteAttraction("The Louvre");
    guide.deleteTourist("Jane Smith");

    guide.displayAttractions();
    guide.displayTourists();

    return 0;
}