#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Attraction {
public:
    string name;
    string location;
    string description;

    Attraction(string n, string l, string d) : name(n), location(l), description(d) {}
};

class Tourist {
public:
    string name;
    string nationality;
    vector<Attraction> visitedAttractions;

    Tourist(string n, string na) : name(n), nationality(na) {}
    void visitAttraction(Attraction attr) {
        visitedAttractions.push_back(attr);
    }
};

class TourismGuide {
private:
    vector<Tourist> tourists;
    vector<Attraction> attractions;

public:
    void addTourist(string name, string nationality) {
        tourists.push_back(Tourist(name, nationality));
    }

    void deleteTourist(string name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(string oldName, string newName, string newNationality) {
        for (auto& tourist : tourists) {
            if (tourist.name == oldName) {
                tourist.name = newName;
                tourist.nationality = newNationality;
                break;
            }
        }
    }

    Tourist* searchTourist(string name) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                return &tourist;
            }
        }
        return nullptr;
    }

    void addAttraction(string name, string location, string description) {
        attractions.push_back(Attraction(name, location, description));
    }

    void deleteAttraction(string name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(string oldName, string newName, string newLocation, string newDescription) {
        for (auto& attraction : attractions) {
            if (attraction.name == oldName) {
                attraction.name = newName;
                attraction.location = newLocation;
                attraction.description = newDescription;
                break;
            }
        }
    }

    Attraction* searchAttraction(string name) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                return &attraction;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            cout << "Name: " << tourist.name << ", Nationality: " << tourist.nationality << endl;
        }
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            cout << "Name: " << attraction.name << ", Location: " << attraction.location
                 << ", Description: " << attraction.description << endl;
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist("Alice", "American");
    guide.addTourist("Bob", "British");
    guide.addAttraction("Eiffel Tower", "Paris", "A wrought-iron lattice tower");
    guide.displayTourists();
    guide.displayAttractions();
    return 0;
}