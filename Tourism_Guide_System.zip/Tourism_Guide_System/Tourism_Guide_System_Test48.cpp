#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    int id;
    std::string name;
    std::string location;
    double entryFee;

    Attraction(int id, const std::string& name, const std::string& location, double fee)
        : id(id), name(name), location(location), entryFee(fee) {}
};

class Tourist {
public:
    int id;
    std::string name;
    int age;

    Tourist(int id, const std::string& name, int age)
        : id(id), name(name), age(age) {}
};

class TourismGuideSystem {
private:
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;

public:
    void addAttraction(int id, const std::string& name, const std::string& location, double fee) {
        attractions.push_back(Attraction(id, name, location, fee));
    }

    void removeAttraction(int id) {
        attractions.erase(std::remove_if(attractions.begin(), attractions.end(), 
            [id](const Attraction& attr) { return attr.id == id; }), attractions.end());
    }

    void updateAttraction(int id, const std::string& name, const std::string& location, double fee) {
        for (auto& attr : attractions) {
            if (attr.id == id) {
                attr.name = name;
                attr.location = location;
                attr.entryFee = fee;
            }
        }
    }

    Attraction* searchAttraction(int id) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) return &attraction;
        }
        return nullptr;
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "ID: " << attraction.id << ", Name: " << attraction.name 
                      << ", Location: " << attraction.location << ", Fee: " << attraction.entryFee << "\n";
        }
    }

    void addTourist(int id, const std::string& name, int age) {
        tourists.push_back(Tourist(id, name, age));
    }

    void removeTourist(int id) {
        tourists.erase(std::remove_if(tourists.begin(), tourists.end(), 
            [id](const Tourist& tourist) { return tourist.id == id; }), tourists.end());
    }

    void updateTourist(int id, const std::string& name, int age) {
        for (auto& tourist : tourists) {
            if (tourist.id == id) {
                tourist.name = name;
                tourist.age = age;
            }
        }
    }

    Tourist* searchTourist(int id) {
        for (auto& tourist : tourists) {
            if (tourist.id == id) return &tourist;
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "ID: " << tourist.id << ", Name: " << tourist.name 
                      << ", Age: " << tourist.age << "\n";
        }
    }
};

int main() {
    TourismGuideSystem system;
    
    system.addAttraction(1, "Eiffel Tower", "Paris", 25.0);
    system.addAttraction(2, "Statue of Liberty", "New York", 22.50);
    system.displayAttractions();
    
    system.addTourist(1, "John Doe", 30);
    system.addTourist(2, "Jane Smith", 27);
    system.displayTourists();

    system.updateAttraction(1, "Eiffel Tower", "Paris", 30.0);
    system.displayAttractions();
    
    system.updateTourist(1, "John Doe", 31);
    system.displayTourists();

    system.removeAttraction(2);
    system.displayAttractions();

    system.removeTourist(2);
    system.displayTourists();

    return 0;
}