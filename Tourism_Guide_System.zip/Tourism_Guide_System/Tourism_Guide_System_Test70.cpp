#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    int id;
    std::string name;
    std::string description;

    Attraction(int id, std::string name, std::string description)
     : id(id), name(name), description(description) {}
};

class Tourist {
public:
    int id;
    std::string name;
    std::string contactInfo;

    Tourist(int id, std::string name, std::string contactInfo)
     : id(id), name(name), contactInfo(contactInfo) {}
};

class TourismGuideSystem {
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(int id, const std::string& name, const std::string& contactInfo) {
        tourists.push_back(Tourist(id, name, contactInfo));
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(int id, const std::string& name, const std::string& contactInfo) {
        for (auto& t : tourists) {
            if (t.id == id) {
                t.name = name;
                t.contactInfo = contactInfo;
                break;
            }
        }
    }

    Tourist* searchTourist(int id) {
        for (auto& t : tourists) {
            if (t.id == id) {
                return &t;
            }
        }
        return nullptr;
    }

    void displayTourists() {
        for (const auto& t : tourists) {
            std::cout << "Tourist ID: " << t.id << ", Name: " << t.name
                      << ", Contact Info: " << t.contactInfo << std::endl;
        }
    }

    void addAttraction(int id, const std::string& name, const std::string& description) {
        attractions.push_back(Attraction(id, name, description));
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(int id, const std::string& name, const std::string& description) {
        for (auto& a : attractions) {
            if (a.id == id) {
                a.name = name;
                a.description = description;
                break;
            }
        }
    }

    Attraction* searchAttraction(int id) {
        for (auto& a : attractions) {
            if (a.id == id) {
                return &a;
            }
        }
        return nullptr;
    }

    void displayAttractions() {
        for (const auto& a : attractions) {
            std::cout << "Attraction ID: " << a.id << ", Name: " << a.name
                      << ", Description: " << a.description << std::endl;
        }
    }
};

int main() {
    TourismGuideSystem system;
    system.addTourist(1, "John Doe", "john@example.com");
    system.addTourist(2, "Jane Smith", "jane@example.com");
    system.addAttraction(101, "Eiffel Tower", "Famous landmark in Paris");
    system.addAttraction(102, "Great Wall", "Historic wall in China");

    system.displayTourists();
    system.displayAttractions();

    system.updateTourist(1, "John A. Doe", "john.a.doe@example.com");
    system.deleteTourist(2);

    system.updateAttraction(101, "Eiffel Tower", "Iconic landmark in Paris, France");
    system.deleteAttraction(102);

    system.displayTourists();
    system.displayAttractions();

    return 0;
}