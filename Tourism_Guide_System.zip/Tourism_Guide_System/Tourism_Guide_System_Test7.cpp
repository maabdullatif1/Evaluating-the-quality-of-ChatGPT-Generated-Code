#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Attraction {
public:
    string name;
    string location;
    string description;

    Attraction(string name, string location, string description)
        : name(name), location(location), description(description) {}
};

class Tourist {
public:
    string name;
    int age;
    string nationality;

    Tourist(string name, int age, string nationality)
        : name(name), age(age), nationality(nationality) {}
};

class TourismGuide {
private:
    vector<Tourist> tourists;
    vector<Attraction> attractions;

public:
    void addTourist(const string& name, int age, const string& nationality) {
        tourists.push_back(Tourist(name, age, nationality));
    }

    void deleteTourist(const string& name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                return;
            }
        }
    }

    void updateTourist(const string& name, int age, const string& nationality) {
        for (auto& tourist : tourists) {
            if (tourist.name == name) {
                tourist.age = age;
                tourist.nationality = nationality;
                return;
            }
        }
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            cout << "Name: " << tourist.name << ", Age: " << tourist.age << ", Nationality: " << tourist.nationality << endl;
        }
    }

    void addAttraction(const string& name, const string& location, const string& description) {
        attractions.push_back(Attraction(name, location, description));
    }

    void deleteAttraction(const string& name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                return;
            }
        }
    }

    void updateAttraction(const string& name, const string& location, const string& description) {
        for (auto& attraction : attractions) {
            if (attraction.name == name) {
                attraction.location = location;
                attraction.description = description;
                return;
            }
        }
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            cout << "Name: " << attraction.name << ", Location: " << attraction.location << ", Description: " << attraction.description << endl;
        }
    }

    void searchTourist(const string& name) {
        for (const auto& tourist : tourists) {
            if (tourist.name == name) {
                cout << "Found Tourist: " << "Name: " << tourist.name << ", Age: " << tourist.age << ", Nationality: " << tourist.nationality << endl;
                return;
            }
        }
        cout << "Tourist not found." << endl;
    }

    void searchAttraction(const string& name) {
        for (const auto& attraction : attractions) {
            if (attraction.name == name) {
                cout << "Found Attraction: " << "Name: " << attraction.name << ", Location: " << attraction.location << ", Description: " << attraction.description << endl;
                return;
            }
        }
        cout << "Attraction not found." << endl;
    }
};

int main() {
    TourismGuide guide;
    
    guide.addTourist("Alice", 30, "American");
    guide.addTourist("Bob", 25, "British");
    guide.displayTourists();
    
    guide.addAttraction("Eiffel Tower", "Paris", "Iconic French landmark.");
    guide.addAttraction("Statue of Liberty", "New York", "Symbol of Freedom.");
    guide.displayAttractions();
    
    guide.updateTourist("Alice", 31, "American");
    guide.searchTourist("Alice");
    
    guide.updateAttraction("Eiffel Tower", "Paris, France", "World-famous landmark.");
    guide.searchAttraction("Eiffel Tower");
    
    guide.deleteTourist("Bob");
    guide.displayTourists();
    
    guide.deleteAttraction("Statue of Liberty");
    guide.displayAttractions();

    return 0;
}