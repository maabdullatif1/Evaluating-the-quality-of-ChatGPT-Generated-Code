#include <iostream>
#include <vector>
#include <string>

class Tourist {
public:
    std::string name;
    std::string nationality;
    int age;

    Tourist(std::string name, std::string nationality, int age) :
        name(name), nationality(nationality), age(age) {}
};

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;

    Attraction(std::string name, std::string location, std::string description) :
        name(name), location(location), description(description) {}
};

class TourismGuide {
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;

public:
    void addTourist(std::string name, std::string nationality, int age) {
        tourists.emplace_back(name, nationality, age);
    }

    void deleteTourist(std::string name) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->name == name) {
                tourists.erase(it);
                break;
            }
        }
    }

    void updateTourist(std::string oldName, std::string newName, std::string nationality, int age) {
        for (auto& tourist : tourists) {
            if (tourist.name == oldName) {
                tourist.name = newName;
                tourist.nationality = nationality;
                tourist.age = age;
                break;
            }
        }
    }

    void searchTourist(std::string name) {
        for (const auto& tourist : tourists) {
            if (tourist.name == name) {
                std::cout << "Tourist Found: " << tourist.name << ", " << tourist.nationality << ", " << tourist.age << "\n";
                return;
            }
        }
        std::cout << "Tourist Not Found\n";
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << tourist.name << ", " << tourist.nationality << ", " << tourist.age << "\n";
        }
    }

    void addAttraction(std::string name, std::string location, std::string description) {
        attractions.emplace_back(name, location, description);
    }

    void deleteAttraction(std::string name) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->name == name) {
                attractions.erase(it);
                break;
            }
        }
    }

    void updateAttraction(std::string oldName, std::string newName, std::string location, std::string description) {
        for (auto& attraction : attractions) {
            if (attraction.name == oldName) {
                attraction.name = newName;
                attraction.location = location;
                attraction.description = description;
                break;
            }
        }
    }

    void searchAttraction(std::string name) {
        for (const auto& attraction : attractions) {
            if (attraction.name == name) {
                std::cout << "Attraction Found: " << attraction.name << ", " << attraction.location << ", " << attraction.description << "\n";
                return;
            }
        }
        std::cout << "Attraction Not Found\n";
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << attraction.name << ", " << attraction.location << ", " << attraction.description << "\n";
        }
    }
};

int main() {
    TourismGuide guide;
    guide.addTourist("John Doe", "American", 30);
    guide.addTourist("Jane Smith", "British", 25);
    guide.displayTourists();
    guide.addAttraction("Eiffel Tower", "Paris", "Iconic tower in the heart of Paris");
    guide.addAttraction("Louvre Museum", "Paris", "Famous art museum");
    guide.displayAttractions();
    guide.searchTourist("Jane Smith");
    guide.searchAttraction("Louvre Museum");
    guide.updateTourist("Jane Smith", "Jane Doe", "Canadian", 26);
    guide.updateAttraction("Louvre Museum", "Louvre Museum", "Paris, France", "World-renowned art museum");
    guide.displayTourists();
    guide.displayAttractions();
    guide.deleteTourist("John Doe");
    guide.deleteAttraction("Eiffel Tower");
    guide.displayTourists();
    guide.displayAttractions();
    return 0;
}