#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;

    Attraction(std::string n, std::string loc, std::string desc)
        : name(n), location(loc), description(desc) {}
};

class Tourist {
public:
    std::string name;
    std::string passportNumber;

    Tourist(std::string n, std::string passport)
        : name(n), passportNumber(passport) {}
};

class TourismGuideSystem {
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;

    int findAttractionIndex(const std::string &name) {
        for (int i = 0; i < attractions.size(); ++i) {
            if (attractions[i].name == name) {
                return i;
            }
        }
        return -1;
    }

    int findTouristIndex(const std::string &passportNumber) {
        for (int i = 0; i < tourists.size(); ++i) {
            if (tourists[i].passportNumber == passportNumber) {
                return i;
            }
        }
        return -1;
    }

public:
    void addAttraction(const std::string &name, const std::string &location, const std::string &description) {
        attractions.push_back(Attraction(name, location, description));
    }

    void deleteAttraction(const std::string &name) {
        int index = findAttractionIndex(name);
        if (index != -1) {
            attractions.erase(attractions.begin() + index);
        }
    }

    void updateAttraction(const std::string &name, const std::string &newLocation, const std::string &newDescription) {
        int index = findAttractionIndex(name);
        if (index != -1) {
            attractions[index].location = newLocation;
            attractions[index].description = newDescription;
        }
    }

    void searchAttraction(const std::string &name) {
        int index = findAttractionIndex(name);
        if (index != -1) {
            std::cout << "Attraction Found: " << attractions[index].name << ", " << attractions[index].location << ", "
                      << attractions[index].description << std::endl;
        } else {
            std::cout << "Attraction not found" << std::endl;
        }
    }

    void displayAttractions() {
        for (const auto &attr : attractions) {
            std::cout << "Attraction: " << attr.name << ", Location: " << attr.location << ", Description: " << attr.description << std::endl;
        }
    }

    void addTourist(const std::string &name, const std::string &passportNumber) {
        tourists.push_back(Tourist(name, passportNumber));
    }

    void deleteTourist(const std::string &passportNumber) {
        int index = findTouristIndex(passportNumber);
        if (index != -1) {
            tourists.erase(tourists.begin() + index);
        }
    }

    void updateTourist(const std::string &passportNumber, const std::string &newName) {
        int index = findTouristIndex(passportNumber);
        if (index != -1) {
            tourists[index].name = newName;
        }
    }

    void searchTourist(const std::string &passportNumber) {
        int index = findTouristIndex(passportNumber);
        if (index != -1) {
            std::cout << "Tourist Found: " << tourists[index].name << ", " << tourists[index].passportNumber << std::endl;
        } else {
            std::cout << "Tourist not found" << std::endl;
        }
    }

    void displayTourists() {
        for (const auto &t : tourists) {
            std::cout << "Tourist: " << t.name << ", Passport Number: " << t.passportNumber << std::endl;
        }
    }
};

int main() {
    TourismGuideSystem tgs;
    tgs.addAttraction("Eiffel Tower", "Paris, France", "An iconic symbol of France.");
    tgs.addTourist("John Doe", "123456789");

    tgs.displayAttractions();
    tgs.displayTourists();

    tgs.searchAttraction("Eiffel Tower");
    tgs.searchTourist("123456789");

    tgs.updateAttraction("Eiffel Tower", "Paris, France", "The most-visited paid monument in the world.");
    tgs.updateTourist("123456789", "John Smith");

    tgs.displayAttractions();
    tgs.displayTourists();

    tgs.deleteAttraction("Eiffel Tower");
    tgs.deleteTourist("123456789");

    tgs.displayAttractions();
    tgs.displayTourists();

    return 0;
}