#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    std::string name;
    std::string location;
    std::string description;

    Attraction(std::string n, std::string loc, std::string desc)
        : name(n), location(loc), description(desc) {}
};

class Tourist {
public:
    std::string name;
    std::string nationality;
    
    Tourist(std::string n, std::string nation)
        : name(n), nationality(nation) {}
};

class TourismGuideSystem {
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;

public:
    void addAttraction(const std::string& name, const std::string& location, const std::string& description) {
        attractions.emplace_back(name, location, description);
    }

    void deleteAttraction(const std::string& name) {
        for (size_t i = 0; i < attractions.size(); ++i) {
            if (attractions[i].name == name) {
                attractions.erase(attractions.begin() + i);
                return;
            }
        }
    }

    void updateAttraction(const std::string& name, const std::string& location, const std::string& description) {
        for (auto& attr : attractions) {
            if (attr.name == name) {
                attr.location = location;
                attr.description = description;
                return;
            }
        }
    }

    void searchAttraction(const std::string& name) {
        for (const auto& attr : attractions) {
            if (attr.name == name) {
                std::cout << "Name: " << attr.name 
                          << ", Location: " << attr.location 
                          << ", Description: " << attr.description << std::endl;
                return;
            }
        }
        std::cout << "Attraction not found." << std::endl;
    }

    void displayAttractions() {
        for (const auto& attr : attractions) {
            std::cout << "Name: " << attr.name 
                      << ", Location: " << attr.location 
                      << ", Description: " << attr.description << std::endl;
        }
    }

    void addTourist(const std::string& name, const std::string& nationality) {
        tourists.emplace_back(name, nationality);
    }

    void deleteTourist(const std::string& name) {
        for (size_t i = 0; i < tourists.size(); ++i) {
            if (tourists[i].name == name) {
                tourists.erase(tourists.begin() + i);
                return;
            }
        }
    }

    void updateTourist(const std::string& name, const std::string& nationality) {
        for (auto& tour : tourists) {
            if (tour.name == name) {
                tour.nationality = nationality;
                return;
            }
        }
    }

    void searchTourist(const std::string& name) {
        for (const auto& tour : tourists) {
            if (tour.name == name) {
                std::cout << "Name: " << tour.name 
                          << ", Nationality: " << tour.nationality << std::endl;
                return;
            }
        }
        std::cout << "Tourist not found." << std::endl;
    }

    void displayTourists() {
        for (const auto& tour : tourists) {
            std::cout << "Name: " << tour.name 
                      << ", Nationality: " << tour.nationality << std::endl;
        }
    }
};

int main() {
    TourismGuideSystem system;
    
    system.addAttraction("Eiffel Tower", "Paris", "Iconic French landmark");
    system.displayAttractions();

    system.addTourist("Alice", "USA");
    system.displayTourists();

    system.searchAttraction("Eiffel Tower");

    system.updateAttraction("Eiffel Tower", "Paris, France", "Famous landmark in France");
    system.displayAttractions();

    system.deleteTourist("Alice");
    system.displayTourists();

    return 0;
}