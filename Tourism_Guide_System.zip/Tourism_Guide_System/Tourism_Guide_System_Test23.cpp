#include <iostream>
#include <string>
#include <vector>

struct Tourist {
    int id;
    std::string name;
    std::string nationality;
    int age;
};

struct Attraction {
    int id;
    std::string name;
    std::string location;
    std::string description;
};

class TourismGuideSystem {
private:
    std::vector<Tourist> tourists;
    std::vector<Attraction> attractions;
    int touristCounter;
    int attractionCounter;
    
    Tourist* findTouristById(int id) {
        for (auto& tourist : tourists) {
            if (tourist.id == id) return &tourist;
        }
        return nullptr;
    }
    
    Attraction* findAttractionById(int id) {
        for (auto& attraction : attractions) {
            if (attraction.id == id) return &attraction;
        }
        return nullptr;
    }

public:
    TourismGuideSystem() : touristCounter(0), attractionCounter(0) {}

    void addTourist(const std::string& name, const std::string& nationality, int age) {
        tourists.push_back({++touristCounter, name, nationality, age});
    }
    
    void addAttraction(const std::string& name, const std::string& location, const std::string& description) {
        attractions.push_back({++attractionCounter, name, location, description});
    }

    void deleteTourist(int id) {
        for (auto it = tourists.begin(); it != tourists.end(); ++it) {
            if (it->id == id) {
                tourists.erase(it);
                return;
            }
        }
    }

    void deleteAttraction(int id) {
        for (auto it = attractions.begin(); it != attractions.end(); ++it) {
            if (it->id == id) {
                attractions.erase(it);
                return;
            }
        }
    }
    
    void updateTourist(int id, const std::string& name, const std::string& nationality, int age) {
        Tourist* tourist = findTouristById(id);
        if (tourist) {
            tourist->name = name;
            tourist->nationality = nationality;
            tourist->age = age;
        }
    }
    
    void updateAttraction(int id, const std::string& name, const std::string& location, const std::string& description) {
        Attraction* attraction = findAttractionById(id);
        if (attraction) {
            attraction->name = name;
            attraction->location = location;
            attraction->description = description;
        }
    }

    Tourist* searchTourist(int id) {
        return findTouristById(id);
    }

    Attraction* searchAttraction(int id) {
        return findAttractionById(id);
    }

    void displayTourists() {
        for (const auto& tourist : tourists) {
            std::cout << "ID: " << tourist.id << ", Name: " << tourist.name 
                      << ", Nationality: " << tourist.nationality << ", Age: " << tourist.age << std::endl;
        }
    }

    void displayAttractions() {
        for (const auto& attraction : attractions) {
            std::cout << "ID: " << attraction.id << ", Name: " << attraction.name 
                      << ", Location: " << attraction.location << ", Description: " << attraction.description << std::endl;
        }
    }
};

int main() {
    TourismGuideSystem system;
    system.addTourist("John Doe", "American", 30);
    system.addTourist("Marta Singh", "Indian", 25);
    system.addAttraction("Eiffel Tower", "Paris", "An iconic symbol of France.");
    system.addAttraction("Great Wall", "China", "Historical wall in China.");

    std::cout << "Tourists: " << std::endl;
    system.displayTourists();
    
    std::cout << "Attractions: " << std::endl;
    system.displayAttractions();

    system.updateTourist(1, "John Smith", "Canadian", 32);
    system.updateAttraction(2, "Great Wall", "Beijing", "Great historical wall in Beijing.");

    system.deleteTourist(2);
    system.deleteAttraction(1);

    std::cout << "\nAfter update and delete operations: " << std::endl;
    std::cout << "Tourists: " << std::endl;
    system.displayTourists();
    
    std::cout << "Attractions: " << std::endl;
    system.displayAttractions();

    return 0;
}