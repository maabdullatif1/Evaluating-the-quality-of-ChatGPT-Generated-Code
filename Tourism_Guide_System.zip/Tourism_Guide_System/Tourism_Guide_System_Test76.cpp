#include <iostream>
#include <vector>
#include <string>

class Attraction {
public:
    int id;
    std::string name;
    std::string location;
    std::string description;

    Attraction(int a_id, std::string a_name, std::string a_location, std::string a_description)
        : id(a_id), name(a_name), location(a_location), description(a_description) {}
};

class Tourist {
public:
    int id;
    std::string name;
    std::string email;

    Tourist(int t_id, std::string t_name, std::string t_email)
        : id(t_id), name(t_name), email(t_email) {}
};

class TourismGuideSystem {
private:
    std::vector<Attraction> attractions;
    std::vector<Tourist> tourists;

    template<typename T>
    void displayList(const std::vector<T>& list) {
        for (const auto& item : list) {
            std::cout << "ID: " << item.id << ", Name: " << item.name;
            if constexpr (std::is_same<T, Attraction>::value) {
                std::cout << ", Location: " << item.location << ", Description: " << item.description;
            } else if constexpr (std::is_same<T, Tourist>::value) {
                std::cout << ", Email: " << item.email;
            }
            std::cout << std::endl;
        }
    }

public:
    void addAttraction(int id, std::string name, std::string location, std::string description) {
        attractions.emplace_back(id, name, location, description);
    }

    void deleteAttraction(int id) {
        attractions.erase(std::remove_if(attractions.begin(), attractions.end(),
            [id](const Attraction& a) { return a.id == id; }), attractions.end());
    }

    void updateAttraction(int id, std::string name, std::string location, std::string description) {
        for (auto& a : attractions) {
            if (a.id == id) {
                a.name = name;
                a.location = location;
                a.description = description;
            }
        }
    }

    void searchAttraction(int id) {
        for (const auto& a : attractions) {
            if (a.id == id) {
                std::cout << "ID: " << a.id << ", Name: " << a.name
                          << ", Location: " << a.location << ", Description: " << a.description << std::endl;
            }
        }
    }

    void addTourist(int id, std::string name, std::string email) {
        tourists.emplace_back(id, name, email);
    }

    void deleteTourist(int id) {
        tourists.erase(std::remove_if(tourists.begin(), tourists.end(),
            [id](const Tourist& t) { return t.id == id; }), tourists.end());
    }

    void updateTourist(int id, std::string name, std::string email) {
        for (auto& t : tourists) {
            if (t.id == id) {
                t.name = name;
                t.email = email;
            }
        }
    }

    void searchTourist(int id) {
        for (const auto& t : tourists) {
            if (t.id == id) {
                std::cout << "ID: " << t.id << ", Name: " << t.name << ", Email: " << t.email << std::endl;
            }
        }
    }

    void displayAttractions() {
        displayList(attractions);
    }

    void displayTourists() {
        displayList(tourists);
    }
};

int main() {
    TourismGuideSystem tgs;
    tgs.addAttraction(1, "Eiffel Tower", "Paris, France", "An iconic symbol of France.");
    tgs.addTourist(101, "John Doe", "john@example.com");
    tgs.displayAttractions();
    tgs.displayTourists();
    tgs.updateAttraction(1, "Eiffel Tower", "Paris, France", "World-famous tower in Paris.");
    tgs.updateTourist(101, "John Doe", "john.doe@example.com");
    tgs.searchAttraction(1);
    tgs.searchTourist(101);
    tgs.deleteAttraction(1);
    tgs.deleteTourist(101);
    tgs.displayAttractions();
    tgs.displayTourists();
    return 0;
}